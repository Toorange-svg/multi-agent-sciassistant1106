"""Real gateway/Web dispatch, isolated stores and no provider calls."""
import io
import json
from pathlib import Path

import pytest
from flask import abort, g

import app as account
import web_app as web
from research_library import LibraryLinks, processing_state, original_path, copy_pdf

PDF = b'%PDF-1.4\n isolated library fixture\n%%EOF'
FILE_ID = 'a' * 32


class Database:
    def __init__(self, rows):
        self.rows, self.calls, self.result = rows, [], None

    def cursor(self): return self
    def __enter__(self): return self
    def __exit__(self, *args): pass
    def close(self): pass
    def commit(self): pass
    def rollback(self): pass

    def execute(self, sql, params=None):
        self.calls.append((sql, params))
        if 'INSERT INTO user_files' in sql:
            file_id, user_id, name, stored, path, size, kind, status = params
            self.rows[file_id] = dict(file_id=file_id, user_id=user_id, original_filename=name,
                stored_filename=stored, file_path=path, file_size=size, file_type=kind,
                status=status, upload_time='2026-10-15 00:00:00')
        elif 'DELETE FROM user_files' in sql:
            self.rows.pop(params[0], None)
        elif 'FROM user_files' in sql:
            if 'file_id=' in sql or 'file_id = ' in sql:
                row = self.rows.get(params[0])
                self.result = row if row and str(row['user_id']) == str(params[1]) else None
            else:
                self.result = [dict(row, name=row['original_filename'], size=row['file_size'])
                               for row in self.rows.values() if str(row['user_id']) == str(params[0])]

    def fetchone(self): return self.result
    def fetchall(self): return self.result


@pytest.fixture
def isolated(tmp_path, monkeypatch):
    library, uploads, tasks = [tmp_path / name for name in ('library', 'uploads', 'tasks')]
    for folder in (library / 'alice', uploads, tasks): folder.mkdir(parents=True)
    source = library / 'alice' / (FILE_ID + '.pdf'); source.write_bytes(PDF)
    row = dict(file_id=FILE_ID, user_id='alice', original_filename='原始论文.pdf', stored_filename=source.name,
               file_path=str(source), file_size=len(PDF), file_type='pdf', status='processed', upload_time=None)
    database = Database({FILE_ID: row})
    monkeypatch.setattr(account, 'get_db_connection', lambda: database)
    monkeypatch.setattr(account, 'UPLOAD_BASE_DIR', library)
    monkeypatch.setattr(account, 'RESEARCH_LIBRARY_STATE_PATH', tmp_path / 'library.sqlite3')
    monkeypatch.setattr(account, 'PDF_SESSION_STATE_PATH', tmp_path / 'bindings.sqlite3')
    monkeypatch.setattr(account, 'SCIENCE_TASK_STATE_DIR', tasks)
    monkeypatch.setattr(account, 'SCIENCE_TASK_OWNER_STATE_PATH', tmp_path / 'owners.json')
    monkeypatch.setattr(account, '_SCIENCE_TASK_OWNERS', {})
    monkeypatch.setattr(account, '_current_auth_version', lambda owner: 0)
    monkeypatch.setattr(account, '_LOCAL_SCIENCE_APP', web.app)
    monkeypatch.setenv('SCIASSISTANT_WEB_BASE', '')
    monkeypatch.setattr(web, 'TASKS', {})
    monkeypatch.setattr(web, 'TASK_STATE_DIR', tasks)
    monkeypatch.setattr(web, 'UPLOAD_DIR', uploads)
    monkeypatch.setattr(web, '_missing_task_configuration', lambda mode: [])
    monkeypatch.setattr(web.rag_web, 'readiness', lambda: {'ready': True})
    launched = []
    monkeypatch.setattr(web, '_enqueue_retrieval_task', lambda *args, **kwargs: launched.append((args, kwargs)))
    def require_conversation(cid):
        if str(g.current_user_id) != 'alice' or cid not in {'chat-a', 'chat-a2'}: abort(404)
    monkeypatch.setattr(account, '_require_science_conversation_owner', require_conversation)
    return account.app.test_client(), database, launched, source, tmp_path


def headers(owner='alice'):
    return {'Authorization': 'Bearer ' + account.generate_token(owner, owner)} if owner else {}


def analyze(client, owner='alice', **extra):
    return client.post('/api/science/tasks', headers=headers(owner), json={
        'query': '请解释本文方法', 'conversation_id': 'chat-a', 'processing_mode': 'multi_agent_pdf',
        'library_file_id': FILE_ID, **extra})


def test_upload_is_storage_only_and_legacy_processed_does_not_mean_indexed(isolated):
    client, database, launched, _, _ = isolated
    response = client.post('/api/research-library/upload', headers=headers(), data={
        'files': (io.BytesIO(PDF), '新论文.pdf')})
    assert response.status_code == 200
    item = response.json['files'][0]
    assert item['processing_state'] == 'uploaded'
    assert database.rows[item['file_id']]['status'] == 'processing'
    assert not any("SET status = 'processed'" in sql for sql, _ in database.calls)
    assert not launched
    listing = client.get('/api/research-library/files', headers=headers())
    assert listing.status_code == 200
    assert all(file['processing_state'] == 'uploaded' and not file['has_indexed_run'] for file in listing.json['files'])
    assert 'file_path' not in listing.text


@pytest.mark.parametrize('name,content,status', [('fake.pdf', b'not a PDF', 400), ('text.txt', b'hello', 400)])
def test_pdf_upload_rejects_non_pdf_before_write(isolated, name, content, status):
    client, database, launched, source, _ = isolated
    before = list(source.parent.iterdir())
    response = client.post('/api/research-library/upload', headers=headers(), data={'files': (io.BytesIO(content), name)})
    assert response.status_code == status and not launched
    assert list(source.parent.iterdir()) == before


def test_selected_pdf_enters_existing_workflow_and_durable_binding(isolated, monkeypatch):
    client, _, launched, source, root = isolated
    response = analyze(client)
    assert response.status_code == 202, response.json
    task = response.json['task']; task_id = task['id']
    assert task['library_file_id'] == FILE_ID and task['source_scope'] == 'uploaded_pdf'
    assert task['source_policy'] == 'local' and not task['public_search_allowed']
    assert task['processing_mode'] == 'multi_agent_rag'
    copied = launched[0][1]['pdf']
    assert copied != source and copied.read_bytes() == PDF
    assert len(task['library_file_sha256']) == 64 and str(root) not in response.text
    descriptor = client.get('/api/science/conversations/chat-a/pdf-attachment', headers=headers()).json['attachment']
    assert descriptor['library_file_id'] == FILE_ID
    monkeypatch.setattr(web, 'TASKS', {})
    response = client.post('/api/science/tasks', headers=headers(), json={
        'query': '追问这个方法', 'conversation_id': 'chat-a', 'processing_mode': 'multi_agent_pdf',
        'pdf_source_task_id': task_id})
    assert response.status_code == 202 and response.json['task']['library_file_id'] == FILE_ID
    assert launched[-1][1]['pdf'] == copied
    detail = client.get('/api/research-library/files/' + FILE_ID, headers=headers())
    assert len(detail.json['file']['outcomes']) == 2 and detail.json['file']['processing_state'] == 'queued'


def test_auto_requires_per_request_consent_and_uses_same_task_path(isolated):
    client, _, launched, _, _ = isolated
    bad = analyze(client, processing_mode='multi_agent_rag', source_policy='auto')
    assert bad.status_code == 400 and not launched
    good = analyze(client, processing_mode='multi_agent_rag', source_policy='auto', allow_public_search=True,
                   query='对比本文与原始 LoRA 方法')
    assert good.status_code == 202
    assert good.json['task']['source_scope'] == 'uploaded_pdf_and_arxiv'
    assert good.json['task']['public_search_allowed'] is True
    second = analyze(client)
    assert second.status_code == 202 and second.json['task']['public_search_allowed'] is False


@pytest.mark.parametrize('endpoint', ['/api/research-library/files', '/api/research-library/files/' + FILE_ID])
def test_anonymous_and_cross_account_library_reads(isolated, endpoint):
    client = isolated[0]
    assert client.get(endpoint).status_code == 401
    other = client.get(endpoint, headers=headers('bob'))
    assert (other.status_code == 200 and other.json['files'] == []) if endpoint.endswith('/files') else other.status_code == 404


def test_original_pdf_preview_is_owned_typed_and_not_a_path_capability(isolated):
    client, database, _, _, root = isolated
    endpoint = '/api/research-library/files/' + FILE_ID + '/pdf'
    assert client.get(endpoint).status_code == 401
    assert client.get(endpoint, headers=headers('bob')).status_code == 404
    response = client.get(endpoint, headers=headers())
    assert response.status_code == 200 and response.data == PDF
    assert response.mimetype == 'application/pdf' and str(root) not in response.headers.get('Content-Disposition', '')
    outside = root / 'secret.pdf'; outside.write_bytes(PDF)
    database.rows[FILE_ID]['file_path'] = str(outside)
    assert client.get(endpoint, headers=headers()).status_code == 404


def test_spoofed_owner_cross_conversation_and_public_capability_rejected(isolated):
    client, _, launched, _, _ = isolated
    assert analyze(client, owner='bob', conversation_id='', user_id='alice').status_code == 404
    assert analyze(client, conversation_id='chat-b').status_code == 404
    assert analyze(client, library_file_id='../private').status_code == 404
    assert web.app.test_client().post('/api/tasks', json={
        'query': 'read', 'processing_mode': 'multi_agent_pdf', 'library_file_id': FILE_ID,
        'library_source': {'path': 'private.pdf', 'file_id': FILE_ID}}).status_code == 404
    assert not launched


@pytest.mark.parametrize('extra', [{'pdf_source_task_id': 'a' * 12}, {'processing_mode': 'pdf_local'}, {'library_file_id': ['bad']}])
def test_mutually_exclusive_selection_is_rejected(isolated, extra):
    client, _, launched, _, _ = isolated
    assert analyze(client, **extra).status_code == 400 and not launched


def test_path_guard_and_invalid_pdf_fail_before_task(isolated):
    client, database, launched, source, root = isolated
    outside = root / 'outside.pdf'; outside.write_bytes(PDF)
    database.rows[FILE_ID]['file_path'] = str(outside)
    assert analyze(client).status_code == 400 and not launched
    database.rows[FILE_ID]['file_path'] = str(source)
    source.write_bytes(b'not PDF')
    assert analyze(client).status_code == 400 and not launched


def test_actual_pdf_index_state_is_not_answer_quality_or_public_index_count(isolated):
    client, _, _, _, _ = isolated
    task = analyze(client).json['task']; task_id = task['id']
    web._update(task_id, execution={'reading_progress': {'papers_indexed': 12}}, status='running')
    assert client.get('/api/research-library/files/' + FILE_ID, headers=headers()).json['file']['processing_state'] == 'queued'
    web._update(task_id, execution={'reading_progress': {'uploaded_pdf_phase': 'pdf_parse'}})
    assert client.get('/api/research-library/files/' + FILE_ID, headers=headers()).json['file']['processing_state'] == 'parsing'
    web._update(task_id, execution={'reading_progress': {'uploaded_pdf_phase': 'pdf_index'}})
    assert client.get('/api/research-library/files/' + FILE_ID, headers=headers()).json['file']['processing_state'] == 'indexing'
    web._update(task_id, execution={'reading_progress': {'uploaded_pdf_indexed': 1}}, status='needs_review', report_available=True)
    file = client.get('/api/research-library/files/' + FILE_ID, headers=headers()).json['file']
    assert file['processing_state'] == 'indexed' and file['index_scope'] == 'private_task'
    assert file['outcomes'][0]['status'] == 'needs_review' and file['outcomes'][0]['report_available']


def test_missing_linked_snapshot_is_unknown_not_unindexed(isolated):
    client, _, _, _, root = isolated
    task = analyze(client).json['task']
    (root / 'tasks' / (task['id'] + '.json')).unlink()
    file = client.get('/api/research-library/files/' + FILE_ID, headers=headers()).json['file']
    assert file['processing_state'] == 'unavailable' and file['unavailable_outcome_count'] == 1
    assert file['outcomes'][0]['report_available'] is False


def test_missing_owner_binding_does_not_grant_task_access_from_library_link(isolated, monkeypatch):
    client, _, _, _, _ = isolated
    analyze(client)
    monkeypatch.setattr(account, '_SCIENCE_TASK_OWNERS', {})
    file = client.get('/api/research-library/files/' + FILE_ID, headers=headers()).json['file']
    assert file['processing_state'] == 'unavailable'
    assert file['outcomes'][0]['task_id'] is None and not file['outcomes'][0]['report_available']


def test_boolean_index_flag_cannot_manufacture_success():
    assert processing_state({'status': 'failed', 'execution': {'reading_progress': {'uploaded_pdf_indexed': True}}}) == 'failed'


def test_preview_authorizes_before_render_and_never_indexes(isolated, monkeypatch):
    client, _, launched, _, _ = isolated
    calls = []
    import research_library
    def render(path, page):
        calls.append((path, page))
        return {'page': page, 'page_count': 2}, b'\x89PNG\r\n\x1a\nFAKE'
    monkeypatch.setattr(research_library, 'render_preview', render)
    url = '/api/research-library/files/' + FILE_ID + '/pages/1'
    assert client.get(url, headers=headers('bob')).status_code == 404
    assert client.get(url).status_code == 401
    assert not calls
    response = client.get(url, headers=headers())
    assert response.status_code == 200 and response.mimetype == 'image/png'
    assert response.headers['X-PDF-Page-Count'] == '2' and len(calls) == 1
    assert client.get('/api/research-library/files/' + FILE_ID, headers=headers()).json['file']['processing_state'] == 'uploaded'
    assert not launched and "object-src 'none'" in response.headers['Content-Security-Policy']


@pytest.mark.parametrize('code,status', [('PREVIEW_BUSY', 503), ('PREVIEW_TIMEOUT', 503), ('PREVIEW_UNAVAILABLE', 422)])
def test_preview_errors_are_safe_and_allow_download(isolated, monkeypatch, code, status):
    client = isolated[0]
    import research_library
    def fail(*_): raise research_library.PreviewError(code)
    monkeypatch.setattr(research_library, 'render_preview', fail)
    response = client.get('/api/research-library/files/' + FILE_ID + '/pages/1', headers=headers())
    assert response.status_code == status and response.json['error'] == code
    assert 'file_path' not in response.text and '下载' in response.json['message']
    assert client.get('/api/research-library/files/' + FILE_ID + '/pdf', headers=headers()).status_code == 200


def test_real_disposable_renderer_and_limits(tmp_path, monkeypatch):
    import pymupdf as fitz
    import research_library
    pdf = tmp_path / 'source.pdf'
    with fitz.open() as document:
        document.new_page().insert_text((72, 72), 'Original library page')
        document.new_page()
        document.save(pdf)
    meta, png = research_library.render_preview(pdf, 1)
    assert meta == {'page': 1, 'page_count': 2} and png.startswith(b'\x89PNG')
    for page in (True, 0, 10001):
        with pytest.raises(research_library.PreviewError, match='PREVIEW_PAGE_INVALID'):
            research_library.render_preview(pdf, page)
    with pytest.raises(research_library.PreviewError): research_library.render_preview(pdf, 3)
    # Slots limit concurrency before launching another parser.
    assert research_library._PREVIEW_SLOTS.acquire(False) and research_library._PREVIEW_SLOTS.acquire(False)
    try:
        with pytest.raises(research_library.PreviewError, match='PREVIEW_BUSY'):
            research_library.render_preview(pdf, 1)
    finally:
        research_library._PREVIEW_SLOTS.release(); research_library._PREVIEW_SLOTS.release()
    def timeout(*args, **kwargs): raise research_library.subprocess.TimeoutExpired('isolated', 15)
    monkeypatch.setattr(research_library.subprocess, 'run', timeout)
    with pytest.raises(research_library.PreviewError, match='PREVIEW_TIMEOUT'):
        research_library.render_preview(pdf, 1)


def test_deleting_original_does_not_break_old_task_or_pdf_followup(isolated):
    client, _, launched, source, _ = isolated
    first = analyze(client).json['task']; copied = launched[0][1]['pdf']
    assert client.delete('/api/files/delete/' + FILE_ID, headers=headers()).status_code == 200
    assert not source.exists() and copied.read_bytes() == PDF
    assert analyze(client).status_code == 404
    assert client.get('/api/research-library/files/' + FILE_ID, headers=headers()).status_code == 404
    response = client.post('/api/science/tasks', headers=headers(), json={
        'query': '继续解释本文', 'conversation_id': 'chat-a', 'processing_mode': 'multi_agent_pdf',
        'pdf_source_task_id': first['id']})
    assert response.status_code == 202 and launched[-1][1]['pdf'] == copied


def test_ledger_user_scope_and_restart_read_only(tmp_path):
    path = tmp_path / 'links.sqlite3'
    assert LibraryLinks(path).tasks('alice', FILE_ID) == [] and not path.exists()
    ledger = LibraryLinks(path)
    ledger.link('alice', FILE_ID, 'a' * 12, 'chat-a')
    ledger.link('alice', FILE_ID, 'a' * 12, 'chat-a')
    assert LibraryLinks(path).tasks('alice', FILE_ID) == [{'task_id': 'a' * 12, 'conversation_id': 'chat-a'}]
    assert ledger.tasks('bob', FILE_ID) == []
    with pytest.raises(ValueError): ledger.link('alice', FILE_ID, '../task')


@pytest.mark.parametrize('task,expected', [(None, 'uploaded'), ({'status': 'partial'}, 'unavailable'),
    ({'status': 'failed'}, 'failed'), ({'status': 'cancelled'}, 'cancelled'),
    ({'status': 'failed', 'execution': {'reading_progress': {'uploaded_pdf_indexed': 1}}}, 'indexed')])
def test_processing_state_never_infers_index_from_success(task, expected):
    assert processing_state(task) == expected


def test_copy_does_not_overwrite_or_remove_existing_destination(tmp_path):
    source = tmp_path / 'source.pdf'; source.write_bytes(PDF)
    destination = tmp_path / 'old.pdf'; destination.write_bytes(b'KEEP')
    with pytest.raises(FileExistsError): copy_pdf(source, destination)
    assert destination.read_bytes() == b'KEEP'


def test_library_files_shipped_and_fingerprinted():
    from runtime_identity import IDENTITY_FILES
    root = Path(__file__).resolve().parents[1]
    assert all(name in IDENTITY_FILES for name in ('research_library.py', 'chatAi/research_library.js', 'chatAi/research_library.css'))
    assert "!fileLibraryList.querySelector('.file-checkbox:checked')" in (root / 'chatAi/ai_chat.html').read_text(encoding='utf8')
    for name in ('Dockerfile.account.cloud', 'Dockerfile.cloud'):
        assert 'COPY research_library.py /app/' in (root / name).read_text(encoding='utf8')
        assert '!research_library.py' in (root / (name + '.dockerignore')).read_text(encoding='utf8')
