"""Question focus reaches review; passage summaries cannot deny cited outputs."""
from copy import deepcopy
from dataclasses import replace
import inspect
import json

import pytest

from multi_agent_quality import (PASSAGE_EXCLUSIVITY_POLICY, check_passage_exclusivity,
    check_claim_revision, citation_audit_input, answer_focus_brief, answer_requirements)
from test_multi_agent_report_fields import draft, evidence

INPUT = 'The operation treats constants aFP32 9 as inputs to a second quantization.'
OUTPUT = 'This second step yields the quantized constants aFP8 9 and the second level constants bFP32 4.'
BAD = '本次所引片段只说明该输入角色，未提供完整公式。'
GOOD = '该片段同时说明输入和两个输出；这里仅解释所问的输入角色。'


def example(field='qualification'):
    data, sources = draft(), evidence()
    data['passage_exclusivity_policy'] = PASSAGE_EXCLUSIVITY_POLICY
    data['claims'][0].update(text='量化常数被用作第二次量化的输入。', scope_note='', qualification='原文同时描述输入和输出。')
    data['claims'][0][field] = BAD
    sources['evidence'][0]['excerpt'] = INPUT + ' ' + OUTPUT
    return data, sources


@pytest.mark.parametrize('field', ['text', 'scope_note', 'qualification'])
def test_passage_only_input_claim_is_contradicted_in_its_actual_field(field):
    data, sources = example(field)
    before = deepcopy((data, sources))
    rows = check_passage_exclusivity(data, sources)
    assert len(rows) == 1 and rows[0]['field'] == field
    assert rows[0]['reason'] == 'PASSAGE_CONTENT_EXCLUSIVITY_CONTRADICTION'
    assert not rows[0]['automatic_rewrite']
    for row in rows[0]['source_witnesses']:
        assert row['quote'] == sources['evidence'][0][row['field']][row['start']:row['end']]
    assert (data, sources) == before


@pytest.mark.parametrize('value', [
    GOOD, '该句只说明输入角色。', '本次回答只解释输入角色。',
    '不能说本次所引片段只说明该输入角色。', '如果该片段只说明输入角色，才需补读。',
    '此处只说明输入角色，原片段还提供输出。', '该片段未提供完整推导，但提供输入和输出。',
])
def test_sentence_focus_answer_focus_conditional_and_missing_derivation_are_not_exclusivity(value):
    data, sources = example(); data['claims'][0]['qualification'] = value
    assert not check_passage_exclusivity(data, sources)


@pytest.mark.parametrize('fault', [
    'old_policy', 'unapproved', 'uncited', 'multiple_cited', 'input_only', 'outputs_only',
    'hypothetical_input', 'hypothetical_output', 'different_representation', 'formula_only',
])
def test_no_unapproved_cross_passage_or_hypothetical_counterevidence(fault):
    data, sources = example()
    row = sources['evidence'][0]
    if fault == 'old_policy': data.pop('passage_exclusivity_policy')
    elif fault == 'unapproved': row['review_status'] = 'pending'
    elif fault == 'uncited': data['claims'][0]['evidence_ids'] = ['unknown']
    elif fault == 'multiple_cited':
        sources['evidence'].append({**row, 'evidence_id':'e2'})
        data['claims'][0]['evidence_ids'].append('e2')
    elif fault == 'input_only': row['excerpt'] = INPUT
    elif fault == 'outputs_only': row['excerpt'] = OUTPUT
    elif fault == 'hypothetical_input': row['excerpt'] = 'If required, ' + INPUT + ' ' + OUTPUT
    elif fault == 'hypothetical_output': row['excerpt'] = INPUT + ' This step may yield aFP8 9 and bFP32 4.'
    elif fault == 'different_representation': row.update(excerpt=INPUT, text=INPUT + ' ' + OUTPUT)
    elif fault == 'formula_only': row['excerpt'] = INPUT + ' aFP8 9 + bFP32 4'
    assert not check_passage_exclusivity(data, sources)


def test_english_and_changed_source_symbols_use_literal_prose_not_qlora_answers():
    data, sources = example()
    data['claims'][0]['qualification'] = 'The selected excerpt only describes the input role.'
    assert check_passage_exclusivity(data, sources)
    assert 'c1' not in sources['evidence'][0]['excerpt']
    audit_input = citation_audit_input(data, sources)
    assert audit_input['passage_exclusivity_policy'] == PASSAGE_EXCLUSIVITY_POLICY


def test_detail_only_actual_edit_still_needs_complete_reaudit():
    data, sources = example()
    feedback = {'code_issues': check_passage_exclusivity(data, sources)}
    assert check_claim_revision(data, deepcopy(data), feedback)['code_issues']
    revised = deepcopy(data); revised['claims'][0]['scope_note'] = GOOD
    assert check_claim_revision(data, revised, feedback)['code_issues']
    revised['claims'][0]['qualification'] = GOOD
    result = check_claim_revision(data, revised, feedback)
    assert not result['code_issues'] and result['changed_claims_still_require_audit']


@pytest.mark.parametrize('question, expected', [
    ('解释表3中的88.6和40.1属于哪列，不要求统计检验。', True),
    ('请计算置信区间并做显著性检验。', False),
])
def test_brief_reviewer_rules_keep_real_gaps_and_explicit_uncertainty(question, expected):
    brief = answer_focus_brief(answer_requirements(question), {'groups':[]})
    assert ('confidence_intervals' in brief['not_mandatory_for_this_question']) is expected
    assert any('real unsupported number' in value for value in brief['review_decision_rules'])
    assert not brief['evidence_auto_approval'] and not brief['automatic_claim_removal']


@pytest.mark.parametrize('recovery', [False, True])
def test_formal_workflow_sends_same_focus_before_review_and_to_gap_without_extra_calls(tmp_path, recovery):
    from test_multi_agent_pipeline_v2 import agents, pipeline
    configured, calls = agents(recovery=recovery)
    received = {}
    def wrap(worker):
        handler = worker.handler
        def capture(packet):
            received.setdefault(worker.role, []).append([
                item['artifact_id'] for item in packet['inputs']
                if item['payload'].get('schema_version') == 'sciassistant.answer-focus-brief/v1'])
            return handler(packet)
        return replace(worker, handler=capture)
    configured = replace(configured, **{role:wrap(configured.by_role(role)) for role in
        ('planner','retriever','reviewer','gap_analyst','writer','citation_auditor')})
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run('review-focus', 'owner', '解释这个方法，不需要完整公式。')
    assert result['run']['model_calls_used'] == (8 if recovery else 5)
    refs = {row[0] for role in ('reviewer','writer','citation_auditor') for row in received[role] if row}
    assert len(refs) == 1 and all(len(row) == 1 for role in
        ('reviewer','writer','citation_auditor') for row in received[role])
    if recovery: assert received['gap_analyst'] == [list(refs)]
    assert received['planner'] == [[]] and all(row == [] for row in received['retriever'])
    events = [json.loads(line) for line in (tmp_path/'events.jsonl').read_text().splitlines()]
    focus_index = next(i for i, row in enumerate(events) if row['event'] == 'answer_focus_prepared')
    review_index = next(i for i, row in enumerate(events) if row['event'] == 'agent_started' and row['role'] == 'reviewer')
    assert focus_index < review_index


def test_workflow_repairs_only_exclusive_detail_then_reaudits_full_claim(tmp_path):
    from test_multi_agent_pipeline_v2 import agents, pipeline, worker
    configured, calls = agents(partial=True)
    drafts = []
    def writer(_):
        calls.append('writer')
        value, _ = example()
        value['claims'][0].update(evidence_ids=['arxiv-1'], confidence='low')
        if drafts: value['claims'][0]['qualification'] = GOOD
        drafts.append(value)
        return {'output':value}
    configured = replace(configured, writer=worker('writer',writer,'write_approved_claims'))
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {'status':'ok','papers':[
        {'paper_id':'1','title':'Generic operation','abstract': INPUT + ' ' + OUTPUT}]})
    result = flow.run('passage-repair','owner','解释输入角色')
    assert calls.count('writer') == calls.count('citation_auditor') == 2
    assert result['run']['model_calls_used'] == 7
    final = flow.artifacts.get(result['final_artifact_id'])
    approved = flow.artifacts.get(final['artifact_refs']['approved'])
    checked = flow.artifacts.get(final['artifact_refs']['draft'])
    assert check_passage_exclusivity(drafts[0],approved)
    assert not check_passage_exclusivity(checked,approved)
    assert checked['claims'][0]['qualification']==GOOD
    assert not flow.artifacts.get(final['artifact_refs']['audit'])['code_issues']
    assert BAD not in result['direct_answer']


def test_format_retry_has_no_arbitrary_eight_claim_or_6500_character_target():
    from multi_agent_pipeline_v2 import LiteraturePipelineV2
    source = inspect.getsource(LiteraturePipelineV2._invoke)
    assert '最多8条重要声明' not in source and '6500字符' not in source
    assert '不设声明条数或正文字符上限' in source


def test_effective_writer_prompt_has_no_conflicting_length_target_or_generic_detail_instruction():
    from multi_agent_live import effective_role_prompt
    for local in (False, True):
        prompt = effective_role_prompt('writer', local_source=local)
        assert 'at most 12 claims' not in prompt and '9000 characters' not in prompt
        assert 'Keep those details in qualification' not in prompt
        assert 'Do not move those generic caveats into qualification' in prompt


@pytest.mark.parametrize('value, error', [
    ({'metrics':['role']*9}, 'TOO_MANY_ITEMS'),
    ({'core':{'unsafe':'private-value'}}, 'EXPECTED_ARRAY'),
    ({'support':['secret-private-value'*10]}, 'INVALID_STRING_LENGTH'),
    ({'metrics':[{'unsafe':'private-value'}]}, 'EXPECTED_STRING'),
])
def test_planner_diagnostic_reports_static_paths_bounds_not_raw_terms(value,error):
    from multi_agent_live import plan_term_diagnostics
    rows = plan_term_diagnostics({'output':{'groups':[value]}})
    assert any(r['error']==error for r in rows)
    assert 'private-value' not in json.dumps(rows)
    assert all(r['path'].startswith('groups[0].') for r in rows)


def test_real_adapter_delivers_safe_term_feedback_to_one_planner_correction(tmp_path,monkeypatch):
    from multi_agent_live import LiveModelClient
    from test_multi_agent_live import Response, config, typed_plan_fixture, add_typed_report_review
    from test_multi_agent_pipeline_v2 import agents,pipeline
    monkeypatch.setenv('MODEL_REQUEST_URL','https://example.test/v1/chat/completions')
    configured,_ = agents(); valid = configured.planner.handler
    packets = []
    def post(_url,**kwargs):
        packet = json.loads(kwargs['json']['messages'][1]['content']); packets.append(packet)
        if len(packets)==1:
            return Response({'output':{'schema_version':'sciassistant.research-plan/v7',
                'groups':[{'id':'g1','core':{'invalid':'do-not-save-raw'},'queries':['A']}]}})
        assert any(item['payload'].get('term_issues',[{}])[0].get('path')=='groups[0].core'
            for item in packet['inputs'] if item['payload'].get('term_issues'))
        assert 'do-not-save-raw' not in json.dumps(packet)
        return Response({'output': typed_plan_fixture()})
    client = LiveModelClient(config(),post=post)
    configured.planner.handler = lambda p:client.call('planner',p)
    from tests.test_multi_agent_sections import good_draft
    configured.writer.handler = lambda p: {'output': good_draft(next(i['payload'] for i in p['inputs']
        if i['payload'].get('schema_version') == 'sciassistant.writer-job/v1'))}
    add_typed_report_review(configured)
    flow,_ = pipeline(tmp_path,configured)
    result = flow.run('exact-plan-feedback','owner','解释A')
    assert result['run']['model_calls_used']==6 and result['run']['status']=='completed'
    events = [json.loads(line) for line in (tmp_path/'events.jsonl').read_text().splitlines()]
    assert len([e for e in events if e['event']=='agent_started' and e['role']=='citation_auditor']) == 1
    assert not any(e['event']=='audit_protocol_retry' for e in events)
    original = {i['artifact_id'] for i in packets[0]['inputs']}
    corrected = {i['artifact_id'] for i in packets[1]['inputs']}
    assert original<corrected and len(corrected-original)==1
