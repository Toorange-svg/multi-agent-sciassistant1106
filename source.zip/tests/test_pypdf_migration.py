"""Regression coverage for the maintained pypdf migration and MCP PDF gate."""

from importlib.metadata import version
import inspect
from pathlib import Path
import sys
from unittest import mock

import fitz
import pdf_pipeline
from pypdf import PdfReader


ROOT = Path(__file__).resolve().parents[1]
for entry in (str(ROOT), str(ROOT / "deepdiver_v2")):
    if entry not in sys.path:
        sys.path.insert(0, entry)

from deepdiver_v2.src.tools.mcp_tools import MCPTools  # noqa: E402


CANARY = "token=pdf-migration-secret C:\\private\\migration.pdf"


def _make_pdf(path: Path, text: str = "maintained pypdf fallback evidence") -> None:
    document = fitz.open()
    page = document.new_page()
    page.insert_text((72, 72), text)
    document.save(path)
    document.close()


def test_runtime_uses_supported_pypdf_major_version():
    major = int(version("pypdf").split(".", 1)[0])
    assert 6 <= major < 7


def test_requirements_use_pypdf_and_drop_deprecated_distribution():
    requirements = (ROOT / "deepdiver_v2" / "requirements.txt").read_text(encoding="utf-8")
    assert "pypdf>=6.19.0,<7.0.0" in requirements
    assert "PyPDF2" not in requirements


def test_production_python_has_no_pypdf2_imports():
    production_files = [ROOT / "app.py", ROOT / "pdf_pipeline.py"]
    production_files.extend((ROOT / "deepdiver_v2" / "src").rglob("*.py"))
    for source_file in production_files:
        source = source_file.read_text(encoding="utf-8")
        assert "import PyPDF2" not in source, source_file
        assert "from PyPDF2" not in source, source_file


def test_real_pdf_reaches_pypdf_fallback_without_deprecation_warning(tmp_path, monkeypatch):
    pdf = tmp_path / "fallback.pdf"
    _make_pdf(pdf)
    monkeypatch.setattr(pdf_pipeline, "PDF_PARSE_CACHE_DIR", tmp_path / "cache")

    with (
        mock.patch("fitz.open", side_effect=RuntimeError("primary unavailable")),
        mock.patch("pdfminer.high_level.extract_text", side_effect=RuntimeError("secondary unavailable")),
    ):
        result = pdf_pipeline.parse_pdf(pdf, enable_ocr=False)

    assert result["success"] is True
    assert result["parser"] == "pypdf"
    assert "maintained pypdf fallback evidence" in result["text"]
    assert PdfReader(pdf).pages


def test_mcp_pdf_reader_has_no_independent_parser_fallbacks():
    source = inspect.getsource(MCPTools._read_pdf_text)
    assert "parse_pdf(path)" in source
    assert "fitz" not in source
    assert "pdfminer" not in source
    assert "PdfReader" not in source


def test_mcp_resource_rejection_fails_closed_without_bypass(tmp_path):
    pdf = tmp_path / "over-budget.pdf"
    _make_pdf(pdf)
    tools = MCPTools.__new__(MCPTools)
    limited = {
        "success": False,
        "extraction_status": "resource_limited",
        "error_code": "PDF_PAGE_LIMIT_EXCEEDED",
        "text": "",
    }

    with mock.patch("pdf_pipeline.parse_pdf", return_value=limited) as parse_pdf:
        assert tools._read_pdf_text(pdf) == ""
    parse_pdf.assert_called_once_with(pdf)


def test_mcp_parser_exception_does_not_log_path_or_exception_text(tmp_path, caplog):
    pdf = tmp_path / CANARY
    tools = MCPTools.__new__(MCPTools)

    with mock.patch("pdf_pipeline.parse_pdf", side_effect=RuntimeError(CANARY)):
        assert tools._read_pdf_text(pdf) == ""

    assert "RuntimeError" in caplog.text
    assert "pdf-migration-secret" not in caplog.text
    assert "private" not in caplog.text
