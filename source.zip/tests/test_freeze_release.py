import json
from pathlib import Path
import subprocess
import zipfile

import pytest

from tools import freeze_release as release


@pytest.mark.parametrize('name', ['.env', '.env.account.cloud', 'logs/secret.py',
    'tools/.env', 'models/model.py', 'chatAi/private.pdf', 'web/a.sql', '../app.py',
    'tools/../app.py', 'chatAi/key.pem', 'deepdiver_v2/src/cache.sqlite3',
    'deepdiver_v2/private.json', 'docs/acceptance/response.json', '/app.py'])
def test_private_and_traversal_excluded(name):
    assert not release.allowed(name)


@pytest.mark.parametrize('name', ['app.py', 'multi_agent_presentation.py',
    'chatAi/attachment_menu.js', 'Dockerfile.account.rag', 'docker-compose.account.rag.yml',
    'tools/freeze_release.py', '.env.account.cloud.example',
    'deepdiver_v2/requirements.rag.cloud.hashes.txt', 'deepdiver_v2/rag.cloud.artifacts.json',
    'bin/windows/start_chat_5000.ps1', 'tests/test_freeze_release.py',
    'deploy/mysql-init/001_schema.sql'])
def test_source_and_deployment_included(name):
    assert release.allowed(name)


@pytest.mark.parametrize('name', ['chatAi/assets/manifest.json', 'frontend/package.json',
    'frontend/package-lock.json', 'frontend/tailwind.config.cjs', 'frontend/tailwind.css',
    'frontend/THIRD_PARTY_NOTICES.md', 'chatAi/vendor/katex/fonts/KaTeX_Main-Regular.ttf',
    'chatAi/vendor/font-awesome/fonts/fontawesome-webfont.woff', 'chatAi/vendor/font-awesome/LICENSE-FONT',
    'chatAi/vendor/prism/LICENSE', 'docs/DEPLOYMENT_READINESS_ACCEPTANCE_20261023.md',
    'tests/fixtures/full_report_cases.json'])
def test_reviewed_static_delivery_and_rebuild_sources_included(name):
    assert release.allowed(name)


@pytest.mark.parametrize('name', ['tools/user_server.py', 'deploy/user-server.env.example',
    'source_delivery.py', 'docs/USER_SERVER_DEPLOYMENT_20261023.md',
    'docs/DEPLOYMENT_NONQUALITY_ACCEPTANCE_20261023.md'])
def test_nonquality_deployment_materials_included(name):
    assert release.allowed(name)


@pytest.mark.parametrize('name', ['frontend/private.json', 'frontend/node_modules/a.js',
    'chatAi/vendor/private.json', 'chatAi/assets/user.json', 'tests/fixtures/user_credentials.json'])
def test_static_asset_fix_does_not_allow_arbitrary_json_or_dependency_trees(name):
    assert not release.allowed(name)


def test_every_pinned_runtime_frontend_asset_has_a_release_allowlist_entry():
    root = Path(__file__).resolve().parents[1]
    manifest = json.loads((root/'chatAi/assets/manifest.json').read_text(encoding='utf-8'))
    assert manifest['files']
    assert all(release.allowed('chatAi/'+row['path']) for row in manifest['files'])


def repository(tmp_path):
    subprocess.run(['git', 'init', '-q', str(tmp_path)], check=True)
    subprocess.run(['git', '-C', str(tmp_path), 'config', 'user.email', 'test@example.invalid'], check=True)
    subprocess.run(['git', '-C', str(tmp_path), 'config', 'user.name', 'test'], check=True)
    (tmp_path / 'app.py').write_text('original\n')
    release.git(tmp_path, 'add', 'app.py')
    release.git(tmp_path, 'commit', '-qm', 'fixture')
    (tmp_path / 'app.py').write_text('user staged\n')
    release.git(tmp_path, 'add', 'app.py')
    (tmp_path / 'app.py').write_text('current working bytes\n')
    return tmp_path


def test_local_release_isolated_from_staging_and_hash_roundtrip(tmp_path, monkeypatch):
    root = repository(tmp_path / 'repo')
    import runtime_identity
    monkeypatch.setattr(runtime_identity, 'IDENTITY_FILES', ('app.py',))
    (root / '.env').write_text('DO_NOT_EXPORT=private')
    before = release.index_hash(root)
    head = release.git(root, 'rev-parse', 'HEAD')
    result = release.freeze(root, tmp_path / 'release', 'refs/heads/release/test')
    assert result['original_index_unchanged']
    assert release.index_hash(root) == before
    assert release.git(root, 'rev-parse', 'HEAD') == head
    assert release.git(root, 'show', ':app.py') == b'user staged\n'
    working_bytes = (root / 'app.py').read_bytes()
    assert release.git(root, 'show', result['release_commit'] + ':app.py') == working_bytes
    with zipfile.ZipFile(tmp_path / 'release/source.zip') as bundle:
        assert '.env' not in bundle.namelist()
        assert bundle.read('app.py') == working_bytes
    assert release.verify(tmp_path / 'release/source.zip')['passed']
    assert (tmp_path / 'release/source/app.py').read_bytes() == (root / 'app.py').read_bytes()
    with pytest.raises(release.ReleaseError, match='RELEASE_REF_ALREADY_EXISTS'):
        release.freeze(root, tmp_path / 'duplicate', 'refs/heads/release/test')
    assert not (tmp_path / 'duplicate').exists()
    with pytest.raises(release.ReleaseError):
        release.freeze(root, tmp_path / 'release')


def test_archive_tampering_rejected(tmp_path):
    archive = tmp_path / 'bad.zip'
    manifest = {'schema_version': release.SCHEMA,
                'files': [{'path': 'app.py', 'size': 1, 'sha256': '0' * 64}]}
    with zipfile.ZipFile(archive, 'w') as bundle:
        bundle.writestr(release.MANIFEST, json.dumps(manifest))
        bundle.writestr('app.py', b'x')
    with pytest.raises(release.ReleaseError, match='RELEASE_HASH_MISMATCH'):
        release.verify(archive)
