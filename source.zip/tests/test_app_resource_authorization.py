"""Offline authorization regressions for account-owned chat and file resources."""
from unittest import TestCase, mock

import app as account_app


class _Cursor:
    def __init__(self, owner_by_session=None):
        self.owner_by_session = owner_by_session or {}
        self.lastrowid = 11
        self._result = None
        self.calls = []

    def execute(self, sql, params=()):
        self.calls.append((sql, params))
        if "SELECT 1 FROM chat_list" in sql:
            session_id, user_id = params
            self._result = {"ok": 1} if self.owner_by_session.get(session_id) == str(user_id) else None
        elif "FROM user_files" in sql:
            # File download returns no row when the owner predicate does not
            # match, exactly as a real parameterized query would.
            self._result = None
        else:
            self._result = None

    def fetchone(self):
        return self._result

    def fetchall(self):
        return []

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False


class _Connection:
    def __init__(self, cursor):
        self.cursor_value = cursor

    def cursor(self):
        return self.cursor_value

    def commit(self):
        return None

    def rollback(self):
        return None

    def close(self):
        return None


class _MixedOwnershipBatchCursor(_Cursor):
    """Return only the current user's file for a mixed-ID batch request."""

    def __init__(self, current_owner):
        super().__init__()
        self.current_owner = current_owner
        self._rows = []

    def execute(self, sql, params=()):
        self.calls.append((sql, params))
        if "SELECT user_id, file_path, file_id" in sql:
            self._rows = [
                {
                    "user_id": self.current_owner,
                    "file_id": "file-owned-by-current-user",
                    "file_path": "C:/not-used/b-current-file.txt",
                }
            ]

    def fetchall(self):
        return self._rows


class AccountResourceAuthorizationTests(TestCase):
    def setUp(self):
        self.auth_version = mock.patch.object(
            account_app, "_current_auth_version", return_value=0)
        self.auth_version.start()
        self.addCleanup(self.auth_version.stop)

    def _token(self, user_id):
        return account_app.generate_token(user_id, f"user-{user_id}")

    def _headers(self, user_id):
        return {"Authorization": f"Bearer {self._token(user_id)}"}

    def test_chat_messages_require_authentication(self):
        response = account_app.app.test_client().get("/api/chat/messages/session-a")
        self.assertEqual(response.status_code, 401)

    def test_other_user_cannot_read_chat_messages(self):
        cursor = _Cursor({"session-a": "owner-a"})
        with mock.patch.object(account_app, "get_db_connection", return_value=_Connection(cursor)):
            response = account_app.app.test_client().get(
                "/api/chat/messages/session-a", headers=self._headers("owner-b")
            )
        self.assertEqual(response.status_code, 404)

    def test_session_creation_uses_jwt_identity_not_payload_user_id(self):
        cursor = _Cursor()
        with mock.patch.object(account_app, "get_db_connection", return_value=_Connection(cursor)):
            response = account_app.app.test_client().post(
                "/api/chat/sessions",
                json={"title": "隔离测试", "user_id": "attacker-id"},
                headers=self._headers("owner-a"),
            )
        self.assertEqual(response.status_code, 201)
        insert = next(params for sql, params in cursor.calls if "INSERT INTO chat_list" in sql)
        self.assertEqual(str(insert[0]), "owner-a")

    def test_other_user_cannot_list_owner_files_by_changing_path_id(self):
        response = account_app.app.test_client().get(
            "/api/files/list/owner-a", headers=self._headers("owner-b")
        )
        self.assertEqual(response.status_code, 404)

    def test_file_download_query_is_scoped_to_jwt_owner(self):
        cursor = _Cursor()
        with mock.patch.object(account_app, "get_db_connection", return_value=_Connection(cursor)):
            response = account_app.app.test_client().get(
                "/api/files/download/file-owned-by-a", headers=self._headers("owner-b")
            )
        self.assertEqual(response.status_code, 404)
        query = next((params for sql, params in cursor.calls if "FROM user_files" in sql), ())
        self.assertEqual(query, ("file-owned-by-a", "owner-b"))

    def test_batch_delete_rejects_mixed_ownership_before_any_delete(self):
        cursor = _MixedOwnershipBatchCursor("owner-b")
        with mock.patch.object(account_app, "get_db_connection", return_value=_Connection(cursor)):
            response = account_app.app.test_client().post(
                "/api/files/batch-delete",
                json={"file_ids": ["file-owned-by-current-user", "file-owned-by-a"]},
                headers=self._headers("owner-b"),
            )
        self.assertEqual(response.status_code, 404)
        self.assertFalse(any("DELETE FROM user_files" in sql for sql, _ in cursor.calls))

    def test_context_download_rejects_another_users_temporary_file(self):
        with mock.patch.dict(
            account_app._CONTEXT_FILE_OWNERS,
            {"context-file-owned-by-a": "owner-a"},
            clear=True,
        ):
            response = account_app.app.test_client().get(
                "/api/context/files/context-file-owned-by-a",
                headers=self._headers("owner-b"),
            )
        self.assertEqual(response.status_code, 404)

    def test_rag_search_rejects_another_users_file_before_reading(self):
        with mock.patch.object(account_app, "_file_owned_by_user", return_value=False):
            response = account_app.app.test_client().post(
                "/api/rag/search",
                json={"query": "private research", "file_ids": ["file-owned-by-a"]},
                headers=self._headers("owner-b"),
            )
        self.assertEqual(response.status_code, 404)

    def test_file_parse_rejects_another_users_file_before_reading(self):
        with mock.patch.object(account_app, "_file_owned_by_user", return_value=False):
            response = account_app.app.test_client().post(
                "/api/user_files/download_and_parse",
                json={"file_ids": ["file-owned-by-a"]},
                headers=self._headers("owner-b"),
            )
        self.assertEqual(response.status_code, 404)

    def test_file_qa_query_is_scoped_to_jwt_owner(self):
        cursor = _Cursor()
        with mock.patch.object(account_app, "get_db_connection", return_value=_Connection(cursor)):
            response = account_app.app.test_client().post(
                "/api/files/start_qa",
                json={"file_id": "file-owned-by-a", "session_id": "session-owned-by-a"},
                headers=self._headers("owner-b"),
            )
        self.assertEqual(response.status_code, 404)
        query = next((params for sql, params in cursor.calls if "FROM user_files" in sql), ())
        self.assertEqual(query, ("file-owned-by-a", "owner-b"))


if __name__ == "__main__":
    import unittest
    unittest.main()
