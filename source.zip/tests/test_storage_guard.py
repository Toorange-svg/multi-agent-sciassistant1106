from collections import namedtuple
from pathlib import Path
from unittest import mock

import storage_guard


def test_storage_threshold_defaults_fail_closed_for_invalid_values():
    assert storage_guard.configured_min_free_bytes("") == storage_guard.DEFAULT_MIN_FREE_BYTES
    assert storage_guard.configured_min_free_bytes("bad") == storage_guard.DEFAULT_MIN_FREE_BYTES
    assert storage_guard.configured_min_free_bytes("-1") == storage_guard.DEFAULT_MIN_FREE_BYTES
    assert storage_guard.configured_min_free_bytes("0") == 0


def test_storage_guard_requires_existing_writable_paths_and_minimum_space(tmp_path):
    usage = namedtuple("usage", "total used free")
    with mock.patch.object(storage_guard.shutil, "disk_usage", return_value=usage(100, 50, 50)):
        assert storage_guard.has_minimum_free_space((tmp_path,), 50)
        assert not storage_guard.has_minimum_free_space((tmp_path,), 51)
    assert not storage_guard.has_minimum_free_space((Path(tmp_path) / "missing",), 0)


def test_mcp_log_rotation_is_configurable_and_compose_wires_the_limits():
    root = Path(__file__).resolve().parents[1]
    source = (root / "deepdiver_v2/src/tools/mcp_server_standard.py").read_text(encoding="utf-8")
    account_compose = (root / "docker-compose.account.cloud.yml").read_text(encoding="utf-8")
    research_compose = (root / "docker-compose.cloud.yml").read_text(encoding="utf-8")
    assert "RotatingFileHandler" in source
    assert "MCP_LOG_MAX_BYTES" in source and "MCP_LOG_BACKUP_COUNT" in source
    for compose in (account_compose, research_compose):
        assert "MCP_LOG_MAX_BYTES" in compose
    assert "SCIASSISTANT_MIN_FREE_DISK_BYTES" in account_compose
