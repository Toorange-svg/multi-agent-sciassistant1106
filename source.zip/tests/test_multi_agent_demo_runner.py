from __future__ import annotations

import pytest

from multi_agent_demo_runner import _decode_json_object, _filter_relevant_papers
from multi_agent_workflow import WorkflowError


def test_model_json_decoder_accepts_only_one_object_and_optional_json_fence():
    assert _decode_json_object('{"groups": []}') == {"groups": []}
    assert _decode_json_object('```json\n{"groups": []}\n```') == {"groups": []}
    for value in ("not json", "[]", '{"groups": []}\nextra'):
        with pytest.raises(WorkflowError):
            _decode_json_object(value)


def test_retrieval_relevance_gate_runs_before_a_role_can_receive_papers():
    result = {
        "status": "ok",
        "papers": [
            {"paper_id": "good", "title": "Relevant paper"},
            {"paper_id": "bad", "title": "Unrelated paper"},
        ],
    }

    def scorer(_query, paper):
        return {"accepted": paper["paper_id"] == "good"}

    filtered = _filter_relevant_papers("research question", result, scorer)
    assert [paper["paper_id"] for paper in filtered["papers"]] == ["good"]
    assert [paper["paper_id"] for paper in result["papers"]] == ["good", "bad"]


def test_retrieval_relevance_gate_fails_closed_when_the_gate_errors():
    filtered = _filter_relevant_papers(
        "research question", {"status": "ok", "papers": [{"paper_id": "candidate"}]},
        lambda *_args: (_ for _ in ()).throw(RuntimeError("gate unavailable")),
    )
    assert filtered["papers"] == []


def test_topic_grounded_candidate_is_retained_for_not_reported_or_noncomparable_findings():
    result = {"status": "ok", "papers": [{"paper_id": "topic-only", "title": "KV cache paper"}]}

    def scorer(query, _paper):
        return {"accepted": query == "KV cache quantization for LLM inference"}

    filtered = _filter_relevant_papers(
        "KV cache quantization TPOT latency benchmark", result, scorer,
        topic_query="KV cache quantization for LLM inference",
    )
    assert [paper["paper_id"] for paper in filtered["papers"]] == ["topic-only"]
    assert filtered["screening"] == {
        "candidate_count": 1, "accepted_count": 1, "contextual_count": 1, "rejected_count": 0,
    }


def test_topic_gate_does_not_admit_unrelated_candidate():
    filtered = _filter_relevant_papers(
        "KV cache latency", {"status": "ok", "papers": [{"paper_id": "unrelated"}]},
        lambda *_args: {"accepted": False}, topic_query="KV cache quantization",
    )
    assert filtered["papers"] == []
    assert filtered["screening"]["rejected_count"] == 1
