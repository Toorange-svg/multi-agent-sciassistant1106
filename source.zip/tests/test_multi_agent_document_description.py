"""Passage attribution is not document genre, nor an automatic verdict."""
from copy import deepcopy

import pytest

from multi_agent_evidence import document_description_record, source_attribution_hint
from multi_agent_quality import source_boundary_brief, citation_audit_input
from test_multi_agent_report_fields import draft, evidence


@pytest.mark.parametrize('section', ['Introduction', 'Related Work', ''])
def test_method_contribution_and_secondary_account_do_not_certify_survey(section):
    text = 'Carion et al. propose DETR. We propose a novel Adaptive Clustering Transformer (ACT).'
    item = {'evidence_id':'e1','paper_id':'2011.09315v2', 'title':'End-to-End Object Detection with Adaptive Clustering Transformer',
        'excerpt':text,'locator':{'page':2,'section':section}}
    item['source_attribution'] = source_attribution_hint(item)
    before = deepcopy(item)
    result = document_description_record(item)
    assert item == before and result['survey_title_hint'] is False
    assert not result['document_genre_verified'] and not result['primary_method_verified']
    assert len(result['self_contribution_cues']) == 1
    cue = result['self_contribution_cues'][0]
    assert cue['quote'] == text[cue['start']:cue['end']] and 'We propose' in cue['quote']


@pytest.mark.parametrize('title,abstract', [('A Survey of Detectors','We propose a taxonomy.'),
    ('Detector Research','In this review, we analyze detectors.')])
def test_survey_hints_and_self_contribution_can_coexist_without_auto_classification(title, abstract):
    item = {'title':title,'excerpt':'We propose a taxonomy for current approaches.'}
    item['source_attribution'] = source_attribution_hint(item, document_abstract=abstract)
    result = document_description_record(item)
    assert result['survey_title_hint'] or result['survey_abstract_hint']
    assert result['self_contribution_cues'] and not result['document_genre_verified']


def test_missing_cues_never_prove_primary_authority_or_non_survey_genre():
    result = document_description_record({'excerpt':'A technical explanation.'})
    assert result['self_contribution_cues'] == []
    assert not result['document_genre_verified'] and not result['primary_method_verified']


def test_writer_and_each_claim_auditor_receive_same_unmodified_approved_record():
    data, sources = draft(), evidence()
    item = sources['evidence'][0]
    item['excerpt'] += ' We propose our own model.'
    before = deepcopy((data, sources))
    record = document_description_record(item)
    assert source_boundary_brief(sources)['document_description_records'] == [record]
    audit_input = citation_audit_input(data, sources)
    assert audit_input['claims'][0]['source_context'][0]['document_description'] == record
    assert (data, sources) == before
    sources['evidence'].append({**item,'evidence_id':'not-approved','review_status':'rejected'})
    assert len(source_boundary_brief(sources)['document_description_records']) == 1


def test_prompt_calls_citing_paper_not_reviewing_paper_and_requires_field_checks():
    from multi_agent_live import ROLE_PROMPTS
    assert 'reviewing paper' not in ROLE_PROMPTS['writer']
    assert 'document_description_records' in ROLE_PROMPTS['writer']
    assert 'unsupported genre claims' in ROLE_PROMPTS['citation_auditor']


def test_cli_live_environment_isolates_actual_source_cooldown_not_just_old_cache(tmp_path, monkeypatch):
    from tools.check_question_premises import isolated_environment
    monkeypatch.setenv('SCIASSISTANT_LITERATURE_STATE_PATH','private-original-canary')
    env = isolated_environment(tmp_path)
    assert env['SCIASSISTANT_LITERATURE_STATE_PATH'] == str(tmp_path/'source-state.sqlite3')
    assert env['SCIASSISTANT_LITERATURE_CACHE_DIR'] == str(tmp_path/'source-cache')
    assert __import__('os').environ['SCIASSISTANT_LITERATURE_STATE_PATH'] == 'private-original-canary'
