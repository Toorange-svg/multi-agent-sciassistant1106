"""Offline process deadlines and crash-safe CLI termination metadata."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from types import SimpleNamespace

import pytest

from multi_agent_agents import ArtifactDirectory
from multi_agent_live import LiveArxivRagExecutor
from multi_agent_rag import RagError
from multi_agent_report import read_run_manifest
from multi_agent_workflow import WorkflowStore
from tools import multi_agent_cli as cli
from tools import multi_agent_download_pdf as download_worker


@pytest.mark.parametrize("content", ["{", "[]", '{"run_id":"another-run"}', '\ufeff{"run_id":"another-run"}'])
def test_broken_manifest_cannot_block_terminal_record(tmp_path, content):
    store = WorkflowStore(tmp_path / "workflow.sqlite3")
    store.create_run("interrupted", "owner")
    (tmp_path / "manifest.json").write_text(content, encoding="utf-8")
    assert cli.finalize_worker_exit(tmp_path, "interrupted", 7, 360)
    manifest = read_run_manifest(tmp_path)
    assert manifest["run_id"] == "interrupted" and manifest["manifest_read_status"] == "missing_or_invalid"
    assert store.get_run("interrupted")["status"] == "failed"
    final = ArtifactDirectory(tmp_path / "artifacts").get(manifest["final_artifact_id"])
    assert final["failure_code"] == "CLI_WORKER_EXITED"
    assert (tmp_path / "final_answer.html").is_file()


def test_bom_manifest_preserves_completed_result_and_replay(tmp_path):
    args = ["run", "--mode", "mock", "--query", "question", "--run-id", "bom",
            "--output-root", str(tmp_path)]
    assert cli.main(args) == 0
    directory = tmp_path / "bom"
    path = directory / "manifest.json"
    manifest = read_run_manifest(directory)
    path.write_text(json.dumps(manifest), encoding="utf-8-sig")
    assert not cli.finalize_worker_exit(directory, "bom", 0, 360)
    assert cli.replay_command(SimpleNamespace(run_dir=directory)) == 0
    assert read_run_manifest(directory)["final_artifact_id"] == manifest["final_artifact_id"]


def test_atomic_manifest_failure_retains_last_good_snapshot(tmp_path, monkeypatch):
    path = tmp_path / "manifest.json"
    cli.write_run_json(path, {"run_id": "before"})
    def fail(*_args):
        raise OSError("path-and-token-canary")
    monkeypatch.setattr(cli.os, "replace", fail)
    with pytest.raises(OSError):
        cli.write_run_json(path, {"run_id": "after"})
    assert read_run_manifest(tmp_path) == {"run_id": "before"}
    assert not list(tmp_path.glob("*.tmp"))


@pytest.mark.parametrize("content", ["{", "[]", '\ufeff{"run_id":"timeout"}'])
def test_supervisor_timeout_recovers_manifest_and_records_wrapper(tmp_path, monkeypatch, content):
    directory = tmp_path / "timeout"
    class Process:
        pid = 123
        def __init__(self, *_args, **_kwargs):
            directory.mkdir()
            WorkflowStore(directory / "workflow.sqlite3").create_run("timeout", "owner")
            (directory / "manifest.json").write_text(content, encoding="utf-8")
        def communicate(self, **_kwargs):
            raise subprocess.TimeoutExpired("fixture", 1)
    monkeypatch.setattr(cli.subprocess, "Popen", Process)
    monkeypatch.setattr("process_cleanup.terminate_process_tree", lambda _p: {
        "status": "confirmed", "parent_stopped": True, "tree_stop_confirmed": True})
    args = SimpleNamespace(output_root=tmp_path, storage_root=tmp_path / "storage",
        rag_mode="lexical", time_budget=1, query_file=None, query="question", context_file=None)
    assert cli.supervise_live(args, "timeout") == 1
    assert WorkflowStore(directory / "workflow.sqlite3").get_run("timeout")["status"] == "timed_out"
    summary = json.loads((directory / "supervision.json").read_text())
    assert summary["failure_code"] == "OUTER_CLI_TIMEOUT" and summary["worker_pid"] == 123
    assert "question" not in json.dumps(summary)


def test_unexpected_worker_exception_is_safe_and_terminal(tmp_path, monkeypatch, capsys):
    def fail(*_args, **_kwargs):
        raise RuntimeError("Authorization Bearer secret-canary C:\\private\\file")
    monkeypatch.setattr(cli.LiteraturePipelineV2, "run", fail)
    assert cli.main(["run", "--mode", "mock", "--query", "question", "--run-id", "runtime-failure",
                     "--output-root", str(tmp_path)]) == 1
    directory = tmp_path / "runtime-failure"
    assert WorkflowStore(directory / "workflow.sqlite3").get_run("runtime-failure")["failure_code"] == "CLI_WORKER_EXCEPTION"
    summary = json.loads((directory / "worker_failure.json").read_text())
    assert summary["error_category"] == "runtime"
    assert "secret-canary" not in capsys.readouterr().out
    assert all("secret-canary" not in p.read_text(encoding="utf-8-sig") for p in directory.glob("*.json"))


def test_inspection_marks_overdue_state_without_changing_it(tmp_path, capsys):
    cli.write_run_json(tmp_path / "manifest.json", {"run_id": "stale"})
    store = WorkflowStore(tmp_path / "workflow.sqlite3", clock=lambda: time.time() - 100)
    store.create_run("stale", "owner", time_budget_seconds=1)
    assert cli.inspect_command(SimpleNamespace(run_dir=tmp_path)) == 0
    report = json.loads(capsys.readouterr().out)
    assert report["lifecycle_check"]["terminal_record_missing"] is True
    assert store.get_run("stale")["status"] == "created"


def test_blocked_download_process_is_terminated_and_part_removed(tmp_path, monkeypatch):
    tool = object.__new__(LiveArxivRagExecutor)
    tool.retrieval_deadline = time.monotonic() + 1.5
    original_popen = subprocess.Popen
    children = []
    def blocked(_command, **kwargs):
        if "multi_agent_download_pdf.py" not in str(_command):
            return original_popen(_command, **kwargs)
        process = original_popen([sys.executable, "-c", "import time; time.sleep(60)"], **kwargs)
        children.append(process)
        (tmp_path / "source.part").write_bytes(b"%PDF incomplete")
        return process
    monkeypatch.setattr(subprocess, "Popen", blocked)
    started = time.monotonic()
    with pytest.raises(subprocess.TimeoutExpired):
        tool._download("2305.14314", tmp_path)
    assert time.monotonic() - started < 10
    assert children[0].poll() is not None
    assert not (tmp_path / "source.part").exists()
    assert not (tmp_path / "source.pdf").exists()


def test_expired_download_starts_no_process(tmp_path, monkeypatch):
    tool = object.__new__(LiveArxivRagExecutor)
    tool.retrieval_deadline = time.monotonic() - 1
    monkeypatch.setattr(subprocess, "Popen", lambda *_a, **_k: pytest.fail("expired tool must not launch"))
    with pytest.raises(TimeoutError):
        tool._download("2305.14314", tmp_path)


@pytest.mark.parametrize("slow", [False, True])
def test_real_http_worker_success_and_slow_drip_deadline(tmp_path, monkeypatch, slow):
    complete_pdf = b"%PDF-1.4\nfixture content\n%%EOF"
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.send_header("Content-Length", "1000" if slow else str(len(complete_pdf)))
            self.end_headers()
            if not slow:
                self.wfile.write(complete_pdf)
                return
            try:
                for _ in range(1000):
                    self.wfile.write(b"x")
                    self.wfile.flush()
                    time.sleep(0.05)  # far below the socket inactivity timeout
            except (BrokenPipeError, ConnectionResetError):
                pass
        def log_message(self, *_args): pass
    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    server.daemon_threads = True
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    real_popen = subprocess.Popen
    children = []
    # Only the test child replaces official transport with a loopback fixture.
    # The production helper exposes no arbitrary URL setting/argument.
    script = (
        "import sys,requests; "
        "from deepdiver_v2.src import literature_sources as sources; "
        "sources._request=lambda source,url,**kw: requests.get(sys.argv[1],stream=True,timeout=15); "
        "from tools.multi_agent_download_pdf import main; "
        "raise SystemExit(main(sys.argv[2:]))"
    )
    def start(command, **kwargs):
        if "multi_agent_download_pdf.py" not in str(command):
            return real_popen(command, **kwargs)
        process = real_popen([sys.executable, "-c", script,
            f"http://127.0.0.1:{server.server_port}/fixture", *command[-3:]],
            cwd=Path(__file__).resolve().parents[1], **kwargs)
        children.append(process)
        return process
    monkeypatch.setattr(subprocess, "Popen", start)
    tool = object.__new__(LiveArxivRagExecutor)
    tool.retrieval_deadline = time.monotonic() + (2 if slow else 10)
    try:
        began = time.monotonic()
        if slow:
            with pytest.raises(subprocess.TimeoutExpired):
                tool._download("2305.14314", tmp_path)
        else:
            assert tool._download("2305.14314", tmp_path).read_bytes() == complete_pdf
        assert time.monotonic() - began < 10
        assert children[0].poll() is not None
        assert not (tmp_path / "source.part").exists()
    finally:
        server.shutdown()
        server.server_close()


def test_supervisor_error_cleans_worker_and_records_safe_terminal(tmp_path, monkeypatch):
    directory = tmp_path / "wrapper-error"
    class Process:
        pid = 123
        def __init__(self, *_args, **_kwargs):
            directory.mkdir()
            WorkflowStore(directory / "workflow.sqlite3").create_run("wrapper-error", "owner")
        def communicate(self, **_kwargs):
            raise RuntimeError("token-and-path-secret-canary")
    monkeypatch.setattr(subprocess, "Popen", Process)
    cleaned = []
    def cleanup(process):
        cleaned.append(process.pid)
        return {"status": "confirmed", "parent_stopped": True, "tree_stop_confirmed": True}
    monkeypatch.setattr("process_cleanup.terminate_process_tree", cleanup)
    args = SimpleNamespace(output_root=tmp_path, storage_root=tmp_path / "storage",
        rag_mode="lexical", time_budget=1, query_file=None, query="question", context_file=None)
    assert cli.supervise_live(args, "wrapper-error") == 1
    assert cleaned == [123]
    assert WorkflowStore(directory / "workflow.sqlite3").get_run("wrapper-error")["failure_code"] == "CLI_SUPERVISOR_EXCEPTION"
    assert "secret-canary" not in (directory / "supervision.json").read_text()


@pytest.mark.parametrize("status", [302, 403, 429, 503])
def test_isolated_http_errors_preserve_status_without_raw_output(tmp_path, monkeypatch, status):
    import requests
    tool = object.__new__(LiveArxivRagExecutor)
    tool.retrieval_deadline = time.monotonic() + 30
    class Process:
        pid = 123
        returncode = 1
        def communicate(self, **kwargs):
            return json.dumps({"status": "failed", "error_code": "SOURCE_HTTP_ERROR", "http_status": status}), None
    monkeypatch.setattr(subprocess, "Popen", lambda *_a, **_k: Process())
    with pytest.raises(requests.HTTPError) as caught:
        tool._download("2305.14314", tmp_path)
    assert caught.value.response.status_code == status


@pytest.mark.parametrize("result,code", [
    ('{"status":"completed"}', 0),
    ('{"status":"failed","error_code":"secret-canary"}', 1),
    ('not JSON secret-canary', 1),
])
def test_isolated_download_never_accepts_missing_pdf_or_raw_error(tmp_path, monkeypatch, result, code):
    tool = object.__new__(LiveArxivRagExecutor)
    tool.retrieval_deadline = time.monotonic() + 30
    class Process:
        pid = 123
        returncode = code
        def communicate(self, **kwargs): return result, None
    monkeypatch.setattr(subprocess, "Popen", lambda *_a, **_k: Process())
    with pytest.raises(RagError) as caught:
        tool._download("2305.14314", tmp_path)
    assert "secret-canary" not in str(caught.value)


@pytest.mark.parametrize("paper,budget", [("https://evil.invalid/x", "1"), ("../file", "1"), ("2305.14314", "nan"), ("2305.14314", "31")])
def test_download_worker_invalid_input_cannot_network(tmp_path, capsys, paper, budget):
    assert download_worker.main([paper, str(tmp_path), budget]) == 2
    assert json.loads(capsys.readouterr().out)["error_code"] == "PDF_DOWNLOAD_INPUT_INVALID"
