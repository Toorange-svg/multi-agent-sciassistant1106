"""Theme persistence contains no session data; layout contracts are explicit."""
import json
from pathlib import Path
import shutil
import subprocess
import pytest

ROOT = Path(__file__).resolve().parents[1]

@pytest.mark.parametrize("stored,blocked", [(None,False),("dark",False),("light",False),("unknown",False),(None,True)])
def test_theme_default_toggle_reset_and_storage_event(stored, blocked):
    node = shutil.which("node")
    if not node: pytest.skip("Node required")
    source = (ROOT / "chatAi/chat_theme.js").read_text(encoding="utf8")
    script = "const SOURCE=" + json.dumps(source) + "; const STORED=" + json.dumps(stored) + "; const BLOCKED=" + json.dumps(blocked) + ";" + r'''
const vm=require('node:vm'),writes=[],events={};
const ids={}; for(const id of ['chat-theme-light','chat-theme-dark','reset-chat-theme'])ids[id]={attrs:{},events:{},setAttribute(k,v){this.attrs[k]=v;},addEventListener(k,fn){this.events[k]=fn;}};
const root={dataset:{},style:{}};
const document={documentElement:root,readyState:'complete',getElementById:id=>ids[id]};
const localStorage={getItem(k){if(BLOCKED)throw Error('blocked');return STORED;},setItem(k,v){if(BLOCKED)throw Error('blocked');writes.push([k,v]);}};
vm.runInNewContext(SOURCE,{document,localStorage,window:{addEventListener(k,fn){events[k]=fn;}}});
const initial=root.dataset.chatTheme;
ids['chat-theme-dark'].events.click();const dark=root.dataset.chatTheme==='dark'&&ids['chat-theme-dark'].attrs['aria-pressed']==='true';
ids['reset-chat-theme'].events.click();const reset=root.dataset.chatTheme==='light';
events.storage({key:'other-key',newValue:'dark'});const ignored=root.dataset.chatTheme==='light';
events.storage({key:'sciassistant.chat-theme',newValue:'dark'});const synced=root.dataset.chatTheme==='dark';
console.log(JSON.stringify({initial,dark,reset,ignored,synced,writes}));
'''
    completed = subprocess.run([node,"-"],input=script,capture_output=True,text=True,encoding="utf8",timeout=10)
    assert completed.returncode == 0, completed.stderr
    data = json.loads(completed.stdout)
    assert data["initial"] == ("dark" if stored == "dark" and not blocked else "light")
    assert all(data[k] for k in ("dark","reset","ignored","synced"))
    assert data["writes"] == ([] if blocked else [["sciassistant.chat-theme","dark"],["sciassistant.chat-theme","light"]])

def test_settings_no_longer_expose_export_or_sidebar_width():
    html = (ROOT / "chatAi/ai_chat.html").read_text(encoding="utf8")
    settings = html.split('<dialog id="chat-settings-dialog"',1)[1].split('</dialog>',1)[0]
    assert 'id="export-conversation-btn"' not in html
    assert 'id="sidebar-width-setting"' not in settings
    assert 'id="chat-theme-dark"' in settings and 'id="chat-theme-light"' in settings
    assert 'id="sidebar-resize-handle"' in html

def test_evidence_grid_default_half_width_adjustable_independent_scroll_not_drawer():
    css = (ROOT / "chatAi/multi_agent_rag.css").read_text(encoding="utf8")
    assert "minmax(0,var(--rag-source-share,1fr)) 14px minmax(0,var(--rag-answer-share,1fr))" in css
    assert ".rag-column-resizer" in css and "cursor:col-resize" in css
    assert ".rag-source-scroll{position:sticky;top:8px;" in css
    assert "overflow:auto;overscroll-behavior:contain" in css
    assert ".rag-evidence-drawer" not in css
    assert "@media(max-width:700px)" in css
