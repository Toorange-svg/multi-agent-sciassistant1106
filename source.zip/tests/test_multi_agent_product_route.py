from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_new_mode_is_parallel_to_legacy_mode_and_has_a_hard_web_timeout():
    source = (ROOT / "web_app.py").read_text(encoding="utf-8")
    assert '"literature_answer": "science_literature"' in source
    assert '"multi_agent_literature": "multi_agent_literature"' in source
    assert '"bounded_multi_agent_literature_v1"' in source
    assert 'timeout_seconds = min(timeout_seconds, 360)' in source
    assert '"--workflow-run-id", task_id' in source
    assert '"model_call_limit": 10' in source
    coordinator = (ROOT / "multi_agent_literature.py").read_text(encoding="utf-8")
    assert 'MAX_EVIDENCE_RECOVERY_ROUNDS = 1' in coordinator
    assert 'FINALIZATION_RESERVE_SECONDS = 90' in coordinator
    assert 'def _multi_agent_workflow_summary' in source
    assert 'agent_workflow=summary' in source
    assert '"evidence_review"' in source
    assert 'SCIASSISTANT_MULTI_AGENT_STATE_PATH' in source


def test_cli_and_browser_expose_only_the_safe_workflow_summary():
    demo = (ROOT / "deepdiver_v2" / "cli" / "demo.py").read_text(encoding="utf-8")
    browser = (ROOT / "chatAi" / "ai_chat.html").read_text(encoding="utf-8")
    helper = (ROOT / "tools" / "run_research.py").read_text(encoding="utf-8")
    assert '"multi_agent_literature"' in demo
    assert 'run_multi_agent_literature_query' in demo
    assert '--workflow-run-id' in demo
    assert '<option value="multi_agent_literature"' not in browser
    assert '<input type="hidden" id="research-processing-mode" value="multi_agent_rag">' in browser
    assert '<select id="research-processing-mode"' not in browser
    assert '多 Agent 协作摘要' in browser
    assert '页面仅展示阶段摘要，不展示提示词或隐藏推理' in browser
    assert '已完成/进入阶段' in browser
    assert 'multi_agent_literature' in helper
