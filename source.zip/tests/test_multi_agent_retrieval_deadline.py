from __future__ import annotations

from pathlib import Path

from deepdiver_v2.src import literature_sources


def test_search_source_reports_deadline_skip_without_exposing_exception(monkeypatch):
    def deadline(*_args, **_kwargs):
        raise literature_sources.SourceDeadlineExceeded("canary path and token must not escape")

    monkeypatch.setattr(literature_sources, "_arxiv", deadline)
    result = literature_sources.search_source(
        "arxiv", "bounded query", 5,
        request_deadline_monotonic=1.0,
        request_max_attempts=2,
        request_max_wait_seconds=5.0,
    )
    assert result["status"] == "deadline_skipped"
    assert result["error"] == "source request skipped by workflow deadline"
    assert "canary" not in str(result)


def test_runner_uses_bounded_arxiv_request_policy():
    root = Path(__file__).resolve().parents[1]
    source = (root / "multi_agent_demo_runner.py").read_text(encoding="utf-8")
    assert "request_max_attempts=2" in source
    assert "request_max_wait_seconds=5.0" in source
    assert "time.monotonic() + 270.0" in source
