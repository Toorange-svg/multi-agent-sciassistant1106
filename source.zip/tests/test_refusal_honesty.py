"""Offline acceptance tests for refusal honesty and diagnostics auditability.

Covers the acceptance criteria of the "拒答内容诚实性与诊断可审计性" task:

1. Refusal text separates three cases - source unreachable / no relevant
   evidence / partial evidence - and a source outage is never hidden behind
   a blanket "检索到 0 篇".
2. A failed retrieval still persists query_plan, per-source adapter_query,
   returned titles, score/accepted/rejection_reason.
3. A rotation-skipped source emits exactly one ``skipped`` event, never a
   ``completed``+``failed`` pair; ``source_status`` keeps one semantics.
4. ``Search Rounds`` is derivable from diagnostics (workflow iterations and
   retrieval rounds are distinct counters).
5. Regression: the existing retrieval tests keep passing (run with
   ``python -m unittest discover -s tests -p "test_*.py"``).

All tests are offline: the retrieval integration test mocks the arxiv
adapter, the public-source adapter, rotation state, and the cache writer.
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "deepdiver_v2") not in sys.path:
    sys.path.insert(0, str(ROOT / "deepdiver_v2"))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from deepdiver_v2.cli import demo  # noqa: E402
import src.literature_sources as lit_src  # noqa: E402  (same module demo imported)


def _round(source, returned, accepted, status, error="", skip_reason="", adapter_query="adapter-q"):
    item = {
        "round": 1, "source": source, "query": "q", "adapter_query": adapter_query,
        "returned": returned, "max_score": 0.4 if accepted else 0.1,
        "accepted_total": accepted, "source_status": status,
    }
    if error:
        item["search_error"] = error
    if skip_reason:
        item["skip_reason"] = skip_reason
    return item


class RefusalTextTests(unittest.TestCase):
    """Problem 1: the refusal wording must distinguish the three cases."""

    def _sufficiency(self, paper_count, minimum=2):
        return {
            "status": "insufficient_evidence",
            "paper_count": paper_count,
            "minimum_required": minimum,
            "notice": "检索到的论文不足以回答该问题。",
        }

    def test_source_failure_is_not_hidden_behind_zero_hits(self):
        # (a) arxiv unreachable, no source returned anything usable.
        diagnostics = {
            "relevance_threshold": 0.35,
            "rounds": [
                _round("arxiv", 0, 0, "error",
                       error="arXiv API read timeout (20s); connection failed"),
                _round("techrxiv", 0, 0, "skipped",
                       skip_reason="techrxiv 半开冷却中，本轮跳过；约 3600s 后自动以真实查询重试。停用原因：3 blocks"),
            ],
        }
        text = demo._build_insufficient_evidence_answer(diagnostics, self._sufficiency(0))
        self.assertIn("未能完成", text)
        self.assertIn("不可用", text)
        self.assertIn("不能据此判断没有相关论文", text)
        self.assertIn("已查询来源", text)
        self.assertNotIn("检索到 0 篇", text)   # must not mask the outage
        self.assertNotIn("未找到足够相关文献", text)  # (a) is not (b)

    def test_no_relevant_evidence_wording(self):
        # (b) sources answered, but nothing passed the relevance gate.
        diagnostics = {
            "relevance_threshold": 0.35,
            "candidates_seen": 30,
            "rounds": [
                _round("arxiv", 0, 0, "error",
                       error="arXiv API read timeout (20s); connection failed"),
                _round("zenodo", 15, 0, "ok"),
                _round("hal", 15, 0, "ok"),
            ],
        }
        text = demo._build_insufficient_evidence_answer(diagnostics, self._sufficiency(0))
        self.assertIn("未找到足够相关文献", text)
        self.assertIn("共检索到 30 篇候选文献", text)
        self.assertIn("均未通过相关性门控", text)
        self.assertIn("已查询来源", text)
        self.assertIn("返回 15 篇候选", text)   # per-source detail present

    def test_partial_evidence_reports_count_and_gap(self):
        # (c) 1 paper passed, 2 required: say the count and what was missing.
        diagnostics = {
            "relevance_threshold": 0.35,
            "rounds": [
                _round("zenodo", 15, 1, "ok"),
                _round("hal", 15, 0, "ok"),
            ],
            "candidate_scores": [
                {"paper_id": "h1", "title": "t1", "final_accepted": False,
                 "rejection_reason": "below_threshold"},
                {"paper_id": "h2", "title": "t2", "final_accepted": False,
                 "rejection_reason": "domain_mismatch"},
            ],
        }
        text = demo._build_insufficient_evidence_answer(diagnostics, self._sufficiency(1, 2))
        self.assertIn("1 篇候选文献通过相关性门控", text)
        self.assertIn("少于回答所需的 2 篇", text)
        self.assertIn("被拒候选的主要类型", text)
        self.assertIn("相关性分数低于阈值（1 篇）", text)
        self.assertIn("领域不符（1 篇）", text)


class DiagnosticsPersistenceTests(unittest.TestCase):
    """Problems 2-3: a failed search still persists audit data; skips are single events."""

    def test_failed_search_persists_audit_and_skips_emit_one_event(self):
        query = "LoRA 与 QLoRA 的核心差异是什么？"

        def fake_paper(source, idx):
            return {
                "paper_id": f"{source}-{idx}", "id": f"{source}-{idx}",
                "title": f"Environmental Limitations to Rice Cultivation {idx}",
                "abstract": ("Rice cultivation in monsoon regions depends on water "
                             "availability, soil conditions and seasonal rainfall."),
                "url": f"https://example.org/{source}/{idx}",
                "source": source, "published": "2024-01-01",
            }

        def fake_search_source(source, adapter_query, limit=3):
            return {"status": "ok", "papers": [fake_paper(source, i) for i in range(limit)],
                    "error": None}

        def fake_skip_reason(source):
            if source == "techrxiv":
                return ("techrxiv 半开冷却中，本轮跳过；约 3600s 后自动以真实查询重试。"
                        "停用原因：3 consecutive access blocks")
            return ""

        class ArxivFailure:
            success = False
            error = "arXiv API read timeout (20s); connection failed"
            data = {}
            metadata = {"warnings": []}

        # A plain object, not a MagicMock: the cooldown probe must read None
        # (no cooldown) so the round really calls arxiv_search and fails with
        # a network error instead of being pre-skipped by a mock artifact.
        import types
        tools = types.SimpleNamespace(
            arxiv_cooldown_remaining=None,
            arxiv_search=lambda search_query, max_results: ArxivFailure(),
        )

        with tempfile.TemporaryDirectory() as tmp:
            diag_path = Path(tmp) / "diagnostics.jsonl"
            env = {
                "SCIASSISTANT_DIAGNOSTICS_PATH": str(diag_path),
                "MODEL_REQUEST_URL": "",
                "MODEL_REQUEST_TOKEN": "",
            }
            with mock.patch.dict(os.environ, env, clear=False), \
                 mock.patch.object(demo, "search_source", side_effect=fake_search_source), \
                 mock.patch.object(demo, "source_skip_reason", side_effect=fake_skip_reason), \
                 mock.patch.object(demo, "put_literature_cache", return_value=None):
                papers, diagnostics, cache_hit = demo._search_relevant_literature(
                    query, "arxiv", tools, config=None
                )
                # Read the JSONL inside the tempdir block so it still exists.
                diagnostics_events = [
                    json.loads(line) for line in diag_path.read_text(encoding="utf-8").splitlines()
                    if line.strip()
                ]

        self.assertFalse(papers)  # the refusal scenario
        self.assertFalse(cache_hit)

        # P2: query_plan and per-source adapter_query persisted.
        self.assertTrue(diagnostics.get("query_plan"))
        rounds = diagnostics.get("rounds")
        self.assertTrue(rounds)
        sources_seen = {item["source"] for item in rounds}
        self.assertEqual(sources_seen, {"arxiv", "zenodo", "techrxiv", "hal"})
        for item in rounds:
            self.assertIn("adapter_query", item)
        arxiv_rounds = [item for item in rounds if item["source"] == "arxiv"]
        self.assertTrue(arxiv_rounds)
        self.assertTrue(all(item["source_status"] == "error" for item in arxiv_rounds))
        self.assertTrue(all("timeout" in (item.get("search_error") or "") for item in arxiv_rounds))
        zenodo_rounds = [item for item in rounds if item["source"] == "zenodo"]
        self.assertTrue(all(item["source_status"] == "ok" for item in zenodo_rounds))
        self.assertTrue(all(item["returned"] > 0 for item in zenodo_rounds))
        self.assertEqual(diagnostics.get("search_rounds"), demo.MAX_RETRIEVAL_ROUNDS)

        # P2: per-candidate audit fields present (score / accepted / reason).
        candidate_scores = diagnostics.get("candidate_scores")
        self.assertTrue(candidate_scores)
        for item in candidate_scores:
            for key in ("paper_id", "title", "score", "lexical_accepted",
                        "semantic_label", "final_accepted", "rejection_reason"):
                self.assertIn(key, item)

        # P2: evidence sufficiency is recorded as insufficient_evidence.
        sufficiency = diagnostics["evidence_sufficiency"]
        self.assertEqual(sufficiency["status"], "insufficient_evidence")

        # Aggregation: skipped source is not listed as attempted.
        self.assertIn("techrxiv", diagnostics.get("sources_skipped") or [])
        self.assertNotIn("techrxiv", diagnostics.get("sources_attempted") or [])
        # Honest search_failed: not triggered by a single source's error while
        # other sources answered (rounds without search_error exist).
        self.assertFalse(diagnostics.get("search_failed"))

        # P3: JSONL has exactly one skipped event per round for techrxiv and
        # never a completed+failed pair for it.
        techrxiv_events = [event for event in diagnostics_events if event.get("source") == "techrxiv"]
        self.assertTrue(techrxiv_events)
        self.assertEqual(set(event["status"] for event in techrxiv_events), {"skipped"})
        techrxiv_rounds = [item for item in rounds if item["source"] == "techrxiv"]
        self.assertEqual(len(techrxiv_events), len(techrxiv_rounds))

        # P5: the refusal built from this diagnostics lists queried sources.
        text = demo._build_insufficient_evidence_answer(diagnostics, sufficiency)
        self.assertIn("已查询来源", text)
        self.assertIn("zenodo", text)
        self.assertIn("hal", text)
        self.assertIn("未找到足够相关文献", text)


class SkipReasonTests(unittest.TestCase):
    """Problem 3 helper: source_skip_reason mirrors search_source's skip branches."""

    def setUp(self):
        # Half-open skip semantics are generic and techrxiv is only a sample
        # source here. The deployment parks techrxiv statically; lift that for
        # these tests so the runtime cooldown/probe branches are exercised.
        self._static_patch = mock.patch.object(lit_src, "STATIC_DISABLED_SOURCES", ())
        self._static_patch.start()
        self.addCleanup(self._static_patch.stop)

    class _FakeConn:
        def __init__(self, row):
            self._row = row
            self.last_sql = None

        def execute(self, sql, params):
            self.last_sql = (sql, params)
            return self

        def fetchone(self):
            return self._row

        def close(self):
            pass

    def test_enabled_source_has_no_skip_reason(self):
        with mock.patch.object(lit_src, "disabled_reason", return_value=""):
            self.assertEqual(lit_src.source_skip_reason("zenodo"), "")

    def test_cooldown_not_expired_skips(self):
        now = time.time()
        row = (now + 3600, 0)
        with mock.patch.object(lit_src, "disabled_reason", return_value="3 blocks"), \
             mock.patch.object(lit_src, "_state_connection",
                               return_value=self._FakeConn(row)):
            note = lit_src.source_skip_reason("techrxiv")
        self.assertIn("半开冷却中", note)
        self.assertIn("停用原因：3 blocks", note)

    def test_sibling_probe_claims_skip(self):
        now = time.time()
        row = (now - 10, now + 30)  # cooldown expired, sibling probe in flight
        with mock.patch.object(lit_src, "disabled_reason", return_value="3 blocks"), \
             mock.patch.object(lit_src, "_state_connection",
                               return_value=self._FakeConn(row)):
            note = lit_src.source_skip_reason("techrxiv")
        self.assertIn("并行任务", note)

    def test_cooldown_expired_and_probe_free_is_not_skipped(self):
        now = time.time()
        row = (now - 10, now - 30)
        with mock.patch.object(lit_src, "disabled_reason", return_value="3 blocks"), \
             mock.patch.object(lit_src, "_state_connection",
                               return_value=self._FakeConn(row)):
            self.assertEqual(lit_src.source_skip_reason("techrxiv"), "")


class SearchRoundsFieldTests(unittest.TestCase):
    """Problem 4: workflow iterations and retrieval rounds are distinct."""

    def test_search_rounds_read_from_diagnostics(self):
        class FakeResponse:
            def __init__(self, result):
                self.result = result

        five = FakeResponse({"search_diagnostics": {"search_rounds": 5}})
        self.assertEqual(demo._search_rounds_of(five), 5)
        self.assertIsNone(demo._search_rounds_of(FakeResponse(None)))
        self.assertIsNone(demo._search_rounds_of(FakeResponse({"search_diagnostics": {}})))
        self.assertIsNone(demo._search_rounds_of(FakeResponse({})))


if __name__ == "__main__":
    unittest.main(verbosity=2)
