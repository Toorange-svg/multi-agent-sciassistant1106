"""Approved recovery boundaries: no network, credentials or shared storage."""
from copy import deepcopy
import json
import time
import subprocess
import sys
from pathlib import Path

import pytest

from multi_agent_pipeline_v2 import check_review, recover_review_subset, ReviewContractError
from multi_agent_quality import check_audit, publication_rejections, review_repair_feedback
from test_multi_agent_pipeline_v2 import agents, pipeline


def packet_set():
    return {"evidence": [{"evidence_id": key, "group_id": "g1", "excerpt": "Evidence", "coverage_scope": "selected_chunks",
                           "locator": {"page": 1}} for key in ["e1", "e2"]]}


def reviewer_data():
    return {"schema_version": "sciassistant.evidence-review/v3", "coverage_status": "partial",
            "allowed_evidence_ids": ["e1"], "coverage": [], "conflicts": [],
            "decisions": [{"evidence_id": "e1", "decision": "approved", "reason_code": "SUPPORTED",
                           "detail": "Specific support", "group_ids": ["g1"]}]}


def audit_data(draft, schema="sciassistant.citation-audit/v3", size=700):
    return {"schema_version": schema, "status": "passed", "issues": [], "rejected_claim_ids": [],
            "claim_results": [{"claim_id": c["claim_id"], "decision": "approved", "reason_code": "SUPPORTED",
                "evidence_ids": c["evidence_ids"], "detail": "x" * size} for c in draft["claims"]]}


@pytest.mark.parametrize("size", [601, 700, 4000])
def test_new_audit_accepts_full_detail_without_reinterpreting_old_schema(size):
    draft = {"claims": [{"claim_id": "c1", "evidence_ids": ["e1"]}]}
    current = audit_data(draft, size=size)
    assert not check_audit(current, draft)["contract_errors"]
    assert publication_rejections(current, draft) == set()
    legacy = {**current, "schema_version": "sciassistant.citation-audit/v2"}
    assert publication_rejections(legacy, draft) == {"c1"}
    assert current["claim_results"][0]["detail"] == "x" * size


@pytest.mark.parametrize("mutation", [
    lambda a: a["claim_results"][0].update(detail="x" * 4001),
    lambda a: a["claim_results"][0].update(evidence_ids=["unknown"]),
    lambda a: a["claim_results"][0].update(reason_code="UNSUPPORTED_NUMBER"),
    lambda a: a["claim_results"].clear(),
    lambda a: a.update(schema_version="sciassistant.citation-audit/unknown"),
])
def test_new_audit_never_salvages_incomplete_or_contradictory_verdicts(mutation):
    draft = {"claims": [{"claim_id": "c1", "evidence_ids": ["e1"]}]}
    data = audit_data(draft)
    mutation(data)
    assert publication_rejections(data, draft) == {"c1"}


def test_review_isolates_missing_id_and_bad_coverage_without_inventing_decision():
    data = reviewer_data()
    data["coverage"] = [{"group_id": "g1", "status": "direct", "evidence_ids": ["e2"]}]
    original = deepcopy(data)
    recovered, report = recover_review_subset(data, packet_set(), {"g1"})
    assert recovered["allowed_evidence_ids"] == ["e1"]
    assert recovered["coverage_status"] == "needs_review"
    assert report["quarantined_evidence_ids"] == ["e2"]
    assert report["quarantined_coverage_indices"] == [0]
    assert not any(r["evidence_id"] == "e2" for r in recovered["decisions"])
    assert data == original
    assert check_review(recovered, {"evidence": packet_set()["evidence"][:1]}, {"g1"})


def test_identical_duplicates_can_be_normalized_but_conflicting_duplicates_quarantine():
    data = reviewer_data()
    data["decisions"].append(deepcopy(data["decisions"][0]))
    good, report = recover_review_subset(data, packet_set(), {"g1"})
    assert good["allowed_evidence_ids"] == ["e1"]
    assert report["normalizations"][0]["action"] == "deduplicate_identical"
    data["decisions"][1]["decision"] = "rejected"
    bad, report = recover_review_subset(data, packet_set(), {"g1"})
    assert not bad["allowed_evidence_ids"] and "e1" in report["quarantined_evidence_ids"]


@pytest.mark.parametrize("field,value", [("detail", ""), ("reason_code", "IRRELEVANT"),
                                        ("group_ids", ["wrong"]), ("decision", "unknown")])
def test_incomplete_support_fields_are_not_optional_and_cannot_be_filled(field, value):
    data = reviewer_data()
    data["decisions"][0][field] = value
    checked, _ = recover_review_subset(data, packet_set(), {"g1"})
    assert not checked["allowed_evidence_ids"]


def test_repair_feedback_names_missing_duplicate_and_unknown_ids():
    data = reviewer_data()
    data["decisions"] += [deepcopy(data["decisions"][0]), {"evidence_id": "fake"}]
    feedback = review_repair_feedback(data, "BAD", packet_set())["inconsistencies"]
    assert feedback["missing_decision_ids"] == ["e2"]
    assert feedback["duplicate_decision_ids"] == ["e1"]
    assert feedback["unknown_decision_ids"] == ["fake"]


def test_initial_review_correction_then_subset_reaches_writer_and_auditor(tmp_path):
    configured, calls = agents()
    def reviewer(packet):
        calls.append("reviewer")
        evidence = next(i["payload"] for i in packet["inputs"] if "evidence" in i["payload"])
        key = evidence["evidence"][0]["evidence_id"]
        return {"output": {**reviewer_data(), "allowed_evidence_ids": [key],
            "decisions": [{**reviewer_data()["decisions"][0], "evidence_id": key}]}}
    configured.reviewer.handler = reviewer
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {"status": "ok", "papers": [
        {"paper_id": str(i), "title": "Paper", "abstract": "Evidence"} for i in [1, 2]]})
    flow.time_budget_seconds = 140  # No optional gap calls; writer+auditor still possible.
    result = flow.run("subset", "owner", "Define A")
    assert result["run"]["status"] == "needs_review"
    assert calls.count("reviewer") == 2 and calls.count("writer") == 1 and calls.count("citation_auditor") == 1
    final = flow.artifacts.get(result["final_artifact_id"])
    approved = flow.artifacts.get(final["artifact_refs"]["approved"])
    assert [e["evidence_id"] for e in approved["evidence"]] == ["arxiv-1"]


def test_followup_invalid_json_preserves_old_approval_and_does_not_approve_new(tmp_path):
    configured, calls = agents(partial=True)
    original = configured.reviewer.handler
    count = []
    def reviewer(packet):
        count.append(1)
        if len(count) == 2:
            return {"status": "failed", "error_code": "MODEL_JSON_INVALID"}
        result = original(packet)
        result["output"]["coverage"] = [{"group_id": "g1", "status": "partial", "evidence_ids": ["arxiv-1"]}]
        return result
    configured.reviewer.handler = reviewer
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("old-review", "owner", "A")
    assert result["run"]["status"] == "needs_review"
    assert "writer" in calls and "citation_auditor" in calls
    final = flow.artifacts.get(result["final_artifact_id"])
    assert flow.artifacts.get(final["artifact_refs"]["review"])["allowed_evidence_ids"] == ["arxiv-1"]


def test_protocol_error_repairs_auditor_not_writer(tmp_path):
    configured, calls = agents()
    audit_calls = []
    def auditor(packet):
        calls.append("citation_auditor")
        draft = next(i["payload"] for i in packet["inputs"] if "claims" in i["payload"])
        output = audit_data(draft)
        if not audit_calls:
            output["claim_results"] = []
        audit_calls.append(1)
        return {"output": output}
    configured.citation_auditor.handler = auditor
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("audit-repair", "owner", "A")
    assert result["run"]["status"] == "completed"
    assert calls.count("writer") == 1 and len(audit_calls) == 2
    assert result["run"]["model_calls_used"] == 6


@pytest.mark.parametrize("error", ["MODEL_OUTPUT_TRUNCATED", "MODEL_JSON_INVALID", "MODEL_SCHEMA_REJECTED"])
def test_writer_recovers_once_with_separate_budgeted_call(tmp_path, error):
    configured, calls = agents()
    original = configured.writer.handler
    count = []
    def writer(packet):
        count.append(packet)
        return {"status": "failed", "error_code": error} if len(count) == 1 else original(packet)
    configured.writer.handler = writer
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("writer-repair", "owner", "A")
    assert result["run"]["status"] == "completed" and result["run"]["model_calls_used"] == 6
    assert len(count) == 2 and count[0]["inputs"] == count[1]["inputs"]
    assert count[1]["remaining_model_calls"] == count[0]["remaining_model_calls"] - 1


def test_writer_repeat_truncation_does_not_publish_and_stops(tmp_path):
    configured, _ = agents()
    configured.writer.handler = lambda _: {"status": "failed", "error_code": "MODEL_OUTPUT_TRUNCATED"}
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("writer-stop", "owner", "A")
    assert result["run"]["failure_code"] == "MODEL_OUTPUT_TRUNCATED"
    assert result["run"]["model_calls_used"] == 5
    assert not any(p.name.endswith("-citation_auditor.json") for p in (tmp_path / "agents").glob("*.json"))


def test_all_source_unreachable_skips_review_and_gap_and_classifies_source_failure(tmp_path):
    configured, calls = agents()
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {"status": "source_unreachable", "papers": []})
    result = flow.run("source-failure", "owner", "A")
    assert result["run"]["failure_code"] == "RETRIEVAL_SOURCE_UNREACHABLE"
    assert calls == ["planner", "retriever"]
    assert "来源不可达" in result["direct_answer"]


def test_healthy_empty_result_is_not_misreported_as_source_failure(tmp_path):
    configured, calls = agents(recovery=True)
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {"status": "ok", "papers": []})
    result = flow.run("empty", "owner", "A")
    assert result["run"]["failure_code"] == "INSUFFICIENT_EVIDENCE"
    assert "gap_analyst" in calls


def test_writer_retry_preserves_auditor_time_reserve(tmp_path):
    configured, _ = agents()
    configured.writer.handler = lambda _: {"status": "failed", "error_code": "MODEL_OUTPUT_TRUNCATED"}
    flow, store = pipeline(tmp_path, configured)
    store.create_run("reserve", "owner")
    store.transition("reserve", "planned")
    store.transition("reserve", "retrieving")
    store.transition("reserve", "reviewing")
    store.transition("reserve", "writing")
    flow.deadline = time.monotonic() + 80
    from multi_agent_pipeline_v2 import PipelineExecutionError
    with pytest.raises(PipelineExecutionError):
        flow._invoke("reserve", "writer", "Write", [])
    assert store.get_run("reserve")["model_calls_used"] == 1
    assert not flow.writer_format_retry_used


def test_repeated_invalid_audit_never_routes_to_writer_or_publishes(tmp_path):
    configured, calls = agents()
    def bad(_):
        calls.append("citation_auditor")
        return {"output": {"schema_version": "sciassistant.citation-audit/v3", "status": "passed",
                           "issues": [], "rejected_claim_ids": [], "claim_results": []}}
    configured.citation_auditor.handler = bad
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("bad-audit", "owner", "A")
    assert result["run"]["status"] == "failed"
    assert result["run"]["failure_code"] == "NO_AUDITED_CLAIMS"
    assert calls.count("writer") == 1 and calls.count("citation_auditor") == 2
    final = flow.artifacts.get(result["final_artifact_id"])
    published = flow.artifacts.get(final["artifact_refs"]["publication"])
    assert not any(c["published"] for c in published["claims"])


def test_source_group_mismatch_is_not_a_valid_recovered_approval():
    evidence = packet_set()
    evidence["evidence"][0]["group_id"] = "g2"
    checked, report = recover_review_subset(reviewer_data(), evidence, {"g1", "g2"})
    assert not checked["allowed_evidence_ids"] and "e1" in report["quarantined_evidence_ids"]


def test_complete_rereview_resolves_recovery_notice_without_automatic_coverage_upgrade(tmp_path):
    configured, _ = agents()
    flow, _ = pipeline(tmp_path, configured)
    recovered, _ = recover_review_subset(reviewer_data(), packet_set(), {"g1"})
    complete = reviewer_data()
    complete["decisions"].append({"evidence_id": "e2", "decision": "rejected", "reason_code": "IRRELEVANT",
                                   "detail": "Not about the requested task", "group_ids": ["g1"]})
    checked = flow._validated_followup_review("unused", complete, recovered, packet_set(), {"g1"}, None, {})
    assert checked["coverage_status"] == "partial"
    assert not checked.get("recovery_notice")


def test_bom_query_context_and_role_json_are_valid_without_paid_calls(tmp_path):
    root = Path(__file__).resolve().parents[1]
    query = tmp_path / "query.txt"
    query.write_text("中文问题", encoding="utf-8-sig")
    context = tmp_path / "context.json"
    context.write_text(json.dumps({"schema_version": "sciassistant.followup-context/v1", "previous_question": "前问",
        "previous_answer": "前答", "paper_ids": [], "evidence_policy": "context_only_retrieve_again"}), encoding="utf-8-sig")
    command = [sys.executable, str(root / "tools/multi_agent_cli.py")]
    result = subprocess.run([*command, "run", "--mode", "mock", "--run-id", "bom-test", "--query-file", str(query),
        "--context-file", str(context), "--output-root", str(tmp_path / "runs")], capture_output=True, timeout=30)
    assert result.returncode == 0
    result = subprocess.run([*command, "agent", "--role", "planner", "--input-json", str(context),
        "--output-dir", str(tmp_path / "agent")], capture_output=True, timeout=30)
    assert result.returncode == 0
