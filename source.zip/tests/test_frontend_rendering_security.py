"""Regression checks for untrusted text rendered by the single-page chat UI."""

import json
from pathlib import Path
import shutil
import subprocess

import pytest


HTML = (Path(__file__).resolve().parents[1] / "chatAi" / "ai_chat.html").read_text(encoding="utf-8")


def _markdown_script() -> str:
    section = HTML.split("<!-- 全局Markdown转HTML函数 -->", 1)[1]
    return section.split("</script>", 1)[0].replace("<script>", "", 1)


def test_untrusted_markdown_source_is_escaped_before_html_generation():
    assert "let html = escapeMarkdownSource(text);" in HTML
    assert "function safeExternalUrl(value)" in HTML
    assert 'rel="noopener noreferrer"' in HTML


def test_user_messages_and_common_metadata_paths_escape_external_text():
    assert "formattedText = escapeHtml(formattedText).replace" in HTML
    assert "${escapeHtml(item.title)}" in HTML
    assert "${escapeHtml(file.name)}" in HTML
    assert "${escapeHtml(data.message)}" in HTML
    assert "toast.innerHTML = `${icon}<span>${escapeHtml(message)}</span>`;" in HTML


def test_markdown_renderer_rejects_tags_and_unsafe_link_schemes():
    node = shutil.which("node")
    if not node:
        pytest.skip("Node required for renderer security regression")
    probe = r'''
console.log(JSON.stringify({
  rawTag: markdownToHtml('<img src=x onerror=alert(1)>'),
  scriptLink: markdownToHtml('[bad](javascript:alert(1))'),
  scriptImage: markdownToHtml('![bad](javascript:alert(1))'),
  validLink: markdownToHtml('[site](https://example.test/paper)')
}));
'''
    completed = subprocess.run(
        [node, "-e", _markdown_script() + probe],
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=10,
    )
    assert completed.returncode == 0, completed.stderr
    rendered = json.loads(completed.stdout)
    assert "<img" not in rendered["rawTag"]
    assert 'href="javascript:' not in rendered["scriptLink"]
    assert "<img" not in rendered["scriptImage"]
    assert 'href="https://example.test/paper"' in rendered["validLink"]
    assert 'rel="noopener noreferrer"' in rendered["validLink"]


def test_citation_at_paragraph_end_cannot_swallow_following_markdown_heading():
    node = shutil.which("node")
    if not node: pytest.skip("Node required")
    probe = "console.log(JSON.stringify(markdownToHtml('正文 [1]\\n\\n### 分项分析\\n\\n内容 [2]\\n\\n#### 子主题\\n\\n说明')));"
    result = subprocess.run([node,"-e",_markdown_script()+probe],capture_output=True,text=True,encoding="utf8",timeout=10)
    assert result.returncode == 0, result.stderr
    rendered = json.loads(result.stdout)
    assert "<h3" in rendered and "<h4" in rendered
    assert "###" not in rendered and "[1]" in rendered and "[2]" in rendered
