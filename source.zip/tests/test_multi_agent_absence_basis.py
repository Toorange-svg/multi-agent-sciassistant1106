"""Field-local absence evidence; provenance alone never proves semantic support."""
from copy import deepcopy

import pytest

from multi_agent_agents import AgentContractError
from multi_agent_live import normalize_live_result
from multi_agent_quality import (ABSENCE_AUDIT_SCHEMA, ABSENCE_AUDIT_POLICY,
    FIELD_AUDIT_SCHEMA, check_audit, check_claim_revision, citation_audit_input,
    publication_rejections, writer_revision_brief)
from test_multi_agent_report_fields import audit as legacy_audit, draft, evidence, QUOTE
from test_multi_agent_pipeline_v2 import agents, pipeline


def audit(data):
    value = legacy_audit(data)
    value["schema_version"] = ABSENCE_AUDIT_SCHEMA
    for row in value["claim_results"]:
        for field in row["field_results"].values():
            field["absence_checks"] = []
    return value


def absence(value, text, *, field="qualification", basis="selected_excerpts", witness_index=None):
    value["claim_results"][0]["field_results"][field]["absence_checks"] = [
        {"assertion": text, "basis": basis, "witness_index": witness_index}]
    return value


def test_current_contract_input_and_output_do_not_modify_evidence_or_invent_verdicts():
    data, sources = draft(), evidence()
    original = deepcopy((data, sources))
    value = audit(data)
    parsed = normalize_live_result("citation_auditor", {"output": value}, require_current=True)["output"]
    assert parsed == value
    assert not check_audit(parsed, data, sources)["contract_errors"]
    assert citation_audit_input(data, sources)["absence_audit_policy"] == ABSENCE_AUDIT_POLICY
    assert (data, sources) == original


@pytest.mark.parametrize("field", ["text", "scope_note", "qualification"])
@pytest.mark.parametrize("text", ["三者均未报告配对评估。", "这并非经过统一对照验证的机制。",
    "论文只报告准确率，未给出泛化指标。"])
def test_matching_quote_or_other_scoped_field_cannot_rescue_unscoped_negative(field, text):
    data = draft()
    data["claims"][0][field] = text
    checked = check_audit(absence(audit(data), text, field=field), data, evidence())
    assert not checked["contract_errors"] and not checked["witness_issues"]
    assert checked["absence_issues"][0]["field"] == field
    assert checked["absence_issues"][0]["assertion"] == text
    assert publication_rejections(checked, data) == {"c1"}


@pytest.mark.parametrize("text", ["所选片段未提供统一对照。", "所选原文片段未报告此指标。",
    "The selected excerpts do not report paired evaluation.", "The reviewed excerpts do not establish causality."])
def test_exact_selected_excerpt_negative_is_not_whole_paper_absence(text):
    data = draft()
    data["claims"][0]["qualification"] = text
    checked = check_audit(absence(audit(data), text), data, evidence())
    assert not checked["contract_errors"] and not checked["absence_issues"]
    assert publication_rejections(checked, data) == set()


def test_author_explicit_omission_uses_real_witness_not_coverage_label():
    data, sources = draft(), evidence()
    text = "作者自述未进行端到端微调。"
    quote = "We have not fine-tuned the CLIP encoder in an end-to-end manner."
    data["claims"][0]["qualification"] = text
    sources["evidence"][0]["excerpt"] = quote
    value = absence(audit(data), text, basis="source_reported", witness_index=0)
    value["claim_results"][0]["source_witnesses"][0]["quote"] = quote
    checked = check_audit(value, data, sources)
    assert not checked["contract_errors"] and not checked["witness_issues"] and not checked["absence_issues"]
    # These checks certify provenance, not automatic entailment of every quoted sentence.
    assert publication_rejections(checked, data) == set()
    value["claim_results"][0]["source_witnesses"][0]["quote"] = "Invented original sentence about a missing controlled experiment."
    assert check_audit(value, data, sources)["witness_issues"]


@pytest.mark.parametrize("index", [None, -1, 1, True, "0", [], {}])
def test_source_reported_absence_requires_actual_witness_index(index):
    data = draft()
    value = absence(audit(data), data["claims"][0]["qualification"], basis="source_reported", witness_index=index)
    assert "AUDIT_ABSENCE_WITNESS_INVALID" in check_audit(value, data, evidence())["contract_errors"]


@pytest.mark.parametrize("bad", [None, {}, "bad", [None], [False], [
    {"assertion": "not in field", "basis": "unverified", "witness_index": None}], [
    {"assertion": "仅所选片段，不能认定全文没有验证。", "basis": [], "witness_index": None}], [
    {"assertion": "仅所选片段，不能认定全文没有验证。", "basis": "unverified"}]])
def test_bad_absence_records_rejected_not_guessed_or_dropped(bad):
    data, value = draft(), audit(draft())
    value["claim_results"][0]["field_results"]["qualification"]["absence_checks"] = bad
    normalized = normalize_live_result("citation_auditor", {"output": value})["output"]
    assert normalized["claim_results"][0]["field_results"]["qualification"]["absence_checks"] == bad
    assert "AUDIT_ABSENCE_CHECKS_INVALID" in check_audit(normalized, data)["contract_errors"]


def test_missing_negative_basis_is_protocol_fault_with_no_auto_migration():
    data, value = draft(), audit(draft())
    del value["claim_results"][0]["field_results"]["qualification"]["absence_checks"]
    assert "AUDIT_ABSENCE_CHECKS_INVALID" in check_audit(value, data)["contract_errors"]
    old = legacy_audit(data)
    original = deepcopy(old)
    assert old["schema_version"] == FIELD_AUDIT_SCHEMA
    assert not check_audit(old, data, evidence())["contract_errors"]
    with pytest.raises(AgentContractError):
        normalize_live_result("citation_auditor", {"output": old}, require_current=True)
    assert old == original


def test_unverified_negative_cannot_be_supported_or_dismissed_as_not_applicable():
    data = draft()
    value = absence(audit(data), data["claims"][0]["qualification"], basis="unverified")
    assert "AUDIT_ABSENCE_VERDICT_INCONSISTENT" in check_audit(value, data)["contract_errors"]


def test_empty_field_requires_empty_negative_checks():
    data = draft()
    data["claims"][0]["scope_note"] = ""
    value = audit(data)
    absence(value, "", field="scope_note", basis="unverified")
    assert "AUDIT_ABSENCE_CHECKS_INVALID" in check_audit(value, data)["contract_errors"]


def test_local_negative_issue_isolated_and_correct_field_revision_requires_reaudit():
    data = draft()
    text = "三者均未报告配对评估。"
    data["claims"][0]["qualification"] = text
    data["claims"] += [{**deepcopy(data["claims"][0]), "claim_id": "c2", "qualification": "实验设置如原文。"},
        {**deepcopy(data["claims"][0]), "claim_id": "c3", "qualification": "实验设置如原文。", "depends_on_claim_ids": ["c1"]}]
    checked = check_audit(absence(audit(data), text), data, evidence())
    assert publication_rejections(checked, data) == {"c1", "c3"}
    feedback = {"model_audit": checked, "code_issues": checked["absence_issues"]}
    brief = writer_revision_brief(data, feedback, evidence())
    assert brief["targets"][0]["fields"][0]["field"] == "qualification"
    revised = deepcopy(data)
    revised["claims"][0]["qualification"] = "所选片段未提供跨数据集配对评估，不能据此判断全文不存在。"
    assert not check_claim_revision(data, revised, feedback)["code_issues"]
    assert check_claim_revision(data, revised, feedback)["changed_claims_still_require_audit"]
    revised["claims"][0]["qualification"] = text
    revised["claims"][0]["scope_note"] = "仅所选片段，改变错误字段。"
    assert check_claim_revision(data, revised, feedback)["code_issues"]


@pytest.mark.parametrize("repair", [True, False])
def test_full_workflow_negative_basis_routes_to_writer_not_auditor_format_retry(tmp_path, repair):
    configured, calls = agents()
    original = draft()
    original["claims"][0]["evidence_ids"] = ["arxiv-1"]
    original["claims"][0]["qualification"] = "三者均未报告配对评估。"
    written = []
    def writer(packet):
        calls.append("writer")
        data = deepcopy(original)
        if written and repair:
            brief = next(i["payload"] for i in packet["inputs"] if i["payload"].get("targets"))
            assert [r["field"] for r in brief["targets"][0]["fields"]] == ["qualification"]
            data["claims"][0]["qualification"] = "所选片段未提供配对评估。"
        written.append(data)
        return {"output": data}
    def auditor(packet):
        calls.append("citation_auditor")
        data = next(i["payload"] for i in packet["inputs"] if i["payload"].get("claims"))
        return {"output": absence(audit(data), data["claims"][0]["qualification"])}
    configured.writer.handler, configured.citation_auditor.handler = writer, auditor
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {"status": "ok", "papers": [
        {"paper_id": "1", "title": "Paper", "abstract": QUOTE}]})
    result = flow.run("negative-basis", "owner", "Define A")
    assert calls.count("writer") == calls.count("citation_auditor") == 2
    assert result["run"]["model_calls_used"] == 7
    final = flow.artifacts.get(result["final_artifact_id"])
    checked = flow.artifacts.get(final["artifact_refs"]["audit"])
    assert bool(publication_rejections(checked, written[-1])) is not repair
    assert result["run"]["status"] == ("completed" if repair else "failed")
    if not repair:
        assert result["run"]["failure_code"] == "NO_AUDITED_CLAIMS"


def test_missing_basis_protocol_routes_to_auditor_once_and_preserves_call_budget(tmp_path):
    configured, calls = agents()
    data = draft()
    data["claims"][0]["evidence_ids"] = ["arxiv-1"]
    configured.writer.handler = lambda _: {"output": data}
    seen = []
    def auditor(packet):
        calls.append("citation_auditor")
        value = audit(data)
        if not seen:
            del value["claim_results"][0]["field_results"]["text"]["absence_checks"]
        seen.append(value)
        return {"output": value}
    configured.citation_auditor.handler = auditor
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {"status": "ok", "papers": [
        {"paper_id": "1", "title": "Paper", "abstract": QUOTE}]})
    result = flow.run("negative-format", "owner", "Define A")
    assert len(seen) == 2 and result["run"]["model_calls_used"] == 6
    assert result["run"]["status"] == "completed"
