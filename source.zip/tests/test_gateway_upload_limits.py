"""Account-gateway request ceilings and atomic upload regressions."""

import io
from pathlib import Path
from unittest import mock

import app as gateway


class _Cursor:
    def __init__(self, fail_on_insert=None):
        self.insert_count = 0
        self.fail_on_insert = fail_on_insert
        self.calls = []

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def execute(self, sql, params=None):
        self.calls.append((" ".join(sql.split()), params))
        if "INSERT INTO user_files" in sql:
            self.insert_count += 1
            if self.insert_count == self.fail_on_insert:
                raise RuntimeError("private database failure")


class _Connection:
    def __init__(self, cursor):
        self._cursor = cursor
        self.commits = 0
        self.rollbacks = 0
        self.closed = False

    def cursor(self):
        return self._cursor

    def commit(self):
        self.commits += 1

    def rollback(self):
        self.rollbacks += 1

    def close(self):
        self.closed = True


def _headers():
    token = gateway.generate_token("upload-owner", "owner", 0)
    return {"Authorization": f"Bearer {token}"}


def _post_files(client, members):
    return client.post(
        "/api/files/upload",
        data={"files": [(io.BytesIO(content), name) for content, name in members]},
        headers=_headers(),
        content_type="multipart/form-data",
    )


def test_gateway_rejects_body_before_route_database_or_disk(monkeypatch, tmp_path):
    monkeypatch.setitem(gateway.app.config, "MAX_CONTENT_LENGTH", 128)
    monkeypatch.setattr(gateway, "UPLOAD_BASE_DIR", tmp_path)
    monkeypatch.setattr(gateway, "_current_auth_version", lambda _user: 0)
    database = mock.Mock(side_effect=AssertionError("database must not open"))
    monkeypatch.setattr(gateway, "get_db_connection", database)

    response = _post_files(gateway.app.test_client(), [(b"x" * 512, "large.pdf")])

    assert response.status_code == 413
    assert response.get_json()["error"] == "REQUEST_TOO_LARGE"
    database.assert_not_called()
    assert list(tmp_path.rglob("*")) == []


def test_batch_size_is_preflighted_before_database_and_first_write(monkeypatch, tmp_path):
    monkeypatch.setattr(gateway, "MAX_FILE_SIZE", 5)
    monkeypatch.setattr(gateway, "UPLOAD_BASE_DIR", tmp_path)
    monkeypatch.setattr(gateway, "_current_auth_version", lambda _user: 0)
    database = mock.Mock(side_effect=AssertionError("database must not open"))
    monkeypatch.setattr(gateway, "get_db_connection", database)

    response = _post_files(gateway.app.test_client(), [
        (b"abc", "first.pdf"), (b"def", "second.txt")])

    assert response.status_code == 413
    database.assert_not_called()
    assert list(tmp_path.rglob("*")) == []


def test_invalid_later_member_cannot_leave_earlier_file(monkeypatch, tmp_path):
    monkeypatch.setattr(gateway, "UPLOAD_BASE_DIR", tmp_path)
    monkeypatch.setattr(gateway, "_current_auth_version", lambda _user: 0)
    database = mock.Mock(side_effect=AssertionError("database must not open"))
    monkeypatch.setattr(gateway, "get_db_connection", database)

    response = _post_files(gateway.app.test_client(), [
        (b"valid", "first.pdf"), (b"invalid", "second.exe")])

    assert response.status_code == 400
    database.assert_not_called()
    assert list(tmp_path.rglob("*")) == []


def test_database_failure_rolls_back_and_removes_every_saved_file(monkeypatch, tmp_path):
    cursor = _Cursor(fail_on_insert=2)
    connection = _Connection(cursor)
    monkeypatch.setattr(gateway, "UPLOAD_BASE_DIR", tmp_path)
    monkeypatch.setattr(gateway, "_current_auth_version", lambda _user: 0)
    monkeypatch.setattr(gateway, "get_db_connection", lambda: connection)

    response = _post_files(gateway.app.test_client(), [
        (b"one", "first.pdf"), (b"two", "second.txt")])

    assert response.status_code == 500
    assert connection.rollbacks == 1 and connection.commits == 0 and connection.closed
    assert list(tmp_path.rglob("*.*")) == []
    assert "private database failure" not in response.get_data(as_text=True)


def test_successful_batch_uses_one_database_commit(monkeypatch, tmp_path):
    cursor = _Cursor()
    connection = _Connection(cursor)
    monkeypatch.setattr(gateway, "UPLOAD_BASE_DIR", tmp_path)
    monkeypatch.setattr(gateway, "_current_auth_version", lambda _user: 0)
    monkeypatch.setattr(gateway, "get_db_connection", lambda: connection)

    response = _post_files(gateway.app.test_client(), [
        (b"one", "first.pdf"), (b"two", "second.txt")])

    assert response.status_code == 200
    assert response.get_json()["uploaded_count"] == 2
    assert connection.commits == 1 and connection.rollbacks == 0 and connection.closed
    assert len(list((tmp_path / "upload-owner").glob("*"))) == 2


def test_context_file_oversize_uses_413_and_writes_nothing(monkeypatch, tmp_path):
    monkeypatch.setattr(gateway, "MAX_UPLOAD_SIZE", 4)
    monkeypatch.setattr(gateway, "UPLOAD_DIR", tmp_path)
    monkeypatch.setattr(gateway, "_current_auth_version", lambda _user: 0)
    database = mock.Mock(side_effect=AssertionError("database must not open"))
    monkeypatch.setattr(gateway, "get_db_connection", database)

    response = gateway.app.test_client().post(
        "/api/context/upload",
        data={"file": (io.BytesIO(b"12345"), "context.txt")},
        headers=_headers(),
        content_type="multipart/form-data",
    )

    assert response.status_code == 413
    database.assert_not_called()
    assert list(Path(tmp_path).rglob("*")) == []
