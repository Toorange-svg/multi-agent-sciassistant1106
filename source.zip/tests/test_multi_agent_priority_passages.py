from copy import deepcopy
import pytest
from multi_agent_rag import EvidenceStore, HybridRetriever, RagError, build_chunks
from multi_agent_pipeline_v2 import _reported_item_counts
from multi_agent_quality import _bounded_absence_context

FACET = "CIFAKE accuracy test samples"

def indexed(tmp_path):
    store = EvidenceStore(tmp_path / "index.sqlite3")
    blocks = [{"page": 1, "text": "CIFAKE accuracy adaptation dataset classifier generalization results 95%. " * 6},
        {"page": 2, "text": "CIFAKE accuracy test samples classifier adaptation dataset uses 20% images and domain shift. " * 6},
        {"page": 3, "text": "Figure 2: CIFAKE accuracy 95%, large test set (12 000 samples).", "figure_id": "Figure-2", "block_type": "figure_caption"},
        {"page": 4, "text": "CIFAKE classifier uses MLP and CNN heads 512 dimensions."}]
    chunks = build_chunks("doc", "paper", "CIFAKE", blocks, target_tokens=100, overlap_tokens=0)
    store.index_document({"document_id": "doc", "paper_id": "paper", "title": "CIFAKE", "content_hash": "first"}, chunks)
    class BodyFirst:
        def rerank(self, query, rows):
            return [r["chunk_id"] for r in sorted(rows, key=lambda r: (bool(r.get("figure_id")), r["page"]))]
    return HybridRetriever(store, reranker=BodyFirst())

def search(tool, **kwargs):
    return tool.search("CIFAKE classifier adaptation", limit=4, per_document=4, context_budget=4000,
        document_ids={"doc"}, representative_document_ids=["doc"],
        passage_queries=[FACET, "adaptation dataset"], **kwargs)

def test_evaluation_passage_not_crowded_out_by_body_reranker(tmp_path):
    packets = search(indexed(tmp_path), priority_passage_queries=[FACET])
    assert packets[0]["locator"]["figure_id"] == "Figure-2"
    assert packets[0]["retrieval"]["priority_passage_selected"] is True
    assert len(packets) <= 4 and sum(bool(p["retrieval"]["priority_passage_selected"]) for p in packets) == 1
    assert not any(p.get("review_status") == "approved" for p in packets)

def test_default_path_does_not_force_caption(tmp_path):
    assert not search(indexed(tmp_path))[0]["retrieval"]["priority_passage_selected"]

@pytest.mark.parametrize("bad", ["not-a-list", ["unplanned"], [FACET, "adaptation dataset"], [None]])
def test_priority_cannot_expand_queries_or_accept_invalid_input(tmp_path, bad):
    with pytest.raises(RagError):
        search(indexed(tmp_path), priority_passage_queries=bad)

def test_priority_respects_context_budget_and_document_filter(tmp_path):
    tool = indexed(tmp_path)
    assert tool.search("CIFAKE", limit=4, context_budget=0, document_ids={"doc"},
        passage_queries=[FACET], priority_passage_queries=[FACET]) == []
    assert tool.search("CIFAKE", document_ids={"absent"}, passage_queries=[FACET], priority_passage_queries=[FACET]) == []

def test_priority_without_actual_body_match_does_not_invent_result(tmp_path):
    packets = indexed(tmp_path).search("CIFAKE", passage_queries=["unknown-topic mechanism"],
        priority_passage_queries=["unknown-topic mechanism"], document_ids={"doc"})
    assert not any(p["retrieval"]["priority_passage_selected"] for p in packets)

@pytest.mark.parametrize("text", ["本次所引片段未提供对照。", "本轮引用片段未给出参数。"])
def test_explicit_cited_excerpt_scope_is_not_false_whole_paper_absence(text):
    assert _bounded_absence_context(text, text)

@pytest.mark.parametrize("text", ["本次论文未提供实验。", "本次所引片段未提供对照；论文没有测试。"])
def test_excerpt_alias_does_not_rescue_whole_paper_negatives(text):
    assert not _bounded_absence_context(text, text)

@pytest.mark.parametrize("text,value", [("60 000 AI-generated and 60 000 real images", 60000),
    ("130 real and 130 synthetic images", 130)])
def test_actual_source_parallel_item_counts(text, value):
    from decimal import Decimal
    assert _reported_item_counts(text) == {(Decimal(value), "item_count")}

def test_spaced_resolution_not_image_sample_count():
    assert _reported_item_counts("256 x 256 images") == set()
