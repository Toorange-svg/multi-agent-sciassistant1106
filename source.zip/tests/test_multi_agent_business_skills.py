"""Business capabilities are bounded inputs, never tools or approval."""
from copy import deepcopy
import hashlib
import json

import pytest

from multi_agent_skills import (ASSERTION_POLICY, PRECISE_REVISION_POLICY, ASSERTION_MODES,
    skill_bundle, skill_catalog, assertion_issues)
from multi_agent_quality import (citation_audit_input, exact_field_revision_targets, check_claim_revision,
    check_metric_direction, LEGACY_METRIC_DIRECTION_POLICY, METRIC_DIRECTION_POLICY,
    check_audit, publication_rejections)
from multi_agent_sections import project_writer_job, writer_job_issues
from multi_agent_pipeline_v2 import render_claims, check_draft
from multi_agent_live import normalize_live_result, effective_role_prompt
from multi_agent_handoffs import project_audit_packet, AUDIT_JOB_POLICY
from test_multi_agent_report_fields import draft, evidence, audit, reject
from test_multi_agent_sections import composition, good_draft


def test_exactly_five_reviewed_skills_with_templates_counterexamples_and_no_permission_change():
    catalog = skill_catalog()
    assert len(catalog['skills']) == 5
    data = {'requirements': [{'answer_kind': k} for k in ('comparison', 'proposal')]}
    bundle = skill_bundle('writer', data, revision=True)
    assert len(bundle['skills']) == 5 and not bundle['allowed_actions_override']
    assert not bundle['remote_or_user_skills_allowed'] and not bundle['semantic_auto_approval']
    for s in bundle['skills']:
        assert s['instructions'] and s['template'] and s['counterexamples'] and s['output_requirements']
        raw = {k:v for k,v in s.items() if k not in {'skill_id','version','sha256'}}
        assert s['sha256'] == hashlib.sha256(json.dumps(raw,sort_keys=True,ensure_ascii=False).encode()).hexdigest()


@pytest.mark.parametrize('role', ['retriever', 'gap_analyst'])
def test_unneeded_roles_cannot_load_writing_or_revision_skills(role):
    assert skill_bundle(role, {'requirements': [{'answer_kind':'proposal'}]}, revision=True)['skills'] == []


@pytest.mark.parametrize('role', ['writer', 'citation_auditor', 'reviewer', 'planner'])
def test_on_demand_selection_not_all_skills_for_every_call(role):
    simple = skill_bundle(role)
    full = skill_bundle(role, {'requirements':[{'answer_kind':'comparison'},{'answer_kind':'evaluation_protocol'}]}, revision=True)
    assert len(simple['skills']) < len(full['skills'])
    assert 'experimental-design' not in [s['skill_id'] for s in simple['skills']]
    assert ('report-revision' in [s['skill_id'] for s in full['skills']]) == (role in {'writer','citation_auditor'})


@pytest.mark.parametrize('bad', ['../../secret', 'https://example.test/skill', 'admin', '', None])
def test_no_path_url_or_unknown_role_loading(bad):
    with pytest.raises(ValueError, match='SKILL_ROLE_UNKNOWN'):
        skill_bundle(bad)


def test_bundle_mutation_cannot_change_future_snapshot_or_ledger():
    ledger = {'requirements':[{'answer_kind':'proposal'}], 'allowed_actions':['delete_database']}
    original = deepcopy(ledger)
    a, b = skill_bundle('writer',ledger), skill_bundle('writer',ledger)
    a['skills'][0]['instructions'].append('untrusted override')
    assert skill_bundle('writer',ledger) == b and ledger == original


@pytest.mark.parametrize('mode', sorted(ASSERTION_MODES))
def test_declared_modes_preserved_to_claim_scoped_audit_not_approval(mode):
    data, sources = draft(), evidence()
    data.update(assertion_policy=ASSERTION_POLICY, audit_job_policy=AUDIT_JOB_POLICY)
    data['claims'][0]['assertion_mode'] = mode
    before = deepcopy((data,sources))
    packet = citation_audit_input(data,sources)
    assert packet['claims'][0]['assertion_mode'] == mode
    assert packet['assertion_modes']['claims'][0]['declared_mode'] == mode
    projected = project_audit_packet({'inputs':[{'payload':packet}]})
    current = projected['inputs'][0]['payload']
    assert current['audit_jobs'][0]['claim']['assertion_mode'] == mode
    assert not current['assertion_modes']['semantic_auto_approval']
    assert (data,sources) == before and not assertion_issues(data)


@pytest.mark.parametrize('bad', ['paper_proves_my_plan', None, [], False, 9])
def test_invalid_declared_mode_not_silently_converted_to_fact(bad):
    data = draft()
    data['assertion_policy'] = ASSERTION_POLICY
    data['claims'][0]['assertion_mode'] = bad
    assert assertion_issues(data)[0]['reason'] == 'ASSERTION_MODE_INVALID'
    assert any(i['reason']=='ASSERTION_MODE_INVALID' for i in check_draft(data,evidence()))


def test_missing_declaration_recorded_unclassified_not_fact_or_whole_draft_veto():
    from multi_agent_sections import writer_jobs
    outline,dossiers,_ = composition()
    job = writer_jobs(outline,dossiers,'standard',10)[0]
    job['assertion_policy'] = ASSERTION_POLICY
    data = good_draft(job)
    result = project_writer_job(data,job)
    assert not writer_job_issues(result,job)
    assert all(c['assertion_mode']=='unclassified' for c in result['claims'])
    assert all('assertion_mode' not in c for c in data['claims'])
    output = normalize_live_result('writer', {'output':result})['output']
    assert output['claims'][0]['assertion_mode'] == 'unclassified'


@pytest.mark.parametrize('mode,label', [('proposal','实验建议（尚未验证）'),('synthesis','综合推断'),('attributed_interpretation','作者解释')])
def test_published_inferences_and_plans_have_visible_labels_without_changing_claim(mode,label):
    data,sources=draft(),evidence()
    data['assertion_policy']=ASSERTION_POLICY
    data['claims'][0]['assertion_mode']=mode
    original=deepcopy(data)
    text=render_claims(data,sources)
    assert '【'+label+'】' in text and data['claims'][0]['text'] in text
    assert data==original
    assert not data.get('semantic_auto_approval')


def test_proposal_label_does_not_restore_a_rejected_number_or_bypass_audit():
    data=draft()
    data['assertion_policy']=ASSERTION_POLICY
    data['claims'][0]['assertion_mode']='proposal'
    rejected=reject(audit(data),field='text')
    assert publication_rejections(check_audit(rejected,data,evidence()),data)=={'c1'}
    rendered=render_claims(data,evidence(),rejected={'c1'})
    assert data['claims'][0]['text'] not in rendered and '实验建议（尚未验证）' not in rendered


def detail_inputs():
    data=draft()
    data['precise_revision_policy']=PRECISE_REVISION_POLICY
    return data, {'model_audit':reject(audit(data)), 'code_issues':[]}


def test_detail_only_edit_uses_actual_field_decisions_and_still_requires_reaudit():
    data,feedback=detail_inputs()
    result=exact_field_revision_targets(data,feedback,evidence())
    assert result['targets'][0]['repair_scope']=='detail_only'
    assert result['full_reaudit_required'] and not result['automatic_text_repair']
    revised=deepcopy(data)
    revised['claims'][0]['qualification']='仅据本次所选原文核对该实验条件。'
    assert not check_claim_revision(data,revised,feedback,evidence())['code_issues']
    assert check_claim_revision(data,data,feedback,evidence())['code_issues']
    assert publication_rejections(check_audit(feedback['model_audit'],revised,evidence()),revised)=={'c1'}


@pytest.mark.parametrize('fault',['body','scope','bad_quote','incomplete_audit','global_code','unlocated_code','unknown_schema'])
def test_ambiguous_or_body_fault_cannot_get_detail_only_exception(fault):
    data,feedback=detail_inputs()
    row=feedback['model_audit']['claim_results'][0]
    if fault=='body': row['field_results']['text']['status']='unsupported'
    elif fault=='scope': row['field_results']['scope_note']['status']='needs_review'
    elif fault=='bad_quote': row['source_witnesses'][0]['quote']='Invented quotation that does not appear in approved evidence.'
    elif fault=='incomplete_audit': feedback['model_audit']['claim_results']=[]
    elif fault=='global_code': feedback['code_issues']=[{'claim_id':'draft','reason':'GLOBAL_ERROR'}]
    elif fault=='unlocated_code': feedback['code_issues']=[{'claim_id':'c1','reason':'UNSUPPORTED_CLAIM'}]
    else: feedback['model_audit']['schema_version']='unknown/v1'
    target=exact_field_revision_targets(data,feedback,evidence())['targets']
    assert not any(r['repair_scope']=='detail_only' for r in target)


def test_unrelated_claim_fault_does_not_erase_precise_supported_body_of_this_claim():
    data,feedback=detail_inputs()
    feedback['code_issues']=[{'claim_id':'c2','reason':'UNSUPPORTED_NUMBER','field':'text'}]
    assert exact_field_revision_targets(data,feedback,evidence())['targets'][0]['repair_scope']=='detail_only'


def test_empty_repaired_detail_allowed_but_actual_new_audit_remains_required():
    data,feedback=detail_inputs()
    revised=deepcopy(data)
    revised['claims'][0]['qualification']=''
    assert not check_claim_revision(data,revised,feedback,evidence())['code_issues']
    assert publication_rejections(feedback['model_audit'],revised)=={'c1'}


@pytest.mark.parametrize('field',['text','scope_note','qualification'])
def test_descriptive_loss_maximum_is_not_maximization_goal_but_old_policy_unchanged(field):
    data,sources=draft(),evidence()
    data['claims'][0].update(text='表内数据如下。',scope_note='',qualification='')
    data['claims'][0][field]='验证损失最小值为1.16，对应六个并列rank；验证损失最大值为1.23，对应r=1。最优取最小损失。'
    sources['evidence'][0]['excerpt']='The performance peaks at r=16 for validation loss and r=4 for BLEU.'
    assert not check_metric_direction(data,sources)
    assert check_metric_direction(data,sources,policy=LEGACY_METRIC_DIRECTION_POLICY)
    data['metric_direction_policy']=LEGACY_METRIC_DIRECTION_POLICY
    assert any(i['reason']=='METRIC_DIRECTION_INVERTED' for i in check_draft(data,sources))
    data['metric_direction_policy']=METRIC_DIRECTION_POLICY
    assert not any(i['reason']=='METRIC_DIRECTION_INVERTED' for i in check_draft(data,sources))


@pytest.mark.parametrize('text',['最优验证损失最大值为1.23。','验证损失最优最大值为1.23。','验证损失最大化。','验证损失达到峰值。'])
def test_optimum_inversion_not_exempted_by_maximum_reporting_fix(text):
    data,sources=draft(),evidence()
    data['claims'][0]['text']=text
    sources['evidence'][0]['excerpt']='The performance peaks at r=16 for validation loss and r=4 for BLEU.'
    assert check_metric_direction(data,sources)


@pytest.mark.parametrize('text', ['作者表注称性能在验证损失上于r=16达到峰值。',
    '性能按训练损失在r=16达到峰值；按BLEU在r=4达到峰值。'])
def test_source_performance_optimum_is_not_loss_maximum_in_chinese(text):
    data,sources=draft(),evidence()
    data['claims'][0]['text']=text
    metric='training loss' if '训练' in text else 'validation loss'
    sources['evidence'][0]['excerpt']=f'The performance peaks at r=16 for {metric} and r=4 for BLEU.'
    assert not check_metric_direction(data,sources)
    assert check_metric_direction(data,sources,policy=LEGACY_METRIC_DIRECTION_POLICY)


def test_performance_label_does_not_hide_explicit_largest_loss_optimum():
    data,sources=draft(),evidence()
    data['claims'][0]['text']='性能在验证损失最大时达到峰值。'
    sources['evidence'][0]['excerpt']='The performance peaks at r=16 for validation loss and r=4 for BLEU.'
    assert check_metric_direction(data,sources)


def test_prompt_requires_actual_role_specific_audit_not_extra_unvalidated_verdict_fields():
    assert 'assertion_mode' in effective_role_prompt('writer')
    audit_prompt=effective_role_prompt('citation_auditor')
    assert 'existing field_results.detail' in audit_prompt
    assert 'no author omission' in audit_prompt
    assert 'allowed_actions' in audit_prompt


def test_old_drafts_without_opt_in_not_given_new_assertion_verdict_or_label():
    data=draft()
    data['claims'][0]['assertion_mode']='proposal'
    assert not assertion_issues(data)
    assert 'assertion_modes' not in citation_audit_input(data,evidence())
    assert '实验建议（尚未验证）' not in render_claims(data,evidence())


@pytest.mark.parametrize('text', ['不代表整篇论文未报告该指标。', '不意味着论文未进行对照。', '不能据此断言论文未验证这一点。'])
def test_no_whole_paper_inference_warning_not_misread_as_paper_absence(text):
    from multi_agent_quality import check_reading_scope
    data=draft()
    data['claims'][0]['text']=text
    original=deepcopy(data)
    assert bool(check_reading_scope(data,evidence())) == (not text.startswith('不能据此断言'))
    data['assertion_policy']=ASSERTION_POLICY
    assert not check_reading_scope(data,evidence())
    assert original['claims']==data['claims']


def test_noninference_warning_cannot_excuse_later_actual_unscoped_absence():
    from multi_agent_quality import check_reading_scope
    data=draft()
    data['assertion_policy']=ASSERTION_POLICY
    data['claims'][0]['text']='不代表这一点不重要，但论文未进行验证。'
    assert check_reading_scope(data,evidence())


def test_workflow_records_per_call_skill_hashes_and_no_extra_tools(tmp_path):
    from multi_agent_agents import ArtifactDirectory
    from multi_agent_workflow import WorkflowStore
    from multi_agent_pipeline_v2 import LiteraturePipelineV2, DeterministicLiteratureExecutor
    from tools.multi_agent_cli import _mock_agents, _mock_search
    artifacts=ArtifactDirectory(tmp_path/'artifacts')
    flow=LiteraturePipelineV2(WorkflowStore(tmp_path/'workflow.sqlite3'),artifacts,_mock_agents(),
        DeterministicLiteratureExecutor(_mock_search))
    result=flow.run('skill-records','owner','请解释方法并给出实验建议。')
    final=artifacts.get(result['final_artifact_id'])
    record=artifacts.get(final['artifact_refs']['skill_loads'])
    assert record['loads'] and len(record['catalog']['skills'])==5 and not record['permissions_expanded']
    for load in record['loads']:
        bundle=artifacts.get(load['artifact_id'])
        assert load['bundle_sha256']==bundle['bundle_sha256']
        assert not bundle['allowed_actions_override']
    packet=artifacts.get(final['artifact_refs']['assertion_modes'])
    assert packet['claims'] and not packet['semantic_auto_approval']


def test_code_issue_in_detail_plus_independent_bad_claim_allows_only_exact_local_edit():
    data,feedback=detail_inputs()
    feedback['code_issues']=[{'claim_id':'c1','reason':'READING_SCOPE_OVERSTATED','field':'qualification'},
        {'claim_id':'c2','reason':'UNSUPPORTED_NUMBER','field':'text'}]
    assert exact_field_revision_targets(data,feedback,evidence())['targets'][0]['repair_scope']=='detail_only'
    revised=deepcopy(data)
    revised['claims'][0]['qualification']='所选原文片段仅支持当前实验条件。'
    assert not check_claim_revision(data,revised,feedback,evidence())['code_issues']
