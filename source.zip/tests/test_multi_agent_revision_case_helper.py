"""Standalone diagnostic outputs are not safe claim drafts."""
import json
from multi_agent_agents import ArtifactDirectory
from revision_focus_quality_development_20261013.run_revision_case import read_role_result


def test_failed_writer_diagnostic_cannot_become_auditor_input(tmp_path):
    folder = tmp_path / "writer"
    store = ArtifactDirectory(folder / "artifacts")
    ref = store.put("writer-output", {"schema_version": "diagnostic/v1",
        "parse_error_type": "JSONDecodeError", "visible_char_count": 5000, "finish_reason": "stop"})
    (folder / "agent_result.json").write_text(json.dumps({"status": "failed", "error_code": "MODEL_JSON_INVALID",
        "output_artifact_ids": [ref["artifact_id"]], "usage": {"model_calls": 1}}), encoding="utf-8")
    metadata, draft = read_role_result("writer", tmp_path, 1)
    assert draft is None and metadata["diagnostic"]["visible_char_count"] == 5000
    assert metadata["error_code"] == "MODEL_JSON_INVALID"


def test_valid_completed_writer_output_is_retained(tmp_path):
    folder = tmp_path / "writer"
    store = ArtifactDirectory(folder / "artifacts")
    payload = {"schema_version": "sciassistant.claim-draft/v2", "claims": [], "direct_answer": "No evidence"}
    ref = store.put("writer-output", payload)
    (folder / "agent_result.json").write_text(json.dumps({"status": "completed", "error_code": None,
        "output_artifact_ids": [ref["artifact_id"]], "usage": {"model_calls": 1}}), encoding="utf-8")
    metadata, draft = read_role_result("writer", tmp_path, 0)
    assert draft == payload and metadata["status"] == "completed"
