from copy import deepcopy

import pytest

from multi_agent_pipeline_v2 import review_targets, check_review, ReviewContractError, WorkflowError
from multi_agent_quality import answer_requirements, scope_plan_to_question
from multi_agent_live import ROLE_PROMPTS
from test_multi_agent_pipeline_v2 import agents, pipeline


def test_current_checklist_exposes_new_ids_and_does_not_inherit_old_approval():
    evidence = {"evidence": [{"evidence_id": key} for key in ["old", "rejected", "new"]]}
    plan = {"groups": [{"id": "g1", "metrics": ["relation", "detection_performance"]}]}
    previous = {"allowed_evidence_ids": ["old", "historical"],
                "decisions": [{"evidence_id": "old"}, {"evidence_id": "rejected"}]}
    original = deepcopy((evidence, plan, previous))
    targets = review_targets(evidence, plan, previous)
    assert targets["current_evidence_ids"] == ["old", "rejected", "new"]
    assert targets["new_evidence_ids"] == ["new"]
    assert targets["new_or_previously_unapproved_ids"] == ["rejected", "new"]
    assert targets["prior_approved_current_ids"] == ["old"]
    assert targets["historical_only_ids"] == ["historical"]
    assert targets["automatic_approval"] is False
    assert targets["all_current_ids_require_new_decision"]
    assert targets["previous_decisions_are_context_only"]
    assert targets["requested_coverage"] == [{"group_id": "g1", "metric": value}
                                           for value in ["relation", "detection_performance"]]
    assert (evidence, plan, previous) == original


def test_current_duplicate_ids_are_not_silently_collapsed():
    with pytest.raises(WorkflowError):
        review_targets({"evidence": [{"evidence_id": "x"}] * 2}, {})


def test_first_checklist_contains_no_automatic_prior_approval():
    targets = review_targets({"evidence": [{"evidence_id": "x"}]}, {})
    assert targets["new_evidence_ids"] == ["x"]
    assert targets["prior_approved_current_ids"] == []


def test_workflow_passes_checksummed_targets_without_extra_model_call(tmp_path):
    configured, calls = agents()
    original = configured.reviewer.handler
    seen = []
    def reviewer(packet):
        inputs = [row["payload"] for row in packet["inputs"]]
        target = next(row for row in inputs if row.get("schema_version") == "sciassistant.review-targets/v1")
        evidence = next(row for row in inputs if "evidence" in row)
        seen.append(target)
        assert target["current_evidence_ids"] == [row["evidence_id"] for row in evidence["evidence"]]
        return original(packet)
    configured.reviewer.handler = reviewer
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("targets", "owner", "Compare A")
    assert result["run"]["status"] == "completed"
    assert result["run"]["model_calls_used"] == 5 and len(seen) == 1
    assert calls == ["planner", "retriever", "reviewer", "writer", "citation_auditor"]
    assert list((tmp_path / "artifacts").glob("review-targets-*.json"))


def test_missing_new_decision_still_rejected_after_checklist_creation():
    evidence = {"evidence": [{"evidence_id": key} for key in ["old", "new"]]}
    decision = {"evidence_id": "old", "decision": "approved", "reason_code": "SUPPORTED",
                "detail": "Supports the mechanism", "group_ids": ["g1"], "task_relevance": "direct_task_evidence"}
    previous = {"schema_version": "sciassistant.evidence-review/v5", "coverage_status": "partial",
                "allowed_evidence_ids": ["old"], "decisions": [decision], "coverage": []}
    assert review_targets(evidence, {}, previous)["new_evidence_ids"] == ["new"]
    with pytest.raises(ReviewContractError, match="REVIEW_DECISIONS_INCOMPLETE"):
        check_review(previous, evidence, {"g1"})


def test_each_reading_batch_gets_fresh_current_targets_with_prior_ids_separated(tmp_path):
    from test_multi_agent_reading_batches import executor, configured_agents
    from multi_agent_agents import ArtifactDirectory
    from multi_agent_pipeline_v2 import LiteraturePipelineV2
    from multi_agent_workflow import WorkflowStore
    tool, _ = executor(tmp_path)
    configured, _ = configured_agents(sufficient_after=2)
    original = configured.reviewer.handler
    seen = []
    def reviewer(packet):
        values = [row["payload"] for row in packet["inputs"]]
        targets = next(row for row in values if row.get("schema_version") == "sciassistant.review-targets/v1")
        seen.append(targets)
        assert targets["requested_coverage"]
        return original(packet)
    configured.reviewer.handler = reviewer
    folder = tmp_path / "current-run"
    flow = LiteraturePipelineV2(WorkflowStore(folder / "workflow.sqlite3"), ArtifactDirectory(folder / "artifacts"),
        configured, tool, event_path=folder / "events.jsonl")
    result = flow.run("fresh-batches", "owner", "Compare three topics")
    assert result["run"]["status"] == "completed" and result["run"]["model_calls_used"] == 6
    assert len(seen) == 2
    assert seen[0]["prior_approved_current_ids"] == []
    # This fixture approves all first-batch packets: retaining immutable prior
    # evidence may fill the 12-packet context. More indexed PDFs do NOT imply
    # new packets were selected, and the checklist must not invent new IDs.
    assert set(seen[1]["new_evidence_ids"]) == set(seen[1]["current_evidence_ids"]) - set(seen[0]["current_evidence_ids"])
    assert set(seen[1]["prior_approved_current_ids"]) == set(seen[0]["current_evidence_ids"])
    assert not set(seen[1]["new_evidence_ids"]) & set(seen[0]["current_evidence_ids"])


@pytest.mark.parametrize("question,removed,kept", [
    ("CLIP和DINOv2是什么关系？只比较检测性能与冻结骨干的取舍。", ["generation quality", "latency"], ["relation", "detection_performance"]),
    ("定义ViT并解释检测性能。", ["latency", "ranking"], ["definition", "accuracy"]),
    ("对比KV量化和投机解码的吞吐。", ["latency", "memory"], ["throughput"]),
    ("比较GAN与扩散模型的生成质量。", ["latency"], ["generation_quality"]),
    ("比较冻结ViT的检测质量。", ["generation_quality"], ["quality"]),
])
def test_comparison_does_not_request_every_measurement_family(question, removed, kept):
    plan = {"groups": [{"id": "g1", "metrics": [*kept, *removed], "queries": ["untouched"]}]}
    original = deepcopy(plan)
    scoped, report = scope_plan_to_question(plan, answer_requirements(question))
    assert scoped["groups"][0]["metrics"] == kept
    assert scoped["groups"][0]["queries"] == ["untouched"] and plan == original
    assert report["changes"][0]["unrequested_metrics"] == removed
    assert not report["evidence_auto_approval"]


@pytest.mark.parametrize("question,metrics", [
    ("比较KV量化对推理延迟、吞吐和质量的影响。", ["latency", "throughput", "quality"]),
    ("ViT准确率是多少？", ["accuracy"]),
    ("比较冻结骨干的显存和推理速度。", ["memory", "latency", "throughput"]),
])
def test_explicit_requests_and_quantitative_questions_keep_their_metrics(question, metrics):
    plan = {"groups": [{"id": "g1", "metrics": metrics}]}
    assert scope_plan_to_question(plan, answer_requirements(question))[0] == plan


def test_removed_inference_template_falls_back_to_qualitative_tradeoff():
    plan = {"groups": [{"id": "g1", "metrics": ["generation_quality", "latency"]}]}
    scoped, report = scope_plan_to_question(plan, answer_requirements("比较冻结和微调ViT在图像检测中的取舍。"))
    assert scoped["groups"][0]["metrics"] == ["comparison"]
    assert report["changes"] and not report["evidence_auto_approval"]


def test_context_cannot_add_old_benchmark_requirements():
    req = answer_requirements("比较CLIP和DINOv2的检测性能。", {"previous_answer": "latency throughput memory"})
    assert req["requested_measurement_families"] == ["performance"]


def test_legacy_requirements_and_unknown_dimensions_are_not_reinterpreted():
    plan = {"groups": [{"id": "g1", "metrics": ["latency", "custom_scientific_property"]}]}
    legacy = {"question_kind": "comparison", "evaluation_requested": True, "requested_dimensions": []}
    assert scope_plan_to_question(plan, legacy)[0] == plan
    scoped, _ = scope_plan_to_question(plan, answer_requirements("比较CLIP和DINOv2的架构。"))
    assert scoped["groups"][0]["metrics"] == ["custom_scientific_property"]


def test_live_prompts_have_neutral_examples_and_new_round_id_checklist():
    assert '"metrics":["latency","quality"]' not in ROLE_PROMPTS["planner"]
    assert "DETECTION performance is not image GENERATION quality" in ROLE_PROMPTS["planner"]
    assert "review-targets/v1" in ROLE_PROMPTS["reviewer"]
    assert "new_evidence_ids first" in ROLE_PROMPTS["reviewer"]
