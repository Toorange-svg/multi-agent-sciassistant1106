"""Source consent is per-round; reference removal is not original deletion."""
import json
from pathlib import Path
import shutil
import subprocess

import pytest

ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.parametrize('scenario', ['upload_local', 'upload_auto', 'switch_local', 'radio_default', 'new_file_resets', 'submitted_resets',
    'reuse_one_card', 'detach', 'detach_failure', 'account_change'])
def test_sources(scenario):
    node = shutil.which('node')
    if not node: pytest.skip('Node required')
    source = (ROOT / 'chatAi/research_library.js').read_text(encoding='utf8')
    harness = r'''
const vm=require('node:vm'),assert=require('node:assert/strict'),requests=[];
const element=()=>({hidden:true,children:[],events:{},textContent:'',checked:false,
 get childNodes(){return this.children;},append(...x){this.children.push(...x);},replaceChildren(...x){this.children=x;},
 addEventListener(k,fn){this.events[k]=fn;}});
const host=element(),mode=Object.assign(element(),{value:'multi_agent_rag'}),file={name:'paper.pdf'},other={name:'other.pdf'};
const window={currentSessionId:null,userToken:'a',sciencePendingFile:file,addEventListener(){},SciencePdfSession:{clear(){window.detached=true;}}};
const findId=(n,id)=>n.id===id?n:n.children?.map(x=>findId(x,id)).find(Boolean);
const document={createElement:element,createTextNode:t=>({textContent:t}),getElementById:id=>id==='library-selected-pdf'?host:
 id==='research-processing-mode'?mode:findId(host,id),querySelectorAll:()=>[]};
const fetch=async(url,options={})=>{requests.push({url,method:options.method||'GET'});return {ok:SCENARIO!=='detach_failure',json:async()=>({file:{}})};};
vm.runInNewContext(SOURCE,{window,document,fetch,setInterval(){},DOMException,URL,Blob});
window.currentSessionId='s1';
(async()=>{
const lib=window.ResearchLibrary,form={data:[],append(k,v){this.data.push([k,v]);}};
if(['reuse_one_card','detach','detach_failure'].includes(SCENARIO)){
 assert(lib.attachment({filename:'paper.pdf',source_task_id:'a'.repeat(12)},{credential:'a',session:'s1'}));
 assert.equal(host.children.length,3);
 if(SCENARIO.startsWith('detach')){
  await host.children[2].events.click();
  assert.equal(requests.length,1);assert.equal(requests[0].method,'DELETE');
  assert(requests[0].url.includes('/conversations/s1/pdf-attachment'));
  assert.equal(host.hidden,SCENARIO==='detach');
 }else{await lib.append(form,'s1','multi_agent_rag',null);assert(form.data.some(x=>x[0]==='pdf_source_task_id'));}
}else{
 lib.pending(file);
 const local=document.getElementById('library-local-only'),publicChoice=document.getElementById('library-public-consent');
 assert(local.checked&&!publicChoice.checked);assert.equal(local.type,'radio');assert.equal(publicChoice.type,'radio');assert.equal(local.name,publicChoice.name);
 publicChoice.checked=!['upload_local','radio_default'].includes(SCENARIO);local.checked=!publicChoice.checked;
 if(SCENARIO==='switch_local'){local.checked=true;publicChoice.checked=false;}
 if(SCENARIO==='new_file_resets'){window.sciencePendingFile=other;lib.pending(other);}
 if(SCENARIO==='submitted_resets')lib.submitted({pdf_attachment:{filename:'paper.pdf',source_task_id:'a'.repeat(12)}});
 if(SCENARIO==='account_change'){window.userToken='b';lib.changed();assert(host.hidden);}
 else{await lib.append(form,'s1','multi_agent_rag',SCENARIO==='new_file_resets'?other:SCENARIO==='submitted_resets'?null:file);
  const auto=SCENARIO==='upload_auto';assert(form.data.some(x=>x[0]==='source_policy'&&x[1]===(auto?'auto':'local')));
  assert(form.data.some(x=>x[0]==='allow_public_search'&&x[1]===(auto?'true':'false')));}
 assert.equal(requests.length,SCENARIO==='account_change'?1:0);
}
console.log('ok');
})().catch(e=>{console.error(e);process.exitCode=1;});
'''
    result = subprocess.run([node, '-'], input='const SOURCE=' + json.dumps(source) + ';const SCENARIO=' + json.dumps(scenario) + ';\n' + harness,
                            capture_output=True, text=True, encoding='utf8', timeout=10)
    assert result.returncode == 0, result.stderr


def test_preview_uses_png_without_weakening_browser_policy():
    source = (ROOT / 'chatAi/research_library.js').read_text(encoding='utf8')
    assert "type: 'image/png'" in source and "createElement('iframe')" not in source
    assert '仅查看，不会调用模型或创建索引' in source
    assert 'URL.revokeObjectURL(previewUrl)' in source
