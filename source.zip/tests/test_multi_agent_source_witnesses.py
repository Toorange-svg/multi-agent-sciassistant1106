"""Literal audit provenance never substitutes for scientific entailment."""
from copy import deepcopy

import pytest

from multi_agent_agents import AgentContractError
from multi_agent_live import ROLE_PROMPTS, normalize_live_result
from multi_agent_quality import WITNESS_AUDIT_SCHEMA, FIELD_AUDIT_SCHEMA, ABSENCE_AUDIT_SCHEMA, check_audit, publication_rejections
from test_multi_agent_scientific_scope import draft, audit

QUOTE = "Fine-tuning often induces catastrophic forgetting."


def inputs():
    data = draft()
    value = audit(data)
    value["schema_version"] = WITNESS_AUDIT_SCHEMA
    value["claim_results"][0]["source_witnesses"] = [{"evidence_id": "e1", "quote": QUOTE}]
    evidence = {"evidence": [{"evidence_id": "e1", "review_status": "approved", "excerpt": QUOTE}]}
    return value, data, evidence


def test_current_output_preserves_real_witness_and_does_not_modify_inputs():
    value, data, evidence = inputs()
    value["schema_version"] = ABSENCE_AUDIT_SCHEMA
    value["claim_results"][0]["field_results"] = {field: {"status": "supported" if data["claims"][0].get(field) else "not_applicable",
        "detail": "Reviewed field or empty field.", "absence_checks": []} for field in ("text", "scope_note", "qualification")}
    before = deepcopy((value, data, evidence))
    normalized = normalize_live_result("citation_auditor", {"output": value}, require_current=True)["output"]
    checked = check_audit(normalized, data, evidence)
    assert not checked["contract_errors"] and not checked["witness_issues"]
    assert publication_rejections(checked, data) == set()
    assert (value, data, evidence) == before


@pytest.mark.parametrize("bad", [None, [], [{"evidence_id": "e1", "quote": "too short"}],
    [{"evidence_id": "unknown", "quote": QUOTE}], [{"evidence_id": "e1", "quote": "a" * 351}],
    [{"evidence_id": "e1", "quote": QUOTE, "invented": True}], [False],
    [{"evidence_id": "e1", "quote": QUOTE}] * 5])
def test_missing_or_malformed_witness_is_protocol_error_not_auto_filled(bad):
    value, data, evidence = inputs()
    value["claim_results"][0]["source_witnesses"] = bad
    checked = check_audit(value, data, evidence)
    assert not checked["contract_errors"]
    assert checked["witness_issues"][0]["reason"] == "AUDIT_SOURCE_WITNESSES_INVALID"
    assert publication_rejections(checked, data) == {"c1"}


@pytest.mark.parametrize("quote", ["Fine-tuning always induces catastrophic forgetting.",
    "Fine-tuning often … catastrophic forgetting.", "微调经常导致灾难性遗忘，需要具体核查实际实验范围。"])
def test_modified_joined_or_translated_quotation_does_not_match(quote):
    value, data, evidence = inputs()
    value["claim_results"][0]["source_witnesses"][0]["quote"] = quote
    checked = check_audit(value, data, evidence)
    assert not checked["contract_errors"]
    assert checked["witness_issues"][0]["reason"] == "AUDIT_WITNESS_NOT_IN_SOURCE"


@pytest.mark.parametrize("change", ["pending", "wrong_id", "metadata_only", "cross_field"])
def test_quote_requires_same_approved_excerpt_not_other_fields(change):
    value, data, evidence = inputs()
    source = evidence["evidence"][0]
    if change == "pending":
        source["review_status"] = "pending"
    elif change == "wrong_id":
        source["evidence_id"] = "other"
    elif change == "metadata_only":
        source.update(excerpt="", title=QUOTE)
    else:
        source.update(excerpt=QUOTE[:18], text=QUOTE[18:])
    assert check_audit(value, data, evidence)["witness_issues"]


def test_whitespace_only_normalization_keeps_pdf_line_breaks_usable():
    value, data, evidence = inputs()
    evidence["evidence"][0]["excerpt"] = QUOTE.replace(" ", "\n  ")
    assert check_audit(value, data, evidence)["witness_issues"] == []


def test_invalid_witness_blocks_only_its_claim_and_dependent():
    value, data, evidence = inputs()
    data["claims"] += [{**data["claims"][0], "claim_id": "c2"},
                        {**data["claims"][0], "claim_id": "c3", "depends_on_claim_ids": ["c1"]}]
    value["claim_results"] += [{**deepcopy(value["claim_results"][0]), "claim_id": "c2"},
                               {**deepcopy(value["claim_results"][0]), "claim_id": "c3"}]
    value["claim_results"][0]["source_witnesses"][0]["quote"] = "An invented conclusion absent from the source."
    checked = check_audit(value, data, evidence)
    assert not checked["contract_errors"]
    assert publication_rejections(checked, data) == {"c1", "c3"}


def test_quote_format_fault_does_not_block_independent_valid_claim():
    value, data, evidence = inputs()
    data["claims"].append({**data["claims"][0], "claim_id": "c2"})
    value["claim_results"].append({**deepcopy(value["claim_results"][0]), "claim_id": "c2"})
    value["claim_results"][0]["source_witnesses"] = []
    checked = check_audit(value, data, evidence)
    assert not checked["contract_errors"]
    assert publication_rejections(checked, data) == {"c1"}


def test_valid_quote_is_not_deterministic_semantic_approval():
    value, data, evidence = inputs()
    # Literal validator intentionally cannot infer Chinese entailment. The
    # counterexample stays visible: semantics still require model/manual review.
    data["claims"][0]["text"] = "微调总是导致遗忘。"
    assert not check_audit(value, data, evidence)["witness_issues"]
    row = value["claim_results"][0]
    row.update(decision="rejected", reason_code="OVERSTATED_SCOPE", source_witnesses=[])
    row["scope_checks"]["comparison_design"] = "unsupported"
    value.update(status="needs_revision", rejected_claim_ids=["c1"],
                 issues=[{"claim_id": "c1", "reason_code": "OVERSTATED_SCOPE"}])
    assert publication_rejections(check_audit(value, data, evidence), data) == {"c1"}


def test_historical_v4_stays_readable_but_current_live_cannot_downgrade():
    data = draft()
    old = audit(data)
    assert not check_audit(old, data)["contract_errors"]
    normalize_live_result("citation_auditor", {"output": old})
    with pytest.raises(AgentContractError):
        normalize_live_result("citation_auditor", {"output": old}, require_current=True)


def test_prompts_require_modal_actor_and_unmatched_comparison_boundaries():
    for role in ("writer", "citation_auditor"):
        assert "often" in ROLE_PROMPTS[role] and "teacher" in ROLE_PROMPTS[role]
        assert "different datasets" in ROLE_PROMPTS[role]


@pytest.mark.parametrize("correct_second", [True, False])
def test_wrong_audit_quote_repairs_auditor_not_writer(tmp_path, correct_second):
    from test_multi_agent_pipeline_v2 import agents, pipeline
    configured, calls = agents()
    count = []
    actual = "This study reports supported features in benchmark A."
    def auditor(packet):
        calls.append("citation_auditor")
        count.append(packet)
        data = next(row["payload"] for row in packet["inputs"] if "claims" in row["payload"])
        value = audit(data)
        value["schema_version"] = WITNESS_AUDIT_SCHEMA
        for row in value["claim_results"]:
            row["source_witnesses"] = [{"evidence_id": row["evidence_ids"][0],
                "quote": actual if correct_second and len(count) > 1 else "An invented quotation never stated in the approved source."}]
        return {"output": value}
    configured.citation_auditor.handler = auditor
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {"status": "ok", "papers": [
        {"paper_id": "1", "title": "Paper", "abstract": actual}]})
    result = flow.run("quote-repair", "owner", "A")
    assert len(count) == 2 and calls.count("writer") == 1
    assert result["run"]["model_calls_used"] == 6
    assert result["run"]["status"] == ("completed" if correct_second else "failed")
    if not correct_second:
        assert result["run"]["failure_code"] == "NO_AUDITED_CLAIMS"
    feedback = next(row["payload"] for row in count[1]["inputs"] if row["payload"].get("stage") == "citation_auditor")
    assert feedback["source_witness_issues"][0]["claim_id"] == "c1"
    assert "AUDIT_WITNESS_NOT_IN_SOURCE" in feedback["reason_codes"]
