"""Actual visible audit input and verified-metadata reading priority, offline."""
from copy import deepcopy
from dataclasses import replace

import pytest

from multi_agent_agents import AgentContractError
from multi_agent_evidence import source_attribution_hint
from multi_agent_live import normalize_live_result, rank_read_candidates, ROLE_PROMPTS
from multi_agent_pipeline_v2 import prioritize_source_title_actions
from multi_agent_quality import citation_audit_input, check_audit, publication_rejections
from test_multi_agent_pipeline_v2 import agents, pipeline, worker
from test_multi_agent_protocol_recovery import audit_data


def test_audit_input_preserves_visible_scope_and_hidden_detail_without_approval():
    draft = {"schema_version": "sciassistant.claim-draft/v2", "claims": [{"claim_id": "c1",
             "text": "This is a reported result.", "scope_note": "Only within benchmark X.",
             "qualification": "The annotation protocol was not fully read.", "evidence_ids": ["e1"]}]}
    old = deepcopy(draft)
    data = citation_audit_input(draft)
    row = data["claims"][0]
    assert draft == old
    assert row["visible_text"] == "This is a reported result.\nOnly within benchmark X."
    assert row["hidden_review_detail"] == draft["claims"][0]["qualification"]
    assert "decision" not in row and "approved" not in row
    # A new input artifact cannot rescue an incomplete audit.
    audit = {"schema_version": "sciassistant.citation-audit/v3", "status": "passed",
             "issues": [], "rejected_claim_ids": [], "claim_results": []}
    assert check_audit(audit, draft)["contract_errors"]
    assert publication_rejections(audit, draft) == {"c1"}


def test_legacy_qualification_remains_visible_not_reinterpreted():
    data = citation_audit_input({"claims": [{"claim_id": "c1", "text": "A", "qualification": "Legacy caveat"}]})
    assert data["claims"][0]["visible_text"] == "A\nLegacy caveat"
    assert data["claims"][0]["hidden_review_detail"] == ""


@pytest.mark.parametrize("retry", ["none", "audit_protocol", "writer_revision"])
def test_every_audit_receives_question_requirements_plan_and_current_visible_claims(tmp_path, retry):
    configured, _calls = agents()
    packets = []
    def audit(packet):
        packets.append(packet)
        values = [item["payload"] for item in packet["inputs"]]
        assert next(value for value in values if "question" in value)["question"] == "What is A?"
        assert any(value.get("schema_version", "").startswith("sciassistant.answer-requirements/") for value in values)
        assert any("groups" in value for value in values)
        draft = next(value for value in values if "direct_answer" in value)
        targets = next(value for value in values if value.get("schema_version") == "sciassistant.citation-audit-input/v1")
        assert [r["claim_id"] for r in targets["claims"]] == [r["claim_id"] for r in draft["claims"]]
        verdict = audit_data(draft, size=10)
        if len(packets) == 1 and retry == "audit_protocol":
            verdict["claim_results"] = []
        if len(packets) == 1 and retry == "writer_revision":
            verdict.update(status="needs_revision", rejected_claim_ids=["c1"],
                           issues=[{"claim_id": "c1", "reason_code": "UNSUPPORTED_NUMBER"}])
            verdict["claim_results"][0].update(decision="rejected", reason_code="UNSUPPORTED_NUMBER")
        return {"output": verdict}
    configured = replace(configured, citation_auditor=worker("citation_auditor", audit, "audit_citations"))
    flow, _store = pipeline(tmp_path, configured)
    result = flow.run("run", "owner", "What is A?")
    assert result["run"]["status"] == "completed"
    assert len(packets) == (1 if retry == "none" else 2)
    assert result["run"]["model_calls_used"] <= 7


def test_prompt_separates_specific_statement_support_from_full_document_coverage():
    prompt = ROLE_PROMPTS["citation_auditor"]
    assert "visible_text" in prompt and "CURRENT question" in prompt
    assert "partial coverage alone is not a claim defect" in prompt
    assert "do NOT invalidate a supported" in prompt
    assert "Essential conditions" in prompt and "Related-work paraphrases still cannot certify" in prompt


def plan_and_requests():
    plan = {"groups": [{"id": "g1", "question": "Transformer", "source_hints": ["Attention Is All You Need"]}]}
    requests = [{"request_id": f"r{i}", "action": "request_arxiv_search",
                 "arguments": {"group_id": "g1", "query": q}}
                for i, q in enumerate(['ti:"Transformer"', 'abs:"attention"'], 1)]
    return plan, requests


def test_title_clue_uses_existing_slot_keeps_broad_query_and_no_fake_source():
    plan, requests = plan_and_requests()
    old = deepcopy((plan, requests))
    result, changes = prioritize_source_title_actions(plan, requests, {"explicit_entities": []})
    assert (plan, requests) == old
    assert len(result) == 2 and result[0] == requests[0]
    assert result[1]["arguments"]["query"] == 'ti:"Attention Is All You Need"'
    assert changes[0]["reason_code"] == "PLANNED_SOURCE_TITLE_QUERY"
    assert "paper_id" not in changes[0] and "approval" not in changes[0]


def test_single_search_or_explicit_entity_does_not_get_replaced():
    plan, requests = plan_and_requests()
    assert prioritize_source_title_actions(plan, requests[:1], {"explicit_entities": []}) == (requests[:1], [])
    requests[1]["arguments"]["query"] = 'ti:"XAIGID-RewardBench"'
    assert prioritize_source_title_actions(plan, requests, {"explicit_entities": ["XAIGID-RewardBench"]}) == (requests, [])


def test_entity_already_covered_in_core_query_allows_original_title_slot():
    plan, requests = plan_and_requests()
    requests[1]["arguments"]["query"] = 'abs:"Transformer" AND abs:"mechanism"'
    result, changes = prioritize_source_title_actions(plan, requests, {"explicit_entities": ["Transformer"]})
    assert result[0] == requests[0]
    assert result[1]["arguments"]["query"] == 'ti:"Attention Is All You Need"'
    assert len(changes) == 1


@pytest.mark.parametrize("hint", ['x', 'a" OR all:x', 'https://example.com/Paper', 'a\nb', 'x' * 201, 42])
def test_unsafe_or_unbounded_title_clues_rejected(hint):
    result = {"output": {"schema_version": "sciassistant.research-plan/v2",
                         "groups": [{"id": "g1", "source_hints": [hint]}]}}
    with pytest.raises(AgentContractError):
        normalize_live_result("planner", result)


def test_optional_title_clues_legacy_plan_and_normalization():
    plan, _requests = plan_and_requests()
    result = normalize_live_result("planner", {"output": {"schema_version": "sciassistant.research-plan/v2", **plan}})
    assert result["output"]["groups"][0]["source_hints"] == ["Attention Is All You Need"]
    legacy = normalize_live_result("planner", {"output": {"groups": [{"id": "g1"}]}})
    assert "source_hints" not in legacy["output"]["groups"][0]


def test_no_added_queries_when_title_is_already_searched():
    plan, requests = plan_and_requests()
    requests[1]["arguments"]["query"] = 'ti:"Attention Is All You Need"'
    result, changes = prioritize_source_title_actions(plan, requests, {"explicit_entities": []})
    assert result == requests and changes == []


def test_live_reading_queue_prefers_retrieved_title_and_keeps_topic_fairness(tmp_path):
    from test_multi_agent_reading_batches import executor
    tool, _downloads = executor(tmp_path)
    plan, _requests = plan_and_requests()
    plan["groups"][0]["core"] = ["Transformer"]
    plan["groups"].append({"id": "g2", "question": "Other topic", "core": ["Other"]})
    tool.configure_plan(plan)
    tool.group_queries = {"g1": ['ti:"Transformer"'], "g2": ['ti:"Other"']}
    tool.candidates = {
        "1706.03762": {"paper_id": "1706.03762v1", "title": "Attention Is All You Need", "group_ids": ["g1"]},
        "2401.00001": {"paper_id": "2401.00001v1", "title": "Transformer in astronomy", "group_ids": ["g1"]},
        "2401.00002": {"paper_id": "2401.00002v1", "title": "Other topic", "group_ids": ["g2"]}}
    queue = tool._reading_queue()
    assert [(row[0], row[2]["paper_id"]) for row in queue[:2]] == [("g1", "1706.03762v1"), ("g2", "2401.00002v1")]
    assert all("review_status" not in row[2] for row in queue)


@pytest.mark.parametrize("support", [[], ["scaled dot-product attention", "multi-head attention"]])
def test_chunk_retrieval_receives_planned_support_without_extra_search_or_approval(tmp_path, support):
    from multi_agent_live import LiveArxivRagExecutor
    from multi_agent_rag import EvidenceStore, HybridRetriever
    observed = []
    services = HybridRetriever(EvidenceStore(tmp_path / "test.sqlite3"))
    def search(query, **options):
        observed.append((query, options))
        return [{"evidence_id": "e1", "paper_id": "1706.03762v7", "title": "Attention Is All You Need",
                 "text": "MultiHead(Q,K,V) = Concat(head1, ..., headh)W", "locator": {"page": 5}}]
    services.search = search
    tool = LiveArxivRagExecutor(tmp_path / "run", tmp_path / "store", rag_mode="lexical", services=services)
    tool.configure_plan({"groups": [{"id": "g1", "core": ["Transformer"], "support": support,
                                      "question": "How does attention work?", "metrics": ["mechanism"]}]})
    tool.group_queries = {"g1": ['ti:"Transformer"']}
    tool.candidates = {"1706.03762": {"paper_id": "1706.03762v7", "title": "Attention Is All You Need", "group_ids": ["g1"]}}
    tool.ingested = {"arxiv-1706-03762v7"}
    packets = tool._select_packets()
    assert len(observed) == 1 and len(packets) == 1
    assert all(term in observed[0][0] for term in ["Transformer", "How does attention work?", "mechanism", *support])
    assert observed[0][1]["context_budget"] == 4000 and observed[0][1]["per_document"] == 2
    assert packets[0]["locator"]["page"] == 5 and "review_status" not in packets[0]


def test_title_priority_needs_actual_exact_metadata_match_not_an_abstract_mention():
    papers = [{"paper_id": "a", "title": "Transformer Transformer Transformer Transformer Transformer",
               "abstract": "Attention Is All You Need"},
              {"paper_id": "b", "title": "Attention is All You Need", "abstract": "attention mechanism"}]
    result = rank_read_candidates(papers, ['ti:"Transformer"'], core=["Transformer"], source_hints=["Attention Is All You Need"])
    assert result[0]["paper_id"] == "b"
    assert all("review_status" not in item for item in result)
    assert len(rank_read_candidates(papers[:1], [], source_hints=["nonexistent title"])) == 1


@pytest.mark.parametrize("abstract", ["In this Review, we provide a systematic overview.",
    "We present a comprehensive survey of detectors.", "This paper provides a systematic review of methods.",
    "We systematically review existing works.", "本文系统综述检测方法。"])
def test_survey_self_description_not_in_title_is_secondary_hint(abstract):
    row = {"title": "Definition, Recent Advances and Challenges", "excerpt": "A method overview", "locator": {"page": 21}}
    old = deepcopy(row)
    hint = source_attribution_hint(row, document_abstract=abstract)
    assert row == old
    assert hint["classification"] == "secondary_summary" and hint["survey_abstract_hint"] is True
    assert hint["primary_method_verified"] is False


@pytest.mark.parametrize("abstract", ["We compare against a prior review.", "Reviewers praised our method.",
    "A survey was conducted among users.", "We review our predictions before publication.", ""])
def test_passing_review_mention_does_not_classify_primary_paper_as_survey(abstract):
    hint = source_attribution_hint({"title": "New Model", "excerpt": "Results"}, document_abstract=abstract)
    assert hint["classification"] == "unclassified" and hint["survey_abstract_hint"] is False
    assert hint["primary_method_verified"] is False
