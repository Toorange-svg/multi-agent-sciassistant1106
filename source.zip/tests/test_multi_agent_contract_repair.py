"""Format repair calls remain bounded; recovery never broadens approvals."""
import copy
import json
import time

import pytest

from multi_agent_live import LiveModelClient, ROLE_PROMPTS
from multi_agent_pipeline_v2 import PipelineExecutionError, ReviewContractError, check_review
from test_multi_agent_live import Response, config
from test_multi_agent_pipeline_v2 import agents, pipeline


def test_retriever_prompt_example_is_complete_and_escaped():
    example = ROLE_PROMPTS["retriever"].split("Exact valid envelope example: ", 1)[1]
    decoded, _ = json.JSONDecoder().raw_decode(example)
    assert decoded["status"] == "completed"
    assert decoded["output"]["action_count"] == len(decoded["tool_requests"]) == 1
    assert decoded["tool_requests"][0]["arguments"]["query"] == '(ti:"PagedAttention" OR abs:"PagedAttention")'


@pytest.mark.parametrize("error", ["MODEL_JSON_INVALID", "MODEL_SCHEMA_REJECTED"])
def test_retriever_repair_has_distinct_call_and_same_artifact_inputs(tmp_path, error):
    configured, _ = agents()
    handler = configured.retriever.handler
    packets = []
    def retriever(packet):
        packets.append(copy.deepcopy(packet))
        if len(packets) == 1:
            return {"status": "failed", "error_code": error}
        return handler(packet)
    configured.retriever.handler = retriever
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("run-1", "owner-1", "question")
    assert result["run"]["status"] == "completed"
    assert result["run"]["model_calls_used"] == 6
    assert len(packets) == 2 and packets[0]["inputs"] == packets[1]["inputs"]
    assert packets[1]["remaining_model_calls"] == packets[0]["remaining_model_calls"] - 1
    records = sorted((tmp_path / "agents").glob("*-retriever.json"))
    assert [p.name for p in records] == ["02-retriever.json", "03-retriever.json"]
    events = [json.loads(row) for row in (tmp_path / "events.jsonl").read_text().splitlines()]
    retries = [row for row in events if row["event"] == "agent_format_retry"]
    assert len(retries) == 1 and retries[0]["reason_code"] == error


def test_retriever_invalid_live_json_repairs_through_real_adapter(tmp_path, monkeypatch):
    monkeypatch.setenv("MODEL_REQUEST_URL", "https://example.test/v1/chat/completions")
    configured, _ = agents()
    valid = configured.retriever.handler
    responses, packets = [], []
    class BrokenResponse(Response):
        def iter_content(self, **kwargs):
            yield json.dumps({"choices": [{"finish_reason": "stop", "message": {
                "content": '{"tool_requests":[{"query":"ti:"ViT""}]}'}}]}).encode()
    def post(_url, **kwargs):
        packet = json.loads(kwargs["json"]["messages"][1]["content"])
        packets.append(packet)
        response = BrokenResponse(None) if len(packets) == 1 else Response({
            **valid(packet), "output": {"schema_version": "sciassistant.search-actions/v1", "action_count": 1}})
        responses.append(response)
        return response
    client = LiveModelClient(config(), post=post)
    configured.retriever.handler = lambda packet: client.call("retriever", packet)
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("run-1", "owner-1", "question")
    assert result["run"]["status"] == "completed" and result["run"]["model_calls_used"] == 6
    assert len(responses) == 2 and all(r.closed for r in responses)
    assert not any('ti:\\"ViT' in p.read_text(encoding="utf-8")
                   for p in (tmp_path / "artifacts").glob("*.json"))


def test_retriever_second_format_failure_uses_compiled_plan_queries(tmp_path):
    configured, calls = agents()
    configured.retriever.handler = lambda _: {"status": "failed", "error_code": "MODEL_SCHEMA_REJECTED"}
    flow, _ = pipeline(tmp_path, configured)
    # Mark the deterministic fixture as a live retrieval executor so the
    # production-only compiled-query fallback is exercised.
    flow.executor.documents = object()
    result = flow.run("run-compiled-fallback", "owner-1", "question")
    assert result["run"]["status"] == "completed"
    assert result["run"]["model_calls_used"] == 6
    events = [json.loads(row) for row in (tmp_path / "events.jsonl").read_text(encoding="utf-8").splitlines()]
    fallback = [row for row in events if row.get("event") == "retriever_format_fallback"]
    assert len(fallback) == 1 and fallback[0]["semantic_auto_approval"] is False


def test_planner_second_format_failure_keeps_literal_question_query(tmp_path):
    configured, _ = agents()
    configured.planner.handler = lambda _: {"status": "failed", "error_code": "MODEL_SCHEMA_REJECTED"}
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("run-planner-fallback", "owner-1", "What is the relation between A and B?")
    assert result["run"]["status"] == "completed"
    assert result["run"]["model_calls_used"] == 6
    events = [json.loads(row) for row in (tmp_path / "events.jsonl").read_text(encoding="utf-8").splitlines()]
    assert any(row.get("event") == "planner_format_fallback" for row in events)


@pytest.mark.parametrize("error", ["MODEL_HTTP_429", "MODEL_SERVICE_UNAVAILABLE", "MODEL_OUTPUT_TRUNCATED",
                                  "AGENT_CONTRACT_REJECTED", "AGENT_DEADLINE_EXCEEDED"])
def test_non_format_errors_do_not_trigger_retry(tmp_path, error):
    configured, _ = agents()
    configured.retriever.handler = lambda _: {"status": "failed", "error_code": error}
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("run-1", "owner-1", "question")
    assert result["run"]["status"] == "failed" and result["run"]["model_calls_used"] == 2
    assert not flow.retriever_format_retry_used


def test_retriever_format_retry_once_per_run_not_per_phase(tmp_path):
    configured, _ = agents()
    configured.retriever.handler = lambda _: {"status": "failed", "error_code": "MODEL_JSON_INVALID"}
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("run-1", "owner-1", "question")
    assert result["run"]["model_calls_used"] == 3
    assert result["run"]["failure_code"] == "MODEL_JSON_INVALID"
    assert len(list((tmp_path / "agents").glob("*-retriever.json"))) == 2


@pytest.mark.parametrize("reserve", ["time", "calls", "used"])
def test_format_repair_respects_final_answer_reserve(tmp_path, reserve):
    configured, _ = agents()
    configured.retriever.handler = lambda _: {"status": "failed", "error_code": "MODEL_JSON_INVALID"}
    flow, store = pipeline(tmp_path, configured)
    store.create_run("run-1", "owner-1")
    store.transition("run-1", "planned")
    store.transition("run-1", "retrieving")
    flow.deadline = time.monotonic() + (150 if reserve == "time" else 360)
    if reserve == "calls":
        for _ in range(6):
            store.reserve_model_call("run-1", "planner")
    if reserve == "used":
        flow.retriever_format_retry_used = True
    before = store.get_run("run-1")["model_calls_used"]
    with pytest.raises(PipelineExecutionError, match="MODEL_JSON_INVALID"):
        flow._invoke("run-1", "retriever", "retrieval", [])
    assert store.get_run("run-1")["model_calls_used"] == before + 1


def review_fixture():
    old = {"evidence": [{"evidence_id": "good", "group_id": "g1", "excerpt": "approved text"},
                        {"evidence_id": "obsolete", "group_id": "g1", "excerpt": "rejected text"}]}
    previous = check_review({"coverage_status": "partial", "allowed_evidence_ids": ["good"],
        "coverage": [{"group_id": "g1", "status": "partial", "evidence_ids": ["good"]}],
        "decisions": [{"evidence_id": "good", "decision": "approved", "reason_code": "SUPPORTED"},
                      {"evidence_id": "obsolete", "decision": "rejected", "reason_code": "IRRELEVANT"}],
        "conflicts": []}, old, {"g1"})
    latest = {"evidence": [old["evidence"][0], {"evidence_id": "new", "group_id": "g1", "excerpt": "not approved"}]}
    bad = {**previous, "decisions": [{"evidence_id": "good", "decision": "rejected", "reason_code": "IRRELEVANT"}]}
    return previous, latest, bad


def test_obsolete_rejected_decision_does_not_destroy_earlier_approvals(tmp_path):
    configured, _ = agents()
    flow, _ = pipeline(tmp_path, configured)
    previous, latest, bad = review_fixture()
    unchanged = copy.deepcopy(previous)
    result = flow._validated_followup_review("run-1", bad, previous, latest, {"g1"}, None, {})
    assert result["coverage_status"] == "needs_review" and result["recovery_status"] == "rejected"
    assert result["allowed_evidence_ids"] == ["good"] and previous == unchanged
    assert result["decisions"] == [
        {"evidence_id": "good", "decision": "approved", "reason_code": "SUPPORTED"}]
    assert result["reviewed_evidence_ids"] == ["good"]  # new packet remains unreviewed, not a model rejection
    assert result["recovery_reason_code"] == "REVIEW_DECISIONS_INVALID"


def test_absent_prior_approval_still_rejected(tmp_path):
    configured, _ = agents()
    flow, _ = pipeline(tmp_path, configured)
    previous, latest, bad = review_fixture()
    latest["evidence"] = latest["evidence"][1:]
    with pytest.raises(ReviewContractError, match="REVIEW_APPROVED_EVIDENCE_UNKNOWN"):
        flow._validated_followup_review("run-1", bad, previous, latest, {"g1"}, None, {})


def test_new_conflicting_decisions_still_rejected_without_scoping():
    _, latest, bad = review_fixture()
    with pytest.raises(ReviewContractError, match="REVIEW_DECISIONS_INVALID"):
        check_review(bad, latest, {"g1"})


def test_bad_first_review_stops_after_single_format_repair(tmp_path):
    configured, _ = agents()
    configured.reviewer.handler = lambda _: {"status": "failed", "error_code": "MODEL_JSON_INVALID"}
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("run-1", "owner-1", "question")
    assert result["run"]["status"] == "failed" and result["run"]["model_calls_used"] == 4
    assert len(list((tmp_path / "agents").glob("*-reviewer.json"))) == 2


def test_full_workflow_writes_and_audits_after_rejected_packet_leaves_context(tmp_path):
    configured, calls = agents()
    reviews = []
    def reviewer(packet):
        reviews.append(1)
        return {"output": {"coverage_status": "partial", "allowed_evidence_ids": ["arxiv-1"],
            "conflicts": [], "coverage": [{"group_id": "g1", "status": "partial", "evidence_ids": ["arxiv-1"]}],
            "decisions": [{"evidence_id": "arxiv-1", "decision": "approved" if len(reviews) == 1 else "rejected",
                           "reason_code": "SUPPORTED" if len(reviews) == 1 else "IRRELEVANT"},
                          {"evidence_id": "arxiv-2" if len(reviews) == 1 else "arxiv-3", "decision": "rejected",
                           "reason_code": "IRRELEVANT"}]}}
    configured.reviewer.handler = reviewer
    base_writer = configured.writer.handler
    def writer(packet):
        approved = next(row["payload"]["evidence"] for row in packet["inputs"] if "evidence" in row["payload"])
        assert [row["evidence_id"] for row in approved] == ["arxiv-1"]
        assert "NEW_UNAPPROVED_CANARY" not in json.dumps(packet)
        return base_writer(packet)
    configured.writer.handler = writer
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {"status": "ok", "papers": [
        {"paper_id": "1", "title": "Good", "abstract": "Approved"},
        {"paper_id": "2", "title": "Other", "abstract": "Rejected"}]})
    original = flow._retrieve
    def retrieve(*args, **kwargs):
        evidence = original(*args, **kwargs)
        if kwargs.get("recovery"):
            evidence["evidence"] = [row for row in evidence["evidence"] if row["evidence_id"] != "arxiv-2"]
            evidence["evidence"].append({"evidence_id": "arxiv-3", "group_id": "g1", "excerpt": "NEW_UNAPPROVED_CANARY"})
        return evidence
    flow._retrieve = retrieve
    result = flow.run("run-1", "owner-1", "question")
    assert result["run"]["status"] == "needs_review" and result["run"]["failure_code"] is None
    assert result["run"]["model_calls_used"] == 8
    assert "writer" in calls and "citation_auditor" in calls and result["direct_answer"]
    events = [json.loads(row) for row in (tmp_path / "events.jsonl").read_text().splitlines()]
    retained = next(row for row in events if row["event"] == "prior_review_retained")
    assert retained["obsolete_rejected_decision_count"] == 1 and retained["new_approved_count"] == 0
