"""PDF UI state and async identity guards in Node; not visual browser proof."""
import json
from pathlib import Path
import shutil
import subprocess

import pytest

ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.parametrize("scenario", ["restore", "reuse", "new_file", "public_mode", "empty", "late_session",
    "late_account", "late_file", "detach", "unavailable", "changed", "multi_pdf", "unified_empty"])
def test_server_reference_and_async_guards(scenario):
    node = shutil.which("node")
    if not node: pytest.skip("Node required")
    source = (ROOT / "chatAi/pdf_session.js").read_text(encoding="utf8")
    harness = r'''
const vm=require('node:vm'),requests=[],chips=[];
const el=()=>({children:[],hidden:true,events:{},textContent:'',replaceChildren(...x){this.children=x;this.textContent='';},
 setAttribute(){},addEventListener(k,fn){this.events[k]=fn;},remove(){this.removed=true;}});
const host=el(),mode={value:'pdf_local'};
const window={currentSessionId:null,userToken:'a',selectedTab:'research',attachedContexts:[],showToast(){},updateAttachmentsBarVisibility(){}};
let release, slow=false, fail=false;
const fetch=async (url,init={})=>{requests.push({url,method:init.method||'GET'});
 if(slow)return new Promise(resolve=>{release=()=>resolve({ok:true,json:async()=>({attachment:{filename:'OLD_PAPER',source_task_id:'aaaaaaaaaaaa'}})});});
 return {ok:!fail,status:fail?404:200,json:async()=>({attachment:['empty','unified_empty'].includes(SCENARIO)?null:{filename:'论文 <script>.pdf',source_task_id:'aaaaaaaaaaaa'}})};};
const context={window,fetch,DOMException,AbortController,document:{createElement:el,getElementById:id=>id==='session-pdf-attachment'?host:id==='research-processing-mode'?mode:null,querySelectorAll:()=>chips}};
vm.runInNewContext(SOURCE,context);
window.currentSessionId='s1';
const form={values:[],append(k,v){this.values.push([k,v]);}};
(async()=>{
 let error=null;
 if(['late_session','late_account','late_file'].includes(SCENARIO)){
  slow=true;const pending=window.SciencePdfSession.restore();
  if(SCENARIO==='late_session')window.currentSessionId='s2';
  if(SCENARIO==='late_account')window.userToken='b';
  if(SCENARIO==='late_file')window.sciencePendingFile={};
  release();await pending;
 }else if(SCENARIO==='multi_pdf'){
  mode.value='multi_agent_pdf';await window.SciencePdfSession.restore();await window.SciencePdfSession.append(form,'s1','multi_agent_pdf',null);
 }else if(['public_mode','unified_empty'].includes(SCENARIO)){
  mode.value='multi_agent_rag';await window.SciencePdfSession.restore();await window.SciencePdfSession.append(form,'s1','multi_agent_rag',null);
 }else if(SCENARIO==='new_file'){
  window.sciencePendingFile={};await window.SciencePdfSession.restore();await window.SciencePdfSession.append(form,'s1','pdf_local',{});
 }else if(SCENARIO==='changed'){
  window.currentSessionId='s2';window.sciencePendingFile={};window.sciencePendingSessionId='s1';
  window.attachedContexts=[{scienceLocal:true},{name:'context'}];chips.push(el());await window.SciencePdfSession.changed();
 }else if(['reuse','empty'].includes(SCENARIO)){
  try{await window.SciencePdfSession.append(form,'s1','pdf_local',null);}catch(e){error=e.message;}
 }else{
  fail=SCENARIO==='unavailable';await window.SciencePdfSession.restore();
  if(['detach','unavailable'].includes(SCENARIO)){fail=false;await host.children[1].events.click();}
 }
 console.log(JSON.stringify({hidden:host.hidden,requests,children:host.children.map(n=>n.textContent),values:form.values,error,
  pending:!!window.sciencePendingFile,contexts:window.attachedContexts.length,removed:chips.every(n=>n.removed)}));
})().catch(e=>{console.error(e);process.exit(1);});
'''
    script = "const SOURCE=" + json.dumps(source) + ";const SCENARIO=" + json.dumps(scenario) + ";\n" + harness
    result = subprocess.run([node, "-"], input=script, text=True, encoding="utf8", capture_output=True, timeout=10)
    assert result.returncode == 0, result.stderr
    data = json.loads(result.stdout)
    if scenario == "restore":
        assert not data["hidden"] and data["children"] == ["本会话 PDF：论文 <script>.pdf（后续 PDF 解析可复用）", "移除"]
    elif scenario == "reuse": assert data["values"] == [["pdf_source_task_id", "aaaaaaaaaaaa"]]
    elif scenario == "multi_pdf":
        assert not data["hidden"] and '六角色' in data["children"][0]
        assert data["values"] == [["pdf_source_task_id", "aaaaaaaaaaaa"], ["source_policy", "local"], ["allow_public_search", "false"]]
    elif scenario == "empty": assert data["error"] and "上传" in data["error"] and not data["values"]
    elif scenario == "public_mode":
        assert not data["hidden"] and data["values"] == [["pdf_source_task_id", "aaaaaaaaaaaa"], ["source_policy", "local"], ["allow_public_search", "false"]]
    elif scenario == "unified_empty": assert data["hidden"] and not data["values"] and not data["error"]
    elif scenario == "new_file": assert not data["requests"] and not data["values"] and data["hidden"]
    elif scenario.startswith("late_"): assert data["hidden"] and not data["children"]
    elif scenario in {"detach", "unavailable"}:
        assert data["hidden"] and [r["method"] for r in data["requests"]] == ["GET", "DELETE"]
    elif scenario == "changed":
        assert not data["pending"] and data["contexts"] == 1 and data["removed"]
        assert data["requests"][0]["url"].endswith('/s2/pdf-attachment')


def test_chat_hooks_use_snapshot_not_global_file_and_configured_mode():
    html = (ROOT / "chatAi/ai_chat.html").read_text(encoding="utf8")
    assert '/chatAi/pdf_session.js' in html
    assert "SciencePdfSession?.append(formData, sessionId, processingMode, scienceFile)" in html
    assert "const scienceFile = savedAttachments.find(item => item.scienceLocal)?.file" in html
    assert "createdTask.pdf_attachment" in html and "SciencePdfSession?.changed()" in html
    assert "window.sciencePendingFile === scienceFile" in html
    assert 'id="session-pdf-attachment" hidden' in html


def test_deployment_and_identity_include_new_helpers():
    from runtime_identity import IDENTITY_FILES
    assert 'science_pdf_sessions.py' in IDENTITY_FILES and 'chatAi/pdf_session.js' in IDENTITY_FILES
    for name in ('Dockerfile.cloud', 'Dockerfile.account.cloud'):
        assert 'COPY science_pdf_sessions.py /app/' in (ROOT / name).read_text(encoding='utf8')
        assert '!science_pdf_sessions.py' in (ROOT / (name + '.dockerignore')).read_text(encoding='utf8')
