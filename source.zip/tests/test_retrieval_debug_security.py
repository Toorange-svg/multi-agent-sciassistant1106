"""The retrieval inspection UI is local-only and fails closed."""

from pathlib import Path

import pytest

from tools import retrieval_debug_app as debug


ROOT = Path(__file__).resolve().parents[1]


def test_debug_bind_defaults_to_loopback_and_rejects_remote_overrides(monkeypatch):
    monkeypatch.delenv("RETRIEVAL_DEBUG_HOST", raising=False)
    assert debug._configured_debug_host() == "127.0.0.1"
    assert debug._configured_debug_host("localhost") == "localhost"
    assert debug._configured_debug_host("::1") == "::1"
    for host in ("0.0.0.0", "192.168.1.20", "example.com", ""):
        with pytest.raises(RuntimeError, match="回环"):
            debug._configured_debug_host(host)


def test_launcher_never_binds_or_opens_non_loopback_debug_host():
    launcher = (ROOT / "tools/start_retrieval_debug.cmd").read_text(encoding="utf-8")
    assert "0.0.0.0" not in launcher
    assert "RETRIEVAL_DEBUG_HOST=127.0.0.1" in launcher
    assert "http://127.0.0.1:5080/" in launcher


def test_socket_peer_and_host_must_both_be_loopback():
    client = debug.app.test_client()
    assert client.get("/", environ_base={"REMOTE_ADDR": "127.0.0.1"}).status_code == 200
    remote = client.get("/", environ_base={"REMOTE_ADDR": "192.0.2.10"})
    assert remote.status_code == 403 and remote.get_json() == {"error": "LOCAL_ACCESS_REQUIRED"}
    rebound = client.get("/", headers={"Host": "attacker.example:5080"},
                         environ_base={"REMOTE_ADDR": "127.0.0.1"})
    assert rebound.status_code == 403 and rebound.get_json() == {"error": "LOCAL_ACCESS_REQUIRED"}


def test_cross_origin_mutation_is_rejected_before_queue_creation():
    client = debug.app.test_client()
    before = set(debug.QUEUES)
    response = client.post(
        "/api/queue",
        json={"queries": ["must never launch"]},
        headers={"Origin": "https://attacker.example"},
        environ_base={"REMOTE_ADDR": "127.0.0.1"},
    )
    assert response.status_code == 403
    assert response.get_json() == {"error": "SAME_ORIGIN_REQUIRED"}
    assert set(debug.QUEUES) == before


def test_debug_responses_are_non_cacheable_and_browser_hardened():
    response = debug.app.test_client().get("/")
    assert response.status_code == 200
    expected = {
        "Cache-Control": "no-store",
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "Referrer-Policy": "no-referrer",
        "Cross-Origin-Opener-Policy": "same-origin",
        "Cross-Origin-Resource-Policy": "same-origin",
    }
    for name, value in expected.items():
        assert response.headers[name] == value
    assert "default-src 'self'" in response.headers["Content-Security-Policy"]


def test_oversized_query_is_rejected_without_starting_worker():
    client = debug.app.test_client()
    before = set(debug.QUEUES)
    response = client.post("/api/queue", json={"queries": ["x" * (debug.MAX_QUERY_CHARS + 1)]})
    assert response.status_code == 413
    assert response.get_json() == {"error": "单个问题过长"}
    assert set(debug.QUEUES) == before
