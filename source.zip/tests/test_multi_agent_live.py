from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from types import SimpleNamespace

import pytest

from multi_agent_agents import AgentContractError, ArtifactDirectory
from multi_agent_live import LiveArxivRagExecutor, LiveConfigurationError, LiveModelClient, ROLE_OUTPUT_SCHEMAS, canonical_arxiv_query, normalize_live_result, rank_read_candidates
from multi_agent_pipeline_v2 import LiteraturePipelineV2
from multi_agent_rag import EvidenceStore, HybridRetriever, RagIndexer
from multi_agent_report import export_run_report
from multi_agent_workflow import WorkflowStore


def config(url="https://example.test/v1/chat/completions"):
    return SimpleNamespace(model_name="test-model", get_custom_llm_config=lambda: {"url": url, "token": "credential-canary"})


def typed_plan_fixture():
    return {'schema_version': ROLE_OUTPUT_SCHEMAS['planner'],
        'user_requirements': [{'id':'u1', 'question_quote':'A', 'answer_kind':'definition',
            'research_group_ids':['g1'], 'report_obligation_ids':[]}],
        'segment_dispositions': {'s1':['u1']}, 'groups': [{'id': 'g1',
        'kind': 'research', 'question_quote': 'A', 'core': ['A'], 'metrics': [],
        'support': [], 'queries': ['A'], 'question': 'A',
        'evidence_needs': [{'entity': 'A', 'question_quote': 'A', 'aspect': 'definition', 'source_title': ''}]}]}


def typed_report_review_fixture(audit_input):
    """Complete metadata for controlled protocol tests, not real semantic proof."""
    claims = [job['claim'] for job in audit_input['audit_jobs']]
    return {'schema_version': 'sciassistant.report-review/v1',
        'requirements': [{'requirement_id': row['requirement_id'], 'status': 'answered',
            'claim_ids': [c['claim_id'] for c in claims if row['requirement_id'] in c['requirement_ids']],
            'reason': '本测试的受控需求核对，不代表真实科研质量。'}
            for row in audit_input['report_review_request']['requirements']],
        'consistency': {'reviewed_claim_ids': [c['claim_id'] for c in claims], 'conflicts': []}}


def add_typed_report_review(configured):
    """Keep the original source-audit fixture; add only its missing v96 metadata."""
    original = configured.citation_auditor.handler
    def auditor(packet):
        result = original(packet)
        audit_input = next(item['payload'] for item in packet['inputs']
            if item['payload'].get('schema_version') == 'sciassistant.citation-audit-input/v1')
        result['output']['report_review'] = typed_report_review_fixture(audit_input)
        return result
    configured.citation_auditor.handler = auditor


class Response:
    status_code = 200
    closed = False

    def __init__(self, output):
        self.output = output

    def raise_for_status(self):
        pass

    def iter_content(self, **kwargs):
        yield json.dumps({"choices": [{"message": {"content": json.dumps(self.output)}}]}).encode()

    def close(self):
        self.closed = True


class PlainTextResponse:
    status_code = 200

    def __init__(self, text):
        self.text = text
        self.closed = False

    def iter_content(self, **kwargs):
        yield json.dumps({"choices": [{"message": {"content": self.text}}]}).encode()

    def close(self):
        self.closed = True


def test_model_adapter_is_bounded_and_discards_provider_private_fields(monkeypatch):
    monkeypatch.setenv("MODEL_REQUEST_URL", "https://example.test/v1/chat/completions")
    monkeypatch.delenv("MODEL_REQUEST_TOKEN", raising=False)
    observed = {}
    response = Response({'output': typed_plan_fixture()})
    def post(url, **kwargs):
        observed.update(kwargs)
        return response
    client = LiveModelClient(config(), post=post)
    result = client.call("planner", {"deadline_at": time.time() + 25, "inputs": []})
    assert result["output"]["groups"][0]['id'] == 'g1'
    assert 0 < observed["timeout"] <= 25
    assert observed["max_key_attempts"] == 1
    assert observed["allow_redirects"] is False
    assert response.closed
    assert "credential-canary" not in json.dumps(client.prompt_metadata()) + client.fingerprint
    assert "credential-canary" not in observed["json"]["messages"][1]["content"]


def test_general_fallback_returns_plain_answer_without_citations(monkeypatch):
    monkeypatch.setenv("MODEL_REQUEST_URL", "https://example.test/v1/chat/completions")
    observed = {}

    def post(target, **kwargs):
        observed.update(kwargs)
        return PlainTextResponse("这是基于通用知识的解释，不是本轮检索结论。")

    client = LiveModelClient(config(), post=post)
    permit = SimpleNamespace(deadline_at=time.time() + 10, call_number=3)
    answer = client.general_fallback("为什么卷积网络适合处理图像？", "RETRIEVAL_SOURCE_UNREACHABLE", permit)

    assert answer.startswith("这是基于通用知识")
    assert observed["json"]["max_tokens"] == 2200
    assert "不能声称已经查阅论文" in observed["json"]["messages"][0]["content"]


def test_unknown_role_schema_is_rejected(monkeypatch):
    monkeypatch.setenv("MODEL_REQUEST_URL", "https://example.test/v1/chat/completions")
    response = Response({"output": {"schema_version": "wrong/v9"}})
    client = LiveModelClient(config(), post=lambda *_a, **_k: response)
    result = client.call("planner", {"deadline_at": time.time() + 20, "inputs": []})
    assert result["status"] == "failed" and result["error_code"] == "MODEL_SCHEMA_REJECTED"
    assert response.closed


def test_deterministic_envelope_repair_does_not_guess_research_fields():
    out = normalize_live_result("planner", {"groups": [{"id": "g1"}]})
    assert out["output"]["groups"] == [{"id": "g1"}]
    assert out["output"]["schema_version"] == 'sciassistant.research-plan/v2'  # Legacy replay, not live downgrade.
    with pytest.raises(AgentContractError):
        normalize_live_result("planner", {"text": "invent a plan"})
    retrieved = normalize_live_result("retriever", {"output": {"action_count": 1, "actions": request()}})
    assert retrieved["tool_requests"] == request()
    assert "actions" not in retrieved["output"]
    with pytest.raises(AgentContractError):
        normalize_live_result("retriever", {"output": {"action_count": 1}})


def test_plain_query_never_becomes_a_long_exact_phrase():
    from deepdiver_v2.src.arxiv_query import validate_arxiv_query
    normalized = canonical_arxiv_query("PagedAttention paged KV cache memory management serving throughput")
    assert validate_arxiv_query(normalized)[0]
    assert 'ti:"PagedAttention"' in normalized
    assert '"PagedAttention paged KV cache' not in normalized
    legal = '(ti:"PagedAttention" OR abs:"PagedAttention")'
    assert canonical_arxiv_query(legal) == legal


def test_pdf_slot_prefers_direct_title_match_over_incidental_mentions():
    papers = [{"paper_id": "2606.13708", "title": "Remote Memory ISA", "abstract": "mentions PagedAttention"},
              {"paper_id": "2309.06180", "title": "Efficient Memory Management with PagedAttention"}]
    assert rank_read_candidates(papers, ['(ti:"PagedAttention" OR abs:"PagedAttention")'])[0]["paper_id"] == "2309.06180"


@pytest.mark.parametrize("url", ["http://public.example/model", "https://user:pass@example.test/model", "https://example.test/model?token=bad"])
def test_unsafe_model_endpoint_is_rejected_without_request(monkeypatch, url):
    monkeypatch.setenv("MODEL_REQUEST_URL", url)
    with pytest.raises(LiveConfigurationError):
        LiveModelClient(config(url), post=lambda *_a, **_k: pytest.fail("must not request"))


def test_real_local_http_model_adapter(monkeypatch):
    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            self.rfile.read(int(self.headers["Content-Length"]))
            content = json.dumps({"choices": [{"message": {"content": json.dumps({'output': typed_plan_fixture()})}}]}).encode()
            self.send_response(200)
            self.send_header("Content-Length", str(len(content)))
            self.end_headers()
            self.wfile.write(content)
        def log_message(self, *_):
            pass
    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    url = f"http://127.0.0.1:{server.server_port}/v1/chat/completions"
    monkeypatch.setenv("MODEL_REQUEST_URL", url)
    monkeypatch.setenv("MODEL_REQUEST_TOKENS", "")
    monkeypatch.setenv("MODEL_REQUEST_TOKEN", "")
    import requests
    client = LiveModelClient(config(url), post=lambda target, **kwargs: requests.post(target, **{
        k: v for k, v in kwargs.items() if k not in {"deadline", "max_key_attempts"}}))
    try:
        assert client.call("planner", {"deadline_at": time.time() + 10, "inputs": []})["output"]["groups"][0]["id"] == "g1"
    finally:
        server.shutdown(); server.server_close(); thread.join(5)


def make_search():
    return lambda *_a, **_k: {"status": "ok", "papers": [{"paper_id": "2309.06180", "title": "PagedAttention",
                                                         "abstract": "Memory management and throughput"}]}


def request():
    return [{"request_id": "r1", "action": "request_arxiv_search", "arguments": {"query": "PagedAttention throughput", "group_id": "g1"}}]


def create_pdf(folder):
    fitz = pytest.importorskip("fitz")
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / "source.pdf"
    with fitz.open() as doc:
        page = doc.new_page()
        page.insert_text((50, 70), "PagedAttention improves throughput by reducing memory fragmentation.")
        doc.save(path)
    return path


def test_real_pdf_parse_index_cache_and_highlight(tmp_path):
    downloads = []
    def download(paper_id, folder):
        downloads.append(paper_id)
        return create_pdf(folder)
    run_dir = tmp_path / "run"
    executor = LiveArxivRagExecutor(run_dir, tmp_path / "storage", rag_mode="lexical", search=make_search(), download=download)
    result = executor.execute(request(), group_ids={"g1"}, deadline=time.monotonic() + 30)
    assert result["evidence"]
    item = result["evidence"][0]
    assert item["locator"]["page"] == 1 and item["locator"]["bbox"]
    assert item["retrieval"]["lexical_used"] is True
    assert item["retrieval"]["vector_used"] is False
    second = LiveArxivRagExecutor(tmp_path / "second", tmp_path / "storage", rag_mode="lexical", search=make_search(),
                                 download=lambda *_: pytest.fail("cache should reuse download"),
                                 parse=lambda *_: pytest.fail("cache should reuse parsed PDF"))
    cached = second.execute(request(), group_ids={"g1"}, deadline=time.monotonic() + 30)
    assert any(x.get("cache_reused") is True for x in cached["observations"])
    artifacts = ArtifactDirectory(run_dir / "artifacts")
    evidence_id = artifacts.put("approved-evidence", {**result, "evidence": [dict(item, review_status="approved")]})["artifact_id"]
    artifacts.put("final-result", {"status": "partial", "direct_answer": "Evidence [1]", "artifact_refs": {"approved": evidence_id}})
    export_run_report(run_dir)
    assert (run_dir / "source-1.html").exists()
    assert "border:3px" in (run_dir / "source-1.html").read_text(encoding="utf-8")
    assert (run_dir / "pages" / "evidence-1.png").exists()
    assert 'href="source-1.html"' in (run_dir / "final_answer.html").read_text(encoding="utf-8")
    assert downloads == ["2309.06180"]


def test_full_six_agent_live_adapters_with_local_pdf_not_whole_document(tmp_path, monkeypatch):
    monkeypatch.setenv("MODEL_REQUEST_URL", "https://example.test/v1/chat/completions")
    roles = []
    def post(url, **kwargs):
        packet = json.loads(kwargs["json"]["messages"][1]["content"])
        role = packet["role"]
        roles.append(role)
        payloads = [x["payload"] for x in packet["inputs"]]
        if role == "planner":
            output = {'groups': [{'id': 'g1', 'kind': 'research', 'question_quote': 'PagedAttention',
                'question': 'PagedAttention', 'queries': ['PagedAttention throughput'],
                'core': ['PagedAttention'], 'support': [], 'metrics': ['latency'],
                'evidence_needs': [{'entity': 'PagedAttention', 'question_quote': 'PagedAttention', 'aspect': 'mechanism', 'source_title': ''}]}]}
            output.update(user_requirements=[{'id':'u1','question_quote':'PagedAttention速度？','answer_kind':'mechanism',
                'research_group_ids':['g1'],'report_obligation_ids':[]}], segment_dispositions={'s1':['u1']})
        elif role == "retriever":
            return Response({"output": {"schema_version": ROLE_OUTPUT_SCHEMAS[role], "action_count": 1}, "tool_requests": request()})
        elif role == "reviewer":
            records = next(p["evidence"] for p in payloads if "evidence" in p)
            ids = [r["evidence_id"] for r in records]
            assert all(r.get("locator", {}).get("page") == 1 for r in records)
            output = {"coverage_status": "partial", "allowed_evidence_ids": ids, "conflicts": [],
                "decisions": [{"evidence_id": key, "decision": "approved", "reason_code": "SUPPORTED",
                               "detail": "Selected page supports the memory-management mechanism.", "group_ids": ["g1"],
                               "task_relevance": "direct_task_evidence"} for key in ids], "coverage": [
                {"group_id": "g1", "metric": "latency", "status": "not_reported", "evidence_ids": ids}]}
        elif role == "writer":
            records = next(p["evidence"] for p in payloads if "evidence" in p)
            assert "pdf_path" not in json.dumps(packet)
            assert records[0]["review_status"] == "approved"
            job = next(p for p in payloads if p.get('schema_version') == 'sciassistant.writer-job/v1')
            claims = [{"claim_id": f"c{i+1}", "claim_type": "technical", "assertion_mode": "reported_fact", "section": s['role'],
                'report_section_id': s['section_id'], 'requirement_ids': s['requirement_ids'], 'group_id': 'g1',
                "text": "PagedAttention通过降低内存碎片改善吞吐量。", "evidence_ids": [records[0]["evidence_id"]],
                "scope_note": "仅据本次单页材料。", "qualification": "单页测试材料"} for i,s in enumerate(job['sections'])]
            output = {"direct_answer": "有限结论", "claims": claims, 'requirement_results': [
                {'requirement_id': rid, 'status': 'answered', 'reason': '受控响应',
                    'claim_ids': [c['claim_id'] for c in claims if rid in c['requirement_ids']]}
                for rid in job['requirement_ids']]}
        else:
            audit_input = next(p for p in payloads if 'audit_jobs' in p)
            assert 'claims' not in audit_input and 'source_witness_options' not in audit_input
            assert audit_input['comparison_context_policy'] == 'printed-table-observations-and-cross-claim-context/v1'
            assert len(audit_input['report_assertions']) == len(audit_input['audit_jobs'])
            assert audit_input['comparison_observations']['semantic_auto_approval'] is False
            claims = [{**j['claim'], **j['claim']['report_fields']} for j in audit_input['audit_jobs']]
            report_review = typed_report_review_fixture(audit_input)
            output = {"status": "passed", "report_review":report_review, "rejected_claim_ids": [], "issues": [], "claim_results": [
                {"claim_id": c["claim_id"], "decision": "approved", "reason_code": "SUPPORTED",
                 "detail": "The selected excerpt supports the scoped mechanism.", "evidence_ids": c["evidence_ids"],
                 "field_results": {field: {"status": "supported" if c.get(field, "").strip() else "not_applicable",
                     "detail": "The scoped field is checked against the selected excerpt.", "absence_checks": []}
                     for field in ("text", "scope_note", "qualification")},
                 "source_witnesses": [{"evidence_id": c["evidence_ids"][0],
                     "quote": "PagedAttention improves throughput by reducing memory fragmentation."}],
                 "scope_checks": {"family_scope": "not_applicable", "comparison_design": "supported",
                                  "task_scope": "supported", "metric_semantics": "not_applicable"}} for c in claims]}
        return Response({"output": {"schema_version": ROLE_OUTPUT_SCHEMAS[role], **output}})
    client = LiveModelClient(config(), post=post)
    executor = LiveArxivRagExecutor(tmp_path, tmp_path / "storage", rag_mode="lexical", search=make_search(),
                                    download=lambda _paper, folder: create_pdf(folder))
    store = WorkflowStore(tmp_path / "workflow.sqlite3")
    flow = LiteraturePipelineV2(store, ArtifactDirectory(tmp_path / "artifacts"), client.agents(), executor,
                                event_path=tmp_path / "events.jsonl", configuration_fingerprint=client.fingerprint)
    result = flow.run("live-fixture", "owner", "PagedAttention速度？")
    assert result["run"]["status"] == "partial", result
    assert roles == ["planner", "retriever", "reviewer", "writer", "citation_auditor"]
    assert result["run"]["model_calls_used"] == 5 and "[1]" in result["direct_answer"]
    export_run_report(tmp_path)
    assert (tmp_path / "source-1.html").is_file()


def test_cli_parent_deadline_stops_process_and_persists_terminal(tmp_path):
    root = Path(__file__).resolve().parents[1]
    env = {**os.environ, "MODEL_REQUEST_URL": "http://127.0.0.1:1/model", "MODEL_REQUEST_TOKEN": "test-only",
           "MODEL_REQUEST_TOKENS": "test-only", "MODEL_KEY_POOL_STATE_PATH": str(tmp_path / "key_pool.sqlite3")}
    result = subprocess.run([sys.executable, str(root / "tools/multi_agent_cli.py"), "run", "--mode", "live",
        "--query", "test", "--run-id", "timeout-fixture", "--output-root", str(tmp_path / "runs"),
        "--storage-root", str(tmp_path / "storage"), "--rag-mode", "lexical", "--time-budget", "1", "--time-policy", "hard-deadline/v1"],
        cwd=root, env=env, capture_output=True, text=True, timeout=15)
    assert result.returncode in {1, 2}, result.stdout
    folder = tmp_path / "runs" / "timeout-fixture"
    state = WorkflowStore(folder / "workflow.sqlite3").get_run("timeout-fixture")
    assert state["status"] in {"failed", "timed_out"}
    assert (folder / "final_answer.md").is_file()
    if (folder / "process_cleanup.json").exists():
        cleanup = json.loads((folder / "process_cleanup.json").read_text())
        assert cleanup["parent_stopped"] is True
