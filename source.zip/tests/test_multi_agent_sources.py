"""Source routing is explicit, bounded, private and independently replayable."""
import io
import json
import subprocess
import sys
import time
from dataclasses import replace
from pathlib import Path

import pytest
from requests import ConnectionError

import app as account
import web_app as web
from multi_agent_agents import AgentWorker, ArtifactDirectory
from multi_agent_pipeline_v2 import DeterministicLiteratureExecutor, LiteraturePipelineV2
from multi_agent_sources import AutoSourceExecutor, MIXED_SCOPE, SEARCH_ACTION, source_options
from multi_agent_workflow import WorkflowError, WorkflowStore
from test_multi_agent_local_pdf import pdf, gateway, headers
from tools.multi_agent_cli import _mock_agents

ROOT = Path(__file__).resolve().parents[1]


def plan():
    return {"groups": [{"id": "g1", "question": "PagedAttention memory",
        "queries": ["PagedAttention memory", "PagedAttention throughput"]}]}


def action(source="uploaded_pdf", query="PagedAttention memory", **extra):
    return {"request_id": "r1", "action": SEARCH_ACTION,
        "arguments": {"group_id": "g1", "query": query, "source": source, **extra}}


def public_search(query, _limit):
    return {"status": "ok", "papers": [{"paper_id": "2309.06180", "title": "Public PagedAttention evidence",
        "abstract": "Public evidence of PagedAttention throughput at matched latency."}]}


def executor(pdf, tmp_path, **options):
    result = AutoSourceExecutor(tmp_path / "run", pdf, allow_public=True, rag_mode="lexical", **options)
    result.configure_plan(plan())
    return result


@pytest.mark.parametrize("has_pdf,policy,allow,code", [
    (True, "auto", False, "PUBLIC_SEARCH_PERMISSION_REQUIRED"),
    (True, "local", True, "PUBLIC_SEARCH_PERMISSION_REQUIRES_AUTO"),
    (False, "auto", True, "SOURCE_POLICY_REQUIRES_PDF"),
    (False, "local", False, "SOURCE_POLICY_REQUIRES_PDF"),
    (True, "public", False, "UPLOADED_PDF_CANNOT_BE_IGNORED"),
    (True, [], False, "INVALID_SOURCE_POLICY"),
    (True, "", False, "INVALID_SOURCE_POLICY"),
    (True, "auto", "true", "INVALID_PUBLIC_SEARCH_PERMISSION"),
])
def test_source_permission_rejected(has_pdf, policy, allow, code):
    with pytest.raises(ValueError, match=code):
        source_options(has_pdf=has_pdf, policy=policy, allow_public=allow)


def test_old_defaults_are_unchanged():
    assert source_options(has_pdf=True)["source_scope"] == "uploaded_pdf"
    assert source_options(has_pdf=False)["source_scope"] == "arxiv"
    assert source_options(has_pdf=True, policy="auto", allow_public=True)["source_scope"] == MIXED_SCOPE


def test_auto_prompt_has_complete_tool_envelope_and_invalid_fields_stay_rejected(tmp_path):
    from multi_agent_live import effective_role_prompt
    from multi_agent_agents import AgentContractError, make_agent_input
    prompt = effective_role_prompt("retriever", mixed_source=True)
    example = json.JSONDecoder().raw_decode(prompt.split("Exact complete envelope example (substitute real plan group and query): ")[1])[0]
    worker = AgentWorker("retriever", lambda _packet: example, [SEARCH_ACTION])
    packet = make_agent_input(run_id="contract-example", role="retriever", goal="检查本文",
        input_artifact_ids=[], remaining_model_calls=9, deadline_at=time.time() + 40)
    artifacts = ArtifactDirectory(tmp_path / "artifacts")
    result = worker.run(packet, artifacts)
    assert result["status"] == "completed" and result["tool_requests"][0]["request_id"] == "r1"
    del example["tool_requests"][0]["request_id"]
    with pytest.raises(AgentContractError, match="invalid tool request fields"):
        worker.run(packet, artifacts)


@pytest.mark.parametrize("question", ["请仅依据上传 PDF 回答", "解释本文，不要联网", "use only this PDF", "Do not search external sources"])
def test_explicit_document_only_overrides_auto_permission(question):
    options = source_options(has_pdf=True, policy="auto", allow_public=True, question=question)
    assert options["source_policy"] == "local" and options["public_search_allowed"] is False
    assert options["source_policy_reason"] == "USER_DOCUMENT_ONLY"


def test_auto_requires_consent_before_creating_storage(pdf, tmp_path):
    with pytest.raises(ValueError, match="PUBLIC_SEARCH_PERMISSION_REQUIRED"):
        AutoSourceExecutor(tmp_path / "run", pdf, rag_mode="lexical")
    assert not (tmp_path / "run").exists()


def test_local_only_choice_never_constructs_public_executor(pdf, tmp_path):
    tool = executor(pdf, tmp_path, public_factory=lambda: pytest.fail("must not initialize public search"))
    result = tool.execute([action()], group_ids={"g1"}, deadline=time.monotonic() + 30)
    assert result["evidence"] and all(row["source"] == "uploaded_pdf" for row in result["evidence"])
    assert tool.public is None and tool.pdf_reads == 1
    assert tool.routing_summary()["routes"][-1]["public_actions"] == 0


def test_public_choice_still_reads_local_first(pdf, tmp_path):
    sequence = []
    def search(query, limit):
        sequence.append("public")
        assert tool.local.ingested
        return public_search(query, limit)
    tool = executor(pdf, tmp_path, public_factory=lambda: DeterministicLiteratureExecutor(search))
    result = tool.execute([action("arxiv", "PagedAttention throughput")], group_ids={"g1"},
                          deadline=time.monotonic() + 30)
    assert {row["source"] for row in result["evidence"]} == {"uploaded_pdf", "arxiv"}
    assert sequence == ["public"]
    assert tool.routes[-1]["local_actions"] == 1 and tool.routes[-1]["public_actions"] == 1
    assert all(row["official_url"] == "" for row in result["evidence"] if row["source"] == "uploaded_pdf")


@pytest.mark.parametrize("bad", ["path", "group", "source", "query", "count", "duplicate", "action"])
def test_illegal_source_action_rejected_before_parse_or_network(pdf, tmp_path, bad):
    tool = executor(pdf, tmp_path, parse=lambda _: pytest.fail("must validate before parse"),
        public_factory=lambda: pytest.fail("must validate before network"))
    request = action()
    requests = [request]
    if bad == "path": request["arguments"]["path"] = "another-user.pdf"
    if bad == "group": request["arguments"]["group_id"] = "not-planned"
    if bad == "source": request["arguments"]["source"] = "https://attacker.test"
    if bad == "query": request["arguments"].update(source="arxiv", query="PRIVATE_DOCUMENT_SENTINEL")
    if bad == "count": requests *= 7
    if bad == "duplicate": requests *= 2
    if bad == "action": request["action"] = "request_arxiv_search"
    with pytest.raises(WorkflowError):
        tool.execute(requests, group_ids={"g1"}, deadline=time.monotonic() + 30)


def test_gap_can_use_unused_public_plan_query_without_reparsing(pdf, tmp_path):
    tool = executor(pdf, tmp_path, public_factory=lambda: DeterministicLiteratureExecutor(public_search))
    tool.execute([action()], group_ids={"g1"}, deadline=time.monotonic() + 30)
    tool.local.parse = lambda _: pytest.fail("recovery must reuse original index")
    result = tool.execute([action("arxiv", "PagedAttention throughput", gap_id="latency-gap")],
        recovery=True, group_ids={"g1"}, deadline=time.monotonic() + 15)
    assert tool.pdf_reads == 1 and {row["source"] for row in result["evidence"]} == {"uploaded_pdf", "arxiv"}
    assert tool.routes[-1]["recovery"] is True


def test_network_failure_keeps_uploaded_evidence_and_safe_error(pdf, tmp_path):
    def fail(*_):
        raise ConnectionError("PRIVATE_PATH /home/private/token-secret")
    tool = executor(pdf, tmp_path, public_factory=lambda: DeterministicLiteratureExecutor(fail))
    result = tool.execute([action("arxiv", "PagedAttention throughput")], group_ids={"g1"}, deadline=time.monotonic() + 30)
    assert result["evidence"] and all(row["source"] == "uploaded_pdf" for row in result["evidence"])
    assert any(row.get("reason_code") == "EXTERNAL_SOURCE_UNAVAILABLE" for row in result["observations"])
    assert "PRIVATE_PATH" not in json.dumps(result)


def test_external_store_uses_private_vector_and_keyword_store(pdf, tmp_path, monkeypatch):
    monkeypatch.setenv("SCIASSISTANT_QDRANT_URL", "https://do-not-connect.test")
    tool = executor(pdf, tmp_path)
    public = tool._public_executor()
    assert public.services is tool.local.services
    assert public.evidence_store is tool.local.evidence_store
    assert public.storage_root.is_relative_to(tool.local.storage_root)
    assert public.indexer.evidence_store is tool.local.indexer.evidence_store


def test_source_quota_does_not_crowd_out_uploaded_passages(pdf, tmp_path):
    tool = executor(pdf, tmp_path)
    tool.local_snapshot = {"evidence": [{"evidence_id": f"local-{i}", "source": "uploaded_pdf"} for i in range(12)]}
    tool.public_snapshot = {"evidence": [{"evidence_id": f"public-{i}", "source": "arxiv"} for i in range(12)]}
    rows = tool._snapshot()["evidence"]
    assert len(rows) == 12 and sum(row["source"] == "uploaded_pdf" for row in rows) == 6


def test_real_public_fixture_index_is_searchable_and_not_shared(pdf, tmp_path):
    from multi_agent_live import LiveArxivRagExecutor
    import fitz
    tool = executor(pdf, tmp_path)
    def download(paper_id, folder):
        target = folder / "source.pdf"
        with fitz.open() as document:
            page = document.new_page()
            page.insert_text((50, 70), "PUBLIC fixture: PagedAttention throughput under matching latency.")
            document.save(target)
        return target
    tool.public_factory = lambda: LiveArxivRagExecutor(tool.run_dir, tool.local.storage_root / "external",
        rag_mode="lexical", services=tool.services, evidence_store=tool.local.evidence_store,
        search=lambda *a, **k: public_search(a[1], 5), download=download,
        parse=lambda _: {"success": True, "pages": [{"page": 1,
            "text": "PUBLIC fixture PagedAttention throughput under matching latency."}]})
    result = tool.execute([action("arxiv", "PagedAttention throughput")], group_ids={"g1"}, deadline=time.monotonic() + 30)
    public = [row for row in result["evidence"] if row["source"] == "arxiv"]
    assert public and "PUBLIC fixture" in public[0]["excerpt"]
    assert (tool.run_dir / "pdf" / public[0]["document_id"] / "source.pdf").is_file()
    assert tool.reading_summary()["papers_indexed"] == 2 and tool.pdf_reads == 2
    assert tool.public.services.evidence_store is tool.local.services.evidence_store


def test_network_failure_still_runs_writer_and_auditor(pdf, tmp_path):
    def fail(*_):
        raise ConnectionError("private provider detail")
    run = tmp_path / "run"
    tool = AutoSourceExecutor(run, pdf, allow_public=True, rag_mode="lexical",
        public_factory=lambda: DeterministicLiteratureExecutor(fail))
    result = LiteraturePipelineV2(WorkflowStore(run / "workflow.sqlite3"), ArtifactDirectory(run / "artifacts"),
        _mock_agents(source_scope=MIXED_SCOPE), tool, event_path=run / "events.jsonl").run(
        "auto-network-failure", "test-user", "compare bounded scientific evidence")
    assert result["run"]["status"] == "partial" and result["run"]["model_calls_used"] == 5
    events = [json.loads(row) for row in (run / "events.jsonl").read_text(encoding="utf8").splitlines()]
    assert [row["role"] for row in events if row["event"] == "agent_started"][-2:] == ["writer", "citation_auditor"]


@pytest.mark.parametrize("problem", ["unplanned_public_query", "repeated_initial_actions", "group_type", "gap_type", "query_type", "duplicate_ids"])
def test_invalid_recovery_preserves_approved_evidence_without_tool_execution(pdf, tmp_path, problem):
    original = _mock_agents(source_scope=MIXED_SCOPE)
    def reviewer(packet):
        raw = original.reviewer.handler(packet)
        raw["output"]["coverage"].append({"gap_id": "definition-gap", "group_id": "group-1", "metric": "definition",
            "status": "missing", "evidence_ids": [], "recommended_action": "targeted_search"})
        return raw
    def retriever(packet):
        if not any("gaps" in item["payload"] for item in packet["inputs"]):
            return original.retriever.handler(packet)
        row = {"request_id": "gap-1", "action": SEARCH_ACTION, "arguments": {
            "gap_id": "definition-gap", "group_id": "group-1", "query": "PRIVATE_GAP_SENTINEL",
            "source": "arxiv"}}
        if problem == "group_type": row["arguments"]["group_id"] = ["group-1"]
        if problem == "gap_type": row["arguments"]["gap_id"] = ["definition-gap"]
        if problem == "query_type": row["arguments"]["query"] = {"query": "PRIVATE_GAP_SENTINEL"}
        return {"tool_requests": [dict(row, request_id=f"gap-{n}") for n in range(3)]
            if problem == "repeated_initial_actions" else [row, row] if problem == "duplicate_ids" else [row]}
    workers = replace(original, reviewer=AgentWorker("reviewer", reviewer, ["review_evidence"]),
        gap_analyst=AgentWorker("gap_analyst", lambda _packet: {"output": {"gaps": [{"gap_id": "definition-gap",
            "group_id": "group-1", "metric": "definition", "query": "PRIVATE_GAP_SENTINEL"}]}}, ["create_gap_search_plan"]),
        retriever=AgentWorker("retriever", retriever, [SEARCH_ACTION]))
    run = tmp_path / "run"
    tool = AutoSourceExecutor(run, pdf, allow_public=True, rag_mode="lexical",
        public_factory=lambda: pytest.fail("rejected recovery cannot initialize public search"))
    artifacts = ArtifactDirectory(run / "artifacts")
    result = LiteraturePipelineV2(WorkflowStore(run / "workflow.sqlite3"), artifacts, workers,
        tool, event_path=run / "events.jsonl").run("invalid-source-recovery", "owner", "bounded scientific evidence")
    assert result["run"]["status"] == "needs_review" and result["run"]["model_calls_used"] == 7
    final = artifacts.get(result["final_artifact_id"])
    assert final["direct_answer"] and tool.public is None and len(tool.routes) == 1
    events = [json.loads(row) for row in (run / "events.jsonl").read_text(encoding="utf8").splitlines()]
    assert [row["role"] for row in events if row["event"] == "agent_started"][-2:] == ["writer", "citation_auditor"]
    assert any(row["event"] == "source_recovery_rejected" and row["retained_approved_evidence_count"] > 0 for row in events)


@pytest.mark.parametrize("problem", ["extra_group", "wrong_metric", "wrong_gap_id", "empty", "too_many", "format_error"])
def test_gap_plan_rejected_before_retriever_preserves_writer_auditor(pdf, tmp_path, problem):
    original = _mock_agents(source_scope=MIXED_SCOPE)
    approvals, writer_ids, targets_seen = [], [], []
    def reviewer(packet):
        raw = original.reviewer.handler(packet)
        approvals.extend(raw["output"]["allowed_evidence_ids"])
        raw["output"]["coverage"].append({"gap_id": "definition-gap", "group_id": "group-1", "metric": "definition",
            "status": "missing", "evidence_ids": [], "recommended_action": "targeted_search"})
        return raw
    def gap(packet):
        targets_seen.append(next(row["payload"] for row in packet["inputs"]
            if row["payload"].get("schema_version") == "sciassistant.gap-targets/v1"))
        if problem == "format_error":
            return {"status": "failed", "error_code": "MODEL_JSON_INVALID"}
        rows = [{"gap_id": "definition-gap", "group_id": "group-1", "metric": "definition", "query": "targeted new local query"}]
        if problem == "extra_group": rows.append({**rows[0], "gap_id": "extra-gap", "group_id": "unrequested-group"})
        if problem == "wrong_metric": rows[0]["metric"] = "unrequested metric"
        if problem == "wrong_gap_id": rows[0]["gap_id"] = "unrequested-gap"
        if problem == "empty": rows = []
        if problem == "too_many": rows *= 3
        return {"output": {"gaps": rows}}
    def retriever(packet):
        assert not any("gaps" in row["payload"] for row in packet["inputs"]), "invalid plan must not reach recovery retriever"
        return original.retriever.handler(packet)
    def writer(packet):
        writer_ids.extend(row["evidence_id"] for payload in packet["inputs"]
            for row in payload["payload"].get("evidence", []))
        return original.writer.handler(packet)
    workers = replace(original, reviewer=AgentWorker("reviewer", reviewer, ["review_evidence"]),
        gap_analyst=AgentWorker("gap_analyst", gap, ["create_gap_search_plan"]),
        retriever=AgentWorker("retriever", retriever, [SEARCH_ACTION]),
        writer=AgentWorker("writer", writer, ["write_approved_claims"]))
    run = tmp_path / "run"
    tool = AutoSourceExecutor(run, pdf, allow_public=True, rag_mode="lexical",
        public_factory=lambda: pytest.fail("rejected plan must not initialize external tools"))
    artifacts = ArtifactDirectory(run / "artifacts")
    result = LiteraturePipelineV2(WorkflowStore(run / "workflow.sqlite3"), artifacts, workers,
        tool, event_path=run / "events.jsonl").run("gap-plan-rejection", "owner", "bounded scientific evidence")
    assert result["run"]["status"] == "needs_review" and result["run"]["failure_code"] is None
    assert result["run"]["model_calls_used"] == 6
    assert set(writer_ids) == set(approvals) and writer_ids
    assert result["direct_answer"] and tool.public is None and len(tool.routes) == 1
    assert targets_seen[0]["targets"] == [{"gap_id": "definition-gap", "group_id": "group-1", "metric": "definition"}]
    events = [json.loads(row) for row in (run / "events.jsonl").read_text(encoding="utf8").splitlines()]
    assert [row["role"] for row in events if row["event"] == "agent_started"] == [
        "planner", "retriever", "reviewer", "gap_analyst", "writer", "citation_auditor"]
    assert any(row["event"] == "gap_plan_rejected" and row["retained_approved_evidence_count"] == len(approvals) for row in events)


def test_recovery_progress_keeps_latest_query_and_source(pdf, tmp_path):
    tool = executor(pdf, tmp_path, public_factory=lambda: DeterministicLiteratureExecutor(public_search))
    tool.execute([action()], group_ids={"g1"}, deadline=time.monotonic() + 30)
    snapshots = []
    tool.execute([action("arxiv", "PagedAttention throughput", gap_id="gap")], recovery=True,
        group_ids={"g1"}, deadline=time.monotonic() + 30, progress=snapshots.append)
    query_events = [row["observations"][-1] for row in snapshots if "query" in row["observations"][-1]]
    assert query_events and query_events[-1]["source"] == "arxiv"
    assert query_events[-1]["query"] == "PagedAttention throughput"


def test_cancelled_state_is_not_swallowed_as_public_network_failure(pdf, tmp_path):
    def interrupt(*_):
        raise KeyboardInterrupt
    tool = executor(pdf, tmp_path, public_factory=lambda: DeterministicLiteratureExecutor(interrupt))
    with pytest.raises(KeyboardInterrupt):
        tool.execute([action("arxiv", "PagedAttention throughput")], group_ids={"g1"}, deadline=time.monotonic() + 30)


def test_public_deadline_skipped_without_starting_network(pdf, tmp_path):
    tool = executor(pdf, tmp_path, public_factory=lambda: pytest.fail("no network time left"))
    tool.execute([action()], group_ids={"g1"}, deadline=time.monotonic() + 30)
    result = tool.execute([action("arxiv", "PagedAttention throughput", gap_id="gap")], recovery=True,
        group_ids={"g1"}, deadline=time.monotonic() - 1)
    assert result["evidence"] and tool.public is None
    assert any(row.get("source_status") == "deadline_skipped" for row in result["observations"])


def test_planner_does_not_receive_private_previous_answer(pdf, tmp_path):
    captured = []
    original = _mock_agents(source_scope=MIXED_SCOPE)
    def planner(packet):
        captured.append(packet)
        assert "PRIVATE_CONTEXT_SENTINEL" not in json.dumps(packet)
        return original.planner.handler(packet)
    workers = replace(original, planner=AgentWorker("planner", planner, ["create_research_plan"]))
    run = tmp_path / "run"
    tool = AutoSourceExecutor(run, pdf, allow_public=True, rag_mode="lexical",
        public_factory=lambda: DeterministicLiteratureExecutor(public_search))
    context = {"schema_version": "sciassistant.followup-context/v1", "previous_question": "older question",
        "previous_answer": "PRIVATE_CONTEXT_SENTINEL", "paper_ids": [], "evidence_policy": "context_only_retrieve_again"}
    result = LiteraturePipelineV2(WorkflowStore(run / "workflow.sqlite3"), ArtifactDirectory(run / "artifacts"),
        workers, tool).run("auto-context", "test-user", "bounded scientific evidence", conversation_context=context)
    assert captured and result["run"]["status"] == "partial"
    assert result["run"]["model_calls_used"] == 5
    assert tool.public is None


@pytest.mark.parametrize("question,expect_public", [("bounded scientific evidence", False), ("compare bounded scientific evidence", True)])
def test_cli_real_pdf_mock_auto_inspect_replay(pdf, tmp_path, question, expect_public):
    run = tmp_path / "runs" / "auto-demo"
    command = [sys.executable, str(ROOT / "tools/multi_agent_cli.py"), "run", "--mode", "mock",
        "--pdf", str(pdf), "--source-policy", "auto", "--allow-public-search", "--query", question,
        "--output-root", str(run.parent), "--run-id", run.name]
    result = subprocess.run(command, cwd=ROOT, text=True, encoding="utf8", capture_output=True, timeout=45)
    assert result.returncode == 0, result.stdout + result.stderr
    manifest = json.loads((run / "manifest.json").read_text(encoding="utf8"))
    assert manifest["source_scope"] == MIXED_SCOPE and manifest["source_policy"] == "auto"
    assert manifest["source_routing"]["routes"][-1]["public_actions"] == int(expect_public)
    report = (run / "final_answer.md").read_bytes()
    for cmd in ("inspect", "replay"):
        output = subprocess.run([sys.executable, str(ROOT / "tools/multi_agent_cli.py"), cmd, "--run-dir", str(run)],
            cwd=ROOT, text=True, encoding="utf8", capture_output=True, timeout=30)
        assert output.returncode == 0, output.stdout + output.stderr
    assert (run / "final_answer.md").read_bytes() == report


@pytest.mark.parametrize("fields,code", [
    ({"source_policy": "auto"}, "PUBLIC_SEARCH_PERMISSION_REQUIRED"),
    ({"source_policy": "local", "allow_public_search": "true"}, "PUBLIC_SEARCH_PERMISSION_REQUIRES_AUTO"),
    ({"source_policy": "bad"}, "INVALID_SOURCE_POLICY"),
])
def test_gateway_rejects_bad_source_options_before_task_creation(gateway, pdf, fields, code):
    result = account.app.test_client().post("/api/science/tasks", headers=headers(), data={
        "query": "explain paper", "processing_mode": "multi_agent_pdf", **fields,
        "pdf": (io.BytesIO(pdf.read_bytes()), "source.pdf")})
    assert result.status_code == 400 and result.json["error"] == code
    assert not web.TASKS


def test_gateway_auto_consent_persisted_but_not_inherited_by_followup(gateway, pdf):
    client = account.app.test_client()
    result = client.post("/api/science/tasks", headers=headers(), data={"query": "compare public findings",
        "processing_mode": "multi_agent_rag", "conversation_id": "chat-a", "source_policy": "auto",
        "allow_public_search": "true", "pdf": (io.BytesIO(pdf.read_bytes()), "source.pdf")})
    assert result.status_code == 202, result.json
    task = result.json["task"]
    assert task["source_scope"] == MIXED_SCOPE and task["public_search_allowed"] is True
    snapshot = json.loads((web.TASK_STATE_DIR / (task["id"] + ".json")).read_text(encoding="utf8"))
    assert snapshot["source_policy"] == "auto" and snapshot["public_search_allowed"] is True
    follow = client.post("/api/science/tasks", headers=headers(), json={"query": "explain this PDF",
        "processing_mode": "multi_agent_pdf", "conversation_id": "chat-a", "pdf_source_task_id": task["id"]})
    assert follow.status_code == 202 and follow.json["task"]["public_search_allowed"] is False
    assert follow.json["task"]["source_scope"] == "uploaded_pdf"
    forged = client.post("/api/science/tasks", headers=headers("bob"), json={"query": "test",
        "processing_mode": "multi_agent_pdf", "conversation_id": "chat-b", "pdf_source_task_id": task["id"],
        "source_policy": "auto", "allow_public_search": True})
    assert forged.status_code == 404


def test_auto_command_and_prompt_boundary(pdf, tmp_path):
    from types import SimpleNamespace
    from multi_agent_live import LiveModelClient, effective_role_prompt
    from multi_agent_web import command
    config = SimpleNamespace(model_name="test", get_custom_llm_config=lambda: {"url": "https://example.test/v1/chat/completions"})
    client = LiveModelClient(config)
    assert client.agents(source_scope=MIXED_SCOPE).retriever.allowed_actions == [SEARCH_ACTION]
    assert "exactly copy" in effective_role_prompt("retriever", mixed_source=True)
    assert 'ti:"LoRA: Low-Rank Adaptation of Large Language Models"' in effective_role_prompt("planner", mixed_source=True)
    assert "ORIGINAL paper" not in effective_role_prompt("planner", local_source=True)
    args = command("abcdefabcdef", tmp_path / "q.txt", pdf=pdf, source_policy="auto", allow_public_search=True)
    assert "--source-policy" in args and "--allow-public-search" in args
    with pytest.raises(ValueError, match="PUBLIC_SEARCH_PERMISSION_REQUIRED"):
        command("abcdefabcdef", tmp_path / "q.txt", pdf=pdf, source_policy="auto")


def test_source_module_in_fingerprint_and_both_containers():
    from runtime_identity import IDENTITY_FILES
    assert "multi_agent_sources.py" in IDENTITY_FILES
    for name in ("Dockerfile.cloud", "Dockerfile.account.cloud"):
        assert "COPY multi_agent_sources.py /app/" in (ROOT / name).read_text(encoding="utf8")
        assert "!multi_agent_sources.py" in (ROOT / (name + ".dockerignore")).read_text(encoding="utf8")


def test_public_state_can_be_isolated_from_running_service(tmp_path):
    import os
    env = {**os.environ, "SCIASSISTANT_LITERATURE_STATE_PATH": str(tmp_path / "state.sqlite3"),
        "SCIASSISTANT_LITERATURE_CACHE_DIR": str(tmp_path / "cache")}
    script = "import os; from pathlib import Path; from deepdiver_v2.src import literature_sources as s; assert s.STATE_DB == Path(os.environ['SCIASSISTANT_LITERATURE_STATE_PATH']); assert s.CACHE_DIR == Path(os.environ['SCIASSISTANT_LITERATURE_CACHE_DIR']); print('isolated')"
    result = subprocess.run([sys.executable, "-c", script], cwd=ROOT, env=env, text=True, capture_output=True, timeout=20)
    assert result.returncode == 0 and result.stdout.strip() == "isolated"
