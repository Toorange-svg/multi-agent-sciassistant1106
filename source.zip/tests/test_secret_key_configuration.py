"""JWT signing-key startup policy regression coverage."""
import os
from unittest import TestCase, mock

import app as account_app


class SecretKeyConfigurationTests(TestCase):
    def test_production_rejects_missing_secret_key(self):
        with mock.patch.dict(os.environ, {"APP_ENV": "production"}, clear=True):
            with self.assertRaisesRegex(RuntimeError, "SECRET_KEY"):
                account_app._configured_secret_key()

    def test_production_rejects_documented_placeholder(self):
        values = {"APP_ENV": "production", "SECRET_KEY": "change-me"}
        with mock.patch.dict(os.environ, values, clear=True):
            with self.assertRaisesRegex(RuntimeError, "示例值"):
                account_app._configured_secret_key()

    def test_production_accepts_explicit_stable_secret(self):
        values = {"APP_ENV": "production", "SECRET_KEY": "stable-test-signing-key"}
        with mock.patch.dict(os.environ, values, clear=True):
            self.assertEqual(account_app._configured_secret_key(), "stable-test-signing-key")

    def test_development_keeps_explicit_placeholder_for_local_compatibility(self):
        values = {"APP_ENV": "development", "SECRET_KEY": "change-me"}
        with mock.patch.dict(os.environ, values, clear=True):
            self.assertEqual(account_app._configured_secret_key(), "change-me")


if __name__ == "__main__":
    import unittest

    unittest.main()
