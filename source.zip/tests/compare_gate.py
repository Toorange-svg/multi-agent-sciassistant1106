"""Offline regression fixtures for the literature relevance gate.

This suite is deliberately offline and deterministic: it exercises
``score_literature_relevance`` against fixed (question, paper) pairs so a
change to the gate can be judged by measured behaviour instead of by reading
a diff or reasoning from a single example.

Run directly::

    venv\\Scripts\\python.exe tests\\compare_gate.py

Every fixture records the question, the candidate paper, the expected
accept/reject verdict, and the score band the verdict should fall in. A
fixture whose behaviour is not yet decided uses ``expected_verdict=None`` and
is reported as *unjudged* rather than silently passing.

``--baseline`` compares the working copy against the committed ``HEAD``
version of ``query_router.py`` and reports every fixture whose verdict
differs, which is how a change is shown to be an improvement rather than a
regression.
"""
from __future__ import annotations

import argparse
import importlib.util
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from deepdiver_v2.src.query_router import score_literature_relevance  # noqa: E402


@dataclass
class Fixture:
    """One judged (question, candidate paper) pair."""

    query: str
    paper_id: str
    paper_title: str
    paper_abstract: str
    # None means "behaviour not yet decided"; such a fixture is reported as
    # unjudged so an undecided case can never be mistaken for a pass.
    expected_verdict: bool | None
    # Inclusive (low, high) band the gate's score should fall in.
    expected_score_range: tuple[float, float] = (0.0, 1.0)
    # The scoring_status the bridge must report. A purely Chinese question
    # carries no English terminology, so the gate can only degrade: expecting
    # it to accept would assert behaviour the bridge deliberately refuses to
    # fake. Such a fixture is judged on ``degraded`` plus an explicit
    # unresolved-term report, not on the verdict.
    expected_scoring_status: str | None = None
    note: str = ""
    tags: tuple[str, ...] = field(default_factory=tuple)


# --------------------------------------------------------------------------
# Fixture set.
#
# Every entry records the question, the candidate paper, the expected verdict
# and the score band that verdict should fall in. Tags carry the reason a
# fixture exists so a failure can be attributed without re-reading the suite.
#
# Verdict values:
#   True      the gate must accept
#   False     the gate must reject
#   None      behaviour not yet decided -> reported as unjudged, never a pass
# --------------------------------------------------------------------------
FIXTURES = [
    # ----------------------------------------------------------------------
    # Judged relevant: a paper that must be usable as evidence.
    # ----------------------------------------------------------------------
    Fixture(
        query="What are the key challenges of retrieval augmented generation?",
        paper_id="hal-5018800",
        paper_title="Unifying Retrieval and Generation: A Survey on RAG in NLP",
        paper_abstract=(
            "This survey covers retrieval augmented generation in natural "
            "language processing."
        ),
        expected_verdict=True,
        expected_score_range=(0.35, 1.0),
        note="a RAG survey must be usable for a RAG challenges question",
        tags=("english", "relevant"),
    ),
    Fixture(
        query="Explain the limitations of the Transformer architecture",
        paper_id="2306.02896",
        paper_title="On Limitation of Transformer for Learning HMMs",
        paper_abstract=(
            "We study limitations of Transformer for learning hidden Markov "
            "models."
        ),
        expected_verdict=True,
        expected_score_range=(0.35, 1.0),
        note="direct architecture-limitation evidence",
        tags=("english", "relevant", "limitation"),
    ),
    Fixture(
        query="Representational Strengths and Limitations of Transformers",
        paper_id="2306.02897",
        paper_title="Representational Strengths and Limitations of Transformers",
        paper_abstract=(
            "We characterize the expressivity and limitations of transformers."
        ),
        expected_verdict=True,
        expected_score_range=(0.35, 1.0),
        tags=("english", "relevant", "limitation"),
    ),
    Fixture(
        query="根据 arXiv 上的文章解释 CNN 的局限性",
        paper_id="cnn-limited-data",
        paper_title="CNN feature extraction under limited data",
        paper_abstract=(
            "Conventional convolutional neural networks with local receptive "
            "fields are inadequate for extracting global features."
        ),
        expected_verdict=True,
        expected_score_range=(0.35, 1.0),
        note="Chinese question carrying an English acronym entity",
        tags=("chinese", "relevant", "limitation"),
    ),
    Fixture(
        query="How does DoRA differ from LoRA?",
        paper_id="dora-paper",
        paper_title="DoRA: Weight-Decomposed Low-Rank Adaptation",
        paper_abstract=(
            "We propose DoRA, a weight-decomposed low-rank adaptation method "
            "for fine-tuning."
        ),
        expected_verdict=False,
        # Rejected by the comparison constraint at a score above the
        # threshold, so only the verdict is asserted.
        expected_score_range=(0.0, 1.0),
        note=(
            "the abstract introduces DoRA but never names LoRA, so it cannot "
            "support a conclusion about how the two differ. A comparison "
            "requires evidence on both sides."
        ),
        tags=("comparison-needs-both-terms",),
    ),
    # ----------------------------------------------------------------------
    # Cross-domain noise: shares a surface word but is not on topic.
    # ----------------------------------------------------------------------
    Fixture(
        query="What are the key challenges of retrieval augmented generation?",
        paper_id="hal-2388103",
        paper_title="5D World-Universe Model. Space-Time-Energy",
        paper_abstract="A unified model of the universe in five dimensions.",
        expected_verdict=False,
        expected_score_range=(0.0, 0.34),
        note="cross-domain: shares only the word 'model'",
        tags=("english", "cross-domain"),
    ),
    Fixture(
        query="What are the key challenges of retrieval augmented generation?",
        paper_id="zenodo-18381336",
        paper_title="Algal diversity in coalfield areas of Talcher",
        paper_abstract="Algal diversity was surveyed in coalfield areas.",
        expected_verdict=False,
        expected_score_range=(0.0, 0.34),
        note="cross-domain noise observed in a real retrieval run",
        tags=("english", "cross-domain"),
    ),
    Fixture(
        query="What are the key challenges of retrieval augmented generation?",
        paper_id="zenodo-15782260",
        paper_title="Discrete Mathematics",
        paper_abstract=(
            "An introduction to discrete mathematics and combinatorics."
        ),
        expected_verdict=False,
        expected_score_range=(0.0, 0.34),
        note="cross-domain noise observed in a real retrieval run",
        tags=("english", "cross-domain"),
    ),
    Fixture(
        query="根据 arXiv 上的文章解释 CNN 的局限性",
        paper_id="pupilnet",
        paper_title=(
            "PupilNet v2.0: Convolutional neural network for pupil detection"
        ),
        paper_abstract=(
            "Pupil detection is challenging under illumination changes. The "
            "CNN improves detection accuracy."
        ),
        expected_verdict=False,
        # Rejection does not imply a low score: this paper clears the score
        # threshold but is refused by a coverage/limitation gate, so the band
        # stays open and the verdict alone decides.
        expected_score_range=(0.0, 1.0),
        note="a CNN application paper is not an architecture-limitation source",
        tags=("chinese", "cross-domain", "limitation"),
    ),
    # ----------------------------------------------------------------------
    # Comparison evidence: a question that compares two named objects requires
    # both names, so a paper documenting only one side is refused.
    # ----------------------------------------------------------------------
    Fixture(
        query="How does DoRA differ from LoRA?",
        paper_id="lora-paper",
        paper_title="LoRA: Low-Rank Adaptation of Large Language Models",
        paper_abstract=(
            "We propose LoRA for parameter-efficient fine-tuning of large "
            "language models."
        ),
        expected_verdict=False,
        # Refused by the comparison constraint at a score above the threshold,
        # so only the verdict is asserted.
        expected_score_range=(0.0, 1.0),
        note=(
            "the abstract names LoRA but never DoRA, so it cannot describe how "
            "the two differ"
        ),
        tags=("comparison-needs-both-terms",),
    ),
    # ----------------------------------------------------------------------
    # New this round.
    # ----------------------------------------------------------------------
    Fixture(
        query="What are the key challenges of retrieval augmented generation?",
        paper_id="hal-5180963",
        paper_title=(
            "Sparse Attention Combined with RAG Technology for Financial "
            "Data Analysis"
        ),
        paper_abstract=(
            "We combine sparse attention with RAG for financial data analysis."
        ),
        expected_verdict=True,
        expected_score_range=(0.35, 1.0),
        note=(
            "under the strong/weak split this is asked with weak vocabulary "
            "('challenges'), so an application paper in the same field counts "
            "as in scope"
        ),
        tags=("expanded-scope",),
    ),
    Fixture(
        query="What are the limitations of RAG?",
        paper_id="hal-5018801",
        paper_title="Unifying Retrieval and Generation: A Survey on RAG in NLP",
        paper_abstract=(
            "This survey covers retrieval augmented generation in natural "
            "language processing."
        ),
        expected_verdict=False,
        # Rejected by the strict limitation gate at a score above threshold,
        # so only the verdict is asserted here.
        expected_score_range=(0.0, 1.0),
        note=(
            "a survey does not document a direct architecture limitation in "
            "one sentence, so the strict same-sentence gate rejects the very "
            "paper that answers the question. The abstract is the paper's real "
            "wording: an earlier revision of this fixture added the phrase "
            "'including open problems and limitations', which made the gate "
            "pass on text the paper does not contain."
        ),
        tags=("english", "known-defect"),
    ),
    Fixture(
        query="What are the limitations of RAG?",
        paper_id="rag-limitations-paper",
        paper_title="On the Limitations of Retrieval-Augmented Generation",
        paper_abstract=(
            "We analyze the limitations of retrieval augmented generation, "
            "showing that retrieval quality and knowledge conflicts bound the "
            "achievable answer accuracy."
        ),
        expected_verdict=True,
        expected_score_range=(0.35, 1.0),
        note="a non-survey paper that states the limitation directly",
        tags=("english", "relevant"),
    ),
    Fixture(
        query="What are the challenges of Transformer?",
        paper_id="2306.02896",
        paper_title="On Limitation of Transformer for Learning HMMs",
        paper_abstract=(
            "We study limitations of Transformer for learning hidden Markov "
            "models, showing expressivity bounds."
        ),
        expected_verdict=True,
        expected_score_range=(0.35, 1.0),
        note=(
            "weak vocabulary ('challenges') must still accept a paper that "
            "addresses the topic's difficulties"
        ),
        tags=("english", "relevant"),
    ),
    # ----------------------------------------------------------------------
    # Purely Chinese questions: no ASCII terminology, so the bridge cannot
    # resolve an English concept and reports degraded. Expecting a verdict
    # here would assert a translation the bridge deliberately refuses to
    # invent; the honest expectation is the explicit degraded status.
    # ----------------------------------------------------------------------
    Fixture(
        query="世界模型",
        paper_id="2606.18208v1",
        paper_title="Looped World Models",
        paper_abstract=(
            "We introduce Looped World Models (LoopWM), the first looped "
            "architectures for world modelling. Our method iteratively refines "
            "latent environment states through a parameter-shared transformer "
            "block with adaptive computation."
        ),
        expected_verdict=False,
        expected_score_range=(0.0, 0.34),
        expected_scoring_status="degraded",
        note=(
            "topically exact, but no English term is resolvable locally; the "
            "gate reports degraded instead of silently rejecting everything"
        ),
        tags=("chinese", "pure-chinese", "degraded"),
    ),
    Fixture(
        query="什么是混合专家模型？",
        paper_id="moe-expert-choice",
        paper_title="Mixture-of-Experts with Expert Choice Routing",
        paper_abstract=(
            "We propose expert choice routing for mixture of experts models, "
            "letting experts select the tokens they process."
        ),
        expected_verdict=False,
        expected_score_range=(0.0, 0.34),
        expected_scoring_status="degraded",
        note="exact topical match that the lexical gate cannot see",
        tags=("chinese", "pure-chinese", "degraded"),
    ),
    Fixture(
        query="什么是混合专家模型？ Mixture Experts",
        paper_id="moe-survey-plural-title",
        paper_title="Mixtures of Experts Models",
        paper_abstract=(
            "This survey reviews sparse mixture of experts, expert gating "
            "networks and conditional computation."
        ),
        expected_verdict=True,
        expected_score_range=(0.35, 1.0),
        expected_scoring_status="ok",
        note=(
            "a free-text phrase with 'of' stripped must still resolve to the "
            "moe concept, and the plural title must match the singular alias"
        ),
        tags=("chinese", "stripped-phrase", "degraded-fix"),
    ),
    Fixture(
        query="大模型的幻觉问题",
        paper_id="hallucination-survey",
        paper_title="Hallucination in Large Language Models: A Survey",
        paper_abstract=(
            "We survey hallucination in large language models, covering causes, "
            "detection methods and mitigation strategies."
        ),
        expected_verdict=False,
        expected_score_range=(0.0, 0.34),
        expected_scoring_status="degraded",
        note="on-topic survey, but nothing the English lexical gate can match",
        tags=("chinese", "pure-chinese", "degraded"),
    ),
    # ----------------------------------------------------------------------
    # Chinese questions that do carry an ASCII term: the bridge reaches ok,
    # so these are judged on the verdict like any English fixture.
    # ----------------------------------------------------------------------
    Fixture(
        query="Transformer 的局限性有哪些？",
        paper_id="transformer-limitations",
        paper_title="On Limitation of Transformer for Learning HMMs",
        paper_abstract=(
            "We study limitations of Transformer for learning hidden Markov "
            "models, showing expressivity bounds."
        ),
        expected_verdict=True,
        expected_score_range=(0.35, 1.0),
        expected_scoring_status="ok",
        note="'Transformer' is resolvable vocabulary, so the gate can judge it",
        tags=("chinese", "ascii-term", "relevant", "limitation"),
    ),
    Fixture(
        query="Transformer 的局限性有哪些？",
        paper_id="transform-limited-photons",
        paper_title=(
            "Transform-limited single photons from a single quantum dot"
        ),
        paper_abstract=(
            "We report transform-limited single photons emitted by a single "
            "quantum dot in a micropillar cavity."
        ),
        expected_verdict=False,
        expected_score_range=(0.0, 0.34),
        expected_scoring_status="ok",
        note=(
            "shares the token 'transform' but is quantum optics, not the "
            "Transformer architecture"
        ),
        tags=("chinese", "ascii-term", "cross-domain", "limitation"),
    ),
]

# Kept as separate names so callers can still address the two historical
# groups; the suite itself evaluates FIXTURES in order.
ENGLISH_FIXTURES = [item for item in FIXTURES if "chinese" not in item.tags]
CHINESE_FIXTURES = [item for item in FIXTURES if "chinese" in item.tags]

ALL_FIXTURES = ENGLISH_FIXTURES + CHINESE_FIXTURES


def evaluate(fixture: Fixture, scorer=score_literature_relevance) -> dict:
    """Run one fixture through the gate and compare with its expectation."""
    result = scorer(
        fixture.query,
        {"title": fixture.paper_title, "abstract": fixture.paper_abstract},
    )
    score = float(result.get("score") or 0.0)
    low, high = fixture.expected_score_range
    in_band = low <= score <= high
    scoring_status = result.get("scoring_status")
    status_ok = (
        fixture.expected_scoring_status is None
        or scoring_status == fixture.expected_scoring_status
    )
    if fixture.expected_verdict is None and fixture.expected_scoring_status is None:
        status = "unjudged"
    elif result.get("accepted") == fixture.expected_verdict and in_band and status_ok:
        status = "pass"
    else:
        status = "FAIL"
    return {
        "fixture": fixture,
        "accepted": bool(result.get("accepted")),
        "score": score,
        "scoring_status": scoring_status,
        "in_band": in_band,
        "status_ok": status_ok,
        "status": status,
        "result": result,
    }


def run_suite(scorer=score_literature_relevance, verbose: bool = True) -> dict:
    outcomes = [evaluate(fixture, scorer) for fixture in ALL_FIXTURES]
    passed = [item for item in outcomes if item["status"] == "pass"]
    failed = [item for item in outcomes if item["status"] == "FAIL"]
    unjudged = [item for item in outcomes if item["status"] == "unjudged"]
    if verbose:
        print("=" * 96)
        print("LITERATURE RELEVANCE GATE - OFFLINE REGRESSION SUITE")
        print("=" * 96)
        for item in outcomes:
            fixture = item["fixture"]
            marker = {"pass": "PASS", "FAIL": "FAIL", "unjudged": "----"}[item["status"]]
            print(
                f"[{marker}] score={item['score']:<6} accepted={str(item['accepted']):<5} "
                f"status={str(item['scoring_status']):<9} expected={fixture.expected_verdict}"
                + (
                    f" (expect status={fixture.expected_scoring_status})"
                    if fixture.expected_scoring_status else ""
                )
            )
            print(f"        query : {fixture.query}")
            print(f"        paper : {fixture.paper_title[:74]} ({fixture.paper_id})")
            if item["status"] == "FAIL":
                print(f"        band  : {fixture.expected_score_range} in_band={item['in_band']}")
                print(f"        status_ok: {item['status_ok']}")
                if fixture.note:
                    print(f"        note  : {fixture.note}")
            elif fixture.note:
                print(f"        note  : {fixture.note}")
        print("-" * 96)
        print(
            f"total={len(outcomes)}  pass={len(passed)}  FAIL={len(failed)}  "
            f"unjudged={len(unjudged)}"
        )
        if failed:
            print("\nFailures:")
            for item in failed:
                print(f"  - {item['fixture'].query[:50]!r} -> {item['fixture'].paper_title[:50]!r}")
    return {
        "outcomes": outcomes,
        "pass": len(passed),
        "fail": len(failed),
        "unjudged": len(unjudged),
        "total": len(outcomes),
    }


def _load_from_path(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    module.__package__ = "deepdiver_v2.src"
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def compare_with_head() -> int:
    """Report every fixture whose verdict differs from the committed version."""
    target = ROOT / "deepdiver_v2" / "src" / "query_router.py"
    try:
        completed = subprocess.run(
            ["git", "show", "HEAD:deepdiver_v2/src/query_router.py"],
            cwd=str(ROOT), capture_output=True, check=True,
        )
    except (subprocess.CalledProcessError, FileNotFoundError) as exc:
        print(f"cannot read HEAD version: {exc}")
        return 1
    # Decode explicitly: the repository mixes BOM and non-BOM files, and the
    # committed source is not always valid UTF-8 after a lossy round-trip.
    head_source = completed.stdout.decode("utf-8-sig", errors="replace")
    if not head_source.strip():
        print("HEAD version is empty; cannot compare.")
        return 1
    with tempfile.TemporaryDirectory() as directory:
        head_path = Path(directory) / "query_router_head.py"
        head_path.write_text(head_source, encoding="utf-8")
        head_module = _load_from_path(head_path, "qr_head_compare")
        current = run_suite(verbose=False)
        baseline = run_suite(head_module.score_literature_relevance, verbose=False)
    print("=" * 96)
    print("WORKING COPY vs HEAD")
    print("=" * 96)
    differences = 0
    for now, before in zip(current["outcomes"], baseline["outcomes"]):
        fixture = now["fixture"]
        if now["accepted"] != before["accepted"] or now["score"] != before["score"]:
            differences += 1
            print(f"[DIFF] {fixture.query[:46]!r}")
            print(f"       paper    : {fixture.paper_title[:66]}")
            print(f"       HEAD     : accepted={before['accepted']} score={before['score']}")
            print(f"       WORKING  : accepted={now['accepted']} score={now['score']}")
    print("-" * 96)
    print(
        f"fixtures={current['total']}  differences={differences}  "
        f"HEAD pass={baseline['pass']}/{baseline['total']}  "
        f"WORKING pass={current['pass']}/{current['total']}"
    )
    if differences == 0:
        print("No behavioural difference from HEAD.")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--baseline", action="store_true",
        help="compare the working copy against the committed HEAD version",
    )
    args = parser.parse_args()
    if args.baseline:
        return compare_with_head()
    summary = run_suite()
    return 1 if summary["fail"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
