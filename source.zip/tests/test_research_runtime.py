"""No-provider launch, dependency boundary and shared-service regressions."""

import ast
import io
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest.mock import MagicMock, Mock, patch

import research_runtime as runtime
import web_app
from tests.test_process_cleanup import pid_alive

ROOT = Path(__file__).resolve().parents[1]


class RuntimeContractTests(unittest.TestCase):
    def test_command_uses_current_python_and_preserves_unicode_arguments(self):
        command = runtime.research_command(["--query-file", "中文 空格/问题.txt", "--quiet"])
        self.assertEqual(command[:2], [sys.executable, "-u"])
        self.assertTrue(command[2].endswith("demo.py"))
        self.assertEqual(command[4], "中文 空格/问题.txt")
        self.assertFalse(any(arg.endswith((".cmd", ".sh")) for arg in command))

    def test_environment_honors_service_url_and_forces_http_utf8_without_mutating_parent(self):
        with patch.dict(os.environ, {"MCP_SERVER_URL": "http://mcp:6274/mcp", "MCP_USE_STDIO": "true"}):
            environment = runtime.research_environment()
            self.assertEqual(environment["MCP_SERVER_URL"], "http://mcp:6274/mcp")
            self.assertEqual(environment["MCP_USE_STDIO"], "false")
            self.assertEqual(environment["PYTHONIOENCODING"], "utf-8")
            self.assertEqual(os.environ["MCP_USE_STDIO"], "true")

    def test_non_mcp_routes_and_help_do_not_require_service(self):
        for arguments in (["--help"], ["--config-only"], ["--query-mode", "direct_llm"],
                          ["--query-mode=science_literature"]):
            with self.subTest(arguments=arguments):
                self.assertFalse(runtime.requires_shared_mcp(arguments))
        self.assertTrue(runtime.requires_shared_mcp(["--query-mode", "paper_evidence"]))
        self.assertTrue(runtime.requires_shared_mcp([]))

    def test_launch_uses_no_shell_and_own_posix_session(self):
        fake = Mock(pid=43210)
        with patch.object(web_app, "check_shared_mcp") as probe, patch.object(web_app.subprocess, "Popen", return_value=fake) as spawn:
            web_app._spawn_research_process(runtime.research_command(["--query-mode", "paper_evidence"]), io.StringIO())
        probe.assert_called_once()
        kwargs = spawn.call_args.kwargs
        self.assertEqual(kwargs["cwd"], ROOT)
        self.assertNotIn("shell", kwargs)
        self.assertEqual(kwargs["env"]["MCP_USE_STDIO"], "false")
        if os.name != "nt":
            self.assertTrue(kwargs["start_new_session"])
            self.assertEqual(fake._sciassistant_process_group, fake.pid)

    def test_env_only_configuration_no_longer_requires_private_file(self):
        # Execute the actual function without importing the heavy CLI or
        # touching/renaming the user's private configuration file.
        source = (ROOT / "deepdiver_v2/cli/demo.py").read_text(encoding="utf-8")
        function = next(node for node in ast.parse(source).body
                        if isinstance(node, ast.FunctionDef) and node.name == "load_environment_config")
        fake_path = MagicMock()
        fake_path.return_value.parent.parent.__truediv__.return_value.__truediv__.return_value.exists.return_value = False
        expected_config = object()
        namespace = {"Path": fake_path, "__file__": "demo.py", "console": Mock(),
                     "reload_config": Mock(), "get_config": Mock(return_value=expected_config)}
        exec(compile(ast.Module(body=[function], type_ignores=[]), "demo.py", "exec"), namespace)
        self.assertIs(namespace["load_environment_config"](quiet=True), expected_config)
        namespace["reload_config"].assert_called_once()

    def test_windows_research_wrappers_do_not_bootstrap_services(self):
        text = (ROOT / "bin/windows/run_demo.cmd").read_text(encoding="utf-8")
        self.assertIn("tools\\run_research.py", text)
        self.assertNotIn("mcp_server_standard.py", text)
        self.assertNotIn('start "', text.lower())
        self.assertIn("exit /b %DEMO_EXIT%", (ROOT / "run_demo.cmd").read_text())

    def test_real_cross_platform_cli_help_from_unrelated_working_directory(self):
        with tempfile.TemporaryDirectory(prefix="科研 launch ") as directory:
            result = subprocess.run([sys.executable, str(ROOT / "tools/run_research.py"), "--help"],
                                    cwd=directory, capture_output=True, timeout=30)
        self.assertEqual(result.returncode, 0)
        self.assertIn(b"--query-file", result.stdout)
        self.assertIn(b"--diagnostics-file", result.stdout)

    def test_real_config_module_loads_from_environment_without_any_env_file(self):
        with tempfile.TemporaryDirectory() as directory:
            shutil.copyfile(ROOT / "deepdiver_v2/config/config.py", Path(directory) / "env_config.py")
            environment = os.environ.copy()
            environment.update(MODEL_REQUEST_URL="http://127.0.0.1:9/offline", MODEL_REQUEST_TOKEN="offline-unused",
                               MCP_SERVER_URL="http://private-mcp:6274/mcp", MCP_USE_STDIO="false", PDF_PARSE_MODE="local")
            script = ("import env_config; c = env_config.get_config(); "
                      "assert c.model_request_url == 'http://127.0.0.1:9/offline'; "
                      "assert c.mcp_server_url == 'http://private-mcp:6274/mcp'; "
                      "assert c.mcp_use_stdio is False; print('env_only_ok')")
            result = subprocess.run([sys.executable, "-c", script], cwd=directory,
                                    env=environment, capture_output=True, timeout=10)
            self.assertEqual(result.returncode, 0)
            self.assertIn(b"env_only_ok", result.stdout)

    def test_real_cli_missing_mcp_is_safe_and_does_not_auto_start_service(self):
        with socket.socket() as reservation:
            reservation.bind(("127.0.0.1", 0))
            port = reservation.getsockname()[1]
        environment = os.environ.copy()
        environment["MCP_SERVER_URL"] = f"http://127.0.0.1:{port}/mcp"
        command = [sys.executable, str(ROOT / "tools/run_research.py"),
                   "--query-mode", "paper_evidence", "--query", "offline canary", "--quiet"]
        result = subprocess.run(command, env=environment, capture_output=True, timeout=10)
        self.assertEqual(result.returncode, 2)
        output = (result.stdout + result.stderr).decode("utf-8")
        self.assertIn(runtime.MCP_UNAVAILABLE_MESSAGE, output)
        self.assertNotIn("127.0.0.1", output)
        self.assertNotIn("Traceback", output)
        with socket.socket() as client:
            client.settimeout(1)
            self.assertNotEqual(client.connect_ex(("127.0.0.1", port)), 0)

    def test_real_independent_mcp_process_survives_direct_task_tree_cleanup(self):
        # Actual project MCP on a private temporary port; only GET /health.
        # No production ports, provider requests, tools, or database access.
        with tempfile.TemporaryDirectory() as directory:
            with socket.socket() as reservation:
                reservation.bind(("127.0.0.1", 0))
                port = reservation.getsockname()[1]
            environment = os.environ.copy()
            environment.update(MCP_SERVER_URL=f"http://127.0.0.1:{port}/mcp",
                               MCP_SERVER_LOG_PATH=str(Path(directory) / "mcp.log"),
                               MODEL_REQUEST_URL="http://127.0.0.1:9/offline", MODEL_REQUEST_TOKEN="offline-unused",
                               PYTHONUTF8="1")
            command = [sys.executable, "-u", str(ROOT / "tools/run_mcp_service.py"),
                       "--host", "127.0.0.1", "--port", str(port),
                       "--workspace-dir", str(Path(directory) / "workspaces")]
            service, task_process = None, None
            with open(os.devnull, "w") as stream:
                try:
                    service = subprocess.Popen(command, cwd=directory, env=environment, stdout=stream,
                                               stderr=subprocess.STDOUT, start_new_session=os.name != "nt")
                    if os.name != "nt":
                        service._sciassistant_process_group = service.pid
                    deadline = time.monotonic() + 25
                    while time.monotonic() < deadline:
                        self.assertIsNone(service.poll(), "Isolated MCP exited before healthy")
                        try:
                            runtime.check_shared_mcp(environment)
                            break
                        except runtime.ResearchDependencyError:
                            time.sleep(0.1)
                    else:
                        self.fail("Isolated MCP failed its health check")
                    tree = Path(directory) / "tree"
                    tree.mkdir()
                    fixture = ROOT / "tests/fixtures/heartbeat_tree.py"
                    with patch.dict(os.environ, {"MCP_SERVER_URL": environment["MCP_SERVER_URL"]}):
                        task_process = web_app._spawn_research_process(
                            [sys.executable, "-u", str(fixture), str(tree), "2"], stream)
                    deadline = time.monotonic() + 10
                    while len(list(tree.glob("beat-*.txt"))) < 3 and time.monotonic() < deadline:
                        time.sleep(0.05)
                    self.assertEqual(len(list(tree.glob("beat-*.txt"))), 3)
                    pids = [int(file.read_text()) for file in tree.glob("pid-*.txt")]
                    self.assertEqual(web_app._terminate_subprocess_tree(task_process)["status"], "confirmed")
                    deadline = time.monotonic() + 2
                    while any(pid_alive(pid) for pid in pids) and time.monotonic() < deadline:
                        time.sleep(0.02)
                    self.assertTrue(all(not pid_alive(pid) for pid in pids))
                    self.assertIsNone(service.poll())
                    runtime.check_shared_mcp(environment)
                finally:
                    for owned_process in (task_process, service):
                        if owned_process is not None and owned_process.poll() is None:
                            web_app._terminate_subprocess_tree(owned_process)


class SharedServiceBoundaryTests(unittest.TestCase):
    def setUp(self):
        self.hits = []
        self.payload = b'{"status":"healthy"}'
        self.status = 200
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                owner.hits.append({"path": self.path, "authorization": self.headers.get("Authorization")})
                self.send_response(owner.status)
                self.send_header("Content-Length", str(len(owner.payload)))
                self.end_headers()
                self.wfile.write(owner.payload)

            def log_message(self, *_args):
                pass

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.environment = {"MCP_SERVER_URL": f"http://127.0.0.1:{self.server.server_port}/mcp"}

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)

    def test_health_is_only_request_and_does_not_forward_credentials_or_query(self):
        environment = {**self.environment, "Authorization": "do-not-leak", "MCP_AUTH_TOKEN": "do-not-leak"}
        environment["MCP_SERVER_URL"] += "?token=do-not-leak"
        runtime.check_shared_mcp(environment)
        self.assertEqual(self.hits, [{"path": "/health", "authorization": None}])

    def test_bad_health_redirect_and_oversized_response_are_safe_failures(self):
        for status, payload in ((503, b"private host/token detail"), (302, b"redirect"),
                                (200, b"not-json"), (200, b'{"status":"down"}'),
                                (200, b"x" * 65537)):
            with self.subTest(status=status, size=len(payload)):
                self.status, self.payload = status, payload
                with self.assertRaises(runtime.ResearchDependencyError) as caught:
                    runtime.check_shared_mcp(self.environment)
                self.assertEqual(str(caught.exception), runtime.MCP_UNAVAILABLE_MESSAGE)

    def test_invalid_url_fails_without_network(self):
        for url in ("file:///private/path", "http://user:secret@localhost/mcp", "not-a-url"):
            with self.subTest(url=url), self.assertRaises(runtime.ResearchDependencyError):
                runtime.check_shared_mcp({"MCP_SERVER_URL": url})
        self.assertEqual(self.hits, [])

    def test_unavailable_service_never_launches_child_and_exports_safe_failed_evidence(self):
        with tempfile.TemporaryDirectory() as directory:
            task_id = "mcp-dependency-canary"
            with patch.object(web_app, "LOG_DIR", Path(directory)), patch.object(web_app, "TASK_STATE_DIR", Path(directory)), \
                 patch.dict(web_app.TASKS, {task_id: {"id": task_id, "status": "queued", "created_at": web_app._now()}}), \
                 patch.dict(os.environ, self.environment), patch.object(web_app, "_evidence_build_revision", return_value="offline-test"), \
                 patch.object(web_app.subprocess, "Popen") as spawn:
                self.status = 503
                web_app._run_query_task(task_id, "offline canary", query_mode="paper_evidence")
                spawn.assert_not_called()
                task = web_app.TASKS[task_id]
                self.assertEqual(task["status"], "failed")
                self.assertEqual(task["execution"]["failure_stage"], "mcp_dependency")
                for format_name in ("json", "md"):
                    response = web_app.app.test_client().get(f"/api/tasks/{task_id}/evidence?format={format_name}")
                    self.assertEqual(response.status_code, 200)
                    self.assertNotIn(str(self.server.server_port), response.get_data(as_text=True))
                self.assertFalse(list(Path(directory).glob("web_query*")))

    def test_real_direct_python_tree_cleanup_keeps_shared_health_service_alive(self):
        # Use production spawn + real cleanup, replacing only CLI payload
        # with an offline heartbeat tree. MCP fixture is outside that tree.
        with tempfile.TemporaryDirectory() as directory:
            fixture = ROOT / "tests/fixtures/heartbeat_tree.py"
            command = [sys.executable, "-u", str(fixture), directory, "2"]
            process = None
            try:
                with patch.dict(os.environ, self.environment), open(os.devnull, "w") as stream:
                    process = web_app._spawn_research_process(command, stream)
                    deadline = time.monotonic() + 10
                    while len(list(Path(directory).glob("pid-*.txt"))) < 3 and time.monotonic() < deadline:
                        time.sleep(0.05)
                    pids = [int(file.read_text()) for file in Path(directory).glob("pid-*.txt")]
                    self.assertEqual(len(pids), 3)
                    result = web_app._terminate_subprocess_tree(process)
                    self.assertEqual(result["status"], "confirmed")
                    deadline = time.monotonic() + 2
                    while any(pid_alive(pid) for pid in pids) and time.monotonic() < deadline:
                        time.sleep(0.02)
                    self.assertTrue(all(not pid_alive(pid) for pid in pids))
                    runtime.check_shared_mcp(self.environment)
                    self.assertTrue(self.thread.is_alive())
            finally:
                if process is not None and process.poll() is None:
                    web_app._terminate_subprocess_tree(process)


if __name__ == "__main__":
    unittest.main()
