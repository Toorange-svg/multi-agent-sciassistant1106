from __future__ import annotations

import json
import time

import pytest

from multi_agent_agents import ArtifactDirectory, AgentContractError
from multi_agent_live import LiveArxivRagExecutor, normalize_live_result, rank_read_candidates
from multi_agent_pipeline_v2 import LiteraturePipelineV2, check_review, render_claims, check_draft
from multi_agent_workflow import WorkflowStore
from multi_agent_report import export_run_report
from test_multi_agent_pipeline_v2 import agents


def searches():
    def search(_source, query, _limit, **_kwargs):
        group = next((i for i in range(1, 4) if f"Topic{i}" in query), 1)
        return {"status": "ok", "papers": [
            {"paper_id": f"2401.{group * 10 + i:05d}v1", "title": f"Topic{group} study {i}",
             "abstract": f"Topic{group} reports latency under specified experimental conditions."}
            for i in range(5)]}
    return search


def executor(tmp_path, *, fail_first=False):
    downloads = []
    def download(paper_id, folder):
        downloads.append(paper_id)
        if fail_first and len(downloads) == 1:
            raise TimeoutError("private-canary must not be logged")
        target = folder / "source.pdf"
        target.write_bytes(b"%PDF-1.4\n" + paper_id.encode() + b"\n%%EOF")
        return target
    def parse(path):
        paper_id = path.parent.name
        return {"success": True, "layout_blocks": [{"page": 1, "bbox": [1, 2, 3, 4],
                "text": f"Topic1 Topic2 Topic3 latency experiment {paper_id} reports a 2x throughput gain, not a latency percentage. " * 15}]}
    return LiveArxivRagExecutor(tmp_path / "run", tmp_path / "storage", rag_mode="lexical",
                                search=searches(), download=download, parse=parse), downloads


def actions(groups=3):
    return [{"request_id": f"r{i}", "action": "request_arxiv_search",
             "arguments": {"query": f'(ti:"Topic{i}" OR abs:"Topic{i}")', "group_id": f"g{i}"}}
            for i in range(1, groups + 1)]


def plan(groups=3):
    return {"groups": [{"id": f"g{i}", "question": f"Topic{i} latency?", "core": [f"Topic{i}"],
                        "support": [], "metrics": ["latency"]} for i in range(1, groups + 1)]}


def test_three_fair_batches_read_up_to_fifteen_and_reuse_search(tmp_path):
    tool, downloads = executor(tmp_path)
    tool.configure_plan(plan())
    snapshots = []
    first = tool.execute(actions(), group_ids={"g1", "g2", "g3"}, deadline=time.monotonic() + 60, progress=snapshots.append)
    assert len(downloads) == 5
    assert {row["group_id"] for row in first["observations"] if row["source_status"] == "reading_selected"} == {"g1", "g2", "g3"}
    assert len(first["evidence"]) <= 12
    assert any(row["source_status"] == "pdf_indexed" for s in snapshots for row in s["observations"])
    assert tool.has_more_reading()
    second = tool.continue_reading(deadline=time.monotonic() + 60, focus_groups={"g3"})
    assert len(downloads) == 10
    new = [row for row in second["observations"] if row["source_status"] == "reading_selected" and row["batch"] == 2]
    assert new[0]["group_id"] == "g3"
    final = tool.continue_reading(deadline=time.monotonic() + 60)
    assert len(downloads) == len(set(downloads)) == 15
    assert tool.read_batches == 3 and not tool.has_more_reading()
    assert len([row for row in final["observations"] if "query" in row]) == 3
    assert final["reading_summary"]["papers_indexed"] == 15
    tool.continue_reading(deadline=time.monotonic() + 60)
    assert len(downloads) == 15


def test_failure_of_first_paper_does_not_block_next_candidate(tmp_path):
    tool, downloads = executor(tmp_path, fail_first=True)
    result = tool.execute(actions(1), group_ids={"g1"}, deadline=time.monotonic() + 60)
    assert len(downloads) == 5 and len(tool.ingested) == 4
    assert any(row["source_status"] == "pdf_download_deadline_skipped" for row in result["observations"])
    assert "private-canary" not in json.dumps(result)
    assert result["evidence"] and all(row["coverage_scope"] == "selected_chunks" for row in result["evidence"])


def test_deadline_before_batch_does_not_download(tmp_path):
    tool, downloads = executor(tmp_path)
    tool.execute(actions(), group_ids={"g1", "g2", "g3"}, deadline=time.monotonic() - 1)
    assert downloads == [] and tool.pdf_reads == tool.read_batches == 0


def test_same_paper_and_versions_in_multiple_groups_are_read_once(tmp_path):
    tool, downloads = executor(tmp_path)
    tool.search_function = lambda *_a, **_k: {"status": "ok", "papers": [
        {"paper_id": "2309.06180v1", "title": "PagedAttention", "abstract": "Topic1 Topic2"},
        {"paper_id": "2309.06180v2", "title": "PagedAttention", "abstract": "Topic1 Topic2"}]}
    tool.execute(actions(2), group_ids={"g1", "g2"}, deadline=time.monotonic() + 60)
    assert len(downloads) == tool.pdf_reads == 1
    assert set(next(iter(tool.candidates.values()))["group_ids"]) == {"g1", "g2"}


def test_generic_repeated_metrics_do_not_outrank_core_entities():
    papers = [{"paper_id": "broad", "title": "Serving latency throughput latency throughput"},
              {"paper_id": "original", "title": "Efficient memory management with PagedAttention"}]
    queries = ['abs:"PagedAttention" AND abs:"latency" AND abs:"throughput"'] * 6
    assert rank_read_candidates(papers, queries)[0]["paper_id"] == "original"
    assert rank_read_candidates(papers, queries, core=["PagedAttention"], support=["vLLM"])[0]["paper_id"] == "original"


def test_phrase_duplicates_do_not_change_rank():
    papers = [{"title": "PagedAttention"}, {"title": "vLLM PagedAttention"}]
    assert rank_read_candidates(papers, ['ti:"PagedAttention"']) == rank_read_candidates(papers, ['ti:"PagedAttention"'] * 5)


@pytest.mark.parametrize("metric", ["latency", "TTFT", "TPOT", "quality"])
def test_omitted_metric_cannot_be_called_fully_covered(metric):
    reviewed = {"coverage_status": "sufficient", "allowed_evidence_ids": ["e1"], "coverage": [
        {"group_id": "g1", "metric": "throughput", "status": "direct", "evidence_ids": ["e1"]}], "conflicts": []}
    result = check_review(reviewed, {"evidence": [{"evidence_id": "e1"}]}, {"g1"},
                          plan={"groups": [{"id": "g1", "metrics": [metric]}]})
    assert result["coverage_status"] == "partial"
    assert any(row["metric"] == metric and row["status"] == "missing" for row in result["coverage"])
    assert len(reviewed["coverage"]) == 1


@pytest.mark.parametrize("status", ["not_reported", "not_comparable", "conflicting"])
def test_legitimate_metric_boundaries_are_not_failures(status):
    result = check_review({"coverage_status": "sufficient", "allowed_evidence_ids": ["e1"], "coverage": [
        {"group_id": "g1", "metric": "latency", "status": status, "evidence_ids": ["e1"]}], "conflicts": []},
        {"evidence": [{"evidence_id": "e1"}]}, {"g1"}, plan=plan(1))
    assert result["coverage_status"] == ("needs_review" if status == "conflicting" else "partial")


@pytest.mark.parametrize("bad", [{"core": "PagedAttention"}, {"support": ["x"] * 5}, {"metrics": ["x" * 101]}])
def test_optional_plan_terms_remain_bounded(bad):
    with pytest.raises(AgentContractError):
        normalize_live_result("planner", {"groups": [{"id": "g1", **bad}]})


def configured_agents(*, sufficient_after=3):
    configured, calls = agents()
    configured.planner.handler = lambda _: {"output": plan()}
    configured.retriever.handler = lambda _: {"output": {"actions": 3}, "tool_requests": actions()}
    seen = []
    def reviewer(packet):
        seen.append(1)
        data = next(x["payload"] for x in packet["inputs"] if "evidence" in x["payload"])
        ids = [row["evidence_id"] for row in data["evidence"]]
        coverage = []
        for group in plan()["groups"]:
            matching = [row["evidence_id"] for row in data["evidence"] if group["id"] in row["group_ids"]]
            coverage.append({"group_id": group["id"], "metric": "latency", "status": "direct" if len(seen) >= sufficient_after else "partial",
                             "evidence_ids": matching, "gap_id": group["id"] + "-latency"})
        return {"output": {"coverage_status": "sufficient" if len(seen) >= sufficient_after else "partial",
                           "allowed_evidence_ids": ids, "coverage": coverage, "conflicts": []}}
    def writer(packet):
        rows = next(x["payload"]["evidence"] for x in packet["inputs"] if "evidence" in x["payload"])
        return {"output": {"direct_answer": "UNCHECKED_SUMMARY_CANARY", "claims": [
            {"claim_id": "c1", "text": "各技术的实验指标不能直接混为统一的延迟百分比。", "section": "direct_conclusion",
             "evidence_ids": [rows[0]["evidence_id"]], "qualification": "实验材料限定"},
            {"claim_id": "c2", "text": "Topic1 实验描述。", "section": "topic_analysis", "group_id": "g1",
             "evidence_ids": [rows[0]["evidence_id"]]}]}}
    configured.reviewer.handler = reviewer
    configured.writer.handler = writer
    return configured, seen


@pytest.mark.parametrize("batches,expected_calls", [(1, 5), (2, 6), (3, 7)])
def test_workflow_stops_by_coverage_not_required_paper_count(tmp_path, batches, expected_calls):
    tool, downloads = executor(tmp_path)
    configured, seen = configured_agents(sufficient_after=batches)
    run = tmp_path / "run"
    flow = LiteraturePipelineV2(WorkflowStore(run / "workflow.sqlite3"), ArtifactDirectory(run / "artifacts"),
                                configured, tool, event_path=run / "events.jsonl")
    result = flow.run("batch-test", "owner", "Compare three topics")
    assert result["run"]["status"] == "completed", result
    assert result["run"]["model_calls_used"] == expected_calls
    assert len(seen) == batches and len(downloads) == 5 * batches
    assert "直接回答" in result["direct_answer"]
    assert "UNCHECKED_SUMMARY_CANARY" not in result["direct_answer"]
    final = flow.artifacts.get(result["final_artifact_id"])
    budget = flow.artifacts.get(final["artifact_refs"]["budget"])
    assert budget["reading"]["papers_attempted"] == 5 * batches
    assert budget["model_call_limit"] == 10 and budget["time_budget_seconds"] == 360
    export_run_report(run)
    assert (run / "budget_usage.json").exists()
    assert '<h3>直接回答</h3>' in (run / "final_answer.html").read_text(encoding="utf-8")


def test_time_reserve_skips_more_reading_and_gap_but_still_writes_partial(tmp_path):
    tool, downloads = executor(tmp_path)
    configured, _ = configured_agents(sufficient_after=99)
    run = tmp_path / "run"
    flow = LiteraturePipelineV2(WorkflowStore(run / "workflow.sqlite3"), ArtifactDirectory(run / "artifacts"),
                                configured, tool, event_path=run / "events.jsonl")
    reviewer = configured.reviewer.handler
    def slow_review(packet):
        output = reviewer(packet)
        flow.deadline = time.monotonic() + 135
        return output
    configured.reviewer.handler = slow_review
    result = flow.run("time-reserve", "owner", "three topics")
    assert result["run"]["status"] == "partial"
    assert result["run"]["model_calls_used"] == 5 and len(downloads) == 5
    final = flow.artifacts.get(result["final_artifact_id"])
    assert flow.artifacts.get(final["artifact_refs"]["budget"])["reading_stop_reason"] == "writer_auditor_time_reserve"


def test_structured_conclusions_cannot_bypass_claim_audit():
    evidence = {"evidence": [{"evidence_id": "e1", "excerpt": "Throughput improved 2x under fixed latency."}]}
    draft = {"direct_answer": "LEAK 99%", "claims": [
        {"claim_id": "bad", "text": "延迟减少99%", "claim_type": "quantitative", "section": "direct_conclusion", "evidence_ids": ["e1"]},
        {"claim_id": "good", "text": "吞吐提升不等于延迟下降。", "section": "evidence_boundary", "evidence_ids": ["e1"]}]}
    issues = check_draft(draft, evidence)
    output = render_claims(draft, evidence, rejected={row["claim_id"] for row in issues})
    assert "99%" not in output and "LEAK" not in output
    assert "证据边界" in output and "[1]" in output


def test_unknown_writer_section_is_rejected():
    with pytest.raises(AgentContractError):
        normalize_live_result("writer", {"direct_answer": "answer", "claims": [
            {"claim_id": "c1", "text": "text", "evidence_ids": ["e1"], "section": "execute_anything"}]})


def test_three_batch_reviews_and_recovery_still_reserve_final_two_calls(tmp_path):
    tool, downloads = executor(tmp_path)
    configured, reviews = configured_agents(sufficient_after=99)
    def gap(_packet):
        return {"output": {"gaps": [{"gap_id": "g1-latency", "group_id": "g1",
                                      "metric": "latency", "query": '(ti:"Topic1" OR abs:"Topic1") AND abs:"latency"'}]}}
    def retriever(packet):
        gaps = next((item["payload"]["gaps"] for item in packet["inputs"] if "gaps" in item["payload"]), None)
        requested = actions() if gaps is None else [{"request_id": "gap-r1", "action": "request_arxiv_search", "arguments": dict(gaps[0])}]
        return {"output": {"actions": len(requested)}, "tool_requests": requested}
    configured.gap_analyst.handler = gap
    configured.retriever.handler = retriever
    run = tmp_path / "run"
    flow = LiteraturePipelineV2(WorkflowStore(run / "workflow.sqlite3"), ArtifactDirectory(run / "artifacts"),
                                configured, tool, event_path=run / "events.jsonl")
    result = flow.run("budget-ten", "owner", "three topics")
    assert result["run"]["status"] == "partial", result
    assert result["run"]["model_calls_used"] == 10
    assert len(reviews) == 4 and len(downloads) == 15
    final = flow.artifacts.get(result["final_artifact_id"])
    budget = flow.artifacts.get(final["artifact_refs"]["budget"])
    roles = [item.get("role") for item in budget["stages"]]
    assert roles.count("gap_analyst") == roles.count("writer") == roles.count("citation_auditor") == 1


def test_next_batch_invalid_review_keeps_first_approved_evidence(tmp_path):
    tool, _ = executor(tmp_path)
    configured, _ = configured_agents(sufficient_after=99)
    valid = configured.reviewer.handler
    reviews = []
    def reviewer(packet):
        reviews.append(1)
        if len(reviews) > 1:
            return {"output": {"coverage_status": "sufficient", "allowed_evidence_ids": ["invented"], "coverage": [], "conflicts": []}}
        return valid(packet)
    configured.reviewer.handler = reviewer
    run = tmp_path / "run"
    flow = LiteraturePipelineV2(WorkflowStore(run / "workflow.sqlite3"), ArtifactDirectory(run / "artifacts"),
                                configured, tool, event_path=run / "events.jsonl")
    # Isolate the old-snapshot path without an optional gap round. The new
    # authorized policy can still use a remaining gap opportunity at 360s.
    flow.time_budget_seconds = 150
    result = flow.run("bad-batch-review", "owner", "three topics")
    assert result["run"]["status"] == "needs_review"
    assert result["run"]["model_calls_used"] == 6
    assert "invented" not in result["direct_answer"]


def test_fulltext_cache_reuses_download_parse_and_index(tmp_path):
    tool, _ = executor(tmp_path)
    tool.execute(actions(1), group_ids={"g1"}, deadline=time.monotonic() + 60)
    def unavailable(*_a):
        pytest.fail("cached content must not be downloaded or parsed again")
    second = LiveArxivRagExecutor(tmp_path / "second", tmp_path / "storage", rag_mode="lexical",
                                 search=searches(), download=unavailable, parse=unavailable)
    result = second.execute(actions(1), group_ids={"g1"}, deadline=time.monotonic() + 60)
    indexed = [row for row in result["observations"] if row["source_status"] == "pdf_indexed"]
    assert len(indexed) == 5
    assert all(row["download_reused"] and row["parse_reused"] and row["cache_reused"] for row in indexed)


def test_web_html_headings_remain_escaped_and_citations_linked():
    from multi_agent_web import exported_report
    data = {"status": "partial", "direct_answer": "### 简洁比较与直接结论\n\n<script>alert(1)</script> [1]",
            "references": [{"evidence_id": "e1", "citation": 1, "title": "Paper", "excerpt": "evidence",
                            "locator": {"page": 1}, "official_pdf_url": "https://arxiv.org/pdf/2309.06180",
                            "official_url": "https://arxiv.org/abs/2309.06180"}], "claims": [], "audit_status": "passed"}
    body, _ = exported_report(data, "html")
    html = body.decode("utf-8")
    assert "<h3>简洁比较与直接结论</h3>" in html and '<a href="#evidence-1">[1]</a>' in html
    assert "<script>" not in html and "&lt;script&gt;" in html
