"""One public research route; PDF parsing choices and privacy remain separate."""
import json
from html.parser import HTMLParser
from pathlib import Path


def test_tenant_browser_probe_uses_current_controls_not_hidden_mode_selector():
    script = (Path(__file__).resolve().parents[1]/'tools/check_user_isolation_browser.cjs').read_text(encoding='utf-8')
    assert "locator('#research-processing-mode').selectOption" not in script
    assert "locator('#research-report-profile').selectOption" in script
    assert "locator('#pdf-parse-mode').selectOption" in script
    assert "mode.type==='hidden'&&mode.value==='multi_agent_rag'" in script


def test_tenant_browser_probe_covers_embedding_secret_without_old_three_field_count():
    script = (Path(__file__).resolve().parents[1]/'tools/check_user_isolation_browser.cjs').read_text(encoding='utf-8')
    assert 'account-embedding-key' not in script
    assert "input[type=password]').count()===3" not in script
import shutil
import subprocess

import pytest

ROOT = Path(__file__).resolve().parents[1]


def test_no_processing_selector_but_pdf_parser_remains():
    class Controls(HTMLParser):
        def __init__(self):
            super().__init__()
            self.nodes = []
        def handle_starttag(self, tag, attrs):
            self.nodes.append((tag, dict(attrs)))
    source = (ROOT/'chatAi/ai_chat.html').read_text(encoding='utf8')
    controls = Controls()
    controls.feed(source)
    selected = [(tag, fields) for tag, fields in controls.nodes
                if fields.get('id') == 'research-processing-mode']
    assert selected == [('input', {'type': 'hidden', 'id': 'research-processing-mode',
                                    'value': 'multi_agent_rag'})]
    assert any(tag == 'select' and row.get('id') == 'pdf-parse-mode'
               for tag, row in controls.nodes)
    assert all(f'<option value="{mode}">' in source for mode in ('local', 'llama_full', 'hybrid'))
    assert '可在同一会话中连续追问并切换处理方式' not in source


@pytest.mark.parametrize('profile', ['standard', 'enhanced'])
@pytest.mark.parametrize('legacy_mode', [None, 'general_answer', 'pdf_local', 'context_search'])
def test_actual_submit_cannot_switch_away_from_multi_agent(legacy_mode, profile):
    node = shutil.which('node')
    if not node:
        pytest.skip('Node required')
    source = (ROOT/'chatAi/ai_chat.html').read_text(encoding='utf8')
    start = source.index('async function runScienceTask(')
    end = source.index('\n        // Detect a degraded', start)
    actual = source[start:end]
    harness = r"""
const vm=require('node:vm'),assert=require('node:assert/strict');
let posted;
const win={userToken:'fixture-account', ResearchLibrary:{append:async(form,session,mode)=>{
    assert.equal(mode,'multi_agent_rag'); return false;
}}, SciencePdfSession:{append:async(form,session,mode)=>assert.equal(mode,'multi_agent_rag')}};
const context=vm.createContext({window:win,FormData,DOMException,
    document:{getElementById:id=>id==='pdf-parse-mode'?{value:'local'}:
        id==='research-report-profile'?{value:PROFILE}:
        (LEGACY===null?null:{value:LEGACY})},
    fetch:async(url,options)=>{posted=options.body; throw Error('INTERCEPTED_NO_NETWORK');}});
vm.runInContext(SOURCE+'\nthis.submit=runScienceTask;',context);
(async()=>{
    await assert.rejects(context.submit('question','session-a',[],null,null),
        error=>error.message==='INTERCEPTED_NO_NETWORK');
    assert.equal(posted.get('processing_mode'),'multi_agent_rag');
    assert.equal(posted.get('pdf_parse_mode'),'local');
    assert.equal(posted.get('report_profile'),PROFILE);
    assert.equal(posted.get('llama_cloud_consent'),null);
})().catch(error=>{console.error(error);process.exitCode=1;});
"""
    result = subprocess.run([node, '-'],
        input='const SOURCE='+json.dumps(actual)+';const LEGACY='+json.dumps(legacy_mode)+';const PROFILE='+json.dumps(profile)+';\n'+harness,
        capture_output=True, text=True, encoding='utf8', timeout=10)
    assert result.returncode == 0, result.stderr


def test_research_profile_selector_follows_parser_and_shares_visual_style():
    source = (ROOT/'chatAi/ai_chat.html').read_text(encoding='utf8')
    class Selects(HTMLParser):
        def __init__(self):
            super().__init__(); self.nodes = {}
        def handle_starttag(self, tag, attrs):
            attrs = dict(attrs)
            if tag == 'select': self.nodes[attrs.get('id')] = attrs
    controls = Selects(); controls.feed(source)
    assert controls.nodes['research-report-profile']['class'] == controls.nodes['pdf-parse-mode']['class']
    assert source.index('id="pdf-parse-mode-control"') < source.index('id="report-profile-control"') < source.index('id="chat-form"')
    assert '<option value="standard">标准（约 6 分钟）</option>' in source
    assert '<option value="enhanced">增强报告（约 12 分钟）</option>' in source
    assert '实际可能更长' in controls.nodes['research-report-profile']['title']
