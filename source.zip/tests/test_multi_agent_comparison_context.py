"""Observed table arithmetic and cross-report context are not automatic verdicts."""
from copy import deepcopy
import hashlib
import json
from types import SimpleNamespace
import time

import pytest
from multi_agent_handoffs import comparison_observations, COMPARISON_POLICY, AUDIT_JOB_POLICY, project_audit_packet
from multi_agent_quality import citation_audit_input
from multi_agent_live import LiveArxivRagExecutor
from test_multi_agent_report_fields import draft

TABLE = 'Table 18\nRank r | val loss | BLEU\n4 | 1.18 | 70.38\n16 | 1.16 | 69.1\n32 | 1.16 | 68.9\n1024 | 1.17 | 68.1\n'


def sources(text=TABLE):
    return {'evidence':[{'evidence_id':'e1','paper_id':'p1','review_status':'approved',
        'evidence_strength':'fulltext_located','coverage_scope':'selected_chunks','excerpt':text,
        'locator':{'page':26,'table_id':'Table18','bbox':[0,0,100,100]}}]}


def test_exact_table_cells_extrema_ties_and_source_offsets_are_preserved():
    data = sources(); before = deepcopy(data)
    result = comparison_observations(data); record = result['records'][0]
    loss, bleu = record['scalar_columns']
    assert loss['minimum_printed_value']=='1.16' and loss['minimum_row_indices']==[1,2]
    assert bleu['maximum_printed_value']=='70.38' and bleu['maximum_row_indices']==[0]
    for row in record['rows']:
        original = TABLE[row['start']:row['end']]
        assert all(cell in original for cell in row['printed_cells'])
    assert record['source_text_sha256']==hashlib.sha256(TABLE.encode()).hexdigest()
    assert not result['semantic_auto_approval'] and not record['column_semantics_verified']
    assert not record['manual_visual_verification'] and not record['statistical_significance_verified']
    assert 'best_rank' not in json.dumps(record) and data==before


@pytest.mark.parametrize('field,value', [('review_status','rejected'),('evidence_strength','abstract_only'),
    ('locator',{'page':26}),('locator',{'table_id':'Table18'})])
def test_unapproved_unlocated_or_non_table_inputs_do_not_create_arithmetic(field,value):
    data=sources(); data['evidence'][0][field]=value
    assert comparison_observations(data)['records']==[]


@pytest.mark.parametrize('text',[
    'r | loss\n1 | 0.1\n2 | ?\n',
    'r | loss\n1 | 0.1 ± 0.02\n2 | 0.2 ± 0.01\n',
    'r | loss\n1 | 0.1\n2 | 0.2 | extra\n',
    'r | loss\n1 | 0.1\n',
    '1 | 2\n3 | 4\n5 | 6\n',
    'r | loss\n1 | NaN\n2 | Infinity\n',
])
def test_ambiguous_layout_or_partial_column_never_guesses_numbers(text):
    assert comparison_observations(sources(text))['records']==[]


def test_decimal_printed_equality_not_binary_float_and_no_direction_guess():
    result=comparison_observations(sources('model | error\nA | 0.10\nB | 0.100\nC | 1e-1\n'))
    col=result['records'][0]['scalar_columns'][0]
    assert col['minimum_row_indices']==[0,1,2] and col['maximum_row_indices']==[0,1,2]
    assert 'direction' not in col and 'optimal' not in col


def test_markdown_separator_is_not_a_numeric_observation():
    result=comparison_observations(sources('| model | score |\n|---|---|\n|A|1|\n|B|2|\n'))
    assert [r['printed_cells'] for r in result['records'][0]['rows']]==[['A','1'],['B','2']]


def test_blank_lines_from_pdf_table_parser_keep_one_table_and_exact_offsets():
    text=TABLE.replace('\n','\n\n')
    result=comparison_observations(sources(text)); row=result['records'][0]
    assert row['scalar_columns'][0]['minimum_row_indices']==[1,2]
    assert all(' | ' in text[r['start']:r['end']] for r in row['rows'])


def test_peer_context_survives_projection_without_foreign_menus_or_auto_verdicts():
    data=draft(); data.update(audit_job_policy=AUDIT_JOB_POLICY,comparison_context_policy=COMPARISON_POLICY)
    data['claims'][0]['text']='验证损失最优r=16。'
    data['claims'].append({**deepcopy(data['claims'][0]),'claim_id':'c2','text':'r=16与32在1.16并列。'})
    packet=citation_audit_input(data,sources())
    projected=project_audit_packet({'inputs':[{'artifact_id':'audit','payload':packet}]})['inputs'][0]['payload']
    assert len(projected['report_assertions'])==2 and projected['comparison_observations']['records']
    assert projected['audit_jobs'][0]['related_report_claim_ids']==['c2']
    assert projected['audit_jobs'][1]['related_report_claim_ids']==['c1']
    assert 'choice_label' not in json.dumps(projected['report_assertions'])
    assert all(o['claim_id']=='c1' for o in projected['audit_jobs'][0]['source_witness_options'])
    assert all('decision' not in r for r in projected['report_assertions'])
    # Legacy policy does not gain new verdict/context on historical reconstruction.
    data.pop('comparison_context_policy')
    legacy=citation_audit_input(data,sources())
    assert 'report_assertions' not in legacy and 'related_report_claim_ids' not in legacy['audit_jobs'][0]


def cached_executor(tmp_path):
    executor=LiveArxivRagExecutor.__new__(LiveArxivRagExecutor)
    executor.documents=SimpleNamespace(root=tmp_path/'documents'); executor.documents.root.mkdir()
    executor.source_clues={}; executor.retrieval_deadline=time.monotonic()+120
    executor.observations=[]; executor.run_dir=tmp_path/'run'
    executor.evidence_store=SimpleNamespace(lexical_search=lambda *a,**k:[],get_chunks=lambda ids:[])
    executor.search_function=lambda *a,**k:{'status':'rate_limited','papers':[],'retry_after':60}
    return executor


def cache_paper(executor, paper_id='2005.12872v3', title='End-to-End Object Detection with Transformers', **changes):
    folder=executor.documents.root/('arxiv-'+paper_id.replace('.','-')); folder.mkdir()
    payload=b'%PDF-1.4\nTEST FIXTURE ONLY\n%%EOF'
    (folder/'source.pdf').write_bytes(payload)
    metadata={'paper_id':paper_id,'document_id':folder.name,'title':title,
        'official_url':'https://arxiv.org/abs/'+paper_id,'content_hash':hashlib.sha256(payload).hexdigest(),**changes}
    (folder/'metadata.json').write_text(json.dumps(metadata),encoding='utf8')
    return folder


def test_title_or_cache_lookup_does_not_require_intersection_in_paper_body(tmp_path):
    executor=cached_executor(tmp_path)
    cache_paper(executor); cache_paper(executor,'2304.02643v1','Segment Anything')
    executor.evidence_store.lexical_search=lambda *a,**k:pytest.fail('exact title registry lookup must not use body AND')
    result=executor._search('(ti:"End-to-End Object Detection with Transformers" OR ti:"Segment Anything")',5)
    assert result['status']=='ok' and result['upstream_status']=='rate_limited'
    assert len(result['papers'])==2 and result['retrieval_origin']=='verified_local_public_cache'
    assert result['cache_fallback_diagnostic']['match_basis']=='exact_title_registry'
    assert result['cache_fallback_diagnostic']['verified_papers']==2
    assert all('evidence_id' not in p for p in result['papers']) # Candidates, not approved evidence.


@pytest.mark.parametrize('fault',['hash','official_url','private','date_scope','deadline'])
def test_cache_match_never_bypasses_hash_source_or_scope(tmp_path,fault):
    executor=cached_executor(tmp_path)
    changes={'content_hash':'wrong'} if fault=='hash' else {'official_url':'https://example.test/private'} if fault=='official_url' else {}
    folder=cache_paper(executor,**changes)
    if fault=='private': folder.rename(executor.documents.root/'uploaded-private')
    if fault=='date_scope': executor.source_clues['publication_window']={'start_year':2025}
    if fault=='deadline': executor.retrieval_deadline=time.monotonic()
    assert executor._cached_public_papers('ti:"End-to-End Object Detection with Transformers"',5)==[]


@pytest.mark.parametrize('query',['ti:"Segment Anything" AND abs:forgery','ti:"Segment Anything" ANDNOT abs:medical'])
def test_constrained_query_is_not_simplified_to_title_union(tmp_path,query):
    executor=cached_executor(tmp_path); cache_paper(executor)
    seen=[]
    executor.evidence_store.lexical_search=lambda *a,**k: seen.append(a) or []
    assert executor._cached_public_papers(query,5)==[] and not seen
    assert executor.cache_fallback_diagnostic['reason_code']=='CACHE_QUERY_SCOPE_UNVERIFIABLE'


def test_recorded_sam_query_cannot_recover_detr_or_clip_by_body_term_overlap(tmp_path):
    executor=cached_executor(tmp_path); cache_paper(executor)
    executor.evidence_store.lexical_search=lambda *a,**k:pytest.fail('cannot validate abstract predicates from body FTS')
    query='(ti:"Segment Anything" OR abs:"Segment Anything") AND abs:"promptable segmentation"'
    result=executor._search(query,5)
    assert result['status']=='rate_limited' and result['papers']==[]
    assert result['cache_fallback_diagnostic']['reason_code']=='CACHE_QUERY_SCOPE_UNVERIFIABLE'


def test_missing_cache_is_explained_without_hiding_upstream_failure(tmp_path):
    executor=cached_executor(tmp_path)
    result=executor._search('ti:"Segment Anything"',5)
    assert result['status']=='rate_limited'
    assert result['cache_fallback_diagnostic']['reason_code']=='NO_VERIFIED_PUBLIC_CACHE'
    assert executor.observations[0]['source_status']=='cache_fallback_attempt'


def test_real_workflow_hands_the_same_table_to_writer_and_full_audit(tmp_path):
    from test_multi_agent_pipeline_v2 import agents, pipeline
    from test_multi_agent_report_fields import audit
    configured, calls=agents(); seen=[]
    data=draft(); data['claims'][0].update(text='表格读数中16与32并列。',scope_note='',qualification='')
    def writer(packet):
        supplied=next(i['payload'] for i in packet['inputs'] if i['payload'].get('schema_version')=='sciassistant.comparison-observations/v1')
        assert supplied['records'][0]['scalar_columns'][0]['minimum_row_indices']==[1,2]
        seen.append('writer'); calls.append('writer')
        return {'output':data}
    def auditor(packet):
        supplied=next(i['payload'] for i in packet['inputs'] if i['payload'].get('schema_version')=='sciassistant.citation-audit-input/v1')
        assert supplied['comparison_observations']['records'][0]['scalar_columns'][0]['minimum_row_indices']==[1,2]
        assert supplied['report_assertions'][0]['report_fields']['text']==data['claims'][0]['text']
        seen.append('auditor'); calls.append('citation_auditor')
        value=audit(data)
        value['claim_results'][0]['source_witnesses'][0]['quote']='Rank r | val loss | BLEU\n4 | 1.18 | 70.38'
        return {'output':value}
    configured.writer.handler=writer; configured.citation_auditor.handler=auditor
    flow,_=pipeline(tmp_path,configured)
    evidence=sources(); evidence['evidence'][0].update(group_id='g1',group_ids=['g1'])
    flow.executor.execute=lambda *a,**k: {**deepcopy(evidence),'observations':[]}
    result=flow.run('comparison-handoff','owner','解释表格。')
    assert seen==['writer','auditor'] and result['run']['model_calls_used']==5
    assert result['run']['status']=='completed',result
