"""Internal gateway failures never expose exception, path or credential text."""

from pathlib import Path
from unittest import mock

import pymysql

import app as gateway


SECRET = "private-db-host-password-path-canary"


def _headers():
    token = gateway.generate_token(7, "person", 0)
    return {"Authorization": f"Bearer {token}"}


def _assert_safe(response, expected_status, expected_code):
    assert response.status_code == expected_status
    payload = response.get_json()
    assert payload == {
        "success": False,
        "error": expected_code,
        "message": ("数据库服务暂时不可用，请稍后重试。"
                    if expected_code == "DATABASE_UNAVAILABLE"
                    else "服务器内部错误，请稍后重试。"),
    }
    assert SECRET not in response.get_data(as_text=True)


def test_db_decorator_redacts_connection_failure_before_route_runs():
    with mock.patch.object(gateway, "_current_auth_version", return_value=0), \
         mock.patch.object(
             gateway, "get_db_connection", side_effect=pymysql.MySQLError(SECRET)
         ), mock.patch.object(gateway.logger, "error") as logged:
        response = gateway.app.test_client().post(
            "/api/chat/sessions", json={"title": "offline"}, headers=_headers())
    _assert_safe(response, 503, "DATABASE_UNAVAILABLE")
    assert SECRET not in repr(logged.call_args)
    assert logged.call_args.args == (
        "Gateway operation failed: operation=%s error_type=%s",
        "create_chat_session",
        "MySQLError",
    )


def test_db_decorator_rolls_back_and_closes_on_query_failure():
    connection = mock.MagicMock()
    cursor = connection.cursor.return_value.__enter__.return_value
    cursor.execute.side_effect = pymysql.MySQLError(SECRET)
    with mock.patch.object(gateway, "_current_auth_version", return_value=0), \
         mock.patch.object(gateway, "get_db_connection", return_value=connection):
        response = gateway.app.test_client().post(
            "/api/chat/sessions", json={"title": "offline"}, headers=_headers())
    _assert_safe(response, 503, "DATABASE_UNAVAILABLE")
    connection.rollback.assert_called_once_with()
    connection.close.assert_called_once_with()


def test_generic_internal_failure_uses_fixed_500_without_exception_text():
    with gateway.app.app_context(), mock.patch.object(gateway.logger, "error") as logged:
        response, status = gateway._safe_internal_failure(
            "offline_test", RuntimeError(SECRET))
    response.status_code = status
    _assert_safe(response, 500, "INTERNAL_ERROR")
    assert SECRET not in repr(logged.call_args)


def test_login_database_failure_is_safe_503():
    with mock.patch.object(
        gateway, "get_db_connection", side_effect=pymysql.MySQLError(SECRET)
    ):
        response = gateway.app.test_client().post(
            "/api/login", json={"loginId": "person", "password": "valid-password"})
    _assert_safe(response, 503, "DATABASE_UNAVAILABLE")


def test_source_has_no_direct_exception_text_in_json_or_sensitive_traceback_logging():
    source = Path(gateway.__file__).read_text(encoding="utf-8")
    forbidden = (
        "jsonify({'error': str(e)})",
        "message': str(e)",
        "message': f'文件上传失败: {str(e)}'",
        "logger.error(traceback.format_exc())",
        'logger.error("检查报告归属失败: %s", exc)',
        'logger.error("检查文件归属失败: %s", exc)',
    )
    assert all(item not in source for item in forbidden)
