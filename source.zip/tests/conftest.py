"""Test-only configuration required before modules import the Flask app."""
import os
import atexit
from pathlib import Path
from tempfile import TemporaryDirectory


# The application deliberately rejects a missing production signing key.  Test
# collection imports ``app`` directly, so provide a stable non-production key
# unless a caller intentionally supplies its own configuration.
os.environ.setdefault("APP_ENV", "test")
os.environ.setdefault("SECRET_KEY", "test-only-stable-signing-key")

# Pool regressions explicitly DELETE cooldown rows. Never let a collection
# import/private dotenv or caller's live state path make those production rows.
_runtime_test_state = TemporaryDirectory(prefix="sciassistant-pytest-state-")
os.environ["MODEL_KEY_POOL_STATE_PATH"] = str(Path(_runtime_test_state.name) / "keys.sqlite3")
# Loading Web task snapshots can itself mark active tasks restart-interrupted.
# Isolate before collection, not only inside fixtures after imports happened.
os.environ["SCIASSISTANT_TASK_STATE_DIR"] = str(Path(_runtime_test_state.name) / "task-state")
# Gateway creation writes ownership independently of Web task snapshots. Tests
# replace the in-memory map with fixtures, so allowing the real owner path here
# would atomically replace live bindings with e.g. "new-task" / "owner-1".
# Override caller/private-dotenv paths before collection imports app as well.
os.environ["SCIASSISTANT_TASK_OWNER_STATE_PATH"] = str(Path(_runtime_test_state.name) / "task-owners.json")
os.environ["SCIASSISTANT_CONTEXT_FILE_OWNER_STATE_PATH"] = str(Path(_runtime_test_state.name) / "context-owners.json")
os.environ["SCIASSISTANT_PDF_SESSION_STATE_PATH"] = str(Path(_runtime_test_state.name) / "pdf-sessions.sqlite3")
os.environ["SCIASSISTANT_RESEARCH_LIBRARY_STATE_PATH"] = str(Path(_runtime_test_state.name) / "research-library.sqlite3")
os.environ['SCIASSISTANT_USER_CREDENTIAL_DB'] = str(Path(_runtime_test_state.name) / 'user-credentials.sqlite3')
os.environ['SCIASSISTANT_USER_RUNTIME_ROOT'] = str(Path(_runtime_test_state.name) / 'users')
atexit.register(_runtime_test_state.cleanup)
