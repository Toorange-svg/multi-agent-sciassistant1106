"""Explicit scientific scope/metric checks, not keyword-based semantic approval."""
from copy import deepcopy

import pytest

from multi_agent_agents import AgentContractError
from multi_agent_live import normalize_live_result, ROLE_PROMPTS
from multi_agent_quality import (SCOPE_AUDIT_SCHEMA, WITNESS_AUDIT_SCHEMA, FIELD_AUDIT_SCHEMA, ABSENCE_AUDIT_SCHEMA, SCOPE_CHECKS, check_audit,
                                 citation_audit_input, publication_rejections)
from test_multi_agent_protocol_recovery import audit_data


def draft(kind="technical"):
    return {"schema_version": "sciassistant.claim-draft/v2", "claims": [{
        "claim_id": "c1", "text": "该研究的ViT变体用于人脸伪造检测。", "scope_note": "",
        "qualification": "仅该实验。", "claim_type": kind, "evidence_ids": ["e1"]}]}


def audit(data):
    value = audit_data(data, schema=SCOPE_AUDIT_SCHEMA)
    for row in value["claim_results"]:
        row["scope_checks"] = {key: "supported" for key in SCOPE_CHECKS}
    return value


def test_four_explicit_checks_preserved_without_auto_approval():
    data = draft()
    value = audit(data)
    normalized = normalize_live_result("citation_auditor", {"output": value})["output"]
    assert normalized["claim_results"][0]["scope_checks"] == value["claim_results"][0]["scope_checks"]
    checked = check_audit(normalized, data)
    assert checked["contract_errors"] == []
    assert publication_rejections(checked, data) == set()


@pytest.mark.parametrize("dimension", SCOPE_CHECKS)
@pytest.mark.parametrize("finding", ["needs_review", "unsupported"])
def test_explicit_quality_problem_cannot_be_declared_approved(dimension, finding):
    data = draft()
    value = audit(data)
    value["claim_results"][0]["scope_checks"][dimension] = finding
    checked = check_audit(value, data)
    assert "AUDIT_SCOPE_VERDICT_INCONSISTENT" in checked["contract_errors"]
    assert publication_rejections(checked, data) == {"c1"}


@pytest.mark.parametrize("bad", [None, {}, [], {"family_scope": "supported"},
    {**dict.fromkeys(SCOPE_CHECKS, "supported"), "extra": "supported"},
    {**dict.fromkeys(SCOPE_CHECKS, "supported"), "task_scope": "auto_approved"},
    {**dict.fromkeys(SCOPE_CHECKS, "supported"), "metric_semantics": []}])
def test_invalid_checks_rejected_not_filled_or_guessed(bad):
    data = draft()
    value = audit(data)
    value["claim_results"][0]["scope_checks"] = bad
    assert "AUDIT_SCOPE_CHECKS_INVALID" in check_audit(value, data)["contract_errors"]


def test_missing_checks_remain_missing_after_envelope_normalization():
    data = draft()
    value = audit(data)
    del value["claim_results"][0]["scope_checks"]
    normalized = normalize_live_result("citation_auditor", {"output": value})["output"]
    assert "scope_checks" not in normalized["claim_results"][0]
    assert check_audit(normalized, data)["contract_errors"]


def test_quantitative_metric_cannot_be_skipped_but_definition_needs_no_benchmark():
    qualitative = draft()
    value = audit(qualitative)
    value["claim_results"][0]["scope_checks"]["metric_semantics"] = "not_applicable"
    assert check_audit(value, qualitative)["contract_errors"] == []
    assert "AUDIT_QUANTITATIVE_METRIC_UNCHECKED" in check_audit(value, draft("quantitative"))["contract_errors"]


def test_consistent_semantic_rejection_blocks_only_claim_and_dependencies():
    data = draft()
    data["claims"] += [{**data["claims"][0], "claim_id": "c2", "text": "独立支持的事实。"},
                       {**data["claims"][0], "claim_id": "c3", "depends_on_claim_ids": ["c1"]}]
    value = audit(data)
    row = value["claim_results"][0]
    row.update(decision="rejected", reason_code="TASK_SCOPE_OVERSTATED")
    row["scope_checks"]["task_scope"] = "unsupported"
    value.update(status="needs_revision", rejected_claim_ids=["c1"],
                 issues=[{"claim_id": "c1", "reason_code": "TASK_SCOPE_OVERSTATED"}])
    checked = check_audit(value, data)
    assert checked["contract_errors"] == []
    assert publication_rejections(checked, data) == {"c1", "c3"}


def test_historical_v3_readable_but_new_live_cannot_downgrade_protocol():
    data = draft()
    old = audit_data(data, schema="sciassistant.citation-audit/v3")
    before = deepcopy(old)
    assert check_audit(old, data)["contract_errors"] == []
    normalize_live_result("citation_auditor", {"output": old})
    with pytest.raises(AgentContractError):
        normalize_live_result("citation_auditor", {"output": old}, require_current=True)
    assert old == before


def test_source_context_uses_only_cited_approved_metadata_not_labels_as_truth():
    data = draft()
    data["claims"][0]["evidence_ids"] = ["e1", "unapproved", "missing"]
    evidence = {"evidence": [{"evidence_id": "e1", "paper_id": "paper1", "review_status": "approved",
        "title": "DeepFake Face Detection", "locator": {"page": 3},
        "task_relevance": "direct_task_evidence", "source_domain": ""},
        {"evidence_id": "unapproved", "title": "Unknown", "review_status": "pending"},
        {"evidence_id": "uncited", "review_status": "approved", "title": "Other"}]}
    original = deepcopy((data, evidence))
    result = citation_audit_input(data, evidence)
    assert (data, evidence) == original
    assert result["required_scope_checks"] == list(SCOPE_CHECKS)
    row = result["claims"][0]
    assert [source["evidence_id"] for source in row["source_context"]] == ["e1"]
    assert row["source_context"][0]["title"] == "DeepFake Face Detection"
    assert row["source_context"][0]["page"] == 3
    assert row["source_context"][0]["source_domain"] == ""  # No invented domain decision.
    assert row["unavailable_evidence_ids"] == ["unapproved", "missing"]
    assert "decision" not in row


def test_ambiguous_reported_percent_not_automatically_converted():
    data = draft("quantitative")
    data["claims"][0]["text"] = "作者写作“+25.90% acc”；现有片段不足以判断相对百分比或百分点。"
    result = citation_audit_input(data, {"evidence": []})
    assert result["claims"][0]["visible_text"] == data["claims"][0]["text"]
    assert "verified baseline/calculation" in result["scope_instructions"]
    assert "decision" not in result["claims"][0]


def test_role_prompts_require_four_boundaries_not_general_benchmark_gate():
    assert ABSENCE_AUDIT_SCHEMA in ROLE_PROMPTS["citation_auditor"]
    assert all(key in ROLE_PROMPTS["citation_auditor"] for key in SCOPE_CHECKS)
    assert "controlled" in ROLE_PROMPTS["writer"]
    assert "FACE" in ROLE_PROMPTS["writer"]
    assert "percentage points" in ROLE_PROMPTS["writer"]
