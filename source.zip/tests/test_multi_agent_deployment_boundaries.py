"""Cache recovery, task session inheritance, and bounded report rendering."""
import os
import math
import sys
from types import SimpleNamespace
from unittest.mock import patch

from multi_agent_live import parser_process_options
from multi_agent_rag import EvidenceStore, RagIndexer, build_chunks
from tests.test_multi_agent_rag import FakeEmbedding, FakeVectorStore, metadata, blocks
from multi_agent_report import _source_view
import pytest


def test_posix_nested_parser_inherits_supervised_session(monkeypatch):
    monkeypatch.setenv("SCIASSISTANT_SUPERVISED_CLI", "1")
    with patch("multi_agent_live.os.name", "posix"):
        assert parser_process_options() == {"start_new_session": False}
    monkeypatch.delenv("SCIASSISTANT_SUPERVISED_CLI")
    with patch("multi_agent_live.os.name", "posix"):
        assert parser_process_options() == {"start_new_session": True}


def test_windows_parser_is_hidden_and_tree_owned():
    with patch("multi_agent_live.os.name", "nt"):
        assert "creationflags" in parser_process_options()
        assert "start_new_session" not in parser_process_options()


class RestorableVector(FakeVectorStore):
    def __init__(self):
        super().__init__()
        self.count = 0

    def document_chunk_count(self, document_id):
        return self.count

    def upsert(self, chunks, vectors):
        super().upsert(chunks, vectors)
        self.count = len(chunks)


def test_lost_vector_volume_rebuilds_despite_fts_hash(tmp_path):
    store, embedding, vectors = EvidenceStore(tmp_path / "evidence.sqlite3"), FakeEmbedding(), RestorableVector()
    indexer = RagIndexer(store, embedding, vectors, vector_required=True)
    first = indexer.index(metadata(), blocks())
    assert first["changed"] and vectors.count
    before = vectors.upserts
    assert not indexer.index(metadata(), blocks())["changed"]
    assert vectors.upserts == before
    vectors.count = 0
    repaired = indexer.index(metadata(), blocks())
    assert repaired["changed"] and repaired["vector_indexed"]
    assert repaired["repair_reason"] == "VECTOR_INDEX_MISSING_OR_INCOMPLETE"
    assert vectors.count and vectors.upserts == before + 1


def test_partial_vector_restore_is_not_a_cache_hit(tmp_path):
    vectors = RestorableVector()
    indexer = RagIndexer(EvidenceStore(tmp_path / "evidence.sqlite3"), FakeEmbedding(), vectors, vector_required=True)
    result = indexer.index(metadata(), blocks())
    vectors.count = result["chunk_count"] + 1
    assert indexer.index(metadata(), blocks())["repair_reason"] == "VECTOR_INDEX_MISSING_OR_INCOMPLETE"


@pytest.mark.parametrize("width,height", [(80000, 80000), (100000000, 1)])
def test_pdf_page_render_has_pixel_and_dimension_limits(tmp_path, monkeypatch, width, height):
    pdf = tmp_path / "pdf/paper/source.pdf"
    pdf.parent.mkdir(parents=True)
    pdf.write_bytes(b"fixture")
    dimensions = []
    class Page:
        rect = SimpleNamespace(width=width, height=height)
        def get_pixmap(self, matrix):
            dimensions.append((math.ceil(width * matrix[0]), math.ceil(height * matrix[1])))
            return SimpleNamespace(save=lambda path: path.write_bytes(b"fixture-pixels"))
    class Document:
        page_count = 1
        def __enter__(self): return self
        def __exit__(self, *_): pass
        def __getitem__(self, _): return Page()
    monkeypatch.setitem(sys.modules, "pymupdf", SimpleNamespace(open=lambda _: Document(), Matrix=lambda x, y: (x, y)))
    assert _source_view(tmp_path, {"document_id": "paper", "citation": 1, "locator": {"page": 1}}) == "source-1.html"
    assert dimensions[0][0] * dimensions[0][1] <= 5_000_000
    assert max(dimensions[0]) <= 8192
