import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from deepdiver_v2.src import query_router


class LiteratureDiskCacheTests(unittest.TestCase):
    def test_nonempty_search_result_survives_memory_cache_clear(self):
        papers = [{"paper_id": "2401.00001", "title": "Cached paper"}]
        with tempfile.TemporaryDirectory() as directory, patch.object(
            query_router, "_LITERATURE_CACHE_DB", Path(directory) / "cache.sqlite3"
        ):
            query_router._LITERATURE_CACHE.clear()
            query_router.put_literature_cache("arxiv", "test query", papers, 5)
            query_router._LITERATURE_CACHE.clear()
            restored = query_router.get_literature_cache("arxiv", "test query", 5)

        self.assertEqual(restored, papers)

    def test_empty_results_are_not_persisted(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(
            query_router, "_LITERATURE_CACHE_DB", Path(directory) / "cache.sqlite3"
        ):
            query_router._LITERATURE_CACHE.clear()
            query_router.put_literature_cache("arxiv", "empty query", [], 5)
            self.assertIsNone(query_router.get_literature_cache("arxiv", "empty query", 5))


if __name__ == "__main__":
    unittest.main()
