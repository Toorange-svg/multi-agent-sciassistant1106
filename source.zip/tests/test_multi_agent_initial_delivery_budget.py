"""Optional research must not consume the estimated whole-report delivery path."""
from copy import deepcopy
import json

import pytest

from multi_agent_agents import ArtifactDirectory
from multi_agent_workflow import WorkflowStore
from multi_agent_pipeline_v2 import LiteraturePipelineV2, DeterministicLiteratureExecutor
from multi_agent_report_contracts import compile_user_requirements, report_budget
from multi_agent_sections import initial_delivery_budget, INITIAL_DELIVERY_BUDGET_POLICY
from tools.multi_agent_cli import _mock_agents, _mock_search
from test_multi_agent_report_requirements import plan_for_case
from test_multi_agent_report_fields import QUOTE
from test_multi_agent_audit_batches import good_audit, report_for


def requirements(count):
    case = {'question': ''.join(f'请解释第{i}个机制。' for i in range(count)),
            'requirements': [{'question_quote': f'请解释第{i}个机制。', 'answer_kind': 'mechanism'}
                             for i in range(count)]}
    plan = plan_for_case(case)
    return case, plan, compile_user_requirements(case['question'], plan)


@pytest.mark.parametrize('count,expected', [(1, 3), (2, 5), (6, 5), (12, 5), (13, 5), (17, 5), (25, 6), (80, 10)])
def test_standard_reserves_source_batches_global_and_one_protocol_correction(count, expected):
    _, plan, ledger = requirements(count)
    original = deepcopy((plan, ledger))
    receipt = initial_delivery_budget(ledger, plan, 'standard')
    assert receipt['estimated_delivery_calls'] == expected
    assert receipt['estimated_claim_count'] == count
    assert receipt['estimate_is_not_output_limit'] and not receipt['semantic_auto_approval']
    assert not receipt['automatic_profile_escalation'] and (plan, ledger) == original


@pytest.mark.parametrize('available', [True, False])
def test_used_protocol_correction_is_not_reserved_again(available):
    _, plan, ledger = requirements(17)
    result = initial_delivery_budget(ledger, plan, 'standard', protocol_retry_available=available)
    assert result['estimated_delivery_calls'] == 4 + int(available)


def test_guidance_is_not_an_extra_scientific_claim_or_model_call():
    _, plan, ledger = requirements(12)
    ledger['requirements'] += [{**deepcopy(ledger['requirements'][0]),
        'requirement_id': f'guide-{i}', 'answer_kind': 'constraint'} for i in range(50)]
    result = initial_delivery_budget(ledger, plan, 'standard')
    assert result['content_requirement_count'] == 12 and result['estimated_delivery_calls'] == 5
    assert len(ledger['requirements']) == 62  # No requirement deleted to fit a budget.


@pytest.mark.parametrize('ledger', [None, {}, {'requirements': []}])
@pytest.mark.parametrize('profile,baseline', [('standard', 2), ('enhanced', 7)])
def test_legacy_without_literal_requirements_keeps_existing_behavior(ledger, profile, baseline):
    result = initial_delivery_budget(ledger, {}, profile)
    assert result['estimated_delivery_calls'] == baseline
    assert result['estimated_claim_count'] == 0


def test_enhanced_keeps_seven_call_floor_without_profile_escalation():
    _, plan, ledger = requirements(17)
    result = initial_delivery_budget(ledger, plan, 'enhanced')
    assert result['estimated_delivery_calls'] == 7
    assert report_budget('enhanced')['model_call_limit'] == 20


@pytest.mark.parametrize('has_source', [True, False])
def test_recorded_reserve_applies_only_after_real_approval(tmp_path, has_source):
    _, plan, ledger = requirements(17)
    store = WorkflowStore(tmp_path/'workflow.sqlite3')
    store.create_run('reserve', 'owner', report_profile='standard')
    flow = LiteraturePipelineV2(store, ArtifactDirectory(tmp_path/'artifacts'),
        _mock_agents(), DeterministicLiteratureExecutor(_mock_search), event_path=tmp_path/'events.jsonl')
    flow._skill_ledger = ledger
    refs = {}
    reserve = flow._reserve_initial_delivery('reserve', plan,
        {'allowed_evidence_ids': ['existing-approved'] if has_source else []}, refs)
    result = flow.artifacts.get(refs['initial_delivery_budget'])
    assert reserve == (5 if has_source else 2)
    assert result['applied_to_optional_research'] is has_source
    assert result['policy'] == INITIAL_DELIVERY_BUDGET_POLICY
    assert store.get_run('reserve')['model_calls_used'] == 0


@pytest.mark.parametrize('bad_witness', [False, True])
@pytest.mark.parametrize('ask_count', [6, 17])
def test_full_standard_workflow_protects_nineteen_claims_after_reviewer_correction(tmp_path, bad_witness, ask_count):
    workers = _mock_agents()
    original_review = workers.reviewer.handler
    seen = []
    def reviewer(packet):
        result = original_review(packet)
        seen.append(1)
        if len(seen) == 1:
            result['output']['allowed_evidence_ids'] = ['forged-source']
        else:
            result['output']['coverage'][0]['status'] = 'partial'
        return result
    workers.reviewer.handler = reviewer
    original_writer = workers.writer.handler
    def writer(packet):
        result = original_writer(packet)
        template = result['output']['claims'][0]
        result['output']['claims'] = [{**deepcopy(template), 'claim_id': f'c{i}'} for i in range(1,20)]
        result['output']['claims'][-1]['depends_on_claim_ids'] = ['c1']
        return result
    workers.writer.handler = writer
    phases = []
    def auditor(packet):
        whole = next((i['payload'] for i in packet['inputs']
            if i['payload'].get('schema_version') == 'sciassistant.report-global-review-input/v1'), None)
        if whole:
            phases.append('global')
            return {'output': {'schema_version': 'sciassistant.citation-audit/v7', 'status': 'passed',
                'rejected_claim_ids': [], 'issues': [], 'claim_results': [], 'report_review': report_for(whole)}}
        supplied = next(i['payload'] for i in packet['inputs']
            if i['payload'].get('schema_version') == 'sciassistant.citation-audit-input/v1')
        claims = [{**j['claim'], **j['claim']['report_fields']} for j in supplied['audit_jobs']]
        phases.append(len(claims))
        output = good_audit({'claims': claims})
        if bad_witness and claims[0]['claim_id'] == 'b1-c1':
            output['claim_results'][0]['source_witnesses'][0]['quote'] = 'This sentence was never printed in the source.'
        return {'output': output}
    workers.citation_auditor.handler = auditor
    def search(query, limit):
        result = _mock_search(query, limit)
        for paper in result['papers']: paper['abstract'] = QUOTE
        return result
    store, artifacts = WorkflowStore(tmp_path/'workflow.sqlite3'), ArtifactDirectory(tmp_path/'artifacts')
    flow = LiteraturePipelineV2(store, artifacts, workers, DeterministicLiteratureExecutor(search),
        event_path=tmp_path/'events.jsonl', report_profile='standard')
    question = ''.join(f'请解释第{i}个机制。' for i in range(ask_count))
    result = flow.run('complete-audit', 'owner', question)
    final = artifacts.get(result['final_artifact_id'])
    assert result['run']['failure_code'] is None, result
    assert len(seen) == 2  # Exactly one Reviewer correction; no optional gap re-review.
    events = [json.loads(s) for s in (tmp_path/'events.jsonl').read_text(encoding='utf-8').splitlines()]
    assert not any(e['event'] == 'gap_recovery_started' for e in events)
    assert any(e['event'] == 'gap_recovery_skipped' and e.get('required_delivery_calls') == 5 for e in events)
    assert phases == ([12,12,7,'global'] if bad_witness else [12,7,'global'])
    audit = artifacts.get(final['artifact_refs']['audit'])
    assert audit['source_unreviewed_claim_ids'] == []
    publication = artifacts.get(final['artifact_refs']['publication'])
    published = {r['claim_id'] for r in publication['claims'] if r['published']}
    assert len(published) == (17 if bad_witness else 19)
    if bad_witness: assert not {'b1-c1','b1-c19'}.intersection(published)
    assert result['run']['model_calls_used'] <= 10
    assert len(artifacts.get(final['artifact_refs']['draft'])['claims']) == 19
