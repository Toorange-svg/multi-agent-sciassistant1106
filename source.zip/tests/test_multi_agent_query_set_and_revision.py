"""Preserve useful retrieval actions; a disclaimer is not a repaired assertion."""
from copy import deepcopy

import pytest

from multi_agent_pipeline_v2 import prioritize_named_entity_actions, prioritize_source_title_actions, WorkflowError
from multi_agent_quality import check_claim_revision, publication_rejections
from multi_agent_live import ROLE_PROMPTS
from test_multi_agent_pipeline_v2 import agents, pipeline


CLIP_TITLE = "Learning Transferable Visual Models From Natural Language Supervision"
VIT_TITLE = "An Image is Worth 16x16 Words: Transformers for Image Recognition at Scale"


def searches(queries):
    return [{"request_id": f"r{i}", "action": "request_arxiv_search", "arguments": {"group_id": "g1", "query": query}}
            for i, query in enumerate(queries, 1)]


def test_entity_in_second_query_does_not_destroy_first_original_paper_query():
    plan = {"groups": [{"id": "g1", "question": "CLIP DINOv2 ViT relation", "source_hints": [VIT_TITLE, CLIP_TITLE]}]}
    requests = searches([f'(ti:"{CLIP_TITLE}" OR abs:"CLIP" AND abs:"vision transformer")',
                         '(abs:"DINOv2" OR abs:"self-supervised" AND abs:"vision transformer")'])
    original = deepcopy((plan, requests))
    pinned, _ = prioritize_named_entity_actions(plan, requests, {"explicit_entities": ["CLIP", "DINOv2", "ViT"]})
    final, changes = prioritize_source_title_actions(plan, pinned, {"explicit_entities": ["CLIP", "DINOv2", "ViT"]})
    assert final == requests and (plan, requests) == original
    assert len(final) == 2 and not changes


@pytest.mark.parametrize("query", ['abs:"DINOv20"', 'abs:"DINOv2extended"'])
def test_entity_substrings_are_not_coverage(query):
    plan = {"groups": [{"id": "g1", "question": "DINOv2"}]}
    result, changes = prioritize_named_entity_actions(plan, searches([query]), {"explicit_entities": ["DINOv2"]})
    assert result[0]["arguments"]["query"] == '(ti:"DINOv2" OR abs:"DINOv2")'
    assert len(changes) == 1


def test_negative_entity_queries_are_not_rewritten():
    requests = searches(['abs:"CLIP" NOT abs:"DINOv2"', 'abs:"other"'])
    assert prioritize_named_entity_actions({"groups": [{"id": "g1", "question": "DINOv2"}]}, requests,
                                            {"explicit_entities": ["DINOv2"]}) == (requests, [])


@pytest.mark.parametrize("query", [f'ti:"{CLIP_TITLE}"', 'ti:"Learning Transferable Visual Models"'])
def test_second_title_hint_can_satisfy_original_slot_without_overwrite(query):
    plan = {"groups": [{"id": "g1", "source_hints": [VIT_TITLE, CLIP_TITLE]}]}
    requests = searches([query, 'abs:"DINOv2"'])
    final, changes = prioritize_source_title_actions(plan, requests, {"explicit_entities": []})
    assert final == requests
    assert not changes or all(row["query_replaced"] is False for row in changes)


@pytest.mark.parametrize("bad", ['x', 'unsafe" title', 42, 'https://invalid.test/paper'])
def test_later_title_hint_is_validated_even_if_first_already_matches(bad):
    with pytest.raises(WorkflowError):
        prioritize_source_title_actions({"groups": [{"id": "g1", "source_hints": [CLIP_TITLE, bad]}]},
                                        searches([f'ti:"{CLIP_TITLE}"', 'abs:"DINOv2"']), {"explicit_entities": []})


def draft_and_feedback(reason="OVERSTATED_SCOPE"):
    draft = {"claims": [{"claim_id": "c1", "text": "All visual encoders use the same mechanism.", "evidence_ids": ["ev1"],
                          "scope_note": "", "confidence": "medium", "section": "direct_conclusion"},
                         {"claim_id": "c2", "text": "This experiment uses a frozen classifier.", "evidence_ids": ["ev1"]}]}
    feedback = {"model_audit": {"claim_results": [{"claim_id": "c1", "decision": "needs_review", "reason_code": reason}]},
                "code_issues": []}
    return draft, feedback


@pytest.mark.parametrize("reason", ["OVERSTATED_SCOPE", "UNSUPPORTED_EXTRAPOLATION", "UNSUPPORTED_NUMBER",
                                   "UNSUPPORTED_CLAIM", "UNAPPROVED_CITATION"])
def test_disclaimer_only_change_does_not_rescue_unsupported_core(reason):
    old, feedback = draft_and_feedback(reason)
    revised = deepcopy(old)
    revised["claims"][0].update(scope_note="The original mechanism was not verified.", confidence="low")
    check = check_claim_revision(old, revised, feedback)
    assert check["code_issues"] == [{"claim_id": "c1", "reason": "UNCHANGED_UNSUPPORTED_CLAIM",
                                     "prior_claim_id": "c1", "prior_reason_code": reason}]
    assert not check["semantic_auto_approval"]
    assert check["changed_claims_still_require_audit"]
    assert old["claims"][0]["scope_note"] == ""


def test_renaming_or_moving_claim_does_not_hide_same_rejected_assertion():
    old, feedback = draft_and_feedback()
    revised = deepcopy(old)
    revised["claims"][0].update(claim_id="new-id", section="evidence_boundary", text=" All   visual encoders use the same mechanism. ")
    issues = check_claim_revision(old, revised, feedback)["code_issues"]
    assert issues[0]["claim_id"] == "new-id" and issues[0]["prior_claim_id"] == "c1"


@pytest.mark.parametrize("repair", ["reword", "remove", "citation"])
def test_real_edit_is_sent_to_audit_not_automatically_approved(repair):
    old, feedback = draft_and_feedback()
    revised = deepcopy(old)
    if repair == "reword":
        revised["claims"][0]["text"] = "This passage only describes a text encoder, not the visual objective."
    elif repair == "remove":
        revised["claims"] = revised["claims"][1:]
    else:
        revised["claims"][0]["evidence_ids"] = ["other-already-approved-ev"]
    check = check_claim_revision(old, revised, feedback)
    assert not check["code_issues"] and not check["semantic_auto_approval"]


@pytest.mark.parametrize("reason", ["MISSING_QUALIFIER", "SOURCE_DOMAIN_NOT_VISIBLE", "SUPPORTED"])
def test_missing_condition_or_label_can_legitimately_be_fixed_in_scope_note(reason):
    old, feedback = draft_and_feedback(reason)
    revised = deepcopy(old)
    revised["claims"][0]["scope_note"] = "Only in the reported domain, not a universal result."
    assert not check_claim_revision(old, revised, feedback)["code_issues"]


def test_independent_claim_stays_publishable_and_dependencies_are_blocked():
    old, feedback = draft_and_feedback()
    revised = deepcopy(old)
    revised["claims"].append({"claim_id": "c3", "text": "Consequence", "evidence_ids": ["ev1"], "depends_on_claim_ids": ["c1"]})
    audit = {"schema_version": "sciassistant.citation-audit/v3", "status": "passed", "issues": [], "rejected_claim_ids": [],
             "claim_results": [{"claim_id": c["claim_id"], "decision": "approved", "reason_code": "SUPPORTED", "detail": "Supported",
                                "evidence_ids": c["evidence_ids"]} for c in revised["claims"]],
             "code_issues": check_claim_revision(old, revised, feedback)["code_issues"]}
    assert publication_rejections(audit, revised) == {"c1", "c3"}


def test_invalid_citation_type_does_not_crash_revision_comparison():
    old, feedback = draft_and_feedback()
    revised = deepcopy(old)
    revised["claims"][0]["evidence_ids"] = ["ev1", 42]
    assert not check_claim_revision(old, revised, feedback)["code_issues"]
    # This is not an approval: ordinary schema/citation validators reject it.


def test_final_auditor_sees_prior_rejection_and_unchanged_guard_in_full_workflow(tmp_path):
    configured, _ = agents()
    writer_calls, audit_calls = [], []
    def writer(packet):
        writer_calls.append(packet)
        return {"output": {"direct_answer": "A claim", "claims": [
            {"claim_id": "c1", "text": "All visual encoders use the same mechanism.", "evidence_ids": ["arxiv-1"], "scope_note": "Only indirect evidence." if len(writer_calls) > 1 else ""},
            {"claim_id": "c2", "text": "This passage describes a frozen classifier.", "evidence_ids": ["arxiv-1"]}]}}
    def auditor(packet):
        audit_calls.append(packet)
        rejected = len(audit_calls) == 1
        if not rejected:
            schemas = {row["payload"].get("schema_version") for row in packet["inputs"]}
            assert {"sciassistant.audit-revision-context/v1", "sciassistant.claim-revision-check/v1"}.issubset(schemas)
            assert "sciassistant.citation-feedback/v1" not in schemas
            context = next(row["payload"] for row in packet["inputs"]
                           if row["payload"].get("schema_version") == "sciassistant.audit-revision-context/v1")
            assert any(row.get("claim_id") == "c1" and row.get("reason") == "OVERSTATED_SCOPE"
                       for row in context["prior_issues_not_current_verdicts"])
            assert context["current_claim_ids"] == ["c1", "c2"] and not context["semantic_auto_approval"]
            revision = next(row["payload"] for row in packet["inputs"]
                            if row["payload"].get("schema_version") == "sciassistant.claim-revision-check/v1")
            assert any(row["claim_id"] == "c1" and row["reason"] == "UNCHANGED_UNSUPPORTED_CLAIM"
                       for row in revision["code_issues"])
        return {"output": {"schema_version": "sciassistant.citation-audit/v3", "status": "needs_revision" if rejected else "passed",
             "rejected_claim_ids": ["c1"] if rejected else [],
             "issues": [{"claim_id": "c1", "reason_code": "OVERSTATED_SCOPE"}] if rejected else [],
             "claim_results": [{"claim_id": key, "decision": "needs_review" if rejected and key == "c1" else "approved",
                                "reason_code": "OVERSTATED_SCOPE" if rejected and key == "c1" else "SUPPORTED",
                                "detail": "Scope incorrect" if rejected and key == "c1" else "Supported", "evidence_ids": ["arxiv-1"]} for key in ["c1", "c2"]]}}
    configured.writer.handler, configured.citation_auditor.handler = writer, auditor
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("revision-test", "owner", "Compare A")
    assert result["run"]["status"] == "needs_review"
    assert result["run"]["model_calls_used"] == 7
    assert "All visual encoders" not in result["direct_answer"]
    assert "frozen classifier" in result["direct_answer"]
    assert any(row["payload"].get("schema_version") == "sciassistant.citation-feedback/v1"
               for row in writer_calls[1]["inputs"])
    assert list((tmp_path / "artifacts").glob("claim-revision-check-*.json"))


def test_prompts_distinguish_core_repair_and_component_roles():
    assert "THEIR original papers" in ROLE_PROMPTS["planner"]
    assert "SAME core text" in ROLE_PROMPTS["writer"]
    assert "text encoder is not evidence for a visual encoder" in ROLE_PROMPTS["writer"]
    assert "Recheck the original rejection" in ROLE_PROMPTS["citation_auditor"]
    assert "ONE original-title query may OR" in ROLE_PROMPTS["retriever"]
    assert "compare prior_text with current_text" in ROLE_PROMPTS["citation_auditor"]


def test_semantic_reaudit_gets_actual_before_after_text_not_just_old_reason():
    old, feedback = draft_and_feedback()
    revised = deepcopy(old)
    revised["claims"][0]["text"] = "This passage only establishes a text encoder, not a visual mechanism."
    check = check_claim_revision(old, revised, feedback)
    assert check["resolution_targets"] == [{"prior_claim_id": "c1", "prior_reason_code": "OVERSTATED_SCOPE",
        "current_claim_id": "c1", "prior_text": old["claims"][0]["text"], "current_text": revised["claims"][0]["text"],
        "prior_evidence_ids": ["ev1"], "current_evidence_ids": ["ev1"], "change_status": "edited_requires_semantic_reaudit"}]
    assert not check["code_issues"] and not check["semantic_auto_approval"]


def test_removed_claim_remains_removed_in_resolution_targets():
    old, feedback = draft_and_feedback()
    revised = {"claims": [old["claims"][1]]}
    target = check_claim_revision(old, revised, feedback)["resolution_targets"][0]
    assert target["change_status"] == "removed" and target["current_text"] is None
    assert target["current_claim_id"] is None and target["current_evidence_ids"] == []
