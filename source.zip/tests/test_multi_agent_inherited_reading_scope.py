"""Same-clause subjects and production-bounded independent revision calls."""
from copy import deepcopy
import time

import pytest

from multi_agent_quality import check_reading_scope, READING_SCOPE_POLICY, check_claim_revision
from multi_agent_pipeline_v2 import check_draft
from test_multi_agent_quantity_feedback_and_reading_scope import example
from revision_focus_quality_development_20261013.run_revision_case import workflow_role, start_role_case, close_role_case


@pytest.mark.parametrize("text", [
    "论文只报告了各设置下的准确率，未给出统一的泛化损失指标。",
    "本文报告两个设置，但没有进行同条件对照。",
    "作者展示各设置的准确率，并未提供统一的基线。",
    "The paper reports separate accuracies but does not provide a common baseline.",
])
@pytest.mark.parametrize("field", ["text", "scope_note"])
def test_inherited_subject_is_not_rescued_by_another_field(text, field):
    draft, evidence = example()
    draft["claims"][0].update(text="所选片段展示独立设置。", scope_note="", qualification="仅指所选片段。")
    draft["claims"][0][field] = text
    issue = check_reading_scope(draft, evidence)[0]
    assert issue["field"] == field and issue["policy"] == READING_SCOPE_POLICY


@pytest.mark.parametrize("text", [
    "所选原文片段中，论文报告各设置准确率，未给出统一泛化指标。",
    "论文在所选原文片段中报告各设置准确率，未给出统一泛化指标。",
    "不能据此断言论文报告各设置准确率，未给出统一泛化指标。",
    "论文报告准确率。所选片段未给出统一泛化指标。",
    "论文报告准确率；模型未提供输出。",
    "论文报告准确率，模型未提供输出。",
    "The paper reports accuracies. The selected excerpts do not provide a common baseline.",
    "In selected excerpts the paper reports accuracies but does not provide a common baseline.",
])
def test_boundaries_and_actual_scoping_are_preserved(text):
    draft, evidence = example()
    draft["claims"][0].update(scope_note=text)
    assert check_reading_scope(draft, evidence) == []


def test_inherited_field_edit_is_reaudited_not_automatically_published():
    old, evidence = example()
    old["reading_scope_policy"] = READING_SCOPE_POLICY
    old["claims"][0]["qualification"] = ""
    old["claims"][0]["scope_note"] = "论文只报告准确率，未给出统一指标。"
    feedback = {"code_issues": check_draft(old, evidence)}
    new = deepcopy(old)
    new["claims"][0]["scope_note"] = "所选片段未提供统一指标，不能据此判断全文是否报告。"
    result = check_claim_revision(old, new, feedback)
    assert not result["code_issues"] and not result["semantic_auto_approval"]
    assert not check_draft(new, evidence)


def controller(tmp_path, handler, *, calls=10, seconds=360):
    from test_multi_agent_pipeline_v2 import agents, pipeline
    configured, _ = agents()
    configured.writer.handler = handler
    flow, store = pipeline(tmp_path, configured)
    store.create_run("isolated", "test", max_model_calls=calls, time_budget_seconds=seconds)
    flow.deadline = time.monotonic() + seconds
    return flow, store


def test_revision_helper_uses_exact_production_format_retry(tmp_path):
    packets = []
    def writer(packet):
        packets.append(packet)
        if len(packets) == 1:
            return {"status": "failed", "error_code": "MODEL_JSON_INVALID", "output": {"parse_error_type": "JSONDecodeError"}}
        return {"output": {"claims": [{"claim_id": "c1"}], "direct_answer": "draft"}}
    flow, store = controller(tmp_path, writer)
    payloads = [{"schema_version": "test/v1", "approved": ["e1"]}]
    metadata, draft = workflow_role(flow, "isolated", "writer", payloads)
    assert metadata["status"] == "completed" and metadata["usage"]["model_calls"] == 2
    assert store.get_run("isolated")["model_calls_used"] == 2
    assert packets[0]["inputs"] == packets[1]["inputs"]
    assert draft["claims"] == [{"claim_id": "c1"}]
    assert flow.writer_format_retry_used


@pytest.mark.parametrize("code,calls,seconds,expected", [
    ("MODEL_JSON_INVALID", 10, 360, 2),
    ("MODEL_JSON_INVALID", 2, 360, 1),
    ("MODEL_JSON_INVALID", 10, 90, 1),
    ("MODEL_SERVICE_UNAVAILABLE", 10, 360, 1),
])
def test_no_diagnostic_as_draft_and_no_unbounded_retries(tmp_path, code, calls, seconds, expected):
    flow, store = controller(tmp_path, lambda _: {"status": "failed", "error_code": code,
        "output": {"parse_error_type": "JSONDecodeError"}}, calls=calls, seconds=seconds)
    metadata, draft = workflow_role(flow, "isolated", "writer", [{"approved": ["e1"]}])
    assert metadata["status"] == "failed" and draft is None
    assert store.get_run("isolated")["model_calls_used"] == expected
    assert metadata["usage"]["model_calls"] == expected


def test_legacy_draft_publication_policy_is_not_recomputed():
    draft, evidence = example()
    draft["reading_scope_policy"] = "selected-evidence-absence-scope/v2"
    draft["claims"][0]["qualification"] = ""
    draft["claims"][0]["scope_note"] = "论文只报告准确率，未给出统一指标。"
    assert not check_draft(draft, evidence)
    assert check_reading_scope(draft, evidence)  # Explicit current diagnostic only.


@pytest.mark.parametrize("eligible", [True, False])
def test_independent_role_case_has_honest_closed_lifecycle(tmp_path, eligible):
    from multi_agent_workflow import WorkflowStore
    store = WorkflowStore(tmp_path / "workflow.sqlite3")
    start_role_case(store, "test", 360)
    assert store.get_run("test")["status"] == "writing"
    assert store.get_run("test")["model_calls_used"] == 0
    store.transition("test", "auditing")
    assert close_role_case(store, "test", eligible)["status"] == ("needs_review" if eligible else "failed")
