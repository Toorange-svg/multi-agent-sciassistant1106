import json

import pytest

from tools.check_multi_agent_rag import check_retrieval


class FixtureEmbedding:
    model_name = "unit-test-fake"
    dimension = 3
    def embed(self, texts):
        return [[1, 0, 0] if "serving engine" in text else [0, 1, 0] if "Speculative" in text else [0, 0, 1] for text in texts]
    def embed_query(self, query):
        return [0, 0, 1] if query == "garden" else [1, 0, 0]


def vector_factory():
    persisted = {}
    class FakeVector:
        def upsert(self, chunks, vectors):
            for chunk, vector in zip(chunks, vectors):
                persisted[chunk["chunk_id"]] = (chunk["document_id"], vector)
        def search(self, vector, *, limit, document_ids=None):
            scores = [(key, sum(a * b for a, b in zip(value[1], vector))) for key, value in persisted.items()
                      if document_ids is None or value[0] in document_ids]
            return sorted(scores, key=lambda item: -item[1])[:limit]
        def delete_document(self, document_id):
            for key in list(persisted):
                if persisted[key][0] == document_id:
                    del persisted[key]
        def close(self):
            pass
    return lambda *_: FakeVector()


def test_selfcheck_reports_all_invariants_and_preserves_existing_output(tmp_path):
    result = check_retrieval(tmp_path / "run", FixtureEmbedding(), vector_factory())
    assert result["status"] == "passed"
    assert len(result["checks"]) == 12 and all(result["checks"].values())
    assert result["answer_model_calls"] == 0
    saved = (tmp_path / "run" / "summary.json").read_bytes()
    with pytest.raises(FileExistsError):
        check_retrieval(tmp_path / "run", FixtureEmbedding(), vector_factory())
    assert (tmp_path / "run" / "summary.json").read_bytes() == saved


def test_selfcheck_failure_is_recorded_without_exception_details(tmp_path):
    class BrokenEmbedding(FixtureEmbedding):
        def embed(self, texts):
            raise RuntimeError("secret-canary /home/private/credential")
    result = check_retrieval(tmp_path / "run", BrokenEmbedding(), vector_factory())
    assert result["status"] == "failed"
    assert result["error_code"] == "RAG_SELF_CHECK_FAILED"
    assert "secret-canary" not in json.dumps(result)
