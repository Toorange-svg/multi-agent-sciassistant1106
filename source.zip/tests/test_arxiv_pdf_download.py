"""Behavioral checks for download budgets, atomic files, and independent-process reuse."""
import subprocess
import os
import sys
import tempfile
import threading
import time
import unittest
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import Mock, patch

import requests

from deepdiver_v2.src import arxiv_pdf_download as pdf


PDF_BYTES = b"%PDF-1.4\nmock complete document\n%%EOF\n"
ROOT = Path(__file__).resolve().parents[1]


class Response:
    def __init__(self, body=PDF_BYTES, status=200):
        self.body = body
        self.status_code = status

    def __enter__(self):
        return self

    def __exit__(self, *_):
        pass

    def raise_for_status(self):
        if self.status_code >= 400:
            raise requests.HTTPError("HTTP error", response=self)

    def iter_content(self, chunk_size):
        yield self.body


class Clock:
    def __init__(self):
        self.now = 0.0

    def monotonic(self):
        return self.now

    def sleep(self, seconds):
        self.now += seconds


class PdfDownloadTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.output = Path(self.directory.name)
        self.reserve = Mock(return_value=(True, 0.0))
        self.network_cooldown = Mock()
        self.rate_cooldown = Mock()
        self.get = Mock(return_value=Response())

    def download(self, **kwargs):
        return pdf.download_arxiv_pdf(
            "2401.00001", self.output,
            reserve_request=self.reserve,
            network_cooldown=self.network_cooldown,
            rate_limit_cooldown=self.rate_cooldown,
            request_get=self.get, **kwargs,
        )

    def test_complete_cache_is_reused_without_reserving_or_requesting(self):
        path = self.output / "2401.00001.pdf"
        path.write_bytes(PDF_BYTES)
        self.assertEqual(self.download(), str(path))
        self.get.assert_not_called()
        self.reserve.assert_not_called()

    @unittest.skipUnless(os.name == "nt", "Windows byte-range lock regression")
    def test_lock_byte_is_initialised_only_after_acquiring_windows_lock(self):
        import msvcrt
        original_open = Path.open
        original_locking = msvcrt.locking
        state = {"locked": False, "flush_checked": False}
        test = self

        class CheckedStream:
            def __init__(self, stream):
                self.stream = stream
            def __enter__(self):
                return self
            def __exit__(self, *_):
                self.stream.close()
            def __getattr__(self, name):
                return getattr(self.stream, name)
            def flush(self):
                test.assertTrue(state["locked"], "Initialisation must not write before acquiring byte lock")
                state["flush_checked"] = True
                self.stream.flush()

        def locking(fd, mode, count):
            original_locking(fd, mode, count)
            state["locked"] = mode != msvcrt.LK_UNLCK

        def open_checked(path, *args, **kwargs):
            return CheckedStream(original_open(path, *args, **kwargs))

        target = self.output / "2401.00001.pdf"
        with patch.object(Path, "open", side_effect=open_checked, autospec=True), patch.object(msvcrt, "locking", side_effect=locking):
            with pdf._download_lock(target, time.monotonic() + 5):
                self.assertTrue(state["locked"])
        self.assertTrue(state["flush_checked"])
        self.assertFalse(state["locked"])
        self.assertEqual(target.with_suffix(".pdf.download.lock").read_bytes(), b"0")

    def test_partial_cache_is_replaced_only_after_complete_stream(self):
        path = self.output / "2401.00001.pdf"
        path.write_bytes(b"%PDF-incomplete")

        class StreamingResponse(Response):
            def iter_content(inner, chunk_size):
                self.assertEqual(path.read_bytes(), b"%PDF-incomplete")
                yield PDF_BYTES[:10]
                self.assertEqual(path.read_bytes(), b"%PDF-incomplete")
                yield PDF_BYTES[10:]

        self.get.return_value = StreamingResponse()
        self.download()
        self.assertEqual(path.read_bytes(), PDF_BYTES)
        self.assertFalse(list(self.output.glob("*.part")))

    def test_invalid_body_never_publishes_a_final_file(self):
        self.get.return_value = Response(b"%PDF-truncated")
        with patch.object(pdf.time, "sleep"):
            with self.assertRaises(ValueError):
                self.download()
        self.assertFalse((self.output / "2401.00001.pdf").exists())
        self.assertFalse(list(self.output.glob("*.part")))

    def test_retry_budget_is_shared_across_attempts(self):
        clock = Clock()

        def get(*args, **kwargs):
            clock.now += 2
            return Response(status=503)

        self.get.side_effect = get
        with patch.object(pdf.time, "monotonic", clock.monotonic), patch.object(pdf.time, "sleep", clock.sleep):
            with self.assertRaises(TimeoutError):
                self.download(total_timeout=5)
        self.assertEqual(self.get.call_count, 2)
        self.assertEqual(clock.now, 5)

    def test_cooldown_wait_uses_the_same_budget_without_http(self):
        clock = Clock()
        self.reserve.return_value = (False, 60.0)
        with patch.object(pdf.time, "monotonic", clock.monotonic), patch.object(pdf.time, "sleep", clock.sleep):
            with self.assertRaises(TimeoutError):
                self.download(total_timeout=5)
        self.get.assert_not_called()
        self.assertEqual(clock.now, 5)

    def test_expired_stream_removes_partial_file(self):
        clock = Clock()

        class SlowResponse(Response):
            def iter_content(inner, chunk_size):
                yield b"%PDF-1.4\n"
                clock.now = 2
                yield b"%%EOF\n"

        self.get.return_value = SlowResponse()
        with patch.object(pdf.time, "monotonic", clock.monotonic):
            with self.assertRaises(TimeoutError):
                self.download(total_timeout=1)
        self.assertFalse((self.output / "2401.00001.pdf").exists())
        self.assertFalse(list(self.output.glob("*.part")))

    def test_rate_limit_records_shared_cooldown(self):
        self.get.side_effect = [Response(status=429), Response()]
        with patch.object(pdf.time, "sleep"):
            self.download()
        self.rate_cooldown.assert_called_once()
        self.assertEqual(self.get.call_count, 2)

    def test_independent_threads_fetch_same_target_once(self):
        def get(*args, **kwargs):
            time.sleep(0.1)
            return Response()

        self.get.side_effect = get
        with ThreadPoolExecutor(max_workers=2) as executor:
            results = list(executor.map(lambda _: self.download(), range(2)))
        self.assertEqual(results[0], results[1])
        self.assertEqual(self.get.call_count, 1)

    def test_invalid_identifier_is_rejected_before_requesting(self):
        for identifier in ("../private", "2401.00001/../../secret", "https://example.test/pdf"):
            with self.subTest(identifier=identifier), self.assertRaises(ValueError):
                pdf.download_arxiv_pdf(
                    identifier, self.output, reserve_request=self.reserve,
                    network_cooldown=self.network_cooldown,
                    rate_limit_cooldown=self.rate_cooldown, request_get=self.get,
                )
        self.get.assert_not_called()

    def test_separate_processes_use_one_download_and_complete_final_file(self):
        counts = []

        class Handler(BaseHTTPRequestHandler):
            def do_GET(inner):
                counts.append(1)
                time.sleep(0.15)
                inner.send_response(200)
                inner.send_header("Content-Length", str(len(PDF_BYTES)))
                inner.end_headers()
                inner.wfile.write(PDF_BYTES)

            def log_message(inner, *_):
                pass

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        script = (
            "import sys, requests; from pathlib import Path; "
            "from deepdiver_v2.src.arxiv_pdf_download import download_arxiv_pdf; "
            "download_arxiv_pdf('2401.00001', Path(sys.argv[1]), total_timeout=10, "
            "reserve_request=lambda _: (True, 0), network_cooldown=lambda: None, "
            "rate_limit_cooldown=lambda _: None, "
            "request_get=lambda url, **kw: requests.get(sys.argv[2], **kw))"
        )
        processes = []
        try:
            for _ in range(2):
                processes.append(subprocess.Popen(
                    [sys.executable, "-c", script, str(self.output), f"http://127.0.0.1:{server.server_port}"],
                    cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                ))
            for process in processes:
                stdout, stderr = process.communicate(timeout=15)
                self.assertEqual(process.returncode, 0, stderr.decode(errors="replace"))
            self.assertEqual(len(counts), 1)
            self.assertEqual((self.output / "2401.00001.pdf").read_bytes(), PDF_BYTES)
        finally:
            for process in processes:
                if process.poll() is None:
                    process.kill()
                    process.wait()
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)
