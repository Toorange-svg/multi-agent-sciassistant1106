"""Readable answers preserve evidence requirements and historical rendering."""
from copy import deepcopy
import json
import time

import pytest

from multi_agent_evidence import ANSWER_STYLE_POLICY, source_identity_record, report_source_identity
from multi_agent_live import LiveArxivRagExecutor, ROLE_PROMPT_SUFFIXES
from multi_agent_pipeline_v2 import DeterministicLiteratureExecutor, render_claims as render_answer
from multi_agent_quality import (source_boundary_brief, citation_audit_input,
    _bounded_absence_context, absence_scope_features, ABSENCE_SCOPE_POLICY,
    NAMED_PASSAGE_ABSENCE_SCOPE_POLICY)
from multi_agent_rag import DocumentStore
from test_multi_agent_report_fields import draft, evidence


def test_bibliography_does_not_infer_author_from_related_work():
    item = {'paper_id': '2003.08685v3', 'title': 'Frequency analysis',
            'authors': ['Joel Frank', 'Thorsten Eisenhofer'], 'author_metadata_source': 'arxiv_api',
            'excerpt': 'Concurrently, Durall et al. made similar observations.'}
    saved = deepcopy(item)
    identity = source_identity_record(item)
    assert identity['authors'] == ['Joel Frank', 'Thorsten Eisenhofer']
    assert not identity['semantic_support_verified']
    item.pop('authors')
    assert source_identity_record(item)['authors'] == []
    assert 'Durall' not in str(identity['authors'])
    assert saved['excerpt'] == item['excerpt']


def test_legacy_reference_replay_does_not_gain_new_identity_fields():
    source = {'authors': ['Joel Frank'], 'author_metadata_source': 'arxiv_api'}
    assert report_source_identity({}, source) == {}
    assert report_source_identity({'answer_style_policy': ANSWER_STYLE_POLICY}, source)['source_identity']['authors'] == ['Joel Frank']


@pytest.mark.parametrize('raw,expected', [
    (None, []), ('Frank et al.', []), ([None, {}, 7], []),
    (['Joel\n Frank', 'Joel Frank', 'x'*161], ['Joel Frank'])])
def test_authors_are_bounded_metadata_not_free_form_inference(raw, expected):
    assert source_identity_record({'authors': raw})['authors'] == expected


def test_search_to_abstract_and_document_persistence_keeps_authors(tmp_path):
    source = {'paper_id': '2003.08685v3', 'title': 'Frequency analysis',
              'authors': ['Joel Frank'], 'abstract': 'Durall is cited, not this author.'}
    executor = DeterministicLiteratureExecutor(lambda *_: {'status': 'ok', 'papers': [source]})
    action = {'request_id': 'r1', 'action': 'request_arxiv_search',
              'arguments': {'query': 'frequency', 'group_id': 'g1'}}
    result = executor.execute([action], group_ids={'g1'}, deadline=time.monotonic()+10)
    packet = result['evidence'][0]
    assert packet['authors'] == ['Joel Frank']
    assert packet['author_metadata_source'] == 'arxiv_api'
    folder = DocumentStore(tmp_path).put('doc1', {**packet, 'content_hash': 'hash'})
    stored = json.loads((folder/'metadata.json').read_text(encoding='utf8'))
    assert stored['authors'] == packet['authors']
    assert stored['author_metadata_source'] == 'arxiv_api'


def test_writer_and_auditor_receive_cited_identity_only():
    data, sources = draft(), evidence()
    sources['evidence'][0].update(authors=['Joel Frank'], author_metadata_source='arxiv_api')
    brief = source_boundary_brief(sources)
    assert brief['source_identity_records'][0]['authors'] == ['Joel Frank']
    packet = citation_audit_input(data, sources)
    row = packet['claims'][0]['source_context'][0]
    assert row['source_identity']['authors'] == ['Joel Frank']
    assert row['source_identity']['semantic_support_verified'] is False


def test_fulltext_packet_and_warm_reuse_keep_retrieved_authors(tmp_path):
    from test_multi_agent_live import create_pdf, request
    search = lambda *_a, **_k: {'status': 'ok', 'papers': [{'paper_id': '2309.06180',
        'title': 'PagedAttention', 'authors': ['Verified Metadata Author'],
        'abstract': 'Memory management and throughput'}]}
    executor = LiveArxivRagExecutor(tmp_path/'run', tmp_path/'storage', rag_mode='lexical',
        search=search, download=lambda _paper, folder: create_pdf(folder))
    result = executor.execute(request(), group_ids={'g1'}, deadline=time.monotonic()+30)
    assert result['evidence'] and all(p['authors'] == ['Verified Metadata Author'] for p in result['evidence'])
    second = LiveArxivRagExecutor(tmp_path/'second', tmp_path/'storage', rag_mode='lexical', search=search,
        download=lambda *_: pytest.fail('do not redownload'))
    again = second.execute(request(), group_ids={'g1'}, deadline=time.monotonic()+30)
    assert again['evidence'] and again['evidence'][0]['author_metadata_source'] == 'arxiv_api'


@pytest.mark.parametrize('prefix', ['摘要级报告', '摘要级证据', '图注级描述', '片段级材料'])
@pytest.mark.parametrize('assertion_only', [False, True])
def test_local_report_alias_does_not_require_stock_disclaimer(prefix, assertion_only):
    text = prefix+'，未给出具体泛化数值。'
    assertion = '未给出具体泛化数值。' if assertion_only else text
    assert _bounded_absence_context(assertion, text, **absence_scope_features(ABSENCE_SCOPE_POLICY))
    assert not _bounded_absence_context(assertion, text, **absence_scope_features(NAMED_PASSAGE_ABSENCE_SCOPE_POLICY))


@pytest.mark.parametrize('text,assertion', [
    ('摘要级报告，但论文未做任何实验。', '但论文未做任何实验。'),
    ('摘要级报告。未提供具体数字。', '未提供具体数字。'),
    ('论文没有给出具体数字。', '论文没有给出具体数字。'),
    ('摘要级报告；另一研究未开展验证。', '另一研究未开展验证。')])
def test_local_alias_never_proves_whole_paper_absence(text, assertion):
    assert not _bounded_absence_context(assertion, text, **absence_scope_features(ABSENCE_SCOPE_POLICY))


def test_optional_scope_is_not_repeated_but_original_fields_remain():
    data, sources = draft(), evidence()
    data['answer_style_policy'] = ANSWER_STYLE_POLICY
    claim = data['claims'][0]
    claim.update(text='仅在该数据集上观察到这一结果。', scope_note='仅在该数据集上观察到这一结果。')
    old = deepcopy(data)
    text = render_answer(data, sources)
    assert text.count(claim['text']) == 1
    assert data == old
    data.pop('answer_style_policy')
    assert render_answer(data, sources).count(claim['text']) == 2


def test_different_essential_condition_is_never_silently_removed():
    data, sources = draft(), evidence()
    data['answer_style_policy'] = ANSWER_STYLE_POLICY
    data['claims'][0]['scope_note'] = '实验采用不同数据集，不能直接排名。'
    assert '实验采用不同数据集，不能直接排名。' in render_answer(data, sources)


def test_short_abstract_badge_preserves_strength_and_legacy_wording():
    data, sources = draft(), evidence()
    sources['evidence'][0].update(coverage_scope='abstract', locator={'page': None, 'section': 'abstract'})
    data['answer_style_policy'] = ANSWER_STYLE_POLICY
    text = render_answer(data, sources)
    assert '摘要级依据' in text
    assert '仅作低置信度线索' not in text
    data.pop('answer_style_policy')
    assert '仅作低置信度线索' in render_answer(data, sources)


def test_unlocated_fulltext_is_not_mislabelled_as_abstract():
    data, sources = draft(), evidence()
    sources['evidence'][0].update(coverage_scope='selected_chunks', locator={'page': None})
    data['answer_style_policy'] = ANSWER_STYLE_POLICY
    assert '含未定位原文依据' in render_answer(data, sources)
    assert '摘要级依据' not in render_answer(data, sources)


def test_prompts_request_relevance_not_generic_warning_or_claim_cap():
    writer = ROLE_PROMPT_SUFFIXES['writer']
    auditor = ROLE_PROMPT_SUFFIXES['citation_auditor']
    assert 'not a disclaimer catalogue' in writer
    assert 'not a claim-count' in writer
    assert 'rather than guessing' in writer
    assert 'not disclaimer density' in auditor
    assert 'does not waive unsupported numbers' in auditor
