"""Cited literal definitions, not subscript chronology or semantic auto-approval."""
from copy import deepcopy
from dataclasses import replace

import pytest

from multi_agent_quality import (SYMBOL_ROLE_POLICY, check_symbol_roles, check_claim_revision,
                                 publication_rejections, check_audit)
from multi_agent_pipeline_v2 import check_draft
from test_multi_agent_report_fields import draft, evidence, audit


SOURCE = ('Double Quantization treats quantization constants cFP32 2 of the first quantization '
          'as inputs to a second quantization. This second step yields the quantized '
          'quantization constants cFP8 2 and the second level of quantization constants cFP32 1.')
BAD = '第一层量化常数 c1 为 FP32，第二层量化常数 c2 用8-bit Float量化。'
GOOD = '第一次量化常数 c2 是再次量化的输入，第二层量化常数 c1 是 FP32。'


def inputs(text=BAD):
    data, sources = draft(), evidence()
    data['symbol_role_policy'] = SYMBOL_ROLE_POLICY
    data['claims'][0].update(text=text, scope_note='', qualification='仅此原文符号定义。')
    sources['evidence'][0]['excerpt'] = SOURCE
    return data, sources


@pytest.mark.parametrize('field', ['text', 'scope_note', 'qualification'])
def test_exact_field_contradiction_has_literal_source_offsets_without_mutation(field):
    data, sources = inputs(GOOD)
    data['claims'][0][field] = BAD
    before = deepcopy((data, sources))
    issues = check_symbol_roles(data, sources)
    assert len(issues) == 1 and issues[0]['field'] == field
    assert issues[0]['reason'] == 'SYMBOL_ROLE_CONTRADICTION'
    assert not issues[0]['automatic_rewrite']
    quote = issues[0]['source_witnesses'][0]
    assert quote['quote'] == SOURCE[quote['start']:quote['end']]
    assert (data, sources) == before


@pytest.mark.parametrize('text', [GOOD, 'c2为第一次量化常数，c1为第二层量化常数。',
    '不能称第一层量化常数 c1 为 FP32。', 'c1、c2下标不能直接当作操作先后顺序。',
    'DQ再次量化常数以节省额外存储。', 'c2用于FP8存储；c1为FP32。',
    '第二次量化常数 c2 的FP8形式。', 'second quantization constants c2 are FP8.'])
def test_correct_mapping_conceptual_wording_and_refutations_are_not_rejected(text):
    assert not check_symbol_roles(*inputs(text))


@pytest.mark.parametrize('text', ['c1为第一次量化常数。', '第一轮量化的常数 c1 是FP32。',
    '第二级量化常数c2是FP32。', 'first quantization constants c1 are stored as FP32.'])
def test_explicit_forward_and_reverse_stage_bindings(text):
    assert check_symbol_roles(*inputs(text))


@pytest.mark.parametrize('fault', ['uncited', 'unapproved', 'dtype_only', 'broken_definition', 'ambiguous'])
def test_no_verdict_from_uncited_or_ambiguous_source(fault):
    data, sources = inputs()
    if fault == 'uncited': data['claims'][0]['evidence_ids'] = ['elsewhere']
    if fault == 'unapproved': sources['evidence'][0]['review_status'] = 'pending'
    if fault == 'dtype_only': sources['evidence'][0]['excerpt'] = 'We use FP32 for c1 and FP8 for c2.'
    if fault == 'broken_definition': sources['evidence'][0]['excerpt'] = 'quantization constants cFP32 as inputs. 2'
    if fault == 'ambiguous':
        sources['evidence'].append({**sources['evidence'][0], 'evidence_id': 'e2',
                                   'excerpt': SOURCE.replace('cFP32 2', 'cFP32 1').replace('cFP32 1.', 'cFP32 2.')})
        data['claims'][0]['evidence_ids'].append('e2')
    assert not check_symbol_roles(data, sources)


def test_indices_are_source_defined_not_hardcoded_qlora_answers():
    data, sources = inputs('第一层量化常数c7，第二层量化常数c4。')
    sources['evidence'][0]['excerpt'] = SOURCE.replace('cFP32 2', 'cFP32 7').replace('cFP32 1', 'cFP32 4')
    assert not check_symbol_roles(data, sources)
    data['claims'][0]['text'] = GOOD
    assert check_symbol_roles(data, sources)


def test_policy_gated_and_correct_note_cannot_rescue_wrong_body():
    data, sources = inputs()
    assert any(x['reason'] == 'SYMBOL_ROLE_CONTRADICTION' for x in check_draft(data, sources))
    legacy = deepcopy(data); legacy.pop('symbol_role_policy')
    assert not any(x['reason'] == 'SYMBOL_ROLE_CONTRADICTION' for x in check_draft(legacy, sources))
    feedback = {'code_issues': check_symbol_roles(data, sources)}
    changed = deepcopy(data); changed['claims'][0]['qualification'] = GOOD
    assert check_claim_revision(data, changed, feedback)['code_issues']
    changed['claims'][0]['text'] = GOOD
    assert not check_symbol_roles(changed, sources)
    assert not check_claim_revision(data, changed, feedback)['code_issues']


def test_hidden_field_repair_is_not_automatic_approval():
    data, sources = inputs(GOOD)
    data['claims'][0]['qualification'] = BAD
    feedback = {'code_issues': check_symbol_roles(data, sources)}
    changed = deepcopy(data); changed['claims'][0]['qualification'] = '仅此原文符号定义。'
    assert not check_claim_revision(data, changed, feedback)['code_issues']
    assert not check_symbol_roles(changed, sources)
    assert changed['claims'][0]['text'] == data['claims'][0]['text']


def test_model_approval_does_not_override_code_or_block_unrelated_claim():
    data, sources = inputs()
    extra = {**data['claims'][0], 'claim_id': 'c2', 'text': GOOD}
    data['claims'].append(extra)
    verdict = audit(data)
    for row in verdict['claim_results']:
        row['source_witnesses'][0]['quote'] = SOURCE[:180]
    checked = check_audit(verdict, data, sources)
    assert not checked['contract_errors']
    checked['code_issues'] = check_symbol_roles(data, sources)
    assert publication_rejections(checked, data) == {'c1'}


def test_full_workflow_repairs_explicit_contradiction_and_reaudits(tmp_path):
    from test_multi_agent_pipeline_v2 import agents, pipeline, worker
    configured, calls = agents(partial=True)
    count = []
    def writer(_packet):
        calls.append('writer'); count.append(1)
        data, _ = inputs(BAD if len(count) == 1 else GOOD)
        data['claims'][0].update(evidence_ids=['arxiv-1'], confidence='low',
                                 qualification='仅所选摘要原句。')
        return {'output': data}
    configured = replace(configured, writer=worker('writer', writer, 'write_approved_claims'))
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {'status': 'ok', 'papers': [
        {'paper_id': '1', 'title': 'DQ', 'abstract': SOURCE, 'landing_url': 'https://arxiv.org/abs/1'}]})
    result = flow.run('symbols', 'owner', '仅核对量化常数符号。')
    assert calls.count('writer') == calls.count('citation_auditor') == 2
    assert result['run']['status'] in {'partial', 'needs_review'}
    assert result['run']['model_calls_used'] == 7
    assert GOOD in result['direct_answer'] and BAD not in result['direct_answer']
