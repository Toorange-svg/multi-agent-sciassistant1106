"""Report size is not quality; direction cues are questions, never approvals."""
from copy import deepcopy
import json
import time

import pytest

from multi_agent_agents import AgentWorker, ArtifactDirectory, MODEL_DELIVERY_SCHEMA, ROLE_ALLOWED_ACTIONS, make_agent_input
from multi_agent_live import LiveModelClient, ROLE_OUTPUT_SCHEMAS, effective_role_prompt, normalize_live_result
from multi_agent_quality import METRIC_INTERPRETATION_POLICY, citation_audit_input, source_boundary_brief
from test_multi_agent_live import config, Response
from test_multi_agent_semantic_boundaries import draft, source


def test_writer_has_no_numeric_writing_target_in_any_source_mode():
    for options in ({}, {"local_source": True}, {"mixed_source": True}):
        prompt = effective_role_prompt("writer", **options)
        for old in ("4-8", "3-6 focused", "1-2 short sentences"):
            assert old not in prompt
        assert "no target claim count or report length" in prompt
        assert "ALL" in effective_role_prompt("citation_auditor", **options)


def test_long_writer_result_is_not_sliced_to_eight_claims():
    claims = [{"claim_id": f"c{i}", "text": "必要机制解释。" * 200, "claim_type": "technical",
               "scope_note": "", "qualification": "必要的实验条件。" * 200,
               "evidence_ids": ["e1"], "section": "topic_analysis"} for i in range(12)]
    result = normalize_live_result("writer", {"output": {"schema_version": ROLE_OUTPUT_SCHEMAS["writer"],
                                                           "direct_answer": "完整回答", "claims": claims}})
    assert result["output"]["claims"] == claims


@pytest.mark.parametrize("text,category", [
    ("Validation loss: 1.16 1.16. Performance peaks at rank 16.", "metric_direction_and_ties"),
    ("BLEU is best at rank 4.", "metric_direction_and_ties"),
    ("Rank is insensitive when adapting all linear layers.", "tested_sensitivity_conditions")])
def test_source_conditions_are_verbatim_questions_not_invented_facts(text, category):
    evidence = {"evidence": [source(text=text)]}
    before = deepcopy(evidence)
    brief = source_boundary_brief(evidence)
    cue = next(row for row in brief["cues"] if row["category"] == category)
    assert cue["quote"] == text[cue["start"]:cue["end"]]
    assert brief["metric_interpretation_policy"] == METRIC_INTERPRETATION_POLICY
    assert "decision" not in cue and evidence == before


@pytest.mark.parametrize("field", ["text", "scope_note", "qualification"])
def test_wrong_direction_is_presented_unchanged_for_all_field_review(field):
    data = draft("有依据的正文。")
    data["claims"][0][field] = "验证损失达到峰值，因此r=16唯一最优。"
    before = deepcopy(data)
    result = citation_audit_input(data, {"evidence": [source(text="Validation loss 1.16 ties at ranks 16 and 32.")]})
    assert result["metric_interpretation_policy"] == METRIC_INTERPRETATION_POLICY
    row = result["claims"][0]
    assert row["report_fields"][field] == before["claims"][0][field]
    assert any("lower loss" in q and "ties" in q for q in row["semantic_review_questions"])
    assert any("TESTED" in q for q in row["semantic_review_questions"])
    assert "decision" not in row and data == before


class Provider(Response):
    def __init__(self, finish="stop", usage=None, malformed=False):
        self.finish, self.usage, self.malformed = finish, usage, malformed

    def iter_content(self, **kwargs):
        from test_multi_agent_live import typed_plan_fixture
        content = "{unfinished" if self.malformed else json.dumps({"output": typed_plan_fixture(),
            "delivery_metadata": {"finish_reason": "forged"}})
        yield json.dumps({"choices": [{"finish_reason": self.finish, "message": {
            "content": content, "reasoning_content": "PRIVATE-HIDDEN-CANARY"}}], "usage": self.usage,
            "private_provider_data": "PRIVATE-PROVIDER-CANARY"}).encode()


@pytest.mark.parametrize("usage,expected", [
    ({"completion_tokens": 123, "prompt_tokens": 200}, (123, 200)),
    (None, (None, None)),
    ({"completion_tokens": True, "prompt_tokens": -1}, (None, None)),
    ({"completion_tokens": "secret-canary", "prompt_tokens": 10_000_001}, (None, None))])
def test_provider_delivery_counts_are_whitelisted_not_model_supplied(monkeypatch, usage, expected):
    monkeypatch.setenv("MODEL_REQUEST_URL", "https://example.test/v1/chat/completions")
    response = Provider(usage=usage)
    result = LiveModelClient(config(), post=lambda *_a, **_k: response).call(
        "planner", {"deadline_at": time.time() + 20, "inputs": []})
    metadata = result["delivery_metadata"]
    assert metadata["finish_reason"] == "stop" and metadata["output_limit"] == 8192
    assert (metadata["completion_units"], metadata["prompt_units"]) == expected
    assert metadata["schema_version"] == MODEL_DELIVERY_SCHEMA
    assert "CANARY" not in json.dumps(result) and "secret-canary" not in json.dumps(result)
    assert response.closed


@pytest.mark.parametrize("finish,malformed,code", [
    ("length", False, "MODEL_OUTPUT_TRUNCATED"), ("length", True, "MODEL_OUTPUT_TRUNCATED"),
    ("content_filter", False, "MODEL_OUTPUT_FILTERED"), ("tool_calls", False, "MODEL_FINISH_UNEXPECTED"),
    ("stop", True, "MODEL_JSON_INVALID")])
def test_incomplete_or_filtered_delivery_never_becomes_a_scientific_output(monkeypatch, finish, malformed, code):
    monkeypatch.setenv("MODEL_REQUEST_URL", "https://example.test/v1/chat/completions")
    response = Provider(finish=finish, malformed=malformed)
    result = LiveModelClient(config(), post=lambda *_a, **_k: response).call(
        "planner", {"deadline_at": time.time() + 20, "inputs": []})
    assert result["status"] == "failed" and result["error_code"] == code
    assert result["delivery_metadata"]["finish_reason"] == finish
    assert "groups" not in result["output"] and response.closed


def test_missing_finish_is_unknown_not_claimed_complete(monkeypatch):
    monkeypatch.setenv("MODEL_REQUEST_URL", "https://example.test/v1/chat/completions")
    result = LiveModelClient(config(), post=lambda *_a, **_k: Provider(finish=None)).call(
        "planner", {"deadline_at": time.time() + 20, "inputs": []})
    assert result["delivery_metadata"]["finish_reason"] == "unknown"
    assert result["output"]["groups"][0]['id'] == 'g1'  # Valid current plan, but provider finish is still unknown.


@pytest.mark.parametrize("invalid", [False, True])
def test_delivery_artifact_does_not_change_role_output_ids_or_validate_science(tmp_path, invalid):
    store = ArtifactDirectory(tmp_path)
    metadata = {"schema_version": MODEL_DELIVERY_SCHEMA, "finish_reason": "stop", "output_limit": 8192,
                "visible_char_count": 500, "completion_units": 100, "prompt_units": None}
    if invalid:
        metadata["private_details"] = "provider-canary"
    worker = AgentWorker("planner", lambda _: {"output": {"schema_version": "demo/v1", "groups": []},
                                              "delivery_metadata": metadata}, ROLE_ALLOWED_ACTIONS["planner"])
    packet = make_agent_input(run_id="delivery-test", role="planner", goal="Check metadata",
                              input_artifact_ids=[], remaining_model_calls=10, deadline_at=time.time() + 10)
    result = worker.run(packet, store)
    assert len(result["output_artifact_ids"]) == 1
    assert store.get(result["output_artifact_ids"][0])["groups"] == []
    receipts = list(tmp_path.glob("model-delivery-*.json"))
    assert len(receipts) == (0 if invalid else 1)
    if receipts:
        receipt = store.get(receipts[0].stem)
        assert receipt["agent_role"] == "planner" and receipt["input_artifact_ids"] == []
        assert "approved" not in receipt
