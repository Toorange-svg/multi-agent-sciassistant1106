from __future__ import annotations

import time

from multi_agent_agents import AgentWorker, ArtifactDirectory, make_rework_ticket
from multi_agent_pipeline_v2 import DeterministicLiteratureExecutor, LiteraturePipelineV2, PipelineAgents
from multi_agent_workflow import WorkflowStore


def worker(role, handler, action):
    return AgentWorker(role, handler, [action])


def agents(*, partial=False, recovery=False, revise=False, audit_status="passed"):
    calls = []

    def planner(_packet):
        calls.append("planner")
        return {"output": {"groups": [{"id": "g1", "question": "A", "queries": ["A"]}]}}

    def retriever(packet):
        calls.append("retriever")
        group_id = "g1"
        query = "A targeted" if any(item["payload"].get("gaps") for item in packet["inputs"]) else "A"
        return {"output": {"actions": 1}, "tool_requests": [{
            "request_id": f"request-{len(calls)}", "action": "request_arxiv_search",
            "arguments": {"query": query, "group_id": group_id},
        }]}

    reviews = []

    def reviewer(packet):
        calls.append("reviewer")
        evidence = next(item["payload"] for item in packet["inputs"] if "evidence" in item["payload"])
        reviews.append(len(evidence["evidence"]))
        if recovery and len(reviews) == 1:
            return {"output": {"coverage_status": "insufficient", "allowed_evidence_ids": [],
                               "conflicts": [], "coverage": []}}
        ids = [item["evidence_id"] for item in evidence["evidence"]]
        return {"output": {"coverage_status": "partial" if partial or recovery else "sufficient",
                           "allowed_evidence_ids": ids, "conflicts": [], "coverage": []}}

    def gap(_packet):
        calls.append("gap_analyst")
        return {"output": {"gaps": [{"group_id": "g1", "query": "A targeted"}]}}

    def writer_handler(_packet):
        calls.append("writer")
        return {"output": {"direct_answer": "有限回答 [1]", "claims": [{"claim_id": "c1",
                                                                          "evidence_ids": ["arxiv-1"]}]}}

    audit_count = []

    def auditor(packet):
        calls.append("citation_auditor")
        audit_count.append(1)
        if revise and len(audit_count) == 1:
            ticket = make_rework_ticket(
                run_id=packet["run_id"], from_role="citation_auditor", to_role="writer",
                reason_code="UNSUPPORTED_CLAIM", artifact_ids=[], required_changes=["修订声明"],
            )
            return {"status": "rework_required", "output": {"status": "needs_revision"},
                    "rework_ticket": ticket}
        return {"output": {"status": audit_status}}

    return PipelineAgents(
        worker("planner", planner, "create_research_plan"),
        worker("retriever", retriever, "request_arxiv_search"),
        worker("reviewer", reviewer, "review_evidence"),
        worker("gap_analyst", gap, "create_gap_search_plan"),
        worker("writer", writer_handler, "write_approved_claims"),
        worker("citation_auditor", auditor, "audit_citations"),
    ), calls


def pipeline(tmp_path, configured_agents, search=None, general_fallback=None):
    store = WorkflowStore(tmp_path / "workflow.sqlite3")
    artifacts = ArtifactDirectory(tmp_path / "artifacts")
    search = search or (lambda _query, _limit: {"status": "ok", "papers": [{
        "paper_id": "1", "title": "Paper", "abstract": "Evidence", "landing_url": "https://arxiv.org/abs/1",
    }]})
    return LiteraturePipelineV2(store, artifacts, configured_agents,
                                DeterministicLiteratureExecutor(search), event_path=tmp_path / "events.jsonl",
                                general_fallback=general_fallback), store


def test_pipeline_runs_six_agents_in_workflow_order(tmp_path):
    configured, calls = agents()
    flow, store = pipeline(tmp_path, configured)
    result = flow.run("run-1", "owner-1", "Compare A")
    assert result["run"]["status"] == "completed"
    assert result["run"]["model_calls_used"] == 5
    assert calls == ["planner", "retriever", "reviewer", "writer", "citation_auditor"]
    assert (tmp_path / "events.jsonl").is_file()


def test_pipeline_performs_one_gap_recovery_and_returns_partial(tmp_path):
    configured, calls = agents(recovery=True)
    flow, _store = pipeline(tmp_path, configured)
    result = flow.run("run-1", "owner-1", "Compare A")
    assert result["run"]["status"] == "partial"
    assert result["run"]["model_calls_used"] == 8
    assert calls.count("gap_analyst") == 1
    assert calls.count("retriever") == 2
    assert calls.count("reviewer") == 2


def test_pipeline_allows_one_writer_rework_and_reaudit(tmp_path):
    configured, calls = agents(revise=True)
    flow, _store = pipeline(tmp_path, configured)
    result = flow.run("run-1", "owner-1", "Compare A")
    assert result["run"]["status"] == "completed"
    assert result["run"]["model_calls_used"] == 7
    assert calls.count("writer") == 2
    assert calls.count("citation_auditor") == 2


def test_zero_evidence_after_recovery_is_real_failure_with_explanation(tmp_path):
    configured, _calls = agents(recovery=True)
    flow, _store = pipeline(tmp_path, configured, search=lambda *_args: {"status": "ok", "papers": []})
    result = flow.run("run-1", "owner-1", "Compare A")
    assert result["run"]["status"] == "failed"
    assert result["run"]["failure_code"] == "INSUFFICIENT_EVIDENCE"
    assert result["direct_answer"]


def test_source_unreachable_publishes_general_fallback_when_callback_is_available(tmp_path):
    configured, calls = agents()
    fallback_calls = []

    def fallback(question, reason, permit):
        fallback_calls.append((question, reason, permit.call_number))
        return "卷积网络通常利用局部连接和权重共享处理图像；这只是通用解释。"

    flow, store = pipeline(
        tmp_path, configured,
        search=lambda *_: {"status": "source_unreachable", "papers": []},
        general_fallback=fallback,
    )
    result = flow.run("source-fallback", "owner", "为什么卷积网络适合处理图像？")

    assert result["run"]["status"] == "needs_review"
    assert result["run"]["failure_code"] == "RETRIEVAL_SOURCE_UNREACHABLE"
    assert result["run"]["model_calls_used"] == 3
    assert fallback_calls == [("为什么卷积网络适合处理图像？", "RETRIEVAL_SOURCE_UNREACHABLE", 3)]
    assert "降级回答" in result["direct_answer"]
    assert "通用解释" in result["direct_answer"]
    assert store.get_run("source-fallback")["status"] == "needs_review"


def test_no_audited_claims_publishes_general_fallback_when_callback_is_available(tmp_path):
    configured, _calls = agents(audit_status="needs_review")

    def fallback(question, reason, permit):
        assert reason == "NO_AUDITED_CLAIMS"
        assert permit.call_number == 8
        return "可以先从通用知识解释，但本轮没有可核验的论文声明。"

    flow, store = pipeline(tmp_path, configured, general_fallback=fallback)
    result = flow.run("audit-fallback", "owner", "为什么卷积网络适合处理图像？")

    assert result["run"]["status"] == "needs_review"
    assert result["run"]["failure_code"] == "NO_AUDITED_CLAIMS"
    assert result["run"]["model_calls_used"] == 8
    assert "现有证据未形成可发布声明" in result["direct_answer"]
    assert "通用知识解释" in result["direct_answer"]
    assert store.get_run("audit-fallback")["status"] == "needs_review"
