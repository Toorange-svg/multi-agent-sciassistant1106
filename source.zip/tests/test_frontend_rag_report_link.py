"""Read-only report-link UI logic, with a mocked DOM/network, not browser clicks."""
import json
from pathlib import Path
import shutil
import subprocess

import pytest


SOURCE = (Path(__file__).resolve().parents[1] / "chatAi/multi_agent_rag.js").read_text(encoding="utf-8")


@pytest.mark.parametrize("search,status,stale,replacement,expected", [
    ("?rag_task=abcdef012345", 200, False, False, 1),
    ("?rag_task=abcdef012345", 401, False, False, 1),
    ("?rag_task=../private", 200, False, False, 0),
    ("?rag_task=abcdef012345", 200, True, False, 1),
    ("?rag_task=abcdef012345", 200, False, True, 2),
])
def test_report_link_is_read_only_and_identity_guarded(search, status, stale, replacement, expected):
    node = shutil.which("node")
    if not node:
        pytest.skip("Node required for report-link UI logic")
    harness = r'''
const vm = require('node:vm');
const created=[], calls=[], listeners={}, timers=[], downloads=[];
let releaseFirst;
function element(tag) {
  const item={tag, children:[], events:{}, dataset:{}, removed:false,
    append(...nodes) {this.children.push(...nodes);},
    remove() {this.removed=true;}, showModal() {this.shown=true;},
    addEventListener(key,fn) {this.events[key]=fn;},
    classList:{toggle(){}}, click() {if(this.download) downloads.push(this.download);}};
  created.push(item); return item;
}
const options=OPTIONS;
const window={currentSessionId:null, userToken:'fixture-identity', location:{search:options.search},
  addEventListener(key,fn) {listeners[key]=fn;}};
const document={createElement:element, body:element('body'), createTreeWalker:() => ({nextNode:() => false})};
const context={window, document, NodeFilter:{SHOW_TEXT:4}, URLSearchParams, AbortController, DOMException,
  URL:{createObjectURL:()=>'blob:fixture',revokeObjectURL(){}},
  setTimeout:fn => timers.push(fn), setInterval:()=>0,
  fetch:async (url,opts={})=>{
    calls.push({url,method:opts.method||'GET'});
    const index=calls.length;
    return {ok:options.status===200, status:options.status,
      json:async()=>{
        if(options.replacement && index===1) await new Promise(resolve=>releaseFirst=resolve);
        if(options.stale) window.userToken=null;
        return {status:'partial',references:[],limitation:'limits',direct_answer:'approved fixture [1]'};},
      blob:async()=>({})};}};
vm.runInNewContext(SOURCE,context);
(async()=>{
  listeners.DOMContentLoaded();
  for(let i=0;i<6;i++) await new Promise(resolve=>setImmediate(resolve));
  if(options.replacement) {
    window.location.search='?rag_task=bbbbbbbbbbbb'; listeners.DOMContentLoaded();
    for(let i=0;i<6;i++) await new Promise(resolve=>setImmediate(resolve));
    releaseFirst();
    for(let i=0;i<6;i++) await new Promise(resolve=>setImmediate(resolve));
  }
  const dialog=created.find(x=>x.tag==='dialog');
  const answer=created.find(x=>x.className==='rag-linked-answer');
  if(answer) for(const button of created.filter(x=>x.tag==='button' && /^下载 /.test(x.textContent||''))) await button.events.click();
  console.log(JSON.stringify({initial_calls:calls.filter(x=>!x.url.includes('/export')).length,
    readonly:calls.every(x=>x.method==='GET'),answer:!!answer,removed:!!dialog?.removed,
    visible_dialogs:created.filter(x=>x.tag==='dialog' && !x.removed).length,
    downloads,urls:calls.map(x=>x.url)}));
})();
'''
    script = "const SOURCE=" + json.dumps(SOURCE) + ";\n" + harness.replace("OPTIONS", json.dumps({"search": search, "status": status, "stale": stale, "replacement": replacement}))
    result = subprocess.run([node, "-"], input=script, capture_output=True, text=True, encoding="utf-8", timeout=10)
    assert result.returncode == 0, result.stderr
    outcome = json.loads(result.stdout)
    assert outcome["initial_calls"] == expected and outcome["readonly"]
    assert all("token=" not in url and url.startswith("/5000/api/science/tasks/") for url in outcome["urls"])
    assert outcome["answer"] == (bool(expected) and status == 200 and not stale)
    assert outcome["visible_dialogs"] == (1 if expected and not stale else 0)
    if outcome["answer"]:
        task = "bbbbbbbbbbbb" if replacement else "abcdef012345"
        assert outcome["downloads"] == [f"sciassistant_rag_{task}.{ext}" for ext in ("html", "md", "json")]
    else:
        assert not outcome["downloads"]
    if stale:
        assert outcome["removed"]
