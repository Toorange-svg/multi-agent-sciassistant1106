from __future__ import annotations

from multi_agent_literature import LiteratureRoles, LiteratureWorkflowCoordinator
from multi_agent_workflow import WorkflowStore


def question(run_id="task-001"):
    return {"schema_version": 1, "task_id": run_id, "question": "Compare A and B.",
            "conversation_facts": [], "deadline_at": 9999.0, "remaining_model_calls": 10}


def plan(_question):
    return {"schema_version": 1, "groups": [
        {"id": "group-a", "question": "method A", "queries": ["method A"], "priority": 1},
        {"id": "group-b", "question": "method B", "queries": ["method B"], "priority": 2},
    ], "assumptions": [], "out_of_scope": []}


def retriever(group):
    suffix = group["id"][-1]
    return {"schema_version": 1, "records": [{
        "evidence_id": f"evidence-{suffix}", "group_id": group["id"], "paper_id": f"paper-{suffix}",
        "title": f"Paper {suffix}", "source": "arxiv", "publication_date": None,
        "claim_support": [f"claim-{suffix}"], "excerpt": "A bounded evidence excerpt.",
        "fulltext_available": True, "provenance": {"retrieval_run_id": f"retrieval-{suffix}"},
    }]}


def reviewer(_plan, evidence_set):
    return {"schema_version": 1, "coverage_status": "sufficient",
            "supported_claims": ["claim-a", "claim-b"], "unsupported_questions": [], "conflicts": [],
            "allowed_evidence_ids": [record["evidence_id"] for record in evidence_set["records"]]}


def writer(_question, _review, _evidence, prior_audit=None):
    answer = "A and B differ according to the reviewed evidence."
    if prior_audit:
        answer += " The audit-driven revision removed unsupported wording."
    return {"schema_version": 1, "answer": answer, "coverage_status": "sufficient", "unresolved_questions": [],
            "claim_evidence_map": [
                {"claim_id": "claim-a", "evidence_ids": ["evidence-a"]},
                {"claim_id": "claim-b", "evidence_ids": ["evidence-b"]},
            ]}


def auditor(draft, _review):
    return {"schema_version": 1, "status": "passed", "rejected_claim_ids": [],
            "claim_results": [{"claim_id": item["claim_id"], "evidence_ids": item["evidence_ids"], "status": "supported"}
                              for item in draft["claim_evidence_map"]]}


def coordinator(tmp_path, roles=None):
    store = WorkflowStore(tmp_path / "multi-agent.sqlite3", clock=lambda: 1000.0)
    default = LiteratureRoles(plan, retriever, reviewer, writer, auditor)
    return LiteratureWorkflowCoordinator(store, roles or default), store


def test_workflow_uses_fixed_roles_and_persists_only_structured_artifacts(tmp_path):
    flow, store = coordinator(tmp_path)
    summary = flow.run("task-001", "user-001", question())
    assert summary["workflow_status"] == "completed"
    assert summary["model_calls_used"] == 4
    assert [stage["stage"] for stage in summary["stages"]] == [
        "created", "model_call", "planned", "retrieving",
        "retrieval_query", "retrieval_query", "reviewing", "model_call",
        "writing", "model_call", "auditing", "model_call", "completed",
    ]
    artifact_types = [item["artifact_type"] for item in store.list_artifacts("task-001")]
    assert artifact_types.count("evidence_set") == 3  # two query snapshots plus the merged set
    assert set(artifact_types) == {
        "citation_audit", "draft_answer", "evidence_review",
        "evidence_set", "question_envelope", "research_plan",
    }


def test_partial_review_produces_partial_result_with_no_unapproved_claims(tmp_path):
    def partial_reviewer(_plan, evidence):
        return {"schema_version": 1, "coverage_status": "partial", "supported_claims": ["claim-a"],
                "unsupported_questions": ["method B"], "conflicts": [], "allowed_evidence_ids": [evidence["records"][0]["evidence_id"]]}

    def partial_writer(_question, _review, _evidence, prior_audit=None):
        return {"schema_version": 1, "answer": "Only A is supported.", "coverage_status": "partial",
                "unresolved_questions": ["method B"],
                "claim_evidence_map": [{"claim_id": "claim-a", "evidence_ids": ["evidence-a"]}]}

    flow, _store = coordinator(tmp_path, LiteratureRoles(plan, retriever, partial_reviewer, partial_writer, auditor))
    summary = flow.run("task-001", "user-001", question())
    assert summary["workflow_status"] == "partial"


def test_insufficient_review_stops_before_writer_and_auditor(tmp_path):
    calls = []

    def insufficient_reviewer(_plan, _evidence):
        return {"schema_version": 1, "coverage_status": "insufficient", "supported_claims": [],
                "unsupported_questions": ["everything"], "conflicts": [], "allowed_evidence_ids": []}

    def should_not_run(*_args):
        calls.append("called")
        raise AssertionError("writer/auditor must not run")

    flow, _store = coordinator(tmp_path, LiteratureRoles(plan, retriever, insufficient_reviewer, should_not_run, should_not_run))
    summary = flow.run("task-001", "user-001", question())
    assert summary["workflow_status"] == "failed"
    assert summary["failure_code"] == "INSUFFICIENT_EVIDENCE"
    assert calls == []


def test_insufficient_first_review_runs_targeted_recovery_then_writes_partial_answer(tmp_path):
    reviewed = []
    retrieved_queries = []

    def recovering_retriever(group):
        retrieved_queries.extend(group["queries"])
        if group["queries"] == ["method A latency benchmark"]:
            return {"schema_version": 1, "records": [{
                "evidence_id": "evidence-recovered", "group_id": group["id"], "paper_id": "paper-recovered",
                "title": "Recovered paper", "source": "arxiv", "publication_date": None,
                "claim_support": ["claim-recovered"], "excerpt": "Direct benchmark evidence.",
                "fulltext_available": False, "provenance": {"retrieval_run_id": "retrieval-recovered"},
            }]}
        return {"schema_version": 1, "records": []}

    def recovering_reviewer(_plan, evidence):
        reviewed.append(len(evidence["records"]))
        if len(reviewed) == 1:
            return {"schema_version": 1, "coverage_status": "insufficient", "supported_claims": [],
                    "unsupported_questions": ["method A latency"], "conflicts": [], "allowed_evidence_ids": []}
        return {"schema_version": 1, "coverage_status": "partial", "supported_claims": ["claim-recovered"],
                "unsupported_questions": ["method B"], "conflicts": [],
                "allowed_evidence_ids": ["evidence-recovered"]}

    def gap(_plan, _review, _evidence, round_number):
        assert round_number == 1
        return {"schema_version": 1, "round": round_number,
                "groups": [{"group_id": "group-a", "queries": ["method A latency benchmark"]}]}

    def partial_writer(_question, review, _evidence, _prior_audit=None):
        assert review["coverage_status"] == "partial"
        return {"schema_version": 1, "answer": "Only the recovered benchmark is supported.",
                "coverage_status": "partial", "unresolved_questions": ["method B"],
                "claim_evidence_map": [{"claim_id": "claim-recovered", "evidence_ids": ["evidence-recovered"]}]}

    roles = LiteratureRoles(plan, recovering_retriever, recovering_reviewer, partial_writer, auditor, gap)
    flow, store = coordinator(tmp_path, roles)
    summary = flow.run("task-001", "user-001", question())
    assert summary["workflow_status"] == "partial"
    assert summary["model_calls_used"] == 6
    assert reviewed == [0, 1]
    assert "method A latency benchmark" in retrieved_queries
    assert [item["artifact_type"] for item in store.list_artifacts("task-001")].count("research_gap") == 1


def test_recovery_exhaustion_fails_only_when_no_evidence_is_approved(tmp_path):
    gap_rounds = []

    def always_insufficient(_plan, _evidence):
        return {"schema_version": 1, "coverage_status": "insufficient", "supported_claims": [],
                "unsupported_questions": ["everything"], "conflicts": [], "allowed_evidence_ids": []}

    def gap(_plan, _review, _evidence, round_number):
        gap_rounds.append(round_number)
        return {"schema_version": 1, "round": round_number,
                "groups": [{"group_id": "group-a", "queries": [f"missing evidence round {round_number}"]}]}

    flow, _store = coordinator(tmp_path, LiteratureRoles(plan, lambda _group: {"schema_version": 1, "records": []},
                                                           always_insufficient, writer, auditor, gap))
    summary = flow.run("task-001", "user-001", question())
    assert summary["workflow_status"] == "failed"
    assert summary["failure_code"] == "INSUFFICIENT_EVIDENCE"
    assert gap_rounds == [1]


def test_initial_and_recovery_queries_are_bounded_and_persisted_incrementally(tmp_path):
    seen_queries = []

    def many_query_plan(_question):
        return {"schema_version": 1, "groups": [{
            "id": "group-a", "question": "method A",
            "queries": ["q1", "q2", "q3", "q4"], "priority": 1,
        }], "assumptions": [], "out_of_scope": []}

    def empty_retriever(group):
        seen_queries.extend(group["queries"])
        return {"schema_version": 1, "records": [], "retrieval_summary": [{
            "group_id": group["id"], "source": "arxiv", "source_status": "deadline_skipped",
            "candidate_count": 0, "accepted_count": 0, "contextual_count": 0,
            "rejected_count": 0, "round": int(group.get("recovery_round", 0)),
        }]}

    def insufficient(_plan, _evidence):
        return {"schema_version": 1, "coverage_status": "insufficient", "supported_claims": [],
                "unsupported_questions": ["all"], "conflicts": [], "allowed_evidence_ids": []}

    def one_gap(_plan, _review, _evidence, round_number):
        return {"schema_version": 1, "round": round_number,
                "groups": [{"group_id": "group-a", "queries": ["g1", "g2", "g3"]}]}

    flow, store = coordinator(
        tmp_path, LiteratureRoles(many_query_plan, empty_retriever, insufficient, writer, auditor, one_gap),
    )
    summary = flow.run("task-001", "user-001", question())
    assert summary["workflow_status"] == "failed"
    assert seen_queries == ["q1", "q2", "g1", "g2"]
    query_events = [stage for stage in store.list_stages("task-001") if stage["stage"] == "retrieval_query"]
    assert len(query_events) == 4
    assert len([item for item in store.list_artifacts("task-001") if item["artifact_type"] == "evidence_set"]) >= 4


def test_audit_can_request_only_one_budgeted_revision(tmp_path):
    audits = []

    def revise_once(draft, _review):
        audits.append(draft["answer"])
        status = "needs_revision" if len(audits) == 1 else "passed"
        return {"schema_version": 1, "status": status,
                "rejected_claim_ids": ["claim-b"] if status == "needs_revision" else [],
                "claim_results": [{"claim_id": item["claim_id"], "evidence_ids": item["evidence_ids"], "status": "supported"}
                                  for item in draft["claim_evidence_map"]]}

    flow, _store = coordinator(tmp_path, LiteratureRoles(plan, retriever, reviewer, writer, revise_once))
    summary = flow.run("task-001", "user-001", question())
    assert summary["workflow_status"] == "completed"
    assert summary["model_calls_used"] == 6
    assert len(audits) == 2


def test_wrong_group_evidence_is_rejected_before_reviewer(tmp_path):
    def wrong_group(_group):
        result = retriever({"id": "other"})
        return result

    flow, _store = coordinator(tmp_path, LiteratureRoles(plan, wrong_group, reviewer, writer, auditor))
    summary = flow.run("task-001", "user-001", question())
    assert summary["workflow_status"] == "failed"
    assert summary["failure_code"] == "WORKFLOW_CONTRACT_REJECTED"
