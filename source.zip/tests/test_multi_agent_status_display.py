"""Chinese outcome panel is not an answer claim. No network or model calls."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

import pytest

from multi_agent_agents import ArtifactDirectory
from multi_agent_report import export_run_report
from multi_agent_status import describe_status, status_html, status_markdown
from multi_agent_web import exported_report

ROOT = Path(__file__).resolve().parents[1]
STATES = {"completed": "已完成", "partial": "有限回答", "needs_review": "需要复核", "failed": "分析未完成"}
ANSWER = "正文哨兵：已获批的有限结论[1]，实验条件保持不变。"


@pytest.mark.parametrize("status,label", STATES.items())
def test_chinese_state_explanation_is_detailed_and_distinct(status, label):
    display = describe_status(status, audit={"status": "passed"}, coverage=[{"status": "missing"}, {"status": "not_comparable"}])
    assert label in display["title"] and len(display["description"]) >= 30 and len(display["guidance"]) >= 30
    assert len(display["findings"]) == 2
    assert 'aria-label="结果状态与使用建议"' in status_html(display)
    assert "## 结果状态与使用建议" in status_markdown(display)
    if status == "partial":
        assert "保留的声明通过审查" in display["description"]
    if status == "needs_review":
        assert "可靠性也需要进一步核对" in display["description"]
        assert "未经核对" in display["guidance"]


def test_code_audit_failure_does_not_display_passed_model_audit_as_clean():
    display = describe_status("needs_review", audit={"status": "passed", "code_issues": [{"claim_id": "c1"}]})
    assert display["audit_label"] == "存在引用或声明审查疑点"
    display["workflow_notice"] = "<script>fixture</script>"
    assert "<script>fixture</script>" not in status_html(display)
    data = {"status": "needs_review", "audit_status": "passed", "audit_has_unresolved_issues": True,
            "references": [], "direct_answer": ANSWER, "limitation": ""}
    exported = json.loads(exported_report(data, "json")[0])
    assert exported["status_display"]["audit_label"] == "存在引用或声明审查疑点"


@pytest.mark.parametrize("status,label", STATES.items())
def test_web_exports_separate_outcome_from_unchanged_body_and_machine_status(status, label):
    data = {"status": status, "direct_answer": ANSWER, "audit_status": "passed", "references": [], "limitation": "OLD_GENERIC_WARNING"}
    html = exported_report(data, "html")[0].decode()
    md = exported_report(data, "md")[0].decode()
    structured = json.loads(exported_report(data, "json")[0])
    assert label in html.split('<section id="answer"')[0]
    body = html.split('<section id="answer"')[1].split('</section>')[0]
    assert "正文哨兵" in body and "使用建议" not in body and "OLD_GENERIC_WARNING" not in html
    assert label in md.split("## 回答正文")[0]
    assert md.split("## 回答正文\n\n")[1].startswith(ANSWER + "\n\n")
    assert structured["status"] == status and structured["direct_answer"] == ANSWER
    assert label in structured["status_display"]["title"]


@pytest.mark.parametrize("status,label", STATES.items())
def test_cli_exports_panel_without_mutating_original_artifact(tmp_path, status, label):
    artifacts = ArtifactDirectory(tmp_path / "artifacts")
    evidence = {"evidence": [{"evidence_id": "ev-1", "paper_id": "2309.06180", "title": "Paper",
                              "review_status": "approved", "locator": {"page": 2}, "excerpt": "approved"}]}
    refs = {"approved": artifacts.put("approved-evidence", evidence)["artifact_id"],
            "audit": artifacts.put("citation-audit", {"status": "passed"})["artifact_id"]}
    final = {"run_id": "fixture-run", "status": status, "direct_answer": ANSWER, "artifact_refs": refs}
    final_id = artifacts.put("final-result", final)["artifact_id"]
    (tmp_path / "manifest.json").write_text(json.dumps({"run_id": "fixture-run", "final_artifact_id": final_id}), encoding="utf-8")
    artifact_path = tmp_path / "artifacts" / (final_id + ".json")
    before = hashlib.sha256(artifact_path.read_bytes()).hexdigest()
    export_run_report(tmp_path)
    assert hashlib.sha256(artifact_path.read_bytes()).hexdigest() == before
    html = (tmp_path / "final_answer.html").read_text(encoding="utf-8")
    md = (tmp_path / "final_answer.md").read_text(encoding="utf-8")
    assert label in html.split('<section id="answer">')[0]
    assert "使用建议" not in html.split('<section id="answer">')[1].split('</section>')[0]
    assert md.split("## 回答正文\n\n")[1].startswith(ANSWER)


@pytest.mark.parametrize("status,label", STATES.items())
def test_chat_and_viewer_have_independent_outcome_region(status, label):
    node = shutil.which("node")
    if not node:
        pytest.skip("Node needed for DOM substitute tests; these are not browser checks")
    harness = r'''
const vm=require('node:vm'), nodes=[];
function el(tag) {
 const item={tag,children:[],dataset:{},events:{},append(...items){this.children.push(...items);},
 addEventListener(k,v){this.events[k]=v;},showModal(){},remove(){},classList:{toggle(){}},querySelector(){return null;}};
 Object.defineProperty(item,'textContent',{get(){return this._text??this.children.map(n=>n.textContent??'').join('');},set(v){this._text=String(v);this.children=[];}});
 Object.defineProperty(item,'innerHTML',{set(){throw Error('unsafe HTML');}});nodes.push(item);return item;
}
const container=el('div'), window={currentSessionId:'s1',userToken:'fixture',location:{search:''},addEventListener(){}};
const context={window,document:{createElement:el,body:el('body'),getElementById:()=>container,createTreeWalker:()=>({nextNode:()=>false})},
 NodeFilter:{SHOW_TEXT:4},AbortController,DOMException,URLSearchParams,setInterval(){},setTimeout(){},
 fetch:async()=>({ok:true,json:async()=>({status:STATUS,direct_answer:ANSWER,references:[],coverage:[]})})};
vm.runInNewContext(SOURCE,context);
(async()=>{
 window.MultiAgentRagUI.attach({id:'abcdef012345',status:STATUS,processing_mode:'multi_agent_rag',execution:{}},'s1');
 await window.MultiAgentRagUI.open('abcdef012345', null, true);
 const panels=nodes.filter(n=>(n.className||'').startsWith('rag-outcome-panel'));
 const answers=nodes.filter(n=>n.className==='rag-linked-answer');
 console.log(JSON.stringify({panels:panels.map(p=>({state:p.dataset.resultStatus,text:p.children.map(n=>n.textContent).join('\n')})),
 answers:answers.map(n=>n.textContent),separate:container.children[0]?.className==='rag-report-card'}));
})().catch(e=>{console.error(e);process.exit(1);});
'''
    source = (ROOT / "chatAi/multi_agent_rag.js").read_text(encoding="utf-8")
    script = "const SOURCE=" + json.dumps(source) + ";const STATUS=" + json.dumps(status) + ";const ANSWER=" + json.dumps(ANSWER) + ";\n" + harness
    result = subprocess.run([node, "-"], input=script, capture_output=True, text=True, encoding="utf-8", timeout=10)
    assert result.returncode == 0, result.stderr
    data = json.loads(result.stdout)
    assert len(data["panels"]) == 2 and data["separate"] and data["answers"] == [ANSWER]
    assert all(p["state"] == status and label in p["text"] and "使用建议" in p["text"] for p in data["panels"])
    display = describe_status(status)
    assert all(display["description"] in p["text"] and display["guidance"] in p["text"] for p in data["panels"])
    assert len({describe_status(key)["description"] for key in STATES}) == 4


def test_chat_no_longer_injects_status_warning_into_answer():
    source = (ROOT / "chatAi/ai_chat.html").read_text(encoding="utf-8")
    assert "answer = '> **有限回答：仅依据批准原文片段" not in source
    assert "MultiAgentRagUI?.attach" in source


def test_status_dependency_is_in_cloud_images_and_runtime_identity():
    from runtime_identity import IDENTITY_FILES
    from tools.cloud_release import REQUIRED
    assert "multi_agent_status.py" in IDENTITY_FILES and "multi_agent_status.py" in REQUIRED
    for name in ("Dockerfile.cloud", "Dockerfile.account.cloud"):
        text = (ROOT / name).read_text(encoding="utf-8")
        assert any(line.startswith("COPY ") and "multi_agent_status.py" in line and "multi_agent_evidence.py" in line
                   and line.endswith(" /app/") for line in text.splitlines())
