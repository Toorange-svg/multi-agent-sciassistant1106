"""Restart snapshots preserve terminal task access without resuming workers."""
import json
import tempfile
from pathlib import Path
from unittest import TestCase, mock

import app as account_app
import web_app


class TaskRestartPersistenceTests(TestCase):
    def setUp(self):
        self.auth_version = mock.patch.object(
            account_app, "_current_auth_version", return_value=0)
        self.auth_version.start()
        self.tempdir = tempfile.TemporaryDirectory()
        self.old_task_dir = web_app.TASK_STATE_DIR
        self.old_tasks = web_app.TASKS.copy()
        self.old_owner_path = account_app.SCIENCE_TASK_OWNER_STATE_PATH
        self.old_account_task_dir = account_app.SCIENCE_TASK_STATE_DIR
        self.old_owners = account_app._SCIENCE_TASK_OWNERS.copy()
        self.old_context_owner_path = account_app.CONTEXT_FILE_OWNER_STATE_PATH
        self.old_context_owners = account_app._CONTEXT_FILE_OWNERS.copy()
        web_app.TASK_STATE_DIR = Path(self.tempdir.name) / "task_state"
        web_app.TASK_STATE_DIR.mkdir(parents=True)
        account_app.SCIENCE_TASK_OWNER_STATE_PATH = Path(self.tempdir.name) / "owners.json"
        account_app.SCIENCE_TASK_STATE_DIR = web_app.TASK_STATE_DIR
        account_app.CONTEXT_FILE_OWNER_STATE_PATH = Path(self.tempdir.name) / "context-owners.json"
        with web_app.TASK_LOCK:
            web_app.TASKS.clear()
        with account_app._RESOURCE_OWNER_LOCK:
            account_app._SCIENCE_TASK_OWNERS.clear()
            account_app._CONTEXT_FILE_OWNERS.clear()

    def tearDown(self):
        self.auth_version.stop()
        with web_app.TASK_LOCK:
            web_app.TASKS.clear()
            web_app.TASKS.update(self.old_tasks)
        with account_app._RESOURCE_OWNER_LOCK:
            account_app._SCIENCE_TASK_OWNERS.clear()
            account_app._SCIENCE_TASK_OWNERS.update(self.old_owners)
            account_app._CONTEXT_FILE_OWNERS.clear()
            account_app._CONTEXT_FILE_OWNERS.update(self.old_context_owners)
        web_app.TASK_STATE_DIR = self.old_task_dir
        account_app.SCIENCE_TASK_OWNER_STATE_PATH = self.old_owner_path
        account_app.SCIENCE_TASK_STATE_DIR = self.old_account_task_dir
        account_app.CONTEXT_FILE_OWNER_STATE_PATH = self.old_context_owner_path
        self.tempdir.cleanup()

    def test_terminal_task_snapshot_restores_after_memory_is_cleared(self):
        task = {"id": "finished-task", "status": "completed", "answer": "稳定答案"}
        with web_app.TASK_LOCK:
            web_app.TASKS[task["id"]] = task
            web_app._persist_task_locked(task)
            web_app.TASKS.clear()

        self.assertEqual(web_app._restore_persisted_tasks(), 1)
        self.assertEqual(web_app.TASKS["finished-task"]["status"], "completed")
        self.assertEqual(web_app.TASKS["finished-task"]["answer"], "稳定答案")

    def test_active_snapshot_is_explicitly_failed_after_restart(self):
        task = {"id": "active-task", "status": "running", "message": "处理中"}
        with web_app.TASK_LOCK:
            web_app.TASKS[task["id"]] = task
            web_app._persist_task_locked(task)
            web_app.TASKS.clear()

        web_app._restore_persisted_tasks()
        restored = web_app.TASKS["active-task"]
        self.assertEqual(restored["status"], "failed")
        self.assertTrue(restored["interrupted_by_restart"])
        self.assertIn("服务重启", restored["message"])

    def test_task_owner_binding_restores_without_storing_a_jwt(self):
        with account_app._RESOURCE_OWNER_LOCK:
            account_app._SCIENCE_TASK_OWNERS["owned-task"] = "owner-a"
            account_app._persist_science_task_owners_locked()
            account_app._SCIENCE_TASK_OWNERS.clear()

        self.assertEqual(account_app._restore_science_task_owners(), 1)
        self.assertEqual(account_app._SCIENCE_TASK_OWNERS, {"owned-task": "owner-a"})
        snapshot = account_app.SCIENCE_TASK_OWNER_STATE_PATH.read_text(encoding="utf-8")
        self.assertNotIn("Bearer", snapshot)
        self.assertNotIn("token", snapshot.lower())

    def test_context_file_owner_restores_without_storing_a_jwt(self):
        with account_app._RESOURCE_OWNER_LOCK:
            account_app._CONTEXT_FILE_OWNERS["context-file"] = "owner-a"
            account_app._persist_context_file_owners_locked()
            account_app._CONTEXT_FILE_OWNERS.clear()

        self.assertEqual(account_app._restore_context_file_owners(), 1)
        self.assertEqual(account_app._CONTEXT_FILE_OWNERS, {"context-file": "owner-a"})
        snapshot = account_app.CONTEXT_FILE_OWNER_STATE_PATH.read_text(encoding="utf-8")
        self.assertNotIn("Bearer", snapshot)
        self.assertNotIn("token", snapshot.lower())

    def test_utf8_bom_task_owner_restores_without_granting_other_accounts(self):
        account_app.SCIENCE_TASK_OWNER_STATE_PATH.write_text(
            json.dumps({"bom-task": "owner-a"}), encoding="utf-8-sig")
        self.assertEqual(account_app._restore_science_task_owners(), 1)
        self.assertEqual(account_app._SCIENCE_TASK_OWNERS, {"bom-task": "owner-a"})
        client = account_app.app.test_client()
        upstream = (b'{"task":{"id":"bom-task","status":"partial"}}', 200,
                    [("Content-Type", "application/json")])
        with mock.patch.object(account_app, "_science_dispatch", return_value=upstream) as dispatch:
            for owner, expected in (("owner-a", 200), ("owner-b", 404), (None, 401)):
                headers = {"Authorization": "Bearer " + account_app.generate_token(owner, owner)} if owner else {}
                self.assertEqual(client.get("/api/science/tasks/bom-task", headers=headers).status_code, expected)
            dispatch.assert_called_once()

    def test_utf8_bom_context_owner_restores(self):
        account_app.CONTEXT_FILE_OWNER_STATE_PATH.write_text(
            json.dumps({"bom-file": "owner-a"}), encoding="utf-8-sig")
        self.assertEqual(account_app._restore_context_file_owners(), 1)
        self.assertEqual(account_app._CONTEXT_FILE_OWNERS, {"bom-file": "owner-a"})

    def test_invalid_owner_json_still_fails_closed_with_safe_diagnostics(self):
        for path, load, owners in (
            (account_app.SCIENCE_TASK_OWNER_STATE_PATH, account_app._restore_science_task_owners, account_app._SCIENCE_TASK_OWNERS),
            (account_app.CONTEXT_FILE_OWNER_STATE_PATH, account_app._restore_context_file_owners, account_app._CONTEXT_FILE_OWNERS),
        ):
            path.write_text('{invalid-private-canary', encoding="utf-8-sig")
            with mock.patch.object(account_app.logger, "warning") as warning:
                self.assertEqual(load(), 0)
            self.assertEqual(owners, {})
            warning.assert_called_once()
            self.assertEqual(warning.call_args.args[1], "JSONDecodeError")
            self.assertNotIn("private-canary", str(warning.call_args))
            self.assertNotIn(str(path), str(warning.call_args))

    def test_missing_owner_recovers_from_snapshot_and_authoritative_chat(self):
        task = {"id": "recover-task", "status": "failed", "conversation_id": "conversation-a"}
        with web_app.TASK_LOCK:
            web_app._persist_task_locked(task)
        connection = _FakeConnection(owned=True)
        with mock.patch.object(account_app, "get_db_connection", return_value=connection):
            self.assertTrue(account_app._recover_science_task_owner_from_snapshot("recover-task", "owner-a"))
        self.assertEqual(account_app._SCIENCE_TASK_OWNERS["recover-task"], "owner-a")
        self.assertEqual(connection.params, ("conversation-a", "owner-a"))
        self.assertNotIn("conversation_detail", connection.sql.lower())
        persisted = account_app.SCIENCE_TASK_OWNER_STATE_PATH.read_text(encoding="utf-8")
        self.assertIn('"recover-task": "owner-a"', persisted)
        self.assertNotIn("Bearer", persisted)

    def test_wrong_user_cannot_claim_unbound_snapshot(self):
        task = {"id": "private-task", "status": "failed", "conversation_id": "conversation-a"}
        with web_app.TASK_LOCK:
            web_app._persist_task_locked(task)
        connection = _FakeConnection(owned=False)
        with mock.patch.object(account_app, "get_db_connection", return_value=connection):
            self.assertFalse(account_app._recover_science_task_owner_from_snapshot("private-task", "owner-b"))
        self.assertNotIn("private-task", account_app._SCIENCE_TASK_OWNERS)

    def test_gateway_status_route_recovers_binding_before_dispatch(self):
        task = {"id": "route-task", "status": "failed", "conversation_id": "conversation-a"}
        with web_app.TASK_LOCK:
            web_app._persist_task_locked(task)
        connection = _FakeConnection(owned=True)
        token = account_app.generate_token("owner-a", "owner")
        response_body = (b'{"id":"route-task","status":"failed"}', 200,
                         [("Content-Type", "application/json")])
        with mock.patch.object(account_app, "get_db_connection", return_value=connection), \
             mock.patch.object(account_app, "_science_dispatch", return_value=response_body) as dispatch:
            response = account_app.app.test_client().get(
                "/api/science/tasks/route-task",
                headers={"Authorization": f"Bearer {token}"},
            )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["status"], "failed")
        dispatch.assert_called_once_with("/api/tasks/route-task")
        self.assertEqual(account_app._SCIENCE_TASK_OWNERS["route-task"], "owner-a")

    def test_existing_owner_is_never_overwritten_by_recovery(self):
        account_app._SCIENCE_TASK_OWNERS["bound-task"] = "owner-a"
        with account_app.app.test_request_context():
            from flask import g
            g.current_user_id = "owner-b"
            with mock.patch.object(account_app, "_recover_science_task_owner_from_snapshot") as recover:
                with self.assertRaises(Exception) as raised:
                    account_app._require_science_task_owner("bound-task")
        self.assertEqual(getattr(raised.exception, "code", None), 404)
        recover.assert_not_called()
        self.assertEqual(account_app._SCIENCE_TASK_OWNERS["bound-task"], "owner-a")

    def test_malformed_or_unlinked_snapshot_grants_nothing(self):
        cases = {
            "mismatch": {"id": "other", "conversation_id": "conversation-a"},
            "unlinked": {"id": "unlinked", "status": "failed"},
        }
        for task_id, payload in cases.items():
            (account_app.SCIENCE_TASK_STATE_DIR / f"{task_id}.json").write_text(
                json.dumps(payload), encoding="utf-8")
            self.assertFalse(account_app._recover_science_task_owner_from_snapshot(task_id, "owner-a"))
        self.assertEqual(account_app._SCIENCE_TASK_OWNERS, {})


class _FakeCursor:
    def __init__(self, connection):
        self.connection = connection

    def __enter__(self):
        return self

    def __exit__(self, *_):
        return False

    def execute(self, sql, params):
        self.connection.sql = sql
        self.connection.params = params

    def fetchone(self):
        return {"owned": 1} if self.connection.owned else None


class _FakeConnection:
    def __init__(self, owned):
        self.owned = owned
        self.sql = ""
        self.params = None
        self.closed = False

    def cursor(self):
        return _FakeCursor(self)

    def close(self):
        self.closed = True


if __name__ == "__main__":
    unittest.main()
