"""Real offline CLI-to-Web bridge, final artifacts and authenticated resource boundaries."""
import io
import json
import os
import re
import sys
import time
import threading
import subprocess
from pathlib import Path

import pytest

import app as account
import web_app as web
import multi_agent_web as adapter
from multi_agent_agents import ArtifactDirectory
from multi_agent_workflow import WorkflowStore
from multi_agent_report import export_run_report

TASK = "abcdef012345"


@pytest.fixture
def isolated(tmp_path, monkeypatch):
    monkeypatch.setenv("SCIASSISTANT_MULTI_AGENT_WEB_RUN_ROOT", str(tmp_path / "runs"))
    monkeypatch.setenv("SCIASSISTANT_MULTI_AGENT_WEB_STORAGE_ROOT", str(tmp_path / "rag"))
    monkeypatch.setenv("SCIASSISTANT_WEB_BASE", "")
    monkeypatch.setattr(web, "LOG_DIR", tmp_path)
    monkeypatch.setattr(web, "TASK_STATE_DIR", tmp_path / "state")
    monkeypatch.setattr(web, "UPLOAD_DIR", tmp_path / "uploads")
    web.UPLOAD_DIR.mkdir()
    monkeypatch.setattr(web, "TASKS", {})
    monkeypatch.setattr(web, "_RETRIEVAL_PROCESSES", {})
    monkeypatch.setattr(account, "_SCIENCE_TASK_OWNERS", {TASK: "owner-a"})
    monkeypatch.setattr(account, "_current_auth_version", lambda _id: 0)
    monkeypatch.setattr(account, "_recover_science_task_owner_from_snapshot", lambda *_: False)
    return tmp_path


def seed():
    web.TASKS[TASK] = {"id": TASK, "query": "mock question", "status": "queued",
        "created_at": web._now(), "processing_mode": adapter.MODE, "conversation_context": {"status": "none"}}


def headers(owner="owner-a"):
    return {"Authorization": "Bearer " + account.generate_token(owner, owner)}


@pytest.fixture
def completed(isolated):
    seed()
    web._run_multi_agent_rag_task(TASK, "mock question", mode="mock")
    assert web.TASKS[TASK]["status"] == "partial"
    return isolated


def test_real_mock_cli_bridge_terminal_and_budget(completed):
    task = web.TASKS[TASK]
    assert task["report_available"]
    assert task["execution"]["model_calls"] == 5
    assert task["execution"]["model_call_limit"] == 10
    assert task["execution"]["mcp_lifecycle"] == "not_required"
    assert not web._RETRIEVAL_PROCESSES
    assert not list(completed.glob("multi_agent_question_*"))
    report = adapter.report(TASK)
    assert len(report['references']) == 1 and len(report['claims']) == 2
    assert {c['report_section_id'] for c in report['claims']} == {'summary', 'analysis-group-1'}
    assert all(set(c['evidence_ids']) == {report['references'][0]['evidence_id']} for c in report['claims'])
    assert report["references"][0]["review_status"] == "approved"
    assert "[1]" in report["direct_answer"]
    assert adapter.progress(TASK)["workflow_status"] == "partial"


def test_enhanced_profile_survives_web_cli_store_and_progress(isolated):
    seed()
    web.TASKS[TASK]['report_profile']='enhanced'
    web._run_multi_agent_rag_task(TASK, 'mock question', mode='mock')
    task=web.TASKS[TASK]
    assert task['status']=='partial'
    assert task['execution']['model_call_limit']==20
    progress=adapter.progress(TASK)
    assert progress['report_profile']=='enhanced' and progress['time_budget_seconds']==720
    assert progress['research_start_cutoff_seconds']==600
    assert progress['model_call_limit']==20 and progress['time_budget_is_estimate']
    directory=adapter.run_directory(TASK)
    manifest=json.loads((directory/'manifest.json').read_text(encoding='utf-8'))
    assert manifest['report_profile']=='enhanced' and manifest['research_start_cutoff_seconds']==600
    packets=[json.loads(p.read_text(encoding='utf-8'))['input'] for p in (directory/'agents').glob('*.json')]
    assert len(packets)==5 and all(p['report_profile']=='enhanced' for p in packets)
    assert all(p['schema_version']=='sciassistant.agent-input/v2' for p in packets)


@pytest.mark.parametrize('value', ['automatic', None, {}, True, 20])
def test_api_rejects_invalid_report_profile_before_task_creation(isolated,monkeypatch,value):
    monkeypatch.setattr(web,'_enqueue_retrieval_task',lambda *a,**k: pytest.fail('must not enqueue'))
    response=web.app.test_client().post('/api/tasks',json={'query':'解释原始LoRA的机制','processing_mode':adapter.MODE,'report_profile':value})
    assert response.status_code==400 and response.json['error']=='REPORT_PROFILE_INVALID'
    assert not web.TASKS


def test_api_explicit_profile_persists(isolated,monkeypatch):
    monkeypatch.setattr(adapter,'readiness',lambda:{'ready':True})
    monkeypatch.setattr(web,'_missing_task_configuration',lambda _:[])
    jobs=[]
    monkeypatch.setattr(web,'_enqueue_retrieval_task',lambda *a,**k:jobs.append((a,k)))
    response=web.app.test_client().post('/api/tasks',json={'query':'依据原始论文解释LoRA的低秩更新机制',
        'processing_mode':adapter.MODE,'report_profile':'enhanced'})
    assert response.status_code==202, response.json
    assert response.json['task']['report_profile']=='enhanced'
    assert len(jobs)==1
    path=web._task_state_path(response.json['task']['id'])
    assert json.loads(path.read_text(encoding='utf-8'))['report_profile']=='enhanced'


def test_temporary_cleanup_failure_still_releases_worker_lock(isolated, monkeypatch):
    seed()
    monkeypatch.setattr(adapter, "command", lambda *args, **kwargs: (_ for _ in ()).throw(ValueError("fixture")))
    original = Path.unlink
    def failed_cleanup(path, *args, **kwargs):
        if path.name.startswith("multi_agent_question_"):
            raise PermissionError("private-path-canary")
        return original(path, *args, **kwargs)
    monkeypatch.setattr(Path, "unlink", failed_cleanup)
    web._run_multi_agent_rag_task(TASK, "mock question", mode="mock")
    assert web.TASKS[TASK]["status"] == "failed"
    acquired = web._MULTI_AGENT_RAG_LOCK.acquire(blocking=False)
    assert acquired
    if acquired:
        web._MULTI_AGENT_RAG_LOCK.release()
    assert not web._RETRIEVAL_PROCESSES


def test_rag_writer_locks_are_scoped_per_account(isolated):
    web.TASKS['owner-a-task'] = {'id': 'owner-a-task', 'user_id': 'owner-a'}
    web.TASKS['owner-b-task'] = {'id': 'owner-b-task', 'user_id': 'owner-b'}
    owner_a, lock_a = web._rag_lock_for_task('owner-a-task')
    owner_b, lock_b = web._rag_lock_for_task('owner-b-task')
    assert owner_a == 'owner-a' and owner_b == 'owner-b' and lock_a is not lock_b
    assert lock_a.acquire(blocking=False)
    try:
        assert lock_a.acquire(blocking=False)
        assert lock_a.acquire(blocking=False)
        assert not web._rag_lock_for_task('owner-a-task')[1].acquire(blocking=False)
        lock_a.release()
        lock_a.release()
        assert lock_b.acquire(blocking=False)
        lock_b.release()
    finally:
        lock_a.release()


@pytest.mark.parametrize("suffix", ["report", "report/export?format=html", "report/export?format=md", "report/export?format=json", "report/assets/pdf/private/source.pdf"])
def test_every_report_resource_is_owner_authenticated(completed, suffix):
    client = account.app.test_client()
    url = f"/api/science/tasks/{TASK}/{suffix}"
    assert client.get(url).status_code == 401
    assert client.get(url, headers=headers("owner-b")).status_code == 404
    assert client.get(url, headers=headers()).status_code == (404 if "/assets/" in suffix else 200)


def test_parent_task_is_checked_before_dispatch(isolated, monkeypatch):
    def forbidden(_path):
        raise AssertionError("must not dispatch another account's parent")
    monkeypatch.setattr(account, "_science_dispatch", forbidden)
    response = account.app.test_client().post("/api/science/tasks", headers=headers("owner-b"),
        json={"query": "follow-up", "processing_mode": adapter.MODE, "parent_task_id": TASK})
    assert response.status_code == 404


def test_partial_is_exportable_and_cannot_be_cancelled(completed):
    before = web.TASKS[TASK]["status"]
    client = account.app.test_client()
    response = client.post(f"/api/science/tasks/{TASK}/cancel", headers=headers())
    assert response.get_json()["task"]["status"] == before == "partial"
    assert client.get(f"/api/science/tasks/{TASK}/export?format=md", headers=headers()).status_code == 200


def test_final_artifact_tampering_rejected(completed):
    directory = adapter.run_directory(TASK)
    manifest = json.loads((directory / "manifest.json").read_text())
    path = directory / "artifacts" / (manifest["final_artifact_id"] + ".json")
    path.write_text('{"status":"completed"}', encoding="utf-8")
    response = account.app.test_client().get(f"/api/science/tasks/{TASK}/report", headers=headers())
    assert response.status_code == 409
    assert response.get_json()["error"] == "REPORT_INTEGRITY_REJECTED"


def test_report_exports_keep_coverage_claim_mapping_and_safe_navigation(completed):
    data = adapter.report(TASK)
    data["direct_answer"] += "\n<script>canary()</script> unsupported [999]"
    data["coverage"] = [{"topic": "paged_attention", "metric": "latency", "evidence_status": "not_comparable"}]
    for fmt in ("md", "html", "json"):
        content, _ = adapter.exported_report(data, fmt)
        text = content.decode("utf-8")
        assert ("not_comparable" if fmt == 'json' else '实验不可直接比较') in text
        assert data["claims"][0]["text"] in (text if fmt != "html" else __import__("html").unescape(text))
        if fmt == "html":
            assert '<script>canary()' not in text and '&lt;script&gt;' in text
            assert 'href="#evidence-1"' in text and 'href="#evidence-999"' not in text
            assert 'id="claims"' not in text and 'id="bibliography"' in text and '引用未发布' in text
            assert 'research-note' in text
        elif fmt == "json":
            assert json.loads(text)["claims"][0]["evidence_ids"] == data["claims"][0]["evidence_ids"]
        else:
            assert "## 原文证据与对应说明" in text and "## 参考文献" in text
            assert "## 逐声明证据映射" not in text


def test_active_report_not_published(isolated):
    seed()
    response = account.app.test_client().get(f"/api/science/tasks/{TASK}/report", headers=headers())
    assert response.status_code == 409


@pytest.mark.parametrize('profile', ['standard', 'enhanced'])
def test_default_mode_routes_greeting_direct_but_keeps_pdf(isolated, monkeypatch, profile):
    monkeypatch.setattr(adapter, "readiness", lambda: {"ready": True})
    monkeypatch.setattr(web, "_missing_task_configuration", lambda _: [])
    jobs = []
    direct = []
    monkeypatch.setattr(web, "_start_background_task", lambda *args, **kwargs: direct.append((args, kwargs)))
    monkeypatch.setattr(web, "_enqueue_retrieval_task", lambda *args, **kwargs: jobs.append((args, kwargs)))
    client = web.app.test_client()
    response = client.post("/api/tasks", json={"query": "你好", "processing_mode": adapter.MODE, "report_profile":profile})
    assert response.status_code == 202
    assert not jobs and direct[0][0][1] is web._run_general_chat_task
    assert response.json['task']['processing_mode'] == 'general_answer'
    assert response.json['task']['source_scope'] is None
    assert response.json['task']['report_profile']=='standard'
    response = client.post("/api/tasks", data={"query": "PDF", "processing_mode": adapter.MODE,
        "report_profile":profile, "pdf": (io.BytesIO(b"%PDF-1.7"), "demo.pdf")})
    assert response.status_code == 202
    assert response.json["task"]["processing_mode"] == adapter.MODE
    assert response.json["task"]["source_scope"] == "uploaded_pdf"
    assert response.json['task']['report_profile']==profile
    assert len(jobs) == 1 and jobs[0][1]["pdf"].is_file()


def test_followup_is_bounded_structured_context_not_evidence(isolated):
    seed()
    web.TASKS[TASK]["conversation_context"] = {"status": "ready", "previous_query": "old topic",
        "previous_answer": "old conclusion", "paper_ids": ["2309.06180v1"]}
    web._run_multi_agent_rag_task(TASK, "compare these", mode="mock")
    directory = adapter.run_directory(TASK)
    recorded = json.loads((directory / "agents/01-planner.json").read_text(encoding="utf-8"))
    question = ArtifactDirectory(directory / "artifacts").get(recorded["input"]["input_artifact_ids"][0])
    assert question["schema_version"] == "sciassistant.question/v2"
    assert question["conversation_context"]["evidence_policy"] == "context_only_retrieve_again"
    assert not list(isolated.glob("multi_agent_context_*"))


def test_restart_synchronizes_active_inner_workflow(isolated):
    seed()
    directory = adapter.run_directory(TASK)
    directory.mkdir(parents=True)
    store = WorkflowStore(directory / "workflow.sqlite3")
    store.create_run(TASK, "web")
    web.TASKS[TASK]["status"] = "running"
    web._persist_task_locked(web.TASKS[TASK])
    web.TASKS.clear()
    web._restore_persisted_tasks()
    assert web.TASKS[TASK]["status"] == "failed"
    assert store.get_run(TASK)["status"] == "failed"
    assert store.get_run(TASK)["failure_code"] == "SERVICE_RESTARTED"


def test_readiness_is_authenticated_and_safe(isolated, monkeypatch):
    monkeypatch.setenv("SCIASSISTANT_MULTI_AGENT_RAG_ENABLED", "0")
    client = account.app.test_client()
    assert client.get("/api/science/multi-agent/readyz").status_code == 401
    response = client.get("/api/science/multi-agent/readyz", headers=headers())
    assert response.status_code == 503
    assert response.get_json()["ready"] is False
    assert str(isolated) not in response.get_data(as_text=True)


def test_query_is_not_in_process_argv(isolated):
    argv = adapter.command(TASK, isolated / "question.txt")
    assert "--query-file" in argv and "--query" not in argv
    assert "--worker" in argv and "--rag-mode" in argv


def test_web_vector_path_cannot_lock_the_cli_cache(isolated, monkeypatch):
    monkeypatch.delenv("SCIASSISTANT_QDRANT_URL", raising=False)
    monkeypatch.setenv("SCIASSISTANT_QDRANT_PATH", "logs/cli-cache")
    environment = adapter.environment()
    assert environment["SCIASSISTANT_QDRANT_PATH"] == str((isolated / "rag/qdrant").resolve())
    assert environment["SCIASSISTANT_EMBEDDING_ALLOW_DOWNLOAD"] == "0"
    assert __import__("os").environ["SCIASSISTANT_QDRANT_PATH"] == "logs/cli-cache"


def test_task_namespace_isolated_for_same_account_parallel_slots(isolated, monkeypatch):
    monkeypatch.delenv("SCIASSISTANT_QDRANT_URL", raising=False)
    args = adapter.command(TASK, isolated / "question.txt", task_namespace=TASK)
    storage = args[args.index("--storage-root") + 1].replace('\\', '/')
    environment = adapter.environment(task_namespace=TASK)
    assert storage.endswith(f"/users/owner-a/tasks/{TASK}") or f"/tasks/{TASK}" in storage
    assert f"/tasks/{TASK}/qdrant" in environment["SCIASSISTANT_QDRANT_PATH"].replace('\\', '/')


def test_outer_cancel_wins_during_unpublished_report_render(completed):
    # The core can finish before page rendering finishes. Until Web publication,
    # an outer cancellation must still stop the task and synchronize its store.
    web.TASKS[TASK]["status"] = "running"
    task, _ = web._cancel_task(TASK)
    assert task["status"] == "cancelled"
    assert adapter.progress(TASK)["workflow_status"] == "cancelled"
    assert account.app.test_client().get(f"/api/science/tasks/{TASK}/report", headers=headers()).status_code == 409


def test_completed_task_and_report_survive_snapshot_reload(completed):
    web.TASKS.clear()
    assert web._restore_persisted_tasks() == 1
    response = account.app.test_client().get(f"/api/science/tasks/{TASK}/report", headers=headers())
    assert response.status_code == 200
    assert response.get_json()["status"] == "partial"


def test_real_pdf_page_image_and_account_asset_isolation(completed):
    reference = _add_offline_pdf_assets(TASK)
    assert reference["page_size"] == [600, 800]
    assert reference["page_image_asset"] == "pages/evidence-1.png"
    assert reference["preview_locator"]["bbox"] == reference["locator"]["bbox"]
    assert reference["preview_locator"]["highlight_method"] == "bbox"
    client = account.app.test_client()
    for name in (reference["pdf_asset"], reference["page_image_asset"]):
        url = f"/5000/api/science/tasks/{TASK}/report/assets/{name}"
        assert client.get(url).status_code == 401
        assert client.get(url, headers=headers("owner-b")).status_code == 404
        response = client.get(url, headers=headers())
        assert response.status_code == 200
        assert response.headers["Cache-Control"] == "no-store"
        assert response.data.startswith(b"%PDF" if name.endswith("pdf") else b"\x89PNG")
    # Another PNG exists on disk but is not referenced by approved evidence.
    (adapter.run_directory(TASK) / "pages/evidence-2.png").write_bytes(b"not approved")
    assert client.get(f"/api/science/tasks/{TASK}/report/assets/pages/evidence-2.png", headers=headers()).status_code == 404


@pytest.mark.parametrize("rotation", [90, 180, 270])
def test_web_report_uses_display_coordinates_and_retains_audited_locator(completed, rotation):
    import fitz
    import copy
    reference = _add_offline_pdf_assets(TASK)
    original = copy.deepcopy(reference["locator"])
    directory = adapter.run_directory(TASK)
    with fitz.open(directory / reference["pdf_asset"]) as document:
        page = document[0]
        page.set_rotation(rotation)
        expected = list(fitz.Rect(original["bbox"]) * page.rotation_matrix)
        document.saveIncr()
    export_run_report(directory)
    response = account.app.test_client().get(f"/api/science/tasks/{TASK}/report", headers=headers())
    assert response.status_code == 200
    row = response.get_json()["references"][0]
    assert row["locator"] == original
    assert row["preview_locator"]["bbox"] == pytest.approx(expected)
    assert row["preview_locator"]["page_size"] == row["page_size"]
    assert row["preview_locator"]["coordinate_space"] == "rendered_page_points"
    assert response.get_json()["execution"]["model_calls"] == 5


def _add_offline_pdf_assets(task_id):
    import fitz
    directory = adapter.run_directory(task_id)
    pdf = directory / "pdf/demo-paper/source.pdf"
    pdf.parent.mkdir(parents=True)
    document = fitz.open()
    page = document.new_page(width=600, height=800)
    page.insert_text((30, 50), "Offline citation canary")
    document.save(pdf); document.close()
    manifest = json.loads((directory / "manifest.json").read_text(encoding="utf-8"))
    artifacts = ArtifactDirectory(directory / "artifacts")
    final = artifacts.get(manifest["final_artifact_id"])
    approved = artifacts.get(final["artifact_refs"]["approved"])
    approved["evidence"][0].update(document_id="demo-paper", locator={"page": 1, "section": "Demo", "bbox": [25, 30, 230, 70], "anchor_text": "Offline citation canary"})
    final["artifact_refs"]["approved"] = artifacts.put("approved-evidence", approved)["artifact_id"]
    manifest["final_artifact_id"] = artifacts.put("final-result", final)["artifact_id"]
    (directory / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    export_run_report(directory)
    return adapter.report(task_id)["references"][0]


def test_api_owner_and_report_restore_in_two_fresh_processes(isolated, monkeypatch):
    # Real gateway -> local Web creation; only configuration/queue/model work is
    # stubbed. The caller cannot choose ownership through body fields.
    owner_path = isolated / "owners.json"
    monkeypatch.setattr(account, "SCIENCE_TASK_OWNER_STATE_PATH", owner_path)
    monkeypatch.setattr(account, "_SCIENCE_TASK_OWNERS", {})
    monkeypatch.setattr(account, "_LOCAL_SCIENCE_APP", web.app)
    monkeypatch.setattr(adapter, "readiness", lambda: {"ready": True})
    monkeypatch.setattr(web, "_missing_task_configuration", lambda _: [])
    monkeypatch.setattr(web, "_enqueue_retrieval_task", lambda *args: None)
    created = account.app.test_client().post("/5000/api/science/tasks", headers=headers(),
        json={"query": "offline ownership probe", "processing_mode": adapter.MODE,
              "user_id": "owner-b", "owner": "owner-b"})
    assert created.status_code == 202
    task_id = created.get_json()["task"]["id"]
    assert json.loads(owner_path.read_text(encoding="utf-8")) == {task_id: "owner-a"}
    assert not web.TASKS[task_id].get("conversation_id")
    web._run_multi_agent_rag_task(task_id, "offline ownership probe", mode="mock")
    reference = _add_offline_pdf_assets(task_id)
    urls = [f"/5000/api/science/tasks/{task_id}", f"/5000/api/science/tasks/{task_id}/report"]
    urls += [urls[1] + "/export?format=" + fmt for fmt in ("html", "md", "json")]
    urls += [urls[1] + "/assets/" + reference[key] for key in ("pdf_asset", "page_image_asset")]
    env = os.environ.copy()
    env["SCIASSISTANT_TASK_OWNER_STATE_PATH"] = str(owner_path)
    env["SCIASSISTANT_TASK_STATE_DIR"] = str(web.TASK_STATE_DIR)
    script = '''
import json, sys
import app as account
account._current_auth_version = lambda _id: 0
def forbidden_db():
    raise AssertionError("unlinked task must recover from owner store, not chat DB")
account.get_db_connection = forbidden_db
client = account.app.test_client()
urls = json.loads(sys.argv[1])
matrix = []
for user in ("owner-a", "owner-b", None):
    headers = {"Authorization": "Bearer " + account.generate_token(user, user)} if user else {}
    matrix.append([client.get(url, headers=headers).status_code for url in urls])
response = client.get(urls[1], headers={"Authorization": "Bearer " + account.generate_token("owner-a", "owner-a")})
report = response.get_json()
print(json.dumps({"matrix": matrix, "status": report["status"], "calls": report["execution"]["model_calls"], "references": len(report["references"])}))
'''
    original_owner = owner_path.read_bytes()
    for _ in range(2):
        result = subprocess.run([sys.executable, "-c", script, json.dumps(urls)], cwd=account.BASE_DIR,
            env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=40)
        assert result.returncode == 0, result.stderr
        restored = json.loads(result.stdout.strip().splitlines()[-1])
        assert restored == {"matrix": [[200] * 7, [404] * 7, [401] * 7],
                            "status": "partial", "calls": 5, "references": 1}
        assert owner_path.read_bytes() == original_owner


def test_real_loopback_http_report_prefix_and_auth(completed):
    import requests
    from werkzeug.serving import make_server
    server = make_server("127.0.0.1", 0, account.app)
    thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
    try:
        url = f"http://127.0.0.1:{server.server_port}/5000/api/science/tasks/{TASK}/report"
        assert requests.get(url, timeout=3).status_code == 401
        assert requests.get(url, headers=headers("owner-b"), timeout=3).status_code == 404
        response = requests.get(url, headers=headers(), timeout=3)
        assert response.status_code == 200
        assert response.json()["execution"]["model_calls"] == 5
        assert "no-store" in response.headers["Cache-Control"]
        assert response.headers["X-Content-Type-Options"] == "nosniff"
        assert response.headers.get("X-Request-ID")
        assert "Content-Security-Policy" in response.headers
    finally:
        server.shutdown(); thread.join(timeout=5); server.server_close()


def _slow_command(task_id, query_file, **kwargs):
    # Real child running indefinitely; no models, arXiv or DB account writes.
    directory = adapter.run_directory(task_id)
    script = ("import sys,time;from pathlib import Path;"
              "from multi_agent_workflow import WorkflowStore;"
              "s=WorkflowStore(Path(sys.argv[1])/'workflow.sqlite3');"
              "s.create_run(sys.argv[2],'offline');"
              "s.transition(sys.argv[2],'planned');s.transition(sys.argv[2],'retrieving');"
              "time.sleep(60)")
    return [sys.executable, "-c", script, str(directory), task_id]


def test_real_web_worker_timeout_stops_child_and_store(isolated, monkeypatch):
    seed()
    monkeypatch.setattr(adapter, "command", _slow_command)
    started = time.monotonic()
    web._run_multi_agent_rag_task(TASK, "slow", budget=2, time_policy="hard-deadline/v1")
    assert time.monotonic() - started < 10
    assert web.TASKS[TASK]["status"] == "timed_out"
    assert adapter.progress(TASK)["workflow_status"] == "timed_out"
    assert web.TASKS[TASK]["execution"]["process_cleanup"]["parent_stopped"] is True
    assert not web._RETRIEVAL_PROCESSES


def test_soft_web_estimate_does_not_discard_completed_report(isolated):
    seed()
    web._run_multi_agent_rag_task(TASK, "mock question", mode="mock", budget=1)
    assert web.TASKS[TASK]["status"] == "partial"
    assert web.TASKS[TASK]["execution"]["time_budget_is_estimate"] is True
    assert web.TASKS[TASK]["report_available"] is True
    assert adapter.progress(TASK)["time_policy"] == "research-start-300-complete-inflight/v1"


def test_budget_covers_web_report_publication_after_cli_exit(isolated, monkeypatch):
    seed()
    original = adapter.report
    called = []
    def slow_report(task_id):
        data = original(task_id)
        called.append(data["status"])
        # Leave enough time for Windows interpreter startup. The timeout must
        # occur during publication, not accidentally before the CLI completes.
        time.sleep(15.5)
        return data
    monkeypatch.setattr(adapter, "report", slow_report)
    web._run_multi_agent_rag_task(TASK, "mock question", mode="mock", budget=15, time_policy="hard-deadline/v1")
    assert called == ["partial"]
    assert web.TASKS[TASK]["status"] == "timed_out"
    assert not web.TASKS[TASK].get("report_available")
    assert adapter.progress(TASK)["workflow_status"] == "timed_out"


def test_real_web_cancel_stops_registered_child(isolated, monkeypatch):
    seed()
    monkeypatch.setattr(adapter, "command", _slow_command)
    thread = threading.Thread(target=web._run_multi_agent_rag_task, args=(TASK, "slow"), daemon=True)
    thread.start()
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        try:
            if adapter.progress(TASK):
                break
        except Exception:
            pass
        time.sleep(0.05)
    process = web._RETRIEVAL_PROCESSES[TASK]
    web._cancel_task(TASK)
    thread.join(timeout=10)
    assert not thread.is_alive()
    assert process.poll() is not None
    assert web.TASKS[TASK]["status"] == "cancelled"
    assert adapter.progress(TASK)["workflow_status"] == "cancelled"
    assert web.TASKS[TASK]["execution"]["process_cleanup"]["parent_stopped"] is True


def test_viewer_js_and_css_are_actually_served(isolated):
    client = account.app.test_client()
    assert client.get("/chatAi/multi_agent_rag.js").status_code == 200
    assert client.get("/chatAi/multi_agent_rag.css").status_code == 200
    source = (Path(__file__).resolve().parents[1] / "chatAi/multi_agent_rag.js").read_text(encoding="utf-8")
    assert "innerHTML" not in source
    assert "createTreeWalker" in source and "sameIdentity" in source
    assert "URL.revokeObjectURL" in source
    assert "token=" not in source


def test_exports_are_escaped_and_offline_links_have_no_credentials():
    data = {"status": "partial", "direct_answer": "<script>bad</script>[1]", "limitation": "limits", "references": []}
    content, _ = adapter.exported_report(data, "html")
    text = content.decode()
    assert "<script>" not in text and "&lt;script&gt;" in text
    assert 'href="#evidence-1"' not in text and '引用未发布' in text
    with pytest.raises(ValueError):
        adapter.exported_report(data, "zip")


@pytest.mark.parametrize("name", ["../manifest.json", "workflow.sqlite3", "artifacts/internal.json", "pdf\\x\\source.pdf", "source-1.html", "pages/evidence-0.png"])
def test_report_asset_allowlist_rejects_internal_files(isolated, name):
    with pytest.raises(FileNotFoundError):
        adapter.asset(TASK, name)
