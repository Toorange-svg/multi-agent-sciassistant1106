"""Question provenance prevents invented user beliefs, not scientific judgment."""
from copy import deepcopy

import pytest

from multi_agent_quality import (PREMISE_ORIGIN_POLICY, answer_requirements,
    scope_plan_to_question, answer_focus_brief, checked_premise_assessments)
from multi_agent_live import normalize_live_result, ROLE_PROMPTS
from test_multi_agent_question_premises import plan, review


QUESTION = "ViT 对 AI 生成图片检测有什么帮助？"


def grounded(origin="open_question", kind="task_relation"):
    value = plan(kind, QUESTION)
    value["groups"][0]["metrics"] = ["role", "relation"]
    value["premise_checks"][0].update(origin=origin, question_quote=QUESTION)
    return value


@pytest.mark.parametrize("origin,kind", [("open_question", "task_relation"),
    ("user_statement", "factual_assumption"), ("hypothetical", "hypothetical"),
    ("constraint", "conflicting_constraints")])
def test_exact_current_question_anchor_is_preserved_not_a_semantic_approval(origin, kind):
    value = grounded(origin, kind)
    before = deepcopy(value)
    scoped, report = scope_plan_to_question(value, answer_requirements(QUESTION))
    assert scoped["premise_checks"] == value["premise_checks"]
    assert scoped["premise_origin_policy"] == PREMISE_ORIGIN_POLICY
    assert not report["evidence_auto_approval"] and not report["premise_changes"]
    assert value == before


@pytest.mark.parametrize("field,bad", [("origin", None), ("origin", []), ("origin", "model_belief"),
    ("question_quote", None), ("question_quote", []), ("question_quote", ""),
    ("question_quote", "ViT直接训练成检测器"), ("question_quote", QUESTION.lower()),
    ("question_quote", "x" * 401)])
def test_unanchored_optional_check_is_quarantined_without_losing_groups(field, bad):
    value = grounded(); value["premise_checks"][0][field] = bad
    scoped, report = scope_plan_to_question(value, answer_requirements(QUESTION))
    assert scoped["premise_checks"] == [] and scoped["groups"] == value["groups"]
    assert report["premise_changes"][0]["reason_code"] == "PREMISE_QUESTION_ORIGIN_UNGROUNDED"


@pytest.mark.parametrize("kind", ["hypothetical", "conflicting_constraints"])
def test_special_question_kind_cannot_be_relabelled_as_user_factual_assertion(kind):
    scoped, report = scope_plan_to_question(grounded("user_statement", kind), answer_requirements(QUESTION))
    assert not scoped["premise_checks"]
    assert report["premise_changes"][0]["reason_code"] == "PREMISE_ORIGIN_KIND_CONFLICT"


@pytest.mark.parametrize("verdict", ["supported", "task_mismatch", "unverified", "needs_clarification"])
def test_open_question_can_be_answered_or_explained_without_accusing_user(verdict):
    checked = checked_premise_assessments(review(verdict), grounded())
    assert checked["assessments"][0]["origin"] == "open_question"
    assert not checked["semantic_auto_approval"]


def test_open_question_contradiction_is_isolated_but_approved_evidence_remains():
    raw = review("contradicted")
    checked = checked_premise_assessments(raw, grounded())
    assert not checked["assessments"]
    assert checked["validation_issues"][0]["reason_code"] == "PREMISE_OPEN_QUESTION_IS_NOT_AN_ASSERTION"
    assert raw["allowed_evidence_ids"] == ["e1"]


def test_asserted_false_fact_still_can_be_corrected_with_approved_evidence():
    assert checked_premise_assessments(review("contradicted"), grounded("user_statement"))["assessments"]


def test_legacy_scoping_and_no_optional_checks_remain_readable():
    legacy = {"question_kind": "definition_relation", "evaluation_requested": False}
    raw = plan()
    scoped, report = scope_plan_to_question(raw, legacy)
    assert scoped == raw and not report["premise_changes"]
    empty, _ = scope_plan_to_question({"groups": []}, answer_requirements(QUESTION))
    assert "premise_checks" not in empty


def test_live_normalizer_keeps_origin_and_quote_but_not_arbitrary_authority():
    from multi_agent_report_contracts import REPORT_PLAN_SCHEMA as PLAN_SCHEMA
    value = grounded(); value["schema_version"] = PLAN_SCHEMA
    value['groups'][0].update(kind='research', question_quote=QUESTION,
        evidence_needs=[{'entity':'ViT','question_quote':'ViT','aspect':'definition','source_title':''}])
    value["premise_checks"][0]["auto_approve"] = True
    value.update(user_requirements=[{'id':'u1','question_quote':QUESTION,'answer_kind':'relation',
        'research_group_ids':[value['groups'][0]['id']], 'report_obligation_ids':[]}])
    normalized = normalize_live_result("planner", {"output": value}, require_current=True,question=QUESTION)["output"]
    item = normalized["premise_checks"][0]
    assert item["origin"] == "open_question" and item["question_quote"] == QUESTION
    assert "auto_approve" not in item


def test_opening_contract_is_shared_with_review_and_writing_without_a_length_cap():
    brief = answer_focus_brief(answer_requirements(QUESTION), grounded())
    assert not brief["opening_policy"]["automatic_verdict"]
    assert "task fit first" in " ".join(brief["opening_policy"]["requirements"])
    assert "open_question asks for a relation" in ROLE_PROMPTS["reviewer"]
    assert "No fixed claim count or length target" in ROLE_PROMPTS["writer"]
    assert answer_requirements(QUESTION)["answer_focus"]["report_length_limit"] is None


def test_utility_request_does_not_require_a_loss_derivation_or_unasked_benchmark():
    value = grounded()
    value['groups'][0]['metrics'] = ['role', 'relation', 'formal_definition', 'mechanism', 'generalization', 'tradeoffs']
    scoped, report = scope_plan_to_question(value, answer_requirements(QUESTION))
    assert scoped['groups'][0]['metrics'] == ['role', 'relation']
    assert set(report['changes'][0]['unrequested_metrics']) == {'formal_definition', 'mechanism', 'generalization', 'tradeoffs'}


@pytest.mark.parametrize('question,metric', [
    ('ViT有什么帮助？请详细解释机制。', 'mechanism'),
    ('ViT有什么帮助？比较泛化性能与取舍。', 'generalization'),
    ('ViT有什么帮助？准确率提升多少？', 'accuracy')])
def test_explicit_depth_and_measurement_requests_are_not_suppressed(question, metric):
    value = grounded(); value['groups'][0]['metrics'] = ['role', metric]
    assert metric in scope_plan_to_question(value, answer_requirements(question))[0]['groups'][0]['metrics']
