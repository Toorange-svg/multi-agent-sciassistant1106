"""Printed counts and field-local scope are not semantic auto-approval."""
from copy import deepcopy
from decimal import Decimal

import pytest

from multi_agent_pipeline_v2 import (_reported_item_counts, quantity_feedback, check_draft,
    select_recovery_targets, validate_gap_plan)
from multi_agent_quality import (ABSENCE_SCOPE_POLICY, CITED_EVIDENCE_ABSENCE_SCOPE_POLICY,
    FIELD_QUANTITY_POLICY, PREVIOUS_FIELD_QUANTITY_POLICY, absence_scope_features,
    _bounded_absence_context, check_audit, publication_rejections)
from test_multi_agent_quantity_dimensions import fixture
from test_multi_agent_report_fields import draft, evidence
from test_multi_agent_absence_basis import audit, absence


@pytest.mark.parametrize('printed', ['2000 randomly chosen images', '2000 ran- domly chosen images',
    '2,000 randomly selected images', '2000 randomly sampled real images', '2000 test images'])
def test_exact_printed_random_image_count_is_not_missing(printed):
    assert (Decimal(2000), 'item_count') in _reported_item_counts(printed, modifiers=True)
    data, sources = fixture('平均2000张随机图像。')
    data['field_quantity_policy'] = FIELD_QUANTITY_POLICY
    sources['evidence'][0]['excerpt'] = printed
    assert not [r for r in check_draft(data, sources) if r['reason'] == 'UNSUPPORTED_NUMBER']


@pytest.mark.parametrize('printed', ['2000 pixels', '2000×2000 images', '12000 randomly chosen images',
    '20% randomly chosen images', 'page 2000', '2000% accuracy'])
def test_counts_do_not_turn_dimensions_percentages_or_suffixes_into_2000_items(printed):
    assert (Decimal(2000), 'item_count') not in _reported_item_counts(printed, modifiers=True)


def test_number_fix_preserves_legacy_policy_and_citation_boundaries():
    data, sources = fixture('平均2000张随机图像。')
    sources['evidence'][0]['excerpt'] = 'We average over 2000 ran- domly chosen images.'
    data['field_quantity_policy'] = PREVIOUS_FIELD_QUANTITY_POLICY
    assert any(r['reason'] == 'UNSUPPORTED_NUMBER' for r in check_draft(data, sources))
    data['field_quantity_policy'] = FIELD_QUANTITY_POLICY
    assert not check_draft(data, sources)
    # Other approved passages cannot silently become this claim's citations.
    sources['evidence'].append({**sources['evidence'][0], 'evidence_id': 'other', 'review_status': 'approved'})
    sources['evidence'][0]['excerpt'] = 'The experiment uses 20% of the data.'
    result = check_draft(data, sources)
    assert any(r['reason'] == 'UNSUPPORTED_NUMBER' for r in result)
    assert data['claims'][0]['evidence_ids'] == ['e1']


@pytest.mark.parametrize('field_text,assertion', [
    ('MLDocRAG片段给出评测设置，但未给出具体分数。', 'MLDocRAG片段给出评测设置，但未给出具体分数。'),
    ('MLDocRAG片段给出评测设置，但未给出具体分数。', '但未给出具体分数。'),
    ('所选片段覆盖了分类任务；但未覆盖局部定位实验。', '但未覆盖局部定位实验。'),
    ('所选片段覆盖了分类任务；但未覆盖局部定位实验。', '所选片段覆盖了分类任务；但未覆盖局部定位实验。'),
    ('RAID摘要描述分类输出；引言介绍局部取证。两段均未给出局部定位指标。', '两段均未给出局部定位指标。'),
    ('论文的片段描述实验设置，未提供置信区间。', '未提供置信区间。'),
    ('该结论仅针对本次所引片段，不代表全文或其他研究未做此类对照。', '该结论仅针对本次所引片段，不代表全文或其他研究未做此类对照。'),
])
@pytest.mark.parametrize('field', ['text', 'scope_note', 'qualification'])
def test_visible_local_antecedent_does_not_depend_on_auditor_cut(field_text, assertion, field):
    data, sources = draft(), evidence()
    data['absence_scope_policy'] = ABSENCE_SCOPE_POLICY
    data['claims'][0][field] = field_text
    raw = absence(audit(data), assertion, field=field)
    before = deepcopy((data, sources, raw))
    checked = check_audit(raw, data, sources)
    assert not checked['contract_errors'] and not checked['absence_issues']
    assert (data, sources, raw) == before


@pytest.mark.parametrize('text,assertion', [
    ('所选片段介绍分类任务。未提供任何定位实验。', '未提供任何定位实验。'),
    ('所选片段介绍分类任务；但论文未报告任何定位实验。', '但论文未报告任何定位实验。'),
    ('MLDocRAG片段介绍设置；另一研究没有开展验证。', '另一研究没有开展验证。'),
    ('所选片段介绍设置；2501.01880未给出费用。', '2501.01880未给出费用。'),
    ('所选片段介绍设置；LongRAG未提供实验。', 'LongRAG未提供实验。'),
    ('论文未提供任何实验。', '论文未提供任何实验。'),
    ('摘要介绍分类任务。两项研究均未提供定位指标。', '两项研究均未提供定位指标。'),
])
def test_whole_paper_or_missing_text_antecedent_stays_rejected(text, assertion):
    assert not _bounded_absence_context(assertion, text, **absence_scope_features(ABSENCE_SCOPE_POLICY))


def test_new_scope_does_not_retroactively_change_old_policy_or_override_model_verdict():
    data, sources = draft(), evidence()
    text = '所选片段介绍分类任务；但未给出局部定位实验。'
    data['claims'][0]['qualification'] = text
    raw = absence(audit(data), '但未给出局部定位实验。')
    data['absence_scope_policy'] = CITED_EVIDENCE_ABSENCE_SCOPE_POLICY
    assert check_audit(raw, data, sources)['absence_issues']
    data['absence_scope_policy'] = ABSENCE_SCOPE_POLICY
    assert not check_audit(raw, data, sources)['absence_issues']
    row = raw['claim_results'][0]
    row.update(decision='rejected', reason_code='UNSUPPORTED_EXTRAPOLATION', detail='Source actually contains the alleged missing experiment.')
    row['field_results']['qualification'].update(status='unsupported', detail='Contradicts the selected source.')
    raw.update(status='needs_revision', rejected_claim_ids=['c1'], issues=[
        {'claim_id': 'c1', 'reason_code': 'UNSUPPORTED_EXTRAPOLATION', 'detail': 'Contradicts source.'}])
    assert 'c1' in publication_rejections(check_audit(raw, data, sources), data)


def case_rows():
    plan = {'groups': [{'id': key} for key in ('g1', 'g2', 'g3')]}
    rows = [{'gap_id': f'{group}-{metric}', 'group_id': group, 'metric': metric,
             'status': 'partial', 'evidence_ids': ['e1']} for group, metric in
            [('g1', 'definition'), ('g1', 'role'), ('g2', 'relation'), ('g3', 'comparison')]]
    return plan, rows, {'allowed_evidence_ids': ['e1'], 'coverage': rows}


def test_target_selection_spreads_queries_across_topics_and_preserves_ticket():
    plan, rows, review = case_rows()
    before = deepcopy((plan, rows, review))
    selected = select_recovery_targets(rows, review, plan)
    assert [r['group_id'] for r in selected] == ['g1', 'g2']
    proposal = {'gaps': [{k: v for k, v in row.items() if k in {'gap_id', 'group_id', 'metric'}} |
                         {'query': 'new query ' + row['group_id']} for row in selected]}
    assert validate_gap_plan(proposal, selected, set())['valid']
    proposal['gaps'][1].update(group_id='g3', gap_id='g3-comparison', metric='comparison')
    assert not validate_gap_plan(proposal, selected, set())['valid']
    assert (plan, rows, review) == before


def test_zero_evidence_topics_precede_qualified_partial_topic():
    plan, rows, review = case_rows()
    for row in rows[2:]: row.update(status='missing', evidence_ids=[])
    assert [r['group_id'] for r in select_recovery_targets(rows, review, plan)] == ['g2', 'g3']


def test_single_topic_can_receive_two_targets_unknown_topics_get_none():
    plan, rows, review = case_rows()
    assert len(select_recovery_targets(rows[:2], review, plan)) == 2
    assert select_recovery_targets([{**rows[0], 'group_id': 'invented'}], review, plan) == []


def test_prompts_preserve_open_question_deliverables_and_statistics():
    from multi_agent_live import ROLE_PROMPT_SUFFIXES
    assert 'not separate empirical research topics' in ROLE_PROMPT_SUFFIXES['planner']
    assert 'no statistically significant advantage' in ROLE_PROMPT_SUFFIXES['writer']
    assert 'ground-truth masks' in ROLE_PROMPT_SUFFIXES['writer']
    assert 'equivalence' in ROLE_PROMPT_SUFFIXES['citation_auditor']
