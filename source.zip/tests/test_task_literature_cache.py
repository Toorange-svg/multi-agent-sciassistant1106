import hashlib
import json
from unittest.mock import MagicMock

import pytest
from flask import g, jsonify
import app as gateway
import multi_agent_web as rag


@pytest.fixture
def cache(tmp_path, monkeypatch):
    owner = ['7']
    def authenticate():
        if owner[0] is None:
            return jsonify(error='unauthorized'), 401
        g.current_user_id = owner[0]
    monkeypatch.setattr(gateway, '_authenticate_current_request', authenticate)
    monkeypatch.setattr(gateway, '_SCIENCE_TASK_OWNERS', {'a'*12:'7', 'b'*12:'8'})
    monkeypatch.setenv('SCIASSISTANT_MULTI_AGENT_WEB_RUN_ROOT', str(tmp_path/'runs'))
    monkeypatch.setenv('SCIASSISTANT_WORKSPACE', str(tmp_path/'workspace'))
    monkeypatch.setattr(gateway, 'UPLOAD_BASE_DIR', tmp_path/'my_files')
    for task, name in [('a'*12,'arxiv-2309-06180v1'), ('b'*12,'arxiv-2106-09685v2')]:
        folder=rag.run_directory(task)/'pdf'/name; folder.mkdir(parents=True)
        (folder/'source.pdf').write_bytes(b'%PDF-1.4\nprivate cached original')
        (folder/'metadata.json').write_text(json.dumps({'document_id':name,'title':'Original '+name}),encoding='utf8')
    return gateway.app.test_client(), owner, tmp_path


def test_owned_tasks_only_including_downloaded_unpublished_original(cache):
    client,owner,path=cache
    result=client.get('/api/literature/papers')
    assert result.status_code==200
    rows=result.json['papers'];assert len(rows)==1
    assert rows[0]['task_id']=='a'*12 and rows[0]['cache_kind']=='task'
    assert rows[0]['title'].startswith('Original ') and rows[0]['downloaded_only'] is True
    assert rows[0]['can_delete'] is False
    assert 'path' not in json.dumps(rows).lower()
    owner[0]='8'
    assert client.get('/api/literature/papers').json['papers'][0]['task_id']=='b'*12


def test_cache_download_owner_cross_user_anonymous(cache):
    client,owner,path=cache
    url='/api/literature/tasks/'+ 'a'*12 +'/papers/arxiv-2309-06180v1/pdf'
    result=client.get(url)
    assert result.status_code==200 and result.data.startswith(b'%PDF-')
    assert result.headers['Cache-Control']=='no-store'
    owner[0]='8'; assert client.get(url).status_code==404
    owner[0]=None;assert client.get(url).status_code==401


def test_save_uses_owned_upload_and_preserves_original(cache,monkeypatch):
    client,owner,path=cache
    source=rag.cached_paper_path('a'*12,'arxiv-2309-06180v1')
    before=hashlib.sha256(source.read_bytes()).hexdigest()
    connection=MagicMock();monkeypatch.setattr(gateway,'get_db_connection',lambda:connection)
    url='/api/literature/tasks/'+ 'a'*12 +'/papers/arxiv-2309-06180v1/save'
    result=client.post(url,json={'user_id':'8','file_path':'forged'})
    assert result.status_code==200 and len(result.json['files'])==1
    saved=list((path/'my_files'/'7').glob('*.pdf'))
    assert len(saved)==1 and saved[0].read_bytes()==source.read_bytes()
    assert connection.cursor.return_value.__enter__.return_value.execute.call_args.args[1][1]=='7'
    assert hashlib.sha256(source.read_bytes()).hexdigest()==before
    owner[0]='8';assert client.post(url).status_code==404
    owner[0]=None;assert client.post(url).status_code==401


def test_no_candidates_invalid_pdf_or_unowned_shared_cache(cache):
    client,owner,path=cache
    for name in ['arxiv-candidate','arxiv-bad']:
        folder=rag.run_directory('a'*12)/'pdf'/name;folder.mkdir()
        if name.endswith('bad'):(folder/'source.pdf').write_bytes(b'not pdf')
    shared=path/'workspace'/'literature'/'unknown';shared.mkdir(parents=True)
    (shared/'source.pdf').write_bytes(b'%PDF-1.4')
    rows=client.get('/api/literature/papers').json['papers']
    assert [row['document_id'] for row in rows]==['arxiv-2309-06180v1']
    assert client.get('/api/literature/tasks/'+'a'*12+'/papers/arxiv-bad/pdf').status_code==404
    assert client.get('/api/literature/tasks/'+'a'*12+'/papers/not-safe/pdf').status_code==404


def test_cache_page_and_invalid_offset(cache,monkeypatch):
    client,owner,path=cache
    monkeypatch.setattr(gateway,'_SCIENCE_TASK_OWNERS',{f'{n:012x}':'7' for n in range(41)})
    first=client.get('/api/literature/papers').json
    assert first['next_offset']==40 and first['scanned_tasks']==40
    last=client.get('/api/literature/papers?offset=40').json
    assert last['next_offset'] is None and last['scanned_tasks']==1
    assert client.get('/api/literature/papers?offset=bad').status_code==400
