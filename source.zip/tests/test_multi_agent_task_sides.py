"""Task-side labels are checked provenance, never automatic scientific approval."""
from copy import deepcopy

import pytest

from multi_agent_pipeline_v2 import check_review, recover_review_subset, ReviewContractError, review_targets
from multi_agent_quality import task_side_inventory, source_boundary_brief, answer_focus_brief, answer_requirements
from multi_agent_live import ROLE_PROMPTS


def packet(roles=None):
    decision = {'evidence_id': 'e1', 'decision': 'approved', 'reason_code': 'SUPPORTED',
        'detail': 'Defines the target task; does not demonstrate the requested application.',
        'group_ids': ['g1'], 'task_relevance': 'direct_task_evidence', 'source_domain': ''}
    if roles is not None:
        decision['task_side_roles'] = roles
    review = {'schema_version': 'sciassistant.evidence-review/v5', 'coverage_status': 'partial',
        'allowed_evidence_ids': ['e1'], 'coverage': [], 'conflicts': [], 'decisions': [decision]}
    evidence = {'evidence': [{'evidence_id': 'e1', 'group_id': 'g1', 'excerpt': 'Target task outputs a class.',
        'review_status': 'approved', 'locator': {'page': 1}}]}
    return review, evidence


@pytest.mark.parametrize('roles', [['method_task'], ['target_task'], ['direct_application'],
    ['adjacent_background'], ['method_task', 'target_task']])
def test_valid_roles_survive_contract_and_subset_recovery(roles):
    review, evidence = packet(roles)
    checked = check_review(review, evidence, {'g1'})
    assert checked['decisions'][0]['task_side_roles'] == roles
    recovered, _ = recover_review_subset(review, evidence, {'g1'})
    assert recovered['decisions'][0]['task_side_roles'] == roles


@pytest.mark.parametrize('roles', [[], 'target_task', None, ['invented'], ['target_task', 'target_task'],
    [True], [{'role': 'target_task'}], ['method_task'] * 5])
def test_invalid_labels_cannot_be_silently_kept(roles):
    review, evidence = packet()
    review['decisions'][0]['task_side_roles'] = roles
    with pytest.raises(ReviewContractError, match='REVIEW_TASK_SIDE_ROLES_INVALID'):
        check_review(review, evidence, {'g1'})


def test_old_decisions_remain_unclassified_not_inferred_from_title():
    review, evidence = packet()
    before = deepcopy((review, evidence))
    check_review(review, evidence, {'g1'})
    inventory = task_side_inventory(evidence)
    assert inventory['unclassified_evidence_ids'] == ['e1']
    assert not any(inventory['roles'].values())
    assert not inventory['automatic_verdict']
    assert (review, evidence) == before


def test_inventory_filters_rejected_evidence_and_never_upgrades_role_labels():
    _, evidence = packet()
    evidence['evidence'][0]['task_side_roles'] = ['target_task']
    evidence['evidence'].append({'evidence_id': 'bad', 'review_status': 'rejected',
        'task_side_roles': ['direct_application']})
    brief = source_boundary_brief(evidence)['task_side_inventory']
    assert brief['roles']['target_task'] == ['e1']
    assert brief['roles']['direct_application'] == []
    assert not brief['automatic_verdict']


def test_cross_task_guidance_demands_both_sides_without_extra_calls():
    brief = answer_focus_brief(answer_requirements('方法A对任务B有什么帮助？'), {'groups': []})
    assert any('BOTH sides' in row for row in brief['opening_policy']['requirements'])
    assert not brief['evidence_auto_approval']
    assert 'TARGET TASK alone' in ROLE_PROMPTS['retriever']
    assert 'both tasks' in ROLE_PROMPTS['reviewer']
    assert "question is not evidence" in ROLE_PROMPTS['writer']
    assert "question is not a source" in ROLE_PROMPTS['citation_auditor']


@pytest.mark.parametrize('enabled', [True, False])
def test_review_checklist_distinguishes_target_definition_from_application(enabled):
    _, evidence = packet()
    before = deepcopy(evidence)
    plan = {'groups': [{'id': 'g1', 'metrics': ['relation']}]}
    if enabled:
        plan['task_fit_review_policy'] = 'both-task-sides-before-application/v1'
    targets = review_targets(evidence, plan)['task_fit_checklist']
    assert targets['enabled'] == enabled
    assert targets['current_evidence_ids'] == ['e1']
    assert {q['role'] for q in targets['questions']} == {'method_task', 'target_task', 'direct_application'}
    assert 'need NOT mention' in targets['questions'][1]['question']
    assert not targets['automatic_approval']
    assert evidence == before
