"""Memory components and original-method wording; no semantic auto-approval."""
from copy import deepcopy

import pytest

from multi_agent_quality import (MEMORY_COMPONENT_POLICY, check_memory_component_scope,
    source_boundary_brief, check_claim_revision, check_metric_direction)
from multi_agent_pipeline_v2 import check_draft, prepare_primary_source_plan
from multi_agent_sources import AutoSourceExecutor
from test_multi_agent_report_fields import draft, evidence
from test_multi_agent_remaining_quality import plan, LORA, QLORA
from test_multi_agent_local_pdf import pdf
from test_multi_agent_sources import action

SOURCE = ('Double Quantization is quantizing the quantization constants for additional memory savings. '
          'The quantization constants add 32/64 = 0.5 bits per parameter. '
          'We reduce this overhead to 0.127 bits per parameter, a reduction of 0.373 bits per parameter.')
BAD = '双重量化把每参数显存占用从0.5 bits降到0.127 bits。'


def inputs(text=BAD):
    data, sources = draft(), evidence()
    data['memory_component_policy'] = MEMORY_COMPONENT_POLICY
    claim = data['claims'][0]
    claim.update(text=text, scope_note='', qualification='作者报告这些数值。', claim_type='quantitative')
    sources['evidence'][0]['excerpt'] = SOURCE
    return data, sources


@pytest.mark.parametrize('field', ['text', 'scope_note', 'qualification'])
def test_source_backed_component_confusion_is_exact_field_not_rewrite(field):
    data, sources = inputs('双重量化减少量化常数存储开销。')
    data['claims'][0][field] = BAD
    before = deepcopy((data, sources))
    issues = check_memory_component_scope(data, sources)
    assert len(issues) == 1 and issues[0]['field'] == field
    assert issues[0]['reason'] == 'METRIC_COMPONENT_CONFUSION' and not issues[0]['automatic_rewrite']
    witness = issues[0]['source_witnesses'][0]
    assert witness['quote'] == SOURCE[witness['start']:witness['end']]
    assert (data, sources) == before


@pytest.mark.parametrize('text', [
    '量化常数的每参数显存占用从0.5 bits降到0.127 bits。',
    '每参数额外存储开销从0.5 bits降到0.127 bits。',
    '不能把每参数显存占用从0.5 bits降到0.127 bits当作总存储。',
    '作者把量化尺度的每参数存储占用从0.5 bits降至0.127 bits。',
    '每参数存储占用从4.5 bits降到4.127 bits是独立计算，不能标作直接打印。',
    'DQ saves 0.373 bits per parameter in quantization-constant overhead.',
])
def test_correct_objects_and_refutations_not_rejected(text):
    data, sources = inputs(text)
    assert not check_memory_component_scope(data, sources)


@pytest.mark.parametrize('fault', ['uncited', 'unapproved', 'different_source'])
def test_numbers_without_cited_component_description_are_not_a_guard_verdict(fault):
    data, sources = inputs()
    if fault == 'uncited': data['claims'][0]['evidence_ids'] = ['another']
    if fault == 'unapproved': sources['evidence'][0]['review_status'] = 'pending'
    if fault == 'different_source': sources['evidence'][0]['excerpt'] = 'The total measurement is 0.5 before and 0.127 after.'
    assert not check_memory_component_scope(data, sources)


def test_policy_gated_and_disclaimer_does_not_fix_main_measurement():
    data, sources = inputs()
    failures = check_draft(data, sources)
    target = [x for x in failures if x['reason'] == 'METRIC_COMPONENT_CONFUSION']
    assert len(target) == 1
    old = deepcopy(data); old.pop('memory_component_policy')
    assert not any(x['reason'] == 'METRIC_COMPONENT_CONFUSION' for x in check_draft(old, sources))
    after = deepcopy(data); after['claims'][0]['scope_note'] = '这里是量化常数开销。'
    feedback = {'code_issues': target}
    assert check_claim_revision(after, data, feedback)['code_issues']
    after['claims'][0]['text'] = '量化常数的每参数显存占用从0.5 bits降到0.127 bits。'
    assert not check_memory_component_scope(after, sources)
    assert not check_claim_revision(after, data, feedback)['code_issues']


def test_source_context_is_literal_review_question_not_classification():
    _, sources = inputs()
    brief = source_boundary_brief(sources)
    cues = [c for c in brief['cues'] if c['category'] == 'quantization_overhead_basis']
    assert cues and cues[0]['quote'] == SOURCE[cues[0]['start']:cues[0]['end']]
    assert any(r['aspect'] == 'quantization_overhead' for r in brief['reported_condition_records'])


@pytest.mark.parametrize('question', ['对比本文QLoRA与原始 LoRA的显存。', '比较原版LoRA与QLoRA。',
    'Compare QLoRA with original LoRA memory usage'])
def test_original_prefix_wording_compiles_only_matching_question_title(question):
    original = plan(); before = deepcopy(original)
    result, report = prepare_primary_source_plan(original, question, 'uploaded_pdf_and_arxiv')
    assert original == before and len(report['targets']) == 1
    assert report['targets'][0]['source_title_clue'] == LORA
    assert result['groups'][0]['queries'] == ['QLoRA mechanism', f'ti:"{LORA}"']


@pytest.mark.parametrize('scope,question', [('uploaded_pdf', '对比原始LoRA与本文'),
    ('uploaded_pdf_and_arxiv', '不需要检索原始LoRA，只看本文'),
    ('uploaded_pdf_and_arxiv', '解释原始PDF的内容'),
    ('uploaded_pdf_and_arxiv', '仅解释本文QLoRA，不需要原始论文'),
    ('uploaded_pdf_and_arxiv', 'Compare this with original SecretMethod'),
])
def test_aliases_do_not_create_unrequested_unplanned_or_private_queries(scope, question):
    result, report = prepare_primary_source_plan(plan(), question, scope)
    assert not report['targets'] and result['groups'][0]['queries'] == plan()['groups'][0]['queries']


def test_two_local_actions_still_execute_original_slot_without_new_quota(pdf, tmp_path):
    result, _ = prepare_primary_source_plan(plan(), '对比本文QLoRA与原始 LoRA', 'uploaded_pdf_and_arxiv')
    tool = AutoSourceExecutor(tmp_path / 'run', pdf, allow_public=True, rag_mode='lexical')
    tool.configure_plan(result)
    local, public = tool._requests([action(query='QLoRA mechanism'), {**action(query='LoRA memory'), 'request_id': 'r2'}], False, {'g1'})
    assert len(local) == len(public) == 1
    assert public[0]['arguments']['query'] == f'ti:"{LORA}"'
    assert sum(map(len, (local, public))) == 2


@pytest.mark.parametrize('field', ['text', 'scope_note', 'qualification'])
def test_performance_quote_is_not_maximum_loss(field):
    data, sources = inputs('作者报告打印值。')
    sources['evidence'][0]['excerpt'] = 'The performance peaks at r = 16 for validation loss and r = 4 for BLEU.'
    data['claims'][0][field] = '验证损失在r=16达到最优（performance peaks at r=16 for validation loss）。'
    assert not check_metric_direction(data, sources)
    data['claims'][0][field] = '验证损失在r=16达到最优（performance peaks）、BLEU在r=4达到峰值。'
    assert not check_metric_direction(data, sources)
    data['claims'][0][field] = '验证损失在r=16达到峰值、BLEU在r=4达到峰值。'
    assert check_metric_direction(data, sources)[0]['field'] == field
    data['claims'][0][field] = '验证损失（performance peaks）最高，不能混为性能最佳。'
    assert check_metric_direction(data, sources)[0]['field'] == field
