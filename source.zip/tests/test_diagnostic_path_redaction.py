"""Regressions for client-visible storage paths and MCP diagnostic redaction."""

import asyncio
import json
from pathlib import Path
import sys
from types import SimpleNamespace
from unittest import mock

from starlette.requests import Request

import app as account_app

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "deepdiver_v2"))
from src.tools import mcp_server_standard as mcp_server


def _auth_headers(user_id="path-owner"):
    token = account_app.generate_token(user_id, f"user-{user_id}")
    return {"Authorization": f"Bearer {token}"}


def test_report_both_returns_names_and_authenticated_urls_not_server_paths(tmp_path):
    report_dir = tmp_path / "private-account-storage" / "session-a"
    pdf = report_dir / "final_report.pdf"
    markdown = report_dir / "final_report.md"
    with (
        mock.patch.object(account_app, "_current_auth_version", return_value=0),
        mock.patch.object(account_app, "_require_legacy_report_owner"),
        mock.patch.object(account_app, "_ensure_report_export", side_effect=[pdf, markdown]),
    ):
        response = account_app.app.test_client().get(
            "/api/export_report?session_id=session-a&format=both",
            headers=_auth_headers(),
        )

    assert response.status_code == 200
    payload = response.get_json()
    assert payload["files"] == {
        "pdf": "final_report.pdf",
        "markdown": "final_report.md",
    }
    assert payload["download_urls"] == {
        "pdf": "/api/export_report?session_id=session-a&format=pdf",
        "markdown": "/api/export_report?session_id=session-a&format=md",
    }
    assert str(tmp_path) not in response.get_data(as_text=True)


def test_parse_response_uses_download_url_without_local_storage_path(tmp_path, caplog):
    stored = tmp_path / "private-storage-canary" / "notes.txt"
    stored.parent.mkdir()
    stored.write_text("safe parsed content", encoding="utf-8")
    with (
        mock.patch.object(account_app, "_current_auth_version", return_value=0),
        mock.patch.object(account_app, "_file_owned_by_user", return_value=True),
        mock.patch.object(account_app, "_find_uploaded_path_by_id", return_value=stored),
    ):
        response = account_app.app.test_client().post(
            "/api/user_files/download_and_parse",
            json={"file_ids": ["file-a"], "full_content": True},
            headers=_auth_headers(),
        )

    assert response.status_code == 200
    file_result = response.get_json()["files"][0]
    assert file_result["download_url"] == "/api/files/download/file-a"
    assert "local_path" not in file_result
    assert "source_path" not in file_result
    assert file_result["content"] == "safe parsed content"
    assert str(tmp_path) not in response.get_data(as_text=True)
    assert str(tmp_path) not in caplog.text


def test_tracker_recursively_redacts_long_credentials_paths_and_error_details(tmp_path, monkeypatch):
    monkeypatch.setattr(mcp_server, "config", mcp_server.ServerConfig())
    tracker = mcp_server.ToolCallTracker(tmp_path / "private-workspace", "session-safe")
    long_token = "token-canary-" + "x" * 2500
    call_id = tracker.log_tool_call(
        "diagnostic-tool",
        {
            "nested": [{"api_key": long_token}],
            "Authorization": f"Bearer {long_token}",
            "workspace_path": r"C:\\Users\\private\\workspace",
        },
        {"result": {"access_token": long_token}},
        True,
        12.5,
        error_details=r"failed at C:\\Users\\private\\secret.txt token=token-canary",
        agent_info={"credentials": {"refresh_token": long_token}},
    )

    assert call_id
    log_payload = json.loads(tracker.current_log_file.read_text(encoding="utf-8").splitlines()[-1])
    serialized = json.dumps(log_payload)
    assert "token-canary" not in serialized
    assert "Users" not in serialized
    assert log_payload["input_args"]["nested"][0]["api_key"] == "[REDACTED]"
    assert log_payload["input_args"]["workspace_path"] == "[REDACTED_PATH]"
    assert log_payload["agent_info"]["credentials"] == "[REDACTED]"
    assert "workspace_path" not in json.loads(tracker.summary_file.read_text(encoding="utf-8"))


def _tracking_request(session_id="session-safe"):
    return Request({
        "type": "http",
        "http_version": "1.1",
        "method": "GET",
        "scheme": "http",
        "path": "/tracking",
        "raw_path": b"/tracking",
        "query_string": f"session_id={session_id}".encode("ascii"),
        "headers": [],
        "client": ("127.0.0.1", 12345),
        "server": ("127.0.0.1", 6274),
    })


def test_tracking_response_allowlists_summary_and_returns_only_log_filename(tmp_path, monkeypatch):
    monkeypatch.setattr(mcp_server, "config", mcp_server.ServerConfig())
    tracker = mcp_server.ToolCallTracker(tmp_path / "private-workspace", "session-safe")
    tracker.summary_file.write_text(json.dumps({
        "session_id": "session-safe",
        "total_tool_calls": 3,
        "tool_usage_stats": {"search": 3},
        "workspace_path": str(tmp_path / "private-workspace"),
        "api_key": "summary-secret-canary",
    }), encoding="utf-8")

    class Manager:
        async def get_session(self, _session_id):
            return SimpleNamespace(get_tool_tracker=lambda: tracker)

    monkeypatch.setattr(mcp_server, "session_manager", Manager())
    response = asyncio.run(mcp_server.handle_tracking_info(_tracking_request()))
    payload = json.loads(response.body)
    serialized = response.body.decode("utf-8")
    assert response.status_code == 200
    assert payload["log_file"].startswith("tool_calls_")
    assert payload["summary"]["total_tool_calls"] == 3
    assert "workspace_path" not in serialized
    assert "logs_directory" not in serialized
    assert "summary-secret-canary" not in serialized
    assert str(tmp_path) not in serialized


def test_tracking_failure_does_not_echo_exception_details(monkeypatch):
    class FailingManager:
        async def get_session(self, _session_id):
            raise RuntimeError(r"secret-canary C:\\Users\\private\\workspace")

    monkeypatch.setattr(mcp_server, "session_manager", FailingManager())
    response = asyncio.run(mcp_server.handle_tracking_info(_tracking_request()))
    assert response.status_code == 500
    assert json.loads(response.body) == {"error": "TRACKING_UNAVAILABLE"}
    assert "secret-canary" not in response.body.decode("utf-8")
