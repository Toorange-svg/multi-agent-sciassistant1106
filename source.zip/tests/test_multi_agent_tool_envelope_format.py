"""Correct source-safe shape errors, never repair a forbidden tool into permission."""
import json
import time

import pytest

from multi_agent_agents import AgentWorker, ArtifactDirectory, AgentContractError, make_agent_input
from multi_agent_live import LiveModelClient, effective_role_prompt
from test_multi_agent_live import Response, config


def output(extra=None, action="request_document_search"):
    return {"status": "completed", "output": {"schema_version": "sciassistant.search-actions/v1", "action_count": 1},
            "tool_requests": [{"request_id": "r1", "action": action,
                "arguments": {"group_id": "g1", "query": "experimental settings"}, **(extra or {})}]}


@pytest.mark.parametrize("extra", [{"source": "uploaded_pdf"}, {"group_id": "g1"}, {"priority": 1}])
def test_authorized_tool_shape_gets_safe_model_format_diagnostic(monkeypatch, extra):
    monkeypatch.setenv("MODEL_REQUEST_URL", "https://example.test/model")
    response = Response(output(extra))
    client = LiveModelClient(config(), post=lambda *_a, **_k: response)
    value = client.call("retriever", {"inputs": [], "deadline_at": time.time()+30,
        "allowed_actions": ["request_document_search"]})
    assert value["error_code"] == "MODEL_SCHEMA_REJECTED"
    assert value["output"]["format_reason"] == "TOOL_REQUEST_FIELDS_INVALID"
    assert "tool_requests" not in value and "experimental settings" not in json.dumps(value)
    assert response.closed


def test_forbidden_public_action_even_with_bad_shape_not_format_retry(monkeypatch, tmp_path):
    monkeypatch.setenv("MODEL_REQUEST_URL", "https://example.test/model")
    client = LiveModelClient(config(), post=lambda *_a, **_k: Response(output({"source": "arxiv"}, "request_arxiv_search")))
    worker = AgentWorker("retriever", lambda packet: client.call("retriever", packet), ["request_document_search"])
    packet = make_agent_input(run_id="scope", role="retriever", goal="Search only PDF", input_artifact_ids=[],
        remaining_model_calls=8, deadline_at=time.time()+30)
    with pytest.raises(AgentContractError, match="outside this worker's source scope"):
        worker.run(packet, ArtifactDirectory(tmp_path))


def test_local_prompt_complete_envelope_and_exact_fields():
    prompt = effective_role_prompt("retriever", local_source=True)
    assert '"action": "request_document_search"' in prompt
    assert "EXACTLY request_id, action, arguments" in prompt


@pytest.mark.parametrize("correct_second", [True, False])
def test_actual_adapter_shape_retry_bounded_and_never_executes_rejected_request(monkeypatch, tmp_path, correct_second):
    from test_multi_agent_pipeline_v2 import agents, pipeline
    monkeypatch.setenv("MODEL_REQUEST_URL", "https://example.test/model")
    configured, calls = agents()
    posts = []
    def post(*_a, **_k):
        posts.append(1)
        result = output(None if correct_second and len(posts) == 2 else {"priority": 1}, "request_arxiv_search")
        result["tool_requests"][0]["arguments"]["query"] = "A"
        return Response(result)
    client = LiveModelClient(config(), post=post)
    configured.retriever.handler = lambda packet: client.call("retriever", packet)
    searches = []
    def search(*_):
        searches.append(1)
        return {"status": "ok", "papers": [{"paper_id": "1", "title": "Paper", "abstract": "Evidence"}]}
    flow, _ = pipeline(tmp_path, configured, search=search)
    result = flow.run("shape", "owner", "A")
    assert len(posts) == 2
    assert len(searches) == (1 if correct_second else 0)
    assert result["run"]["status"] == ("completed" if correct_second else "failed")
    assert result["run"]["model_calls_used"] == (6 if correct_second else 3)
    if not correct_second:
        assert not calls.count("writer") and not calls.count("citation_auditor")
