"""Attachment menu buttons must never be mistaken for the send control."""
from pathlib import Path
import re


def test_send_control_is_selected_by_explicit_type_not_first_button():
    source = (Path(__file__).resolve().parents[1] / 'chatAi/ai_chat.html').read_text(encoding='utf8')
    assert 'const submitButton = chatForm.querySelector(\'button[type="submit"]\');' in source
    assert "const submitButton = chatForm.querySelector('button');" not in source
    assert re.search(r'<button\s+type="submit"\s+id="chat-send-btn"', source)
    assert 'id="context-file-label"' in source
