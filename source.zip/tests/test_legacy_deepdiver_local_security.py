"""The unauthenticated legacy 8000 service is a loopback-only dependency."""

import asyncio
from pathlib import Path

import pytest
from starlette.requests import Request

from deepdiver_v2.cli import a as legacy


ROOT = Path(__file__).resolve().parents[1]


def test_legacy_listener_defaults_to_ipv4_loopback_and_fails_closed():
    assert legacy._configured_legacy_listener("127.0.0.1", "8000") == ("127.0.0.1", 8000)
    assert legacy._configured_legacy_listener("127.0.0.2", "65535") == ("127.0.0.2", 65535)
    for host in ("0.0.0.0", "192.168.1.10", "::", "::1", "localhost", ""):
        with pytest.raises(RuntimeError):
            legacy._configured_legacy_listener(host, "8000")
    for port in ("0", "65536", "invalid", ""):
        with pytest.raises(RuntimeError):
            legacy._configured_legacy_listener("127.0.0.1", port)


def _request(peer: str, host: str = "127.0.0.1:8000") -> Request:
    return Request({
        "type": "http",
        "method": "GET",
        "path": "/api/history",
        "headers": [(b"host", host.encode("ascii"))],
        "client": (peer, 43210),
        "server": ("127.0.0.1", 8000),
        "scheme": "http",
        "query_string": b"",
    })


def test_remote_peer_and_dns_rebinding_host_are_rejected_before_route():
    calls = []

    async def downstream(_request):
        calls.append(1)
        return legacy.JSONResponse({"unexpected": True})

    remote = asyncio.run(legacy.local_legacy_boundary(_request("192.0.2.10"), downstream))
    rebound = asyncio.run(legacy.local_legacy_boundary(
        _request("127.0.0.1", "attacker.example:8000"), downstream))
    assert remote.status_code == rebound.status_code == 403
    assert calls == []


def test_local_response_has_security_headers_and_no_cors_wildcard():
    async def downstream(_request):
        return legacy.JSONResponse({"ok": True})

    response = asyncio.run(legacy.local_legacy_boundary(_request("127.0.0.1"), downstream))
    assert response.status_code == 200
    assert response.headers["Cache-Control"] == "no-store"
    assert response.headers["X-Content-Type-Options"] == "nosniff"
    assert response.headers["X-Frame-Options"] == "DENY"
    assert response.headers["Referrer-Policy"] == "no-referrer"
    assert response.headers["Cross-Origin-Resource-Policy"] == "same-origin"
    assert "Access-Control-Allow-Origin" not in response.headers
    source = (ROOT / "deepdiver_v2/cli/a.py").read_text(encoding="utf-8")
    assert "CORSMiddleware" not in source and 'allow_origins=["*"]' not in source


def test_gateway_drops_origin_and_account_authorization_before_legacy_proxy():
    source = (ROOT / "app.py").read_text(encoding="utf-8")
    proxy = source.split("def proxy_deepdiver", 1)[1].split("def proxy_model", 1)[0]
    assert 'LEGACY_SERVICE_NOT_USER_ISOLATED' in proxy and ', 410' in proxy
    assert '_proxy_request(' not in proxy  # no account/private traffic reaches legacy process


def test_invalid_bind_startup_uses_fixed_safe_error_without_traceback_source():
    source = (ROOT / "deepdiver_v2/cli/a.py").read_text(encoding="utf-8")
    main = source.split('if __name__ == "__main__":', 1)[1]
    assert 'print("Error: LOCAL_BIND_REQUIRED", file=sys.stderr)' in main
    assert "raise SystemExit(2) from None" in main
