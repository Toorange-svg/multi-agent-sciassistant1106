import unittest

from deepdiver_v2.src.query_router import (
    build_literature_query_plan,
    build_problem_spec,
    build_literature_queries,
    infer_literature_relation,
    score_literature_relevance,
)


class TransformerLimitationLiteratureTests(unittest.TestCase):
    QUERY = '我的问题根据arXiv上的论文分析transformer架构的局限性在于什么？'

    def test_query_ladder_is_limitation_specific(self):
        queries = build_literature_queries(self.QUERY)
        self.assertGreaterEqual(len(queries), 3)
        self.assertIn('transformer', queries[0].lower())
        self.assertIn('all:limitation', queries[0])
        self.assertIn('all:failure', queries[1])

    def test_limitation_papers_pass_gate(self):
        for paper in (
            {
                'paper_id': '2406.04089',
                'title': 'On Limitation of Transformer for Learning HMMs',
                'abstract': 'We study limitations of Transformer for learning hidden Markov models.',
            },
            {
                'paper_id': '2306.02896',
                'title': 'Representational Strengths and Limitations of Transformers',
                'abstract': 'We characterize the expressivity and limitations of transformers.',
            },
        ):
            result = score_literature_relevance(self.QUERY, paper)
            self.assertTrue(result['accepted'])
            self.assertTrue(result['limitation_topics'])

    def test_unrelated_transformer_paper_is_rejected(self):
        result = score_literature_relevance(
            self.QUERY,
            {
                'paper_id': '9999.00000',
                'title': 'Transformer for Medical Image Segmentation',
                'abstract': 'We propose a transformer model for image segmentation.',
            },
        )
        self.assertFalse(result['accepted'])

    def test_cnn_application_paper_is_not_an_architecture_limitation(self):
        query = '根据 arXiv 上的文章解释 CNN 的局限性'
        result = score_literature_relevance(
            query,
            {
                'paper_id': 'example',
                'title': 'PupilNet v2.0: Convolutional neural network for pupil detection',
                'abstract': 'Pupil detection is challenging under illumination changes. The CNN improves detection accuracy.',
            },
        )
        self.assertFalse(result['accepted'])

    def test_direct_cnn_limitation_is_accepted(self):
        query = '根据 arXiv 上的文章解释 CNN 的局限性'
        result = score_literature_relevance(
            query,
            {
                'paper_id': 'example',
                'title': 'CNN feature extraction under limited data',
                'abstract': 'Conventional convolutional neural networks with local receptive fields are inadequate for extracting global features.',
            },
        )
        self.assertTrue(result['accepted'])

    def test_relation_aware_plan_covers_multiple_question_forms(self):
        checks = (
            ('CNN 架构的优势是什么？', 'advantages', 'direct benefits'),
            ('比较 Transformer 和 RNN 的计算成本', 'comparison', 'direct comparison'),
            ('RAG 的工作原理是什么？', 'mechanism', 'architecture'),
            ('大语言模型的预训练和指令微调分别解决什么问题？', 'training', 'training objectives'),
        )
        for query, relation, first_dimension in checks:
            with self.subTest(query=query):
                plan = build_literature_query_plan(query)
                self.assertEqual(infer_literature_relation(query), relation)
                self.assertGreaterEqual(len(plan), 3)
                self.assertEqual(plan[0]['dimension'], first_dimension)

    def test_comparison_plan_keeps_both_architectures(self):
        plan = build_literature_query_plan('Transformer 和 RNN 比较')
        self.assertIn('all:"transformer"', plan[0]['query'])
        self.assertIn('all:"recurrent neural network"', plan[0]['query'])

    def test_query_plan_keeps_explicit_terms_without_topic_catalog(self):
        rlvr = build_literature_query_plan(
            'RLVR 可验证奖励模型在过程监督和过度思考上的差异'
        )
        self.assertIn('all:"rlvr"', rlvr[0]['query'])
        multimodal = build_literature_query_plan(
            '原生多模态模型的跨模态 token 对齐和共指消解难点'
        )
        self.assertNotIn('all:"多模态"', multimodal[0]['query'])
        graph = build_literature_query_plan(
            'GraphRAG 在多跳推理中的召回缺陷和知识图谱噪声'
        )
        self.assertIn('all:"graphrag"', graph[0]['query'])
        self.assertNotIn('all:"图谱增强"', graph[0]['query'])

    def test_problem_spec_keeps_multiple_aspects(self):
        spec = build_problem_spec('比较 Mamba 和 Transformer 的长序列优势，并分析推理成本与泛化短板。')
        self.assertIn('transformer', [str(item).lower() for item in spec['entities']])
        self.assertGreaterEqual(len(spec['aspects']), 2)
        self.assertEqual(spec['relation'], 'comparison')


if __name__ == '__main__':
    unittest.main()
