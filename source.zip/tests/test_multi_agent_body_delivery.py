"""Missing presentation is bounded recovery feedback, not scientific rejection."""
from copy import deepcopy

import pytest

from multi_agent_publication import body_delivery_findings, review_request, coverage, recovery_brief
from multi_agent_sections import BODY_DELIVERY_POLICY
from multi_agent_quality import (METRIC_DIRECTION_POLICY, NEGATION_METRIC_DIRECTION_POLICY,
    check_metric_direction, publication_rejections)
from multi_agent_pipeline_v2 import check_draft
from test_multi_agent_metric_direction import inputs
from test_multi_agent_publication import data


def table_case(text='Table 18的完整打印值如下（第26页）：'):
    ledger, draft, review = data()
    ledger['requirements'][0]['answer_kind'] = 'table_reading'
    draft['report_outline'] = {'body_delivery_policy': BODY_DELIVERY_POLICY,
                              'requirements': deepcopy(ledger['requirements'])}
    draft['claims'][0].update(text=text, report_section_id='analysis-g1')
    draft['claims'][1].update(report_section_id='proposals')
    return ledger, draft, review


@pytest.mark.parametrize('text', ['完整打印值如下：', '结果见下表：',
    'Table 18的完整打印值如下（第26页）：', 'The values are listed below:',
    'The requested rows are as follows (p.26):'])
def test_empty_body_table_pointer_has_exact_location_and_no_automatic_rewrite(text):
    ledger, draft, review = table_case(text)
    before = deepcopy((ledger, draft, review))
    finding, = body_delivery_findings(draft)
    assert finding['reason'] == 'BODY_TABLE_POINTER_UNRESOLVED'
    assert finding['field'] == 'text' and finding['requirement_ids'] == ['r1']
    assert text[finding['start']:finding['end']] == finding['assertion']
    assert not finding['scientific_rejection'] and not finding['automatic_rewrite']
    assert (ledger, draft, review) == before


def test_model_answered_label_cannot_close_empty_body_and_repair_is_exact():
    ledger, draft, review = table_case()
    draft['claims'][0]['qualification'] = 'r | loss | BLEU\n1 | 2 | 3\n2 | 1 | 4'
    result = coverage(ledger, draft, {'report_review': review}, set())
    assert result['requirements'][0]['status'] == 'limited'
    assert result['requirements'][1]['status'] == 'answered'
    assert result['unresolved_requirement_ids'] == ['r1'] and not result['review_errors']
    brief = recovery_brief(result, {'evidence': [{'evidence_id': 'e1', 'review_status': 'approved'}]})
    assert brief['requirements'][0]['body_delivery_findings'][0]['claim_id'] == 'c1'
    assert brief['uses_existing_writer_revision_round'] and brief['full_reaudit_required']
    assert brief['allowed_evidence_ids'] == ['e1']
    assert review_request(ledger, draft)['body_delivery_findings']


@pytest.mark.parametrize('where', ['qualification', 'other_requirement', 'other_section', 'isolated'])
def test_invisible_or_unrelated_or_isolated_table_does_not_resolve_body_pointer(where):
    _, draft, _ = table_case()
    rows = 'r | loss | BLEU\n1 | 2 | 3\n2 | 1 | 4'
    excluded = set()
    if where == 'qualification':
        draft['claims'][0]['qualification'] = rows
    else:
        extra = {**deepcopy(draft['claims'][0]), 'claim_id': 'table', 'text': rows}
        if where == 'other_requirement': extra['requirement_ids'] = ['r2']
        if where == 'other_section': extra['report_section_id'] = 'other'
        if where == 'isolated': excluded.add('table')
        draft['claims'].append(extra)
    assert body_delivery_findings(draft, excluded_claim_ids=excluded)


@pytest.mark.parametrize('rows', ['r | loss | BLEU\n1 | 2 | 3\n2 | 1 | 4',
    '1. 第一行读数须独立核对。\n2. 第二行读数须独立核对。',
    'r=1：第一行。\nr=2：第二行。'])
def test_later_visible_same_section_answer_resolves_pointer_without_format_mandate(rows):
    ledger, draft, review = table_case()
    extra = {**deepcopy(draft['claims'][0]), 'claim_id': 'table', 'text': rows}
    draft['claims'].append(extra)
    review['consistency']['reviewed_claim_ids'].append('table')
    assert not body_delivery_findings(draft)
    assert coverage(ledger, draft, {'report_review': review}, set())['all_content_answered']


@pytest.mark.parametrize('text', ['原文中的最低损失应与最高BLEU区分。',
    '如下是作者的原句，不是本次承诺补表。', '原表如下：\nr | v | x\n1 | 2 | 3',
    '尚未形成所要求的完整表；不能补造缺失行。'])
def test_real_body_or_explicit_uncompleted_reason_is_not_empty_pointer(text):
    _, draft, _ = table_case(text)
    assert not body_delivery_findings(draft)


@pytest.mark.parametrize('policy', [None, 'unknown'])
def test_historical_unversioned_report_is_not_reinterpreted(policy):
    ledger, draft, review = table_case()
    draft['report_outline']['body_delivery_policy'] = policy
    before = deepcopy(draft)
    assert not body_delivery_findings(draft)
    assert coverage(ledger, draft, {'report_review': review}, set())['all_content_answered']
    assert draft == before


def test_body_pointer_is_not_inserted_into_scientific_rejection_set():
    from test_multi_agent_report_fields import audit
    _, draft, _ = table_case()
    assert body_delivery_findings(draft)
    assert not publication_rejections(audit(draft), draft)


@pytest.mark.parametrize('separator', [',', '，', '、', ', r='])
@pytest.mark.parametrize('field', ['text', 'scope_note', 'qualification'])
def test_numeric_rank_list_cannot_hide_loss_peak_mistranslation(separator, field):
    draft, sources = inputs('原文报告实验结果。')
    draft['claims'][0].update(scope_note='', qualification='')
    draft['claims'][0][field] = '验证损失在r=16' + separator.join(['', '32', '64', '128', '256', '512']) + '达到峰值。'
    before = deepcopy((draft, sources))
    assert not check_metric_direction(draft, sources, policy=NEGATION_METRIC_DIRECTION_POLICY)
    finding, = check_metric_direction(draft, sources)
    assert finding['reason'] == 'METRIC_DIRECTION_INVERTED' and finding['field'] == field
    assert finding['policy'] == METRIC_DIRECTION_POLICY
    witness, = finding['source_witnesses']
    excerpt = sources['evidence'][0]['excerpt']
    assert excerpt[witness['start']:witness['end']] == witness['quote']
    assert (draft, sources) == before


@pytest.mark.parametrize('text', ['验证损失在r=16、32、64并列最低，BLEU达到峰值。',
    '验证损失最低，BLEU在r=16、32达到峰值。',
    '不能写验证损失在r=16、32达到峰值。',
    '验证损失在r=16、32时不是最高。',
    '性能在验证损失上于r=16、32达到峰值。'])
def test_enumerated_rank_protection_keeps_refutations_and_other_metric_boundaries(text):
    draft, sources = inputs(text)
    assert not check_metric_direction(draft, sources)


def test_only_versioned_new_draft_dispatch_uses_rank_list_rule():
    draft, sources = inputs('验证损失在r=16、32、64达到峰值。')
    draft['metric_direction_policy'] = NEGATION_METRIC_DIRECTION_POLICY
    assert not any(f['reason'] == 'METRIC_DIRECTION_INVERTED' for f in check_draft(draft, sources))
    draft['metric_direction_policy'] = METRIC_DIRECTION_POLICY
    assert any(f['reason'] == 'METRIC_DIRECTION_INVERTED' for f in check_draft(draft, sources))


@pytest.mark.parametrize('text', ['作者表注称验证损失在r=16、BLEU在r=4达到峰值。',
    '验证损失在r=16、32和BLEU在r=4均达到峰值。',
    'validation loss at r=16 and BLEU at r=4 peak.'])
def test_two_metrics_sharing_maximum_predicate_still_claims_a_loss_maximum(text):
    draft, sources = inputs(text)
    assert not check_metric_direction(draft, sources, policy=NEGATION_METRIC_DIRECTION_POLICY)
    finding, = check_metric_direction(draft, sources)
    assert finding['field'] == 'text' and finding['reason'] == 'METRIC_DIRECTION_INVERTED'


@pytest.mark.parametrize('text', ['验证损失在r=16最低、BLEU在r=4达到峰值。',
    '验证损失在r=16、BLEU在r=4均最优。',
    '验证损失在r=16、BLEU在r=4不应称达到峰值。',
    '不能写验证损失在r=16、BLEU在r=4达到峰值。'])
def test_independent_minimum_or_performance_optimum_or_refutation_not_shared_maximum(text):
    draft, sources = inputs(text)
    assert not check_metric_direction(draft, sources)


@pytest.mark.parametrize('text', ['不能把验证损失的最小值当作最大值。',
    '不应将validation loss的最小值说成最大值。', '避免把验证损失说成最高。'])
def test_visible_refutation_with_ba_jiang_is_not_an_asserted_loss_maximum(text):
    draft, sources = inputs(text)
    assert check_metric_direction(draft, sources, policy=NEGATION_METRIC_DIRECTION_POLICY)
    assert not check_metric_direction(draft, sources)


def test_refutation_does_not_exempt_a_later_actual_maximum_assertion():
    draft, sources = inputs('不能把验证损失的最小值当作最大值，但验证损失确实最高。')
    finding, = check_metric_direction(draft, sources)
    assert finding['assertion'] == '验证损失确实最高'


@pytest.mark.parametrize('repair', [False, True])
def test_formal_workflow_routes_empty_body_to_one_existing_revision_round(tmp_path, repair):
    import json
    from tools.multi_agent_cli import _mock_agents, _mock_search
    from multi_agent_agents import ArtifactDirectory
    from multi_agent_workflow import WorkflowStore
    from multi_agent_pipeline_v2 import LiteraturePipelineV2, DeterministicLiteratureExecutor
    workers = _mock_agents()
    original_planner, original_writer = workers.planner.handler, workers.writer.handler
    writer_calls = []

    def planner(packet):
        value = original_planner(packet)
        value['output']['user_requirements'][0]['answer_kind'] = 'table_reading'
        return value

    def writer(packet):
        writer_calls.append(packet)
        value = original_writer(packet)
        for claim in value['output']['claims']:
            if claim['section'] != 'direct_conclusion':
                claim['text'] = ('r | value | setting\n1 | 2 | A\n2 | 3 | B'
                                 if repair and len(writer_calls) > 1 else '完整表格如下：')
        return value

    workers.planner.handler, workers.writer.handler = planner, writer
    store = WorkflowStore(tmp_path/'workflow.sqlite3')
    artifacts = ArtifactDirectory(tmp_path/'artifacts')
    flow = LiteraturePipelineV2(store, artifacts, workers, DeterministicLiteratureExecutor(_mock_search),
                               event_path=tmp_path/'events.jsonl')
    result = flow.run('body-repair', 'synthetic-owner', '请按列解释表格。')
    final = artifacts.get(result['final_artifact_id'])
    initial = artifacts.get(final['artifact_refs']['initial_publication_coverage'])
    delivery = artifacts.get(final['artifact_refs']['publication_coverage'])
    assert len(writer_calls) == 2 and result['run']['model_calls_used'] == 7
    assert initial['requirements'][0]['status'] == 'limited'
    assert initial['requirements'][0]['body_delivery_findings']
    assert delivery['all_content_answered'] is repair
    assert not delivery['review_errors']
    assert result['run']['status'] != 'failed' and final['direct_answer']
    assert delivery['requirements'][0]['status'] == ('answered' if repair else 'limited')
    events = [json.loads(line) for line in (tmp_path/'events.jsonl').read_text(encoding='utf-8').splitlines()]
    assert sum(e.get('event') == 'publication_recovery_started' for e in events) == 1
    recovery = next(i['payload'] for i in writer_calls[1]['inputs']
                    if i['payload'].get('schema_version') == 'sciassistant.publication-recovery/v1')
    assert recovery['requirements'][0]['body_delivery_findings']
    assert recovery['full_reaudit_required']
