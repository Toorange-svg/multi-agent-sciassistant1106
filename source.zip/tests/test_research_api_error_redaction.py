"""Research service API and debug exports redact internal failures."""

from pathlib import Path
from unittest import mock

import web_app


SECRET = "private-host-token-absolute-path-canary"


def test_settings_validation_error_is_fixed_and_logged_without_detail():
    with mock.patch.object(web_app, "_persist_api_key_settings", side_effect=ValueError(SECRET)), \
         mock.patch.object(web_app.app.logger, "error") as logged:
        response = web_app.app.test_client().post(
            "/api/settings/api-keys", json={"values": {"x": "y"}})
    assert response.status_code == 400
    assert response.get_json() == {
        "error": "INVALID_SETTINGS",
        "message": "请求配置无效，请检查后重试。",
    }
    assert SECRET not in response.get_data(as_text=True)
    assert SECRET not in repr(logged.call_args)


def test_report_export_failure_is_fixed_500_without_exception_text(tmp_path):
    task_id = "redaction-export"
    task = {"id": task_id, "status": "completed", "answer": "safe answer"}
    with web_app.TASK_LOCK:
        old = web_app.TASKS.get(task_id)
        web_app.TASKS[task_id] = task
    try:
        with mock.patch.object(web_app, "export_report_files", side_effect=OSError(SECRET)):
            response = web_app.app.test_client().get(f"/api/tasks/{task_id}/export?format=md")
    finally:
        with web_app.TASK_LOCK:
            if old is None:
                web_app.TASKS.pop(task_id, None)
            else:
                web_app.TASKS[task_id] = old
    assert response.status_code == 500
    assert response.get_json()["error"] == "INTERNAL_ERROR"
    assert SECRET not in response.get_data(as_text=True)


def test_debug_artifact_metadata_never_contains_path_or_os_error(tmp_path):
    missing = tmp_path / SECRET / "missing.log"
    text, metadata = web_app._debug_artifact_text(missing)
    assert text == "" and metadata == "文件不存在"
    assert SECRET not in metadata and str(tmp_path) not in metadata


def test_debug_json_serialization_error_contains_type_only():
    class Broken:
        pass

    with mock.patch.object(web_app.json, "dumps", side_effect=[ValueError(SECRET), '{"serialization_error":"ValueError"}']):
        result = web_app._debug_json_block(Broken())
    assert SECRET not in result
    assert "ValueError" in result


def test_source_does_not_return_raw_exception_from_research_endpoints():
    source = Path(web_app.__file__).read_text(encoding="utf-8")
    assert 'jsonify({"error": str(exc)})' not in source
    assert 'jsonify({"error": f"导出失败：{exc}"})' not in source
    assert 'f"{type(exc).__name__}: {exc}"' not in source
