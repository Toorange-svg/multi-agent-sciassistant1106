from __future__ import annotations

import sqlite3

import pytest

from multi_agent_workflow import (
    DEFAULT_MAX_MODEL_CALLS,
    WorkflowBudgetExceeded,
    WorkflowError,
    WorkflowStore,
    validate_artifact,
)


def question(task_id="task-001"):
    return {
        "schema_version": 1, "task_id": task_id, "question": "How do method A and B differ?",
        "conversation_facts": ["The user asked for evidence."], "deadline_at": 123.0,
        "remaining_model_calls": 10,
    }


def plan():
    return {
        "schema_version": 1,
        "groups": [{"id": "g1", "question": "method A", "queries": ["method A evidence"], "priority": 1}],
        "assumptions": [], "out_of_scope": [],
    }


def test_contracts_are_versioned_bounded_and_reject_raw_agent_channels():
    assert validate_artifact("question_envelope", question())["task_id"] == "task-001"
    assert validate_artifact("research_plan", plan())["groups"][0]["id"] == "g1"
    malformed = question()
    malformed["raw_response"] = "private model output"
    with pytest.raises(WorkflowError):
        validate_artifact("question_envelope", malformed)
    too_many_groups = plan()
    too_many_groups["groups"] *= 4
    with pytest.raises(WorkflowError):
        validate_artifact("research_plan", too_many_groups)


def test_store_keeps_durable_structured_artifacts_and_no_agent_database_handle(tmp_path):
    now = [1000.0]
    store = WorkflowStore(tmp_path / "workflow.sqlite3", clock=lambda: now[0])
    created = store.create_run("task-001", "user-001")
    assert created["status"] == "created"
    record = store.add_artifact("task-001", "question_envelope", question())
    assert len(record["sha256"]) == 64
    store.add_artifact("task-001", "research_plan", plan())
    reopened = WorkflowStore(tmp_path / "workflow.sqlite3", clock=lambda: now[0])
    artifacts = reopened.list_artifacts("task-001")
    assert [item["artifact_type"] for item in artifacts] == ["question_envelope", "research_plan"]
    assert artifacts[0]["payload"]["question"].startswith("How do method")
    raw = sqlite3.connect(tmp_path / "workflow.sqlite3").execute(
        "SELECT payload_json FROM workflow_artifact"
    ).fetchall()
    assert all("raw_response" not in row[0] and "Authorization" not in row[0] for row in raw)


def test_state_machine_rejects_skips_and_terminal_reactivation(tmp_path):
    store = WorkflowStore(tmp_path / "workflow.sqlite3", clock=lambda: 1000.0)
    store.create_run("task-001", "user-001")
    with pytest.raises(WorkflowError):
        store.transition("task-001", "writing")
    assert store.transition("task-001", "planned")["status"] == "planned"
    assert store.transition("task-001", "retrieving")["status"] == "retrieving"
    assert store.transition("task-001", "partial")["status"] == "partial"
    with pytest.raises(WorkflowError):
        store.transition("task-001", "reviewing")


def test_model_call_budget_is_atomic_and_never_exceeds_ten(tmp_path):
    store = WorkflowStore(tmp_path / "workflow.sqlite3", clock=lambda: 1000.0)
    store.create_run("task-001", "user-001")
    permits = [store.reserve_model_call("task-001", "planner") for _ in range(DEFAULT_MAX_MODEL_CALLS)]
    assert permits[-1].call_number == DEFAULT_MAX_MODEL_CALLS
    assert permits[-1].remaining_calls == 0
    with pytest.raises(WorkflowBudgetExceeded):
        store.reserve_model_call("task-001", "writer")
    run = store.get_run("task-001")
    assert run["model_calls_used"] == DEFAULT_MAX_MODEL_CALLS
    assert run["status"] == "failed"
    assert run["failure_code"] == "MODEL_CALL_BUDGET_EXCEEDED"


def test_time_budget_and_cancellation_stop_new_model_calls(tmp_path):
    now = [1000.0]
    store = WorkflowStore(tmp_path / "workflow.sqlite3", clock=lambda: now[0])
    store.create_run("task-001", "user-001", time_budget_seconds=1)
    now[0] = 1001.0
    with pytest.raises(WorkflowBudgetExceeded):
        store.reserve_model_call("task-001", "planner")
    assert store.get_run("task-001")["failure_code"] == "TIME_BUDGET_EXCEEDED"

    store.create_run("task-002", "user-001")
    store.transition("task-002", "cancelled")
    with pytest.raises(WorkflowBudgetExceeded):
        store.reserve_model_call("task-002", "planner")


def test_partial_answer_requires_explicit_coverage_and_claim_map():
    valid = {
        "schema_version": 1, "answer": "Only the first sub-question has evidence.",
        "claim_evidence_map": [{"claim_id": "claim-1", "evidence_ids": ["evidence-1"]}],
        "coverage_status": "partial", "unresolved_questions": ["method B has no direct evidence"],
    }
    assert validate_artifact("draft_answer", valid)["coverage_status"] == "partial"
    invalid = dict(valid)
    invalid["coverage_status"] = "insufficient"
    with pytest.raises(WorkflowError):
        validate_artifact("draft_answer", invalid)


def test_research_gap_is_bounded_and_rejects_unknown_fields():
    gap = {"schema_version": 1, "round": 1,
           "groups": [{"group_id": "g1", "queries": ["targeted benchmark query"]}]}
    assert validate_artifact("research_gap", gap)["round"] == 1
    malformed = dict(gap)
    malformed["raw_response"] = "not allowed"
    with pytest.raises(WorkflowError):
        validate_artifact("research_gap", malformed)


def test_outer_timeout_is_idempotently_synchronized_to_durable_run(tmp_path):
    store = WorkflowStore(tmp_path / "workflow.sqlite3", clock=lambda: 100.0)
    store.create_run("run-timeout", "owner")
    result = store.force_terminal(
        "run-timeout", "timed_out", failure_code="OUTER_TASK_TIMEOUT",
        details={"source": "test_boundary"},
    )
    assert result["status"] == "timed_out"
    assert result["failure_code"] == "OUTER_TASK_TIMEOUT"
    repeated = store.force_terminal("run-timeout", "timed_out", failure_code="OUTER_TASK_TIMEOUT")
    assert repeated["status"] == "timed_out"
    assert [item["stage"] for item in store.list_stages("run-timeout")].count("timed_out") == 1
