"""Responsive contracts and sidebar state logic; not a browser layout test."""
from html.parser import HTMLParser
import json
from pathlib import Path
import shutil
import subprocess

import pytest


HTML = (Path(__file__).resolve().parents[1] / "chatAi/ai_chat.html").read_text(encoding="utf-8")


class Elements(HTMLParser):
    def __init__(self):
        super().__init__()
        self.elements = {}
        self.submit = []
    def handle_starttag(self, tag, attrs):
        attributes = dict(attrs)
        if "id" in attributes:
            self.elements[attributes["id"]] = (tag, attributes)
        if tag == "button" and attributes.get("type") == "submit":
            self.submit.append(attributes)


def test_input_and_mode_controls_have_shrinkable_wrapping_contract():
    css = HTML.split('<style id="chat-responsive-layout">', 1)[1].split('</style>', 1)[0]
    assert "#main-content { min-width: 0; min-height: 0; }" in css
    assert "#chat-form { display: flex; flex-wrap: wrap;" in css
    assert "#user-input { min-width: 0; width: 0;" in css
    assert "#chat-form > button, #context-file-label { flex-shrink: 0;" in css
    assert "#research-processing-mode, #pdf-parse-mode { min-width: 0; max-width: 100%;" in css
    assert "@media (max-width: 767px)" in css
    assert "#sidebar.sidebar-collapsed { transform: translateX(-100%); }" in css
    assert "#mobile-sidebar-btn { top: 8px;" in css


def test_sidebar_and_cancel_buttons_cannot_submit_form():
    parser = Elements(); parser.feed(HTML)
    for key in ("cancel-button", "sidebar-toggle-btn", "mobile-sidebar-btn", "sidebar-backdrop", "chat-settings-btn", "sidebar-settings-btn"):
        assert parser.elements[key][1]["type"] == "button"
        assert parser.elements[key][1].get("aria-label") or parser.elements[key][1].get("title")
    assert "hidden" in parser.elements["sidebar-backdrop"][1]
    assert any(item.get("aria-label") == "发送问题" for item in parser.submit)


def test_sidebar_initial_narrow_resize_escape_and_backdrop_in_node():
    node = shutil.which("node")
    if not node:
        pytest.skip("Node required for sidebar logic check")
    source = "function toggleSidebar() {" + HTML.split("function toggleSidebar() {", 1)[1].split(
        "// ==================== 文献缓存管理", 1)[0]
    harness = r'''
function element() {
  const values = new Set(), listeners = {}, attrs = {};
  return {style: {}, hidden: true, listeners, attrs, focused: 0,
    classList: {add: (...items) => items.forEach(x => values.add(x)),
      remove: (...items) => items.forEach(x => values.delete(x)),
      contains: x => values.has(x), toggle(x, force) { if(force) values.add(x); else values.delete(x); }},
    setAttribute: (key, value) => attrs[key] = value,
    addEventListener: (key, fn) => listeners[key] = fn,
    focus() { this.focused++; }};
}
const sidebar = element(), sidebarToggleBtn = element(), mobileSidebarBtn = element();
const backdrop = element(), actions = element(), sidebarTexts = [{style:{}}];
let sidebarCollapsed = false;
const document = {listeners:{}, querySelector: () => actions, querySelectorAll: () => [],
  getElementById: key => key === 'sidebar-backdrop' ? backdrop : null,
  addEventListener(key, fn) { this.listeners[key] = fn; }};
const window = {innerWidth:462, listeners:{}, addEventListener(key, fn) { this.listeners[key] = fn; }};
'''
    probe = r'''
const results = {};
results.initial_closed = sidebarCollapsed && sidebar.inert && backdrop.hidden && !mobileSidebarBtn.classList.contains('hidden');
mobileSidebarBtn.listeners.click();
results.opens = !sidebarCollapsed && !sidebar.inert && !backdrop.hidden && sidebar.attrs['aria-hidden'] === 'false';
window.listeners.resize();
results.same_mobile_resize_preserves_open = !sidebarCollapsed;
document.listeners.keydown({key:'Escape'});
results.escape_closes_and_focuses = sidebarCollapsed && sidebar.inert && mobileSidebarBtn.focused === 1;
window.innerWidth = 1280; window.listeners.resize();
results.desktop_not_inert = !sidebar.inert && backdrop.hidden && mobileSidebarBtn.classList.contains('hidden');
results.desktop_restores = !sidebarCollapsed && sidebar.style.width === '260px';
sidebarToggleBtn.listeners.click();
results.desktop_collapses = sidebarCollapsed && sidebar.style.width === '60px';
sidebarToggleBtn.listeners.click();
results.desktop_expands = !sidebarCollapsed && sidebar.style.width === '260px';
window.innerWidth = 320; window.listeners.resize();
results.narrow_transition_closes = sidebarCollapsed && sidebar.inert && backdrop.hidden;
mobileSidebarBtn.listeners.click(); backdrop.listeners.click();
results.backdrop_closes = sidebarCollapsed && backdrop.hidden;
console.log(JSON.stringify(results));
'''
    completed = subprocess.run([node, "-e", harness + source + probe], capture_output=True, text=True, encoding="utf-8", timeout=10)
    assert completed.returncode == 0, completed.stderr
    checks = json.loads(completed.stdout)
    assert len(checks) == 10 and all(checks.values()), checks


def test_desktop_drag_keyboard_settings_and_manual_collapse_restore():
    node = shutil.which("node")
    if not node: pytest.skip("Node required")
    source = "function toggleSidebar() {" + HTML.split("function toggleSidebar() {", 1)[1].split(
        "// ==================== 文献缓存管理", 1)[0]
    harness = r'''
const make=()=>({style:{},events:{},attrs:{},hidden:true,capture:null,modal:false,
 classList:{add(){},remove(){},toggle(){}},setAttribute(k,v){this.attrs[k]=v;},
 addEventListener(k,fn){this.events[k]=fn;},setPointerCapture(id){this.capture=id;},hasPointerCapture(id){return this.capture===id;},
 releasePointerCapture(){this.capture=null;},showModal(){this.modal=true;},close(){this.modal=false;}});
const sidebar=make(),sidebarToggleBtn=make(),mobileSidebarBtn=make(),sidebarTexts=[];
let sidebarCollapsed=false;
const ids={};for(const id of ['sidebar-backdrop','sidebar-resize-handle','sidebar-width-setting','chat-settings-dialog','chat-settings-btn','sidebar-settings-btn','close-chat-settings','reset-chat-layout'])ids[id]=make();
const document={getElementById:id=>ids[id]||null,querySelector:()=>make(),querySelectorAll:()=>[],addEventListener(){}};
const window={innerWidth:1366,events:{},addEventListener(k,fn){this.events[k]=fn;}};
'''
    probe = r'''
const handle=ids['sidebar-resize-handle'],dialog=ids['chat-settings-dialog'],results={};
handle.events.pointerdown({button:0,pointerId:1,preventDefault(){}});
handle.events.pointermove({pointerId:1,clientX:500});
results.drag_clamped=sidebar.style.width==='380px'&&handle.attrs['aria-valuenow']==='380';
handle.events.pointerup({pointerId:1});handle.events.pointermove({pointerId:1,clientX:200});
results.released=sidebar.style.width==='380px';
handle.events.keydown({key:'ArrowLeft',preventDefault(){}});results.keyboard=sidebar.style.width==='370px';
sidebarToggleBtn.events.click();window.innerWidth=462;window.events.resize();mobileSidebarBtn.events.click();
window.innerWidth=1366;window.events.resize();results.manual_collapse_restored=sidebarCollapsed&&sidebar.style.width==='60px';
ids['chat-settings-btn'].events.click();results.settings_when_collapsed=dialog.modal;
ids['close-chat-settings'].events.click();results.close_settings=!dialog.modal&&sidebarCollapsed;
sidebarToggleBtn.events.click();window.innerWidth=800;window.events.resize();handle.events.keydown({key:'End',preventDefault(){}});
results.answer_min_width=sidebar.style.width==='320px';
console.log(JSON.stringify(results));
'''
    result = subprocess.run([node, "-"], input=harness + source + probe, text=True, encoding="utf8", capture_output=True, timeout=10)
    assert result.returncode == 0, result.stderr
    checks = json.loads(result.stdout)
    assert len(checks) == 7 and all(checks.values()), checks
