"""Focused revision is a source-reading aid, never a publication bypass."""
from copy import deepcopy
import json

import pytest

from multi_agent_pipeline_v2 import check_draft
from multi_agent_quality import (check_reading_scope, check_claim_revision,
    writer_revision_brief, READING_SCOPE_POLICY, publication_rejections)
from multi_agent_live import ROLE_PROMPTS
from test_multi_agent_quantity_feedback_and_reading_scope import example


@pytest.mark.parametrize("text", ["论文未做跨数据集同条件对照。", "论文没有开展对照。",
    "本文并未进行消融实验。", "作者未检验统一基线。", "论文未验证该机制。",
    "The study did not perform a controlled experiment.", "The paper does not conduct ablations."])
def test_new_absence_verbs_in_visible_notes(text):
    draft, evidence = example()
    draft["claims"][0].update(text="所选片段展示不同设置。", scope_note=text, qualification="")
    draft["reading_scope_policy"] = READING_SCOPE_POLICY
    issue = next(row for row in check_draft(draft, evidence) if row["reason"] == "READING_SCOPE_OVERSTATED")
    assert issue["field"] == "scope_note" and issue["policy"] == READING_SCOPE_POLICY


@pytest.mark.parametrize("text", ["所选原文片段中，论文未做同条件对照。",
    "不能据此断言论文没有开展对照。", "论文报告的是两个实验设置。",
    "In reviewed excerpts the study did not perform a controlled experiment."])
def test_scoped_or_nonabsence_notes_are_not_rejected(text):
    draft, evidence = example()
    draft["claims"][0].update(scope_note=text, qualification="")
    assert not check_reading_scope(draft, evidence)


def test_note_repair_requires_actual_identified_field_change_and_reaudit():
    old, evidence = example()
    old["claims"][0].update(scope_note="论文未做同条件对照。", qualification="")
    old["reading_scope_policy"] = READING_SCOPE_POLICY
    feedback = {"code_issues": check_draft(old, evidence)}
    revised = deepcopy(old)
    revised["claims"][0]["scope_note"] = "所选原文片段未提供同条件对照，不能作因果比较。"
    result = check_claim_revision(old, revised, feedback)
    assert not result["code_issues"] and not result["semantic_auto_approval"]
    assert result["resolution_targets"][0]["change_status"] == "edited_located_fields_requires_semantic_reaudit"
    assert check_draft(revised, evidence) == []
    assert publication_rejections({}, revised) == {"c1"}


@pytest.mark.parametrize("mutation", ["hidden", "move", "model_reject", "old_policy", "no_fields"])
def test_note_repair_cannot_bypass_unchanged_or_semantic_rejection(mutation):
    old, evidence = example()
    old["claims"][0].update(scope_note="论文未做同条件对照。", qualification="")
    feedback = {"code_issues": check_reading_scope(old, evidence)}
    revised = deepcopy(old)
    if mutation == "hidden":
        revised["claims"][0]["qualification"] = "仅核查所选片段。"
    elif mutation == "move":
        revised["claims"][0].update(scope_note="", text="论文未做同条件对照。")
    else:
        revised["claims"][0]["scope_note"] = "所选片段未提供对照。"
        if mutation == "model_reject":
            feedback["model_audit"] = {"claim_results": [{"claim_id": "c1", "decision": "rejected",
                "reason_code": "UNSUPPORTED_EXTRAPOLATION"}]}
        elif mutation == "old_policy":
            feedback["code_issues"][0]["policy"] = "selected-evidence-absence-scope/v1"
        else:
            feedback["code_issues"][0].pop("field")
    assert check_reading_scope(revised, evidence) or check_claim_revision(old, revised, feedback)["code_issues"]


def test_brief_focuses_on_actual_hidden_numeric_field_without_adding_citations():
    draft, evidence = example()
    draft["claims"][0].update(text="本页提示工程约84%。", qualification="另页约85%。")
    evidence["evidence"][0]["excerpt"] = "This page reports about 84% accuracy."
    feedback = {"code_issues": check_draft(draft, evidence)}
    before = deepcopy((draft, feedback, evidence))
    brief = writer_revision_brief(draft, feedback, evidence)
    target = brief["targets"][0]
    assert target["fields"] == [{"field": "qualification", "prior_value": "另页约85%。", "value_truncated": False}]
    assert target["approved_candidate_sources"][0]["evidence_id"] == "p1"
    assert target["approved_candidate_sources"][0]["quote"] == evidence["evidence"][1]["excerpt"]
    assert target["current_evidence_ids"] == ["e1"]
    assert not brief["automatic_text_repair"] and not brief["automatic_citation_repair"]
    assert not brief["semantic_auto_approval"]
    json.dumps(brief)
    assert (draft, feedback, evidence) == before


def test_candidate_brief_passes_actual_artifact_sensitive_field_validation(tmp_path):
    from multi_agent_agents import ArtifactDirectory
    draft, evidence = example()
    draft["claims"][0].update(text="本页提示工程约84%。", qualification="另页约85%。")
    evidence["evidence"][0]["excerpt"] = "84% accuracy."
    brief = writer_revision_brief(draft, {"code_issues": check_draft(draft, evidence)}, evidence)
    directory = ArtifactDirectory(tmp_path / "artifacts")
    saved = directory.put("writer-revision-brief", brief)
    assert directory.get(saved["artifact_id"]) == brief
    assert brief["targets"][0]["approved_candidate_sources"]


def test_brief_excludes_pending_and_marks_caps_without_hiding_full_feedback():
    draft, evidence = example()
    evidence["evidence"][1].update(review_status="pending", excerpt="85% from pending source")
    draft["claims"] = [{**draft["claims"][0], "claim_id": f"c{i}"} for i in range(15)]
    feedback = {"code_issues": [{"claim_id": c["claim_id"], "reason": "UNSUPPORTED_NUMBER",
        "field_errors": [{"field": "qualification", "unsupported_quantities": [{"candidate_evidence_ids": ["p1", "unknown"]}]}]}
        for c in draft["claims"]]}
    brief = writer_revision_brief(draft, feedback, evidence)
    assert brief["target_count"] == 15 and len(brief["targets"]) == 12
    assert not brief["targets_complete"] and brief["full_feedback_and_evidence_required"]
    assert all(not row["approved_candidate_sources"] for row in brief["targets"])


def test_candidate_quote_preserves_literal_offsets_near_number_not_just_abstract_opening():
    draft, evidence = example()
    draft["claims"][0].update(text="本页提示工程约84%。", qualification="另页约85%。")
    evidence["evidence"][0]["excerpt"] = "84% accuracy."
    evidence["evidence"][1]["excerpt"] = "Background " * 100 + "About 85% accuracy on another dataset." + " Context" * 90
    feedback = {"code_issues": check_draft(draft, evidence)}
    quote = writer_revision_brief(draft, feedback, evidence)["targets"][0]["approved_candidate_sources"][0]
    text = evidence["evidence"][1]["excerpt"]
    assert "85%" in quote["quote"] and quote["quote"] == text[quote["start"]:quote["end"]]
    assert len(quote["quote"]) <= 500 and quote["quote_truncated"]


def test_legacy_draft_policy_does_not_recompute_historical_publication():
    draft, evidence = example()
    draft["claims"][0].update(text="论文未做对照。", qualification="", claim_type="limitation")
    draft["reading_scope_policy"] = "selected-evidence-absence-scope/v1"
    before = deepcopy((draft, evidence))
    assert check_draft(draft, evidence) == []
    assert (draft, evidence) == before
    draft["reading_scope_policy"] = READING_SCOPE_POLICY
    assert check_draft(draft, evidence)[0]["reason"] == "READING_SCOPE_OVERSTATED"


def test_prompts_require_setting_not_causal_decomposition_and_actual_field_edits():
    assert "DIFFERENT SETTINGS" in ROLE_PROMPTS["writer"]
    assert "writer-revision-brief/v1" in ROLE_PROMPTS["writer"]
    assert "freshly revised FULL claim-draft" in ROLE_PROMPTS["writer"]
    assert "controlled ablations" in ROLE_PROMPTS["citation_auditor"]


@pytest.mark.parametrize("repair", [True, False])
def test_workflow_focused_note_repair_once_keeps_independent_answer(tmp_path, repair):
    from test_multi_agent_pipeline_v2 import agents, pipeline
    from test_multi_agent_scientific_scope import audit
    from multi_agent_quality import WITNESS_AUDIT_SCHEMA
    configured, calls = agents()
    packets = []
    actual = "This abstract describes an experiment on a single dataset, with one protocol."
    def writer(packet):
        calls.append("writer")
        packets.append(packet)
        source = next(row["payload"] for row in packet["inputs"] if "evidence" in row["payload"])
        key = source["evidence"][0]["evidence_id"]
        note = "所选摘要片段未提供对照。" if repair and len(packets) > 1 else "论文未做对照。"
        return {"output": {"schema_version": "sciassistant.claim-draft/v2", "direct_answer": "有限回答",
            "claims": [{"claim_id": "c1", "text": "所选摘要介绍一种实验协议。", "scope_note": note,
                "claim_type": "limitation", "evidence_ids": [key], "confidence": "low", "section": "direct_conclusion"},
                {"claim_id": "independent", "text": "所选摘要涉及单个数据集。", "scope_note": "",
                 "claim_type": "limitation", "evidence_ids": [key], "confidence": "low", "section": "topic_analysis"}]}}
    def auditor(packet):
        calls.append("citation_auditor")
        data = next(row["payload"] for row in packet["inputs"] if "claims" in row["payload"])
        value = audit(data)
        value["schema_version"] = WITNESS_AUDIT_SCHEMA
        for row in value["claim_results"]:
            row["source_witnesses"] = [{"evidence_id": row["evidence_ids"][0], "quote": actual}]
        return {"output": value}
    configured.writer.handler, configured.citation_auditor.handler = writer, auditor
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {"status": "ok", "papers": [
        {"paper_id": "1", "title": "Paper", "abstract": actual}]})
    execute = flow.executor.execute
    def scoped_execute(*args, **kwargs):
        value = execute(*args, **kwargs)
        for row in value["evidence"]:
            row["coverage_scope"] = "abstract"
        return value
    flow.executor.execute = scoped_execute
    result = flow.run("focused-repair", "owner", "Explain the described protocol")
    assert calls.count("writer") == calls.count("citation_auditor") == 2
    assert result["run"]["model_calls_used"] == 7
    brief = next(row["payload"] for row in packets[1]["inputs"]
        if row["payload"].get("schema_version") == "sciassistant.writer-revision-brief/v1")
    assert brief["targets"][0]["fields"][0]["field"] == "scope_note"
    assert result["run"]["status"] == ("partial" if repair else "needs_review")
    assert "单个数据集" in result["direct_answer"]
    if not repair:
        assert "论文未做对照" not in result["direct_answer"]
