"""Offline regressions for business failures, read suppression and evidence."""
import json
import os
import sys
import tempfile
import threading
from types import SimpleNamespace
import unittest
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import Mock, patch

import httpx

ROOT = Path(__file__).resolve().parents[1]
for entry in (str(ROOT), str(ROOT / "deepdiver_v2")):
    if entry not in sys.path:
        sys.path.insert(0, entry)

from deepdiver_v2.src.arxiv_read_control import ArxivReadGuard, ReadTrace
from deepdiver_v2.src.tools import mcp_client as client_module
from deepdiver_v2.src.tools.mcp_client import MCPClient, MCPClientResult, MCPTool, RetryConfig
from deepdiver_v2.src.tools import mcp_tools
from deepdiver_v2.src import arxiv_pdf_download as pdf
import web_app


def client_with_transport(payload, is_error=False):
    client = MCPClient.__new__(MCPClient)
    client.server_url = "http://127.0.0.1:6274/mcp"
    client.retry_config = RetryConfig(max_retries=0)
    client._request_id = 0
    client._session_id = "test-session"
    client._connected = True
    client._tools = {name: MCPTool(name) for name in ("arxiv_read_paper", "other")}
    response = httpx.Response(200, json={"result": {
        "content": [{"type": "text", "text": json.dumps(payload)}], "isError": is_error
    }})
    client._http_client = Mock()
    client._http_client.post.return_value = response
    return client


class ArxivReadControlTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.task_a = str(Path(directory.name) / "task-a.jsonl")
        self.task_b = str(Path(directory.name) / "task-b.jsonl")
        env_patch = patch.dict(os.environ, {"SCIASSISTANT_DIAGNOSTICS_PATH": self.task_a})
        env_patch.start()
        self.addCleanup(env_patch.stop)
        self.guard_patch = patch.object(client_module, "_ARXIV_READ_GUARD", ArxivReadGuard())
        self.guard_patch.start()
        self.addCleanup(self.guard_patch.stop)

    def test_business_failure_is_not_transport_success(self):
        client = client_with_transport({"success": False, "error": "private-token", "data": None})
        result = client.call_tool("arxiv_read_paper", {"paper_id": "2105.05233"})
        self.assertFalse(result.success)
        self.assertEqual(result.metadata["error_code"], "TOOL_FAILED")
        self.assertNotIn("private-token", result.error)

    def test_mcp_is_error_flag_is_respected(self):
        client = client_with_transport("private error body", is_error=True)
        self.assertFalse(client.call_tool("other", {}).success)

    def test_failed_read_guard_with_real_local_http_transport(self):
        requests_seen = []
        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                requests_seen.append(body)
                result = {"success": False, "metadata": {"read_diagnostics": [
                    {"phase": "request_pacing", "status": "failed", "elapsed_ms": 90000}]}}
                response = json.dumps({"jsonrpc": "2.0", "id": body["id"], "result": {
                    "content": [{"type": "text", "text": json.dumps(result)}]}}).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(response)))
                self.end_headers()
                self.wfile.write(response)
            def log_message(self, *_):
                pass
        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        client = client_with_transport({})
        client.server_url = f"http://127.0.0.1:{server.server_port}/mcp"
        client._http_client = httpx.Client(trust_env=False, timeout=2)
        try:
            with tempfile.TemporaryDirectory() as directory:
                path = Path(directory) / "events.jsonl"
                with patch.dict(os.environ, {"SCIASSISTANT_DIAGNOSTICS_PATH": str(path)}):
                    first = client.call_tool("arxiv_read_paper", {"paper_id": "2105.05233"})
                    second = client.call_tool("arxiv_read_paper", {"paper_id": "2105.05233"})
                self.assertFalse(first.success)
                self.assertFalse(second.success)
                self.assertEqual(len(requests_seen), 1)
                self.assertEqual(second.metadata["read_guard"], "failure_cooldown")
                self.assertTrue(any(e["stage"] == "arxiv_read:request_pacing"
                                    for e in web_app._read_diagnostic_events(path)))
        finally:
            client.close()
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)

    def test_success_payload_shape_is_preserved(self):
        payload = {"success": True, "data": {"text": "document"}, "metadata": {}}
        client = client_with_transport(payload)
        result = client.call_tool("other", {})
        self.assertTrue(result.success)
        self.assertEqual(result.data, payload)

    def test_transport_timeout_is_failed_and_not_replayed(self):
        client = client_with_transport({})
        client.retry_config.max_retries = 5
        client._http_client.post.side_effect = httpx.ReadTimeout("private-token")
        result = client.call_tool("arxiv_read_paper", {"paper_id": "2105.05233"})
        self.assertFalse(result.success)
        self.assertEqual(result.metadata["error_code"], "MCP_TRANSPORT_TIMEOUT")
        client._http_client.post.assert_called_once()

    def test_real_cached_pdf_parse_returns_safe_phase_timings(self):
        import fitz
        tools = mcp_tools.MCPTools.__new__(mcp_tools.MCPTools)
        with tempfile.TemporaryDirectory() as directory:
            tools.workspace_path = Path(directory)
            output = Path(directory) / "arxiv"
            output.mkdir()
            with fitz.open() as document:
                page = document.new_page()
                page.insert_text((72, 72), "Offline public paper parsing canary.")
                document.save(output / "2105.05233.pdf")
            with patch.object(mcp_tools, "get_config", return_value=SimpleNamespace(pdf_parse_mode="local")), patch.object(mcp_tools.requests, "get", side_effect=AssertionError("cached PDF must not request HTTP")):
                result = tools.arxiv_read_paper("2105.05233", pdf_parse_mode="local")
            self.assertTrue(result.success, result.error)
            phases = result.metadata["read_diagnostics"]
            self.assertIn("pdf_parse", [event["phase"] for event in phases])
            self.assertNotIn("http_download", [event["phase"] for event in phases])
            self.assertNotIn(directory, json.dumps(phases))

    def test_identical_failed_read_is_suppressed_across_clients_in_task(self):
        a = client_with_transport({"success": False})
        b = client_with_transport({"success": False})
        with patch.dict(os.environ, {"SCIASSISTANT_DIAGNOSTICS_PATH": self.task_a}):
            a.call_tool("arxiv_read_paper", {"paper_id": "2105.05233", "save_path": "arxiv"})
            result = b.call_tool("arxiv_read_paper", {"save_path": "arxiv", "paper_id": "2105.05233"})
        self.assertFalse(result.success)
        self.assertEqual(result.metadata["read_guard"], "failure_cooldown")
        a._http_client.post.assert_called_once()
        b._http_client.post.assert_not_called()

    def test_scope_session_and_arguments_do_not_cross_contaminate(self):
        client = client_with_transport({"success": False})
        with patch.dict(os.environ, {"SCIASSISTANT_DIAGNOSTICS_PATH": self.task_a}):
            client.call_tool("arxiv_read_paper", {"paper_id": "2105.05233"})
            client.call_tool("arxiv_read_paper", {"paper_id": "2105.05233", "save_path": "other"})
            client.call_tool("arxiv_read_paper", {"paper_id": "2105.05233", "pdf_parse_mode": "hybrid"})
            client._session_id = "other-session"
            client.call_tool("arxiv_read_paper", {"paper_id": "2105.05233"})
        with patch.dict(os.environ, {"SCIASSISTANT_DIAGNOSTICS_PATH": self.task_b}):
            client.call_tool("arxiv_read_paper", {"paper_id": "2105.05233"})
        self.assertEqual(client._http_client.post.call_count, 5)

    def test_cooldown_expires_and_success_is_not_cached(self):
        guard = ArxivReadGuard(cooldown=300)
        invoke = Mock(return_value=MCPClientResult(False))
        with patch("deepdiver_v2.src.arxiv_read_control.time.monotonic", return_value=0):
            guard.run("key", invoke)
            self.assertEqual(guard.run("key", invoke)[1], "failure_cooldown")
        invoke.return_value = MCPClientResult(True)
        with patch("deepdiver_v2.src.arxiv_read_control.time.monotonic", return_value=301):
            guard.run("key", invoke)
            guard.run("key", invoke)
        self.assertEqual(invoke.call_count, 3)

    def test_inflight_duplicate_does_not_execute(self):
        guard = ArxivReadGuard(join_timeout=0.01)
        started, finish = threading.Event(), threading.Event()
        def invoke():
            started.set()
            self.assertTrue(finish.wait(2))
            return MCPClientResult(True)
        with ThreadPoolExecutor(max_workers=1) as executor:
            owner = executor.submit(guard.run, "key", invoke)
            self.assertTrue(started.wait(1))
            duplicate = Mock()
            try:
                self.assertEqual(guard.run("key", duplicate), (None, "inflight"))
                duplicate.assert_not_called()
            finally:
                finish.set()
            self.assertTrue(owner.result()[0].success)

    def test_capacity_never_evicts_an_active_call(self):
        guard = ArxivReadGuard(capacity=1)
        started, finish = threading.Event(), threading.Event()
        def invoke():
            started.set()
            finish.wait(2)
            return MCPClientResult(True)
        with ThreadPoolExecutor(max_workers=1) as executor:
            owner = executor.submit(guard.run, "key", invoke)
            self.assertTrue(started.wait(1))
            try:
                self.assertEqual(guard.run("different", Mock()), (None, "capacity"))
            finally:
                finish.set()
            owner.result()

    def test_exception_releases_guard(self):
        guard = ArxivReadGuard()
        with self.assertRaises(RuntimeError):
            guard.run("key", Mock(side_effect=RuntimeError("private")))
        self.assertEqual(guard.run("key", Mock(return_value=MCPClientResult(True)))[1], "executed")

    def test_concurrent_waiter_shares_result(self):
        guard = ArxivReadGuard(join_timeout=1)
        started, release, waiting = threading.Event(), threading.Event(), threading.Event()
        def invoke():
            started.set()
            release.wait(2)
            return MCPClientResult(False)
        with ThreadPoolExecutor(max_workers=2) as executor:
            owner = executor.submit(guard.run, "key", invoke)
            self.assertTrue(started.wait(1))
            # Signal from inside Event.wait so release cannot race insertion.
            original_wait = guard._entries["key"].ready.wait
            def wait(timeout):
                waiting.set()
                return original_wait(timeout)
            with patch.object(guard._entries["key"].ready, "wait", side_effect=wait):
                duplicate_invoke = Mock()
                waiter = executor.submit(guard.run, "key", duplicate_invoke)
                self.assertTrue(waiting.wait(1))
                release.set()
                self.assertEqual(waiter.result()[1], "shared_result")
                duplicate_invoke.assert_not_called()
            owner.result()

    def test_failure_and_phase_events_are_safe_and_not_replayed(self):
        payload = {"success": False, "error": "private-token C:/private/file",
                   "metadata": {"read_diagnostics": [
                       {"phase": "http_download", "status": "failed", "elapsed_ms": 90000},
                       {"phase": "private-token", "elapsed_ms": 1},
                       {"phase": ["malformed"], "elapsed_ms": 1},
                       {"phase": "pdf_parse", "elapsed_ms": "private"}]}}
        client = client_with_transport(payload)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "events.jsonl"
            with patch.dict(os.environ, {"SCIASSISTANT_DIAGNOSTICS_PATH": str(path)}):
                client.call_tool("arxiv_read_paper", {"paper_id": "2105.05233", "save_path": "C:/private/file"})
                client.call_tool("arxiv_read_paper", {"paper_id": "2105.05233", "save_path": "C:/private/file"})
            text = path.read_text(encoding="utf-8")
            self.assertNotIn("private", text)
            events = web_app._read_diagnostic_events(path)
            ends = [e for e in events if e["stage"] == "arxiv_fulltext_read" and e["status"] == "failed"]
            self.assertEqual(len(ends), 2)
            self.assertTrue(all(e["business_success"] is False and len(e["call_id"]) == 32 for e in ends))
            self.assertEqual(ends[-1]["read_guard"], "failure_cooldown")
            self.assertEqual(len([e for e in events if e["stage"] == "arxiv_read:http_download"]), 1)
            self.assertEqual(web_app._merge_diagnostic_events(events, path), events)

    def test_trace_failure_contains_type_not_exception_body(self):
        trace = ReadTrace()
        with self.assertRaises(TimeoutError):
            with trace.phase("http_download"):
                raise TimeoutError("private-token")
        self.assertEqual(trace.events[0]["status"], "failed")
        self.assertEqual(trace.events[0]["error_type"], "TimeoutError")
        self.assertNotIn("private-token", json.dumps(trace.events))

    def test_tool_acquire_failure_returns_phase_metadata(self):
        tools = mcp_tools.MCPTools.__new__(mcp_tools.MCPTools)
        with tempfile.TemporaryDirectory() as directory:
            tools.workspace_path = Path(directory)
            with patch.object(tools, "download_pdf", side_effect=TimeoutError("private-token")):
                result = tools.arxiv_read_paper("2105.05233")
        self.assertFalse(result.success)
        self.assertEqual(result.metadata["read_diagnostics"][0]["phase"], "pdf_acquire")
        self.assertNotIn("private-token", json.dumps(result.to_dict()))

    def test_parser_business_failure_is_a_failed_phase(self):
        tools = mcp_tools.MCPTools.__new__(mcp_tools.MCPTools)
        with tempfile.TemporaryDirectory() as directory:
            tools.workspace_path = Path(directory)
            with patch.object(tools, "download_pdf", return_value=str(Path(directory) / "dummy.pdf")), patch("pdf_pipeline.parse_pdf", return_value={"success": False, "error": "Invalid PDF"}):
                result = tools.arxiv_read_paper("2105.05233")
        self.assertFalse(result.success)
        phase = result.metadata["read_diagnostics"][-1]
        self.assertEqual(phase["phase"], "pdf_parse")
        self.assertEqual(phase["status"], "failed")
        self.assertEqual(phase["error_type"], "ParseResultFailure")

    def test_unlocked_existing_lock_and_cache_work_without_deletion(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            target = root / "2105.05233.pdf"
            target.write_bytes(b"%PDF-1.4\n%%EOF")
            lock = root / "2105.05233.pdf.download.lock"
            lock.write_bytes(b"0")
            trace = ReadTrace()
            request = Mock(side_effect=AssertionError("no HTTP on cache hit"))
            result = pdf.download_arxiv_pdf("2105.05233", root,
                reserve_request=Mock(), network_cooldown=Mock(), rate_limit_cooldown=Mock(),
                request_get=request, trace=trace)
            self.assertEqual(result, str(target))
            self.assertTrue(lock.exists())
            self.assertEqual([e["phase"] for e in trace.events], ["download_lock", "cache_check"])

    def test_pacing_timeout_is_distinct_from_network_wait(self):
        with tempfile.TemporaryDirectory() as directory:
            trace = ReadTrace()
            with self.assertRaises(TimeoutError):
                pdf.download_arxiv_pdf("2105.05233", Path(directory),
                    reserve_request=Mock(side_effect=TimeoutError("private")),
                    network_cooldown=Mock(), rate_limit_cooldown=Mock(), trace=trace)
            self.assertEqual(trace.events[-1]["phase"], "request_pacing")
            self.assertEqual(trace.events[-1]["status"], "failed")
            self.assertNotIn("http_download", [e["phase"] for e in trace.events])
