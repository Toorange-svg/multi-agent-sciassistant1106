"""Report planning/binding is observable but is never semantic auto-approval."""
from copy import deepcopy
import json
from pathlib import Path

import pytest

from multi_agent_sections import (SECTION_DRAFT_SCHEMA, SECTION_POLICY, report_outline, section_dossiers,
    writer_jobs, writer_job_evidence, writer_job_issues, merge_writer_batches, revision_job,
    writer_result_issues, project_writer_job)
from multi_agent_report_contracts import compile_user_requirements
from multi_agent_report_contracts import REPORT_PLAN_SCHEMA, requirement_plan_issues, plan_term_limit
from multi_agent_pipeline_v2 import (LiteraturePipelineV2, DeterministicLiteratureExecutor,
    render_claims, check_draft)
from multi_agent_quality import claim_scope, citation_audit_input, publication_rejections, check_audit
from multi_agent_agents import ArtifactDirectory, AgentWorker
from multi_agent_workflow import WorkflowStore
from tests.test_multi_agent_report_requirements import CASES, plan_for_case
from tools.multi_agent_cli import _mock_agents, _mock_search


def composition(case=CASES[0]):
    plan = plan_for_case(case)
    ledger = compile_user_requirements(case['question'], plan)
    outline = report_outline(ledger, plan)
    evidence = {'schema_version': 'sciassistant.evidence-set/v1', 'evidence': [
        {'evidence_id': 'e1', 'review_status': 'approved', 'reviewed_group_ids': ['g1'],
         'group_id': 'g1', 'paper_id': '1', 'excerpt': 'Original excerpt, unchanged, with result 12.3.',
         'locator': {'page': 3, 'bbox': [1, 2, 3, 4], 'table_id': 'table-1'},
         'coverage_scope': 'selected_chunks', 'evidence_strength': 'fulltext_located'}]}
    dossiers = section_dossiers(outline, evidence, {'coverage': []})
    return outline, dossiers, evidence


def good_draft(job):
    claims = [{'claim_id': f'c{i+1}', 'text': '原文支持的受控测试描述。', 'scope_note': '仅用于流程测试。',
        'qualification': '完整实验条件仍须独立审计。', 'claim_type': 'technical', 'confidence': 'low',
        'report_section_id': s['section_id'], 'section': s['role'], 'group_id': 'g1',
        'requirement_ids': list(s['requirement_ids']), 'evidence_ids': [job['allowed_evidence_ids'][0]],
        'depends_on_claim_ids': []} for i,s in enumerate(job['sections']) if s['requirement_ids']]
    return {'schema_version': SECTION_DRAFT_SCHEMA, 'direct_answer': '未经审计的草稿说明不得代替正文。',
        'claims': claims, 'requirement_results': [{'requirement_id': k, 'status': 'answered',
            'claim_ids': [c['claim_id'] for c in claims if k in c['requirement_ids']], 'reason': '草稿自报，非发布通过'}
            for k in job['requirement_ids']]}


@pytest.mark.parametrize('case', CASES, ids=lambda c:c['case_id'])
def test_every_literal_ask_in_outline_or_explicit_guidance_no_four_item_cutoff(case):
    outline, dossiers, evidence = composition(case)
    all_ids = {r['requirement_id'] for r in outline['requirements']}
    assert all_ids == set(outline['guidance_requirement_ids']) | {
        r for s in outline['sections'] for r in s['requirement_ids']}
    assert [r['question_quote'] for r in outline['requirements']] == [r['question_quote'] for r in case['requirements']]
    assert not outline['semantic_auto_approval'] and not outline['publication_coverage_verified']
    for profile in ('standard', 'enhanced'):
        jobs = writer_jobs(outline, dossiers, profile, 10 if profile == 'standard' else 20)
        assert [s for j in jobs for s in j['section_ids']] == [s['section_id'] for s in outline['sections']]
        assert len(jobs) <= (1 if profile == 'standard' else 4)
        assert all(not writer_job_issues(good_draft(j), j) for j in jobs)


def test_dossier_preserves_exact_original_excerpts_locators_and_hash_inputs():
    outline, dossiers, source = composition()
    before = deepcopy(source)
    assert all(d['evidence'] == source['evidence'] for d in dossiers['dossiers'])
    assert not dossiers['excerpts_summarized_or_truncated']
    dossiers['dossiers'][0]['evidence'][0]['locator']['page'] = 123
    assert source == before


@pytest.mark.parametrize('fault', ['unapproved', 'duplicate'])
def test_unapproved_or_duplicate_sources_do_not_enter_dossier(fault):
    outline, dossiers, evidence = composition()
    if fault == 'unapproved':
        evidence['evidence'][0]['review_status'] = 'rejected'
    else:
        evidence['evidence'].append(deepcopy(evidence['evidence'][0]))
    with pytest.raises(ValueError):
        section_dossiers(outline, evidence, {'coverage': []})


def test_reviewed_association_not_original_search_group_decides_material_bucket():
    outline, dossiers, evidence = composition()
    evidence['evidence'][0]['reviewed_group_ids'] = ['g2']
    result = section_dossiers(outline, evidence, {'coverage': []})
    assert all(d['evidence'] == [] for d in result['dossiers'])
    assert all(d['missing_source'] for d in result['dossiers'])


@pytest.mark.parametrize('remaining', [2, 3, 4, 5, 7, 10, 20])
def test_job_admission_always_reserves_audit_and_never_drops_later_sections(remaining):
    outline, dossiers, evidence = composition()
    sections = outline['sections']
    # Many section jobs are a controlled delivery-partition case, not word/claim targets.
    outline['sections'] = [{**deepcopy(sections[0]), 'section_id': f's{i}'} for i in range(10)]
    dossiers['dossiers'] = [{**deepcopy(dossiers['dossiers'][0]), 'section_id': f's{i}'} for i in range(10)]
    jobs = writer_jobs(outline, dossiers, 'enhanced', remaining)
    assert 1 <= len(jobs) <= 4 and len(jobs) + 1 <= remaining
    assert [s for j in jobs for s in j['section_ids']] == [f's{i}' for i in range(10)]


@pytest.mark.parametrize('remaining', [0, 1, True, 20.5])
def test_no_unauditable_new_job(remaining):
    outline, dossiers, _ = composition()
    with pytest.raises(ValueError):
        writer_jobs(outline, dossiers, 'enhanced', remaining)


@pytest.mark.parametrize('fault', ['old_schema', 'unknown_requirement', 'foreign_section', 'wrong_role',
    'unapproved_citation', 'cross_batch_dependency', 'missing_result', 'duplicate_result', 'foreign_result',
    'false_answered', 'bad_status', 'duplicate_claim', 'empty_text', 'bad_scope', 'unknown_group'])
def test_invalid_bindings_results_or_sources_not_recovered_as_approval(fault):
    outline, dossiers, _ = composition()
    job = writer_jobs(outline, dossiers, 'standard', 10)[0]
    draft = good_draft(job)
    c = draft['claims'][0]
    if fault == 'old_schema': draft['schema_version'] = 'sciassistant.claim-draft/v2'
    elif fault == 'unknown_requirement': c['requirement_ids'] = ['req-forged']
    elif fault == 'foreign_section': c['report_section_id'] = 'not-assigned'
    elif fault == 'wrong_role': c['section'] = 'not-a-role'
    elif fault == 'unapproved_citation': c['evidence_ids'] = ['foreign']
    elif fault == 'cross_batch_dependency': c['depends_on_claim_ids'] = ['foreign-c1']
    elif fault == 'missing_result': draft['requirement_results'].pop()
    elif fault == 'duplicate_result': draft['requirement_results'].append(deepcopy(draft['requirement_results'][0]))
    elif fault == 'foreign_result': draft['requirement_results'][0]['requirement_id'] = 'req-forged'
    elif fault == 'false_answered': draft['requirement_results'][0]['claim_ids'] = []
    elif fault == 'bad_status': draft['requirement_results'][0]['status'] = {}
    elif fault == 'duplicate_claim': draft['claims'].append(deepcopy(c))
    elif fault == 'empty_text': c['text'] = ''
    elif fault == 'bad_scope': c['scope_note'] = None
    elif fault == 'unknown_group': c['group_id'] = 'g-forged'
    if fault in {'missing_result', 'duplicate_result', 'foreign_result', 'false_answered', 'bad_status'}:
        assert writer_result_issues(draft, job)
        assert not writer_job_issues(draft, job)
        projected = project_writer_job(draft, job)
        assert projected['requirement_result_diagnostics'] and projected['requirement_results'] == []
        merged = merge_writer_batches(outline, [(job, projected, 'raw1')])
        assert merged['claims'] and all(r['status'] == 'unassessed' for r in merged['requirement_results'])
    else:
        assert writer_job_issues(draft, job)
        with pytest.raises(ValueError, match='CANNOT_MERGE'):
            merge_writer_batches(outline, [(job, draft, 'raw1')])


def test_self_report_can_be_false_semantically_without_binding_error():
    outline, dossiers, _ = composition()
    job = writer_jobs(outline, dossiers, 'standard', 10)[0]
    draft = good_draft(job)
    draft['claims'][0]['text'] = '完全没有回答被绑定的问题。'
    assert not writer_job_issues(draft, job)
    # This retained counterexample is exactly why batch 5 must inspect actual
    # post-audit answers, not trust requirement_results or counts.
    merged = merge_writer_batches(outline, [(job, draft, 'raw1')])
    assert merged['draft_self_reports_not_publication_coverage']


def test_merge_remaps_only_ids_and_dependencies_not_text_or_source():
    outline, dossiers, evidence = composition()
    jobs = writer_jobs(outline, dossiers, 'enhanced', 20)
    batches = [(j, good_draft(j), f'raw-{i}') for i,j in enumerate(jobs)]
    merged = merge_writer_batches(outline, batches)
    assert len({c['claim_id'] for c in merged['claims']}) == len(merged['claims'])
    assert not writer_job_issues(merged, revision_job(outline, evidence))
    assert all(c['text'] == '原文支持的受控测试描述。' for c in merged['claims'])
    assert all(c['claim_id'].startswith('b') for c in merged['claims'])
    assert claim_scope(merged, merged['claims'][0]) == '仅用于流程测试。'
    audit_input = citation_audit_input(merged, evidence)
    assert audit_input['claims'][0]['visible_fields']['scope_field'] == 'scope_note'
    assert audit_input['claims'][0]['hidden_review_detail'] == '完整实验条件仍须独立审计。'
    assert audit_input['claims'][0]['requirement_ids'] == merged['claims'][0]['requirement_ids']


def test_render_keeps_order_and_empty_isolated_section_not_unaudited_direct_answer():
    outline, dossiers, evidence = composition()
    jobs = writer_jobs(outline, dossiers, 'enhanced', 20)
    merged = merge_writer_batches(outline, [(j, good_draft(j), f'raw-{i}') for i,j in enumerate(jobs)])
    blocked = {c['claim_id'] for c in merged['claims'] if c['report_section_id'] == outline['sections'][-1]['section_id']}
    text = render_claims(merged, evidence, rejected=blocked)
    positions = [text.index('### ' + s['title']) for s in outline['sections']]
    assert positions == sorted(positions)
    assert '本节尚未形成通过审查' in text
    assert '未经审计的草稿说明' not in text


def test_empty_source_requirement_can_be_unanswered_but_not_falsely_supported():
    outline, dossiers, _ = composition()
    job = writer_jobs(outline, dossiers, 'standard', 10)[0]
    job['allowed_evidence_ids'] = []
    draft = {'schema_version': SECTION_DRAFT_SCHEMA, 'direct_answer': '暂无草稿', 'claims': [],
        'requirement_results': [{'requirement_id': k, 'status': 'unanswered', 'claim_ids': [], 'reason': '本批无已批准来源'}
            for k in job['requirement_ids']]}
    assert not writer_job_issues(draft, job)
    draft['requirement_results'][0]['status'] = 'answered'
    assert writer_result_issues(draft, job)


def test_subset_job_cannot_receive_foreign_approved_source():
    outline, dossiers, _ = composition()
    job = writer_jobs(outline, dossiers, 'standard', 10)[0]
    subset = writer_job_evidence(job, dossiers)
    assert [e['evidence_id'] for e in subset['evidence']] == ['e1']
    job['allowed_evidence_ids'].append('unknown')
    with pytest.raises(ValueError, match='SOURCE_MISSING'):
        writer_job_evidence(job, dossiers)


@pytest.mark.parametrize('profile', ['standard', 'enhanced'])
def test_workflow_mock_uses_real_section_jobs_and_exports_stable_metadata(tmp_path, profile):
    workers = _mock_agents()
    store = WorkflowStore(tmp_path / 'workflow.sqlite3')
    artifacts = ArtifactDirectory(tmp_path / 'artifacts')
    flow = LiteraturePipelineV2(store, artifacts, workers, DeterministicLiteratureExecutor(_mock_search),
        event_path=tmp_path / 'events.jsonl', report_profile=profile)
    result = flow.run('sections', 'owner', '请解释A。请比较A和B。')
    final = artifacts.get(result['final_artifact_id'])
    assert result['run']['status'] == 'partial', result
    outline = artifacts.get(final['artifact_refs']['report_outline'])
    writing = artifacts.get(final['artifact_refs']['section_writing'])
    draft = artifacts.get(final['artifact_refs']['draft'])
    assert all(b['status'] == 'completed' for b in writing['batches'])
    assert len(writing['batches']) == 1
    assert draft['composition_policy'] == SECTION_POLICY
    assert not draft['draft_requirement_observations'][0].get('semantic_support_verified', False)
    assert len(draft['claims']) == 2 and result['run']['model_calls_used'] == 5
    assert '### 直接回答' in final['direct_answer']


def test_failed_later_batch_preserves_prior_draft_but_still_requires_audit(tmp_path):
    workers = _mock_agents()
    original_planner = workers.planner.handler
    def planner(packet):
        output = original_planner(packet)
        rows = output['output']['user_requirements']
        rows[-1]['answer_kind'] = 'proposal'
        return output
    workers.planner.handler = planner
    original_writer = workers.writer.handler
    def writer(packet):
        job = next(i['payload'] for i in packet['inputs'] if i['payload'].get('schema_version') == 'sciassistant.writer-job/v1')
        if job['job_id'] == 'b2':
            return {'status': 'failed', 'error_code': 'MODEL_JSON_INVALID'}
        return original_writer(packet)
    workers.writer.handler = writer
    store, artifacts = WorkflowStore(tmp_path/'workflow.sqlite3'), ArtifactDirectory(tmp_path/'artifacts')
    flow = LiteraturePipelineV2(store, artifacts, workers, DeterministicLiteratureExecutor(_mock_search),
        report_profile='enhanced', event_path=tmp_path/'events.jsonl')
    result = flow.run('sections', 'owner', '请解释A。请给出实验方案。')
    final = artifacts.get(result['final_artifact_id'])
    assert result['run']['status'] == 'needs_review', result
    draft = artifacts.get(final['artifact_refs']['draft'])
    assert draft['claims'] and all(c['claim_id'].startswith('b1-') for c in draft['claims'])
    assert final['artifact_refs'].get('audit')
    writing = artifacts.get(final['artifact_refs']['section_writing'])
    assert writing['batches'][1]['status'] == 'rejected_output'
    assert '本节尚未形成通过审查' in final['direct_answer']


@pytest.mark.parametrize('kind', ['constraint', 'report_structure', 'mechanism', 'proposal'])
def test_global_guidance_is_not_a_new_search_or_falsely_completed_question(kind):
    case = CASES[0]
    plan = plan_for_case(case)
    row = plan['user_requirements'][0]
    row.update(answer_kind=kind, research_group_ids=[], report_obligation_ids=[])
    errors = requirement_plan_issues(plan, case['question'])
    if kind in {'constraint', 'report_structure'}:
        assert not errors
        ledger = compile_user_requirements(case['question'], plan)
        outline = report_outline(ledger, plan)
        assert ledger['requirements'][0]['requirement_id'] in outline['guidance_requirement_ids']
        assert ledger['requirements'][0]['status'] == 'planned'
        plan['schema_version'] = 'sciassistant.research-plan/v6'
        assert any(e['reason'] == 'REQUIREMENT_HAS_NO_PLANNED_DELIVERY' for e in requirement_plan_issues(plan, case['question']))
    else:
        assert any(e['reason'] == 'REQUIREMENT_HAS_NO_PLANNED_DELIVERY' for e in errors)


@pytest.mark.parametrize('schema', ['sciassistant.research-plan/v4', 'sciassistant.research-plan/v5',
    'sciassistant.research-plan/v6', REPORT_PLAN_SCHEMA])
def test_hint_proposal_limit_is_versioned_and_not_executable_queries(schema):
    from multi_agent_live import normalize_live_result
    from multi_agent_handoffs import compile_search_plan
    plan = plan_for_case(CASES[0])
    plan['schema_version'] = schema
    plan['groups'][0]['core'] = ['A', 'B', 'C', 'D', 'E']
    assert plan_term_limit(schema, 'core') == (8 if schema == REPORT_PLAN_SCHEMA else 4)
    if schema == REPORT_PLAN_SCHEMA:
        result = normalize_live_result('planner', {'output': plan}, require_current=True, question=CASES[0]['question'])['output']
        compiled, _ = compile_search_plan(result, 'arxiv')
        assert len(compiled['groups'][0]['queries']) <= 2
        assert compiled['groups'][0]['core'] == plan['groups'][0]['core']
    else:
        from multi_agent_agents import AgentContractError
        with pytest.raises(AgentContractError):
            normalize_live_result('planner', {'output': plan})


def test_current_missing_schema_is_stamped_before_literal_segment_projection():
    from multi_agent_live import normalize_live_result
    plan = plan_for_case(CASES[0])
    del plan['schema_version']
    plan['segment_dispositions'] = {'s999': ['u1']}
    result = normalize_live_result('planner', {'output': plan}, require_current=True, question=CASES[0]['question'])['output']
    assert result['schema_version'] == REPORT_PLAN_SCHEMA
    assert not requirement_plan_issues(result, CASES[0]['question'])
    assert result['segment_mapping']['unknown_proposed_segment_ids'] == ['s999']


def test_actual_dependency_ids_are_namespaced_and_cycles_still_blocked():
    outline, dossiers, evidence = composition()
    job = writer_jobs(outline, dossiers, 'standard', 10)[0]
    draft = good_draft(job)
    assert len(draft['claims']) >= 2
    draft['claims'][1]['depends_on_claim_ids'] = ['c1']
    merged = merge_writer_batches(outline, [(job, draft, 'original')])
    assert merged['claims'][1]['depends_on_claim_ids'] == ['b1-c1']
    assert draft['claims'][1]['depends_on_claim_ids'] == ['c1']
    merged['claims'][0]['depends_on_claim_ids'] = ['b1-c2']
    assert any(r['reason'] == 'INVALID_CLAIM_DEPENDENCY' for r in check_draft(merged, evidence))


@pytest.mark.parametrize('name', ['report_outline', 'section_evidence', 'writer_jobs', 'section_writing', 'report_composition'])
def test_replay_detects_tampering_with_new_composition_export(tmp_path, name):
    from tools.multi_agent_cli import _replay_matches
    source, target = tmp_path/'source', tmp_path/'target'
    source.mkdir(); target.mkdir()
    artifacts = ArtifactDirectory(source/'artifacts')
    ref = artifacts.put('proof', {'schema_version': 'test/v1'})['artifact_id']
    final = artifacts.put('final-result', {'artifact_refs': {name: ref}})['artifact_id']
    (source/'manifest.json').write_text(json.dumps({'final_artifact_id': final}), encoding='utf-8')
    for file in ('final_answer.md', 'final_answer.html', 'references.json', 'claim_evidence_map.json', 'citation_audit.json', name+'.json'):
        (source/file).write_text('{}', encoding='utf-8')
        (target/file).write_text('{}', encoding='utf-8')
    assert all(_replay_matches(source, target).values())
    (source/(name+'.json')).write_text('{"tampered":true}', encoding='utf-8')
    checked = _replay_matches(source, target)
    assert checked[name+'.json'] is False and checked['final_answer.md']


def test_existing_aggregate_audit_envelope_is_explicit_not_truncated(tmp_path):
    workers = _mock_agents()
    original_planner = workers.planner.handler
    def planner(packet):
        value = original_planner(packet)
        value['output']['user_requirements'][-1]['answer_kind'] = 'proposal'
        return value
    workers.planner.handler = planner
    original_writer = workers.writer.handler
    def writer(packet):
        output = original_writer(packet)
        base = output['output']['claims'][0]
        job = next(i['payload'] for i in packet['inputs'] if i['payload'].get('schema_version') == 'sciassistant.writer-job/v1')
        count = 41 if job['job_id'] == 'b1' else 40
        # Retain original sections/results, then append well-bound duplicate toy
        # claims solely to prove the old audit envelope is not a tail clipper.
        for index in range(len(output['output']['claims']), count):
            output['output']['claims'].append({**deepcopy(base), 'claim_id': f'extra-{index}'})
        return output
    workers.writer.handler = writer
    store, artifacts = WorkflowStore(tmp_path/'workflow.sqlite3'), ArtifactDirectory(tmp_path/'artifacts')
    flow = LiteraturePipelineV2(store, artifacts, workers, DeterministicLiteratureExecutor(_mock_search),
        report_profile='enhanced', event_path=tmp_path/'events.jsonl')
    result = flow.run('large', 'owner', '解释A。提出实验方案。')
    assert result['run']['failure_code'] == 'REPORT_AGGREGATE_CAPACITY_EXCEEDED'
    final = artifacts.get(result['final_artifact_id'])
    assert len(artifacts.get(final['artifact_refs']['composed_draft'])['claims']) == 81
    assert 'audit' not in final['artifact_refs']


def test_role_label_projection_does_not_change_scientific_fields():
    outline, dossiers, _ = composition()
    job = writer_jobs(outline, dossiers, 'standard', 10)[0]
    draft = good_draft(job)
    for c in draft['claims']:
        c['section'] = c['report_section_id']  # Actual observed enum confusion.
    before = deepcopy(draft)
    fixed = project_writer_job(draft, job)
    assert not writer_job_issues(fixed, job) and fixed['section_projection']['changes']
    for old, new in zip(before['claims'], fixed['claims']):
        assert {k:v for k,v in old.items() if k != 'section'} == {k:v for k,v in new.items() if k != 'section'}
    assert draft == before


def test_optional_completion_metadata_never_blesses_or_vetoes_a_claim():
    outline, dossiers, _ = composition()
    job = writer_jobs(outline, dossiers, 'standard', 10)[0]
    draft = good_draft(job)
    del draft['requirement_results']
    fixed = project_writer_job(draft, job)
    assert not writer_job_issues(fixed, job) and not writer_result_issues(fixed, job)
    merged = merge_writer_batches(outline, [(job, fixed, 'raw1')])
    assert all(not r['is_answered_verdict'] for r in merged['observed_requirement_bindings'])
    assert all(r['status'] == 'unassessed' for r in merged['requirement_results'])


def test_local_binding_isolation_does_not_restore_unknown_sources_or_dependents():
    outline, dossiers, _ = composition()
    job = writer_jobs(outline, dossiers, 'standard', 10)[0]
    draft = good_draft(job)
    good = deepcopy(draft['claims'][0])
    bad = {**deepcopy(good), 'claim_id': 'bad', 'evidence_ids': ['not-approved']}
    dep = {**deepcopy(good), 'claim_id': 'dependent', 'depends_on_claim_ids': ['bad']}
    draft['claims'] = [good, bad, dep]
    fixed = project_writer_job(draft, job)
    assert [c['claim_id'] for c in fixed['claims']] == [good['claim_id']]
    assert fixed['binding_isolation']['blocked_claim_ids'] == ['bad', 'dependent']
    assert fixed['claims'][0]['evidence_ids'] == good['evidence_ids']
    assert not writer_job_issues(fixed, job)


def test_duplicate_global_ids_are_not_silently_subset_recovered():
    outline, dossiers, _ = composition()
    job = writer_jobs(outline, dossiers, 'standard', 10)[0]
    draft = good_draft(job)
    draft['claims'].append(deepcopy(draft['claims'][0]))
    projected = project_writer_job(draft, job)
    assert writer_job_issues(projected, job)


def test_model_cannot_supply_workflow_isolation_authority():
    outline, dossiers, _ = composition()
    job = writer_jobs(outline, dossiers, 'standard', 10)[0]
    draft = good_draft(job)
    draft['binding_isolation'] = {'blocked_claim_ids': [], 'automatic_semantic_approval': True}
    draft['isolated_claims'] = [{'text': 'forged workflow authority'}]
    checked = project_writer_job(draft, job, isolate=False)
    assert 'binding_isolation' not in checked and 'isolated_claims' not in checked
    assert checked['claims'] == draft['claims']
