"""Copy hazards guide the Auditor; they never make nonliteral quotes valid."""
from copy import deepcopy

import pytest

from multi_agent_quality import (WITNESS_COPY_POLICY, WITNESS_CAPACITY_POLICY, WITNESS_CHOICE_POLICY,
    SHORT_CHOICE_POLICY, AUDIT_QUOTE_MENU_POLICY, source_copy_brief,
    initial_audit_witness_options, citation_audit_input, check_audit,
    publication_rejections, resolve_witness_choices, answer_requirements, answer_focus_brief)
from test_multi_agent_report_fields import draft, evidence, audit


SOURCE = 'Despite this innovation, DETR suffers from slow convergence and high memory overhead.'


def inputs(text='De-\n\nspite this innovation, DETR suffers from slow convergence and high memory overhead.'):
    data, sources = draft(), evidence()
    data.update(witness_copy_policy=WITNESS_COPY_POLICY, witness_choice_policy=WITNESS_CHOICE_POLICY,
        short_choice_policy=SHORT_CHOICE_POLICY, audit_quote_menu_policy=AUDIT_QUOTE_MENU_POLICY)
    sources['evidence'][0]['excerpt'] = text
    value = audit(data)
    value['claim_results'][0]['source_witnesses'][0]['quote'] = SOURCE
    return data, sources, value


@pytest.mark.parametrize('wrap', ['-\n', '-\n\n', '-\r\n', '- \n  '])
def test_rejoined_english_word_is_diagnosed_but_still_rejected(wrap):
    data, sources, raw = inputs('De' + wrap + 'spite' + SOURCE[len('Despite'):])
    before = deepcopy((data, sources, raw))
    checked = check_audit(raw, data, sources)
    issue = checked['witness_issues'][0]
    assert issue['reason'] == 'AUDIT_WITNESS_NOT_IN_SOURCE'
    assert issue['copy_difference'] == 'line_wrap_hyphen_removed'
    assert issue['automatic_text_repair'] is False
    assert publication_rejections(checked, data) == {'c1'}
    assert (data, sources, raw) == before


def test_literal_choice_preserves_hyphen_and_requires_explicit_model_selection():
    data, sources, raw = inputs()
    menu = initial_audit_witness_options(data, sources)
    brief = source_copy_brief(data, sources, menu)
    assert brief['records'][0]['available_choices']
    assert not brief['semantic_auto_approval'] and not brief['automatic_text_repair']
    # Merely constructing the brief does not fix the original raw quotation.
    assert publication_rejections(check_audit(raw, data, sources), data) == {'c1'}
    option = menu['options'][0]
    raw['claim_results'][0]['source_witnesses'] = [
        {'evidence_id': 'e1', 'choice_label': option['choice_label']}]
    selected, receipt = resolve_witness_choices(raw, menu, data, sources)
    assert len(receipt['resolutions']) == 1
    assert selected['claim_results'][0]['source_witnesses'][0]['quote'] == option['quote']
    assert 'De-\n\nspite' in option['quote']
    assert not check_audit(selected, data, sources)['witness_issues']


@pytest.mark.parametrize('case', ['unapproved', 'not_cited', 'unknown'])
def test_hazard_information_never_expands_approved_or_claim_citations(case):
    data, sources, raw = inputs()
    if case == 'unapproved': sources['evidence'][0]['review_status'] = 'rejected'
    if case == 'not_cited': data['claims'][0]['evidence_ids'] = ['e2']
    if case == 'unknown': sources['evidence'][0]['evidence_id'] = 'unknown'
    assert not source_copy_brief(data, sources, {'options': []})['records']
    checked = check_audit(raw, data, sources)
    assert publication_rejections(checked, data) == {'c1'}
    assert all('copy_difference' not in r for r in checked['witness_issues'])


@pytest.mark.parametrize('text', [SOURCE, 'A hyphen-separated term remains intact.',
    'The range is 20-\n30 percent, not a broken English word.'])
def test_ordinary_punctuation_and_numeric_ranges_are_not_word_wrap_hazards(text):
    data, sources, _ = inputs(text)
    assert not source_copy_brief(data, sources, {'options': []})['records']


def test_hazard_brief_is_new_policy_only_and_retains_exact_offsets():
    data, sources, _ = inputs()
    before = deepcopy((data, sources))
    packet = citation_audit_input(data, sources)
    row = packet['source_copy_brief']['records'][0]
    for hazard in row['hazards']:
        assert hazard['literal'] == sources['evidence'][0]['excerpt'][hazard['start_char']:hazard['end_char']]
    assert (data, sources) == before
    data.pop('witness_copy_policy')
    assert 'source_copy_brief' not in citation_audit_input(data, sources)


def test_hazards_are_bounded_without_discarding_approved_sources():
    data, sources, _ = inputs()
    data['claims'] = [{**deepcopy(data['claims'][0]), 'claim_id': f'c{i}'} for i in range(30)]
    before = deepcopy((data, sources))
    brief = source_copy_brief(data, sources, {'options': []})
    assert len(brief['records']) == 24 and brief['records_omitted'] == 6
    assert (data, sources) == before


@pytest.mark.parametrize('question', ['ViT 对 AI 生成图片的检测有什么帮助？',
    'DETR 对 AI 生成图片的检测有什么帮助？'])
def test_utility_metric_guidance_is_per_group_not_an_automatic_verdict(question):
    requirements = answer_requirements(question)
    plan = {'groups': [{'id': 'g1', 'question': question, 'metrics': ['definition', 'role', 'relation', 'other']}]}
    before = deepcopy((requirements, plan))
    brief = answer_focus_brief(requirements, plan)
    assert [r['metric'] for r in brief['metric_guidance']] == ['definition', 'role', 'relation']
    assert all(r['group_id'] == 'g1' for r in brief['metric_guidance'])
    assert not brief['evidence_auto_approval'] and not brief['automatic_claim_removal']
    assert (requirements, plan) == before


@pytest.mark.parametrize('question', ['ViT 比 CNN 的准确率高多少？给出统一实验比较。',
    '请推导注意力公式并说明各变量的正式定义。', 'ViT 有什么帮助？请给出它的正式定义。'])
def test_quantitative_or_formula_requests_do_not_get_ordinary_utility_exemption(question):
    requirements = answer_requirements(question)
    plan = {'groups': [{'id': 'g1', 'metrics': ['definition', 'role']}]}
    assert not answer_focus_brief(requirements, plan)['metric_guidance']


@pytest.mark.parametrize('enabled', [False, True])
@pytest.mark.parametrize('size', [350, 351, 372, 600, 601])
def test_witness_capacity_is_versioned_full_literal_and_never_truncated(enabled, size):
    data, sources, raw = inputs('A' * size)
    if enabled:
        data['witness_capacity_policy'] = WITNESS_CAPACITY_POLICY
    raw['claim_results'][0]['source_witnesses'][0]['quote'] = 'A' * size
    before = deepcopy((data, sources, raw))
    checked = check_audit(raw, data, sources)
    expected_cap = 600 if enabled else 350
    assert citation_audit_input(data, sources)['witness_limits']['max_characters'] == expected_cap
    assert bool(checked['witness_issues']) == (size > expected_cap)
    assert (data, sources, raw) == before


@pytest.mark.parametrize('fault', ['changed_number', 'wrong_source', 'joined_sentences'])
def test_more_quote_capacity_does_not_approve_provenance_errors(fault):
    literal = 'The reported quantity is 20 percent. ' * 12
    data, sources, raw = inputs(literal)
    data['witness_capacity_policy'] = WITNESS_CAPACITY_POLICY
    quote = literal.replace('20', '30') if fault == 'changed_number' else literal
    if fault == 'wrong_source': raw['claim_results'][0]['source_witnesses'][0]['evidence_id'] = 'wrong'
    if fault == 'joined_sentences': quote = literal[:25] + ' invented joining text ' + literal[-60:]
    raw['claim_results'][0]['source_witnesses'][0]['quote'] = quote
    checked = check_audit(raw, data, sources)
    assert checked['witness_issues'] and publication_rejections(checked, data) == {'c1'}


def test_actual_workflow_delivers_hazard_to_auditor_without_new_call(tmp_path):
    from test_multi_agent_pipeline_v2 import agents, pipeline
    configured, calls = agents()
    data, _, _ = inputs()
    data['claims'][0]['evidence_ids'] = ['arxiv-1']
    def writer(_):
        calls.append('writer')
        return {'output': data}
    def auditor(packet):
        calls.append('citation_auditor')
        given = next(i['payload'] for i in packet['inputs']
            if i['payload'].get('schema_version') == 'sciassistant.citation-audit-input/v1')
        row = given['source_copy_brief']['records'][0]
        assert row['claim_id'] == 'c1' and row['evidence_id'] == 'arxiv-1'
        option = next(o for o in given['source_witness_options']['options'] if o['claim_id'] == 'c1')
        result = audit(data)
        result['claim_results'][0]['source_witnesses'] = [
            {'evidence_id': 'arxiv-1', 'choice_label': option['choice_label']}]
        return {'output': result}
    configured.writer.handler, configured.citation_auditor.handler = writer, auditor
    source = 'De-\n\nspite this innovation, DETR suffers from slow convergence and high memory overhead.'
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {'status': 'ok', 'papers': [
        {'paper_id': '1', 'title': 'Method', 'abstract': source}]})
    result = flow.run('copy-hazard', 'owner', 'Explain the method')
    assert result['run']['status'] == 'completed'
    assert result['run']['model_calls_used'] == 5
    assert calls.count('citation_auditor') == calls.count('writer') == 1
