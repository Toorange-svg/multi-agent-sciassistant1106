"""Literal source inventories and type contradictions, not semantic auto-pass."""
from copy import deepcopy
from dataclasses import replace

import pytest

from multi_agent_quality import (SOURCE_ROLE_INVENTORY_POLICY, REPORT_FIELDS,
    source_role_inventory, source_boundary_brief, citation_audit_input,
    check_printed_type_denials, check_claim_revision, check_audit, publication_rejections)
from multi_agent_pipeline_v2 import check_draft
from test_multi_agent_report_fields import draft, evidence, audit

SOURCE = ('Double Quantization treats quantization constants cFP32 2 of the first quantization '
          'as inputs to a second quantization. This second step yields the quantized '
          'quantization constants cFP8 2 and the second level of quantization constants cFP32 1.')
BAD = '所选片段未提供 c1 的存储数据类型，也未提供完整反量化公式。'
GOOD = '所选片段明确标为 cFP32_1；具体数值和完整反量化流程不据此推断。'


def inputs(text=BAD):
    data, sources = draft(), evidence()
    data['source_role_inventory_policy'] = SOURCE_ROLE_INVENTORY_POLICY
    data['claims'][0].update(text=text, scope_note='', qualification='仅所引片段。')
    sources['evidence'][0]['excerpt'] = SOURCE
    return data, sources


def test_inventory_preserves_both_coordinated_outputs_with_exact_positions():
    data, sources = inputs()
    before = deepcopy((data, sources))
    value = source_role_inventory(sources)
    outputs = next(r for r in value['records'] if r['coordinated_output_candidates'])
    assert [(r['symbol'], r['dtype']) for r in outputs['coordinated_output_candidates']] == [('c2','FP8'),('c1','FP32')]
    assert outputs['operation_clause'] == 'This second step'
    for row in value['records']:
        assert row['quote'] == SOURCE[row['start']:row['end']]
        assert not row['semantic_auto_approval']
        for symbol in row['typed_symbols']:
            assert symbol['printed'] == SOURCE[symbol['start']:symbol['end']]
    assert (data, sources) == before and not value['scientific_verdict']


@pytest.mark.parametrize('source', [SOURCE.replace('cFP32 1','sFP16_7').replace('cFP8 2','zINT8_9'),
    SOURCE.replace('cFP32 1','cFP32_1').replace('cFP8 2','cFP8_2')])
def test_symbols_and_types_read_from_text_not_fixed_qlora_answers(source):
    _, sources = inputs()
    sources['evidence'][0]['excerpt'] = source
    row = source_role_inventory(sources)['records'][0]
    assert len(row['coordinated_output_candidates']) == 2
    assert all(s['printed'] in source for s in row['typed_symbols'])


@pytest.mark.parametrize('source', ['This second step yields cFP8 2.',
    'The constants cFP8 2 and cFP32 1 are used.',
    'This operation yields broken symbols cFP32 and cFP8.',
    'This operation yields ' + 'unrelated text ' * 100 + 'cFP8 2 and cFP32 1.'])
def test_no_completed_output_set_from_dtype_only_broken_or_oversize_text(source):
    _, sources = inputs()
    sources['evidence'][0]['excerpt'] = source
    assert not any(r['coordinated_output_candidates'] for r in source_role_inventory(sources)['records'])


def test_source_inventory_is_bounded_input_not_a_report_claim_limit():
    data, sources = inputs()
    sources['evidence'][0]['excerpt'] = ' '.join('Operation yields cFP8 2 and cFP32 1.' for _ in range(30))
    data['claims'] *= 40
    value = source_role_inventory(sources)
    assert len(value['records']) == 12 and value['records_omitted'] == 18
    assert len(data['claims']) == 40


@pytest.mark.parametrize('source', [
    'We discuss a hypothetical cFP32 1.',
    'If a hypothetical operation is used, it yields cFP8 2 and cFP32 1.',
    'This operation never yields cFP8 2 and cFP32 1.',
    'This operation may yield cFP8 2 and cFP32 1.',
    'This formula mentions cFP8 2 and cFP32 1.',
])
def test_typed_notation_hypothesis_or_negation_is_not_a_positive_output_definition(source):
    data, sources = inputs()
    sources['evidence'][0]['excerpt'] = source
    assert not check_printed_type_denials(data, sources)


@pytest.mark.parametrize('field', REPORT_FIELDS)
def test_exact_field_denial_is_not_rescued_by_correct_other_field(field):
    data, sources = inputs(GOOD)
    data['claims'][0][field] = BAD
    issues = check_printed_type_denials(data, sources)
    assert len(issues) == 1 and issues[0]['field'] == field
    assert issues[0]['printed_dtype'] == 'FP32' and issues[0]['symbol'] == 'c1'
    assert not issues[0]['automatic_rewrite']
    assert any(i['reason'] == 'EXPLICIT_SYMBOL_TYPE_DENIED' for i in check_draft(data, sources))
    for w in issues[0]['source_witnesses']:
        assert w['quote'] == SOURCE[w['start']:w['end']]


@pytest.mark.parametrize('text', [GOOD, '所选片段未提供 c1 的具体数值。',
    '所选片段未提供 c1 的具体位布局。', '不能说所选片段未提供 c1 的数据类型。',
    'c1 的数据类型是 FP32，完整公式未提供。', '未提供 c8 的数据类型。',
    'c1 的具体数值未知。'])
def test_known_type_does_not_prove_values_layout_formulas_or_other_symbols(text):
    assert not check_printed_type_denials(*inputs(text))


@pytest.mark.parametrize('fault', ['legacy', 'uncited','unapproved','broken_type','conflicting','cross_paper'])
def test_no_denial_verdict_from_legacy_uncited_unapproved_or_ambiguous_facts(fault):
    data, sources = inputs()
    if fault == 'legacy': data.pop('source_role_inventory_policy')
    elif fault == 'uncited': data['claims'][0]['evidence_ids'] = ['other']
    elif fault == 'unapproved': sources['evidence'][0]['review_status'] = 'pending'
    elif fault == 'broken_type': sources['evidence'][0]['excerpt'] = 'The constants c1 FP are printed in a broken formula.'
    else:
        sources['evidence'].append({**sources['evidence'][0], 'evidence_id':'e2',
            'paper_id':'p2' if fault == 'cross_paper' else 'p1',
            'excerpt':'This operation yields cFP8 2 and cFP16 1.'})
        data['claims'][0]['evidence_ids'].append('e2')
    assert not check_printed_type_denials(data, sources)


def test_writer_sees_approved_inventory_auditor_only_claim_cited_records():
    data, sources = inputs(GOOD)
    sources['evidence'].append({**sources['evidence'][0], 'evidence_id':'e2'})
    brief = source_boundary_brief(sources)
    assert {r['evidence_id'] for r in brief['source_role_inventory']['records']} == {'e1','e2'}
    packet = citation_audit_input(data, sources)
    assert {r['evidence_id'] for r in packet['claims'][0]['source_role_records']} == {'e1'}
    assert 'existing' in packet['source_role_instructions']
    data.pop('source_role_inventory_policy')
    assert 'source_role_records' not in citation_audit_input(data, sources)['claims'][0]


def test_model_approval_cannot_override_type_conflict_or_block_independent_claim():
    data, sources = inputs()
    data['claims'].append({**data['claims'][0], 'claim_id':'c2', 'text':GOOD})
    value = audit(data)
    for row in value['claim_results']:
        row['source_witnesses'][0]['quote'] = SOURCE[:120]
    checked = check_audit(value, data, sources)
    checked['code_issues'] = check_printed_type_denials(data, sources)
    assert not checked['contract_errors']
    assert publication_rejections(checked, data) == {'c1'}
    revised = deepcopy(data)
    revised['claims'][0]['qualification'] = GOOD
    assert check_claim_revision(data, revised, {'code_issues':checked['code_issues']})['code_issues']


def test_detail_only_repair_changes_actual_field_then_requires_reaudit():
    data, sources = inputs(GOOD)
    data['claims'][0]['qualification'] = BAD
    issues = check_printed_type_denials(data, sources)
    revised = deepcopy(data)
    revised['claims'][0]['qualification'] = '原文类型已标出，具体布局不在本结论范围。'
    assert not check_printed_type_denials(revised, sources)
    assert not check_claim_revision(data, revised, {'code_issues':issues})['code_issues']


def test_formal_workflow_revises_false_type_absence_without_adding_agent(tmp_path):
    from test_multi_agent_pipeline_v2 import agents, pipeline, worker
    configured, calls = agents(partial=True)
    invoked = []
    def writer(_packet):
        calls.append('writer'); invoked.append(1)
        data, _ = inputs(BAD if len(invoked) == 1 else GOOD)
        data['claims'][0].update(evidence_ids=['arxiv-1'], confidence='low', qualification='仅所选摘要原句。')
        return {'output':data}
    configured = replace(configured, writer=worker('writer', writer, 'write_approved_claims'))
    flow, _ = pipeline(tmp_path, configured, search=lambda *_:{'status':'ok','papers':[
        {'paper_id':'1','title':'DQ','abstract':SOURCE,'landing_url':'https://arxiv.org/abs/1'}]})
    result = flow.run('types','owner','只按原文解释量化常数类型。')
    assert calls.count('writer') == calls.count('citation_auditor') == 2
    assert result['run']['model_calls_used'] == 7
    assert GOOD in result['direct_answer'] and BAD not in result['direct_answer']
