"""Audit category consistency, without lexical exemptions or automatic approvals."""
from copy import deepcopy

import pytest

from multi_agent_quality import (ABSENCE_MENU_POLICY, ABSENCE_REASON_POLICY, ABSENCE_INVENTORY_POLICY, AUDIT_PROTOCOL_POLICY,
    absence_assertion_options, resolve_absence_choices, citation_audit_input, check_audit, publication_rejections)
from test_multi_agent_report_fields import draft, evidence, QUOTE
from test_multi_agent_absence_basis import audit, absence
from test_multi_agent_pipeline_v2 import agents, pipeline


def enabled():
    value = draft()
    value.update(absence_menu_policy=ABSENCE_MENU_POLICY, absence_reason_policy=ABSENCE_REASON_POLICY,
                 audit_protocol_policy=AUDIT_PROTOCOL_POLICY)
    return value


@pytest.mark.parametrize('text', ['这是作者的解释。', '这是作者的判断，不是已测得的性能。',
    '不能把整体方法收益单独归因于架构。', '所选来源是方法描述，不是性能测量。',
    'This is author attribution, not a measured causal effect.',
    'Do not infer universal superiority from one experiment.'])
def test_menu_does_not_offer_every_negative_word_as_missing_experiment(text):
    value = enabled()
    value['claims'][0].update(text=text, scope_note='', qualification='')
    assert absence_assertion_options(value)['options'] == []
    # This is menu retrieval only, not a scientific approval of any example.
    assert not absence_assertion_options(value).get('semantic_auto_approval', False)


@pytest.mark.parametrize('text', ['论文未进行消融实验。', '所选片段未提供统一对照。',
    '作者解释了方法，但论文未报告控制实验。', 'This paper did not report any controlled comparison.',
    'No controlled experiment was reported.', 'This has not been validated.'])
def test_real_omission_candidates_remain_exact_and_auditable(text):
    value = enabled(); value['claims'][0].update(text=text, scope_note='', qualification='')
    # Non-exhaustive candidate menu: a manually quoted assertion remains valid
    # even when this English tense is not located by the narrow menu regex.
    menu = absence_assertion_options(value)
    if 'not been' not in text:
        assert menu['options']
    for row in menu['options']:
        assert row['assertion'] == text[row['start_char']:row['end_char']]


def test_mixed_field_menu_keeps_omission_sentence_not_entire_attribution_paragraph():
    value = enabled()
    value['claims'][0].update(text='这是作者解释，不是性能测量。所选片段未报告统一对照。', scope_note='', qualification='')
    rows = absence_assertion_options(value)['options']
    assert [r['assertion'] for r in rows] == ['所选片段未报告统一对照。']


def test_legacy_menu_remains_available_and_is_not_recomputed_under_new_policy():
    value = draft(); value['claims'][0].update(text='不能归因于架构。', scope_note='', qualification='')
    assert absence_assertion_options(value)['options']
    before = deepcopy(value)
    assert 'absence_menu_policy' not in value and value == before


def rejected_without_target(value):
    result = audit(value)
    row = result['claim_results'][0]
    row.update(decision='needs_review', reason_code='UNSUPPORTED_ABSENCE_SCOPE', detail='请核查缺项分类。')
    row['field_results']['qualification'].update(status='needs_review', detail='未标出具体缺项。')
    result.update(status='needs_revision', rejected_claim_ids=['c1'], issues=[
        {'claim_id': 'c1', 'reason_code': 'UNSUPPORTED_ABSENCE_SCOPE', 'detail': '需核查分类。'}])
    return result


def test_absence_reason_without_actual_field_target_is_protocol_fault_not_approval():
    value = enabled(); raw = rejected_without_target(value); before = deepcopy(raw)
    checked = check_audit(raw, value, evidence())
    assert not checked['contract_errors']
    assert checked['protocol_issues'][0]['reason'] == 'AUDIT_ABSENCE_REASON_WITHOUT_ASSERTION'
    assert publication_rejections(checked, value) == {'c1'}
    assert raw == before


def test_scope_record_on_supported_other_field_cannot_bind_failing_field_reason():
    value = enabled(); raw = rejected_without_target(value)
    raw['claim_results'][0]['field_results']['scope_note']['absence_checks'] = [
        {'assertion':value['claims'][0]['scope_note'], 'basis':'selected_excerpts', 'witness_index':None}]
    assert check_audit(raw, value, evidence())['protocol_issues']


def test_actual_unverified_omission_is_not_reclassified_or_approved():
    value = enabled(); value['claims'][0]['qualification'] = '论文未做消融。'
    raw = rejected_without_target(value)
    absence(raw, value['claims'][0]['qualification'], basis='unverified')
    checked = check_audit(raw, value, evidence())
    assert not checked['protocol_issues'] and publication_rejections(checked, value) == {'c1'}


def test_old_policy_rejection_is_not_migrated_or_published():
    value = draft(); raw = rejected_without_target(value)
    assert not check_audit(raw, value, evidence()).get('protocol_issues')
    assert publication_rejections(check_audit(raw, value, evidence()), value) == {'c1'}


def test_structured_taxonomy_input_is_not_an_assertion_of_semantic_support():
    value = enabled(); result = citation_audit_input(value, evidence())
    assert result['absence_reason_policy'] == ABSENCE_REASON_POLICY
    assert not result['assertion_classification_brief']['semantic_auto_approval']
    assert 'Author attribution' in ' '.join(result['assertion_classification_brief']['instructions'])


@pytest.mark.parametrize('text,scoped', [('所选片段未提供消融结果。', True),
    ('论文未做消融实验。', False), ('本次所引片段未报告性能。', True)])
def test_inventory_distinguishes_visible_scope_from_source_self_report(text, scoped):
    value = enabled(); value['absence_inventory_policy'] = ABSENCE_INVENTORY_POLICY
    value['claims'][0].update(text=text, scope_note='', qualification='')
    before = deepcopy(value)
    inventory = citation_audit_input(value, evidence())['absence_scope_inventory']
    assert inventory['candidates'][0]['visible_excerpt_scope_only_not_truth'] is scoped
    assert not inventory['semantic_auto_approval'] and value == before
    assert 'source need NOT' in ' '.join(inventory['instructions'])


def test_visible_excerpt_scope_does_not_rescue_a_rejected_factual_assertion():
    value = enabled(); value['absence_inventory_policy'] = ABSENCE_INVENTORY_POLICY
    value['claims'][0]['qualification'] = '所选片段未提供消融结果。'
    raw = rejected_without_target(value)
    absence(raw, value['claims'][0]['qualification'], basis='selected_excerpts')
    checked = check_audit(raw, value, evidence())
    assert not checked['contract_errors'] and not checked['protocol_issues']
    assert publication_rejections(checked, value) == {'c1'}


@pytest.mark.parametrize('correct_second_audit', [True, False])
def test_workflow_corrects_audit_category_once_without_rewriting_valid_writer_text(tmp_path, correct_second_audit):
    configured, calls = agents()
    value = enabled()
    value['claims'][0]['evidence_ids'] = ['arxiv-1']
    value['claims'][0]['qualification'] = '这是作者在该设置下的解释。'
    value['claims'].append({**deepcopy(value['claims'][0]), 'claim_id':'c2', 'text':'独立的获批结果。'})
    def writer(packet):
        calls.append('writer')
        return {'output':deepcopy(value)}
    seen = []
    def auditor(packet):
        calls.append('citation_auditor')
        result = audit(value) if seen and correct_second_audit else rejected_without_target(value)
        seen.append(result)
        return {'output':result}
    configured.writer.handler, configured.citation_auditor.handler = writer, auditor
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {
        'status':'ok', 'papers':[{'paper_id':'1', 'title':'Paper', 'abstract':QUOTE}]})
    result = flow.run('audit-category', 'owner', 'Explain method A')
    assert calls.count('writer') == 1 and calls.count('citation_auditor') == 2
    assert result['run']['model_calls_used'] == 6
    assert result['run']['status'] == ('completed' if correct_second_audit else 'needs_review')
    final = flow.artifacts.get(result['final_artifact_id'])
    checked = flow.artifacts.get(final['artifact_refs']['audit'])
    assert publication_rejections(checked, value) == (set() if correct_second_audit else {'c1'})
