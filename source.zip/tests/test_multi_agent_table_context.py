"""PDF row geometry, bounded RAG and approved-source context, without a model."""
from copy import deepcopy
import pytest

import pdf_pipeline as pdf
from multi_agent_rag import build_chunks, EvidenceStore, HybridRetriever, RagIndexer, TABLE_CONTEXT_POLICY
from multi_agent_quality import source_boundary_brief, citation_audit_input


def line(text, x, y, width=44):
    return {'text': text, 'bbox': [x, y, x + width, y + 9], 'spans': []}


def raw(lines):
    return {'text': '\n'.join(v['text'] for v in lines), 'line_spans': lines,
        'bbox': [min(v['bbox'][0] for v in lines), min(v['bbox'][1] for v in lines),
                 max(v['bbox'][2] for v in lines), max(v['bbox'][3] for v in lines)], 'page': 7}


def test_caption_continuation_is_not_split_into_fake_prose_columns():
    value = raw([line('Table 3: Experiments comparing methods and tasks.', 100, 70, 400),
                 line('finetuning.', 100, 81)])
    assert pdf._split_cross_track_raw_blocks([value], 612) == [value]


def test_multirow_table_headers_and_numbers_keep_left_to_right_geometry():
    value = raw([line('Dataset', 110, 100), line('GLUE (Acc.)', 220, 100),
                 line('Super-NaturalInstructions (RougeL)', 330, 100, 160),
                 line('Model', 110, 111), line('RoBERTa-large', 210, 111, 65), line('T5-80M', 300, 111),
                 line('BF16', 110, 123), line('88.6', 220, 123), line('40.1', 330, 123)])
    assert pdf._split_cross_track_raw_blocks([value], 612) == [value]


def test_ordinary_mixed_track_prose_is_still_split():
    value = raw([line('This is a normal paragraph in the left column.', 100, 100, 190),
                 line('Another paragraph belongs to the right column.', 330, 115, 180)])
    assert len(pdf._split_cross_track_raw_blocks([value], 612)) == 2


def table_blocks():
    return [
        {**raw([line('Table 3: Results on GLUE and Super-NaturalInstructions.', 100, 70, 400)]),
         'type': 'table', 'table_id': 'table-3'},
        {**raw([line('Dataset', 110, 100), line('GLUE (Acc.)', 210, 100, 70),
                line('Super-NaturalInstructions (RougeL)', 310, 100, 180),
                line('Model', 110, 111), line('RoBERTa-large', 210, 111, 70), line('T5-80M', 310, 111)]),
         'type': 'table', 'table_id': 'table-3'},
        {**raw([line('BF16', 110, 123), line('88.6', 210, 123), line('40.1', 310, 123),
                line('QLoRA NF4 + DQ', 110, 135, 90), line('-', 210, 135), line('40.4', 310, 135)]),
         'type': 'table', 'table_id': 'table-3'},
        {'text': 'A separate body paragraph.', 'page': 7, 'type': 'text', 'bbox': [100, 240, 500, 270]},
    ]


def test_chunk_contains_actual_headers_and_values_not_just_caption():
    chunks = build_chunks('doc', 'paper', 'Test', table_blocks())
    table = next(c for c in chunks if c.get('table_id'))
    assert 'Dataset | GLUE (Acc.) | Super-NaturalInstructions (RougeL)' in table['text']
    assert 'BF16 | 88.6 | 40.1' in table['text']
    assert 'A separate body' not in table['text']
    assert table['bbox'] == [100.0, 70.0, 500.0, 144.0]
    assert table['table_context']['policy'] == TABLE_CONTEXT_POLICY
    assert table['table_context']['row_layout_preserved'] is True
    assert table['table_context']['column_semantics_verified'] is False


@pytest.mark.parametrize('boundary', ['page', 'table_id'])
def test_table_chunks_do_not_cross_page_or_table(boundary):
    blocks = table_blocks()[:3]
    blocks[-1][boundary] = 8 if boundary == 'page' else 'table-4'
    chunks = build_chunks('doc', 'paper', 'Test', blocks)
    assert len(chunks) >= 2
    assert not any('GLUE (Acc.)' in c['text'] and '40.4' in c['text'] for c in chunks)


def test_no_geometry_does_not_claim_row_structure_verified():
    chunks = build_chunks('doc', 'paper', 'Test', [
        {'text': 'Table 1: flattening is uncertain. 1 2 3', 'page': 1, 'table_id': 'table-1'}])
    assert chunks[0]['table_context']['row_layout_preserved'] is False
    assert chunks[0]['table_context']['column_semantics_verified'] is False


@pytest.mark.parametrize('lines', [
    [{'text': 'Only a partial header', 'bbox': [1, 1, 20, 10]}],
    [{'text': 'A table row with 88.6 and 40.1', 'bbox': [1, None, 20, 10]}],
    [{'text': 'A table row with 88.6 and 40.1', 'bbox': [1, float('nan'), 20, 10]}],
    ['malformed layout line'],
])
def test_incomplete_or_malformed_lines_keep_complete_text(lines):
    original = 'A table row with 88.6 and 40.1'
    chunk = build_chunks('doc', 'paper', 'Test', [{'text': original, 'page': 1,
        'table_id': 'table-1', 'line_spans': lines}])[0]
    assert chunk['text'] == original
    assert chunk['table_context']['row_layout_preserved'] is False


def test_fts_preserves_scoped_table_metadata_and_budget(tmp_path):
    store = EvidenceStore(tmp_path / 'evidence.sqlite3')
    indexer = RagIndexer(store)
    for name in ['mine', 'other']:
        indexer.index({'document_id': name, 'paper_id': name, 'title': 'QLoRA', 'content_hash': name}, table_blocks())
    packets = HybridRetriever(store).search('GLUE RoBERTa T5', document_ids={'mine'}, limit=4, context_budget=4000)
    table = next(p for p in packets if p.get('table_context'))
    assert table['document_id'] == 'mine' and table['locator']['page'] == 7
    assert 'GLUE (Acc.)' in table['text'] and 'RougeL' in table['text']
    assert table['table_context']['column_semantics_verified'] is False
    assert len(packets) <= 4
    assert HybridRetriever(store).search('GLUE', document_ids={'mine'}, context_budget=1) == []


def test_table_metadata_is_available_only_for_approved_evidence():
    item = {'evidence_id': 'e1', 'paper_id': 'p', 'review_status': 'approved',
        'excerpt': 'Table 3: Dataset | GLUE (Acc.) | Super-NaturalInstructions (RougeL)',
        'locator': {'page': 7, 'table_id': 'table-3'},
        'table_context': {'policy': TABLE_CONTEXT_POLICY, 'column_semantics_verified': False}}
    evidence = {'evidence': [item]}
    before = deepcopy(evidence)
    records = source_boundary_brief(evidence)['table_context_records']
    assert len(records) == 1 and records[0]['is_scientific_verdict'] is False
    assert evidence == before
    item['review_status'] = 'rejected'
    assert source_boundary_brief(evidence)['table_context_records'] == []


def test_old_parse_version_is_not_silently_reused(tmp_path, monkeypatch):
    monkeypatch.setattr(pdf, 'PDF_PARSE_CACHE_DIR', tmp_path)
    path = tmp_path / 'source.pdf'
    path.write_bytes(b'%PDF-1.7 fake fixture, never parsed')
    monkeypatch.setattr(pdf, 'PDF_PARSE_CACHE_VERSION', 'v2')
    old = pdf._pdf_parse_cache_path(path, False)
    monkeypatch.setattr(pdf, 'PDF_PARSE_CACHE_VERSION', 'v3-table-row-context')
    assert pdf._pdf_parse_cache_path(path, False) != old


def test_auditor_sees_table_uncertainty_not_automatic_semantic_approval():
    from test_multi_agent_report_fields import draft, evidence
    source = evidence()
    source['evidence'][0]['table_context'] = {'policy': TABLE_CONTEXT_POLICY,
        'row_layout_preserved': True, 'column_semantics_verified': False}
    result = citation_audit_input(draft(), source)
    context = result['claims'][0]['source_context'][0]['table_context']
    assert context['column_semantics_verified'] is False
    assert context['row_layout_preserved'] is True


def test_old_arxiv_parse_marker_reparses_but_does_not_redownload(tmp_path):
    import time
    from test_multi_agent_live import make_search, request, create_pdf
    from multi_agent_live import LiveArxivRagExecutor
    storage = tmp_path / 'storage'
    first = LiveArxivRagExecutor(tmp_path / 'first', storage, rag_mode='lexical', search=make_search(),
        download=lambda _paper, folder: create_pdf(folder))
    first.execute(request(), group_ids={'g1'}, deadline=time.monotonic() + 30)
    folder = storage / 'documents' / 'arxiv-2309-06180'
    marker = folder / 'parsed_hash.txt'
    marker.write_text(marker.read_text().split(':')[0], encoding='utf-8')
    calls = []
    def parse(path):
        calls.append(True)
        return pdf.parse_pdf(path, enable_ocr=False)
    second = LiveArxivRagExecutor(tmp_path / 'second', storage, rag_mode='lexical', search=make_search(),
        parse=parse, download=lambda *_: pytest.fail('existing PDF must not be downloaded again'))
    result = second.execute(request(), group_ids={'g1'}, deadline=time.monotonic() + 30)
    assert calls == [True]
    assert any(row.get('download_reused') is True and row.get('parse_reused') is False
               for row in result['observations'])
