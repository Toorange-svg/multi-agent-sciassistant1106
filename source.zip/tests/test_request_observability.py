"""Regression coverage for privacy-preserving request correlation."""

import logging
import re
from types import SimpleNamespace
from unittest import mock

import app as account_app
import web_app


def _capture_logger(logger):
    records = []

    class _Capture(logging.Handler):
        def emit(self, record):
            records.append(record.getMessage())

    handler = _Capture()
    logger.addHandler(handler)
    return records, handler


def test_gateway_returns_a_safe_generated_request_id_and_never_logs_query_text():
    records, handler = _capture_logger(account_app.logger)
    previous_level = account_app.logger.level
    account_app.logger.setLevel(logging.INFO)
    try:
        response = account_app.app.test_client().get("/api/health?secret_query=do-not-log-me")
    finally:
        account_app.logger.removeHandler(handler)
        account_app.logger.setLevel(previous_level)

    request_id = response.headers["X-Request-ID"]
    assert response.status_code == 200
    assert re.fullmatch(r"[A-Za-z0-9_-]{8,64}", request_id)
    assert any("component=account_gateway" in message and "route=/api/health" in message for message in records)
    assert all("secret_query" not in message and "do-not-log-me" not in message for message in records)


def test_gateway_preserves_valid_request_id_through_in_process_science_dispatch(tmp_path, monkeypatch):
    old_local_app = account_app._LOCAL_SCIENCE_APP
    account_app._LOCAL_SCIENCE_APP = web_app.app
    monkeypatch.setattr(web_app, "TASK_STATE_DIR", tmp_path)
    try:
        with mock.patch.object(web_app, "check_shared_mcp"):
            response = account_app.app.test_client().get(
                "/api/science/readyz",
                headers={"X-Request-ID": "deploy-batch-20261006"},
            )
    finally:
        account_app._LOCAL_SCIENCE_APP = old_local_app

    assert response.status_code == 200
    assert response.headers["X-Request-ID"] == "deploy-batch-20261006"


def test_invalid_client_request_id_is_replaced_with_opaque_value():
    response = web_app.app.test_client().get(
        "/api/health", headers={"X-Request-ID": "too short"}
    )
    assert response.status_code == 200
    assert re.fullmatch(r"[A-Za-z0-9_-]{8,64}", response.headers["X-Request-ID"])
    assert response.headers["X-Request-ID"] != "too short"


def test_remote_proxy_uses_gateway_generated_request_id_not_raw_client_header():
    upstream = SimpleNamespace(content=b"ok", status_code=200, headers={})
    with account_app.app.test_request_context(
        "/api/science/readyz", headers={"X-Request-ID": "invalid id"}
    ):
        # This mirrors the value installed by the gateway before-request hook.
        account_app.g.request_id = "gateway-trace-20261006"
        with mock.patch.object(account_app.http_requests, "request", return_value=upstream) as send:
            response, status, _headers = account_app._proxy_request(
                "http://127.0.0.1:5050", "api/readyz"
            )

    assert response == b"ok"
    assert status == 200
    forwarded_headers = send.call_args.kwargs["headers"]
    assert forwarded_headers["X-Request-ID"] == "gateway-trace-20261006"
    assert [key.lower() for key in forwarded_headers].count("x-request-id") == 1
    assert "invalid id" not in forwarded_headers.values()
