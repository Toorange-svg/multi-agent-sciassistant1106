from __future__ import annotations

import json
from pathlib import Path
import time

import pytest

from multi_agent_agents import ArtifactDirectory
from multi_agent_live import LiveArxivRagExecutor
from multi_agent_pipeline_v2 import check_draft
from multi_agent_workflow import WorkflowStore
from tools.inspect_research_quality import evidence_preview, inspect_run, main, render_notes


@pytest.mark.parametrize("printed,source", [
    ("2.51×", "2.51x"), ("2.06×, 1.89×, 1.51×", "2.06x, 1.89x, 1.51x"),
    ("8×H100", "8xH100"), ("2.50×", "2.5 X"), ("12％", "12%"),
])
def test_equivalent_printed_quantities_are_not_rejected(printed, source):
    draft = {"direct_answer": "answer", "claims": [{"claim_id": "c1", "claim_type": "quantitative",
                                                       "text": printed, "evidence_ids": ["e1"]}]}
    assert check_draft(draft, {"evidence": [{"evidence_id": "e1", "excerpt": source}]}) == []


@pytest.mark.parametrize("printed,source", [
    ("2.51×", "2.15x"), ("12%", "112%"), ("12×", "112x"),
    ("2.51%", "2.51x"), ("2.51×", "12.51x"), ("2.51×", "2.51 xml"),
])
def test_unreported_or_different_quantities_still_fail(printed, source):
    draft = {"direct_answer": "answer", "claims": [{"claim_id": "c1", "claim_type": "quantitative",
                                                       "text": printed, "evidence_ids": ["e1"]}]}
    assert check_draft(draft, {"evidence": [{"evidence_id": "e1", "excerpt": source}]}) == [
        {"claim_id": "c1", "reason": "UNSUPPORTED_NUMBER"}]


def quality_run(tmp_path: Path, *, papers_override=None, observation_override=None, plan=None, review=None, draft_override=None):
    run = tmp_path / "run"
    artifacts = ArtifactDirectory(run / "artifacts")
    papers = [{"evidence_id": "ev1", "paper_id": "2309.06180v1", "title": "Paper A",
               "group_id": "g1", "group_ids": ["g1"], "excerpt": "2.51x", "coverage_scope": "selected_chunks",
               "review_status": "approved", "locator": {"page": 3}},
              {"evidence_id": "ev2", "paper_id": "2309.06180v2", "title": "Paper A",
               "group_id": "g1", "group_ids": ["g1"], "excerpt": "more evidence", "coverage_scope": "selected_chunks",
               "review_status": "approved", "locator": {"page": 4}}]
    papers = papers if papers_override is None else papers_override
    observations = [{"request_id": "r1", "group_id": "g1", "query": "query", "source_status": "ok", "accepted_count": 2}] if observation_override is None else observation_override
    artifacts.put("evidence-set", {"evidence": papers, "observations": observations})
    artifacts.put("evidence-set", {"evidence": papers, "observations": observations, "recovery": True})
    refs = {
        "plan": artifacts.put("research-plan", plan or {"groups": [{"id": "g1", "question": "question"}]})["artifact_id"],
        "approved": artifacts.put("approved-evidence", {"evidence": papers})["artifact_id"],
        "draft": artifacts.put("draft-answer", draft_override or {"claims": [{"claim_id": "c1", "text": "2.51×",
                 "claim_type": "quantitative", "evidence_ids": ["ev1"]}]})["artifact_id"],
        "audit": artifacts.put("citation-audit", {"status": "passed"})["artifact_id"],
    }
    if review:
        refs["review"] = artifacts.put("evidence-review", review)["artifact_id"]
    final = artifacts.put("final-result", {"status": "partial", "direct_answer": "Result[1]", "artifact_refs": refs})
    (run / "manifest.json").write_text(json.dumps({"run_id": "test-quality", "final_artifact_id": final["artifact_id"]}), encoding="utf-8")
    WorkflowStore(run / "workflow.sqlite3").create_run("test-quality", "owner")
    return run


def test_counts_papers_versions_packets_and_actual_citations_separately(tmp_path):
    summary = inspect_run(quality_run(tmp_path))
    assert summary["funnel"]["queries"] == 1
    assert summary["funnel"]["candidate_count_basis"] == "persisted_lower_bound"
    assert summary["funnel"]["candidate_papers_observed"] == 1
    assert summary["funnel"]["approved_packets"] == 2
    assert summary["funnel"]["approved_papers"] == 1
    assert summary["funnel"]["cited_packets"] == 1
    assert summary["funnel"]["cited_papers"] == 1
    assert summary["papers"][0]["versions"] == ["2309.06180v1", "2309.06180v2"]
    assert "不是全文精读总结" in render_notes(summary)
    assert all(r["label"] is None for r in summary["relevance_review"])


def test_full_catalog_retains_candidate_before_context_cap(tmp_path):
    run = quality_run(tmp_path)
    (run / "tools").mkdir()
    catalog = {"schema_version": "sciassistant.search-catalog/v1", "query": "query", "source_status": "ok",
               "papers": [{"paper_id": "2309.06180v2", "title": "Paper A", "abstract": "one"},
                          {"paper_id": "2402.02750v1", "title": "Paper B", "abstract": "two"}]}
    (run / "tools/search_catalog.jsonl").write_text(json.dumps(catalog) + "\n", encoding="utf-8")
    summary = inspect_run(run)
    assert summary["funnel"]["candidate_count_basis"] == "complete_search_catalog"
    assert summary["funnel"]["candidate_papers_observed"] == 2
    assert summary["groups"][0]["candidate_papers_observed"] == 2
    catalog["query"] = "not-the-recorded-query"
    (run / "tools/search_catalog.jsonl").write_text(json.dumps(catalog) + "\n", encoding="utf-8")
    assert inspect_run(run)["funnel"]["candidate_count_basis"] == "persisted_lower_bound"


def test_output_does_not_overwrite_source_or_previous_reports(tmp_path):
    run = quality_run(tmp_path)
    original = (run / "manifest.json").read_bytes()
    assert main(["--run-dir", str(run), "--output-dir", str(run)]) == 2
    output = tmp_path / "inspection"
    assert main(["--run-dir", str(run), "--output-dir", str(output)]) == 0
    assert main(["--run-dir", str(run), "--output-dir", str(output)]) == 2
    assert (run / "manifest.json").read_bytes() == original


def test_progress_duplicates_are_not_queries_but_real_recovery_repeat_is(tmp_path):
    run = quality_run(tmp_path)
    start = {"event": "agent_started", "role": "retriever"}
    query = {"event": "retrieval_query", "request_id": "r1", "group_id": "g1", "query": "query", "source_status": "ok"}
    events = [start, query, query, start, query, query]
    (run / "events.jsonl").write_text("\n".join(json.dumps(row) for row in events), encoding="utf-8")
    assert inspect_run(run)["funnel"]["queries"] == 2


def test_note_preview_prefers_source_result_over_pdf_header():
    preview = evidence_preview("ICLR 2025\n\nPaper title\n\n" + "Background " * 50 + "achieves a 2.51x speedup in large batch settings.", 60)
    assert "2.51x" in preview and "ICLR" not in preview
    assert len(preview) <= 60


def test_catalog_contains_only_public_bounded_fields(tmp_path):
    executor = LiveArxivRagExecutor(tmp_path / "run", tmp_path / "storage", rag_mode="lexical", search=lambda *_a, **_k: {
        "status": "ok", "authorization": "private-canary", "papers": [
            {"paper_id": "2309.06180v1", "title": "Paper", "abstract": "x" * 5000,
             "authorization": "private-canary", "path": "C:/private-canary"},
            {"paper_id": "../../../secret", "title": "invalid"}]})
    executor.retrieval_deadline = time.monotonic() + 10
    result = executor._search("PagedAttention", 5)
    catalog = (tmp_path / "run/tools/search_catalog.jsonl").read_text(encoding="utf-8")
    record = json.loads(catalog)
    assert result["status"] == "ok"
    assert len(record["papers"]) == 1 and len(record["papers"][0]["abstract"]) == 4000
    assert "private-canary" not in catalog and "../../../secret" not in catalog


def test_corrupt_catalog_or_artifact_does_not_produce_quality_pass(tmp_path, capsys):
    run = quality_run(tmp_path)
    (run / "tools").mkdir()
    (run / "tools/search_catalog.jsonl").write_text('{"schema_version": "unknown"}\n', encoding="utf-8")
    assert main(["--run-dir", str(run)]) == 2
    assert "QUALITY_INPUT_INVALID" in capsys.readouterr().out


def local_packet(**fields):
    return {"evidence_id": "ev1", "paper_id": "uploaded-fixture", "title": "Uploaded paper", "source": "uploaded_pdf",
            "group_id": "g1", "group_ids": ["g1"], "excerpt": "2.51x", "coverage_scope": "selected_chunks",
            "review_status": "approved", "locator": {"page": 3}, **fields}


@pytest.mark.parametrize("paper_id", ["uploaded-fixture", "2106.09685v2", "https://evil.test/paper"])
def test_uploaded_documents_never_get_invented_arxiv_links(tmp_path, paper_id):
    summary = inspect_run(quality_run(tmp_path, papers_override=[local_packet(paper_id=paper_id)]))
    paper = summary["papers"][0]
    assert paper["source"] == "uploaded_pdf" and paper["official_url"] == ""
    notes = render_notes(summary)
    assert "本地上传文档" in notes and "未生成外部链接" in notes and "https://arxiv.org/abs/" not in notes


def test_successful_local_phases_are_not_pdf_failures_and_costs_are_deduplicated(tmp_path):
    rows = [{"source": "uploaded_pdf", "source_status": "pdf_parse_completed", "elapsed_ms": 188},
            {"source": "uploaded_pdf", "source_status": "pdf_index_completed", "elapsed_ms": 17203},
            {"source": "uploaded_pdf", "source_status": "pdf_indexed", "document_id": "uploaded-fixture"},
            {"source_status": "pdf_download_deadline_skipped", "document_id": "arxiv-fixture", "download_ms": 30000},
            {"source_status": "pdf_parse_failed", "document_id": "arxiv-other", "parse_ms": 50},
            {"source_status": "pdf_new_unknown_event"}]
    summary = inspect_run(quality_run(tmp_path, papers_override=[local_packet()], observation_override=rows))
    assert [r["source_status"] for r in summary["funnel"]["pdf_failures"]] == ["pdf_download_deadline_skipped", "pdf_parse_failed"]
    assert summary["processing_ms"] == {"download_ms": 30000, "parse_ms": 238, "index_ms": 17203}
    assert summary["funnel"]["pdf_unclassified_events"] == [{"source_status": "pdf_new_unknown_event"}]


def test_approved_topic_counts_follow_reviewer_not_retrieval_bucket(tmp_path):
    row = local_packet(reviewed_group_ids=["g2"])
    summary = inspect_run(quality_run(tmp_path, papers_override=[row], plan={"groups": [
        {"id": "g1", "question": "retrieval topic"}, {"id": "g2", "question": "actually supported topic"}]}))
    assert [g["approved_packets"] for g in summary["groups"]] == [0, 1]
    paper = summary["papers"][0]
    assert paper["group_ids"] == ["g2"] and paper["retrieval_group_ids"] == ["g1"]
    assert paper["research_questions"] == ["actually supported topic"]


def test_abstract_excerpt_is_not_promoted_to_full_text_notes(tmp_path):
    summary = inspect_run(quality_run(tmp_path, papers_override=[local_packet(content_scope="abstract_only")]))
    assert summary["papers"][0]["reading_scope"] == "abstract_only"
    assert "仅摘要级证据，不能冒称核验全文" in render_notes(summary)


def test_mixed_public_catalog_does_not_need_uploaded_queries_to_be_public(tmp_path):
    papers = [local_packet(), local_packet(evidence_id="ev2", paper_id="2106.09685v2", source="arxiv")]
    rows = [{"request_id": "local-1", "query": "private local query", "group_id": "g1", "source": "uploaded_pdf", "source_status": "ok"},
            {"request_id": "public-1", "query": "public query", "group_id": "g1", "source": "arxiv", "source_status": "ok"}]
    run = quality_run(tmp_path, papers_override=papers, observation_override=rows)
    (run / "tools").mkdir()
    (run / "tools/search_catalog.jsonl").write_text(json.dumps({"schema_version": "sciassistant.search-catalog/v1",
        "query": "public query", "source_status": "ok", "papers": [{"paper_id": "2106.09685v2", "title": "LoRA"}]}) + "\n", encoding="utf8")
    summary = inspect_run(run)
    assert summary["funnel"]["queries"] == 2 and summary["funnel"]["candidate_count_basis"] == "complete_search_catalog"
    assert summary["funnel"]["candidate_to_approved_paper_fraction"] == 1
    assert summary["funnel"]["paper_count_basis"] == "distinct_recorded_document_identities_not_independent_studies"


def test_recovery_reason_is_reported_without_echoing_proposal(tmp_path):
    run = quality_run(tmp_path)
    (run / "events.jsonl").write_text(json.dumps({"event": "gap_plan_rejected", "stage": "gap_plan",
        "reason_code": "GAP_PLAN_REJECTED", "retained_approved_evidence_count": 8,
        "query": "PRIVATE_QUERY_CANARY"}) + "\n", encoding="utf8")
    summary = inspect_run(run)
    assert summary["recovery_summary"]["rejections"][0]["retained_approved_evidence_count"] == 8
    assert "PRIVATE_QUERY_CANARY" not in json.dumps(summary["recovery_summary"])
    assert "不是文献不存在或网络故障的结论" in render_notes(summary)


def test_notes_keep_visible_scope_separate_from_detailed_review(tmp_path):
    draft = {"schema_version": "sciassistant.claim-draft/v2", "claims": [{"claim_id": "c1", "text": "2.51x",
        "evidence_ids": ["ev1"], "scope_note": "Only benchmark X", "qualification": "Detailed protocol Y"}]}
    notes = render_notes(inspect_run(quality_run(tmp_path, draft_override=draft)))
    assert "结论适用范围：Only benchmark X" in notes
    assert "详细实验条件与证据局限：Detailed protocol Y" in notes
    assert "  限定：" not in notes
