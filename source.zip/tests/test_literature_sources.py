import unittest

from deepdiver_v2.src.literature_sources import deduplicate


class LiteratureSourceTests(unittest.TestCase):
    def test_deduplicate_prefers_doi_identity(self):
        papers = [
            {"source": "zenodo", "paper_id": "1", "doi": "10.1234/X", "title": "A"},
            {"source": "hal", "paper_id": "hal-2", "doi": "10.1234/x", "title": "A different copy"},
        ]
        self.assertEqual(len(deduplicate(papers)), 1)

    def test_deduplicate_keeps_distinct_titles(self):
        papers = [
            {"source": "zenodo", "paper_id": "1", "title": "A paper"},
            {"source": "hal", "paper_id": "2", "title": "Another paper"},
        ]
        self.assertEqual(len(deduplicate(papers)), 2)


if __name__ == "__main__":
    unittest.main()
