"""Browser-facing gateway headers, explicit CORS and credential migration."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from unittest import mock

import pytest

import app as gateway


ROOT = Path(__file__).resolve().parents[1]
LOGIN_HTML = (ROOT / "chatAi/login.html").read_text(encoding="utf-8")
CHAT_HTML = (ROOT / "chatAi/ai_chat.html").read_text(encoding="utf-8")


def test_public_pages_and_api_receive_browser_security_headers():
    client = gateway.app.test_client()
    page = client.get("/login.html")
    api = client.get("/api/health")
    for response in (page, api):
        assert response.headers["X-Content-Type-Options"] == "nosniff"
        assert response.headers["X-Frame-Options"] == "DENY"
        assert response.headers["Referrer-Policy"] == "no-referrer"
        assert response.headers["Permissions-Policy"] == "camera=(), microphone=(), geolocation=()"
        assert response.headers["Cross-Origin-Opener-Policy"] == "same-origin"
        assert response.headers["Cross-Origin-Resource-Policy"] == "same-origin"
        csp = response.headers["Content-Security-Policy"]
        assert "default-src 'self'" in csp and "object-src 'none'" in csp
        assert "frame-ancestors 'none'" in csp and "connect-src 'self'" in csp
        assert "cdn.tailwindcss.com" not in csp and "cdn.jsdelivr.net" not in csp
        assert "script-src 'self' 'unsafe-inline'" in csp
    assert api.headers["Cache-Control"] == "no-store"
    assert api.headers["Cache-Control"] != page.headers.get("Cache-Control")


def test_hsts_is_production_only_without_trusting_forwarded_headers():
    client = gateway.app.test_client()
    with mock.patch.dict(os.environ, {"APP_ENV": "production"}):
        response = client.get("/api/health", headers={"X-Forwarded-Proto": "http"})
        assert response.headers["Strict-Transport-Security"] == "max-age=31536000"
    with mock.patch.dict(os.environ, {"APP_ENV": "test"}):
        assert "Strict-Transport-Security" not in client.get("/api/health").headers


@pytest.mark.parametrize("value", [
    "*",
    "https://*.example.org",
    "https://user:secret@example.org",
    "https://example.org/path",
    "https://example.org?token=private",
    "file:///private",
    "https://example.org:invalid",
])
def test_cors_configuration_rejects_wildcards_credentials_and_url_components(value):
    with pytest.raises(RuntimeError):
        gateway._configured_cors_origins(value)


def test_cors_configuration_normalizes_and_deduplicates_exact_origins():
    assert gateway._configured_cors_origins(
        " HTTPS://UI.EXAMPLE.ORG/ ;http://127.0.0.1:3000,https://ui.example.org"
    ) == ["https://ui.example.org", "http://127.0.0.1:3000"]
    assert gateway._configured_cors_origins("") == []


def test_production_cors_requires_https():
    with mock.patch.dict(os.environ, {"APP_ENV": "production"}):
        with pytest.raises(RuntimeError):
            gateway._configured_cors_origins("http://127.0.0.1:3000")
        assert gateway._configured_cors_origins("https://ui.example.org") == ["https://ui.example.org"]


def test_default_gateway_has_no_cross_origin_read_access():
    response = gateway.app.test_client().get("/api/health", headers={"Origin": "https://evil.invalid"})
    assert "Access-Control-Allow-Origin" not in response.headers


def test_direct_gateway_listener_defaults_to_loopback_and_rejects_remote_bind():
    assert gateway._configured_account_listener("127.0.0.1", "5000") == ("127.0.0.1", 5000)
    assert gateway._configured_account_listener("127.0.0.2", "65535") == ("127.0.0.2", 65535)
    for host in ("0.0.0.0", "192.168.1.10", "::1", "localhost", ""):
        with pytest.raises(RuntimeError):
            gateway._configured_account_listener(host, "5000")
    for port in ("0", "65536", "not-a-port", ""):
        with pytest.raises(RuntimeError):
            gateway._configured_account_listener("127.0.0.1", port)


def test_explicit_origin_is_allowed_but_other_origin_is_not(tmp_path):
    environment = {
        **os.environ,
        "APP_ENV": "test",
        "SECRET_KEY": "offline-browser-security-key",
        "CORS_ALLOWED_ORIGINS": "https://ui.example.org",
        "SCIASSISTANT_TASK_STATE_DIR": str(tmp_path / "task-state"),
    }
    script = r"""
import json
import app
c=app.app.test_client()
good=c.get('/api/health', headers={'Origin':'https://ui.example.org'})
bad=c.get('/api/health', headers={'Origin':'https://evil.invalid'})
pre=c.options('/api/login', headers={
  'Origin':'https://ui.example.org',
  'Access-Control-Request-Method':'POST',
  'Access-Control-Request-Headers':'Authorization, Content-Type',
})
print(json.dumps({
  'good':good.headers.get('Access-Control-Allow-Origin'),
  'bad':bad.headers.get('Access-Control-Allow-Origin'),
  'pre':pre.headers.get('Access-Control-Allow-Origin'),
  'allow_headers':pre.headers.get('Access-Control-Allow-Headers'),
}))
"""
    completed = subprocess.run(
        [sys.executable, "-c", script], cwd=ROOT, env=environment,
        capture_output=True, text=True, encoding="utf-8", timeout=20,
    )
    assert completed.returncode == 0, completed.stderr[-1500:]
    payload = json.loads(completed.stdout.strip().splitlines()[-1])
    assert payload["good"] == "https://ui.example.org"
    assert payload["bad"] is None
    assert payload["pre"] == "https://ui.example.org"
    assert "Authorization" in payload["allow_headers"] and "Content-Type" in payload["allow_headers"]


def test_login_never_persists_or_logs_a_password_and_purges_legacy_storage():
    assert "localStorage.setItem('savedCredentials'" not in LOGIN_HTML
    assert "saveRememberedLogin(loginId.value.trim(), password" not in LOGIN_HTML
    assert "console.log" not in LOGIN_HTML
    assert 'autocomplete="username"' in LOGIN_HTML
    assert 'autocomplete="current-password"' in LOGIN_HTML
    node = shutil.which("node")
    if not node:
        pytest.skip("Node is required to execute the actual credential migration functions")
    functions = "function purgeLegacySavedCredentials() {" + LOGIN_HTML.split(
        "function purgeLegacySavedCredentials() {", 1)[1].split("// 邮箱格式验证函数", 1)[0]
    script = r"""
const values = new Map([
  ['savedCredentials', JSON.stringify({loginId:'legacy',password:'private-password'})],
  ['rememberedLoginId', 'remembered-user']
]);
global.localStorage = {
  getItem: key => values.has(key) ? values.get(key) : null,
  setItem: (key, value) => values.set(key, String(value)),
  removeItem: key => values.delete(key)
};
const fields = {loginId:{value:''}, password:{value:'must-clear'}, rememberMe:{checked:false}};
global.document = {getElementById: id => fields[id]};
""" + functions + r"""
loadRememberedLogin();
const loaded = {loginId:fields.loginId.value,password:fields.password.value,
                checked:fields.rememberMe.checked,legacy:values.has('savedCredentials')};
saveRememberedLogin('next-user');
const saved = {loginId:values.get('rememberedLoginId'),legacy:values.has('savedCredentials')};
clearRememberedLogin();
console.log(JSON.stringify({loaded,saved,remaining:[...values.keys()]}));
"""
    completed = subprocess.run([node, "-e", script], capture_output=True, text=True, encoding="utf-8", timeout=5)
    assert completed.returncode == 0, completed.stderr
    payload = json.loads(completed.stdout)
    assert payload == {
        "loaded": {"loginId": "remembered-user", "password": "", "checked": True, "legacy": False},
        "saved": {"loginId": "next-user", "legacy": False},
        "remaining": [],
    }
    assert "private-password" not in completed.stdout + completed.stderr


def test_chat_production_diagnostics_are_noop_not_console_output():
    assert "const sciAssistantDebug = () => {};" in CHAT_HTML
    assert "console.log" not in CHAT_HTML
    for sensitive_marker in ("最终发送的messages", "RAG检索结果", "文件上传成功", "文档库文件列表"):
        assert sensitive_marker in CHAT_HTML  # Calls remain reachable for syntax/flow checks.
