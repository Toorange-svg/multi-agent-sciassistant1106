"""CLI argument/config failures are safe and cannot spend model quota."""
import json
from pathlib import Path
import subprocess
import sys

import pytest

ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.parametrize("task,user", [("../private", "alice"), ("abcdef012345", "../private")])
def test_invalid_identifiers_rejected_before_app_import(task, user):
    proc = subprocess.run([sys.executable, str(ROOT / "tools/check_multi_agent_web_readonly.py"),
                           "--task-id", task, "--other-user-id", user], cwd=ROOT,
                          capture_output=True, text=True, encoding="utf-8", timeout=10)
    assert proc.returncode == 2 and "invalid task/account identifier" in proc.stderr
    assert "Authorization" not in proc.stdout and "Traceback" not in proc.stderr


def test_missing_task_safe_failure_is_not_online_acceptance():
    proc = subprocess.run([sys.executable, str(ROOT / "tools/check_multi_agent_web_readonly.py"),
                           "--task-id", "aaaaaaaaaaaa", "--other-user-id", "bob"], cwd=ROOT,
                          capture_output=True, text=True, encoding="utf-8", timeout=10)
    assert proc.returncode == 1
    data = json.loads(proc.stdout)
    assert not data["passed"] and data["error"] == "READONLY_CHECK_FAILED"
    assert "Traceback" not in proc.stderr and str(ROOT) not in proc.stdout
