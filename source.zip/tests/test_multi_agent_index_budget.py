"""Cold-index deadline, publication pointer and source-scope regressions."""
import json
import subprocess
from types import SimpleNamespace

import pytest

from multi_agent_agents import ArtifactDirectory
from multi_agent_evidence import evidence_strength, excerpt_content_scope
from multi_agent_quality import answer_requirements
from multi_agent_rag import EvidenceStore, RagIndexer
from multi_agent_workflow import WorkflowStore
from test_multi_agent_rag import FakeEmbedding, FakeVectorStore, blocks, metadata


def long_blocks():
    return [{"page": i + 1, "text": "Scientific evaluation observations. " * 40} for i in range(19)]


def test_index_embeds_bounded_batches_and_keeps_order(tmp_path):
    class RecordingEmbedding(FakeEmbedding):
        sizes = []
        def embed(self, texts):
            self.sizes.append(len(texts))
            return super().embed(texts)
    class RecordingVectors(FakeVectorStore):
        def upsert(self, chunks, vectors):
            assert len(chunks) == len(vectors)
            self.ids = [c["chunk_id"] for c in chunks]
            super().upsert(chunks, vectors)
    embedding, vectors = RecordingEmbedding(), RecordingVectors()
    store = EvidenceStore(tmp_path / "evidence.sqlite3")
    indexer = RagIndexer(store, embedding, vectors, vector_required=True)
    result = indexer.index(metadata(), long_blocks())
    assert len(embedding.sizes) >= 3 and max(embedding.sizes) <= 8
    assert len(vectors.ids) == result["chunk_count"]
    assert not indexer.index(metadata(), long_blocks())["changed"]
    assert vectors.upserts == 1


def test_deadline_stops_cold_embedding_before_publication(tmp_path, monkeypatch):
    clock = [0.0]
    monkeypatch.setattr("multi_agent_rag.time.monotonic", lambda: clock[0])
    class SlowEmbedding(FakeEmbedding):
        calls = 0
        def embed(self, texts):
            self.calls += 1
            clock[0] += 1
            return super().embed(texts)
    embedding, vectors = SlowEmbedding(), FakeVectorStore()
    store = EvidenceStore(tmp_path / "evidence.sqlite3")
    with pytest.raises(TimeoutError, match="PDF_INDEX_DEADLINE"):
        RagIndexer(store, embedding, vectors, True).index(metadata(), long_blocks(), deadline_monotonic=1.5)
    assert embedding.calls == 2 and vectors.upserts == 0
    assert store.document_hash("doc-1") is None
    assert not store.lexical_search("Scientific")


def test_deadline_preserves_existing_complete_index_until_publication(tmp_path, monkeypatch):
    store = EvidenceStore(tmp_path / "evidence.sqlite3")
    vector = FakeVectorStore()
    indexer = RagIndexer(store, FakeEmbedding(), vector, True)
    indexer.index(metadata(), blocks())
    old_hash = store.document_hash("doc-1")
    monkeypatch.setattr("multi_agent_rag.time.monotonic", lambda: 2)
    with pytest.raises(TimeoutError):
        indexer.index(metadata("new-hash"), blocks(), deadline_monotonic=1)
    assert store.document_hash("doc-1") == old_hash and vector.upserts == 1


def test_deadline_after_upsert_rolls_back_ready_index(tmp_path, monkeypatch):
    clock = [0.0]
    monkeypatch.setattr("multi_agent_rag.time.monotonic", lambda: clock[0])
    class ExpiredVectors(FakeVectorStore):
        def upsert(self, chunks, vectors):
            clock[0] = 5
            super().upsert(chunks, vectors)
    store = EvidenceStore(tmp_path / "evidence.sqlite3")
    vector = ExpiredVectors()
    with pytest.raises(TimeoutError):
        RagIndexer(store, FakeEmbedding(), vector, True).index(metadata(), blocks(), deadline_monotonic=4)
    assert store.document_hash("doc-1") is None and vector.deleted == ["doc-1", "doc-1"]


def test_vector_count_mismatch_cannot_publish(tmp_path):
    class IncompleteEmbedding(FakeEmbedding):
        def embed(self, texts):
            return []
    store = EvidenceStore(tmp_path / "evidence.sqlite3")
    with pytest.raises(ValueError, match="EMBEDDING_BATCH_COUNT_INVALID"):
        RagIndexer(store, IncompleteEmbedding(), FakeVectorStore(), True).index(metadata(), blocks())
    assert store.document_hash("doc-1") is None


def test_failed_ready_hash_publication_removes_new_vectors(tmp_path, monkeypatch):
    store = EvidenceStore(tmp_path / "evidence.sqlite3")
    vectors = FakeVectorStore()
    def fail(_metadata, _chunks):
        raise RuntimeError("fixture publication failure")
    monkeypatch.setattr(store, "index_document", fail)
    with pytest.raises(RuntimeError, match="publication failure"):
        RagIndexer(store, FakeEmbedding(), vectors, True).index(metadata(), blocks())
    assert store.document_hash("doc-1") is None and vectors.deleted == ["doc-1", "doc-1"]


@pytest.mark.parametrize("text,page,expected", [
    ("Paper title\nAbstract\nA survey of scientific methods.", 1, "abstract_only"),
    ("Abstract\nWe review methods.\n1. Introduction\nBody supports methods.", 1, "mixed_abstract_body"),
    ("Abstract\nSummary.\n1 Introduction\nBody.", 1, "mixed_abstract_body"),
    ("An abstract representation used by a classifier.", 1, "body_or_unclassified"),
    ("Abstract\nSummary.\nTable 2 Evaluation", 1, "mixed_abstract_body"),
    ("Abstract\nSummary.", 4, "abstract_only"),
])
def test_content_scope_does_not_make_page_one_automatically_weak(text, page, expected):
    item = {"excerpt": text, "coverage_scope": "selected_chunks", "locator": {"page": page, "bbox": [1, 2, 3, 4]}}
    assert excerpt_content_scope(item) == expected
    assert evidence_strength(item) == "fulltext_located"  # old tool metadata is unchanged
    item["content_scope"] = expected
    assert evidence_strength(item) == ("abstract_only" if expected == "abstract_only" else "fulltext_located")
    assert item["locator"]["page"] == page and item["locator"]["bbox"]


@pytest.mark.parametrize("question,kind", [
    ("现在判断一张图片是否是 AI 生成的是什么技术？和 ViT 有关系吗？", "method_overview"),
    ("有哪些方法检测生成图像？", "method_overview"),
    ("SOTA和XAIGID-RewardBench各自定义与关系？", "definition_relation"),
    ("技术路线各自降低多少延迟？", "quantitative"),
    ("对比这些技术路线", "comparison"),
])
def test_method_overview_preserves_requested_intent(question, kind):
    assert answer_requirements(question)["question_kind"] == kind


def test_supervisor_timeout_sets_inspectable_pointer_and_preserves_manifest(tmp_path, monkeypatch):
    from tools import multi_agent_cli as cli
    run_id = "deadline-pointer"
    folder = tmp_path / run_id
    class ExpiredProcess:
        pid = 123
        def __init__(self, *_args, **_kwargs):
            folder.mkdir()
            WorkflowStore(folder / "workflow.sqlite3").create_run(run_id, "cli-user")
            (folder / "manifest.json").write_text(json.dumps({"run_id": run_id, "mode": "live", "prompt_version": "fixture"}), encoding="utf-8")
        def communicate(self, **_kwargs):
            raise subprocess.TimeoutExpired("fixture", 1)
    monkeypatch.setattr(cli.subprocess, "Popen", ExpiredProcess)
    monkeypatch.setattr("process_cleanup.terminate_process_tree", lambda _p: {"parent_stopped": True, "tree_stop_confirmed": True})
    args = SimpleNamespace(output_root=str(tmp_path), storage_root=str(tmp_path / "storage"),
        rag_mode="lexical", time_budget=1, query_file=None, query="question", context_file=None)
    assert cli.supervise_live(args, run_id) == 1
    manifest = json.loads((folder / "manifest.json").read_text(encoding="utf-8"))
    final = ArtifactDirectory(folder / "artifacts").get(manifest["final_artifact_id"])
    assert final["status"] == "timed_out" and final["failure_code"] == "OUTER_CLI_TIMEOUT"
    assert manifest["prompt_version"] == "fixture"
    assert (folder / "final_answer.md").is_file()


def test_live_index_receives_shared_reading_deadline(tmp_path, monkeypatch):
    from test_multi_agent_reading_batches import executor, actions
    tool, _ = executor(tmp_path)
    received = []
    def expire(_metadata, _blocks, *, deadline_monotonic):
        received.append(deadline_monotonic)
        raise TimeoutError("PDF_INDEX_DEADLINE")
    monkeypatch.setattr(tool.indexer, "index", expire)
    import time
    deadline = time.monotonic() + 20
    result = tool.execute(actions(1), group_ids={"g1"}, deadline=deadline)
    assert received and all(value == deadline for value in received)
    assert any(row["source_status"] == "pdf_index_deadline_skipped" for row in result["observations"])
