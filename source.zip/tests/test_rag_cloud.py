import json
from pathlib import Path
import shutil
from unittest.mock import patch

import pytest

from tools import rag_cloud as lock
from tools import rag_startup as startup


ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture
def locked(tmp_path):
    (tmp_path / "deepdiver_v2").mkdir()
    for name in (lock.INPUT, lock.PINS, lock.HASHES, lock.ARTIFACTS,
                 "deepdiver_v2/constraints.cloud.txt", "deepdiver_v2/requirements.cloud.hashes.txt"):
        shutil.copyfile(ROOT / name, tmp_path / name)
    return tmp_path


def mutate(root, callback):
    path = root / lock.ARTIFACTS
    value = json.loads(path.read_text(encoding="utf-8"))
    callback(value)
    path.write_text(json.dumps(value), encoding="utf-8")


def test_actual_linux_cpu_extension_is_complete_and_separate():
    result = lock.check(ROOT)
    assert result["passed"]
    assert result["base_package_count"] == 85
    assert result["rag_package_count"] == 21 and result["total_package_count"] == 106
    assert all(item["passed"] for item in result["checks"])


@pytest.mark.parametrize("mutation", [
    lambda x: x.update(platform="windows/amd64"),
    lambda x: x["artifacts"][0].update(sha256="0" * 64),
    lambda x: x["artifacts"].pop(),
    lambda x: x["artifacts"].append(x["artifacts"][0]),
    lambda x: x["artifacts"][0].update(filename="annotated_doc-0.0.5-cp311-cp311-win_amd64.whl"),
    lambda x: x["artifacts"][0].update(requires_python=">=3.12"),
    lambda x: x["artifacts"][0].update(requires_dist=["never-installed-package==1.0"]),
    lambda x: x["artifacts"][0].update(requires_dist=["numpy>=999"]),
    lambda x: x["artifacts"][0].update(requires_dist=["numpy @ https://foreign.invalid/numpy.whl"]),
])
def test_tampered_lock_fails_closed(locked, mutation):
    mutate(locked, mutation)
    assert not lock.check(locked)["passed"]


def test_linux_marker_does_not_require_windows_package(locked):
    mutate(locked, lambda x: x["artifacts"][0].update(requires_dist=['pywin32; sys_platform == "win32"']))
    assert lock.check(locked)["passed"]


def test_unknown_dependency_hash_syntax_is_rejected(locked):
    with (locked / lock.HASHES).open("a", encoding="utf-8") as handle:
        handle.write("--index-url https://secret-canary.invalid\n")
    assert not lock.check(locked)["passed"]


def test_base_dependency_cannot_be_overridden(locked):
    path = locked / lock.PINS
    path.write_text(path.read_text(encoding="utf-8") + "numpy==99.0\n", encoding="utf-8")
    assert not lock.check(locked)["passed"]


def test_verify_installed_cannot_attest_windows(locked):
    output = locked / "attestation.json"
    with patch.object(lock.sys, "platform", "win32"):
        result = lock.verify_installed(locked, output)
    assert not result["passed"] and not output.exists()


@pytest.fixture
def model_configuration(tmp_path, monkeypatch):
    model = tmp_path / "model"
    model.mkdir()
    (model / "modules.json").write_text("[]", encoding="utf-8")
    monkeypatch.setenv("SCIASSISTANT_EMBEDDING_MODEL", str(model))
    monkeypatch.setenv("SCIASSISTANT_QDRANT_URL", "http://qdrant:6333")
    monkeypatch.setenv("SCIASSISTANT_QDRANT_API_KEY", "0123456789abcdef" * 4)
    monkeypatch.setenv("SCIASSISTANT_MULTI_AGENT_WEB_RUN_ROOT", str(tmp_path / "runs"))
    monkeypatch.setenv("SCIASSISTANT_MULTI_AGENT_WEB_STORAGE_ROOT", str(tmp_path / "storage"))
    monkeypatch.setenv("SCIASSISTANT_MULTI_AGENT_VECTOR_LOCK_ROOT", str(tmp_path / "leases"))
    return model


@pytest.mark.parametrize("name,value", [
    ("SCIASSISTANT_EMBEDDING_MODEL", "intfloat/multilingual-e5-small"),
    ("SCIASSISTANT_QDRANT_API_KEY", "change-me-to-a-separate-high-entropy-key"),
    ("SCIASSISTANT_QDRANT_API_KEY", "a" * 40),
    ("SCIASSISTANT_QDRANT_URL", "http://public.invalid:6333"),
    ("SCIASSISTANT_QDRANT_URL", "https://user:password@vector.invalid"),
    ("SCIASSISTANT_QDRANT_URL", "https://vector.invalid?token=secret"),
])
def test_startup_rejects_weak_or_unsafe_configuration(model_configuration, monkeypatch, name, value):
    monkeypatch.setenv(name, value)
    with pytest.raises(ValueError):
        startup.configuration()


class Embedding:
    dimension = 384
    def embed(self, texts):
        return [[0.1] * 384]


def test_startup_retries_closes_and_passes_key_only_to_client(model_configuration):
    count, closed, waits = [], [], []
    class Client:
        def get_collections(self):
            if len(count) < 3:
                raise RuntimeError("secret-canary")
        def close(self):
            closed.append(True)
    def factory(**options):
        count.append(options)
        return Client()
    result = startup.preflight(provider_factory=lambda _: Embedding(), client_factory=factory, sleep=waits.append)
    assert result["passed"] and result["network_attempts"] == 3
    assert len(closed) == 3 and waits == [2, 2]
    assert count[0]["timeout"] == 3 and count[0]["api_key"]
    assert "secret-canary" not in json.dumps(result) and "api_key" not in json.dumps(result)


def test_startup_failure_is_bounded_and_safe(model_configuration, monkeypatch, capsys):
    calls = []
    def broken(**kwargs):
        calls.append(1)
        raise RuntimeError("secret-canary http://internal:6333")
    with pytest.raises(RuntimeError, match="VECTOR_SERVICE_UNAVAILABLE"):
        startup.preflight(provider_factory=lambda _: Embedding(), client_factory=broken, sleep=lambda _: None)
    assert len(calls) == 8
    monkeypatch.setattr(startup, "preflight", lambda: (_ for _ in ()).throw(RuntimeError("secret-canary")))
    monkeypatch.setattr(startup.sys, "argv", ["rag_startup.py"])
    assert startup.main() == 2
    assert "secret-canary" not in capsys.readouterr().out


def test_startup_rejects_wrong_dimension_before_network(model_configuration):
    embedding = Embedding()
    embedding.dimension = 3
    with pytest.raises(ValueError, match="MODEL_DIMENSION"):
        startup.preflight(provider_factory=lambda _: embedding,
                         client_factory=lambda **_: pytest.fail("must not connect"))


def test_deployment_keeps_qdrant_private_and_model_readonly():
    import yaml
    compose = yaml.safe_load((ROOT / "docker-compose.account.rag.yml").read_text(encoding="utf-8"))
    vector = compose["services"]["qdrant"]
    assert "ports" not in vector and vector["user"] == "10001:10001"
    assert vector["read_only"] and vector["cap_drop"] == ["ALL"]
    account = compose["services"]["sciassistant-account"]
    assert account["volumes"][0]["read_only"] and not account["volumes"][0]["bind"]["create_host_path"]
    assert account["environment"]["SCIASSISTANT_EMBEDDING_ALLOW_DOWNLOAD"] == "0"
    dockerfile = (ROOT / "Dockerfile.account.rag").read_text(encoding="utf-8")
    assert "--require-hashes --no-deps" in dockerfile and "pip check" in dockerfile
    assert "verify-installed" in dockerfile and "rag_startup.py &&" in dockerfile
    assert "COPY . " not in dockerfile and "USER sciassistant" in dockerfile
    assert "@sha256:" in (ROOT / "Dockerfile.qdrant").read_text(encoding="utf-8")
    # Production live uses this helper; its transitive module cannot be missing.
    for name in ("Dockerfile.account.cloud", "Dockerfile.cloud"):
        assert "multi_agent_demo_runner.py" in (ROOT / name).read_text(encoding="utf-8")
