"""Regression coverage for the account UI evidence-download proxy."""
import unittest
import tempfile
from pathlib import Path
from unittest import mock
from types import SimpleNamespace

import app as account_app
import web_app


class ScienceEvidenceProxyTests(unittest.TestCase):
    def setUp(self):
        self.auth_version = mock.patch.object(
            account_app, "_current_auth_version", return_value=0)
        self.auth_version.start()
        self.old_local_app = account_app._LOCAL_SCIENCE_APP
        self.old_tasks = web_app.TASKS.copy()
        self.old_task_owners = account_app._SCIENCE_TASK_OWNERS.copy()
        # Also protect the write path if this fixture is run outside pytest.
        self.owner_tempdir = tempfile.TemporaryDirectory(prefix="science-proxy-owners-")
        self.old_owner_path = account_app.SCIENCE_TASK_OWNER_STATE_PATH
        account_app.SCIENCE_TASK_OWNER_STATE_PATH = Path(self.owner_tempdir.name) / "owners.json"
        account_app._LOCAL_SCIENCE_APP = web_app.app
        from user_credentials import ProviderCapability
        self.provider_store_patch = mock.patch.object(account_app, '_provider_store', return_value=SimpleNamespace(
            capability=lambda owner: ProviderCapability(owner, {'MODEL_REQUEST_TOKEN':'test-only-owner-model-key'})))
        self.provider_store_patch.start(); self.addCleanup(self.provider_store_patch.stop)
        with web_app.TASK_LOCK:
            web_app.TASKS.clear()
            web_app.TASKS["evidence-proxy"] = {
                "id": "evidence-proxy",
                "status": "cancelled",
                "cancel_requested": True,
                "query": "代理证据包测试",
                "created_at": web_app._now(),
                "updated_at": web_app._now(),
                "state_timeline": [{"from": "running", "to": "cancelled"}],
            }
        with account_app._RESOURCE_OWNER_LOCK:
            account_app._SCIENCE_TASK_OWNERS.clear()
            account_app._SCIENCE_TASK_OWNERS["evidence-proxy"] = "owner-1"

    def tearDown(self):
        self.auth_version.stop()
        account_app._LOCAL_SCIENCE_APP = self.old_local_app
        with account_app._RESOURCE_OWNER_LOCK:
            account_app._SCIENCE_TASK_OWNERS.clear()
            account_app._SCIENCE_TASK_OWNERS.update(self.old_task_owners)
        account_app.SCIENCE_TASK_OWNER_STATE_PATH = self.old_owner_path
        self.owner_tempdir.cleanup()
        with web_app.TASK_LOCK:
            web_app.TASKS.clear()
            web_app.TASKS.update(self.old_tasks)

    def test_5000_proxy_downloads_cancelled_task_evidence_json(self):
        token = account_app.generate_token("owner-1", "owner")
        response = account_app.app.test_client().get(
            "/api/science/tasks/evidence-proxy/evidence?format=json",
            headers={"Authorization": f"Bearer {token}"},
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["task"]["status"], "cancelled")
        self.assertIn("sciassistant_evidence_evidence-proxy.json", response.headers["Content-Disposition"])

    def test_research_readiness_proxy_keeps_dependency_status(self):
        upstream = (b'{"status":"not_ready"}', 503, [("Content-Type", "application/json")])
        with mock.patch.object(account_app, "_science_dispatch", return_value=upstream) as dispatch:
            response = account_app.app.test_client().get("/api/science/readyz")
        self.assertEqual(response.status_code, 503)
        self.assertEqual(response.get_json(), {"status": "not_ready"})
        dispatch.assert_called_once_with("/api/readyz")

    def test_science_evidence_proxy_rejects_missing_or_wrong_owner_token(self):
        client = account_app.app.test_client()
        missing = client.get("/api/science/tasks/evidence-proxy/evidence?format=json")
        self.assertEqual(missing.status_code, 401)

        other_token = account_app.generate_token("owner-2", "other")
        cross_user = client.get(
            "/api/science/tasks/evidence-proxy/evidence?format=json",
            headers={"Authorization": f"Bearer {other_token}"},
        )
        self.assertEqual(cross_user.status_code, 404)

    def test_task_creation_binds_returned_task_id_to_jwt_owner(self):
        created = (b'{"task":{"id":"new-task"}}', 202, [("Content-Type", "application/json")])
        token = account_app.generate_token("owner-1", "owner")
        with mock.patch.object(account_app, "_science_dispatch", return_value=created):
            response = account_app.app.test_client().post(
                "/api/science/tasks", headers={"Authorization": f"Bearer {token}"}
            )
        self.assertEqual(response.status_code, 202)
        with account_app._RESOURCE_OWNER_LOCK:
            self.assertEqual(account_app._SCIENCE_TASK_OWNERS["new-task"], "owner-1")

    def test_multipart_task_creation_forwards_nonempty_query(self):
        """Parsing gateway form metadata must not consume the forwarded body."""
        token = account_app.generate_token("owner-1", "owner")
        with mock.patch.object(web_app, "_persist_task_locked"), \
             mock.patch.object(web_app, "_start_background_task", return_value=True), \
             mock.patch.object(web_app, "_enqueue_retrieval_task"):
            response = account_app.app.test_client().post(
                "/api/science/tasks",
                data={
                    "query": "用一句话解释什么是过拟合。",
                    "processing_mode": "general_answer",
                    "pdf_parse_mode": "local",
                },
                content_type="multipart/form-data",
                headers={"Authorization": f"Bearer {token}"},
            )
        self.assertEqual(response.status_code, 202)
        task = response.get_json()["task"]
        self.assertEqual(task["query"], "用一句话解释什么是过拟合。")
        self.assertEqual(task["processing_mode"], "general_answer")

    def test_task_creation_rejects_foreign_conversation_before_dispatch(self):
        token = account_app.generate_token("owner-1", "owner")
        connection = mock.MagicMock()
        cursor = connection.cursor.return_value.__enter__.return_value
        cursor.fetchone.return_value = None
        with mock.patch.object(account_app, "get_db_connection", return_value=connection), \
             mock.patch.object(account_app, "_science_dispatch") as dispatch:
            response = account_app.app.test_client().post(
                "/api/science/tasks",
                json={"query": "offline", "conversation_id": "another-users-session"},
                headers={"Authorization": f"Bearer {token}"},
            )
        self.assertEqual(response.status_code, 404)
        dispatch.assert_not_called()
        cursor.execute.assert_called_once()

    def test_task_creation_allows_owned_conversation(self):
        token = account_app.generate_token("owner-1", "owner")
        connection = mock.MagicMock()
        cursor = connection.cursor.return_value.__enter__.return_value
        cursor.fetchone.return_value = {"owned": 1}
        created = (b'{"task":{"id":"owned-conversation-task"}}', 202,
                   [("Content-Type", "application/json")])
        with mock.patch.object(account_app, "get_db_connection", return_value=connection), \
             mock.patch.object(account_app, "_science_dispatch", return_value=created):
            response = account_app.app.test_client().post(
                "/api/science/tasks",
                json={"query": "offline", "conversation_id": "owned-session"},
                headers={"Authorization": f"Bearer {token}"},
            )
        self.assertEqual(response.status_code, 202)
        self.assertEqual(account_app._SCIENCE_TASK_OWNERS["owned-conversation-task"], "owner-1")


if __name__ == "__main__":
    unittest.main()
