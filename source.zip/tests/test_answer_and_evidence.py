import unittest

from deepdiver_v2.src.answer_contract import build_answer_contract, validate_answer_structure
from deepdiver_v2.src.evidence_blocks import build_evidence_blocks, select_evidence_blocks


class AnswerEvidenceTests(unittest.TestCase):
    def test_evidence_blocks_keep_location(self):
        parsed = {
            "pages": [{"page": 3, "risk_flags": ["two_column_uncertain"]}],
            "layout_blocks": [{"text": "3 Segment Anything Task", "page": 3, "bbox": [1, 2, 3, 4]}, {"text": "The task is promptable.", "page": 3, "bbox": [5, 6, 7, 8]}],
        }
        blocks = build_evidence_blocks(parsed)
        self.assertEqual(blocks[1]["page"], 3)
        self.assertEqual(blocks[1]["bbox"], [5, 6, 7, 8])
        self.assertIn("two_column_uncertain", blocks[1]["risk_flags"])
        self.assertFalse(blocks[1]["citation_allowed"])
        self.assertEqual(select_evidence_blocks(blocks, "promptable")[0]["text"], "The task is promptable.")

    def test_answer_contract_detects_missing_boundary(self):
        contract = build_answer_contract({"task_type": "section_summary"})
        self.assertEqual(validate_answer_structure("这是一个足够长但没有证据边界的回答。" * 4, contract)["status"], "needs_review")
        self.assertEqual(validate_answer_structure("直接回答：这是结论。依据见第 3 页；限制是表格解析风险。" * 2, contract)["status"], "passed")

    def test_answer_contract_detects_scope_drift(self):
        contract = build_answer_contract({"task_type": "section_summary", "target": "Dataset"})
        result = validate_answer_structure("论文概览：本文主要提出一个模型。依据见第 1 页。" * 3, contract)
        self.assertIn("scope_drift", result["missing"])

    def test_answer_contract_does_not_accept_bare_evidence_word(self):
        contract = build_answer_contract({"task_type": "section_summary"})
        result = validate_answer_structure("这是一个回答，但依据这个词没有提供定位信息。" * 3, contract)
        self.assertIn("evidence_boundary", result["missing"])


if __name__ == "__main__":
    unittest.main()
