"""Preserve validated explicit approvals, never infer a scientific verdict."""
from copy import deepcopy
import json

import pytest

from multi_agent_quality import (AUDIT_ROW_RETENTION_POLICY, AUDIT_PROTOCOL_POLICY,
    check_audit, publication_rejections, retain_valid_audit_rows)
from test_multi_agent_report_fields import draft, evidence, QUOTE
from test_multi_agent_absence_basis import audit


def case():
    data, sources = draft(), evidence()
    data.update(audit_row_retention_policy=AUDIT_ROW_RETENTION_POLICY,
                audit_protocol_policy=AUDIT_PROTOCOL_POLICY)
    base = data['claims'][0]
    data['claims'] = [{**deepcopy(base),'claim_id':key} for key in ['c1','c2','c3']]
    data['claims'][2]['depends_on_claim_ids'] = ['c1']
    old, new = audit(data), audit(data)
    old['claim_results'][1]['source_witnesses'][0]['quote'] = 'fabricated earlier witness not found in the paper'
    new['claim_results'][0]['source_witnesses'][0]['quote'] = 'fabricated later witness not found in the paper'
    return data, sources, old, new


def retain(data,sources,old,new,context=None):
    return retain_valid_audit_rows(old,new,data,sources,
        prior_context=deepcopy({'draft':data,'evidence':sources}) if context is None else context)


def test_quote_regression_keeps_exact_approved_row_and_dependent_direct_answer():
    data,sources,old,new = case()
    before = deepcopy((data,sources,old,new))
    assert publication_rejections(check_audit(old,data,sources),data) == {'c2'}
    assert publication_rejections(check_audit(new,data,sources),data) == {'c1','c3'}
    result, receipt = retain(data,sources,old,new)
    assert receipt['retained_claim_ids'] == ['c1'] and not receipt['semantic_auto_approval']
    assert result['claim_results'][0] == old['claim_results'][0]
    assert not publication_rejections(result,data)
    assert (data,sources,old,new) == before


@pytest.mark.parametrize('fault',['new_rejection','new_field_problem','new_absence','new_protocol',
    'prior_bad','prior_dependency_bad','schema','global_contradiction','old_policy','code_issue'])
def test_new_disagreement_or_non_quote_failure_never_borrows_an_old_approval(fault):
    data,sources,old,new = case()
    if fault in ['new_rejection','new_field_problem']:
        row = new['claim_results'][0]
        row.update(decision='rejected',reason_code='UNSUPPORTED_CLAIM')
        row['field_results']['text'].update(status='unsupported',detail='科学问题未解决。')
        new.update(status='needs_review',rejected_claim_ids=['c1'],issues=[{'claim_id':'c1','reason_code':'UNSUPPORTED_CLAIM'}])
    if fault == 'new_absence':
        data['claims'][0]['qualification'] = '论文未报告验证。'
        new['claim_results'][0]['field_results']['qualification']['absence_checks'] = [
            {'assertion':'论文未报告验证。','basis':'selected_excerpts','witness_index':None}]
    if fault == 'new_protocol':
        new['claim_results'][0]['field_results']['qualification']['absence_checks'] = [
            {'assertion':'not in this actual field','basis':'selected_excerpts','witness_index':None}]
    if fault == 'prior_bad': old['claim_results'][0]['source_witnesses'] = []
    if fault == 'prior_dependency_bad': data['claims'][0]['depends_on_claim_ids'] = ['c2']
    if fault == 'schema': old['schema_version'] = 'sciassistant.citation-audit/v4'
    if fault == 'global_contradiction': new['rejected_claim_ids'] = ['c1']
    if fault == 'old_policy': data.pop('audit_row_retention_policy')
    if fault == 'code_issue': new['code_issues'] = [{'claim_id':'c1','reason':'UNSUPPORTED_NUMBER'}]
    _, receipt = retain(data,sources,old,new)
    assert not receipt['retained_claim_ids']


@pytest.mark.parametrize('field',['draft','evidence'])
def test_changed_actual_input_never_reuses_a_previous_audit(field):
    data,sources,old,new = case()
    context=deepcopy({'draft':data,'evidence':sources})
    if field == 'draft': data['claims'][0]['text'] += ' Changed scientific scope.'
    else: sources['evidence'][0]['excerpt'] += ' Changed original source.'
    _, receipt=retain(data,sources,old,new,context)
    assert receipt['reason_code']=='AUDIT_INPUT_CHANGED' and not receipt['retained_claim_ids']


def test_unapproved_old_quote_cannot_be_retained():
    data,sources,old,new = case()
    sources['evidence'][0]['review_status']='pending'
    result,receipt=retain(data,sources,old,new)
    assert not receipt['retained_claim_ids']
    assert 'c1' in publication_rejections(check_audit(result,data,sources),data)


def test_full_workflow_correction_does_not_destroy_an_earlier_valid_direct_answer(tmp_path):
    from test_multi_agent_pipeline_v2 import agents,pipeline
    configured,calls=agents()
    data,sources,_,_=case()
    for row in data['claims']: row['evidence_ids']=['arxiv-1']
    def writer(_): calls.append('writer');return {'output':data}
    count=[]
    def auditor(_):
        calls.append('citation_auditor');count.append(True)
        value=audit(data)
        value['claim_results'][1 if len(count)==1 else 0]['source_witnesses']=[]
        return {'output':value}
    configured.writer.handler,configured.citation_auditor.handler=writer,auditor
    flow,_=pipeline(tmp_path,configured,search=lambda *_:{'status':'ok','papers':[
        {'paper_id':'1','title':'Method','abstract':QUOTE}]})
    result=flow.run('audit-continuity','owner','Explain the method')
    assert result['run']['model_calls_used']==6
    assert calls.count('citation_auditor')==2 and calls.count('writer')==1
    # Check the actual stored final audit, not a toy direct rendering.
    final=flow.artifacts.get(result['final_artifact_id'])
    artifact_refs=final['artifact_refs']
    checked=flow.artifacts.get(artifact_refs['audit'])
    assert not publication_rejections(checked,flow.artifacts.get(artifact_refs['draft']))
    events=[json.loads(line) for line in (tmp_path/'events.jsonl').read_text(encoding='utf8').splitlines()]
    retained=next(e for e in events if e['event']=='audit_valid_rows_retained')
    assert retained['claim_ids']==['c1'] and not retained['semantic_auto_approval']


@pytest.mark.parametrize('valid',[True,False])
def test_live_harness_uses_the_existing_followup_context_contract(tmp_path,valid):
    from audit_continuity_development_20261016.run_live_cases import CONTEXT_POLICY
    from test_multi_agent_pipeline_v2 import agents,pipeline
    configured,calls=agents()
    flow,_=pipeline(tmp_path,configured)
    context={'schema_version':'sciassistant.followup-context/v1','previous_question':'Prior question',
        'previous_answer':'Prior answer is background only.','paper_ids':['2106.09685v2'],
        'evidence_policy':CONTEXT_POLICY if valid else 'background_only_retrieve_and_review_again'}
    result=flow.run('context-check','owner','Follow-up question',conversation_context=context)
    assert result['run']['model_calls_used']==(5 if valid else 0)
    assert result['run']['status']==('completed' if valid else 'failed')
