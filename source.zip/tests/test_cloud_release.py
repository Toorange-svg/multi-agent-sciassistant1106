"""Offline packaging gates, startup identity, env redaction and real GET smoke."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import threading
import hashlib

import pytest
from werkzeug.serving import make_server

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "deepdiver_v2"))
from runtime_identity import RuntimeIdentity, IDENTITY_FILES
from tools import cloud_release as release
import app as gateway
import web_app


def project_image(destination):
    """Projection of explicit COPY inputs, NOT a claim of Docker engine build."""
    for name in release.REQUIRED + IDENTITY_FILES + ("deepdiver_v2/env.template",):
        target = destination / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, target)
    for relative in ("deepdiver_v2/src", "deepdiver_v2/config"):
        for source in (ROOT / relative).rglob("*.py"):
            target = destination / source.relative_to(ROOT)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
    for relative in ('chatAi/assets', 'chatAi/vendor'):
        shutil.copytree(ROOT / relative, destination / relative, dirs_exist_ok=True)
    constraints = destination / "deepdiver_v2/constraints.cloud.txt"
    artifacts = destination / "deepdiver_v2/requirements.cloud.hashes.txt"
    (destination / ".dependency-lock.json").write_text(json.dumps({
        "schema": "sciassistant.dependency-lock/v2",
        "sha256": hashlib.sha256(artifacts.read_bytes()).hexdigest(),
        "constraints_sha256": hashlib.sha256(constraints.read_bytes()).hexdigest(),
        "package_count": 85,
        "python": "3.11.14",
        "base_image": release.BASE_IMAGE,
        "platform": "linux/amd64",
    }), encoding="utf-8")


def valid_env():
    return {"APP_ENV": "production", "SECRET_KEY": "jwt-canary-" + "z" * 40,
            "PYMUPDF_LICENSE_MODE": "commercial", "PYMUPDF_COMMERCIAL_LICENSE_CONFIRMED": "true",
            "MCP_SHARED_SECRET": "mcp-canary-" + "m" * 40,
            "ACCOUNT_BIND_ADDRESS": "127.0.0.1", "ACCOUNT_HOST_PORT": "5000",
            "MYSQL_APP_USER": "staging", "MYSQL_APP_PASSWORD": "app-canary-123456",
            "MYSQL_MIGRATION_USER": "staging_migrator", "MYSQL_MIGRATION_PASSWORD": "migration-canary-123456",
            "MYSQL_ROOT_PASSWORD": "root-canary-987654", "MODEL_REQUEST_TOKEN": "",
            "MODEL_REQUEST_URL": "https://provider.invalid/v1/chat/completions",
            "SCIASSISTANT_BUILD_REVISION": "123abcd"}


def write_env(path, values):
    path.write_text("\n".join(f"{k}={v}" for k, v in values.items()), encoding="utf-8")


def agpl_env():
    return {**valid_env(), "PYMUPDF_LICENSE_MODE": "agpl",
            "PYMUPDF_COMMERCIAL_LICENSE_CONFIRMED": "false",
            "PYMUPDF_AGPL_OBLIGATIONS_CONFIRMED": "true",
            "PYMUPDF_CORRESPONDING_SOURCE_CONFIRMED": "true",
            "PYMUPDF_SOURCE_URL": "https://sources.university.edu/sciassistant/release-01"}


def test_agpl_attestation_does_not_require_commercial_license(tmp_path):
    path = tmp_path / "private.env"
    write_env(path, agpl_env())
    report = release.env_checks(path)
    assert report["passed"], report
    assert "agpl_operator_attestation_only_source_delivery_requires_manual_verification" in report["warnings"]


@pytest.mark.parametrize("key,value", [
    ("PYMUPDF_AGPL_OBLIGATIONS_CONFIRMED", "false"),
    ("PYMUPDF_CORRESPONDING_SOURCE_CONFIRMED", "false"),
    ("PYMUPDF_SOURCE_URL", ""),
    ("PYMUPDF_SOURCE_URL", "https://example.com/source"),
    ("PYMUPDF_SOURCE_URL", "https://source.invalid/release"),
    ("PYMUPDF_SOURCE_URL", "https://user:password@source.university.edu/code"),
    ("PYMUPDF_SOURCE_URL", "https://source.university.edu/code?token=private"),
    ("PYMUPDF_SOURCE_URL", "http://source.university.edu/code"),
    ("PYMUPDF_LICENSE_MODE", "unknown"),
])
def test_agpl_requires_source_delivery_attestations(tmp_path, key, value):
    path = tmp_path / "private.env"
    write_env(path, {**agpl_env(), key: value})
    assert not release.env_checks(path)["passed"]


def test_repository_packaging_preflight():
    report = release.file_checks(ROOT)
    assert report["passed"], report
    dockerfile = (ROOT / "Dockerfile.account.cloud").read_text()
    assert "COPY . " not in dockerfile
    assert "chatAi/" not in (ROOT / ".dockerignore").read_text().splitlines()
    rules = (ROOT / "Dockerfile.account.cloud.dockerignore").read_text().splitlines()
    assert rules[1] == "**"
    assert "!tools/run_research.py" in rules and "**/*.sql" in rules
    gitignore = (ROOT / '.gitignore').read_text()
    assert '.env.*' in gitignore.splitlines() and '!.env.*.example' in gitignore.splitlines()


def test_projected_image_check_and_build_stamp(tmp_path):
    project_image(tmp_path)
    assert release.file_checks(tmp_path, image=True)["passed"]
    assert release.stamp(tmp_path, "123abcd")["passed"]
    runtime = RuntimeIdentity("account_gateway", tmp_path).snapshot()
    assert runtime["source_complete"] and runtime["image_revision"] == "123abcd"
    assert runtime["image_source_matches_startup"] is True
    assert runtime["dependency_lock"]["package_count"] == 85
    assert runtime["dependency_lock"]["base_image"] == release.BASE_IMAGE
    assert runtime["dependency_lock"]["platform"] == "linux/amd64"


@pytest.mark.parametrize("missing", ["chatAi/login.html", "chatAi/images/logo.png", "tools/run_research.py", "multi_agent_quality.py"])
def test_image_gate_rejects_missing_runtime_files(tmp_path, missing):
    project_image(tmp_path)
    (tmp_path / missing).unlink()
    assert not release.file_checks(tmp_path, image=True)["passed"]
    assert not release.stamp(tmp_path, "123abcd")["passed"]
    assert not (tmp_path / ".build-info.json").exists()


@pytest.mark.parametrize("private", [".env", "deepdiver_v2/config/.env", "chatAi/chatai.sql",
                                     "deepdiver_v2/src/.env.staging", "deepdiver_v2/src/dump.sql"])
def test_image_gate_rejects_private_configuration_and_dump(tmp_path, private):
    project_image(tmp_path)
    (tmp_path / private).write_text("private-canary", encoding="utf-8")
    report = release.file_checks(tmp_path, image=True)
    assert not report["passed"]
    assert "private-canary" not in json.dumps(report)


def test_startup_fingerprint_detects_live_disk_changes(tmp_path):
    project_image(tmp_path)
    identity = RuntimeIdentity("research_web", tmp_path)
    before = identity.snapshot()
    (tmp_path / "web_app.py").write_text("changed-code", encoding="utf-8")
    after = identity.snapshot()
    assert before["code_on_disk_matches_startup"] is True
    assert after["code_on_disk_matches_startup"] is False
    assert after["source_fingerprint"] == before["source_fingerprint"]
    assert before["instance_id"] == after["instance_id"]
    assert str(tmp_path) not in json.dumps(after)


def test_malformed_build_revision_cannot_leak_values(tmp_path):
    project_image(tmp_path)
    (tmp_path / ".build-info.json").write_text(json.dumps({"revision": "Authorization: private-canary"}))
    report = RuntimeIdentity("research_web", tmp_path).snapshot()
    assert report["image_revision"] == "unknown"
    assert report["image_source_matches_startup"] is False
    assert "private-canary" not in json.dumps(report)
    assert not release.stamp(tmp_path, "private-canary")["passed"]


@pytest.mark.parametrize('content', ['not-json', '[]', '{}', 'null'])
def test_present_invalid_stamp_fails_instead_of_being_unstamped(tmp_path, content):
    project_image(tmp_path)
    (tmp_path / '.build-info.json').write_text(content)
    runtime = RuntimeIdentity('account_gateway', tmp_path).snapshot()
    assert runtime['image_revision'] == 'unknown'
    assert runtime['image_source_matches_startup'] is False


def test_valid_env_and_no_values_in_report(tmp_path):
    path = tmp_path / "private.env"
    values = valid_env()
    write_env(path, values)
    report = release.env_checks(path)
    assert report["passed"], report
    assert all(values[key] not in json.dumps(report) for key in (
        "SECRET_KEY", "MCP_SHARED_SECRET", "MYSQL_APP_PASSWORD", "MYSQL_MIGRATION_PASSWORD"))


@pytest.mark.parametrize('field',['MODEL_REQUEST_TOKEN','MODEL_REQUEST_TOKENS','LLAMA_CLOUD_API_KEY'])
def test_account_deployment_rejects_shared_provider_secrets(tmp_path,field):
    values=valid_env();values[field]='not-a-real-provider-shared-key'
    path=tmp_path/'private.env';write_env(path,values)
    report=release.env_checks(path)
    assert not report['passed']
    assert {'check':'account_shared_provider_keys_absent','passed':False} in report['checks']


@pytest.mark.parametrize("key,value", [
    ("SECRET_KEY", "change-me"), ("MYSQL_APP_USER", "root"),
    ("MCP_SHARED_SECRET", "change-me"),
    ("MYSQL_APP_PASSWORD", "REPLACE_WITH_PRIVATE"), ("MYSQL_MIGRATION_USER", "root"),
    ("MYSQL_MIGRATION_PASSWORD", "REPLACE_WITH_PRIVATE"), ("MODEL_REQUEST_TOKEN", "REPLACE_WITH_PRIVATE"),
    ("SCIASSISTANT_TASK_WORKERS", "2"), ("ARXIV_PAPER_TASK_TIMEOUT", "29"),
    ("ARXIV_PAPER_CONTEXT_CHARS", "999999"), ("MODEL_REQUEST_URL", "https://user:secret@provider.invalid/chat"),
    ("MODEL_REQUEST_URL", "https://provider.invalid/chat?token=private-canary"),
    ("CORS_ALLOWED_ORIGINS", "*"), ("CORS_ALLOWED_ORIGINS", "http://ui.example.invalid"),
    ("CORS_ALLOWED_ORIGINS", "https://user:secret@ui.example.invalid"),
    ("CORS_ALLOWED_ORIGINS", "https://ui.example.invalid/path"),
    ("AUTH_LOGIN_IDENTITY_LIMIT", "0"), ("AUTH_LOGIN_CLIENT_LIMIT", "5001"),
    ("AUTH_LOGIN_WINDOW_SECONDS", "not-a-number"), ("AUTH_REGISTER_IDENTITY_LIMIT", "0"),
    ("AUTH_REGISTER_WINDOW_SECONDS", "86401"), ("AUTH_RATE_LIMIT_MAX_KEYS", "99"),
    ("ACCOUNT_BIND_ADDRESS", "0.0.0.0"), ("ACCOUNT_BIND_ADDRESS", "192.168.1.10"),
    ("ACCOUNT_BIND_ADDRESS", "localhost"), ("ACCOUNT_HOST_PORT", "0"),
    ("ACCOUNT_HOST_PORT", "65536"),
    ("PYMUPDF_LICENSE_MODE", "review-required"),
    ("PYMUPDF_LICENSE_MODE", "agpl"),
    ("PYMUPDF_COMMERCIAL_LICENSE_CONFIRMED", "off"),
    ("ACCOUNT_MEMORY_LIMIT", "0"), ("ACCOUNT_MEMORY_LIMIT", "64m"),
    ("MCP_MEMORY_LIMIT", "unlimited"), ("MYSQL_MEMORY_LIMIT", "9g"),
    ("SCHEMA_MEMORY_LIMIT", "64m"), ("ACCOUNT_CPU_LIMIT", "0"),
    ("MCP_CPU_LIMIT", "9"), ("MYSQL_CPU_LIMIT", "nan"),
    ("SCHEMA_CPU_LIMIT", "invalid"), ("ACCOUNT_PIDS_LIMIT", "-1"),
    ("MCP_PIDS_LIMIT", "0"), ("MYSQL_PIDS_LIMIT", "2048"),
    ("SCHEMA_PIDS_LIMIT", "1024"),
])
def test_unsafe_env_is_rejected_without_value_echo(tmp_path, key, value):
    path = tmp_path / "private.env"
    write_env(path, {**valid_env(), key: value})
    report = release.env_checks(path)
    assert not report["passed"]
    assert all(set(item) == {"check", "passed"} and type(item["passed"]) is bool for item in report["checks"])
    if len(value) > 4:
        assert value not in json.dumps(report)


def test_database_identities_and_passwords_must_all_be_distinct(tmp_path):
    values = valid_env()
    path = tmp_path / "private.env"
    write_env(path, {**values, "MYSQL_MIGRATION_USER": values["MYSQL_APP_USER"]})
    assert not release.env_checks(path)["passed"]
    write_env(path, {**values, "MYSQL_MIGRATION_PASSWORD": values["MYSQL_APP_PASSWORD"]})
    assert not release.env_checks(path)["passed"]


def test_http_requires_explicit_override_and_example_env_fails(tmp_path):
    path = tmp_path / "private.env"
    write_env(path, {**valid_env(), "MODEL_REQUEST_URL": "http://127.0.0.1:9876/model"})
    assert not release.env_checks(path)["passed"]
    assert release.env_checks(path, allow_http_model=True)["passed"]
    assert not release.env_checks(ROOT / ".env.account.cloud.example")["passed"]


def test_release_env_accepts_empty_or_exact_https_cors_origins(tmp_path):
    path = tmp_path / "private.env"
    write_env(path, {**valid_env(), "CORS_ALLOWED_ORIGINS": ""})
    assert release.env_checks(path)["passed"]


def test_enabled_password_reset_requires_https_tls_and_private_smtp(tmp_path):
    path = tmp_path / "private.env"
    reset = {
        "PASSWORD_RESET_ENABLED": "true",
        "PASSWORD_RESET_BASE_URL": "https://science.invalid/forgot-password.html",
        "PASSWORD_RESET_TOKEN_TTL_SECONDS": "900",
        "SMTP_HOST": "smtp.invalid",
        "SMTP_PORT": "587",
        "SMTP_USERNAME": "mailer",
        "SMTP_PASSWORD": "smtp-canary-123456",
        "SMTP_FROM": "noreply@science.invalid",
        "SMTP_USE_TLS": "true",
    }
    write_env(path, {**valid_env(), **reset})
    report = release.env_checks(path)
    assert report["passed"], report
    assert reset["SMTP_PASSWORD"] not in json.dumps(report)
    for key, value in (
        ("PASSWORD_RESET_BASE_URL", "http://science.invalid/reset"),
        ("SMTP_USE_TLS", "false"),
        ("SMTP_PASSWORD", "change-me"),
        ("PASSWORD_RESET_TOKEN_TTL_SECONDS", "60"),
    ):
        write_env(path, {**valid_env(), **reset, key: value})
        assert not release.env_checks(path)["passed"]
    write_env(path, {**valid_env(), "CORS_ALLOWED_ORIGINS": "https://ui.example.invalid;https://admin.example.invalid:8443"})
    assert release.env_checks(path)["passed"]


def test_env_parse_errors_and_missing_file_are_safe(tmp_path):
    path = tmp_path / "private.env"
    path.write_text('SECRET_KEY="private-canary\n', encoding="utf-8")
    assert not release.env_checks(path)["passed"]
    assert not release.env_checks(tmp_path / "missing")["passed"]
    assert "private-canary" not in json.dumps(release.env_checks(path))


def test_gateway_and_research_health_have_distinct_loaded_identity():
    gateway_runtime = gateway.app.test_client().get("/api/health").get_json()["runtime"]
    research_runtime = web_app.app.test_client().get("/api/health").get_json()["runtime"]
    assert gateway_runtime["component"] == "account_gateway"
    assert research_runtime["component"] == "research_web"
    assert gateway_runtime["instance_id"] != research_runtime["instance_id"]
    assert gateway_runtime["code_on_disk_matches_startup"] is True
    evidence = web_app._task_evidence_payload({"id": "identity-offline", "status": "failed"})
    assert evidence["build"]["exporter_runtime"]["instance_id"] == research_runtime["instance_id"]
    assert "runtime" not in evidence["lifecycle"]["execution"]  # never invent old-task runtime


def test_actual_gateway_get_smoke_never_logs_in_or_posts():
    seen = []

    def record(environ, start_response):
        seen.append((environ["REQUEST_METHOD"], environ["PATH_INFO"], environ.get("HTTP_AUTHORIZATION")))
        return gateway.app(environ, start_response)

    server = make_server("127.0.0.1", 0, record)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        report = release.smoke(f"http://127.0.0.1:{server.server_port}")
        assert report["passed"], report
        assert len(seen) == 7 and all(method == "GET" and auth is None for method, _, auth in seen)
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)


@pytest.mark.parametrize("url", ["http://user:secret@localhost", "file:///private", "https://remote.invalid", "http://localhost/?token=secret"])
def test_smoke_rejects_unsafe_targets_without_network(url):
    assert not release.smoke(url)["passed"]


def test_projected_image_import_serves_frontend_without_private_env(tmp_path):
    project_image(tmp_path)
    assert release.stamp(tmp_path, "123abcd")["passed"]
    environment = {**os.environ, "SECRET_KEY": "offline-stable-jwt-key", "APP_ENV": "test",
                   "SCIASSISTANT_TASK_STATE_DIR": str(tmp_path / "task-state"), "PYTHONUTF8": "1"}
    script = """
import app
c=app.app.test_client()
for path in ['/', '/login.html', '/ai_chat.html', '/images/logo.png']:
    assert c.get(path).status_code == 200
r=c.get('/api/health').get_json()['runtime']
assert r['image_revision']=='123abcd' and r['image_source_matches_startup']
assert c.get('/api/science/tasks/none').status_code==401
print('projected_image_entrypoints_pass')
"""
    process = subprocess.run([sys.executable, "-c", script], cwd=tmp_path, env=environment,
                             capture_output=True, timeout=25)
    assert process.returncode == 0, process.stderr.decode("utf-8", errors="replace")[-1500:]
    assert b"projected_image_entrypoints_pass" in process.stdout
