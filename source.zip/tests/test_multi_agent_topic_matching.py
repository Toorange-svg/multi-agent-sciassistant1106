"""Reading-order regressions: metadata matches are not approval decisions."""
import time

import pytest

from multi_agent_live import READING_PRIORITY_POLICY, rank_read_candidates, read_candidate_priority, topic_term_matches
from test_multi_agent_reading_batches import executor


@pytest.mark.parametrize("term,noisy,title", [
    ("GAN", "Organic molecules", "Generative adversarial networks"),
    ("ViT", "Invitation modeling", "Vision Transformer backbone"),
    ("LoRA", "Floral image benchmarks", "Low-rank adaptation"),
    ("NF4", "NF40 unrelated method", "NormalFloat quantization"),
])
def test_whole_entity_in_abstract_beats_embedded_title_substring(term, noisy, title):
    papers = [{"paper_id": "noise", "title": noisy}, {"paper_id": "relevant", "title": title, "abstract": term}]
    ranked = rank_read_candidates(papers, [], core=[term])
    assert [p["paper_id"] for p in ranked] == ["relevant", "noise"]
    assert read_candidate_priority(papers[0], [], core=[term])["score"] == 0
    assert len(ranked) == len(papers)  # No silent filtering or approval.


@pytest.mark.parametrize("term,text", [
    ("ViT", "CLIP-ViT模型"), ("ViT", "ＶｉＴ backbone"),
    ("GAN", "GANs and RNNs"), ("RNN", "GANs and RNNs"),
    ("low rank adaptation", "Low–Rank_Adaptation"),
    ("PagedAttention", "PagedAttention机制"),
    ("vision transformer", "Vision\nTransformers"),
])
def test_typographic_and_regular_plural_variants(term, text):
    assert topic_term_matches(term, text)


@pytest.mark.parametrize("term,text", [
    ("GAN", "organic"), ("ViT", "invitation"), ("LoRA", "QLoRA"),
    ("NF4", "NF40"), ("GAN", "GAN2"), ("ViT", "ViTsized"),
    ("low rank adaptation", "adaptation of low rank"), ("", "anything"),
])
def test_no_substring_prefix_or_phrase_reordering(term, text):
    assert not topic_term_matches(term, text)


def test_weights_hints_generic_exclusion_and_stable_ties():
    paper = {"title": "GAN low-rank adaptation", "abstract": "GAN"}
    score = read_candidate_priority(paper, [], core=["GAN", "latency"], support=["low rank adaptation"])
    assert score == {"policy": READING_PRIORITY_POLICY, "score": 13, "exact_title_hint": False,
                     "core_title_matches": ["gan"], "core_abstract_matches": ["gan"],
                     "support_title_matches": ["low rank adaptation"]}
    hint = {"title": "An Original Method"}
    assert rank_read_candidates([paper, hint], [], core=["GAN"], source_hints=["An Original Method"])[0] == hint
    tied = [{"title": "organic", "paper_id": "a"}, {"title": "invitation", "paper_id": "b"}]
    assert rank_read_candidates(tied, [], core=["GAN"]) == tied


def test_query_fallback_uses_same_token_boundary():
    papers = [{"title": "Invitation"}, {"title": "ViT"}]
    assert rank_read_candidates(papers, ['(ti:"ViT" OR abs:"ViT")'])[0]["title"] == "ViT"


def test_executor_reads_relevant_first_and_records_explanation(tmp_path):
    tool, downloads = executor(tmp_path)
    tool.search_function = lambda *_args, **_kwargs: {"status": "ok", "papers": [
        {"paper_id": "2301.00001v1", "title": "Organic molecules", "abstract": "Chemistry study"},
        {"paper_id": "2301.00002v1", "title": "Generative adversarial networks", "abstract": "GAN study"}]}
    tool.configure_plan({"groups": [{"id": "g1", "question": "GAN?", "core": ["GAN"], "support": []}]})
    # A weak previously cited paper cannot regain first place via 'organic'.
    tool.configure_source_clues({"previous_paper_ids": ["2301.00001v1"], "explicit_entities": ["GAN"]})
    result = tool.execute([{"request_id": "r1", "action": "request_arxiv_search",
        "arguments": {"query": '(ti:"GAN" OR abs:"GAN")', "group_id": "g1"}}],
        group_ids={"g1"}, deadline=time.monotonic() + 60)
    assert downloads == ["2301.00002v1", "2301.00001v1"]
    observations = [row for row in result["observations"] if row.get("source_status") == "reading_selected"]
    assert observations[0]["reading_priority"]["score"] == 2
    assert observations[0]["reading_priority"]["core_abstract_matches"] == ["gan"]
    assert observations[1]["reading_priority"]["previous_source_preferred"] is False
    decisions = tool.reading_decisions("BUDGET_REACHED")
    assert all(row["selection"] == "selected" for row in decisions)
    assert all(row["reading_priority"]["policy"] == READING_PRIORITY_POLICY for row in decisions)
    assert all("approved" not in row for row in decisions)
