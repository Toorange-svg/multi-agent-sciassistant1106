"""Direct research UI/API responses carry baseline browser protections."""

import web_app


def test_research_page_and_api_have_baseline_security_headers():
    client = web_app.app.test_client()
    for response in (client.get("/"), client.get("/api/health")):
        assert response.headers["X-Content-Type-Options"] == "nosniff"
        assert response.headers["X-Frame-Options"] == "DENY"
        assert response.headers["Referrer-Policy"] == "no-referrer"
        assert response.headers["Permissions-Policy"] == "camera=(), microphone=(), geolocation=()"
        assert response.headers["Cross-Origin-Opener-Policy"] == "same-origin"
        assert response.headers["Cross-Origin-Resource-Policy"] == "same-origin"


def test_research_api_is_no_store_but_static_page_can_use_normal_cache_policy():
    client = web_app.app.test_client()
    assert client.get("/api/health").headers["Cache-Control"] == "no-store"
    assert client.get("/api/settings/api-keys").headers["Cache-Control"] == "no-store"
    assert client.get("/").headers.get("Cache-Control") != "no-store"
