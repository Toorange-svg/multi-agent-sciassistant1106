from __future__ import annotations

from multi_agent_literature_adapters import LiteratureRoleAdapters


def test_adapters_exchange_bounded_structured_objects_without_provider_or_store_handles():
    calls = []

    def model(role, payload):
        calls.append((role, payload))
        if role == "planner":
            return {"groups": [{"topic": "KV cache", "queries": ["KV cache quantization"]}]}
        if role == "reviewer":
            return {"coverage_status": "partial", "supported_claims": ["claim-a"],
                    "unsupported_questions": ["latency without direct experiment"], "conflicts": [],
                    "allowed_evidence_ids": [payload["evidence"][0]["evidence_id"]]}
        if role == "writer":
            evidence_id = payload["evidence"][0]["evidence_id"]
            return {"answer": "仅有有限证据。", "coverage_status": "partial",
                    "unresolved_questions": ["缺少直接实验"],
                    "claim_evidence_map": [{"claim_id": "claim-a", "evidence_ids": [evidence_id]}]}
        return {"status": "passed", "rejected_claim_ids": [],
                "claim_results": [{"claim_id": "claim-a", "evidence_ids": ["evidence-placeholder"], "status": "supported"}]}

    def search(query, limit):
        assert query == "KV cache quantization" and limit == 5
        return {"status": "ok", "papers": [{"paper_id": "2401.00001", "title": "KIVI", "source": "arxiv",
                                                  "abstract": "A bounded abstract.", "year": "2024"}]}

    adapters = LiteratureRoleAdapters(model, search)
    plan = adapters.planner({"question": "KV 缓存量化有什么证据？"})
    evidence = adapters.retriever(plan["groups"][0])
    review = adapters.reviewer(plan, evidence)
    draft = adapters.writer({"question": "KV 缓存量化有什么证据？"}, review, evidence)
    audit = adapters.auditor(draft, review)

    assert plan["groups"][0]["id"] == "group-1"
    assert evidence["records"][0]["fulltext_available"] is False
    assert evidence["retrieval_summary"][0]["candidate_count"] == 1
    assert review["coverage_status"] == "partial"
    assert review["coverage"][0]["status"] == "partial"
    assert draft["coverage_status"] == "partial"
    assert audit["status"] == "passed"
    assert [role for role, _payload in calls] == ["planner", "reviewer", "writer", "auditor"]
    assert all("Authorization" not in str(payload) and "raw_response" not in str(payload) for _role, payload in calls)


def test_retriever_deduplicates_source_paper_pairs_and_allows_optional_reading():
    reads = []

    def search(_query, _limit):
        return {"status": "ok", "papers": [
            {"paper_id": "2401.00001", "title": "First", "source": "arxiv", "abstract": "short"},
            {"paper_id": "2401.00001", "title": "First", "source": "arxiv", "abstract": "duplicate"},
        ]}

    def read(paper):
        reads.append(paper["paper_id"])
        return {"excerpt": "full text excerpt", "fulltext_available": True}

    adapter = LiteratureRoleAdapters(lambda *_args: {}, search, read_evidence=read)
    result = adapter.retriever({"id": "group-1", "queries": ["query"]})
    assert len(result["records"]) == 1
    assert result["records"][0]["excerpt"] == "full text excerpt"
    assert result["records"][0]["fulltext_available"] is True
    assert reads == ["2401.00001"]


def test_auditor_rejects_citation_label_not_present_in_this_workflow_evidence():
    def model(role, _payload):
        if role == "reviewer":
            return {"coverage_status": "sufficient", "supported_claims": [], "unsupported_questions": [],
                    "conflicts": [], "allowed_evidence_ids": ["evidence-1"]}
        return {"status": "passed", "rejected_claim_ids": [],
                "claim_results": [{"claim_id": "claim-1", "evidence_ids": ["evidence-1"], "status": "supported"}]}

    adapter = LiteratureRoleAdapters(model, lambda *_args: {"status": "ok", "papers": []})
    evidence = {"schema_version": 1, "records": [{
        "evidence_id": "evidence-1", "group_id": "group-1", "paper_id": "2401.00001", "title": "Paper",
        "source": "arxiv", "publication_date": None, "claim_support": [], "excerpt": "", "fulltext_available": False,
        "provenance": {"retrieval_run_id": "retrieval-1"},
    }]}
    review = adapter.reviewer({"groups": []}, evidence)
    audit = adapter.auditor({
        "answer": "Fabricated [arxiv:9999.99999].",
        "claim_evidence_map": [{"claim_id": "claim-1", "evidence_ids": ["evidence-1"]}],
    }, review)
    assert audit["status"] == "needs_revision"
    assert audit["rejected_claim_ids"] == ["claim-1"]


def test_gap_analyst_returns_only_bounded_structured_retrieval_queries():
    def model(role, _payload):
        assert role == "gap_analyst"
        return {"groups": [{"group_id": "group-1", "queries": ["KV cache latency benchmark"]}]}

    adapter = LiteratureRoleAdapters(model, lambda *_args: {"status": "ok", "papers": []})
    gap = adapter.gap_analyst(
        {"groups": [{"id": "group-1", "question": "KV", "queries": ["KV"], "priority": 1}]},
        {"coverage_status": "insufficient", "unsupported_questions": ["latency"]},
        {"records": []}, 1,
    )
    assert gap == {"schema_version": 1, "round": 1,
                   "groups": [{"group_id": "group-1", "queries": ["KV cache latency benchmark"]}]}


def test_reviewer_promotes_evidence_backed_not_reported_to_partial_answer_state():
    def model(role, _payload):
        assert role == "reviewer"
        return {
            "coverage_status": "insufficient", "supported_claims": [], "unsupported_questions": ["latency"],
            "conflicts": [], "allowed_evidence_ids": [],
            "coverage": [{"group_id": "group-1", "status": "not_reported", "evidence_ids": ["evidence-1"],
                          "reason": "该论文主要报告吞吐量和显存，不报告统一单请求延迟。"}],
        }

    adapter = LiteratureRoleAdapters(model, lambda *_args: {"status": "ok", "papers": []})
    evidence = {"schema_version": 1, "records": [{
        "evidence_id": "evidence-1", "group_id": "group-1", "paper_id": "2401.00001", "title": "Paper",
        "source": "arxiv", "publication_date": None, "claim_support": [], "excerpt": "excerpt",
        "fulltext_available": False, "provenance": {"retrieval_run_id": "retrieval-1"},
    }]}
    review = adapter.reviewer(
        {"groups": [{"id": "group-1", "question": "KV cache", "queries": ["KV"], "priority": 1}]}, evidence,
    )
    assert review["coverage_status"] == "partial"
    assert review["allowed_evidence_ids"] == ["evidence-1"]
    assert review["coverage"][0]["status"] == "not_reported"
