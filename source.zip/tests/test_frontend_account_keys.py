"""Configuration-only onboarding never inherits or reveals a provider secret."""
import json
from pathlib import Path
import shutil
import subprocess

import pytest

ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.parametrize('scenario', ['configured', 'missing', 'llama_optional', 'anonymous',
    'bad_schema', 'late_other_owner', 'close_wipes', 'save_owner_change'])
def test_account_keys_onboarding(scenario):
    node = shutil.which('node')
    if not node:
        pytest.skip('Node required')
    source = (ROOT/'chatAi/account_keys.js').read_text(encoding='utf8')
    harness = r'''
const vm=require('node:vm'),assert=require('node:assert/strict'),requests=[],elements={};
const element=()=>({value:'',checked:false,hidden:true,textContent:'',events:{},open:false,
 addEventListener(k,fn){this.events[k]=fn;},showModal(){this.open=true;},close(){this.open=false;this.events.close?.();}});
const document={readyState:'complete',getElementById:id=>elements[id]||(elements[id]=element())};
const window={userToken:SCENARIO==='anonymous'?null:'owner-a',addEventListener(){}};
let resolveFetch;
const fetch=async(url,opts={})=>{
 requests.push({url,method:opts.method||'GET'});
 if(SCENARIO==='late_other_owner')await new Promise(resolve=>resolveFetch=resolve);
 return {ok:true,json:async()=>({schema_version:SCENARIO==='bad_schema'?'unknown':'sciassistant.account-provider-status/v1',
 deepseek:{configured:['configured','llama_optional'].includes(SCENARIO),key_count:1},llama:{configured:false}})};
};
const settle=()=>new Promise(resolve=>setImmediate(resolve));
vm.runInNewContext(SOURCE,{window,document,fetch,setInterval(){}});
(async()=>{
 if(SCENARIO==='late_other_owner'){window.userToken='owner-b';resolveFetch();}
 await settle();
 const dialog=document.getElementById('account-keys-dialog');
 const prompted=['missing','close_wipes','save_owner_change'].includes(SCENARIO);
 assert.equal(dialog.open,prompted);
 assert.equal(requests.length,SCENARIO==='anonymous'?0:1);
 if(prompted)assert.equal(document.getElementById('account-keys-onboarding').hidden,false);
 if(SCENARIO==='close_wipes'){
  document.getElementById('account-deepseek-key').value='test-secret-never-store';
  window.AccountKeys.close();assert.equal(document.getElementById('account-deepseek-key').value,'');assert.equal(dialog.open,false);
 }
 if(SCENARIO==='save_owner_change'){
  document.getElementById('account-deepseek-key').value='test-secret-never-store';window.userToken='owner-b';
  await document.getElementById('account-keys-save').events.click();
  assert.equal(requests.filter(r=>r.method==='POST').length,0);assert.equal(dialog.open,false);
  assert.equal(document.getElementById('account-deepseek-key').value,'');
 }
 console.log('ok');
})().catch(error=>{console.error(error);process.exitCode=1;});
'''
    result = subprocess.run([node, '-'], input='const SOURCE='+json.dumps(source)+';const SCENARIO='+json.dumps(scenario)+';\n'+harness,
                            capture_output=True, text=True, encoding='utf8', timeout=10)
    assert result.returncode == 0, result.stderr


def test_only_one_unified_mode_and_sidebar_keys_entry():
    source = (ROOT/'chatAi/ai_chat.html').read_text(encoding='utf8')
    assert source.count('id="account-keys-btn"') == 1
    assert 'id="research-task-center-btn"' not in source
    assert '<option value="multi_agent_pdf"' not in source
    assert '<option value="multi_agent_literature"' not in source
    assert 'id="account-keys-onboarding" hidden' in source
    assert source.index('id="account-keys-btn"') < source.index('id="main-content"')
