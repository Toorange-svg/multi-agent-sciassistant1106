import os
import unittest
import json
import subprocess
import sys
import tempfile
import textwrap
import time
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest import mock

import requests

from deepdiver_v2.src import model_key_pool


def _response(status: int, retry_after: str | None = None):
    response = requests.Response()
    response.status_code = status
    response.headers["Retry-After"] = retry_after or ""
    response._content = b'{}'
    return response


class ModelKeyPoolTests(unittest.TestCase):
    def setUp(self):
        self.env = mock.patch.dict(
            os.environ,
            {
                "MODEL_REQUEST_TOKEN": "primary-token",
                "MODEL_REQUEST_TOKENS": "backup-a; backup-b",
                "MODEL_KEY_429_COOLDOWN_SECONDS": "30",
            },
            clear=False,
        )
        self.env.start()
        model_key_pool.reset_model_key_pool()

    def tearDown(self):
        model_key_pool.reset_model_key_pool()
        self.env.stop()

    def test_tokens_are_parsed_and_deduplicated(self):
        self.assertEqual(
            model_key_pool.configured_model_tokens(),
            ["backup-a", "backup-b", "primary-token"],
        )

    def test_rotates_on_rate_limit_and_rewrites_auth_headers(self):
        responses = [_response(429, "7"), _response(200)]
        with mock.patch.object(model_key_pool.requests, "post", side_effect=responses) as post:
            result = model_key_pool.post_model_request("https://model.invalid", headers={"Authorization": "Bearer old"}, json={"x": 1})
        self.assertEqual(result.status_code, 200)
        self.assertEqual(post.call_count, 2)
        sent_tokens = [call.kwargs["headers"]["csb-token"] for call in post.call_args_list]
        self.assertEqual(sent_tokens, ["backup-a", "backup-b"])
        self.assertEqual(post.call_args_list[0].kwargs["headers"]["Authorization"], "Bearer backup-a")

    def test_rotates_on_transport_failure(self):
        responses = [requests.ConnectionError("offline"), _response(200)]
        with mock.patch.object(model_key_pool.requests, "post", side_effect=responses) as post:
            result = model_key_pool.post_model_request("https://model.invalid")
        self.assertEqual(result.status_code, 200)
        self.assertEqual(post.call_count, 2)

    def test_single_key_keeps_last_response_for_existing_error_handling(self):
        with mock.patch.dict(os.environ, {"MODEL_REQUEST_TOKENS": "", "MODEL_REQUEST_TOKEN": "only"}), \
             mock.patch.object(model_key_pool.requests, "post", return_value=_response(402)) as post:
            result = model_key_pool.post_model_request("https://model.invalid")
        self.assertEqual(result.status_code, 402)
        self.assertEqual(post.call_count, 1)

    def test_transport_category_is_logged_without_key_url_or_exception_text(self):
        canary = 'credential-and-private-provider-url-canary'
        with mock.patch.object(model_key_pool.requests, 'post', side_effect=[
                _response(429, '60'), requests.Timeout(canary), requests.ConnectionError(canary)]) as post, \
             mock.patch.object(model_key_pool, '_mark_cooldown') as mark, \
             self.assertLogs(model_key_pool._LOGGER, level='WARNING') as captured:
            result = model_key_pool.post_model_request('https://private-provider.invalid')
        assert result.status_code == 429 and post.call_count == 3 and mark.call_count == 3
        logged = '\n'.join(captured.output)
        assert 'Timeout' in logged and 'ConnectionError' in logged
        assert canary not in logged and 'private-provider.invalid' not in logged
        assert all(key not in logged for key in ['backup-a', 'backup-b', 'primary-token'])

    def test_expired_budget_does_not_attempt_or_cool_another_key(self):
        with mock.patch.object(model_key_pool.requests, 'post') as post, \
             mock.patch.object(model_key_pool, '_mark_cooldown') as mark:
            with self.assertRaises(requests.Timeout):
                model_key_pool.post_model_request('https://model.invalid', deadline=time.monotonic()-1)
        post.assert_not_called()
        mark.assert_not_called()


class ModelKeyPoolProcessTests(unittest.TestCase):
    def run_processes(self, all_cooling=False):
        calls = []

        class Handler(BaseHTTPRequestHandler):
            def do_POST(inner):
                # Consume the actual body; this is a real loopback transport
                # test, not a mocked response or a paid provider request.
                inner.rfile.read(int(inner.headers.get("Content-Length", "0")))
                alias = "A" if inner.headers.get("Authorization") == "Bearer process-test-key-a" else "B"
                calls.append(alias)
                status = 429 if alias == "A" or all_cooling else 200
                inner.send_response(status)
                inner.send_header("Retry-After", "60")
                inner.send_header("Content-Length", "2")
                inner.end_headers()
                inner.wfile.write(b"{}")

            def log_message(inner, *_):
                pass

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        script = textwrap.dedent('''
            import json, sys, requests
            from deepdiver_v2.src.model_key_pool import post_model_request
            actual_post = requests.post
            attempts = []
            def observed_post(url, **options):
                header = options.get('headers', {}).get('Authorization')
                alias = {'Bearer process-test-key-a':'A', 'Bearer process-test-key-b':'B'}.get(header, 'unknown')
                try:
                    response = actual_post(url, **options)
                except requests.RequestException as exc:
                    attempts.append({'alias':alias, 'status':None, 'error_type':type(exc).__name__})
                    raise
                attempts.append({'alias':alias, 'status':response.status_code, 'error_type':None})
                return response
            requests.post = observed_post
            response = post_model_request(sys.argv[1], json={}, timeout=(3, 10))
            print(json.dumps({'status':response.status_code,
                'retry_after':response.headers.get('Retry-After'), 'attempts':attempts}))
        ''')
        try:
            with tempfile.TemporaryDirectory() as directory:
                state = Path(directory) / "pool.sqlite3"
                environment = dict(os.environ, MODEL_REQUEST_TOKEN="",
                    MODEL_REQUEST_TOKENS="process-test-key-a,process-test-key-b",
                    MODEL_KEY_POOL_STATE_PATH=str(state), NO_PROXY="127.0.0.1")
                results = []
                first_calls = None
                for _ in range(2):
                    result = subprocess.run(
                        [sys.executable, "-c", script, f"http://127.0.0.1:{server.server_port}"],
                        cwd=Path(__file__).resolve().parents[1], env=environment,
                        capture_output=True, text=True, timeout=45, check=True,
                    )
                    results.append(json.loads(result.stdout))
                    if first_calls is None:
                        first_calls = list(calls)
                self.assertNotIn(b"process-test-key-a", state.read_bytes())
                self.assertNotIn(b"process-test-key-b", state.read_bytes())
                return results, first_calls, calls
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)

    def test_fresh_process_skips_key_cooled_by_previous_process(self):
        results, first_calls, all_calls = self.run_processes()
        self.assertEqual([r['attempts'] for r in results], [
            [{'alias':'A', 'status':429, 'error_type':None}, {'alias':'B', 'status':200, 'error_type':None}],
            [{'alias':'B', 'status':200, 'error_type':None}]],
            msg=f"Loopback attempts distinguish transport failures from cooldown: {results}")
        self.assertEqual([result["status"] for result in results], [200, 200],
                         msg=f"Local mock results={results}; first aliases={first_calls}; all aliases={all_calls}")
        self.assertEqual(first_calls, ["A", "B"])
        self.assertEqual(all_calls, ["A", "B", "B"])

    def test_fresh_process_returns_local_429_without_upstream_if_all_keys_cooling(self):
        results, first_calls, all_calls = self.run_processes(all_cooling=True)
        self.assertEqual([result["status"] for result in results], [429, 429])
        self.assertEqual(first_calls, ["A", "B"])
        self.assertEqual(all_calls, first_calls)
        self.assertEqual(results[1]['attempts'], [])
        self.assertGreater(int(results[1]["retry_after"]), 0)


if __name__ == "__main__":
    unittest.main()
