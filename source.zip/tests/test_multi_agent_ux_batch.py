"""UX regressions from saved runs: no public network or paid model calls."""
import json
import shutil
import subprocess
import time
from pathlib import Path

import pytest
import requests

from multi_agent_agents import ArtifactDirectory
from multi_agent_rag import build_chunks, _token_estimate
from multi_agent_pipeline_v2 import check_review, ReviewContractError, check_draft
from multi_agent_live import LiveArxivRagExecutor, normalize_live_result
from multi_agent_status import describe_status, status_html, status_markdown
from multi_agent_workflow import WorkflowStore
from test_multi_agent_pipeline_v2 import agents, pipeline
from test_multi_agent_reading_batches import executor, actions, plan
from tools.multi_agent_cli import finalize_worker_exit

ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.parametrize("boundary", ["page", "section", "table_id", "figure_id", "block_type"])
def test_hard_boundaries_do_not_emit_repeated_trailing_chunks(boundary):
    blocks = [{"text": f"unique_{n} scientific paragraph", "page": 1} for n in range(8)]
    if boundary == "section":
        for block in blocks:
            block["section"] = "Introduction"
    for n in range(4, 8):
        blocks[n][boundary] = {"page": 2, "section": "Evaluation", "table_id": "Table-2",
                              "figure_id": "Figure-1", "block_type": "formula"}[boundary]
    chunks = build_chunks("doc", "2309.06180", "Paper", blocks)
    assert len(chunks) == 2
    for n in range(8):
        assert sum(f"unique_{n}" in c["text"] for c in chunks) == 1
    assert all(c["token_estimate"] <= 1000 for c in chunks)


def test_budget_overlap_retains_context_but_makes_forward_progress():
    blocks = [{"text": f"entry_{n} " + "science " * 10, "page": 1} for n in range(20)]
    chunks = build_chunks("doc", "2309.06180", "Paper", blocks, target_tokens=70, overlap_tokens=25)
    assert len(chunks) < len(blocks)
    assert all(_token_estimate(c["text"]) <= 70 for c in chunks)
    assert all(any(f"entry_{n}" in c["text"] for c in chunks) for n in range(20))
    assert any(sum(f"entry_{n}" in c["text"] for c in chunks) == 2 for n in range(20))


def reviewed(decisions=None):
    return {"coverage_status": "partial", "allowed_evidence_ids": ["e1"], "coverage": [],
            **({"decisions": decisions} if decisions is not None else {})}


def test_reviewer_decisions_survive_live_schema_and_legacy_missing_reason_is_not_invented():
    data = normalize_live_result("reviewer", {**reviewed(), "decisions": [
        {"evidence_id": "e1", "decision": "approved", "reason_code": "SUPPORTED", "detail": "Supports this topic", "group_ids": ["g1"], "task_relevance": "direct_task_evidence"},
        {"evidence_id": "e2", "decision": "rejected", "reason_code": "METRIC_MISMATCH", "detail": "Different metric", "group_ids": ["g1"], "task_relevance": "unrelated", "internal_note": "not-for-agent-log"}]})["output"]
    assert "not-for-agent-log" not in json.dumps(data)
    result = check_review(data, {"evidence": [{"evidence_id": "e1"}, {"evidence_id": "e2"}]}, {"g1"})
    assert result["decisions"][1]["reason_code"] == "METRIC_MISMATCH"
    assert result["decisions"][0]["task_relevance"] == "direct_task_evidence"
    legacy = check_review(reviewed(), {"evidence": [{"evidence_id": "e1"}, {"evidence_id": "e2"}]}, {"g1"})
    assert legacy["decisions"][1]["reason_code"] == "REASON_NOT_PROVIDED"
    assert check_review(legacy, {"evidence": [{"evidence_id": "e1"}, {"evidence_id": "e2"}]}, {"g1"}) == legacy


@pytest.mark.parametrize("decisions", [
    [{"evidence_id": "unknown", "decision": "rejected", "reason_code": "IRRELEVANT"}],
    [{"evidence_id": "e1", "decision": "rejected", "reason_code": "IRRELEVANT"}],
    [{"evidence_id": "e1", "decision": "approved", "reason_code": "secret-canary"}],
    [{"evidence_id": "e1", "decision": "approved", "reason_code": "SUPPORTED"}] * 2,
    [{"evidence_id": "e1", "decision": "approved", "reason_code": {"not": "a code"}}],
    "not structured",
])
def test_reviewer_decisions_cannot_override_approval_or_leak_raw_reason(decisions):
    with pytest.raises(ReviewContractError, match="REVIEW_DECISIONS_INVALID"):
        check_review(reviewed(decisions), {"evidence": [{"evidence_id": "e1"}]}, {"g1"})


def test_writer_revision_receives_exact_code_errors_and_allowed_sources(tmp_path):
    configured, calls = agents()
    invocations = []
    def writer(packet):
        calls.append("writer")
        payloads = [p["payload"] for p in packet["inputs"]]
        invocations.append(payloads)
        if len(invocations) == 2:
            feedback = next(p for p in payloads if p.get("schema_version") == "sciassistant.citation-feedback/v1")
            assert feedback["code_issues"] == [{"claim_id": "bad", "reason": "UNAPPROVED_CITATION"}]
            assert feedback["allowed_evidence_ids"] == ["arxiv-1"]
        return {"output": {"direct_answer": "answer", "claims": [{"claim_id": "bad", "text": "supported",
            "evidence_ids": [] if len(invocations) == 1 else ["arxiv-1"]}]}}
    configured.writer.handler = writer
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("revision", "owner", "question")
    assert result["run"]["status"] == "completed"
    assert result["run"]["model_calls_used"] == 7
    assert "[1]" in result["direct_answer"] and len(invocations) == 2


def test_unsupported_numbers_cannot_hide_in_qualification():
    assert check_draft({"direct_answer": "answer", "claims": [{"claim_id": "c1", "claim_type": "quantitative",
        "text": "throughput improves", "qualification": "20%", "evidence_ids": ["e1"]}]},
        {"evidence": [{"evidence_id": "e1", "excerpt": "reports 12%"}]}) == [{"claim_id": "c1", "reason": "UNSUPPORTED_NUMBER"}]


def test_phase_checkpoints_cache_and_failure_timing_are_preserved(tmp_path):
    tool, _ = executor(tmp_path, fail_first=True)
    tool.configure_plan(plan(1))
    snapshots = []
    result = tool.execute(actions(1), group_ids={"g1"}, deadline=time.monotonic() + 40, progress=snapshots.append)
    phases = {r.get("phase") for s in snapshots for r in s["observations"]}
    assert {"pdf_download", "pdf_parse", "pdf_index"}.issubset(phases)
    failed = next(r for r in result["observations"] if r["source_status"] == "pdf_download_deadline_skipped")
    assert failed["reason_code"] == "REQUEST_OR_PARSE_TIMEOUT" and failed["download_ms"] >= 0
    assert "private-canary" not in json.dumps(result)


def test_corrupt_cached_pdf_is_not_reused(tmp_path):
    tool, downloads = executor(tmp_path)
    folder = tool.storage_root / "documents/arxiv-2401-00010v1"
    folder.mkdir(parents=True)
    (folder / "source.pdf").write_bytes(b"not a PDF")
    tool.execute(actions(1), group_ids={"g1"}, deadline=time.monotonic() + 40)
    assert "2401.00010v1" in downloads
    assert (folder / "source.pdf").read_bytes().startswith(b"%PDF")


def test_pdf_host_fallback_has_one_shared_budget_and_closes_responses(tmp_path, monkeypatch):
    tool, _ = executor(tmp_path)
    tool.retrieval_deadline = time.monotonic() + 60
    seen = []
    class Response:
        closed = False
        def iter_content(self, **kwargs):
            yield b"%PDF-1.4\npublic document\n%%EOF"
        def close(self): self.closed = True
    response = Response()
    def request(source, url, **kwargs):
        seen.append((url, kwargs))
        if len(seen) == 1: raise requests.ConnectionError("secret-canary")
        return response
    monkeypatch.setattr("deepdiver_v2.src.literature_sources._request", request)
    assert tool._download_http("2309.06180", tmp_path).read_bytes().startswith(b"%PDF")
    assert [url.split('/')[2] for url, _ in seen] == ["arxiv.org", "export.arxiv.org"]
    assert seen[0][1]["deadline_monotonic"] < seen[1][1]["deadline_monotonic"] <= tool.retrieval_deadline
    assert all(k["max_attempts"] == 1 for _, k in seen) and response.closed
    assert not (tmp_path / "source.part").exists()


@pytest.mark.parametrize("status", [302, 429, 403])
def test_pdf_redirect_auth_and_cooldown_do_not_trigger_host_bypass(tmp_path, monkeypatch, status):
    tool, _ = executor(tmp_path)
    tool.retrieval_deadline = time.monotonic() + 60
    seen = []
    response = requests.Response(); response.status_code = status
    response.close = lambda: seen.append("close")
    def request(*args, **kwargs):
        seen.append("request")
        raise requests.HTTPError("secret-canary", response=response)
    monkeypatch.setattr("deepdiver_v2.src.literature_sources._request", request)
    with pytest.raises(requests.HTTPError): tool._download_http("2309.06180", tmp_path)
    assert seen.count("request") == 1 and "close" in seen
    assert not (tmp_path / "source.part").exists()


@pytest.mark.parametrize("exitcode", [0, 1, 7])
def test_unpublished_worker_exit_never_leaves_active_workflow(tmp_path, exitcode):
    store = WorkflowStore(tmp_path / "workflow.sqlite3")
    store.create_run("exit-test", "owner", time_budget_seconds=360)
    store.reserve_model_call("exit-test", "planner")
    assert finalize_worker_exit(tmp_path, "exit-test", exitcode, 360)
    state = store.get_run("exit-test")
    assert state["status"] == "failed" and state["failure_code"] == "CLI_WORKER_EXITED"
    assert state["model_calls_used"] == 1
    assert (tmp_path / "final_answer.md").read_bytes().startswith(b"\xef\xbb\xbf")
    assert not finalize_worker_exit(tmp_path, "exit-test", exitcode, 360)


def test_partial_topics_and_review_doubts_are_separate_from_answer():
    display = describe_status("partial", plan={"groups": [{"id": "g1", "core": ["PagedAttention"]}]},
        audit={"status": "passed"}, coverage=[{"group_id": "g1", "metric": "throughput", "status": "direct"},
        {"group_id": "g1", "metric": "latency", "status": "not_comparable"}])
    assert display["topic_summaries"][0]["title"] == "PagedAttention"
    assert "吞吐量：有直接证据" in status_markdown(display)
    assert "延迟：实验不可直接比较" in status_html(display)
    other = describe_status("needs_review", audit={"status": "passed", "code_issues": [{"reason": "UNAPPROVED_CITATION"}]})
    assert "引用未获批准" in status_html(other)


def test_web_progress_whitelists_counts_and_never_exposes_paths(tmp_path, monkeypatch):
    import multi_agent_web as web
    monkeypatch.setenv("SCIASSISTANT_MULTI_AGENT_WEB_RUN_ROOT", str(tmp_path))
    directory = tmp_path / "abcdef012345";directory.mkdir()
    store = WorkflowStore(directory / "workflow.sqlite3")
    store.create_run(directory.name, "owner")
    store.record_event(directory.name, "literature_reading", "completed", {"public_progress": {
        "papers_attempted": 5, "papers_indexed": 3, "phase": "pdf_index", "disk_location": "private-canary"}})
    data = web.progress(directory.name)
    assert data["reading_progress"] == {"papers_attempted": 5, "papers_indexed": 3, "phase": "pdf_index"}
    assert "private-canary" not in json.dumps(data)


def test_waiting_progress_uses_safe_dom_and_distinguishes_indexing_from_writing():
    node = shutil.which("node")
    if not node: pytest.skip("Node required; not a browser test")
    harness = r'''
const vm=require('node:vm'),nodes=[];
const el=tag=>{const n={tag,children:[],dataset:{},classList:{add(){}},append(...x){this.children.push(...x)},addEventListener(){},setAttribute(){},querySelector(s){return this.children.find(n=>'.'+n.className===s)||this.children.map(n=>n.querySelector(s)).find(Boolean)||null},querySelectorAll(){return []}};nodes.push(n);return n;};
const window={location:{search:''},addEventListener(){}};
const context={window,document:{createElement:el,getElementById(){return null}},URLSearchParams,setInterval(){}};
vm.runInNewContext(SOURCE,context);
const loading=el('div');
window.MultiAgentRagUI.update({processing_mode:'multi_agent_rag',elapsed_seconds:50,execution:{model_calls:2,workflow_status:'retrieving',reading_progress:{phase:'pdf_index',papers_attempted:5,papers_indexed:3,queries_finished:6}}},loading);
const reading=loading.querySelector('.rag-progress-reading');const first=loading.querySelector('.rag-progress-stage').textContent+' '+reading.textContent;
window.MultiAgentRagUI.update({processing_mode:'multi_agent_rag',execution:{workflow_status:'writing'}},loading);
console.log(JSON.stringify({first,last:loading.querySelector('.rag-progress-stage').textContent,children:loading.children.length}));
'''
    result = subprocess.run([node, "-"], input="const SOURCE=" + json.dumps((ROOT/'chatAi/multi_agent_rag.js').read_text('utf8')) + ";\n" + harness,
                            text=True, encoding="utf8", capture_output=True, timeout=10)
    assert result.returncode == 0, result.stderr
    data = json.loads(result.stdout)
    assert "正在建立检索索引" in data["first"] and "已尝试读取 5 篇" in data["first"] and "已索引 3" in data["first"]
    assert "正在撰写回答" in data["last"] and data["children"] == 1


def test_quality_ratio_counts_papers_not_packets_and_markdown_has_windows_encoding(tmp_path):
    from test_research_quality import quality_run
    from tools.inspect_research_quality import inspect_run, main
    run = quality_run(tmp_path)
    (run / "tools").mkdir()
    (run / "tools/search_catalog.jsonl").write_text(json.dumps({"schema_version": "sciassistant.search-catalog/v1",
        "query": "query", "source_status": "ok", "papers": [{"paper_id": "2309.06180v2", "title": "Paper A"}]}) + "\n", encoding="utf8")
    summary = inspect_run(run)
    assert summary["funnel"]["approved_packets"] == 2
    assert summary["funnel"]["candidate_to_approved_paper_fraction"] == 1.0
    output = tmp_path / "notes"
    assert main(["--run-dir", str(run), "--output-dir", str(output)]) == 0
    assert (output / "paper_notes.md").read_bytes().startswith(b"\xef\xbb\xbf")
    assert not (output / "quality_summary.json").read_bytes().startswith(b"\xef\xbb\xbf")


def test_markdown_web_download_is_utf8_bom_but_json_remains_standard():
    from multi_agent_web import exported_report
    data = {"status": "partial", "direct_answer": "中文科研回答", "references": []}
    md, mime = exported_report(data, "md")
    assert md.startswith(b"\xef\xbb\xbf") and "中文科研回答" in md.decode("utf-8-sig")
    assert "charset=utf-8" in mime
    structured, _ = exported_report(data, "json")
    assert not structured.startswith(b"\xef\xbb\xbf") and json.loads(structured)["direct_answer"] == "中文科研回答"
