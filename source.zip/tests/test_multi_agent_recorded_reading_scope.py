"""Expose actual reading scope and assertions, without deciding semantics by code."""
from copy import deepcopy

import pytest

from multi_agent_agents import ArtifactDirectory
from multi_agent_quality import citation_audit_input, source_boundary_brief, SOURCE_REASONING_POLICY
from multi_agent_live import ROLE_PROMPTS


def inputs(scope="selected_chunks", status="approved"):
    evidence = {"evidence": [{"evidence_id": "e1", "paper_id": "p1", "review_status": status,
        "coverage_scope": scope, "excerpt": "Few-shot adaptation in a custom dataset achieves 85% accuracy.",
        "locator": {"page": 5, "bbox": [1, 2, 3, 4]}}]}
    draft = {"schema_version": "sciassistant.claim-draft/v2", "claims": [{"claim_id": "c1",
        "text": "作者认为适配可行。", "scope_note": "而非经统一对照实验验证的结论。",
        "qualification": "仅所选片段。", "evidence_ids": ["e1"], "claim_type": "technical"}]}
    return draft, evidence


@pytest.mark.parametrize("scope", ["selected_chunks", "abstract", "fulltext", "unrecognized_extent", None, ""])
def test_recorded_scope_not_inferred_from_last_page_bbox_or_title(scope):
    draft, evidence = inputs(scope)
    before = deepcopy((draft, evidence))
    expected = scope or "unknown"
    brief = source_boundary_brief(evidence)
    audit = citation_audit_input(draft, evidence)
    assert brief["approved_reading_scopes"][0]["coverage_scope"] == expected
    assert audit["claims"][0]["source_context"][0]["coverage_scope"] == expected
    assert (draft, evidence) == before
    assert "decision" not in brief and "decision" not in audit["claims"][0]


def test_absent_scope_is_unknown_not_fulltext():
    draft, evidence = inputs()
    del evidence["evidence"][0]["coverage_scope"]
    assert citation_audit_input(draft, evidence)["claims"][0]["source_context"][0]["coverage_scope"] == "unknown"


@pytest.mark.parametrize("status", ["pending", "rejected", None])
def test_no_unapproved_scope_or_counter_context_leaks(status):
    draft, evidence = inputs(status=status)
    brief = source_boundary_brief(evidence)
    row = citation_audit_input(draft, evidence)["claims"][0]
    assert brief["approved_reading_scopes"] == []
    assert row["source_context"] == [] and row["source_boundary_cues"] == []
    assert row["unavailable_evidence_ids"] == ["e1"]


def test_visible_fields_not_rescued_or_rewritten_by_hidden_qualification():
    draft, evidence = inputs()
    row = citation_audit_input(draft, evidence)["claims"][0]
    assert row["visible_fields"] == {"text": "作者认为适配可行。", "scope_field": "scope_note",
        "scope_text": "而非经统一对照实验验证的结论。"}
    assert row["visible_text"] == draft["claims"][0]["text"] + "\n" + draft["claims"][0]["scope_note"]
    assert row["hidden_review_detail"] == "仅所选片段。"
    assert "仅所选片段" not in row["visible_text"]


def test_legacy_visible_qualification_remains_visible_without_history_migration():
    draft, evidence = inputs()
    draft["schema_version"] = "sciassistant.claim-draft/v1"
    row = citation_audit_input(draft, evidence)["claims"][0]
    assert row["visible_fields"]["scope_field"] == "qualification"
    assert row["visible_fields"]["scope_text"] == "仅所选片段。"
    assert row["hidden_review_detail"] == ""


def test_questions_apply_without_phrase_matching_or_auto_approval():
    draft, evidence = inputs()
    draft["claims"][0]["text"] = "两个数字的差异同时涉及数据集域差异与适配流程差异。"
    audit = citation_audit_input(draft, evidence)
    brief = source_boundary_brief(evidence)
    assert audit["reasoning_policy"] == brief["reasoning_policy"] == SOURCE_REASONING_POLICY
    assert all(q in audit["claims"][0]["semantic_review_questions"] for q in brief["reasoning_questions"])
    assert any("SCORE GAP" in q for q in brief["reasoning_questions"])
    assert any("whole-paper absence" in q for q in brief["reasoning_questions"])
    assert draft["claims"][0]["text"] == audit["claims"][0]["visible_fields"]["text"]
    assert "contract_errors" not in audit and "approved_claim_ids" not in audit


def test_new_artifact_fields_pass_sensitive_data_boundary(tmp_path):
    draft, evidence = inputs()
    store = ArtifactDirectory(tmp_path)
    for name, value in [("source-boundary-brief", source_boundary_brief(evidence)),
                        ("citation-audit-input", citation_audit_input(draft, evidence))]:
        stored = store.put(name, value)
        assert store.get(stored["artifact_id"]) == value


def test_prompts_use_recorded_scope_and_existing_audit_contract():
    assert "approved_reading_scopes" in ROLE_PROMPTS["writer"]
    assert "visible_fields" in ROLE_PROMPTS["citation_auditor"]
    assert "comparison_design/task_scope" in ROLE_PROMPTS["citation_auditor"]
    assert "field_results for EXACTLY text, scope_note, qualification" in ROLE_PROMPTS["citation_auditor"]
    assert "not_applicable" in ROLE_PROMPTS["citation_auditor"]
