"""Regression checks for the visible, authenticated local-context search mode."""
from pathlib import Path
from unittest import TestCase


HTML_PATH = Path(__file__).resolve().parents[1] / "chatAi" / "ai_chat.html"


class FrontendContextSearchModeTests(TestCase):
    @classmethod
    def setUpClass(cls):
        cls.html = HTML_PATH.read_text(encoding="utf-8")
        start = cls.html.index("async function runContextSearch(")
        end = cls.html.index("async function runScienceTask(", start)
        cls.context_search = cls.html[start:end]

    def test_legacy_search_helper_remains_but_has_no_mode_selector(self):
        self.assertNotIn('<select id="research-processing-mode"', self.html)
        self.assertIn('<input type="hidden" id="research-processing-mode" value="multi_agent_rag">', self.html)
        self.assertIn("processingMode === 'context_search'", self.html)
        self.assertIn("只检索本地资料，不调用回答模型", self.html)

    def test_search_uses_owned_context_file_ids_and_authenticated_rag_api(self):
        self.assertIn("item && item.fileId", self.context_search)
        self.assertIn("new Set(", self.context_search)
        self.assertIn("fetch('/5000/api/rag/search'", self.context_search)
        self.assertIn("file_ids: fileIds", self.context_search)
        self.assertIn("signal: controller && controller.signal", self.context_search)

    def test_search_renders_existing_authenticated_download_ui_without_model_proxy(self):
        self.assertIn("window.currentRagContext = {mode: 'snippets', snippets}", self.context_search)
        self.assertIn("addMessage(answer, 'ai', sessionId, 0, '')", self.context_search)
        self.assertNotIn("/8088", self.context_search)
        self.assertNotIn("chat/completions", self.context_search)

    def test_empty_attachment_and_authorization_errors_are_safe(self):
        self.assertIn("请先通过回形针上传至少一个资料文件", self.context_search)
        self.assertIn("response.status === 401", self.context_search)
        self.assertIn("response.status === 404", self.context_search)
        self.assertNotIn("await response.text()", self.context_search)

    def test_context_mode_hides_irrelevant_pdf_control(self):
        start = self.html.index("function updatePdfParseModeControl()")
        section = self.html[start : start + 1800]
        self.assertIn("isContextSearch", section)
        self.assertIn("window.selectedTab !== 'research' || isContextSearch", section)

    def test_context_mode_uses_context_upload_not_science_pdf_only_upload(self):
        start = self.html.index("const isDeepDiverMode = (window.selectedTab || '').trim() === 'deepdiver';")
        end = self.html.index('const maxSingleSize =', start)
        section = self.html[start:end]
        self.assertIn("const isContextSearch = isResearchMode", section)
        self.assertIn("if (isResearchMode && !isContextSearch)", section)
        self.assertIn('const maxFileCount = isDeepDiverMode ? 10 : 5;', section)


if __name__ == "__main__":
    import unittest

    unittest.main()
