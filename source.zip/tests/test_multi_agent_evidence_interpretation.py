"""Execution observations are not claims; roles and coverage need actual text."""
from copy import deepcopy
import json
import pytest

from multi_agent_agents import ArtifactDirectory
from multi_agent_quality import (check_evaluation_roles, EVALUATION_ROLE_POLICY, excerpt_shape,
    citation_audit_input, source_boundary_brief, check_claim_revision)
from multi_agent_pipeline_v2 import check_draft
from multi_agent_status import source_execution_notice, source_execution_lines, describe_status, status_html, status_markdown
from multi_agent_report import export_run_report
from test_multi_agent_report_fields import draft, evidence, audit
from test_multi_agent_pipeline_v2 import agents, pipeline


SOURCE = "GPT-4 assigns significantly higher scores to its own outputs compared to human ratings, Elo of 1348 vs 1176."

def role_inputs(text="GPT-4给自己输出的Elo为1348，给人工评分为1176。"):
    data, sources = draft(), evidence()
    data["claims"][0]["text"] = text
    data["claims"][0]["qualification"] = "所选片段报告评分结果。"
    data["claims"][0]["scope_note"] = ""
    sources["evidence"][0]["excerpt"] = SOURCE
    return data, sources


@pytest.mark.parametrize("field", ["text", "scope_note", "qualification"])
def test_evaluator_target_confusion_identifies_exact_field_without_rewriting(field):
    data, sources = role_inputs("作者报告两种评判者的评分差异。")
    data["claims"][0][field] = "GPT-4给人工评分为1176。"
    before = deepcopy((data, sources))
    issues = check_evaluation_roles(data, sources)
    assert len(issues) == 1 and issues[0]["field"] == field
    assert issues[0]["reason"] == "EVALUATION_ROLE_CONFUSION" and not issues[0]["automatic_rewrite"]
    witness = issues[0]["source_witnesses"][0]
    assert witness["quote"] == SOURCE[witness["start"]:witness["end"]]
    assert (data, sources) == before


@pytest.mark.parametrize("text", [
    "GPT-4对自己的输出给出1348的Elo，人工对相同输出给出1176。",
    "GPT-4的评分为1348，而人工评分为1176；比较的是评判者。",
    "不能写GPT-4给人工评分1176。", "不要声称GPT-4给人类输出评分1176。"])
def test_correct_roles_and_explicit_refutations_not_blocked(text):
    data, sources = role_inputs(text)
    assert not check_evaluation_roles(data, sources)


@pytest.mark.parametrize("fault", ["no_contrast", "uncited", "unapproved"])
def test_no_role_accusation_from_numeric_match_or_other_source(fault):
    data, sources = role_inputs()
    if fault == "no_contrast":
        sources["evidence"][0]["excerpt"] = "GPT-4 rates human-written answers. Elo 1176."
    elif fault == "uncited":
        data["claims"][0]["evidence_ids"] = ["other"]
    else:
        sources["evidence"][0]["review_status"] = "pending"
    assert not check_evaluation_roles(data, sources)


def test_role_guard_is_opt_in_and_detail_repair_requires_real_edit():
    data, sources = role_inputs("有来源的正文。")
    data["claims"][0]["qualification"] = "GPT-4给人工评分1176。"
    assert not any(r["reason"] == "EVALUATION_ROLE_CONFUSION" for r in check_draft(data, sources))
    data["evaluation_role_policy"] = EVALUATION_ROLE_POLICY
    issues = check_draft(data, sources)
    assert any(r["reason"] == "EVALUATION_ROLE_CONFUSION" for r in issues)
    feedback = {"model_audit": audit(data), "code_issues": issues}
    assert check_claim_revision(data, deepcopy(data), feedback)["code_issues"]
    revised = deepcopy(data)
    revised["claims"][0]["qualification"] = "人工对相同输出的评分为1176。"
    assert not check_claim_revision(data, revised, feedback)["code_issues"]


@pytest.mark.parametrize("ending,expected", [("and", True), ("or", True), ("complete caption.", False)])
def test_caption_presence_and_boundary_do_not_certify_full_pdf(ending, expected):
    item = {"evidence_id": "e1", "excerpt": "Table 18: Reported validation loss " + ending}
    before = deepcopy(item)
    shape = excerpt_shape(item)
    assert shape["caption_heading"] == "Table 18:" and shape["ends_with_connector"] is expected
    assert shape["shape_is_not_completeness_verdict"] and "complete" not in shape
    assert item == before


def test_shapes_in_writer_and_audit_inputs_preserve_partial_caption():
    data, sources = role_inputs()
    sources["evidence"][0]["excerpt"] = "Table 18: Actual caption includes performance and"
    brief = source_boundary_brief(sources)
    audit_input = citation_audit_input(data, sources)
    assert brief["observed_excerpt_shapes"][0]["ends_with_connector"]
    assert audit_input["claims"][0]["source_context"][0]["excerpt_shape"] == brief["observed_excerpt_shapes"][0]
    assert "decision" not in brief and "decision" not in audit_input["claims"][0]


def observations():
    return {"observations": [{"request_id": "r1", "group_id": "g1", "query": "private-canary",
        "source": "arxiv", "source_status": "source_unreachable", "accepted_count": 0,
        "private_detail": "provider-canary"}]}


def test_execution_notice_uses_only_recorded_public_status_not_paper_claims():
    data = observations()
    data["observations"] *= 2
    data["observations"] += [{"source": "uploaded_pdf", "source_status": "source_unreachable", "query": "local"},
                             {"source": "arxiv", "source_status": "pdf_indexed"}]
    before = deepcopy(data)
    notice = source_execution_notice("r1", data)
    assert notice["problems"] == [{"status": "source_unreachable", "count": 1}]
    lines = source_execution_lines(notice, "r1")
    assert "无法连接来源 1 次" in lines[0] and "不代表相关论文不存在" in lines[1]
    assert "canary" not in json.dumps(notice) and data == before
    assert source_execution_lines(notice, "other") == []


@pytest.mark.parametrize("bad", ["count_bool", "unknown_status", "duplicate", "extra_field", "wrong_schema"])
def test_invalid_notice_cannot_invent_status_or_scientific_fact(bad):
    notice = source_execution_notice("r1", observations())
    if bad == "count_bool":
        notice["problems"][0]["count"] = True
    elif bad == "unknown_status":
        notice["problems"][0]["status"] = "论文没有相关研究"
    elif bad == "duplicate":
        notice["problems"] *= 2
    elif bad == "extra_field":
        notice["problems"][0]["quote"] = "invented"
    else:
        notice["schema_version"] = "wrong/v1"
    assert source_execution_lines(notice, "r1") == []


def test_execution_notice_is_outside_body_and_exported_without_raw_query(tmp_path):
    store = ArtifactDirectory(tmp_path / "artifacts")
    notice = source_execution_notice("r1", observations())
    refs = {"source_execution": store.put("source-execution-notice", notice)["artifact_id"]}
    final_id = store.put("final-result", {"run_id": "r1", "status": "partial",
        "direct_answer": "正文哨兵", "artifact_refs": refs})["artifact_id"]
    (tmp_path / "manifest.json").write_text(json.dumps({"run_id": "r1", "final_artifact_id": final_id}), encoding="utf-8")
    export_run_report(tmp_path)
    md = (tmp_path / "final_answer.md").read_text(encoding="utf-8")
    html = (tmp_path / "final_answer.html").read_text(encoding="utf-8")
    assert "公开来源执行记录" in md.split("## 回答正文")[0]
    assert "公开来源执行记录" not in md.split("## 回答正文")[1]
    assert "公开来源执行记录" in html.split('<section id="answer">')[0]
    assert "canary" not in md + html
    assert json.loads((tmp_path / "source_execution_notice.json").read_text(encoding="utf-8")) == notice


def test_workflow_keeps_raw_tool_records_but_not_in_writer_approved_sources(tmp_path):
    configured, calls = agents()
    prior = configured.writer.handler
    def writer(packet):
        source = next(i["payload"] for i in packet["inputs"] if "evidence" in i["payload"])
        assert "observations" not in source
        return prior(packet)
    configured.writer.handler = writer
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("notice-test", "owner", "A")
    final = flow.artifacts.get(result["final_artifact_id"])
    assert result["run"]["status"] == "completed" and calls.count("writer") == 1
    assert "observations" in flow.artifacts.get(final["artifact_refs"]["evidence"])
    assert "observations" not in flow.artifacts.get(final["artifact_refs"]["approved"])
    assert flow.artifacts.get(final["artifact_refs"]["source_execution"])["run_id"] == "notice-test"
