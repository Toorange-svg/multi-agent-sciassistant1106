import unittest

from deepdiver_v2.src.query_router import build_followup_retrieval_query


class MultiTurnRetrievalTests(unittest.TestCase):
    def test_followup_query_excludes_previous_answer_boilerplate(self):
        query = build_followup_retrieval_query(
            "仔细解释刚才提到的投影层",
            "统一多模态模型的跨模态对齐难点是什么？",
            {
                "task_type": "critical_analysis",
                "target": "跨模态对齐",
                "relation": "mechanism",
                "aspects": ["token alignment", "projection layer"],
                "entities": ["multimodal model"],
            },
        )
        self.assertIn("投影层", query)
        self.assertIn("跨模态对齐", query)
        self.assertIn("projection layer", query)
        self.assertNotIn("回答完整性说明", query)
        self.assertNotIn("引用核验", query)

    def test_followup_query_is_usable_without_parent_answer(self):
        query = build_followup_retrieval_query("为什么会失败？", "原问题", {})
        self.assertEqual(query.splitlines(), ["为什么会失败？", "原问题"])


if __name__ == "__main__":
    unittest.main()
