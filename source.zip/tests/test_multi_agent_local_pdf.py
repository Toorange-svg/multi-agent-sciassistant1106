"""Private uploaded-PDF path; real parser/CLI, isolated gateway, no providers."""
import io
import json
import os
import subprocess
import sys
import time
from pathlib import Path

import pytest
from flask import abort, g
import app as account
import web_app as web
from multi_agent_local_pdf import LocalPdfRagExecutor, validate_pdf_input
from multi_agent_workflow import WorkflowError

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture
def pdf(tmp_path):
    fitz = pytest.importorskip("fitz")
    path = tmp_path / "source.pdf"
    with fitz.open() as doc:
        page = doc.new_page()
        page.insert_text((50, 70), "Bounded scientific evidence. PagedAttention reduces memory fragmentation.")
        page = doc.new_page()
        page.insert_text((50, 70), "Throughput improves at the same latency. Experiments require matching conditions.")
        doc.save(path)
    return path


def action(query="PagedAttention memory", **extra):
    return [{"request_id": "r1", "action": "request_document_search",
        "arguments": {"query": query, "group_id": "g1", **extra}}]


def test_real_local_parser_fts_locator_and_no_public_index(pdf, tmp_path, monkeypatch):
    monkeypatch.setenv("SCIASSISTANT_QDRANT_PATH", str(tmp_path / "public-index"))
    monkeypatch.setenv("SCIASSISTANT_QDRANT_URL", "http://invalid.example")
    executor = LocalPdfRagExecutor(tmp_path / "run", pdf, rag_mode="lexical")
    snapshots = []
    result = executor.execute(action(), group_ids={"g1"}, deadline=time.monotonic() + 30, progress=snapshots.append)
    assert any(row['reading_summary'].get('uploaded_pdf_phase') == 'pdf_parse' for row in snapshots)
    assert any(row['reading_summary'].get('uploaded_pdf_phase') == 'pdf_index' for row in snapshots)
    assert result['reading_summary']['uploaded_pdf_indexed'] == 1  # Actual parser/FTS, not an answer verdict.
    assert result["evidence"]
    row = result["evidence"][0]
    assert row["source"] == "uploaded_pdf" and not row["official_url"]
    assert row["locator"]["page"] == 1 and row["locator"]["bbox"]
    assert "PagedAttention" in row["excerpt"]
    assert executor.storage_root == tmp_path / "run" / "private_rag"
    assert not (tmp_path / "public-index").exists()
    assert executor.source_context["public_search_allowed"] is False
    assert executor.retrieval_configuration()["pdf_download_hosts"] == 0
    assert executor.reading_summary()["batch_limit"] == 1
    assert str(tmp_path) not in json.dumps(executor.source_context)
    original_copy = tmp_path / "run" / "pdf" / row["document_id"] / "source.pdf"
    assert original_copy.read_bytes() == pdf.read_bytes()
    executor.parse = lambda _: pytest.fail("recovery must reuse index")
    recovered = executor.execute(action("throughput same latency", gap_id="g1-latency"), recovery=True,
        group_ids={"g1"}, deadline=time.monotonic() + 10)
    assert recovered["evidence"] and executor.pdf_reads == 1
    assert recovered["evidence"][0]["locator"]["page"] == 2


@pytest.mark.parametrize("damage", ["arxiv_action", "unknown_group", "too_many", "too_long", "path_override"])
def test_tool_scope_rejects_before_parsing(pdf, tmp_path, damage):
    executor = LocalPdfRagExecutor(tmp_path / "run", pdf, rag_mode="lexical",
        parse=lambda _: pytest.fail("invalid tool request must not execute"))
    request = action()
    if damage == "arxiv_action": request[0]["action"] = "request_arxiv_search"
    if damage == "unknown_group": request[0]["arguments"]["group_id"] = "other"
    if damage == "too_many": request *= 7
    if damage == "too_long": request[0]["arguments"]["query"] = "x" * 501
    if damage == "path_override": request[0]["arguments"]["pdf_path"] = "other-user.pdf"
    with pytest.raises(WorkflowError):
        executor.execute(request, group_ids={"g1"}, deadline=time.monotonic() + 30)


def test_bad_input_and_empty_pdf_fail_safely(pdf, tmp_path):
    from multi_agent_pipeline_v2 import PipelineExecutionError
    bad = tmp_path / "bad.pdf"
    bad.write_bytes(b"not a pdf")
    with pytest.raises(ValueError, match="LOCAL_PDF_INPUT_INVALID"):
        validate_pdf_input(bad)
    executor = LocalPdfRagExecutor(tmp_path / "run", pdf, rag_mode="lexical",
        parse=lambda _: {"success": True, "pages": []})
    with pytest.raises(PipelineExecutionError) as error:
        executor.execute(action(), group_ids={"g1"}, deadline=time.monotonic() + 20)
    assert error.value.code == "LOCAL_PDF_TEXT_EMPTY"


def test_cli_real_pdf_mock_six_role_core_and_replay(pdf, tmp_path):
    run = tmp_path / "outputs" / "abcdef123456"
    command = [sys.executable, str(ROOT / "tools/multi_agent_cli.py"), "run", "--mode", "mock",
        "--pdf", str(pdf), "--query", "bounded scientific evidence", "--run-id", run.name,
        "--output-root", str(run.parent)]
    result = subprocess.run(command, cwd=ROOT, text=True, encoding="utf8", capture_output=True, timeout=45)
    assert result.returncode == 0, result.stdout + result.stderr
    manifest = json.loads((run / "manifest.json").read_text(encoding="utf8"))
    assert manifest["source_scope"] == "uploaded_pdf" and manifest["research_source"]["parser"] == "local"
    config = manifest["retrieval_configuration"]
    assert config["pdf_paper_limit"] == 1 and config["pdf_download_max_attempts"] == 0
    assert config["per_query_packet_limit"] == 4 and config["public_search_allowed"] is False
    roles = {path.name.split("-", 1)[1].removesuffix(".json") for path in (run / "agents").glob("*.json")}
    assert roles == {"planner", "retriever", "reviewer", "writer", "citation_auditor"}
    refs = json.loads((run / "evidence_ledger.json").read_text(encoding="utf8"))
    assert refs and all(row["source"] == "uploaded_pdf" and row["official_url"] == "" for row in refs)
    assert (run / "source-1.html").is_file()
    html = (run / "final_answer.html").read_text(encoding="utf8")
    assert 'href="source-1.html"' in html and 'href="#" target=' not in html
    assert "arXiv:uploaded" not in (run / "final_answer.md").read_text(encoding="utf8")
    original = (run / "final_answer.md").read_bytes()
    replay = subprocess.run([sys.executable, str(ROOT / "tools/multi_agent_cli.py"), "replay", "--run-dir", str(run)],
        text=True, encoding="utf8", capture_output=True, timeout=30)
    assert replay.returncode == 0 and (run / "final_answer.md").read_bytes() == original


@pytest.fixture
def gateway(tmp_path, monkeypatch):
    state, uploads = tmp_path / "tasks", tmp_path / "uploads"
    state.mkdir(); uploads.mkdir()
    monkeypatch.setenv("SCIASSISTANT_WEB_BASE", "")
    monkeypatch.setattr(account, "SCIENCE_TASK_STATE_DIR", state)
    monkeypatch.setattr(account, "SCIENCE_TASK_OWNER_STATE_PATH", tmp_path / "owners.json")
    monkeypatch.setattr(account, "PDF_SESSION_STATE_PATH", tmp_path / "bindings.sqlite3")
    monkeypatch.setattr(account, "_SCIENCE_TASK_OWNERS", {})
    monkeypatch.setattr(account, "_current_auth_version", lambda _: 0)
    monkeypatch.setattr(account, "_LOCAL_SCIENCE_APP", web.app)
    monkeypatch.setattr(web, "TASK_STATE_DIR", state)
    monkeypatch.setattr(web, "UPLOAD_DIR", uploads)
    monkeypatch.setattr(web, "TASKS", {})
    monkeypatch.setattr(web, "_missing_task_configuration", lambda _: [])
    monkeypatch.setattr(web.rag_web, "readiness", lambda: {"ready": True})
    launched = []
    monkeypatch.setattr(web, "_enqueue_retrieval_task", lambda *a, **k: launched.append((a, k)))
    monkeypatch.setattr(web, "_start_background_task", lambda *a, **k: pytest.fail("must use six-role workflow"))
    def conversation(cid):
        if (str(g.current_user_id), cid) not in {("alice", "chat-a"), ("bob", "chat-b")}:
            abort(404)
    monkeypatch.setattr(account, "_require_science_conversation_owner", conversation)
    return tmp_path, launched


def headers(user="alice"):
    return {"Authorization": "Bearer " + account.generate_token(user, user)}


@pytest.mark.parametrize("mode", ["multi_agent_pdf", "multi_agent_rag"])
@pytest.mark.parametrize("filename", ["source.pdf", "论文.pdf"])
def test_gateway_upload_binding_reuse_restart_and_owner(gateway, pdf, monkeypatch, mode, filename):
    root, launched = gateway
    client = account.app.test_client()
    created = client.post("/api/science/tasks", headers=headers(), data={
        "query": "", "conversation_id": "chat-a", "processing_mode": mode,
        "pdf": (io.BytesIO(pdf.read_bytes()), filename)})
    assert created.status_code == 202
    task = created.json["task"]
    assert task["processing_mode"] == "multi_agent_rag" and task["source_scope"] == "uploaded_pdf"
    assert task["query"] and task["task_mode"]["id"] == "multi_agent_pdf"
    assert launched[-1][0][1] is web._run_multi_agent_rag_task
    assert launched[-1][1]["pdf"].is_file()
    snapshot = json.loads((root / "tasks" / (task["id"] + ".json")).read_text(encoding="utf8"))
    assert snapshot["pdf_attachment"] == task["pdf_attachment"]
    monkeypatch.setattr(web, "TASKS", {})
    bound = client.get("/api/science/conversations/chat-a/pdf-attachment", headers=headers())
    assert bound.status_code == 200 and bound.json["attachment"]["source_task_id"] == task["id"]
    followup = {"query": "解释实验结果", "conversation_id": "chat-a", "processing_mode": "multi_agent_pdf",
        "pdf_source_task_id": task["id"], "pdf_parse_mode": "local"}
    response = client.post("/api/science/tasks", headers=headers(), json=followup)
    assert response.status_code == 202 and response.json["task"]["pdf_attachment"] == task["pdf_attachment"]
    assert len(list((root / "uploads").iterdir())) == 1
    response = client.post("/api/science/tasks", headers=headers("bob"), json={**followup, "conversation_id": "chat-b"})
    assert response.status_code == 404
    assert client.post("/api/science/tasks", json=followup).status_code == 401
    assert str(root) not in created.text + bound.text


def test_missing_pdf_untrusted_path_and_wrong_parser(gateway, pdf):
    client = account.app.test_client()
    assert client.post("/api/science/tasks", headers=headers(), json={
        "query": "test", "processing_mode": "multi_agent_pdf", "pdf_path": str(pdf)}).json["error"] == "LOCAL_PDF_REQUIRED"
    result = client.post("/api/science/tasks", headers=headers(), data={
        "query": "test", "processing_mode": "multi_agent_pdf", "pdf_parse_mode": "hybrid",
        "pdf": (io.BytesIO(pdf.read_bytes()), "source.pdf")})
    assert result.status_code == 400 and result.json["error"] == "LLAMA_CLOUD_CONSENT_REQUIRED"


def test_local_module_in_container_and_fingerprint():
    from runtime_identity import IDENTITY_FILES
    assert "multi_agent_local_pdf.py" in IDENTITY_FILES
    for name in ("Dockerfile.cloud", "Dockerfile.account.cloud"):
        assert "COPY multi_agent_local_pdf.py /app/" in (ROOT / name).read_text(encoding="utf8")
        assert "!multi_agent_local_pdf.py" in (ROOT / (name + ".dockerignore")).read_text(encoding="utf8")


def test_local_gap_analyst_runs_once_without_public_search(pdf, tmp_path):
    from dataclasses import replace
    from tools.multi_agent_cli import _mock_agents
    from multi_agent_agents import AgentWorker, ArtifactDirectory
    from multi_agent_pipeline_v2 import LiteraturePipelineV2
    from multi_agent_workflow import WorkflowStore
    calls = []
    def review(packet):
        calls.append(1)
        evidence = next(item["payload"]["evidence"] for item in packet["inputs"] if "evidence" in item["payload"])
        ids = [row["evidence_id"] for row in evidence]
        return {"output": {"coverage_status": "insufficient" if len(calls) == 1 else "partial",
            "allowed_evidence_ids": [] if len(calls) == 1 else ids, "conflicts": [],
            "coverage": [{"group_id": "group-1", "status": "missing" if len(calls) == 1 else "partial",
                "evidence_ids": [] if len(calls) == 1 else ids}]}}
    workers = replace(_mock_agents(source_scope="uploaded_pdf"),
        reviewer=AgentWorker("reviewer", review, ["review_evidence"]))
    run = tmp_path / "run"
    executor = LocalPdfRagExecutor(run, pdf, rag_mode="lexical")
    pipeline = LiteraturePipelineV2(WorkflowStore(run / "workflow.sqlite3"),
        ArtifactDirectory(run / "artifacts"), workers, executor, event_path=run / "events.jsonl")
    result = pipeline.run("gap-test", "test-user", "bounded scientific evidence")
    assert result["run"]["status"] == "partial"
    assert result["run"]["model_calls_used"] == 8
    roles = [json.loads(line).get("role") for line in (run / "events.jsonl").read_text(encoding="utf8").splitlines()
             if json.loads(line).get("event") == "agent_started"]
    assert roles.count("gap_analyst") == 1 and roles.count("retriever") == 2 and roles[-2:] == ["writer", "citation_auditor"]
    assert executor.pdf_reads == 1


def test_local_prompt_hashes_and_source_scope_are_explicit():
    from types import SimpleNamespace
    from multi_agent_live import LiveModelClient, effective_role_prompt
    config = SimpleNamespace(model_name="demo", get_custom_llm_config=lambda: {"url": "https://example.test/v1/chat/completions"})
    client = LiveModelClient(config)
    local = client.agents(source_scope="uploaded_pdf")
    assert local.retriever.allowed_actions == ["request_document_search"]
    assert client.agents().retriever.allowed_actions == ["request_arxiv_search"]
    assert "request_document_search" in effective_role_prompt("retriever", local_source=True)
    metadata = client.prompt_metadata(source_scope="uploaded_pdf")
    assert metadata["writer"]["sha256"] != client.prompt_metadata()["writer"]["sha256"]
    assert metadata["writer"]["version"].endswith("local-pdf-v2")


def test_private_report_assets_owner_matrix(gateway, pdf, tmp_path, monkeypatch):
    from tools.multi_agent_cli import _mock_agents
    from multi_agent_agents import ArtifactDirectory
    from multi_agent_pipeline_v2 import LiteraturePipelineV2
    from multi_agent_workflow import WorkflowStore
    from multi_agent_report import export_run_report
    import multi_agent_web as adapter
    task_id = "abcdefabcdef"
    monkeypatch.setenv("SCIASSISTANT_MULTI_AGENT_WEB_RUN_ROOT", str(tmp_path / "runs"))
    directory = adapter.run_directory(task_id)
    executor = LocalPdfRagExecutor(directory, pdf, rag_mode="lexical")
    artifacts = ArtifactDirectory(directory / "artifacts")
    result = LiteraturePipelineV2(WorkflowStore(directory / "workflow.sqlite3"), artifacts,
        _mock_agents(source_scope="uploaded_pdf"), executor).run(task_id, "alice", "bounded scientific evidence")
    (directory / "manifest.json").write_text(json.dumps({"run_id": task_id, "final_artifact_id": result["final_artifact_id"]}), encoding="utf8")
    export_run_report(directory)
    web.TASKS[task_id] = {"id": task_id, "processing_mode": "multi_agent_rag", "status": "partial"}
    account._SCIENCE_TASK_OWNERS[task_id] = "alice"
    data = adapter.report(task_id)
    assert data["references"][0]["source"] == "uploaded_pdf" and data["references"][0]["official_url"] == ""
    asset = data["references"][0]["pdf_asset"]
    page = data["references"][0]["page_image_asset"]
    assert asset and page
    client = account.app.test_client()
    for suffix in ("report", "report/export?format=md", "report/export?format=html", "report/export?format=json",
                   "report/assets/" + asset, "report/assets/" + page):
        url = f"/api/science/tasks/{task_id}/{suffix}"
        assert client.get(url, headers=headers()).status_code == 200
        assert client.get(url, headers=headers("bob")).status_code == 404
        assert client.get(url).status_code == 401
    assert client.get(f"/api/science/tasks/{task_id}/report/assets/private_rag/evidence.sqlite3", headers=headers()).status_code == 404
