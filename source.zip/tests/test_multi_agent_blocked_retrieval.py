"""Reproduce the paid v19 source failure without further paid retries."""
import pytest
from multi_agent_pipeline_v2 import blocked_retrieval_reason
from test_multi_agent_pipeline_v2 import agents, pipeline


@pytest.mark.parametrize("statuses,expected", [
    (["rate_limited", "deadline_skipped", "deadline_skipped"], "RETRIEVAL_SOURCE_RATE_LIMITED"),
    (["cooldown_skipped", "source_unreachable"], "RETRIEVAL_SOURCE_RATE_LIMITED"),
    (["deadline_skipped", "deadline_skipped"], "RETRIEVAL_SOURCE_DEADLINE"),
    (["source_unreachable", "deadline_skipped"], "RETRIEVAL_SOURCE_UNREACHABLE"),
    (["source_unreachable"], "RETRIEVAL_SOURCE_UNREACHABLE"),
    (["no_results", "rate_limited"], None),
    (["ok", "deadline_skipped"], None),
    (["no_results_in_requested_years"], None),
    (["parser_failed"], None),
    ([], None),
])
def test_only_all_blocked_searches_are_infrastructure_failures(statuses, expected):
    evidence = {"evidence": [], "observations": [{"query": "q", "source_status": status} for status in statuses]
                + [{"source_status": "rag_selection_completed"}]}
    assert blocked_retrieval_reason(evidence) == expected
    evidence["evidence"] = [{"evidence_id": "approved-or-reviewable"}]
    assert blocked_retrieval_reason(evidence) is None


@pytest.mark.parametrize("status,code,text", [
    ("rate_limited", "RETRIEVAL_SOURCE_RATE_LIMITED", "限流"),
    ("deadline_skipped", "RETRIEVAL_SOURCE_DEADLINE", "检索等待预算"),
])
def test_no_empty_review_gap_or_writer_calls_when_source_is_blocked(tmp_path, status, code, text):
    workers, calls = agents()
    flow, store = pipeline(tmp_path, workers, search=lambda *_args: {"status": status, "papers": []})
    result = flow.run("blocked", "owner", "definition question")
    assert result["run"]["status"] == "failed" and result["run"]["failure_code"] == code
    assert result["run"]["model_calls_used"] == 2 and calls == ["planner", "retriever"]
    assert text in result["direct_answer"]
    assert store.get_run("blocked")["status"] == "failed"
    final = flow.artifacts.get(result["final_artifact_id"])
    assert final["artifact_refs"].get("evidence") and not final["artifact_refs"].get("review")
