"""Compact Writer inputs preserve exact sources and ordered task coverage."""
from copy import deepcopy
import hashlib
import json

import pytest

from multi_agent_sections import writer_jobs, writer_job_evidence, writer_job_material
from multi_agent_skills import skill_bundle, skill_catalog
from test_multi_agent_sections import composition


def test_material_references_single_exact_source_without_changing_dossier():
    outline, dossiers, _ = composition()
    job = writer_jobs(outline, dossiers, 'standard', 10)[0]
    source = writer_job_evidence(job, dossiers)
    before = deepcopy((job, dossiers, source))
    result = writer_job_material(job, dossiers, source, 'approved-section-evidence-test')
    assert result['schema_version'].endswith('/v2')
    assert all('evidence' not in s and 'requirements' not in s for s in result['sections'])
    assert [s['approved_evidence_ids'] for s in result['sections']] == [s['approved_evidence_ids'] for s in dossiers['dossiers']]
    assert [s['requirement_ids'] for s in result['sections']] == [s['requirement_ids'] for s in job['sections']]
    assert (job, dossiers, source) == before
    assert not result['excerpts_summarized_or_truncated']
    assert not result['semantic_auto_approval']


@pytest.mark.parametrize('fault', ['excerpt', 'page', 'rejected', 'missing', 'duplicate', 'section', 'association'])
def test_no_source_collision_or_invalid_reference_can_be_deduplicated(fault):
    outline, dossiers, _ = composition()
    job = writer_jobs(outline, dossiers, 'standard', 10)[0]
    source = writer_job_evidence(job, dossiers)
    if fault == 'excerpt': source['evidence'][0]['excerpt'] += ' changed'
    elif fault == 'page': source['evidence'][0]['locator']['page'] = 999
    elif fault == 'rejected': source['evidence'][0]['review_status'] = 'rejected'
    elif fault == 'missing': source['evidence'] = []
    elif fault == 'duplicate': source['evidence'].append(deepcopy(source['evidence'][0]))
    elif fault == 'section': job['section_ids'].append('missing-section')
    elif fault == 'association': dossiers['dossiers'][0]['approved_evidence_ids'] = ['unknown']
    with pytest.raises(ValueError, match='WRITER_MATERIAL_'):
        writer_job_material(job, dossiers, source, 'source')


def test_weighted_partition_isolates_all_asks_summary_without_more_calls():
    outline, dossiers, _ = composition()
    section, dossier = outline['sections'][0], dossiers['dossiers'][0]
    weights = [20, 5, 5, 5, 3, 2]
    outline['sections'] = [{**deepcopy(section), 'section_id': f's{i}',
        'requirement_ids': [f'r{j}' for j in range(n)]} for i, n in enumerate(weights)]
    dossiers['dossiers'] = [{**deepcopy(dossier), 'section_id': f's{i}'} for i in range(6)]
    jobs = writer_jobs(outline, dossiers, 'enhanced', 13)
    assert len(jobs) == 3
    assert jobs[0]['section_ids'] == ['s0']
    assert [s for j in jobs for s in j['section_ids']] == [f's{i}' for i in range(6)]
    assert max(sum(len(s['requirement_ids']) for s in j['sections']) for j in jobs) == 20
    assert [sum(len(s['requirement_ids']) for s in j['sections']) for j in jobs] == [20, 10, 10]


def test_auditor_revision_skill_has_audit_output_and_its_own_verified_hash():
    catalog = next(s for s in skill_catalog()['skills'] if s['skill_id'] == 'report-revision')
    results = {}
    for role in ('writer', 'citation_auditor'):
        row = next(s for s in skill_bundle(role, revision=True)['skills'] if s['skill_id'] == 'report-revision')
        content = {k: v for k, v in row.items() if k not in {'skill_id', 'version', 'sha256'}}
        assert row['sha256'] == hashlib.sha256(json.dumps(content, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
        assert row['sha256'] == catalog['role_sha256'][role]
        results[role] = row
    assert results['writer']['sha256'] != results['citation_auditor']['sha256']
    text = ' '.join(results['citation_auditor']['instructions'])
    assert 'Return audit decisions' in text
    assert 'return the complete revised draft' not in text
    assert 'changed AND unchanged' in text


def test_workflow_delivers_reference_material_and_exact_sources_to_writer(tmp_path):
    from multi_agent_pipeline_v2 import LiteraturePipelineV2, DeterministicLiteratureExecutor
    from multi_agent_agents import ArtifactDirectory
    from multi_agent_workflow import WorkflowStore
    from tools.multi_agent_cli import _mock_agents, _mock_search
    workers = _mock_agents()
    original = workers.writer.handler
    checked = []
    def writer(packet):
        materials = [i['payload'] for i in packet['inputs']
                     if i['payload'].get('schema_version') == 'sciassistant.section-writing-material/v2']
        assert len(materials) == 1
        material = materials[0]
        source = artifacts.get(material['source_artifact_id'])
        assert source in [i['payload'] for i in packet['inputs']]
        assert source['evidence'] and all('evidence' not in s for s in material['sections'])
        checked.append(material)
        return original(packet)
    workers.writer.handler = writer
    artifacts = ArtifactDirectory(tmp_path/'artifacts')
    flow = LiteraturePipelineV2(WorkflowStore(tmp_path/'workflow.sqlite3'), artifacts, workers,
        DeterministicLiteratureExecutor(_mock_search), event_path=tmp_path/'events.jsonl')
    result = flow.run('compact-writer', 'owner', '请解释A。请比较A和B。')
    assert checked and result['run']['status'] == 'partial'
