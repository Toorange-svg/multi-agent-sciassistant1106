"""Entity/aspect retrieval is bounded provenance, never evidence approval."""
from copy import deepcopy
import time
import pytest

from multi_agent_handoffs import compile_passage_needs, PLAN_SCHEMA, need_flow_snapshot
from multi_agent_rag import EvidenceStore, HybridRetriever, RagError, build_chunks
from multi_agent_live import LiveArxivRagExecutor


def group():
    return {'id': 'g1', 'kind': 'research', 'core': ['Alpha', 'Beta', 'Gamma'],
        'support': ['image fairness'], 'metrics': ['definition'], 'question': 'Explain native tasks',
        'evidence_needs': [{'entity': name, 'question_quote': name, 'aspect': 'definition', 'source_title': name+' Original'}
                           for name in ['Alpha', 'Beta', 'Gamma']]}


def catalogue():
    return {name.lower(): {'title': name+' Original'} for name in ['Alpha', 'Beta', 'Gamma']}


def store_docs(tmp_path):
    store = EvidenceStore(tmp_path/'e.sqlite3')
    native = {
        'alpha': 'We propose a model. Given input prompts, it predicts output masks for the segmentation task.',
        'beta': 'Our object detection model takes input images and outputs bounding boxes with predicted categories.',
        'gamma': 'The task uses text input and visual encoders. Given language descriptions, this model produces output similarity scores.',
    }
    for doc, metadata in catalogue().items():
        texts = [doc+' Image fairness concerns people and celebrity recognition performance.',
            doc+' '+native[doc],
            doc+' Applications to fairness and celebrities require further evaluation.']
        chunks = build_chunks(doc, doc, metadata['title'], [
            {'text': value, 'page': i+1, 'bbox': [1, 2, 3, 4]} for i,value in enumerate(texts)])
        store.index_document({'document_id': doc, 'paper_id': doc, **metadata, 'content_hash': doc}, chunks)
    return store


def needs():
    return compile_passage_needs(group(), catalogue())['needs']


def test_compiler_binds_all_entities_to_actual_original_titles_without_public_actions():
    topic = group(); before = deepcopy(topic)
    result = compile_passage_needs(topic, catalogue())
    assert len(result['needs']) == 3
    assert [n['document_ids'] for n in result['needs']] == [['alpha'], ['beta'], ['gamma']]
    assert all(n['source_binding'] == 'exact_title' for n in result['needs'])
    assert result['new_public_requests'] == 0 and not result['semantic_support_verified']
    assert topic == before


def test_unindexed_title_is_not_silently_bound_to_another_paper():
    topic = group(); topic['evidence_needs'][0]['source_title'] = 'Unverified title'
    result = compile_passage_needs(topic, catalogue())
    assert result['skipped'] == [{'need_id':'g1-n1', 'entity':'Alpha', 'reason_code':'SOURCE_TITLE_NOT_INDEXED'}]
    assert [n['need_id'] for n in result['needs']] == ['g1-n2','g1-n3']


def test_uploaded_scope_is_explicit_and_does_not_create_a_public_title_lookup():
    result = compile_passage_needs(group(), {'private':{}}, uploaded_document_id='private')
    assert all(n['document_ids'] == ['private'] and n['source_binding'] == 'uploaded_scope' for n in result['needs'])
    assert not result['new_public_requests']


class IncidentalFirst:
    def rerank(self, query, chunks):
        return [c['chunk_id'] for c in sorted(chunks, key=lambda c:c['page'] != 1)]


def test_three_entities_get_native_task_passages_before_incidental_high_global_ranks(tmp_path):
    store = store_docs(tmp_path)
    packets = HybridRetriever(store, reranker=IncidentalFirst()).search('image fairness',
        limit=4, per_document=2, context_budget=4000, document_ids=set(catalogue()),
        representative_document_ids=['alpha','beta'], evidence_needs=needs())
    assert [p['document_id'] for p in packets[:3]] == ['alpha','beta','gamma']
    assert all(p['locator']['page'] == 2 for p in packets[:3])
    assert [p['retrieval']['evidence_need_selection']['selected_for_need_id'] for p in packets[:3]] == ['g1-n1','g1-n2','g1-n3']
    assert all(not p['retrieval']['evidence_need_selection']['semantic_support_verified'] for p in packets)
    assert all('review_status' not in p for p in packets)
    assert len(packets) <= 4


def test_top_one_reranker_cannot_erase_other_entity_recall(tmp_path):
    class TopOne:
        def rerank(self, query, chunks):
            return [chunks[0]['chunk_id']]
    packets = HybridRetriever(store_docs(tmp_path), reranker=TopOne()).search('image fairness',
        limit=3, document_ids=set(catalogue()), evidence_needs=needs())
    assert {p['document_id'] for p in packets} == set(catalogue())


@pytest.mark.parametrize('options', [{'limit':1},{'per_document':1},{'context_budget':1}])
def test_need_reservations_do_not_exceed_existing_limits(tmp_path, options):
    configured = dict(limit=4, per_document=2, context_budget=4000, document_ids=set(catalogue()), evidence_needs=needs())
    configured.update(options)
    packets = HybridRetriever(store_docs(tmp_path)).search('task', **configured)
    assert len(packets) <= configured['limit']
    assert all(sum(q['document_id']==p['document_id'] for q in packets) <= configured['per_document'] for p in packets)
    if options.get('context_budget') == 1:
        assert not packets


@pytest.mark.parametrize('fault', ['unknown_field','outside_document','no_scope','bad_aspect','duplicate_id','too_many','bad_query'])
def test_bad_need_contract_rejected_before_store_access(tmp_path, fault, monkeypatch):
    store = store_docs(tmp_path); configured = needs()
    scope = set(catalogue())
    if fault == 'unknown_field': configured[0]['approval'] = True
    elif fault == 'outside_document': configured[0]['document_ids'] = ['someone-else']
    elif fault == 'no_scope': scope = None
    elif fault == 'bad_aspect': configured[0]['aspect'] = []
    elif fault == 'duplicate_id': configured[1]['need_id'] = configured[0]['need_id']
    elif fault == 'too_many': configured = configured * 2
    else: configured[0]['query'] = 'bad\nquery'
    monkeypatch.setattr(store,'lexical_search',lambda *a,**k:pytest.fail('must validate before recall'))
    with pytest.raises(RagError, match='scoped evidence needs'):
        HybridRetriever(store).search('x',document_ids=scope,evidence_needs=configured)


def test_need_deadline_keeps_base_recall_without_claiming_execution(tmp_path):
    packets = HybridRetriever(store_docs(tmp_path)).search('image fairness',
        document_ids=set(catalogue()), evidence_needs=needs(), deadline_monotonic=time.monotonic()-1)
    assert packets and all(p['retrieval']['evidence_need_selection']['executed_need_ids'] == [] for p in packets)
    assert all(p['retrieval']['evidence_need_selection']['selected_for_need_id'] is None for p in packets)


@pytest.mark.parametrize('schema', [PLAN_SCHEMA,'sciassistant.research-plan/v5','sciassistant.research-plan/v6','sciassistant.research-plan/v7'])
def test_public_executor_transmits_three_scoped_needs_and_keeps_global_quotas(tmp_path,schema):
    services = HybridRetriever(EvidenceStore(tmp_path/'e.sqlite3')); seen=[]
    services.search = lambda query,**kw: seen.append(kw) or []
    executor = LiveArxivRagExecutor(tmp_path/'run',tmp_path/'storage',rag_mode='lexical',services=services)
    executor.configure_plan({'schema_version':schema,'groups':[group()]})
    executor.candidates = {f'1234.0000{i}': {'paper_id':f'1234.0000{i}v1','evidence_id':f'a{i}',
        'title':name+' Original','excerpt':'task','group_ids':['g1']} for i,name in enumerate(['Alpha','Beta','Gamma'])}
    executor.ingested = {f'arxiv-1234-0000{i}v1' for i in range(3)}
    executor.group_queries={'g1':['original public query']}
    before=deepcopy(executor.group_queries)
    executor._select_packets()
    assert len(seen[0]['evidence_needs'])==3 and seen[0]['passage_queries']==[]
    assert (seen[0]['limit'],seen[0]['per_document'],seen[0]['context_budget'])==(4,2,4000)
    assert executor.group_queries==before


def test_need_flow_records_selection_without_claiming_semantic_coverage():
    plan={'groups':[group()]}
    evidence={'evidence':[{'evidence_id':'e1','excerpt':'Alias absent in this text','retrieval':{
        'evidence_need_selection':{'selected_for_need_id':'g1-n2','candidate_need_ids':['g1-n2']}}}]}
    result=need_flow_snapshot(plan,[],evidence)
    assert result['needs'][1]['selected_for_need']==['e1']
    assert result['needs'][1]['presented_literal_mentions']==[]
    assert not result['semantic_coverage_verified']


def test_vector_scope_and_duplicate_query_embedding_are_bounded(tmp_path):
    class Embedding:
        def __init__(self): self.calls=[]
        def embed_query(self, value): self.calls.append(value); return [1., 0.]
    class Vectors:
        def __init__(self): self.scopes=[]
        def search(self, vector, **kw): self.scopes.append(kw['document_ids']); return []
    embedding, vectors = Embedding(), Vectors()
    configured=needs(); configured[1]['query']=configured[0]['query']
    packets=HybridRetriever(store_docs(tmp_path),embedding,vectors,vector_required=True).search(
        'image fairness',document_ids=set(catalogue()),evidence_needs=configured)
    assert len(embedding.calls)==3  # Base + two unique need queries; not a model-agent call.
    assert vectors.scopes==[set(catalogue()),{'alpha'},{'beta'},{'gamma'}]
    assert packets


def test_duplicate_entity_aspects_do_not_crowd_out_another_entity(tmp_path):
    configured=needs()
    repeated={**configured[0],'need_id':'g1-n4','aspect':'mechanism'}
    configured.insert(1,repeated)
    packets=HybridRetriever(store_docs(tmp_path)).search('image fairness',limit=3,
        document_ids=set(catalogue()),evidence_needs=configured)
    assert [p['retrieval']['evidence_need_selection']['selected_for_need_id'] for p in packets]==['g1-n1','g1-n2','g1-n3']


def test_public_backend_cannot_assign_foreign_source_to_exact_title_need(tmp_path,monkeypatch):
    store=store_docs(tmp_path)
    other=store.lexical_search('model',document_ids={'beta'})
    monkeypatch.setattr(store,'lexical_search',lambda *a,**kw:other)
    packets=HybridRetriever(store).search('output',document_ids={'alpha','beta'},evidence_needs=needs()[:1])
    assert packets
    assert all(p['retrieval']['evidence_need_selection']['selected_for_need_id'] is None for p in packets)


@pytest.mark.parametrize('schema', [PLAN_SCHEMA,'sciassistant.research-plan/v5','sciassistant.research-plan/v6','sciassistant.research-plan/v7'])
def test_uploaded_executor_runs_typed_need_against_private_index_only(tmp_path,schema):
    from test_multi_agent_live import create_pdf
    from test_multi_agent_local_pdf import action
    from multi_agent_local_pdf import LocalPdfRagExecutor
    executor=LocalPdfRagExecutor(tmp_path/'run',create_pdf(tmp_path/'input'),rag_mode='lexical')
    topic=group(); topic['evidence_needs']=[{'entity':'PagedAttention','question_quote':'PagedAttention',
        'aspect':'mechanism','source_title':''}]
    executor.configure_plan({'schema_version':schema,'groups':[topic]})
    result=executor.execute(action(),group_ids={'g1'},deadline=time.monotonic()+30)
    assert result['evidence']
    selection=result['evidence'][0]['retrieval']['evidence_need_selection']
    assert selection['planned'][0]['document_ids']==[executor.document_id]
    assert selection['planned'][0]['source_binding']=='uploaded_scope'
    assert all(p['source']=='uploaded_pdf' for p in result['evidence'])
    assert executor.source_context['public_search_allowed'] is False


def test_original_definition_cues_tie_prefers_early_native_description_not_late_application(tmp_path):
    store=EvidenceStore(tmp_path/'e.sqlite3')
    blocks=[{'text':'We propose a model. Given paired input images and text, it predicts output similarity scores.', 'page':2},
        {'text':'Given the flexibility of our model, output labels affect bias in a downstream task.', 'page':23}]
    chunks=build_chunks('alpha','alpha','Alpha Original',blocks)
    store.index_document({'document_id':'alpha','paper_id':'alpha','title':'Alpha Original','content_hash':'x'},chunks)
    class LateFirst:
        def rerank(self,query,chunks): return [c['chunk_id'] for c in sorted(chunks,key=lambda c:-c['page'])]
    packets=HybridRetriever(store,reranker=LateFirst()).search('downstream bias labels',
        limit=1,document_ids={'alpha'},evidence_needs=needs()[:1])
    assert packets[0]['locator']['page']==2
    assert not packets[0]['retrieval']['evidence_need_selection']['semantic_support_verified']
