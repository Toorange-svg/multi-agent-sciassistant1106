"""Keep packaged dependencies, notices and production attestations consistent."""

import hashlib
import json
import shutil
from pathlib import Path

import yaml

from tools import cloud_release


ROOT = Path(__file__).resolve().parents[1]


def test_pymupdf_requirement_is_truthfully_disclosed():
    requirements = (ROOT / "deepdiver_v2/requirements.txt").read_text(encoding="utf-8")
    notice = (ROOT / "NOTICE").read_text(encoding="utf-8")
    assert "PyMuPDF>=1.24.0" in requirements
    assert "PyMuPDF/fitz (GNU AGPL-3.0 OR commercial license)" in notice
    assert "PyMuPDF/fitz (AGPL-3.0 License) - NOT INCLUDED" not in notice
    assert "Apache-2.0 license of SciAssistant's original code" in " ".join(notice.split())


def test_repository_and_projected_image_require_license_files(tmp_path):
    assert cloud_release.file_checks(ROOT)["passed"]
    for name in cloud_release.REQUIRED:
        source = ROOT / name
        destination = tmp_path / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(source.read_bytes())
    # Do not copy developer-local SQL or user data into the projected image.
    manifest = json.loads((ROOT / 'chatAi/assets/manifest.json').read_text(encoding='utf8'))
    for row in manifest['files']:
        target = tmp_path / 'chatAi' / row['path']
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / 'chatAi' / row['path'], target)
    constraints = tmp_path / "deepdiver_v2/constraints.cloud.txt"
    artifacts = tmp_path / "deepdiver_v2/requirements.cloud.hashes.txt"
    (tmp_path / ".dependency-lock.json").write_text(json.dumps({
        "schema": "sciassistant.dependency-lock/v2",
        "sha256": hashlib.sha256(artifacts.read_bytes()).hexdigest(),
        "constraints_sha256": hashlib.sha256(constraints.read_bytes()).hexdigest(),
        "package_count": 85,
        "base_image": cloud_release.BASE_IMAGE,
        "platform": "linux/amd64",
    }), encoding="utf-8")
    assert cloud_release.file_checks(tmp_path, image=True)["passed"]
    (tmp_path / "NOTICE").unlink()
    assert not cloud_release.file_checks(tmp_path, image=True)["passed"]


def test_account_allowlist_and_dockerfile_ship_license_files():
    rules = (ROOT / "Dockerfile.account.cloud.dockerignore").read_text(encoding="utf-8").splitlines()
    dockerfile = (ROOT / "Dockerfile.account.cloud").read_text(encoding="utf-8")
    assert "!LICENSE" in rules and "!NOTICE" in rules
    assert "COPY LICENSE NOTICE /app/" in dockerfile


def test_both_images_publish_non_secret_license_mode_label():
    for name in ("Dockerfile.account.cloud", "Dockerfile.cloud"):
        dockerfile = (ROOT / name).read_text(encoding="utf-8")
        assert "ARG PYMUPDF_LICENSE_MODE=review-required" in dockerfile
        assert "org.sciassistant.dependency.pymupdf.license-mode=$PYMUPDF_LICENSE_MODE" in dockerfile


def test_all_compose_builds_forward_license_mode():
    account = yaml.safe_load((ROOT / "docker-compose.account.cloud.yml").read_text(encoding="utf-8"))
    research = yaml.safe_load((ROOT / "docker-compose.cloud.yml").read_text(encoding="utf-8"))
    for service in ("sciassistant-account", "schema-provision", "schema-migrate", "mcp"):
        assert account["services"][service]["build"]["args"]["PYMUPDF_LICENSE_MODE"] == (
            "${PYMUPDF_LICENSE_MODE:-review-required}")
    for service in ("sciassistant-web", "mcp"):
        assert research["services"][service]["build"]["args"]["PYMUPDF_LICENSE_MODE"] == (
            "${PYMUPDF_LICENSE_MODE:-review-required}")
