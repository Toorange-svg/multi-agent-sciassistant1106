"""Capacity and complete-audit local faults; never semantic automatic approval."""
from copy import deepcopy
import hashlib
import json
import time

import pytest

from multi_agent_live import LiveModelClient, ROLE_OUTPUT_LIMITS, ROLE_OUTPUT_SCHEMAS, COMMON_PROMPT, effective_role_prompt
from multi_agent_quality import AUDIT_PROTOCOL_POLICY, check_audit, publication_rejections, publication_decisions, citation_audit_input
from multi_agent_pipeline_v2 import render_approved_evidence_fallback
from test_multi_agent_absence_basis import audit, absence
from test_multi_agent_report_fields import draft, evidence, QUOTE
from test_multi_agent_live import config, Response
from test_multi_agent_pipeline_v2 import agents, pipeline


def inputs():
    data = draft()
    data["audit_protocol_policy"] = AUDIT_PROTOCOL_POLICY
    data["claims"] += [{**deepcopy(data["claims"][0]), "claim_id": "c2"},
                       {**deepcopy(data["claims"][0]), "claim_id": "c3", "depends_on_claim_ids": ["c1"]}]
    return data, audit(data), evidence()


def test_approved_evidence_fallback_is_excerpt_only():
    value = {"evidence": [{"evidence_id": "pdf-1", "title": "Paper", "excerpt": "原文事实。",
                           "locator": {"page": 3}}]}
    rendered = render_approved_evidence_fallback(value)
    assert "已读取并审查了上传文档" in rendered
    assert "原文事实" in rendered and "第 3 页" in rendered
    assert "新的科研结论" in rendered


@pytest.mark.parametrize("field", ["text", "scope_note", "qualification"])
def test_bad_literal_record_blocks_only_this_claim_and_dependents(field):
    data, value, sources = inputs()
    absence(value, "not a literal substring", field=field)
    before = deepcopy((data, value, sources))
    checked = check_audit(value, data, sources)
    assert not checked["contract_errors"]
    assert checked["protocol_issues"][0]["field"] == field
    assert publication_rejections(checked, data) == {"c1", "c3"}
    assert publication_rejections(check_audit(checked, data, sources), data) == {"c1", "c3"}
    assert (data, value, sources) == before
    decisions = publication_decisions(checked, data, "audit-1")["claims"]
    assert [row["claim_id"] for row in decisions if row["published"]] == ["c2"]
    assert decisions[0]["protocol_issues"]
    assert citation_audit_input(data, sources)["audit_protocol_policy"] == AUDIT_PROTOCOL_POLICY


def test_legacy_policy_does_not_reinterpret_old_global_fault_as_approval():
    data, value, sources = inputs()
    del data["audit_protocol_policy"]
    absence(value, "not a literal substring")
    checked = check_audit(value, data, sources)
    assert "AUDIT_ABSENCE_CHECKS_INVALID" in checked["contract_errors"]
    assert publication_rejections(checked, data) == {"c1", "c2", "c3"}


@pytest.mark.parametrize("fault", ["omit", "duplicate", "unknown", "rejected_set", "status", "extra_field", "field_verdict", "forged_evidence"])
def test_incomplete_or_contradictory_audit_still_blocks_every_claim(fault):
    data, value, sources = inputs()
    if fault == "omit":
        value["claim_results"].pop()
    elif fault == "duplicate":
        value["claim_results"].append(deepcopy(value["claim_results"][0]))
    elif fault == "unknown":
        value["claim_results"][0]["claim_id"] = "invented"
    elif fault == "rejected_set":
        value["rejected_claim_ids"] = ["c1"]
    elif fault == "status":
        value["status"] = "needs_revision"
    elif fault == "extra_field":
        value["claim_results"][0]["field_results"]["extra"] = {}
    elif fault == "field_verdict":
        value["claim_results"][0]["field_results"]["text"]["status"] = "unsupported"
    else:
        value["claim_results"][0]["evidence_ids"] = ["invented"]
    checked = check_audit(value, data, sources)
    assert checked["contract_errors"]
    assert publication_rejections(checked, data) == {"c1", "c2", "c3"}


def test_forged_empty_local_issues_do_not_rescue_bad_literal_or_number():
    data, value, sources = inputs()
    absence(value, "not a literal substring")
    value["protocol_issues"] = []
    checked = check_audit(value, data, sources)
    checked["code_issues"] = [{"claim_id": "c2", "reason": "UNSUPPORTED_NUMBER"}]
    assert publication_rejections(checked, data) == {"c1", "c2", "c3"}


@pytest.mark.parametrize("role", sorted(ROLE_OUTPUT_LIMITS))
def test_evidence_review_writing_audit_capacity_and_actual_prompt_hash(monkeypatch, role):
    monkeypatch.setenv("MODEL_REQUEST_URL", "https://example.test/v1/chat/completions")
    observed = {}
    response = Response({"output": {"schema_version": ROLE_OUTPUT_SCHEMAS[role]}})
    def post(_url, **kwargs):
        observed.update(kwargs)
        return response
    client = LiveModelClient(config(), post=post)
    client.call(role, {"deadline_at": time.time() + 20, "inputs": []})
    assert observed["json"]["max_tokens"] == (8192 if role in {"planner", "writer", "reviewer", "citation_auditor"} else 4500)
    assert observed["max_key_attempts"] == 1 and observed["timeout"] <= 20
    actual_prompt = observed["json"]["messages"][0]["content"]
    assert actual_prompt == COMMON_PROMPT + effective_role_prompt(role)
    assert client.prompt_metadata()[role]["sha256"] == hashlib.sha256(actual_prompt.encode()).hexdigest()
    assert client.prompt_metadata()[role]["output_limit"] == ROLE_OUTPUT_LIMITS[role]
    assert response.closed


def test_parseable_json_with_provider_length_is_not_trusted(monkeypatch):
    monkeypatch.setenv("MODEL_REQUEST_URL", "https://example.test/v1/chat/completions")
    class Truncated(Response):
        def iter_content(self, **_):
            yield json.dumps({"choices": [{"finish_reason": "length", "message": {
                "content": json.dumps({"output": {"schema_version": ROLE_OUTPUT_SCHEMAS["planner"], "groups": []}})}}]}).encode()
    response = Truncated({})
    result = LiveModelClient(config(), post=lambda *_a, **_k: response).call("planner", {"deadline_at": time.time()+20, "inputs": []})
    assert result["error_code"] == "MODEL_OUTPUT_TRUNCATED" and result["output"]["output_limit"] == 8192
    assert response.closed


@pytest.mark.parametrize("correction", ["bad_literal", "global_fault", "truncated", "fixed"])
def test_workflow_protocol_correction_no_writer_rework_and_preserves_independent_claim(tmp_path, correction):
    configured, calls = agents()
    data = draft()
    data["claims"][0]["evidence_ids"] = ["arxiv-1"]
    data["claims"].append({**deepcopy(data["claims"][0]), "claim_id": "c2"})
    def writer(_):
        calls.append("writer")
        return {"output": deepcopy(data)}
    seen = []
    def auditor(packet):
        calls.append("citation_auditor")
        target = next(i["payload"] for i in packet["inputs"] if i["payload"].get("claims"))
        value = audit(target)
        if not seen or correction != "fixed":
            absence(value, "not a literal substring")
        if seen and correction == "global_fault":
            value["claim_results"].pop()
        if seen and correction == "truncated":
            seen.append(None)
            return {"status": "failed", "error_code": "MODEL_OUTPUT_TRUNCATED"}
        if seen:
            report = next(i["payload"] for i in packet["inputs"] if i["payload"].get("stage") == "citation_auditor")
            assert report["field_protocol_issues"][0]["field"] == "qualification"
        seen.append(value)
        return {"output": value}
    configured.writer.handler, configured.citation_auditor.handler = writer, auditor
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {"status": "ok", "papers": [{"paper_id": "1", "title": "Paper", "abstract": QUOTE}]})
    result = flow.run("local-format", "owner", "Define A")
    assert len(seen) == 2 and calls.count("writer") == 1 and result["run"]["model_calls_used"] == 6
    assert result["run"]["status"] == ("completed" if correction == "fixed" else "needs_review")
    final = flow.artifacts.get(result["final_artifact_id"])
    pub = flow.artifacts.get(final["artifact_refs"]["publication"])
    assert [r["claim_id"] for r in pub["claims"] if r["published"]] == (["c1", "c2"] if correction == "fixed" else ["c2"])
    if correction in {"global_fault", "truncated"}:
        assert "audit_correction_prior_retained" in (tmp_path/"events.jsonl").read_text(encoding="utf-8")


def test_zero_audited_claims_is_failed_and_persisted_not_exit0_needs_review(tmp_path):
    configured, calls = agents()
    data = draft()
    data["claims"][0]["evidence_ids"] = ["arxiv-1"]
    configured.writer.handler = lambda _: {"output": deepcopy(data)}
    def auditor(_):
        calls.append("citation_auditor")
        return {"output": absence(audit(data), "not a literal substring")}
    configured.citation_auditor.handler = auditor
    flow, store = pipeline(tmp_path, configured, search=lambda *_: {"status": "ok", "papers": [{"paper_id": "1", "title": "Paper", "abstract": QUOTE}]})
    result = flow.run("zero-published", "owner", "Define A")
    assert result["run"]["status"] == "failed"
    assert store.get_run("zero-published")["failure_code"] == "NO_AUDITED_CLAIMS"
    final = flow.artifacts.get(result["final_artifact_id"])
    assert final["status"] == "failed" and final["failure_code"] == "NO_AUDITED_CLAIMS"
    assert "未能交付" in final["direct_answer"] and result["run"]["model_calls_used"] == 6
