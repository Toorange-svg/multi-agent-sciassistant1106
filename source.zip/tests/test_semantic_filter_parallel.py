"""Serial-vs-parallel equivalence tests for the semantic literature filter.

The parallel version of ``_semantic_filter_literature_candidates`` must
produce exactly the same {paper_id: decision} mapping as the serial version
for the same candidates and the same scripted backend: same keys, same
labels, same reasons, same unjudged set — including when the backend omits
ids, hallucinates a duplicate id across batches, or fails whole batches, and
regardless of candidate order or request completion order.
"""
import copy
import json
import os
import sys
import time
import unittest
from pathlib import Path
from unittest.mock import patch

_ROOT = Path(__file__).resolve().parents[1]
for _entry in (str(_ROOT), str(_ROOT / "deepdiver_v2")):
    if _entry not in sys.path:
        sys.path.insert(0, _entry)

from deepdiver_v2.cli import demo  # noqa: E402


class _FakeConfig:
    model_name = "fake-model"

    def get_custom_llm_config(self):
        return {"url": "http://semantic-filter-fake.local", "token": "", "timeout": 5}


class _FakeResponse:
    def __init__(self, payload):
        self._payload = payload

    def raise_for_status(self):
        return None

    def json(self):
        return self._payload


class _ScriptedBackend:
    """Fake LLM endpoint that judges every supplied candidate by rule.

    Behaviour switches let each test inject the awkward cases the real model
    produces: omitted ids, a hallucinated duplicate id in later batches, and
    whole batches that always fail.
    """

    def __init__(self, latency=0.0, omit_ids=(), fail_ids=frozenset(),
                 hallucinated=None):
        self.latency = latency
        self.omit_ids = set(omit_ids)
        self.fail_ids = frozenset(fail_ids)
        self.hallucinated = hallucinated or {}
        self.calls = 0

    def _decide(self, paper_id):
        label = "strong" if int(paper_id[1:]) % 2 == 0 else "rejected"
        return {"paper_id": paper_id, "label": label, "reason": f"rule-{paper_id}"}

    def __call__(self, url, headers=None, timeout=None, **kwargs):
        self.calls += 1
        if self.latency:
            time.sleep(self.latency)
        payload = kwargs["json"]
        content = payload["messages"][0]["content"]
        marker = "Candidates: "
        start = content.index(marker) + len(marker)
        supplied, _ = json.JSONDecoder().raw_decode(content[start:])
        ids = [item["paper_id"] for item in supplied]
        if self.fail_ids & set(ids):
            # Both the normal and the shortened-abstract attempt fail.
            raise requests_error()
        missing_pass = "Return exactly one decision" in content
        decisions = []
        for paper_id in ids:
            if not missing_pass and paper_id in self.omit_ids:
                continue
            decisions.append(self._decide(paper_id))
        if not missing_pass:
            for paper_id, label in self.hallucinated.items():
                if paper_id not in ids:
                    decisions.append(
                        {"paper_id": paper_id, "label": label, "reason": "hallucinated"}
                    )
        content_json = json.dumps({"decisions": decisions})
        return _FakeResponse({"choices": [{"message": {"content": content_json}}]})


def requests_error():
    import requests
    return requests.ConnectionError("simulated backend failure")


def _make_candidates(count=40):
    candidates = []
    for index in range(count):
        paper_id = f"p{index:02d}"
        candidates.append({
            "paper_id": paper_id,
            "title": f"Paper {paper_id} about retrieval",
            "abstract": f"Abstract of {paper_id}.",
            "relevance": {"score": 0.6, "matched_concepts": ["rag"]},
        })
    return candidates


def _decision_map(candidates):
    return {
        str(item["paper_id"]): (
            item["relevance"].get("semantic_label"),
            item["relevance"].get("semantic_reason", ""),
        )
        for item in candidates
    }


def _run_filter(candidates, concurrency):
    env = {
        "MODEL_REQUEST_URL": "http://semantic-filter-fake.local",
        "MODEL_REQUEST_TOKEN": "",
        "LITERATURE_SEMANTIC_FILTER_CONCURRENCY": str(concurrency),
    }
    with patch.dict(os.environ, env):
        kept, stats = demo._semantic_filter_literature_candidates(
            "retrieval augmented generation", candidates, _FakeConfig()
        )
    return _decision_map(candidates), kept, stats


class SerialParallelEquivalenceTests(unittest.TestCase):
    def test_mapping_equals_serial_with_orderly_backend(self):
        backend = _ScriptedBackend()
        with patch.object(demo.requests, "post", side_effect=backend):
            serial, _, _ = _run_filter(copy.deepcopy(_make_candidates()), 1)
        backend = _ScriptedBackend()
        with patch.object(demo.requests, "post", side_effect=backend):
            parallel, _, _ = _run_filter(copy.deepcopy(_make_candidates()), 4)
        self.assertEqual(serial.keys(), parallel.keys())
        self.assertEqual(serial, parallel)

    def test_mapping_equals_serial_with_shuffled_candidates(self):
        ordered = _make_candidates()
        shuffled = list(reversed(ordered))
        backend = _ScriptedBackend()
        with patch.object(demo.requests, "post", side_effect=backend):
            serial, _, _ = _run_filter(copy.deepcopy(ordered), 1)
        backend = _ScriptedBackend()
        with patch.object(demo.requests, "post", side_effect=backend):
            parallel, _, _ = _run_filter(copy.deepcopy(shuffled), 4)
        self.assertEqual(serial, parallel)

    def test_hallucinated_duplicate_id_matches_serial_override(self):
        # The backend answers every batch but also invents a second decision
        # for p00 with a different label. Serial semantics: a later batch's
        # decision overwrites the earlier one in by_id. The parallel merge
        # keeps batch order, so it must reproduce exactly that override.
        ordered = _make_candidates()
        backend = _ScriptedBackend(hallucinated={"p00": "weak"})
        with patch.object(demo.requests, "post", side_effect=backend):
            serial, _, _ = _run_filter(copy.deepcopy(ordered), 1)
        self.assertEqual(serial["p00"], ("weak", "hallucinated"))
        backend = _ScriptedBackend(hallucinated={"p00": "weak"})
        with patch.object(demo.requests, "post", side_effect=backend):
            parallel, _, _ = _run_filter(copy.deepcopy(ordered), 4)
        self.assertEqual(serial, parallel)

    def test_failed_batch_becomes_unjudged_identically(self):
        # Every request touching p20..p29 fails for good. Those candidates
        # must be unjudged in both versions — the same ten ids, no more, no
        # fewer — while all other batches are judged normally.
        failed = {f"p{index:02d}" for index in range(20, 30)}
        ordered = _make_candidates()
        backend = _ScriptedBackend(fail_ids=failed)
        with patch.object(demo.requests, "post", side_effect=backend):
            serial, _, _ = _run_filter(copy.deepcopy(ordered), 1)
        backend = _ScriptedBackend(fail_ids=failed)
        with patch.object(demo.requests, "post", side_effect=backend):
            parallel, _, stats = _run_filter(copy.deepcopy(ordered), 4)
        self.assertEqual(serial, parallel)
        # The failed batch's candidates keep the recoverable unjudged label
        # (same ten ids in both versions) instead of being judged or dropped.
        unjudged = {
            pid for pid, (label, _) in serial.items() if label == "fallback_unjudged"
        }
        self.assertEqual(unjudged, failed)

    def test_omitted_ids_recovered_via_missing_retry_identically(self):
        omitted = {"p05", "p15", "p25", "p35"}
        ordered = _make_candidates()
        backend = _ScriptedBackend(omit_ids=omitted)
        with patch.object(demo.requests, "post", side_effect=backend):
            serial, _, _ = _run_filter(copy.deepcopy(ordered), 1)
        self.assertTrue(omitted <= {pid for pid, (label, _) in serial.items() if label != "unjudged"})
        backend = _ScriptedBackend(omit_ids=omitted)
        with patch.object(demo.requests, "post", side_effect=backend):
            parallel, _, _ = _run_filter(copy.deepcopy(ordered), 4)
        self.assertEqual(serial, parallel)


class ParallelSpeedupTests(unittest.TestCase):
    def test_parallel_finishes_clearly_earlier(self):
        candidates = _make_candidates()
        backend = _ScriptedBackend(latency=0.15)
        started = time.monotonic()
        with patch.object(demo.requests, "post", side_effect=backend):
            _run_filter(copy.deepcopy(candidates), 1)
        serial_seconds = time.monotonic() - started

        backend = _ScriptedBackend(latency=0.15)
        started = time.monotonic()
        with patch.object(demo.requests, "post", side_effect=backend):
            _run_filter(copy.deepcopy(candidates), 4)
        parallel_seconds = time.monotonic() - started

        # 4 batches at 150 ms each: serial ~0.6 s, parallel ~0.15-0.3 s.
        self.assertLess(parallel_seconds, serial_seconds * 0.8)
        print(
            f"\n[semantic filter timing] serial={serial_seconds:.3f}s "
            f"parallel={parallel_seconds:.3f}s speedup={serial_seconds / parallel_seconds:.2f}x"
        )


if __name__ == "__main__":
    unittest.main()
