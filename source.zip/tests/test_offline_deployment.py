import importlib.util
import json
from pathlib import Path

import pytest

from tools.prepare_offline_deployment import compose_document

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('offline_server', ROOT / 'deploy/offline/server.py')
server = importlib.util.module_from_spec(spec)
spec.loader.exec_module(server)


def test_offline_compose_has_no_build_or_public_internal_services():
    document = compose_document(ROOT)
    assert set(document['services']) == {'sciassistant-account', 'database', 'mcp',
                                         'schema-provision', 'schema-migrate', 'qdrant'}
    for name, service in document['services'].items():
        assert 'build' not in service
        assert service['pull_policy'] == 'never'
        assert service['platform'] == 'linux/amd64'
        if name != 'sciassistant-account':
            assert not service.get('ports')
    account = document['services']['sciassistant-account']
    assert account['ports'] == ['127.0.0.1:${ACCOUNT_HOST_PORT:-5000}:5000']
    assert account['read_only'] is True
    assert account['environment']['MODEL_REQUEST_TOKEN'] == ''
    assert account['environment']['LLAMA_CLOUD_API_KEY'] == ''
    assert 'qdrant' in account['depends_on'] and 'schema-migrate' in account['depends_on']
    assert len(account['volumes']) == 6
    assert 'build' not in json.dumps(document)


def test_init_exclusive_no_secret_echo_or_license_autoconfirm(tmp_path, monkeypatch):
    kit = tmp_path / 'release/offline'
    kit.mkdir(parents=True)
    (kit / 'account.env.example').write_text((ROOT / '.env.account.cloud.example').read_text('utf-8'), 'utf-8')
    monkeypatch.setattr(server, 'ROOT', kit)
    source = kit.parent / 'source'
    target = tmp_path / 'private/server.env'
    record = {'source_revision': 'a3ce456', 'source_fingerprint': 'a' * 64}
    result = server.init_env(source, record, target)
    text = target.read_text('utf-8')
    assert 'PYMUPDF_AGPL_OBLIGATIONS_CONFIRMED="false"' in text
    assert 'MODEL_REQUEST_TOKEN=""' in text
    assert 'LLAMA_CLOUD_API_KEY=""' in text
    secrets = [line.split('=', 1)[1] for line in text.splitlines() if line.startswith(
        ('SECRET_KEY=', 'USER_CREDENTIAL_ENCRYPTION_KEY=', 'MYSQL_ROOT_PASSWORD=', 'QDRANT_API_KEY='))]
    assert len(set(secrets)) == 4
    assert all(value not in json.dumps(result) for value in secrets)
    with pytest.raises(FileExistsError):
        server.init_env(source, record, target)
    assert target.read_text('utf-8') == text


def test_init_refuses_private_env_inside_kit(tmp_path, monkeypatch):
    monkeypatch.setattr(server, 'ROOT', tmp_path / 'offline')
    with pytest.raises(ValueError, match='OUTSIDE'):
        server.init_env(tmp_path / 'source', {}, tmp_path / 'offline/private.env')


def test_image_id_mismatch_is_rejected(monkeypatch):
    monkeypatch.setattr(server.subprocess, 'check_output', lambda *a, **k: json.dumps([
        {'Id': 'sha256:wrong', 'Os': 'linux', 'Architecture': 'amd64'}]))
    with pytest.raises(ValueError, match='IMAGE_ID_MISMATCH'):
        server.verify_images({'images': {'test:tag': {'id': 'sha256:expected'}}})


def test_failed_license_preflight_never_starts_containers(tmp_path, monkeypatch):
    kit = tmp_path / 'offline'
    kit.mkdir()
    (kit / 'offline-manifest.json').write_text('{}', 'utf-8')
    env = tmp_path / 'private.env'
    env.write_text('PYMUPDF_AGPL_OBLIGATIONS_CONFIRMED=false\n', 'utf-8')
    if server.os.name != 'nt':
        env.chmod(0o600)
    monkeypatch.setattr(server, 'ROOT', kit)
    monkeypatch.setattr(server, 'verify_files', lambda record: (tmp_path / 'source', tmp_path / 'images.tar'))
    monkeypatch.setattr(server, 'verify_images', lambda record: None)
    monkeypatch.setattr(server.sys, 'argv', ['server.py', 'start', '--env-file', str(env)])
    calls = []

    def run(args, **kwargs):
        calls.append(args)
        if 'env-check' in args:
            raise server.subprocess.CalledProcessError(2, args)

    monkeypatch.setattr(server.subprocess, 'run', run)
    with pytest.raises(server.subprocess.CalledProcessError):
        server.main()
    assert not any('up' in args for args in calls)
    assert calls[0][-2:] == ['config', '--quiet']
    assert '--network' in calls[1] and '--read-only' in calls[1]
