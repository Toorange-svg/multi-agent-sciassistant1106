"""Selection, source-tier and report-structure regression; no public requests."""
import pytest

from multi_agent_evidence import evidence_strength
from multi_agent_pipeline_v2 import check_review, check_draft, render_claims
from multi_agent_rag import HybridRetriever, EvidenceStore, build_chunks
from test_multi_agent_reading_batches import executor, actions, plan


def evidence(scope="abstract", page=None):
    return {"evidence": [{"evidence_id": "e1", "coverage_scope": scope, "locator": {"page": page},
                          "excerpt": "Reports 2x throughput on specified hardware."}]}


@pytest.mark.parametrize("scope,page,tier", [("abstract", 5, "abstract_only"),
    ("selected_chunks", 2, "fulltext_located"), ("selected_chunks", None, "fulltext_unlocated"),
    ("selected_chunks", True, "fulltext_unlocated"), (None, None, "legacy_unclassified")])
def test_source_tier_is_tool_scope_not_model_label(scope, page, tier):
    item = evidence(scope, page)["evidence"][0]
    item["evidence_strength"] = "fulltext_located"
    assert evidence_strength(item) == tier


def test_pdf_abstract_section_is_still_abstract_evidence_even_with_page():
    item = evidence("selected_chunks", 1)["evidence"][0]
    item["locator"]["section"] = "Abstract"
    assert evidence_strength(item) == "abstract_only"


@pytest.mark.parametrize("status,expected", [("direct", "partial"), ("not_reported", "missing")])
def test_abstract_cannot_be_verified_direct_or_whole_paper_absence(status, expected):
    result = check_review({"coverage_status": "sufficient", "allowed_evidence_ids": ["e1"],
        "coverage": [{"group_id": "g1", "metric": "latency", "status": status, "evidence_ids": ["e1"]}]}, evidence(), {"g1"})
    assert result["coverage_status"] == "partial"
    assert result["coverage"][0]["status"] == expected
    assert result["allowed_evidence_ids"] == ["e1"]


def test_metric_spelling_aliases_do_not_create_false_gaps():
    review = {"coverage_status": "sufficient", "allowed_evidence_ids": ["e1"], "coverage": [
        {"group_id": "g1", "metric": metric, "status": "direct", "evidence_ids": ["e1"]}
        for metric in ["single_request_latency", "memory_footprint", "quality"]]}
    plan = {"groups": [{"id": "g1", "metrics": ["single-request latency", "memory footprint", "generation quality"]}]}
    result = check_review(review, evidence("selected_chunks", 2), {"g1"}, plan=plan)
    assert result["coverage_status"] == "sufficient" and len(result["coverage"]) == 3


def test_ttft_or_throughput_cannot_stand_in_for_single_request_latency():
    review = {"coverage_status": "sufficient", "allowed_evidence_ids": ["e1"], "coverage": [
        {"group_id": "g1", "metric": metric, "status": "direct", "evidence_ids": ["e1"]}
        for metric in ["TTFT", "throughput"]]}
    result = check_review(review, evidence("selected_chunks", 2), {"g1"}, plan={"groups": [{"id": "g1", "metrics": ["latency"]}]})
    assert result["coverage_status"] == "partial" and result["coverage"][-1]["metric"] == "latency"


def test_omitted_topics_use_only_planner_queries_before_second_searches():
    from multi_agent_pipeline_v2 import complete_initial_search_actions
    p = {"groups": [{"id": f"g{i}", "queries": [f"planned Topic{i}"]} for i in range(1, 4)]}
    proposed = [{"request_id": f"r{i}", "action": "request_arxiv_search", "arguments": {"group_id": "g1", "query": f"custom{i}"}} for i in range(2)]
    completed, recovered = complete_initial_search_actions(p, proposed)
    assert recovered == ["g2", "g3"]
    assert [r["arguments"]["group_id"] for r in completed] == ["g1", "g2", "g3", "g1"]
    assert completed[1]["arguments"]["query"] == "planned Topic2"
    assert completed[-1]["arguments"]["query"] == "custom1"
    assert len(completed) <= 6


def test_topic_completion_does_not_repair_forbidden_action_or_unknown_group():
    from multi_agent_pipeline_v2 import complete_initial_search_actions
    from multi_agent_workflow import WorkflowError
    for action, group in [("request_private_file", "g1"), ("request_arxiv_search", "other")]:
        with pytest.raises(WorkflowError):
            complete_initial_search_actions({"groups": [{"id": "g1", "queries": ["valid"]}]}, [
                {"request_id": "r", "action": action, "arguments": {"group_id": group, "query": "valid"}}])


def draft(confidence="low", section="direct_conclusion"):
    return {"direct_answer": "UNAUDITED-SUMMARY", "claims": [{"claim_id": "c1", "text": "Reports 2x throughput",
        "claim_type": "quantitative", "confidence": confidence, "section": section, "group_id": "g1", "evidence_ids": ["e1"]}]}


def test_weak_claim_requires_low_confidence_and_is_visibly_labelled():
    assert check_draft(draft("high"), evidence())[0]["reason"] == "WEAK_EVIDENCE_CONFIDENCE"
    assert check_draft(draft(), evidence()) == []
    answer = render_claims(draft(), evidence())
    assert "摘要级弱证据" in answer and "低置信度" in answer and "[1]" in answer


def test_fulltext_claim_does_not_get_abstract_warning():
    assert check_draft(draft("high"), evidence("selected_chunks", 2)) == []
    assert "摘要级弱证据" not in render_claims(draft(), evidence("selected_chunks", 2))


def test_missing_summary_requests_revision_and_never_releases_unaudited_summary():
    data = draft(section="topic_analysis")
    assert check_draft(data, evidence(), require_summary=True) == [
        {"claim_id": "report_summary", "reason": "MISSING_TOP_LEVEL_CONCLUSION"}]
    answer = render_claims(data, evidence())
    assert answer.startswith("### 直接回答")
    assert "尚未形成通过审计" in answer and "UNAUDITED-SUMMARY" not in answer
    assert "Reports 2x" in answer


def test_rejected_summary_is_not_reintroduced_in_fallback():
    data = draft()
    data["claims"].append({**data["claims"][0], "claim_id": "c2", "text": "Accepted topic finding", "section": "topic_analysis"})
    answer = render_claims(data, evidence(), rejected={"c1"})
    assert "Reports 2x" not in answer and "Accepted topic finding" in answer


def test_unstructured_live_claims_still_get_explicit_summary_boundary():
    data = draft()
    del data["claims"][0]["section"]
    assert render_claims(data, evidence()).startswith("### 直接回答")


def test_missing_summary_rework_reaches_writer_with_exact_feedback(tmp_path):
    from test_multi_agent_pipeline_v2 import agents, pipeline
    configured, _ = agents()
    requests = []
    def writer(packet):
        requests.append(packet)
        section = "topic_analysis" if len(requests) == 1 else "direct_conclusion"
        return {"output": {"direct_answer": "answer", "claims": [{"claim_id": "c1", "text": "supported",
            "section": section, "evidence_ids": ["arxiv-1"]}]}}
    configured.writer.handler = writer
    flow, _ = pipeline(tmp_path, configured)
    original = flow.executor.execute
    def execute(*args, **kwargs):
        result = original(*args, **kwargs)
        for item in result["evidence"]:
            item.update(coverage_scope="selected_chunks", locator={"page": 1})
        return result
    flow.executor.execute = execute
    result = flow.run("summary-rework", "owner", "question")
    assert result["run"]["status"] == "completed"
    assert len(requests) == 2 and result["run"]["model_calls_used"] == 7
    feedback = next(i["payload"] for i in requests[-1]["inputs"] if i["payload"].get("schema_version") == "sciassistant.citation-feedback/v1")
    assert feedback["code_issues"] == [{"claim_id": "report_summary", "reason": "MISSING_TOP_LEVEL_CONCLUSION"}]


def test_representative_recalls_do_not_escape_scope_or_override_context_cap(tmp_path):
    store = EvidenceStore(tmp_path / "fts.sqlite3")
    for i in range(4):
        doc = f"doc-{i}"
        chunks = build_chunks(doc, f"2401.0000{i}", "PagedAttention", [{"text": f"PagedAttention experiment variant {i} throughput latency", "page": 1}])
        store.index_document({"document_id": doc, "paper_id": f"2401.0000{i}", "title": "PagedAttention", "content_hash": f"hash-{i}"}, chunks)
    retriever = HybridRetriever(store)
    packets = retriever.search("PagedAttention", limit=2, document_ids={"doc-0", "doc-1", "doc-2"},
                                representative_document_ids=["doc-2", "doc-1", "doc-3"])
    assert packets[0]["document_id"] == "doc-2"
    assert all(p["document_id"] != "doc-3" for p in packets)
    assert len(packets) <= 2
    assert retriever.search("PagedAttention", document_ids={"doc-0"}, context_budget=1,
                            representative_document_ids=["doc-0"]) == []


def test_indexed_candidates_expose_source_tiers_and_reading_trace(tmp_path):
    import time
    tool, _ = executor(tmp_path)
    tool.configure_plan(plan(1))
    result = tool.execute(actions(1), group_ids={"g1"}, deadline=time.monotonic() + 40)
    assert result["evidence"]
    assert all(p["evidence_strength"] == "fulltext_located" for p in result["evidence"])


def test_representative_missing_from_global_top40_is_recalled(tmp_path, monkeypatch):
    store = EvidenceStore(tmp_path / "fts.sqlite3")
    ids = {}
    for doc, text in [("popular", "PagedAttention throughput crowded ranking"),
                      ("original", "PagedAttention original latency evaluation with conditions")]:
        chunks = build_chunks(doc, "2309.06180" if doc == "original" else "2401.00001", "Study", [{"text": text, "page": 4}])
        store.index_document({"document_id": doc, "paper_id": chunks[0]["paper_id"], "title": "Study", "content_hash": doc}, chunks)
        ids[doc] = chunks[0]["chunk_id"]
    def lexical(query, *, limit=40, document_ids=None):
        return [(ids["original"], 0.2)] if document_ids == {"original"} else [(ids["popular"], 1.0)]
    monkeypatch.setattr(store, "lexical_search", lexical)
    packets = HybridRetriever(store).search("PagedAttention", limit=2, document_ids=set(ids), representative_document_ids=["original"])
    assert packets[0]["document_id"] == "original" and len(packets) == 2


def test_scope_tier_survives_cli_and_web_export_without_model_upgrade(tmp_path):
    import json
    from multi_agent_agents import ArtifactDirectory
    from multi_agent_report import export_run_report
    from multi_agent_web import exported_report
    store = ArtifactDirectory(tmp_path / "artifacts")
    packet = {**evidence()["evidence"][0], "review_status": "approved", "paper_id": "2309.06180", "title": "Study"}
    approved = store.put("approved-evidence", {"evidence": [packet]})["artifact_id"]
    final = store.put("final-result", {"status": "partial", "direct_answer": "qualified [1]", "artifact_refs": {"approved": approved}})["artifact_id"]
    (tmp_path / "manifest.json").write_text(json.dumps({"final_artifact_id": final}), encoding="utf-8")
    export_run_report(tmp_path)
    ledger = json.loads((tmp_path / "references.json").read_text(encoding="utf-8"))
    assert ledger[0]["evidence_strength"] == "abstract_only"
    for name in ["final_answer.md", "final_answer.html"]:
        assert "摘要级弱证据" in (tmp_path / name).read_text(encoding="utf-8-sig")
    # Export surface must carry the same warning even though review_status=approved.
    row = {**ledger[0], "official_pdf_url": "", "locator": {}}
    data = {"status": "partial", "direct_answer": "qualified [1]", "references": [row], "claims": [], "coverage": [], "audit": {}}
    for format_name in ["md", "html", "json"]:
        content, _ = exported_report(data, format_name)
        assert "摘要级弱证据" in content.decode("utf-8-sig")
