import json
from contextlib import contextmanager

import pytest

import multi_agent_rag as rag
from external_embedding import ExternalEmbedding, CachedEmbedding, checked_endpoint
from user_credentials import CredentialStore, ProviderCapability, provider_scope, provider_value, child_environment


@pytest.fixture
def external(monkeypatch):
    monkeypatch.setenv('SCIASSISTANT_EMBEDDING_ALLOWED_HOSTS', 'embed.example.org')
    monkeypatch.setenv('SCIASSISTANT_EMBEDDING_URL', 'https://embed.example.org/v1/embeddings')
    monkeypatch.setenv('SCIASSISTANT_EXTERNAL_EMBEDDING_MODEL', 'test-multilingual')
    monkeypatch.setenv('SCIASSISTANT_EXTERNAL_EMBEDDING_DIMENSION', '2')
    monkeypatch.setenv('EMBEDDING_API_KEY', 'dummy-test-key-only')


def transport(monkeypatch, body, *, status=200):
    calls = []
    class Response:
        status_code = status
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def iter_content(self, size): yield json.dumps(body).encode()
    class Session:
        trust_env = True
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def post(self, url, **kwargs):
            assert not self.trust_env
            calls.append((url, kwargs))
            return Response()
    monkeypatch.setattr('requests.Session', Session)
    return calls


def test_external_order_normalize_and_transport_boundary(external, monkeypatch):
    calls = transport(monkeypatch, {'data': [{'index': 1, 'embedding': [0, 2]}, {'index': 0, 'embedding': [3, 0]}]})
    assert ExternalEmbedding().embed(['first', 'second']) == [[1, 0], [0, 1]]
    assert len(calls) == 1
    assert calls[0][1]['allow_redirects'] is False
    assert calls[0][1]['json'] == {'model': 'test-multilingual', 'input': ['first', 'second'], 'encoding_format': 'float'}


@pytest.mark.parametrize('url', ['http://embed.example.org/v1/embeddings', 'https://evil.example.org/x',
    'https://embed.example.org/x?key=secret', 'https://user:password@embed.example.org/x',
    'https://127.0.0.1/x', 'https://localhost/x', 'https://embed.example.org:8443/x',
    'https://embed.example.org/x#frag'])
def test_endpoint_fail_closed(external, url):
    with pytest.raises(rag.RagError): checked_endpoint(url)


@pytest.mark.parametrize('rows', [[], [{'index': 0, 'embedding': [0, 0]}],
    [{'index': 0, 'embedding': [1]}], [{'index': 1, 'embedding': [1, 0]}],
    [{'index': 0, 'embedding': [True, 0]}], [{'index': 0, 'embedding': [float('nan'), 0]}],
    [{'index': 0, 'embedding': ['secret', 0]}]])
def test_bad_response_not_cached_or_accepted(external, monkeypatch, rows):
    transport(monkeypatch, {'data': rows})
    with pytest.raises(rag.RagError): ExternalEmbedding().embed(['paper'])


@pytest.mark.parametrize('status', [302, 401, 402, 429, 500])
def test_http_failure_no_retry_or_local_vector_mix(external, monkeypatch, status):
    calls = transport(monkeypatch, {'provider-secret': 'never surface this'}, status=status)
    with pytest.raises(rag.RagError, match='^EMBEDDING_') as exc:
        ExternalEmbedding().embed(['text'])
    assert 'provider-secret' not in str(exc.value)
    assert len(calls) == 1


def test_tenant_key_no_server_fallback(external):
    with provider_scope(ProviderCapability('8', {})):
        with pytest.raises(rag.RagError, match='EMBEDDING_CONFIG_INVALID'): ExternalEmbedding()
        assert child_environment({})['EMBEDDING_API_KEY'] == ''
    with provider_scope(ProviderCapability('7', {'EMBEDDING_API_KEY': 'owner-seven-key'})):
        assert provider_value('EMBEDDING_API_KEY') == 'owner-seven-key'
        assert child_environment({})['EMBEDDING_API_KEY'] == 'owner-seven-key'


def test_encrypted_account_key_independent_update_and_clear(tmp_path):
    store = CredentialStore(tmp_path / 'keys.sqlite3', 'dummy-encryption-secret-long-enough')
    store.update('7', {'embedding_key': 'dummy-owner-seven'})
    store.update('8', {'embedding_key': 'dummy-owner-eight'})
    assert store.capability('7').values['EMBEDDING_API_KEY'] == 'dummy-owner-seven'
    assert store.status(store.capability('7'))['embedding']['configured']
    assert b'dummy-owner-seven' not in store.path.read_bytes()
    store.update('7', {'clear': ['embedding']})
    assert not store.status(store.capability('7'))['embedding']['configured']
    assert store.capability('8').values['EMBEDDING_API_KEY'] == 'dummy-owner-eight'


class Local:
    model_name, revision, dimension = 'local-test', 'r1', 2
    def __init__(self, *args): self.calls = []
    def embed(self, texts):
        self.calls.append(list(texts))
        return [[1., 0.] for _ in texts]
    def embed_query(self, query): return [0., 1.]


def test_cache_dedup_restart_revision_and_query_semantics(tmp_path):
    path = tmp_path / 'cache.sqlite3'
    local = Local()
    cached = CachedEmbedding(local, path)
    assert cached.embed(['a', 'a', 'b']) == [[1, 0]] * 3
    assert local.calls == [['a', 'b']]
    assert CachedEmbedding(Local(), path).embed(['a', 'b']) == [[1, 0]] * 2
    assert cached.embed_query('a') == [0, 1]
    newer = Local()
    newer.revision = 'r2'
    CachedEmbedding(newer, path).embed(['a'])
    assert newer.calls == [['a']]


def test_private_requires_separate_consent_public_can_use_external(external, monkeypatch, tmp_path):
    monkeypatch.setattr(rag, 'LocalSentenceTransformerEmbedding', Local)
    monkeypatch.setenv('SCIASSISTANT_EMBEDDING_PROVIDER', 'external')
    store = rag.EvidenceStore(tmp_path / 'evidence.sqlite3')
    assert not rag.configured_embedding(store, private_document=True).external
    assert rag.configured_embedding(store, private_document=True, cloud_consent=True).external
    assert rag.configured_embedding(store).external
    with pytest.raises(rag.RagError): rag.configured_embedding(store, private_document=True, cloud_consent='yes')


def test_external_index_namespace_distinct(external, monkeypatch, tmp_path):
    monkeypatch.setenv('SCIASSISTANT_EMBEDDING_PROVIDER', 'external')
    captured = []
    monkeypatch.setattr(rag, 'QdrantVectorStore', lambda **kw: captured.append(kw) or object())
    store = rag.EvidenceStore(tmp_path / 'evidence.sqlite3')
    first = rag.configured_vector_services(store)
    monkeypatch.setenv('SCIASSISTANT_EXTERNAL_EMBEDDING_MODEL', 'another-model')
    rag.configured_vector_services(store)
    assert captured[0]['collection'] != captured[1]['collection']
    assert '_ext_' in captured[0]['collection']
    assert first.embedding.external


def test_index_timings_and_whole_document_cache(tmp_path):
    class Vectors:
        def upsert(self, chunks, vectors): pass
        def delete_document(self, key): pass
    store = rag.EvidenceStore(tmp_path / 'evidence.sqlite3')
    embed = CachedEmbedding(Local(), tmp_path / 'cache.sqlite3')
    indexer = rag.RagIndexer(store, embed, Vectors(), vector_required=True)
    metadata = {'document_id': 'doc', 'paper_id': 'paper', 'title': 'title', 'content_hash': 'h1'}
    blocks = [{'text': 'A scientific passage about latency.', 'page': 1}]
    first = indexer.index(metadata, blocks)
    assert set(first['phase_timings_ms']) == {'chunk_ms', 'embedding_ms', 'vector_write_ms', 'evidence_write_ms'}
    assert first['embedding_cache']['misses'] == 1
    again = indexer.index(metadata, blocks)
    assert not again['changed'] and again['embedding_cache'] == {'hits': 0, 'misses': 0}
    changed = indexer.index({**metadata, 'content_hash': 'h2'}, blocks)
    assert changed['changed'] and changed['embedding_cache']['hits'] == 1


def test_cache_corruption_recomputes(tmp_path):
    import sqlite3
    local = Local()
    cache = CachedEmbedding(local, tmp_path / 'cache.sqlite3')
    cache.embed(['a'])
    with sqlite3.connect(cache.path) as con:
        con.execute("UPDATE embedding_cache SET vector='[0, 0]'")
    assert cache.embed(['a']) == [[1, 0]]
    assert len(local.calls) == 2


def test_delete_evicts_cached_vectors_across_revisions(tmp_path):
    import sqlite3
    from tests.test_multi_agent_rag import FakeVectorStore, metadata, blocks
    store = rag.EvidenceStore(tmp_path / 'evidence.sqlite3')
    cache = CachedEmbedding(Local(), tmp_path / 'cache.sqlite3')
    indexer = rag.RagIndexer(store, cache, FakeVectorStore(), vector_required=True)
    indexer.index(metadata(), blocks())
    indexer.delete_document('doc-1')
    with sqlite3.connect(cache.path) as con:
        assert con.execute('SELECT count(*) FROM embedding_cache').fetchone()[0] == 0


def test_private_executor_llama_consent_is_not_embedding_consent(external, monkeypatch, tmp_path):
    import multi_agent_local_pdf as local
    monkeypatch.setenv('SCIASSISTANT_EMBEDDING_PROVIDER', 'external')
    monkeypatch.setattr(rag, 'LocalSentenceTransformerEmbedding', Local)
    monkeypatch.setattr(local, 'QdrantVectorStore', lambda **kwargs: object())
    pdf = tmp_path / 'paper.pdf'
    pdf.write_bytes(b'%PDF-1.7\n%%EOF')
    first = local.LocalPdfRagExecutor(tmp_path / 'one', pdf, pdf_parse_mode='llama_full', llama_cloud_consent=True)
    assert not first.services.embedding.external
    assert first.source_context['embedding_cloud_consent'] is False
    second = local.LocalPdfRagExecutor(tmp_path / 'two', pdf, embedding_cloud_consent=True)
    assert second.services.embedding.external


def test_embedding_bad_index_type_rejected(external, monkeypatch):
    transport(monkeypatch, {'data': [{'index': False, 'embedding': [1, 0]}]})
    with pytest.raises(rag.RagError): ExternalEmbedding().embed(['text'])
