from __future__ import annotations

import json
import time

import pytest

from multi_agent_agents import (
    AGENT_RESULT_SCHEMA,
    AgentContractError,
    AgentWorker,
    ArtifactDirectory,
    make_agent_input,
    make_rework_ticket,
    validate_agent_input,
    validate_agent_result,
)


def test_artifacts_are_content_addressed_and_agents_only_receive_ids(tmp_path):
    artifacts = ArtifactDirectory(tmp_path / "artifacts")
    first = artifacts.put("question", {"question": "Compare A and B"})
    second = artifacts.put("question", {"question": "Compare A and B"})
    assert first == second
    assert artifacts.get(first["artifact_id"])["question"] == "Compare A and B"


def test_agent_worker_receives_structured_artifacts_and_emits_result(tmp_path):
    artifacts = ArtifactDirectory(tmp_path / "artifacts")
    question = artifacts.put("question", {"question": "Find evidence"})
    observed = {}

    def handler(packet):
        observed.update(packet)
        return {"status": "completed", "output": {"groups": [{"id": "g1"}]},
                "tool_requests": [], "rework_ticket": None, "error_code": None}

    worker = AgentWorker("planner", handler, ["create_research_plan"])
    result = worker.run(make_agent_input(
        run_id="run-1", role="planner", goal="Create plan",
        input_artifact_ids=[question["artifact_id"]], remaining_model_calls=10,
        deadline_at=time.time() + 60,
    ), artifacts)
    assert result["schema_version"] == AGENT_RESULT_SCHEMA
    assert result["status"] == "completed"
    assert result["usage"]["model_calls"] == 1
    assert observed["inputs"][0]["payload"]["question"] == "Find evidence"
    assert len(result["output_artifact_ids"]) == 1


def test_retriever_can_request_arxiv_but_planner_cannot(tmp_path):
    artifacts = ArtifactDirectory(tmp_path / "artifacts")

    def request(_packet):
        return {"status": "completed", "output": {"actions": []}, "tool_requests": [{
            "request_id": "request-1", "action": "request_arxiv_search", "arguments": {"query": "test"},
        }], "rework_ticket": None, "error_code": None}

    retriever = AgentWorker("retriever", request, ["request_arxiv_search"])
    result = retriever.run(make_agent_input(
        run_id="run-1", role="retriever", goal="Propose search",
        input_artifact_ids=[], remaining_model_calls=9, deadline_at=time.time() + 60,
    ), artifacts)
    assert result["tool_requests"][0]["action"] == "request_arxiv_search"
    with pytest.raises(AgentContractError):
        AgentWorker("planner", request, ["request_arxiv_search"])


def test_only_one_deterministic_json_repair_is_allowed(tmp_path):
    artifacts = ArtifactDirectory(tmp_path / "artifacts")
    valid = AgentWorker("planner", lambda _packet: """```json
        {"status":"completed","output":{"groups":[]},"tool_requests":[],"rework_ticket":null,"error_code":null}
        ```""", ["create_research_plan"])
    result = valid.run(make_agent_input(
        run_id="run-1", role="planner", goal="Plan", input_artifact_ids=[],
        remaining_model_calls=10, deadline_at=time.time() + 60,
    ), artifacts)
    assert result["status"] == "completed"
    invalid = AgentWorker("planner", lambda _packet: "prefix {not-json}", ["create_research_plan"])
    with pytest.raises(AgentContractError):
        invalid.run(make_agent_input(
            run_id="run-2", role="planner", goal="Plan", input_artifact_ids=[],
            remaining_model_calls=10, deadline_at=time.time() + 60,
        ), artifacts)


def test_agent_deadline_blocks_without_model_call(tmp_path):
    artifacts = ArtifactDirectory(tmp_path / "artifacts")
    worker = AgentWorker("writer", lambda _packet: pytest.fail("must not run"), ["write_approved_claims"])
    result = worker.run(make_agent_input(
        run_id="run-1", role="writer", goal="Write", input_artifact_ids=[],
        remaining_model_calls=2, deadline_at=time.time() - 1,
    ), artifacts)
    assert result["status"] == "blocked"
    assert result["usage"]["model_calls"] == 0


def test_rework_ticket_is_structured_and_single_round():
    ticket = make_rework_ticket(
        run_id="run-1", from_role="citation_auditor", to_role="writer",
        reason_code="UNSUPPORTED_CLAIM", artifact_ids=["draft-1"],
        required_changes=["Remove unsupported percentage"],
    )
    result = validate_agent_result({
        "schema_version": AGENT_RESULT_SCHEMA, "status": "rework_required",
        "output_artifact_ids": [], "tool_requests": [], "rework_ticket": ticket,
        "usage": {"model_calls": 1, "elapsed_ms": 5}, "error_code": None,
    }, role="citation_auditor", run_id="run-1")
    assert result["rework_ticket"]["round"] == 1
    broken = dict(ticket, round=2)
    with pytest.raises(AgentContractError):
        validate_agent_result({
            "schema_version": AGENT_RESULT_SCHEMA, "status": "rework_required",
            "output_artifact_ids": [], "tool_requests": [], "rework_ticket": broken,
            "usage": {"model_calls": 1, "elapsed_ms": 5}, "error_code": None,
        }, role="citation_auditor", run_id="run-1")


def test_sensitive_fields_are_rejected_from_agent_packets():
    packet = make_agent_input(
        run_id="run-1", role="planner", goal="Plan", input_artifact_ids=[],
        remaining_model_calls=10, deadline_at=time.time() + 60,
    )
    packet["api_token"] = "secret"
    with pytest.raises(AgentContractError):
        validate_agent_input(packet)
