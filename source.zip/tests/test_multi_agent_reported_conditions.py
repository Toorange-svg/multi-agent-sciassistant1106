"""Source context is literal data; it never supplies automatic approval."""
from copy import deepcopy
import pytest

from multi_agent_quality import (reported_condition_records, source_boundary_brief,
    citation_audit_input, REPORTED_CONDITIONS_POLICY)
from multi_agent_agents import ArtifactDirectory
from multi_agent_live import ROLE_PROMPTS, ROLE_PROMPT_SUFFIXES, PROMPT_VERSION, ROLE_OUTPUT_LIMITS
from test_multi_agent_report_fields import draft, evidence


def sources(text, **changes):
    data = evidence()
    data["evidence"][0].update(excerpt=text, text=text, paper_id="p1", **changes)
    return data


@pytest.mark.parametrize("text,aspect", [
    ("Paged Optimizers use unified memory to handle memory spikes.", "paging_mechanism"),
    ("For 65B models on 48GB GPUs with a batch size of 16, we find the same training speed.", "paging_observation"),
    ("Rank r val loss BLEU NIST\n16 1.16 70.33", "printed_columns"),
    ("For LLaMA 7B finetuning on Alpaca, all linear layers are required.", "tested_sensitivity")])
def test_records_keep_exact_paragraph_offsets_and_never_extract_a_verdict(text, aspect):
    data = sources("Introduction.\n\n" + text + "\n\nUnrelated text.")
    before = deepcopy(data)
    rows = reported_condition_records(data)
    row = next(r for r in rows if r["aspect"] == aspect)
    value = data["evidence"][0][row["field"]]
    assert row["quote"] == value[row["start"]:row["end"]]
    assert text in row["quote"]
    assert not row["is_scientific_verdict"]
    assert not row["context_window_truncated"]
    assert "approved" not in row and "decision" not in row
    assert data == before


@pytest.mark.parametrize("status", ["pending", "rejected", None])
def test_unapproved_context_never_enters_inputs(status):
    assert reported_condition_records(sources("Paged Optimizers use unified memory.", review_status=status)) == []


def test_rank_layout_break_keeps_actual_model_and_following_rank_observation():
    text = ("For 65B we observe same training speed.\n\n"
            "For LLaMA 7B on Alpaca we find all linear transformer block layers required.\n\n"
            "projection dimension r does not affect performance (see Appendix A).\n\nAnother experiment.")
    rows = reported_condition_records(sources(text))
    row = next(r for r in rows if r["aspect"] == "tested_sensitivity")
    assert "LLaMA 7B on Alpaca" in row["quote"] and "projection dimension r" in row["quote"]
    assert "Another experiment." not in row["quote"]
    assert row["quote"] == text[row["start"]:row["end"]]


def test_input_budget_marks_truncation_not_complete_source():
    data = sources("A " * 900 + "Paged Optimizers use unified memory. " + "B " * 900)
    row = reported_condition_records(data)[0]
    assert len(row["quote"]) <= 1100 and row["context_window_truncated"]
    assert "Paged Optimizers" in row["quote"]


def test_no_context_stitching_from_unapproved_next_chunk():
    data = sources("Table 18: Caption text and")
    data["evidence"].append({"evidence_id": "other", "paper_id": "p1", "review_status": "pending",
                             "excerpt": "Rank r val loss BLEU NIST and missing caption tail"})
    brief = source_boundary_brief(data)
    assert brief["reported_condition_records"] == []
    assert brief["observed_excerpt_shapes"][0]["ends_with_connector"]


def test_cap_and_aspect_fairness_preserve_headers_among_many_paging_sources():
    data = {"evidence": [{"evidence_id": f"e{i}", "review_status": "approved", "paper_id": "p1",
        "excerpt": "Paged Optimizers use unified memory to mitigate memory spikes."} for i in range(20)]}
    data["evidence"].append({"evidence_id": "header", "review_status": "approved", "excerpt": "Rank r val loss BLEU NIST"})
    records = reported_condition_records(data)
    assert len(records) == 8
    assert any(r["evidence_id"] == "header" for r in records)
    assert len({(r["evidence_id"], r["aspect"]) for r in records}) == len(records)


def test_secondary_text_used_when_excerpt_has_no_matching_data():
    data = sources("Ordinary paragraph.")
    data["evidence"][0]["text"] = "Paged Optimizers handle memory spikes."
    row = reported_condition_records(data)[0]
    assert row["field"] == "text"


def test_same_paper_uncited_counter_context_not_promoted_to_citation():
    data, claim = sources("Paged Optimizers manage memory spikes."), draft()
    original_id = data["evidence"][0]["evidence_id"]
    data["evidence"].append({"evidence_id": "uncited", "paper_id": "p1", "review_status": "approved",
        "excerpt": "For 65B on 48GB with batch 16, we find same training speed.", "locator": {"page": 6}})
    data["evidence"].append({"evidence_id": "different_paper", "paper_id": "p2", "review_status": "approved",
        "excerpt": "Paged Optimizers in unrelated research."})
    claim["claims"][0]["evidence_ids"] = [original_id]
    before = deepcopy((data, claim))
    result = citation_audit_input(claim, data)["claims"][0]
    records = result["reported_condition_records"]
    assert result["reported_conditions_policy"] == REPORTED_CONDITIONS_POLICY
    assert any(r["evidence_id"] == original_id and r["cited_by_this_claim"] for r in records)
    assert any(r["evidence_id"] == "uncited" and not r["cited_by_this_claim"] for r in records)
    assert not any(r["evidence_id"] == "different_paper" for r in records)
    assert result["evidence_ids"] == [original_id] and (data, claim) == before


def test_structured_conditions_can_be_persisted_without_sensitive_field_names(tmp_path):
    brief = source_boundary_brief(sources("Rank r val loss BLEU NIST"))
    store = ArtifactDirectory(tmp_path)
    ref = store.put("source-boundary-brief", brief)
    assert store.get(ref["artifact_id"])["reported_condition_records"] == brief["reported_condition_records"]


def test_prompts_keep_observations_and_absence_of_measurement_distinct():
    assert PROMPT_VERSION.endswith("/v107")
    assert "Never convert missing measurements into no effect" in ROLE_PROMPT_SUFFIXES["writer"]
    assert "same-speed observation" in ROLE_PROMPTS["citation_auditor"]
    assert "There is no target claim count or report length" in ROLE_PROMPT_SUFFIXES["writer"]
    assert ROLE_OUTPUT_LIMITS["writer"] == ROLE_OUTPUT_LIMITS["reviewer"] == ROLE_OUTPUT_LIMITS["citation_auditor"] == 8192
