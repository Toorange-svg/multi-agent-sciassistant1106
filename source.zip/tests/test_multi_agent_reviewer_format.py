"""A Reviewer format repair is one real budgeted call, never an approval."""
import copy
import json
import time

import pytest

from multi_agent_pipeline_v2 import PipelineExecutionError
from multi_agent_live import LiveModelClient
from test_multi_agent_live import Response, config
from test_multi_agent_pipeline_v2 import agents, pipeline


@pytest.mark.parametrize("error", ["MODEL_JSON_INVALID", "MODEL_SCHEMA_REJECTED"])
def test_first_review_repairs_once_with_identical_evidence_and_checklist(tmp_path, error):
    configured, _ = agents()
    original = configured.reviewer.handler
    packets = []
    def reviewer(packet):
        packets.append(copy.deepcopy(packet))
        return {"status": "failed", "error_code": error} if len(packets) == 1 else original(packet)
    configured.reviewer.handler = reviewer
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("review-repair", "owner", "question")
    assert result["run"]["status"] == "completed"
    assert result["run"]["model_calls_used"] == 6
    assert len(packets) == 2 and packets[0]["inputs"] == packets[1]["inputs"]
    assert packets[1]["remaining_model_calls"] == packets[0]["remaining_model_calls"] - 1
    events = [json.loads(line) for line in (tmp_path / "events.jsonl").read_text(encoding="utf-8").splitlines()]
    retry = [row for row in events if row["event"] == "agent_format_retry" and row["role"] == "reviewer"]
    assert len(retry) == 1 and retry[0]["reason_code"] == error
    assert [p.name for p in sorted((tmp_path / "agents").glob("*-reviewer.json"))] == ["03-reviewer.json", "04-reviewer.json"]


@pytest.mark.parametrize("error", ["MODEL_HTTP_429", "MODEL_SERVICE_UNAVAILABLE", "MODEL_OUTPUT_TRUNCATED",
                                  "AGENT_CONTRACT_REJECTED", "AGENT_DEADLINE_EXCEEDED"])
def test_nonformat_review_failure_does_not_retry(tmp_path, error):
    configured, _ = agents()
    configured.reviewer.handler = lambda _: {"status": "failed", "error_code": error}
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("review-stop", "owner", "question")
    assert result["run"]["failure_code"] == error
    assert result["run"]["model_calls_used"] == 3
    assert not flow.reviewer_format_retry_used


@pytest.mark.parametrize("reserve", ["time", "calls", "used"])
def test_repair_preserves_writing_reserves_and_is_per_run(tmp_path, reserve):
    configured, _ = agents()
    configured.reviewer.handler = lambda _: {"status": "failed", "error_code": "MODEL_JSON_INVALID"}
    flow, store = pipeline(tmp_path, configured)
    store.create_run("review-reserve", "owner")
    store.transition("review-reserve", "planned")
    store.transition("review-reserve", "retrieving")
    store.transition("review-reserve", "reviewing")
    flow.deadline = time.monotonic() + (130 if reserve == "time" else 360)
    if reserve == "calls":
        for _ in range(7):
            store.reserve_model_call("review-reserve", "planner")
    flow.reviewer_format_retry_used = reserve == "used"
    evidence_id = flow.artifacts.put("evidence-set", {"schema_version": "sciassistant.evidence-set/v1", "evidence": []})["artifact_id"]
    before = store.get_run("review-reserve")["model_calls_used"]
    with pytest.raises(PipelineExecutionError, match="MODEL_JSON_INVALID"):
        flow._invoke("review-reserve", "reviewer", "review", [evidence_id])
    assert store.get_run("review-reserve")["model_calls_used"] == before + 1


def test_retry_does_not_turn_unknown_evidence_into_an_approval(tmp_path):
    configured, _ = agents()
    count = []
    def bad(packet):
        count.append(packet)
        if len(count) == 1:
            return {"status": "failed", "error_code": "MODEL_JSON_INVALID"}
        return {"output": {"coverage_status": "sufficient", "allowed_evidence_ids": ["invented"],
                           "coverage": [], "decisions": [], "conflicts": []}}
    configured.reviewer.handler = bad
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("review-unapproved", "owner", "question")
    assert result["run"]["status"] == "failed"
    assert not list((tmp_path / "agents").glob("*-writer.json"))


def test_actual_model_adapter_json_error_gets_one_budgeted_repair(tmp_path, monkeypatch):
    monkeypatch.setenv("MODEL_REQUEST_URL", "https://example.test/v1/chat/completions")
    configured, _ = agents()
    original = configured.reviewer.handler
    packets, responses = [], []
    class InvalidJSON(Response):
        def iter_content(self, **kwargs):
            yield json.dumps({"choices": [{"finish_reason": "stop", "message": {
                "content": '{"output":{"detail":"bad "quote""}}'}}]}).encode()
    def post(_url, **kwargs):
        packet = json.loads(kwargs["json"]["messages"][1]["content"])
        packets.append(packet)
        valid = original(packet)
        valid["output"]["decisions"] = [{"evidence_id": evidence_id, "decision": "approved", "reason_code": "SUPPORTED",
                                        "detail": "The supplied test passage supports this test topic.",
                                        "group_ids": ["g1"], "task_relevance": "direct_task_evidence"}
                                       for evidence_id in valid["output"]["allowed_evidence_ids"]]
        response = InvalidJSON(None) if len(packets) == 1 else Response(valid)
        responses.append(response)
        return response
    client = LiveModelClient(config(), post=post)
    configured.reviewer.handler = lambda packet: client.call("reviewer", packet)
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("review-adapter", "owner", "question")
    assert result["run"]["status"] == "completed"
    assert result["run"]["model_calls_used"] == 6
    assert len(packets) == 2 and packets[0]["inputs"] == packets[1]["inputs"]
    assert all(response.closed for response in responses)
    assert not any('bad "quote"' in file.read_text(encoding="utf-8")
                   for file in (tmp_path / "artifacts").glob("*.json"))
