"""Tests for compound-question decomposition and per-sub-question grouping.

The two questions in the task description are used verbatim as fixtures, since
they are the cases the feature exists to handle.
"""
import unittest

from deepdiver_v2.src.subquestions import decompose, merge_grouped_results

HALLUCINATION_QUESTION = (
    "大模型的幻觉问题，是因为训练数据有偏，还是因为解码策略有问题？"
    "如果是前者，有哪些数据去偏方法？如果是后者，有哪些解码改进？"
)

MOE_QUESTION = (
    "什么是混合专家模型？它和稠密模型有什么区别？"
    "在什么场景下 MoE 更有优势？有哪些开源的 MoE 实现？"
)


class DecompositionTests(unittest.TestCase):
    def test_single_question_stays_one_part(self):
        parts = decompose("What are the key challenges of RAG?")
        self.assertEqual(len(parts), 1)
        self.assertEqual(parts[0].kind, "main")
        self.assertEqual(parts[0].index, 1)

    def test_four_progressive_subquestions_are_separated(self):
        parts = decompose(MOE_QUESTION)
        self.assertEqual(len(parts), 4)
        self.assertEqual([item.index for item in parts], [1, 2, 3, 4])
        self.assertIn("什么是混合专家模型", parts[0].text)
        self.assertIn("稠密模型", parts[1].text)
        self.assertIn("更有优势", parts[2].text)
        self.assertIn("开源", parts[3].text)

    def test_conditional_branches_become_separate_parts(self):
        parts = decompose(HALLUCINATION_QUESTION)
        # The two alternatives plus the two conditional branches.
        conditions = [item.condition for item in parts if item.kind == "conditional"]
        self.assertEqual(len(conditions), 2)
        self.assertTrue(any("前者" in item for item in conditions))
        self.assertTrue(any("后者" in item for item in conditions))
        # The antecedent is recorded, not discarded.
        branch = next(item for item in parts if item.kind == "conditional")
        self.assertIn("仅在该条件成立时适用", branch.note)

    def test_numbered_list_is_split(self):
        parts = decompose("1. What is RAG? 2. How does retrieval work? 3. What is reranking?")
        self.assertEqual(len(parts), 3)
        self.assertTrue(all("What" in item.text or "How" in item.text for item in parts))

    def test_chinese_numbered_list_is_split(self):
        parts = decompose("请回答三点：1、检索器做什么 2、生成器做什么 3、如何评估")
        self.assertGreaterEqual(len(parts), 3)

    def test_semicolons_separate_requests(self):
        parts = decompose("检索器负责召回；生成器负责组织答案")
        self.assertEqual(len(parts), 2)

    def test_comma_alone_does_not_split(self):
        parts = decompose("大模型的幻觉问题，是因为训练数据有偏吗")
        self.assertEqual(len(parts), 1)

    def test_empty_query_yields_nothing(self):
        self.assertEqual(decompose(""), [])

    def test_short_fragments_are_dropped(self):
        parts = decompose("什么是 RAG？为什么？")
        self.assertEqual(len(parts), 1)
        self.assertIn("RAG", parts[0].text)

    def test_all_parts_carry_usable_text(self):
        for query in (HALLUCINATION_QUESTION, MOE_QUESTION):
            for item in decompose(query):
                self.assertGreaterEqual(len(item.text.strip()), 4, query)

    def test_referential_branch_is_flagged(self):
        parts = decompose(HALLUCINATION_QUESTION)
        referential = [item for item in parts if item.referential]
        self.assertTrue(referential, "a branch pointing back at an alternative should be flagged")


class GroupingTests(unittest.TestCase):
    def test_each_subquestion_keeps_its_own_evidence(self):
        parts = decompose(MOE_QUESTION)
        results = [
            {"papers": [{"paper_id": "1"}, {"paper_id": "2"}]},
            {"papers": [{"paper_id": "3"}]},
            {"papers": []},
            {"papers": [{"paper_id": "4"}]},
        ]
        grouped = merge_grouped_results(parts, per_subquestion=results)
        self.assertEqual(len(grouped["groups"]), 4)
        self.assertEqual(grouped["groups"][0]["paper_count"], 2)
        self.assertEqual(grouped["groups"][2]["status"],
                         "insufficient_evidence_for_subquestion")

    def test_one_unanswered_part_does_not_discard_the_others(self):
        parts = decompose(MOE_QUESTION)
        results = [{"papers": [{"paper_id": "1"}]}, {"papers": []},
                   {"papers": [{"paper_id": "2"}]}, {"papers": [{"paper_id": "3"}]}]
        grouped = merge_grouped_results(parts, per_subquestion=results)
        self.assertEqual(grouped["unanswered_subquestions"], [2])
        self.assertEqual(grouped["status"], "insufficient_evidence_for_subquestion")
        surviving = sum(group["paper_count"] for group in grouped["groups"])
        self.assertEqual(surviving, 3)

    def test_all_parts_answered_reports_sufficient(self):
        parts = decompose(MOE_QUESTION)
        results = [{"papers": [{"paper_id": "1"}]} for _ in parts]
        grouped = merge_grouped_results(parts, per_subquestion=results)
        self.assertEqual(grouped["status"], "sufficient")
        self.assertEqual(grouped["unanswered_subquestions"], [])

    def test_threshold_is_respected(self):
        parts = decompose(MOE_QUESTION)
        results = [{"papers": [{"paper_id": "1"}]} for _ in parts]
        grouped = merge_grouped_results(parts, per_subquestion=results, minimum=2)
        self.assertEqual(grouped["status"], "insufficient_evidence_for_subquestion")


if __name__ == "__main__":
    unittest.main()
