"""Two official attempts share 30s; time slicing never bypasses source policy."""
import time
import json

import pytest
import requests

from multi_agent_live import LiveArxivRagExecutor
from deepdiver_v2.src.literature_sources import SourceDeadlineExceeded


PDF = b'%PDF-1.4\nfixture\n%%EOF'


def tool(deadline=60):
    executor = object.__new__(LiveArxivRagExecutor)
    executor.retrieval_deadline = time.monotonic() + deadline
    return executor


@pytest.mark.parametrize('failure', ['timeout', 'unreachable', 'drip', 'incomplete', 'http500'])
def test_first_failure_leaves_official_backup_an_attempt_inside_total_budget(tmp_path, monkeypatch, failure):
    clock = [100.0]
    monkeypatch.setattr('multi_agent_live.time.monotonic', lambda:clock[0])
    executor = tool()
    attempts, responses = [], []
    class Response:
        closed = False
        def __init__(self, first): self.first = first
        def iter_content(self, **_kwargs):
            if self.first and failure == 'drip':
                clock[0] = attempts[0][1]['deadline_monotonic'] + 0.01
            yield b'not a pdf' if self.first and failure == 'incomplete' else PDF
        def close(self): self.closed = True
    def request(_source, url, **kwargs):
        attempts.append((url,kwargs))
        if len(attempts) == 1 and failure in {'timeout','unreachable','http500'}:
            clock[0] += 12
            if failure == 'timeout': raise requests.Timeout('secret-canary')
            if failure == 'unreachable': raise requests.ConnectionError('secret-canary')
            response=requests.Response(); response.status_code=500; response.close=lambda:None
            raise requests.HTTPError('secret-canary',response=response)
        response=Response(len(attempts)==1); responses.append(response)
        return response
    monkeypatch.setattr('deepdiver_v2.src.literature_sources._request', request)
    assert executor._download_http('2005.12872v3',tmp_path).read_bytes() == PDF
    assert len(attempts)==2 and [u.split('/')[2] for u,_ in attempts]==['arxiv.org','export.arxiv.org']
    assert attempts[0][1]['deadline_monotonic']==115
    assert attempts[1][1]['deadline_monotonic']==130
    assert all(k['max_attempts']==1 and k['timeout']<=6 for _,k in attempts)
    assert all(r.closed for r in responses) and not (tmp_path/'source.part').exists()
    assert executor.pdf_download_attempts[-1]['status']=='completed'
    assert 'secret-canary' not in str(executor.pdf_download_attempts)


@pytest.mark.parametrize('status', [302,401,403,404,429])
def test_redirect_permission_and_rate_limit_never_fall_back(tmp_path, monkeypatch, status):
    executor=tool(); seen=[]
    response=requests.Response();response.status_code=status;response.close=lambda:None
    def request(*_args,**_kwargs):
        seen.append(1);raise requests.HTTPError('private-canary',response=response)
    monkeypatch.setattr('deepdiver_v2.src.literature_sources._request',request)
    with pytest.raises(requests.HTTPError): executor._download_http('2005.12872v3',tmp_path)
    assert len(seen)==1 and not (tmp_path/'source.pdf').exists()


def test_source_wait_deadline_is_not_host_network_failure(tmp_path, monkeypatch):
    executor=tool();seen=[]
    def request(*_args,**_kwargs):
        seen.append(1);raise SourceDeadlineExceeded('private-canary')
    monkeypatch.setattr('deepdiver_v2.src.literature_sources._request',request)
    with pytest.raises(SourceDeadlineExceeded): executor._download_http('2005.12872v3',tmp_path)
    assert len(seen)==1 and executor.pdf_download_attempts[0]['status']=='source_wait'


def test_expired_global_budget_does_not_launch_backup_or_publish_partial(tmp_path,monkeypatch):
    executor=tool();seen=[]
    clock=[100.0];executor.retrieval_deadline=130
    monkeypatch.setattr('multi_agent_live.time.monotonic',lambda:clock[0])
    def request(*_args,**_kwargs):
        seen.append(1);clock[0]=131;raise requests.Timeout('private-canary')
    monkeypatch.setattr('deepdiver_v2.src.literature_sources._request',request)
    with pytest.raises(TimeoutError): executor._download_http('2005.12872v3',tmp_path)
    assert len(seen)==1 and not (tmp_path/'source.pdf').exists()


@pytest.mark.parametrize('bad', [False, True])
def test_parent_records_only_valid_worker_attempt_metadata(tmp_path,monkeypatch,bad):
    executor=tool();executor.observations=[]
    (tmp_path/'source.pdf').write_bytes(PDF)
    attempt={'host':'private-malicious-host' if bad else 'arxiv.org', 'status':'completed',
        'elapsed_ms':40,'budget_seconds':15}
    class Process:
        returncode=0
        pid=123
        def communicate(self,**_kwargs):
            return json.dumps({'status':'completed','attempts':[attempt]}),None
    monkeypatch.setattr('subprocess.Popen',lambda *_a,**_k:Process())
    if bad:
        from multi_agent_rag import RagError
        with pytest.raises(RagError,match='PDF_DOWNLOAD_WORKER_FAILED'):
            executor._download('2005.12872v3',tmp_path)
        assert executor.observations==[]
    else:
        assert executor._download('2005.12872v3',tmp_path).read_bytes()==PDF
        assert executor.observations[0]['source_status']=='pdf_download_attempt'
        assert executor.observations[0]['host']=='arxiv.org'
