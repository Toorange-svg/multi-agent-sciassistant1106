"""Audited answer layering; offline substitutes do not certify live quality."""
import json
from pathlib import Path
import shutil
import subprocess

import pytest

from multi_agent_agents import AgentContractError, ArtifactDirectory
from multi_agent_live import normalize_live_result, ROLE_PROMPTS
from multi_agent_pipeline_v2 import check_draft, render_claims
from multi_agent_quality import AUDIT_SCHEMA, DRAFT_SCHEMA
from multi_agent_report import export_run_report
import multi_agent_web as web


def draft():
    return {"schema_version": DRAFT_SCHEMA, "direct_answer": "Not used as an unaudited summary", "claims": [{
        "claim_id": "c1", "text": "该论文自报相同延迟下吞吐量提高2×，并非延迟降低。",
        "scope_note": "只适用于该实验配置，不能直接跨硬件比较。",
        "qualification": "实验详情_CANARY：batch size 64，使用单篇论文所选片段；硬件未在片段中报告。",
        "section": "direct_conclusion", "claim_type": "quantitative", "confidence": "medium",
        "evidence_ids": ["e1"]}]}


def evidence():
    return {"evidence": [{"evidence_id": "e1", "paper_id": "2309.06180", "title": "PagedAttention",
        "review_status": "approved", "coverage_scope": "selected_chunks", "excerpt": "2x throughput at the same latency",
        "locator": {"page": 6, "section": "Evaluation"}}]}


def audit(data, *, rejected=()):
    return {"schema_version": AUDIT_SCHEMA, "status": "needs_review" if rejected else "passed",
        "rejected_claim_ids": list(rejected), "issues": [
            {"claim_id": key, "reason_code": "UNSUPPORTED_NUMBER"} for key in rejected],
        "claim_results": [{"claim_id": c["claim_id"], "decision": "rejected" if c["claim_id"] in rejected else "approved",
            "reason_code": "UNSUPPORTED_NUMBER" if c["claim_id"] in rejected else "SUPPORTED",
            "detail": "Checked visible text and scope against excerpt", "evidence_ids": c["evidence_ids"]}
            for c in data["claims"]]}


def test_v2_body_has_visible_scope_citations_but_no_detailed_note():
    data = draft()
    text = render_claims(data, evidence())
    assert "直接回答" in text and "只适用于该实验配置" in text and "[1]" in text
    assert "CANARY" not in text and "限定条件" not in text
    assert "unaudited summary" not in text
    assert check_draft(data, evidence(), require_summary=True) == []


@pytest.mark.parametrize("schema", [None, "sciassistant.claim-draft/v1"])
def test_legacy_qualification_is_never_hidden(schema):
    data = draft()
    if schema:
        data["schema_version"] = schema
    else:
        data.pop("schema_version")
    assert data["claims"][0]["qualification"] in render_claims(data, evidence())


@pytest.mark.parametrize("value", [None, 123, [], "x" * 601])
def test_v2_missing_or_invalid_scope_fails_validation(value):
    data = draft()
    data["claims"][0]["scope_note"] = value
    with pytest.raises(AgentContractError):
        normalize_live_result("writer", {"output": data})
    assert any(r["reason"] == "INVALID_CLAIM_SCOPE" for r in check_draft(data, evidence()))


def test_empty_explicit_scope_is_allowed_without_guessing_a_hedge():
    data = draft()
    data["claims"][0]["scope_note"] = ""
    result = normalize_live_result("writer", {"output": data})
    assert result["output"]["claims"][0]["scope_note"] == ""


def test_long_review_details_are_rejected_not_silently_truncated():
    data = draft()
    data["claims"][0]["qualification"] = "x" * 4001
    with pytest.raises(AgentContractError):
        normalize_live_result("writer", {"output": data})
    assert check_draft(data, evidence())


def test_scope_numbers_are_checked_against_evidence():
    data = draft()
    data["claims"][0]["scope_note"] += "延迟降低37%。"
    assert any(r["reason"] == "UNSUPPORTED_NUMBER" for r in check_draft(data, evidence()))


def test_scope_cannot_inject_another_citation_marker():
    data = draft()
    data["claims"][0]["scope_note"] += "[99]"
    assert "[99]" not in render_claims(data, evidence())


def test_weak_evidence_remains_visibly_downgraded():
    data = evidence()
    data["evidence"][0].update(coverage_scope="abstract", locator={})
    text = render_claims(draft(), data)
    assert "低置信度" in text and "全文实验结论" in text
    assert any(r["reason"] == "WEAK_EVIDENCE_CONFIDENCE" for r in check_draft(draft(), data))


def test_auditor_explicitly_checks_visible_scope_not_hidden_qualification():
    prompt = ROLE_PROMPTS["citation_auditor"]
    assert "text + scope_note" in prompt and "ONLY in qualification" in prompt


def test_writer_avoids_generic_disclaimers_without_hiding_essential_scope():
    prompt = ROLE_PROMPTS["writer"]
    assert "Default scope_note to an empty string" in prompt
    assert "do not append generic caveats" in prompt
    assert "ONLY when it changes an actual asserted finding" in prompt
    assert "addresses an explicitly requested unresolved point" in prompt
    assert "Do not move those generic caveats into qualification either" in prompt
    assert "Combine shared genuine coverage gaps" in prompt
    assert "Omit unrelated superiority claims" in prompt
    assert "Do not hide a condition that changes the meaning of a number" in prompt


def seed_run(tmp_path, monkeypatch, data=None, decision=None):
    task = "abcdef012345"
    monkeypatch.setenv("SCIASSISTANT_MULTI_AGENT_WEB_RUN_ROOT", str(tmp_path))
    monkeypatch.setattr(web, "progress", lambda _task: {"model_calls": 5})
    directory = tmp_path / task
    artifacts = ArtifactDirectory(directory / "artifacts")
    data = data or draft()
    refs = {"approved": artifacts.put("approved-evidence", evidence())["artifact_id"],
        "draft": artifacts.put("draft-answer", data)["artifact_id"],
        "audit": artifacts.put("citation_auditor-output", decision or audit(data))["artifact_id"]}
    final = artifacts.put("final-result", {"run_id": task, "status": "partial", "artifact_refs": refs,
        "direct_answer": render_claims(data, evidence())})
    (directory / "manifest.json").write_text(json.dumps({"run_id": task, "final_artifact_id": final["artifact_id"]}), encoding="utf8")
    return task, directory


def test_cli_and_web_exports_retain_details_and_identical_claim_map(tmp_path, monkeypatch):
    task, directory = seed_run(tmp_path, monkeypatch)
    export_run_report(directory)
    result = web.report(task)
    mapping = json.loads((directory / "claim_evidence_map.json").read_text("utf8"))
    assert mapping == result["claims"] == draft()["claims"]
    assert result["draft_schema_version"] == DRAFT_SCHEMA
    assert "CANARY" not in result["direct_answer"]
    cli_md = (directory / "final_answer.md").read_text("utf-8-sig")
    cli_html = (directory / "final_answer.html").read_text("utf8")
    for fmt in ("md", "html", "json"):
        data, _ = web.exported_report(result, fmt)
        text = data.decode("utf-8-sig")
        assert "CANARY" in text and "只适用于该实验配置" in text
    assert "CANARY" in cli_md and "CANARY" in cli_html
    assert '<details><summary>对应结论与审查记录</summary>' in cli_html
    assert 'href="#evidence-1"' in cli_html
    current_html = web.exported_report(result, "html")[0].decode()
    assert '<details id="claims"><summary>' not in current_html
    assert '适用范围与实验条件（完整记录）' in current_html
    assert current_html.count('实验详情_CANARY') == 1


def test_details_escape_html_in_both_exports(tmp_path, monkeypatch):
    data = draft()
    data["claims"][0]["qualification"] = '<script>CANARY</script>'
    task, directory = seed_run(tmp_path, monkeypatch, data)
    export_run_report(directory)
    for text in ((directory / "final_answer.html").read_text("utf8"), web.exported_report(web.report(task), "html")[0].decode()):
        assert '<script>CANARY' not in text and '&lt;script&gt;CANARY' in text


def test_web_and_cli_share_dependency_rejections(tmp_path, monkeypatch):
    data = draft()
    dependent = {**data["claims"][0], "claim_id": "c2", "depends_on_claim_ids": ["c1"]}
    independent = {**data["claims"][0], "claim_id": "c3"}
    data["claims"] += [dependent, independent]
    task, directory = seed_run(tmp_path, monkeypatch, data, audit(data, rejected=("c1",)))
    export_run_report(directory)
    mapping = json.loads((directory / "claim_evidence_map.json").read_text("utf8"))
    assert mapping == web.report(task)["claims"]
    assert [c["claim_id"] for c in mapping] == ["c3"]


def test_ambiguous_audit_never_publishes_review_details_as_approved(tmp_path, monkeypatch):
    decision = audit(draft())
    decision["claim_results"] = []
    task, directory = seed_run(tmp_path, monkeypatch, decision=decision)
    export_run_report(directory)
    result = web.report(task)
    assert result["claims"] == [] and result["audit_has_unresolved_issues"]
    assert "通过" not in result["status_display"]["audit_label"]
    assert json.loads((directory / "claim_evidence_map.json").read_text("utf8")) == []


def test_frontend_review_details_collapsed_and_not_duplicated():
    node = shutil.which("node")
    if not node:
        pytest.skip("Node required for DOM substitute, not browser acceptance")
    source = (Path(__file__).resolve().parents[1] / "chatAi/multi_agent_rag.js").read_text("utf8")
    harness = r'''
const vm=require('node:vm'),nodes=[];
function el(tag){const x={tagName:tag.toUpperCase(),children:[],events:{},dataset:{},classList:{toggle(){}},
 append(...xs){this.children.push(...xs)},addEventListener(k,f){this.events[k]=f},showModal(){},scrollIntoView(){},focus(){}};nodes.push(x);return x;}
const listeners={}; const window={userToken:'fixture',currentSessionId:null,location:{search:'?rag_task=abcdef012345'},addEventListener(k,f){listeners[k]=f}};
const document={createElement:el,body:el('body'),createTreeWalker:()=>({nextNode:()=>false})};
const context={window,document,NodeFilter:{SHOW_TEXT:4},URLSearchParams,AbortController,setInterval:()=>0,
fetch:async()=>({ok:true,json:async()=>({status:'partial',direct_answer:'Visible scoped finding [1]',claims:[{text:'Finding',scope_note:'Scope',qualification:'CANARY',evidence_ids:['e1']}],references:[{evidence_id:'e1',citation:1,title:'Paper',locator:{},excerpt:'Excerpt'}]})})};
vm.runInNewContext(SOURCE,context);
(async()=>{listeners.DOMContentLoaded();for(let i=0;i<6;i++)await new Promise(r=>setImmediate(r));
const detail=nodes.find(n=>n.tagName==='DETAILS'&&n.children[0]?.textContent==='适用范围与实验条件（完整记录）');
console.log(JSON.stringify({tag:detail.tagName,open:!!detail.open,standalone:nodes.some(n=>n.className==='rag-claims'),notes:nodes.filter(n=>/CANARY/.test(n.textContent||'')).map(n=>n.textContent)}));})();
'''
    result = subprocess.run([node, "-"], input="const SOURCE=" + json.dumps(source) + ";\n" + harness,
        encoding="utf8", text=True, capture_output=True, timeout=10)
    assert result.returncode == 0, result.stderr
    data = json.loads(result.stdout)
    assert data["tag"] == "DETAILS" and not data["open"] and not data['standalone']
    assert len(data["notes"]) == 1 and "实验条件与证据边界" in data["notes"][0]


def test_review_feedback_identifies_exact_contradiction_without_auto_approval():
    from multi_agent_quality import review_repair_feedback
    review = {"allowed_evidence_ids": [], "decisions": [{"evidence_id": "target", "decision": "approved"}],
        "coverage": [{"evidence_ids": ["target"]}]}
    feedback = review_repair_feedback(review, "REVIEW_COVERAGE_UNAPPROVED_EVIDENCE")
    assert feedback["inconsistencies"]["approved_decisions_not_allowed"] == ["target"]
    assert feedback["inconsistencies"]["coverage_ids_not_allowed"] == ["target"]
    assert review["allowed_evidence_ids"] == []
    assert "Partial coverage is allowed" in feedback["required_action"]


@pytest.mark.parametrize("bad", [None, 1, "not a list", {}])
def test_feedback_accepts_invalid_fields_only_as_diagnostics(bad):
    from multi_agent_quality import review_repair_feedback
    feedback = review_repair_feedback({"allowed_evidence_ids": bad, "coverage": bad, "decisions": bad}, "INVALID")
    assert not any(feedback["inconsistencies"].values())


def test_first_review_correction_receives_specific_ids_and_can_reach_writer(tmp_path):
    from test_multi_agent_pipeline_v2 import agents, pipeline
    from multi_agent_pipeline_v2 import check_review, ReviewContractError
    configured, calls = agents(partial=True)
    original = configured.reviewer.handler
    reviews = []
    def reviewer(packet):
        output = original(packet)["output"]
        output.update(schema_version="sciassistant.evidence-review/v3", decisions=[{
            "evidence_id": "arxiv-1", "decision": "approved", "reason_code": "SUPPORTED",
            "detail": "The excerpt supports a bounded preliminary finding", "group_ids": ["g1"]}],
            coverage=[{"group_id": "g1", "status": "partial", "evidence_ids": ["arxiv-1"]}])
        if not reviews:
            output["allowed_evidence_ids"] = []
        else:
            feedback = next(item["payload"] for item in packet["inputs"] if item["payload"].get("inconsistencies"))
            assert feedback["inconsistencies"]["coverage_ids_not_allowed"] == ["arxiv-1"]
            assert feedback["inconsistencies"]["approved_decisions_not_allowed"] == ["arxiv-1"]
        reviews.append(output)
        return {"output": output}
    configured.reviewer.handler = reviewer
    flow, _ = pipeline(tmp_path, configured)
    # Allow one 40-second protocol correction but reserve the final 90 seconds;
    # this test targets review recovery, not an additional search round.
    flow.time_budget_seconds = 140
    result = flow.run("review-specific", "owner", "Define A")
    assert result["run"]["status"] == "partial"
    assert result["run"]["model_calls_used"] == 6
    assert calls.count("reviewer") == 2 and "writer" in calls and "citation_auditor" in calls
    with pytest.raises(ReviewContractError, match="REVIEW_COVERAGE_UNAPPROVED_EVIDENCE"):
        check_review(reviews[0], {"evidence": [{"evidence_id": "arxiv-1"}]}, {"g1"})
