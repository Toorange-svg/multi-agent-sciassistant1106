"""Column resizing DOM substitutes; real pointer/layout proof is separate."""
import json
from pathlib import Path
import shutil
import subprocess

import pytest

ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.parametrize('scenario', ['default', 'keyboard', 'drag', 'cancel', 'capture_lost',
    'foreign_pointer', 'narrow_restore', 'parent_resize', 'dispose', 'storage_blocked',
    'saved', 'bad_low', 'bad_high', 'bad_text'])
def test_splitter_controls_limits_persistence_and_cleanup(scenario):
    node = shutil.which('node')
    if not node:
        pytest.skip('Node required')
    source = (ROOT / 'chatAi/multi_agent_rag.js').read_text(encoding='utf8')
    code = source[source.index('    const COLUMN_RATIO_KEY'):source.index('    const currentState')]
    harness = r'''
const vm=require('node:vm'),attrs={},styles={},events={},listeners={},writes=[];
let width=1024,capture=null,observer,disconnected=false,prevented=0,focus=0;
const classes=new Set(),body=new Set(),toggle=(s,k,v)=>v?s.add(k):s.delete(k);
const handle={tabIndex:0,setAttribute(k,v){attrs[k]=v;},addEventListener(k,f){events[k]=f;},
 setPointerCapture(id){capture=id;},hasPointerCapture(id){return capture===id;},
 releasePointerCapture(){capture=null;},focus(){focus++;}};
const workspace={getBoundingClientRect(){return {width};},
 classList:{toggle(k,v){toggle(classes,k,v);}},style:{setProperty(k,v){styles[k]=v;}}};
const storage={getItem(){if(SCENARIO==='storage_blocked')throw Error('blocked');
 return ({saved:'70',bad_low:'-2',bad_high:'100',bad_text:'not-a-number'})[SCENARIO]??null;},
 setItem(k,v){if(SCENARIO==='storage_blocked')throw Error('blocked');writes.push([k,v]);}};
const window={innerWidth:1366,localStorage:storage,addEventListener(k,f){listeners[k]=f;},removeEventListener(k,f){if(listeners[k]===f)delete listeners[k];}};
const context={window,document:{body:{classList:{toggle(k,v){toggle(body,k,v);}}}},
 ResizeObserver:class{constructor(f){observer=f;}observe(){}disconnect(){disconnected=true;}}};
vm.runInNewContext(CODE+'\nthis.binding=bindColumnResize;',context);
const control=context.binding(workspace,handle);
const fire=(name,extra={})=>events[name]?.({pointerId:1,button:0,clientX:500,preventDefault(){prevented++;},...extra});
const key=(k,shiftKey=false)=>fire('keydown',{key:k,shiftKey});
const percent=()=>Number.parseFloat(styles['--rag-source-share']);
const initial=percent();let checkpoints={};
if(SCENARIO==='keyboard'){
 key('ArrowRight');checkpoints.right=percent();key('ArrowLeft',true);checkpoints.shift=percent();
 key('Home');checkpoints.home=percent();key('End');checkpoints.end=percent();fire('dblclick');checkpoints.reset=percent();
}
if(['drag','cancel','capture_lost','foreign_pointer','dispose','storage_blocked'].includes(SCENARIO)){
 fire('pointerdown');fire('pointermove',{clientX:650});checkpoints.moved=percent();checkpoints.writesDuringDrag=writes.length;
 if(SCENARIO==='cancel')fire('pointercancel');
 else if(SCENARIO==='capture_lost'){capture=null;fire('lostpointercapture');}
 else if(SCENARIO==='foreign_pointer'){fire('pointermove',{pointerId:2,clientX:900});checkpoints.foreign=percent();fire('pointerup');}
 else if(SCENARIO==='dispose')control.dispose();
 else {fire('pointermove',{clientX:-1000});checkpoints.left=percent();fire('pointermove',{clientX:3000});checkpoints.right=percent();fire('pointerup');}
}
if(['narrow_restore','parent_resize'].includes(SCENARIO)){
 key('ArrowRight',true);key('ArrowRight',true);checkpoints.preferred=percent();
 width=600;observer();checkpoints.clamped=percent();checkpoints.min=attrs['aria-valuemin'];
 if(SCENARIO==='narrow_restore'){width=400;window.innerWidth=462;listeners.resize();checkpoints.stacked=classes.has('rag-workspace-stacked');checkpoints.tab=handle.tabIndex;key('End');}
 width=1024;window.innerWidth=1366;listeners.resize();checkpoints.restored=percent();
}
console.log(JSON.stringify({initial,percent:percent(),attrs,styles,writes,checkpoints,focus,capture,disconnected,
 dragging:body.has('rag-columns-resizing'),resizeListener:!!listeners.resize}));
'''
    result = subprocess.run([node, '-'], input='const CODE='+json.dumps(code)+';const SCENARIO='+json.dumps(scenario)+';\n'+harness,
                            capture_output=True, text=True, encoding='utf8', timeout=10)
    assert result.returncode == 0, result.stderr
    data = json.loads(result.stdout)
    assert data['attrs']['role'] == 'separator'
    assert data['attrs']['aria-orientation'] == 'vertical'
    assert data['initial'] == (70 if scenario == 'saved' else 35)
    if scenario == 'keyboard':
        assert data['checkpoints'] == {'right': 37, 'shift': 27, 'home': 25, 'end': 75, 'reset': 50}
    if scenario in {'drag', 'storage_blocked'}:
        assert data['checkpoints'] == {'moved': 50, 'writesDuringDrag': 0, 'left': 25, 'right': 75}
        assert not data['dragging'] and data['capture'] is None
        assert data['writes'] == ([] if scenario == 'storage_blocked' else [['sciassistant.rag-columns/v1', '75']])
    if scenario in {'cancel', 'capture_lost', 'dispose'}:
        assert data['percent'] == 35 and not data['dragging'] and data['capture'] is None
        assert not data['writes']
    if scenario == 'foreign_pointer':
        assert data['checkpoints']['foreign'] == 50 and data['percent'] == 50
    if scenario in {'narrow_restore', 'parent_resize'}:
        assert data['checkpoints']['clamped'] == 55 and data['checkpoints']['min'] == '39'
        assert data['checkpoints']['restored'] == 55
        assert data['writes'][-1][1] == '55'
    if scenario == 'narrow_restore':
        assert data['checkpoints']['stacked'] and data['checkpoints']['tab'] == -1
    if scenario == 'dispose':
        assert data['disconnected'] and not data['resizeListener']
