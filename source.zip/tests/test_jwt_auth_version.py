"""JWT login generations revoke all older credentials after password reset."""

from unittest import mock

import jwt
import pymysql

import app as gateway


def _headers(version=0, *, include_version=True):
    claims = {"user_id": 7, "username": "person"}
    if include_version:
        claims["auth_version"] = version
    token = jwt.encode(claims, gateway.app.config["SECRET_KEY"], algorithm="HS256")
    return {"Authorization": f"Bearer {token}"}


def test_generated_token_carries_integer_auth_version():
    token = gateway.generate_token(7, "person", 4)
    claims = jwt.decode(token, gateway.app.config["SECRET_KEY"], algorithms=["HS256"])
    assert claims["auth_version"] == 4


def test_matching_auth_version_reaches_protected_route():
    with mock.patch.object(gateway, "_current_auth_version", return_value=3), \
         mock.patch.object(gateway, "_proxy_request", return_value=("forwarded", 204)):
        response = gateway.app.test_client().get("/8000/api/concurrency", headers=_headers(3))
    assert response.status_code == 410  # authenticated, then retired tenant-unsafe legacy route


def test_password_reset_generation_rejects_old_token_before_route_runs():
    with mock.patch.object(gateway, "_current_auth_version", return_value=2), \
         mock.patch.object(gateway, "_proxy_request") as proxy:
        response = gateway.app.test_client().get("/8000/api/concurrency", headers=_headers(1))
    assert response.status_code == 401
    assert response.get_json()["error"] == "登录凭证已失效，请重新登录"
    proxy.assert_not_called()


def test_legacy_token_is_version_zero_until_first_reset():
    with mock.patch.object(gateway, "_current_auth_version", return_value=0), \
         mock.patch.object(gateway, "_proxy_request", return_value=("forwarded", 204)):
        accepted = gateway.app.test_client().get(
            "/8000/api/concurrency", headers=_headers(include_version=False))
    with mock.patch.object(gateway, "_current_auth_version", return_value=1), \
         mock.patch.object(gateway, "_proxy_request") as proxy:
        revoked = gateway.app.test_client().get(
            "/8000/api/concurrency", headers=_headers(include_version=False))
    assert accepted.status_code == 410  # auth passed, independently retired service
    assert revoked.status_code == 401
    proxy.assert_not_called()


def test_invalid_auth_version_claim_is_rejected_without_database_access():
    token = jwt.encode(
        {"user_id": 7, "username": "person", "auth_version": "not-an-integer"},
        gateway.app.config["SECRET_KEY"], algorithm="HS256")
    with mock.patch.object(gateway, "_current_auth_version") as lookup:
        response = gateway.app.test_client().get(
            "/8000/api/concurrency", headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 401
    lookup.assert_not_called()


def test_auth_version_database_failure_is_safe_503_and_never_forwards():
    with mock.patch.object(
        gateway, "_current_auth_version", side_effect=pymysql.MySQLError("private-host-canary")
    ), mock.patch.object(gateway, "_proxy_request") as proxy:
        response = gateway.app.test_client().get("/8000/api/concurrency", headers=_headers())
    assert response.status_code == 503
    assert response.get_json()["error"] == "认证服务暂时不可用，请稍后重试"
    assert "private-host-canary" not in response.get_data(as_text=True)
    proxy.assert_not_called()


def test_missing_user_revokes_token_without_forwarding():
    with mock.patch.object(gateway, "_current_auth_version", return_value=None), \
         mock.patch.object(gateway, "_proxy_request") as proxy:
        response = gateway.app.test_client().get("/8000/api/concurrency", headers=_headers())
    assert response.status_code == 401
    proxy.assert_not_called()
