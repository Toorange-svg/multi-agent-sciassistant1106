"""Literal multi-question contracts; fixtures never stand in for model semantics."""
from copy import deepcopy
import hashlib
import json
import subprocess
import sys

import pytest

from multi_agent_report_contracts import (REPORT_PLAN_SCHEMA, requirement_plan_issues,
    compile_user_requirements, question_inventory, report_budget, default_time_policy,
    PROFILE_SOFT_POLICY, align_requirement_segments)
from multi_agent_agents import make_agent_input, AgentContractError
from multi_agent_handoffs import plan_handoff_issues, compile_search_plan
from multi_agent_quality import scope_plan_to_question, answer_requirements
from multi_agent_workflow import WorkflowStore, WorkflowError, WorkflowBudgetExceeded
from tools.full_report_foundation import build_cases, read_json, SPEC

CASES = build_cases(read_json(SPEC))


def plan_for_case(case):
    question = case['question']
    rows, reports = [], []
    for i, requirement in enumerate(case['requirements'], 1):
        rid = f'o{i}'
        reports.append({'id':rid, 'kind':'report', 'question_quote':requirement['question_quote'],
            'question':requirement['question_quote']})
        rows.append({'id':f'u{i}', 'question_quote':requirement['question_quote'],
            'answer_kind':requirement['answer_kind'], 'research_group_ids':['g1'], 'report_obligation_ids':[rid]})
    dispositions = {}
    for segment in question_inventory(question)['segments']:
        refs = [row['id'] for row in rows if question.index(row['question_quote']) < segment['end']
                and question.index(row['question_quote']) + len(row['question_quote']) > segment['start']]
        dispositions[segment['segment_id']] = refs or 'background'
    return {'schema_version':REPORT_PLAN_SCHEMA, 'groups':[{'id':'g1','kind':'research',
        'question_quote':question[:200], 'question':'Scientific context', 'core':['Research'], 'support':[],
        'queries':['original scientific evidence'], 'metrics':['definition'],
        'evidence_needs':[{'entity':'Research','question_quote':question[:200],'aspect':'definition','source_title':''}]}],
        'report_obligations':reports, 'premise_checks':[], 'user_requirements':rows,
        'segment_dispositions':dispositions}


@pytest.mark.parametrize('case', CASES, ids=lambda c:c['case_id'])
def test_all_six_to_eight_gold_requests_survive_and_order_is_literal(case):
    plan = plan_for_case(case)
    before = deepcopy(plan)
    assert not plan_handoff_issues(plan, case['question'])
    ledger = compile_user_requirements(case['question'], plan)
    assert len(ledger['requirements']) == len(case['requirements']) > 4
    assert [r['question_quote'] for r in ledger['requirements']] == [r['question_quote'] for r in case['requirements']]
    for row in ledger['requirements']:
        assert case['question'][row['start']:row['end']] == row['question_quote']
    assert plan == before
    reordered = deepcopy(plan)
    reordered['user_requirements'].reverse()
    assert compile_user_requirements(case['question'], reordered)['requirements'] == ledger['requirements']
    compiled, diagnostics = compile_search_plan(plan, 'arxiv')
    assert len(compiled['groups']) == 1 and len(compiled['groups'][0]['queries']) <= 2
    assert len(compiled['report_obligations']) == len(case['requirements'])
    assert not ledger['semantic_auto_approval'] and not ledger['publication_coverage_verified']


@pytest.mark.parametrize('fault', ['missing_tail_segment','unknown_segment','foreign_quote','unknown_group',
    'bad_kind','duplicate_requirement','no_delivery','unknown_requirement','unrelated_segment','missing_rows'])
def test_invalid_planner_dispositions_not_silently_dropped(fault):
    case = next(c for c in CASES if c['case_id']=='wrong_premise-long_end')
    plan = plan_for_case(case)
    tail = list(plan['segment_dispositions'])[-1]
    if fault == 'missing_tail_segment':
        del plan['segment_dispositions'][tail]
    elif fault == 'unknown_segment':
        plan['segment_dispositions']['s999']='background'
    elif fault == 'foreign_quote':
        plan['user_requirements'][-1]['question_quote']='not in user question'
    elif fault == 'unknown_group':
        plan['user_requirements'][-1]['research_group_ids']=['invented']
    elif fault == 'bad_kind':
        plan['user_requirements'][0]['answer_kind']='already_verified'
    elif fault == 'duplicate_requirement':
        plan['user_requirements'].append(deepcopy(plan['user_requirements'][0]))
    elif fault == 'no_delivery':
        plan['user_requirements'][0].update(research_group_ids=[],report_obligation_ids=[])
    elif fault == 'unknown_requirement':
        plan['segment_dispositions'][tail]=['u999']
    elif fault == 'unrelated_segment':
        plan['segment_dispositions']['s1']=['u7']
    elif fault == 'missing_rows':
        plan['user_requirements']=[]
    assert requirement_plan_issues(plan, case['question'])
    with pytest.raises(ValueError, match='REJECTED'):
        compile_user_requirements(case['question'], plan)


def test_explicit_background_classification_is_not_a_semantic_pass():
    case = next(c for c in CASES if c['case_id']=='methods_comparison-long_end')
    plan = plan_for_case(case)
    dropped = plan['user_requirements'].pop()
    for key,value in plan['segment_dispositions'].items():
        if isinstance(value, list) and dropped['id'] in value:
            plan['segment_dispositions'][key]='background'
    assert not requirement_plan_issues(plan, case['question'])
    ledger = compile_user_requirements(case['question'], plan)
    assert len(ledger['requirements']) < len(case['requirements'])
    assert not ledger['semantic_auto_approval']
    assert not ledger['publication_coverage_verified']
    # Human/gold check must still fail; shape alone cannot prove comprehension.
    assert case['requirements'][-1]['question_quote'] not in {r['question_quote'] for r in ledger['requirements']}


def test_legacy_plan_remains_explicitly_unclassified_not_reinterpreted():
    ledger = compile_user_requirements('原始问题？末尾要求。', {'schema_version':'sciassistant.research-plan/v4','groups':[]})
    assert ledger['classification_status']=='legacy_unclassified'
    assert ledger['requirements']==[] and all(s['disposition']=='unclassified' for s in ledger['segments'])


def test_moved_report_group_rebinds_requirement_without_new_search():
    question='请解释方法。请给出实验建议。'
    case={'question':question,'requirements':[
        {'question_quote':'请解释方法。','answer_kind':'definition'},
        {'question_quote':'请给出实验建议。','answer_kind':'proposal'}]}
    plan=plan_for_case(case)
    report={'id':'g2','kind':'report','question_quote':'请给出实验建议。','question':'Experiment',
        'queries':[],'core':[],'support':[],'metrics':[],'evidence_needs':[]}
    plan['groups'].append(report)
    plan['user_requirements'][1].update(research_group_ids=['g2'],report_obligation_ids=[])
    effective,_=scope_plan_to_question(plan, answer_requirements(question))
    ledger=compile_user_requirements(question,effective)
    assert ledger['requirements'][1]['research_group_ids']==[]
    assert 'g2' in ledger['requirements'][1]['report_obligation_ids']
    assert len(effective['groups'])==1


@pytest.mark.parametrize('profile,calls,cutoff,target,reserve', [('standard',10,300,360,2),('enhanced',20,600,720,7)])
def test_profiles_are_explicit_and_durable(tmp_path,profile,calls,cutoff,target,reserve):
    config=report_budget(profile)
    assert (config['model_call_limit'], config['research_start_cutoff_seconds'],config['duration_target_seconds'],config['reserved_delivery_calls'])==(calls,cutoff,target,reserve)
    store=WorkflowStore(tmp_path/'workflow.sqlite3')
    state=store.create_run('run','owner',report_profile=profile,time_policy=default_time_policy(profile))
    assert state['max_model_calls']==calls and state['remaining_model_calls']==calls
    assert state['report_profile']==profile
    for _ in range(calls):
        permit=store.reserve_model_call('run','writer')
    assert permit.remaining_calls==0
    with pytest.raises(WorkflowBudgetExceeded):
        store.reserve_model_call('run','writer')
    assert WorkflowStore(tmp_path/'workflow.sqlite3').get_run('run')['model_calls_used']==calls


@pytest.mark.parametrize('kwargs', [{'profile':'automatic'},{'profile':{}},{'profile':False},
    {'time_budget':720},{'time_budget':True},{'time_budget':360.5},{'model_calls':20},
    {'profile':'enhanced','model_calls':21},{'profile':'enhanced','time_budget':721}])
def test_budget_never_infers_or_increases_profile(kwargs):
    with pytest.raises(ValueError):
        report_budget(**kwargs)


def test_old_store_read_does_not_add_profile_table_or_change_bytes(tmp_path):
    path=tmp_path/'legacy.sqlite3'
    store=WorkflowStore(path)
    store.create_run('old','owner')
    before=hashlib.sha256(path.read_bytes()).hexdigest()
    assert 'report_profile' not in WorkflowStore(path).get_run('old')
    assert before==hashlib.sha256(path.read_bytes()).hexdigest()
    with pytest.raises(WorkflowError):
        store.create_run('unpermitted','owner',max_model_calls=20)


def test_agent_packet_v2_does_not_increase_legacy_permissions():
    kwargs=dict(run_id='r',role='planner',goal='Plan',input_artifact_ids=[],remaining_model_calls=19,deadline_at=12345)
    with pytest.raises(AgentContractError):
        make_agent_input(**kwargs)
    with pytest.raises(AgentContractError):
        make_agent_input(**kwargs, report_profile='standard')
    value=make_agent_input(**kwargs, report_profile='enhanced')
    assert value['schema_version']=='sciassistant.agent-input/v2'
    assert value['allowed_actions']==['create_research_plan']


def test_inventory_preserves_long_tail_and_rejects_over_limit():
    question='背景'*2400+'。最后必须说明撤回推荐的条件。'
    inventory=question_inventory(question)
    assert inventory['segments'][-1]['text']=='最后必须说明撤回推荐的条件。'
    assert inventory['question_characters']==len(question)
    with pytest.raises(ValueError, match='INPUT_INVALID'):
        question_inventory('问'*20_001)


def test_repeated_literal_asks_use_explicit_occurrence_not_arbitrary_first_match():
    question='请解释机制。请解释机制。'
    case={'question':question,'requirements':[{'question_quote':'请解释机制。','answer_kind':'mechanism'}]}
    plan=plan_for_case(case)
    row=plan['user_requirements'][0]
    row['occurrence']=1
    plan['user_requirements'].append({**deepcopy(row),'id':'u2','occurrence':2})
    plan['segment_dispositions']={'s1':['u1'],'s2':['u2']}
    ledger=compile_user_requirements(question,plan)
    assert len({r['requirement_id'] for r in ledger['requirements']})==2
    assert [r['start'] for r in ledger['requirements']]==[0,6]
    del plan['user_requirements'][1]['occurrence']
    assert requirement_plan_issues(plan, question)


def test_v6_links_are_code_owned_not_a_model_indexing_lottery():
    case=next(c for c in CASES if c['case_id']=='methods_comparison-long_middle')
    plan=plan_for_case(case)
    plan['segment_dispositions']={key:['u1'] for key in plan['segment_dispositions']}
    before=deepcopy(plan)
    aligned=align_requirement_segments(plan,case['question'])
    assert aligned['user_requirements']==plan['user_requirements'] and plan==before
    assert aligned['segment_mapping']['changes']
    assert not requirement_plan_issues(aligned,case['question'])
    ledger=compile_user_requirements(case['question'],aligned)
    assert len(ledger['requirements'])==len(case['requirements'])
    assert ledger['classification_status']=='explicit_partial'
    assert any(s['disposition']=='unclassified' for s in ledger['segments'])
    assert not ledger['semantic_auto_approval']


def test_mapping_does_not_invent_missing_requests_or_fix_foreign_quotes():
    case=CASES[0]
    plan=plan_for_case(case)
    plan['user_requirements'][0]['question_quote']='FOREIGN INVENTED REQUEST'
    result=align_requirement_segments(plan,case['question'])
    assert result['user_requirements'][0]['question_quote']=='FOREIGN INVENTED REQUEST'
    assert requirement_plan_issues(result,case['question'])


def test_old_v5_mapping_and_verdict_are_not_reinterpreted():
    plan=plan_for_case(CASES[0])
    plan['schema_version']='sciassistant.research-plan/v5'
    plan['segment_dispositions']={'s999':['u1']}
    before=deepcopy(plan)
    assert align_requirement_segments(plan,CASES[0]['question'])==before
    assert requirement_plan_issues(plan,CASES[0]['question'])
