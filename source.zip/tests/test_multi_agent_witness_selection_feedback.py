"""Feedback fixes delivery, never rebinds another claim's source choice."""
from copy import deepcopy
import json

import pytest

from multi_agent_quality import (witness_selection_diagnostics, initial_audit_witness_options,
    resolve_witness_choices, SHORT_CHOICE_POLICY, WITNESS_CHOICE_POLICY, AUDIT_QUOTE_MENU_POLICY,
    check_audit, publication_rejections)
from test_multi_agent_report_fields import draft, evidence, QUOTE
from test_multi_agent_absence_basis import audit


def case():
    data, sources = draft(), evidence()
    data.update(short_choice_policy=SHORT_CHOICE_POLICY, witness_choice_policy=WITNESS_CHOICE_POLICY,
                audit_quote_menu_policy=AUDIT_QUOTE_MENU_POLICY)
    data['claims'].append({**deepcopy(data['claims'][0]), 'claim_id': 'c2'})
    menu = initial_audit_witness_options(data, sources)
    return data, sources, audit(data), menu


@pytest.mark.parametrize('field', ['quote_id', 'choice_label'])
@pytest.mark.parametrize('fault', ['unknown', 'other_claim', 'source'])
def test_diagnostic_names_actual_bad_selection_without_fixing_it(field, fault):
    data, sources, value, menu = case()
    item = next(o for o in menu['options'] if o['claim_id'] == ('c2' if fault == 'other_claim' else 'c1'))
    value['claim_results'][0]['source_witnesses'] = [{'evidence_id': 'other' if fault == 'source' else 'e1',
        field: 'invented' if fault == 'unknown' else item[field]}]
    before = deepcopy((data, sources, value, menu))
    issues = witness_selection_diagnostics(value, menu, data)
    assert len(issues) == 1 and issues[0]['reason'] == {
        'unknown': 'WITNESS_OPTION_UNKNOWN', 'other_claim': 'WITNESS_OPTION_OTHER_CLAIM',
        'source': 'WITNESS_OPTION_SOURCE_MISMATCH'}[fault]
    allowed = issues[0]['valid_choices_for_this_claim_and_source']
    assert all(c['choice_label'].startswith('c1-') for c in allowed)
    assert not issues[0]['automatic_rebinding'] and not issues[0]['semantic_auto_approval']
    normalized, receipt = resolve_witness_choices(value, menu, data, sources)
    assert not receipt['resolutions'] and 'c1' in publication_rejections(check_audit(normalized, data, sources), data)
    assert (data, sources, value, menu) == before


def test_literal_and_valid_choice_do_not_create_false_selection_faults():
    data, _, value, menu = case()
    assert witness_selection_diagnostics(value, menu, data) == []
    item = next(o for o in menu['options'] if o['claim_id'] == 'c1')
    value['claim_results'][0]['source_witnesses'] = [{'evidence_id': 'e1', 'choice_label': item['choice_label']}]
    assert witness_selection_diagnostics(value, menu, data) == []


@pytest.mark.parametrize('rows', [None, [None], [{'claim_id': []}], [{'claim_id': 'unknown'}]])
def test_diagnostics_do_not_crash_malformed_audit(rows):
    data, _, value, menu = case()
    value['claim_results'] = rows
    assert witness_selection_diagnostics(value, menu, data) == []


def test_workflow_feedback_contains_exact_cross_claim_error_and_model_must_correct(tmp_path):
    from test_multi_agent_pipeline_v2 import agents, pipeline
    configured, calls = agents()
    data, _, _, _ = case()
    for claim in data['claims']: claim['evidence_ids'] = ['arxiv-1']
    def writer(_):
        calls.append('writer')
        return {'output': data}
    rounds = []
    def auditor(packet):
        calls.append('citation_auditor')
        rounds.append(1)
        supplied = next(i['payload'] for i in packet['inputs']
                        if i['payload'].get('schema_version') == 'sciassistant.citation-audit-input/v1')
        menu = supplied['source_witness_options']['options']
        value = audit(data)
        if len(rounds) == 2:
            report = next(i['payload'] for i in packet['inputs']
                          if i['payload'].get('schema_version') == 'sciassistant.validation-report/v1')
            issue = report['witness_selection_issues'][0]
            assert issue['claim_id'] == 'c1' and issue['reason'] == 'WITNESS_OPTION_OTHER_CLAIM'
            assert all(c['choice_label'].startswith('c1-') for c in issue['valid_choices_for_this_claim_and_source'])
        for row in value['claim_results']:
            target = 'c2' if len(rounds) == 1 and row['claim_id'] == 'c1' else row['claim_id']
            item = next(o for o in menu if o['claim_id'] == target)
            row['source_witnesses'] = [{'evidence_id': item['evidence_id'], 'choice_label': item['choice_label']}]
        return {'output': value}
    configured.writer.handler, configured.citation_auditor.handler = writer, auditor
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {'status': 'ok', 'papers': [
        {'paper_id': '1', 'title': 'Method', 'abstract': QUOTE}]})
    result = flow.run('selection-feedback', 'owner', 'Explain the method')
    assert result['run']['model_calls_used'] == 6 and calls.count('writer') == 1 and calls.count('citation_auditor') == 2
    final = flow.artifacts.get(result['final_artifact_id'])
    checked = flow.artifacts.get(final['artifact_refs']['audit'])
    assert not publication_rejections(checked, flow.artifacts.get(final['artifact_refs']['draft']))
    events = [json.loads(line) for line in (tmp_path / 'events.jsonl').read_text(encoding='utf8').splitlines()]
    assert len([r for r in events if r['event'] == 'audit_witness_selection_invalid']) == 1
