"""API key mutation is restricted to the actual loopback peer."""

from unittest import mock

import web_app


def test_remote_peer_cannot_write_settings_even_with_spoofed_forwarded_header():
    with mock.patch.object(web_app, "_persist_api_key_settings") as persist:
        response = web_app.app.test_client().post(
            "/api/settings/api-keys",
            json={"values": {"MODEL_REQUEST_TOKEN": "never-written"}},
            environ_base={"REMOTE_ADDR": "192.0.2.44"},
            headers={"X-Forwarded-For": "127.0.0.1"},
        )
    assert response.status_code == 403
    assert response.get_json()["error"] == "LOCAL_ACCESS_REQUIRED"
    persist.assert_not_called()


def test_loopback_ipv4_and_ipv6_can_reach_settings_validation():
    for address in ("127.0.0.1", "::1"):
        with mock.patch.object(web_app, "_persist_api_key_settings") as persist:
            response = web_app.app.test_client().post(
                "/api/settings/api-keys", json={"values": {}},
                environ_base={"REMOTE_ADDR": address})
        assert response.status_code == 200
        persist.assert_called_once_with({})


def test_missing_or_invalid_peer_fails_closed():
    for address in ("", "not-an-ip"):
        with mock.patch.object(web_app, "_persist_api_key_settings") as persist:
            response = web_app.app.test_client().post(
                "/api/settings/api-keys", json={"values": {}},
                environ_base={"REMOTE_ADDR": address})
        assert response.status_code == 403
        persist.assert_not_called()
