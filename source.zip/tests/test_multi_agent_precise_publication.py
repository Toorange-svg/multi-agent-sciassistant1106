"""Scoped false positives and independently verified, uncontested audit rows."""
from copy import deepcopy

import pytest

from multi_agent_audit_batches import (AUDIT_BATCH_RECOVERY_POLICY, merge_source_audits,
    source_batches, global_review_input)
from multi_agent_quality import (ABSENCE_SCOPE_POLICY, BARE_PASSAGE_ABSENCE_SCOPE_POLICY,
    METRIC_DIRECTION_POLICY, PREVIOUS_METRIC_DIRECTION_POLICY, check_audit,
    check_metric_direction, publication_rejections)
from test_multi_agent_audit_batches import data, good_audit, seed_flow
from test_multi_agent_absence_basis import audit, absence, draft, evidence
from test_multi_agent_metric_direction import inputs


@pytest.mark.parametrize('modifier', ['整篇', '整个', '整份'])
@pytest.mark.parametrize('field', ['text', 'scope_note', 'qualification'])
def test_visible_disclaimer_does_not_assert_whole_paper_absence(modifier, field):
    value, sources = draft(), evidence()
    text = f'这是对本次所引片段的说明，不代表{modifier}论文未报告这些信息。'
    value['claims'][0][field] = text
    value['absence_scope_policy'] = BARE_PASSAGE_ABSENCE_SCOPE_POLICY
    raw = absence(audit(value), text, field=field)
    before = deepcopy((raw, value, sources))
    assert check_audit(raw, value, sources)['absence_issues']
    value['absence_scope_policy'] = ABSENCE_SCOPE_POLICY
    checked = check_audit(raw, value, sources)
    assert not checked['absence_issues'] and not publication_rejections(checked, value)
    value['absence_scope_policy'] = BARE_PASSAGE_ABSENCE_SCOPE_POLICY
    assert (raw, value, sources) == before


@pytest.mark.parametrize('text', [
    '所选片段未见对照，但整篇论文未报告这些信息。',
    '论文未报告重复实验。', '作者没有提供统计检验。',
    '所选片段没有这些信息。整篇论文未报告对照。',
    '所选片段未见对照，不代表整篇论文未报告，但作者未做检验。'])
def test_disclaimer_cannot_license_an_actual_whole_paper_negative(text):
    value = draft()
    value['absence_scope_policy'] = ABSENCE_SCOPE_POLICY
    value['claims'][0]['qualification'] = text
    checked = check_audit(absence(audit(value), text), value, evidence())
    assert checked['absence_issues']


@pytest.mark.parametrize('field', ['text', 'scope_note', 'qualification'])
def test_printed_maximum_is_not_an_optimality_recommendation(field):
    value, sources = inputs('原文报告实验。')
    value['claims'][0][field] = '验证损失最大打印值为1.23（r=1），不是最优。'
    assert check_metric_direction(value, sources, policy=PREVIOUS_METRIC_DIRECTION_POLICY)
    assert not check_metric_direction(value, sources, policy=METRIC_DIRECTION_POLICY)


@pytest.mark.parametrize('text', ['验证损失最大打印值为1.23，因此是最优。',
    '验证损失最大打印值为1.23，最好选择该行。', '验证损失最高，因此最优。'])
def test_printed_number_does_not_excuse_wrong_optimization(text):
    value, sources = inputs(text)
    assert check_metric_direction(value, sources)


def records_for(value, sources, fault='contradiction'):
    records = []
    for index, part in enumerate(source_batches(value)):
        raw = good_audit(part['draft'])
        if index == 1:
            raw['rejected_claim_ids'] = [part['claim_ids'][0]]
            raw['issues'] = [{'claim_id': part['claim_ids'][0], 'reason_code': 'UNSUPPORTED_NUMBER',
                'detail': 'Free prose says approve; it MUST NOT override explicit rejection.'}]
            raw['status'] = 'needs_review'
            if fault == 'missing': raw['claim_results'].pop()
            elif fault == 'duplicate': raw['claim_results'][-1] = deepcopy(raw['claim_results'][0])
            elif fault == 'foreign': raw['claim_results'][-1]['claim_id'] = 'foreign'
            elif fault == 'unknown_issue': raw['issues'][0]['claim_id'] = 'foreign'
            elif fault == 'bad_witness': raw['claim_results'][1]['source_witnesses'][0]['quote'] = 'This quote is not in the source text.'
            elif fault == 'bad_field': raw['claim_results'][1]['field_results'] = {}
            elif fault == 'wrong_source': raw['claim_results'][1]['evidence_ids'] = ['foreign']
            elif fault == 'truncated': raw = {'contract_errors': ['MODEL_OUTPUT_TRUNCATED']}
            elif fault == 'status_only': raw['rejected_claim_ids'] = []; raw['issues'] = []
        records.append({**part, 'audit': raw})
    return records


def enabled(count=25):
    value, sources, ledger = data(count)
    value['audit_batch_recovery_policy'] = AUDIT_BATCH_RECOVERY_POLICY
    return value, sources, ledger


def test_recovery_preserves_exact_valid_rows_and_records_original_contradiction():
    value, sources, ledger = enabled()
    records = records_for(value, sources)
    before = deepcopy((value, sources, records))
    checked = merge_source_audits(value, sources, records)
    assert not checked['contract_errors']
    assert checked['source_unreviewed_claim_ids'] == ['c13']
    receipt = checked['source_batch_recoveries'][0]
    assert len(receipt['retained_claim_ids']) == 11 and receipt['contested_claim_ids'] == ['c13']
    assert 'AUDIT_REJECTION_SET_INCONSISTENT' in receipt['original_contract_errors']
    assert not receipt['scientific_auto_approval']
    assert checked['claim_results'][13] == records[1]['audit']['claim_results'][1]
    packet = global_review_input(ledger, value, sources, checked)
    assert all('c13' not in r['eligible_claim_ids'] for r in packet['report_review_request']['requirements'])
    assert (value, sources, records) == before


@pytest.mark.parametrize('fault', ['missing', 'duplicate', 'foreign', 'unknown_issue',
    'bad_field', 'wrong_source', 'truncated', 'status_only'])
def test_incomplete_or_structurally_invalid_batch_is_not_recovered(fault):
    value, sources, _ = enabled()
    checked = merge_source_audits(value, sources, records_for(value, sources, fault))
    assert set(checked['source_unreviewed_claim_ids']) == {f'c{i}' for i in range(13,25)}


def test_invalid_literal_is_isolated_even_when_other_rows_are_retained():
    value, sources, _ = enabled()
    checked = merge_source_audits(value, sources, records_for(value, sources, 'bad_witness'))
    assert checked['source_unreviewed_claim_ids'] == ['c13', 'c14']
    assert checked['source_batch_recoveries'][0]['row_failures'][0]['claim_id'] == 'c14'


def test_old_policy_and_dependencies_keep_their_original_safety_boundary():
    value, sources, _ = enabled()
    value['claims'][0]['depends_on_claim_ids'] = ['c13']
    records = records_for(value, sources)
    checked = merge_source_audits(value, sources, records)
    assert publication_rejections(checked, value) == {'c1', 'c13'}
    value.pop('audit_batch_recovery_policy')
    checked = merge_source_audits(value, sources, records)
    assert set(checked['source_unreviewed_claim_ids']) == {f'c{i}' for i in range(13,25)}


def test_formal_workflow_recovers_without_an_extra_model_call(tmp_path):
    def handler(phase, packet, result):
        if phase == 'source' and result['claim_results'][0]['claim_id'] == 'c13':
            result['rejected_claim_ids'] = ['c13']
            result['issues'] = [{'claim_id': 'c13', 'reason_code': 'UNSUPPORTED_NUMBER'}]
            result['status'] = 'needs_review'
        return {'output': result}
    flow, refs, value, sources, _, phases = seed_flow(tmp_path, count=25, handler=handler)
    value['audit_batch_recovery_policy'] = AUDIT_BATCH_RECOVERY_POLICY
    refs['draft'] = flow.artifacts.put('draft', value)['artifact_id']
    _, checked = flow._audit('audit-batches', 'test', [refs['draft'], refs['approved']], value, refs)
    assert publication_rejections(checked, value) == {'c13'}
    assert flow.artifacts.get(refs['audit_batch_recovery'])['records'][0]['contested_claim_ids'] == ['c13']
    assert phases[-1] == ('global', 25)
    assert flow.store.get_run('audit-batches')['model_calls_used'] <= 5
