"""Real multipart + in-process gateway reuse; no provider/network/live state."""
import io
import json
import sqlite3
from pathlib import Path

import pytest
from flask import abort, g
import app as account
import web_app as web
from science_pdf_sessions import PdfSessions


@pytest.fixture
def isolated(tmp_path, monkeypatch):
    state, uploads = tmp_path / "tasks", tmp_path / "uploads"
    state.mkdir(); uploads.mkdir()
    monkeypatch.setenv("SCIASSISTANT_WEB_BASE", "")
    monkeypatch.setattr(account, "SCIENCE_TASK_STATE_DIR", state)
    monkeypatch.setattr(account, "SCIENCE_TASK_OWNER_STATE_PATH", tmp_path / "owners.json")
    monkeypatch.setattr(account, "PDF_SESSION_STATE_PATH", tmp_path / "bindings.sqlite3")
    monkeypatch.setattr(account, "_SCIENCE_TASK_OWNERS", {})
    monkeypatch.setattr(account, "_current_auth_version", lambda _id: 0)
    monkeypatch.setattr(account, "_LOCAL_SCIENCE_APP", web.app)
    monkeypatch.setattr(web, "TASK_STATE_DIR", state)
    monkeypatch.setattr(web, "UPLOAD_DIR", uploads)
    monkeypatch.setattr(web, "TASKS", {})
    monkeypatch.setattr(web, "_missing_task_configuration", lambda mode: [])
    launched = []
    monkeypatch.setattr(web, "_start_background_task", lambda *args, **kwargs: launched.append((args, kwargs)))
    def conversation(cid):
        if (str(g.current_user_id), cid) not in {("alice", "chat-a"), ("alice", "chat-a2"), ("bob", "chat-b")}:
            abort(404)
    monkeypatch.setattr(account, "_require_science_conversation_owner", conversation)
    return tmp_path, launched


def headers(user="alice"):
    return {"Authorization": "Bearer " + account.generate_token(user, user)} if user else {}


def upload(user="alice", conversation="chat-a", filename="paper.pdf"):
    return account.app.test_client().post("/api/science/tasks", headers=headers(user), data={
        "query": "解析这篇论文", "conversation_id": conversation,
        "processing_mode": "pdf_local", "pdf_parse_mode": "local",
        "pdf": (io.BytesIO(b"%PDF-1.4\ncanary\n%%EOF"), filename),
    })


def binding(user="alice", conversation="chat-a", method="get"):
    return getattr(account.app.test_client(), method)(
        f"/api/science/conversations/{conversation}/pdf-attachment", headers=headers(user))


def reuse(source, user="alice", conversation="chat-a", mode="pdf_local", parser="hybrid", **extra):
    return account.app.test_client().post("/api/science/tasks", headers=headers(user), json={
        "query": "换一条解析链路", "conversation_id": conversation, "processing_mode": mode,
        "pdf_parse_mode": parser, "pdf_source_task_id": source, **extra,
    })


def test_multipart_saved_reference_reuses_original_file_and_explicit_parser(isolated, monkeypatch):
    root, launched = isolated
    response = upload()
    assert response.status_code == 202
    first = response.json["task"]
    descriptor = {"source_task_id": first["id"], "filename": "paper.pdf"}
    assert first["pdf_attachment"] == descriptor
    assert binding().json == {"attachment": descriptor}
    original = launched[0][0][3]
    assert original.read_bytes().startswith(b"%PDF")
    # Simulate loss of Web memory after restart; the binding + snapshot survive.
    monkeypatch.setattr(web, "TASKS", {})
    assert binding().json["attachment"] == descriptor
    second = reuse(first["id"])
    assert second.status_code == 202
    assert second.json["task"]["pdf_attachment"] == descriptor
    assert second.json["task"]["pdf_parse_mode"] == "hybrid"
    assert second.json["task"]["id"] != first["id"]
    assert launched[-1][0][3] == original and launched[-1][0][4] == "hybrid"
    assert len(list((root / "uploads").iterdir())) == 1
    assert str(root) not in response.text + binding().text + second.text


def test_account_conversation_anonymous_and_spoofed_owner_boundary(isolated):
    source = upload().json["task"]["id"]
    assert binding(None).status_code == 401
    assert binding("bob", "chat-a").status_code == 404
    assert binding("bob", "chat-b").json["attachment"] is None
    assert reuse(source, "bob", "chat-b", user_id="alice").status_code == 404
    assert reuse(source, conversation="chat-a2").status_code == 404
    assert reuse("../secret").status_code == 404
    assert reuse(source, mode="multi_agent_rag").status_code == 400
    assert reuse(source, conversation="").status_code == 400
    assert binding().json["attachment"]["source_task_id"] == source


def test_body_or_header_is_not_direct_research_reuse_permission(isolated):
    source = upload().json["task"]["id"]
    result = web.app.test_client().post("/api/tasks", json={
        "query": "解析", "processing_mode": "pdf_local", "pdf_source_task_id": source,
        "pdf_source": {"source_task_id": source, "filename": "paper.pdf"},
    }, headers={"sciassistant.pdf_source": source, "X-PDF-Source": source})
    assert result.status_code == 404


def test_detach_persists_does_not_delete_original_and_other_session_is_independent(isolated):
    root, launched = isolated
    first = upload().json["task"]["id"]
    second = upload(conversation="chat-a2").json["task"]["id"]
    assert binding(method="delete").json["attachment"] is None
    assert binding().json["attachment"] is None
    assert binding(conversation="chat-a2").json["attachment"]["source_task_id"] == second
    assert all(entry[0][3].is_file() for entry in launched)
    assert first in account._SCIENCE_TASK_OWNERS
    assert PdfSessions(root / "bindings.sqlite3").get("alice", "chat-a") is None


def test_latest_upload_and_detach_generation_reject_late_binding(tmp_path):
    store = PdfSessions(tmp_path / "store.sqlite3")
    old = store.reserve("a", "c")
    latest = store.reserve("a", "c")
    assert not store.bind("a", "c", old, "old")
    assert store.bind("a", "c", latest, "latest")
    store.reserve("a", "c", detach=True)
    assert not store.bind("a", "c", latest, "late")
    assert store.get("a", "c") is None
    assert store.get("b", "c") is None


@pytest.mark.parametrize("damage", ["missing", "traversal", "symlink", "bad_id", "corrupt", "bom"])
def test_source_integrity_fail_closed_and_bom_supported(isolated, monkeypatch, damage):
    root, launched = isolated
    source = upload().json["task"]["id"]
    snapshot = root / "tasks" / f"{source}.json"
    task = json.loads(snapshot.read_text(encoding="utf8"))
    if damage == "missing": launched[0][0][3].unlink()
    elif damage == "traversal": task["pdf_attachment"]["filename"] = "../private.pdf"
    elif damage == "symlink":
        original = Path.is_symlink
        monkeypatch.setattr(Path, "is_symlink", lambda path: path.suffix == ".pdf" or original(path))
    elif damage == "bad_id": task["pdf_attachment"]["source_task_id"] = "bbbbbbbbbbbb"
    if damage == "corrupt": snapshot.write_text("{bad", encoding="utf8")
    else: snapshot.write_text(json.dumps(task), encoding="utf-8-sig" if damage == "bom" else "utf8")
    assert binding().status_code == (200 if damage == "bom" else 404)
    assert reuse(source).status_code == (202 if damage == "bom" else 404)


def test_upload_save_failure_does_not_replace_existing_binding(isolated, monkeypatch):
    from werkzeug.datastructures import FileStorage
    first = upload().json["task"]["id"]
    def fail(*_args, **_kwargs): raise OSError("private path canary")
    monkeypatch.setattr(FileStorage, "save", fail)
    failed = upload(filename="second.pdf")
    assert failed.status_code == 202 and failed.json["task"]["status"] == "failed"
    assert "pdf_attachment" not in failed.json["task"]
    assert binding().json["attachment"]["source_task_id"] == first
    assert "private path canary" not in failed.text


def test_storage_error_is_safe_and_no_task_launched(isolated, monkeypatch):
    _, launched = isolated
    def fail(*_args, **_kwargs): raise sqlite3.OperationalError("private password canary")
    monkeypatch.setattr(PdfSessions, "reserve", fail)
    assert upload().status_code == 503
    assert not launched
    result = binding(method="delete")
    assert result.status_code == 503 and "canary" not in result.text


def test_reuse_remote_backend_fails_explicitly_without_forwarding(isolated, monkeypatch):
    monkeypatch.setenv("SCIASSISTANT_WEB_BASE", "http://127.0.0.1:5050")
    result = reuse("aaaaaaaaaaaa")
    assert result.status_code == 503 and result.json["error"] == "PDF_REUSE_UNAVAILABLE"
    assert binding().status_code == 503


@pytest.mark.parametrize("name", ["../x.pdf", "sub/x.pdf", "x" * 256 + ".pdf"])
def test_invalid_filename_rejected_before_save(isolated, name):
    assert upload(filename=name).status_code == 400


@pytest.mark.parametrize("name", ["科研论文.pdf", "科研论文.PDF"])
def test_unicode_basename_is_reusable(isolated, name):
    response = upload(filename=name)
    assert response.status_code == 202
    source = response.json["task"]["id"]
    assert response.json["task"]["pdf_attachment"]["filename"] == name
    assert binding().status_code == 200 and reuse(source).status_code == 202


@pytest.mark.parametrize("name", [r"sub\x.pdf", r"sub\\x.pdf", r"C:\\fakepath\\x.pdf"])
def test_windows_path_is_normalized_or_rejected_without_side_effects(isolated, name):
    # Multipart implementations differ: a parser may strip a Windows browser
    # path, or pass it through. Only the normalized basename may be accepted.
    _, launched = isolated
    response = upload(filename=name)
    if response.status_code == 202:
        source = response.json["task"]["id"]
        filename = response.json["task"]["pdf_attachment"]["filename"]
        # The test serializer also treats a single backslash as a quoted-header
        # escape (sub\x -> subx). This is not an on-disk directory traversal.
        assert filename in {"x.pdf", "subx.pdf"} and "/" not in filename and "\\" not in filename
        assert binding().json["attachment"] == {"source_task_id": source, "filename": filename}
        assert reuse(source).status_code == 202
    else:
        assert response.status_code == 400 and response.json["error"] == "INVALID_PDF_FILENAME"
        assert not launched and not web.TASKS and not account._SCIENCE_TASK_OWNERS
        assert binding().json["attachment"] is None


def test_raw_windows_filename_is_rejected_before_task_or_save(isolated, monkeypatch):
    from werkzeug.datastructures import FileStorage, ImmutableMultiDict
    # Pin the pass-through branch independently of the installed multipart parser.
    monkeypatch.setattr(web.app.request_class, "files", property(lambda _request:
        ImmutableMultiDict({"pdf": FileStorage(io.BytesIO(b"%PDF-1.4\n%%EOF"), filename="sub\\x.pdf")})))
    _, launched = isolated
    response = upload()
    assert response.status_code == 400 and response.json["error"] == "INVALID_PDF_FILENAME"
    assert not launched and not web.TASKS and not account._SCIENCE_TASK_OWNERS
    assert binding().json["attachment"] is None
