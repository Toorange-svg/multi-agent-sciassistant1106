"""Conservative output-only group folding; no lost scientific topics."""
from copy import deepcopy
import pytest
from multi_agent_quality import separate_report_obligations, scope_plan_to_question, answer_requirements, answer_focus_brief


def plan():
    return {'groups': [
        {'id': 'g1', 'question': 'Compare long context and RAG', 'core': ['RAG'],
         'queries': ['RAG long context'], 'metrics': ['answer_accuracy']},
        {'id': 'g3', 'question': 'Give a conditional recommendation and boundaries',
         'core': ['comparison boundary', 'conditional recommendation', 'evidence gaps', 'scientific document QA'],
         'queries': ['RAG evidence gaps recommendation'],
         'metrics': ['comparability', 'evidence_sufficiency', 'conditional_selection']}],
        'premise_checks': [{'check_id': 'p1', 'group_id': 'g1'}, {'check_id': 'p3', 'group_id': 'g3'}]}


def test_generic_group_is_preserved_as_report_obligation_not_a_query():
    original = plan()
    before = deepcopy(original)
    result, changes = separate_report_obligations(original, '比较两条路线，最后给出有条件的选型建议。')
    assert [x['id'] for x in result['groups']] == ['g1']
    assert result['report_obligations'] == [original['groups'][1]]
    assert result['premise_checks'] == [original['premise_checks'][0]]
    assert changes[0]['moved_premise_checks'] == [original['premise_checks'][1]]
    assert not changes[0]['automatic_evidence_approval'] and original == before
    assert separate_report_obligations(result, '给出有条件的选型建议。') == (result, [])


@pytest.mark.parametrize('core', [['evidence gap detection'], ['RAG', 'conditional recommendation'],
                                 ['causal inference'], ['推荐系统'], ['unknown method']])
def test_real_or_unknown_scientific_core_is_never_folded(core):
    data = plan()
    data['groups'][1]['core'] = core
    assert separate_report_obligations(data, '给出选型建议。') == (data, [])


@pytest.mark.parametrize('metrics', [['accuracy'], ['citation_traceability'], ['effect_size'], [], None])
def test_empirical_or_unknown_metrics_are_not_report_only(metrics):
    data = plan()
    data['groups'][1]['metrics'] = metrics
    assert separate_report_obligations(data, '给出选型建议。') == (data, [])


def test_never_empty_a_plan_or_invent_user_request():
    data = plan()
    assert separate_report_obligations(data, '解释RAG是什么。') == (data, [])
    data['groups'] = data['groups'][1:]
    assert separate_report_obligations(data, '给出选型建议。') == (data, [])


def test_focus_brief_and_diagnostics_keep_moved_request_visible():
    data = plan()
    data.pop('premise_checks')
    req = answer_requirements('比较长上下文与RAG，并给出有条件的选型建议。')
    result, diagnosis = scope_plan_to_question(data, req)
    assert len(result['groups']) == 1
    assert diagnosis['delivery_group_changes'][0]['moved_groups'][0]['id'] == 'g3'
    brief = answer_focus_brief(req, result)
    assert brief['report_obligations'][0]['id'] == 'g3'
    assert len(brief['planned_obligations']) == 1
