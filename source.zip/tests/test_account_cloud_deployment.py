"""Regression checks for the authenticated 5000 + MySQL Compose contract."""

from pathlib import Path
import unittest

import yaml


ROOT = Path(__file__).resolve().parents[1]


class AccountCloudDeploymentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.compose = yaml.safe_load(
            (ROOT / "docker-compose.account.cloud.yml").read_text(encoding="utf-8")
        )
        cls.schema = (ROOT / "deploy" / "mysql-init" / "001_schema.sql").read_text(encoding="utf-8")
        cls.env_template = (ROOT / ".env.account.cloud.example").read_text(encoding="utf-8")
        cls.account_dockerfile = (ROOT / "Dockerfile.account.cloud").read_text(encoding="utf-8")

    def test_account_service_exposes_authenticated_gateway_as_single_worker(self):
        service = self.compose["services"]["sciassistant-account"]
        self.assertIn(
            "${ACCOUNT_BIND_ADDRESS:-127.0.0.1}:${ACCOUNT_HOST_PORT:-5000}:5000",
            service["ports"],
        )
        self.assertNotIn("5000:5000", service["ports"])
        self.assertEqual(service["build"]["dockerfile"], "Dockerfile.account.cloud")
        self.assertNotIn("command", service)
        self.assertEqual(service["environment"]["SCIASSISTANT_TASK_WORKERS"], "1")
        self.assertEqual(service["environment"]["WEB_CONCURRENCY"], "1")
        self.assertEqual(service["environment"]["SCIASSISTANT_WEB_BASE"], "")
        self.assertEqual(service["environment"]["CORS_ALLOWED_ORIGINS"], "${CORS_ALLOWED_ORIGINS:-}")
        self.assertEqual(service["environment"]["AUTH_LOGIN_IDENTITY_LIMIT"], "${AUTH_LOGIN_IDENTITY_LIMIT:-8}")
        self.assertEqual(service["environment"]["AUTH_RATE_LIMIT_MAX_KEYS"], "${AUTH_RATE_LIMIT_MAX_KEYS:-10000}")

    def test_account_image_defaults_match_the_compose_gateway_contract(self):
        self.assertIn("EXPOSE 5000", self.account_dockerfile)
        self.assertIn("http://127.0.0.1:5000/api/readyz", self.account_dockerfile)
        self.assertIn("app:app", self.account_dockerfile)
        self.assertNotIn("5050/api/health", self.account_dockerfile)
        self.assertIn("request_limits.py", self.account_dockerfile)
        self.assertIn("account_schema.py", self.account_dockerfile)
        self.assertIn("password_reset.py", self.account_dockerfile)
        self.assertIn("python account_schema.py check && exec gunicorn", self.account_dockerfile)
        self.assertIn("COPY LICENSE NOTICE /app/", self.account_dockerfile)
        self.assertIn("org.sciassistant.dependency.pymupdf.license-mode", self.account_dockerfile)
        account = self.compose["services"]["sciassistant-account"]
        self.assertIn("http://127.0.0.1:5000/api/readyz", account["healthcheck"]["test"][-1])

    def test_all_account_start_paths_fail_closed_on_schema_migration(self):
        standalone = (ROOT / "bin/windows/start_chat_5000.ps1").read_text(encoding="utf-8")
        combined = (ROOT / "bin/windows/quick_start_web.ps1").read_text(encoding="utf-8")
        app_source = (ROOT / "app.py").read_text(encoding="utf-8")
        for source, marker in ((standalone, "Start-Component 'Chat web (5000)'"), (combined, ".\\app.py")):
            migration = source.index('account_schema.py") migrate')
            account_start = source.index(marker)
            self.assertLess(migration, account_start)
            self.assertIn("$LASTEXITCODE -ne 0", source[migration:])
        self.assertIn('run_account_schema("check")', app_source)
        self.assertIn("raise SystemExit(schema_exit)", app_source)

    def test_standalone_chat_launcher_has_a_non_destructive_environment_check(self):
        standalone = (ROOT / "bin/windows/start_chat_5000.ps1").read_text(encoding="utf-8")
        self.assertIn("[switch]$CheckEnvironmentOnly", standalone)
        self.assertIn("SCIASSISTANT_PYTHON", standalone)
        self.assertIn('".venv\\Scripts\\python.exe"', standalone)
        self.assertIn("Environment check passed. No service was started.", standalone)

    def test_schema_provision_and_migration_are_one_shot_boundaries_before_account_start(self):
        account = self.compose["services"]["sciassistant-account"]
        provisioner = self.compose["services"]["schema-provision"]
        migrator = self.compose["services"]["schema-migrate"]
        self.assertEqual(
            account["depends_on"]["schema-migrate"]["condition"],
            "service_completed_successfully",
        )
        self.assertEqual(migrator["command"], ["python", "account_schema.py", "migrate"])
        self.assertEqual(migrator["restart"], "no")
        self.assertEqual(migrator["depends_on"]["schema-provision"]["condition"], "service_completed_successfully")
        self.assertIn("MYSQL_MIGRATION_USER", migrator["environment"]["MYSQL_USER"])
        self.assertIn("MYSQL_MIGRATION_PASSWORD", migrator["environment"]["MYSQL_PASSWORD"])
        self.assertEqual(provisioner["command"], ["python", "account_schema.py", "provision"])
        self.assertEqual(provisioner["restart"], "no")
        self.assertEqual(provisioner["depends_on"]["database"]["condition"], "service_healthy")
        self.assertEqual(provisioner["environment"]["MYSQL_USER"], "root")
        self.assertIn("MYSQL_ROOT_PASSWORD", provisioner["environment"]["MYSQL_PASSWORD"])
        self.assertNotIn("MYSQL_ROOT_PASSWORD", account["environment"])
        for service in (provisioner, migrator):
            self.assertNotIn("ports", service)
            self.assertNotIn("volumes", service)
            for secret in ("SECRET_KEY", "MCP_SHARED_SECRET", "MODEL_REQUEST_TOKEN", "MODEL_REQUEST_TOKENS"):
                self.assertNotIn(secret, service["environment"])

    def test_schema_steps_have_bounded_transient_transport_retries(self):
        source = (ROOT / "account_schema.py").read_text(encoding="utf-8")
        self.assertIn("DATABASE_OPERATION_ATTEMPTS = 6", source)
        self.assertIn("DATABASE_OPERATION_RETRY_DELAY_SECONDS = 5", source)
        for code in ("2002", "2003", "2006", "2013"):
            self.assertIn(code, source)
        self.assertIn("isinstance(error, pymysql.OperationalError)", source)
        self.assertNotIn("1045", source)

    def test_persistent_volumes_cover_account_and_research_state(self):
        mounts = self.compose["services"]["sciassistant-account"]["volumes"]
        expected = {
            "sciassistant_logs:/app/logs",
            "sciassistant_uploads:/app/uploads",
            "sciassistant_user_files:/app/user_files",
            "sciassistant_web_uploads:/app/web_uploads",
            "sciassistant_arxiv:/app/arxiv",
        }
        self.assertTrue(expected.issubset(set(mounts)))
        self.assertTrue(expected and set(self.compose["volumes"]).issuperset({item.split(":", 1)[0] for item in expected}))

    def test_database_is_private_healthy_and_initializes_non_destructively(self):
        database = self.compose["services"]["database"]
        self.assertNotIn("ports", database)
        self.assertEqual(database["healthcheck"]["test"][0], "CMD-SHELL")
        healthcheck = database["healthcheck"]["test"][1]
        self.assertIn("--protocol=TCP", healthcheck)
        self.assertIn("-h 127.0.0.1", healthcheck)
        self.assertIn("information_schema.TABLES", healthcheck)
        self.assertIn("TABLE_SCHEMA='$$MYSQL_DATABASE'", healthcheck)
        self.assertIn("TABLE_NAME='users'", healthcheck)
        self.assertIn("grep -qx 1", healthcheck)
        self.assertNotIn("mysqladmin ping", healthcheck)
        self.assertNotIn("-h localhost", healthcheck)
        self.assertIn("./deploy/mysql-init:/docker-entrypoint-initdb.d:ro", database["volumes"])
        self.assertNotIn("DROP TABLE", self.schema.upper())
        for table in ("users", "chat_list", "conversation_detail", "user_files", "password_reset_tokens"):
            self.assertIn(f"CREATE TABLE IF NOT EXISTS `{table}`", self.schema)

    def test_env_template_requires_separate_application_and_root_credentials(self):
        self.assertIn("APP_ENV=production", self.env_template)
        self.assertIn("PYMUPDF_LICENSE_MODE=review-required", self.env_template)
        self.assertIn("PYMUPDF_COMMERCIAL_LICENSE_CONFIRMED=false", self.env_template)
        self.assertIn("SECRET_KEY=REPLACE_WITH_A_PRIVATE_HIGH_ENTROPY_VALUE", self.env_template)
        self.assertIn("MCP_SHARED_SECRET=REPLACE_WITH_A_PRIVATE_HIGH_ENTROPY_MCP_SECRET", self.env_template)
        self.assertIn("MYSQL_APP_USER=sciassistant", self.env_template)
        self.assertIn("MYSQL_APP_PASSWORD=REPLACE_WITH_A_PRIVATE_DATABASE_PASSWORD", self.env_template)
        self.assertIn("MYSQL_MIGRATION_USER=sciassistant_migrator", self.env_template)
        self.assertIn("MYSQL_MIGRATION_PASSWORD=REPLACE_WITH_A_PRIVATE_MIGRATION_PASSWORD", self.env_template)
        self.assertIn("MYSQL_ROOT_PASSWORD=REPLACE_WITH_A_DIFFERENT_PRIVATE_ROOT_PASSWORD", self.env_template)
        self.assertIn("CORS_ALLOWED_ORIGINS=", self.env_template)
        self.assertIn("ACCOUNT_BIND_ADDRESS=127.0.0.1", self.env_template)
        self.assertIn("ACCOUNT_HOST_PORT=5000", self.env_template)
        self.assertIn("AUTH_LOGIN_IDENTITY_LIMIT=8", self.env_template)
        self.assertIn("AUTH_REGISTER_IDENTITY_LIMIT=3", self.env_template)
        self.assertIn("PASSWORD_RESET_ENABLED=false", self.env_template)
        self.assertIn("SMTP_USE_TLS=true", self.env_template)
        self.assertNotIn("MYSQL_APP_USER=root", self.env_template)

    def test_shared_mcp_is_private_separately_supervised_and_health_gated(self):
        account = self.compose["services"]["sciassistant-account"]
        mcp = self.compose["services"]["mcp"]
        self.assertEqual(account["environment"]["MCP_SERVER_URL"], "http://mcp:6274/mcp")
        self.assertEqual(account["environment"]["MCP_USE_STDIO"], "false")
        self.assertIn("MCP_SHARED_SECRET", account["environment"])
        self.assertEqual(account["environment"]["MCP_SHARED_SECRET"], mcp["environment"]["MCP_SHARED_SECRET"])
        self.assertEqual(account["depends_on"]["mcp"]["condition"], "service_healthy")
        self.assertNotIn("ports", mcp)
        self.assertIn("tools/run_mcp_service.py", mcp["command"])
        self.assertIn("/app/logs/mcp_workspaces", mcp["command"])
        self.assertIn("sciassistant_arxiv:/app/arxiv", mcp["volumes"])
        self.assertIn("sciassistant_logs:/app/logs", mcp["volumes"])
        self.assertIn("6274/health", " ".join(mcp["healthcheck"]["test"]))
        self.assertEqual(mcp["environment"]["APP_ENV"], "production")
        self.assertIn("MCP_SHARED_SECRET", mcp["environment"])
        for credential in ("SECRET_KEY", "MYSQL_PASSWORD", "MYSQL_ROOT_PASSWORD"):
            self.assertNotIn(credential, mcp["environment"])

    def test_standalone_research_compose_also_uses_private_shared_service(self):
        compose = yaml.safe_load((ROOT / "docker-compose.cloud.yml").read_text(encoding="utf-8"))
        dockerfile = (ROOT / "Dockerfile.cloud").read_text(encoding="utf-8")
        web = compose["services"]["sciassistant-web"]
        self.assertEqual(web["environment"]["MCP_SERVER_URL"], "http://mcp:6274/mcp")
        self.assertIn("MCP_SHARED_SECRET", web["environment"])
        self.assertEqual(web["depends_on"]["mcp"]["condition"], "service_healthy")
        self.assertNotIn("ports", compose["services"]["mcp"])
        self.assertIn("MCP_SHARED_SECRET", compose["services"]["mcp"]["environment"])
        self.assertEqual(web["environment"]["MCP_SHARED_SECRET"],
                         compose["services"]["mcp"]["environment"]["MCP_SHARED_SECRET"])
        self.assertIn("http://127.0.0.1:5050/api/readyz", dockerfile)
        self.assertIn("http://127.0.0.1:5050/api/readyz", web["healthcheck"]["test"][-1])
        self.assertNotIn("5050/api/health", dockerfile)
        self.assertNotIn("5050/api/health", web["healthcheck"]["test"][-1])

    def test_private_nested_env_files_are_excluded_from_images(self):
        dockerignore = (ROOT / ".dockerignore").read_text(encoding="utf-8")
        self.assertIn("**/.env", dockerignore.splitlines())
        self.assertIn("**/.env.*", dockerignore.splitlines())


if __name__ == "__main__":
    unittest.main()
