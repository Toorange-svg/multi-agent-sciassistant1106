"""Distinguish actual assertions and protocol repairs without auto-approval."""
from copy import deepcopy

import pytest

from multi_agent_quality import (SCIENTIFIC_REVIEW_FRAME_POLICY, scientific_review_frame,
    audit_correction_brief, citation_audit_input, check_audit, publication_rejections,
    AUDIT_PROTOCOL_POLICY)
from multi_agent_quality import (absence_scope_features, _bounded_absence_context,
    ABSENCE_SCOPE_POLICY, LEVEL_REPORT_ABSENCE_SCOPE_POLICY)
from test_multi_agent_report_fields import draft, evidence, QUOTE
from test_multi_agent_absence_basis import audit, absence
from test_multi_agent_pipeline_v2 import agents, pipeline


@pytest.mark.parametrize('field', ['text', 'scope_note', 'qualification'])
@pytest.mark.parametrize('cue', ['待验证假设', '推断性建议', '作者报告'])
def test_mode_cues_keep_exact_current_field_offsets_and_do_not_approve(field, cue):
    data = draft()
    claim = data['claims'][0]
    claim[field] = '这是一项'+cue+'，需要核查前提。'
    original = deepcopy(data)
    frame = scientific_review_frame(claim)
    match = next(r for r in frame['literal_mode_cues'] if r['field'] == field)
    assert claim[field][match['start']:match['end']] == match['text'] == cue
    assert frame['semantic_auto_approval'] is False
    assert 'decision' not in frame and data == original


def test_audit_input_passes_type_without_turning_it_into_truth_or_changing_legacy():
    data, sources = draft(), evidence()
    assert 'scientific_review_frame' not in citation_audit_input(data, sources)['claims'][0]
    data['scientific_review_frame_policy'] = SCIENTIFIC_REVIEW_FRAME_POLICY
    packet = citation_audit_input(data, sources)
    row = packet['claims'][0]
    assert row['claim_type'] == data['claims'][0]['claim_type']
    assert row['scientific_review_frame']['declared_claim_type'] == row['claim_type']
    assert not row['scientific_review_frame']['semantic_auto_approval']


def test_correction_brief_names_exact_faulty_field_not_invented_writer_failure():
    data, sources = draft(), evidence()
    data['audit_protocol_policy'] = AUDIT_PROTOCOL_POLICY
    data['claims'][0]['scope_note'] = '所选片段未给出具体准确率。'
    raw = absence(audit(data), 'paraphrased nonexistent statement', field='scope_note')
    checked = check_audit(raw, data, sources)
    before = deepcopy((data, checked))
    brief = audit_correction_brief(data, checked)
    row = brief['claims'][0]
    assert row['current_fields'] == {'scope_note': '所选片段未给出具体准确率。'}
    assert all(r['claim_id'] == 'c1' and r['field'] == 'scope_note' for r in row['exact_absence_options'])
    assert not brief['semantic_auto_approval'] and not brief['writer_fields_changed']
    assert (data, checked) == before
    assert publication_rejections(checked, data) == {'c1'}


def test_hypothesis_label_cannot_override_a_scientific_rejection():
    data, sources = draft(), evidence()
    data['scientific_review_frame_policy'] = SCIENTIFIC_REVIEW_FRAME_POLICY
    data['claims'][0]['scope_note'] = '这是待验证假设。'
    raw = audit(data)
    raw.update(status='needs_revision', rejected_claim_ids=['c1'], issues=[
        {'claim_id': 'c1', 'reason_code': 'UNSUPPORTED_INFERENCE', 'detail': 'Invalid experimental premise.'}])
    row = raw['claim_results'][0]
    row.update(decision='rejected', reason_code='UNSUPPORTED_INFERENCE', detail='Invalid experimental premise.')
    row['field_results']['text'].update(status='unsupported', detail='Invalid experimental premise.')
    citation_audit_input(data, sources)
    checked = check_audit(raw, data, sources)
    assert publication_rejections(checked, data) == {'c1'}


def test_formal_workflow_correction_receives_current_field_brief(tmp_path):
    configured, calls = agents()
    data = draft()
    data['claims'][0]['evidence_ids'] = ['arxiv-1']
    configured.writer.handler = lambda _: {'output': deepcopy(data)}
    seen = []
    def auditor(packet):
        target = next(i['payload'] for i in packet['inputs'] if i['payload'].get('direct_answer'))
        frame = next(i['payload'] for i in packet['inputs'] if i['payload'].get('schema_version') == 'sciassistant.citation-audit-input/v1')
        assert frame['claims'][0]['claim_type'] == 'technical'
        value = audit(target)
        if not seen:
            absence(value, 'invented bookkeeping span')
        else:
            validation = next(i['payload'] for i in packet['inputs'] if i['payload'].get('stage') == 'citation_auditor')
            brief = validation['current_field_correction_brief']
            assert brief['claims'][0]['current_fields'] == {'qualification': target['claims'][0]['qualification']}
            assert not brief['semantic_auto_approval']
        seen.append(packet)
        return {'output': value}
    configured.citation_auditor.handler = auditor
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {'status': 'ok', 'papers': [
        {'paper_id': '1', 'title': 'Paper', 'abstract': QUOTE}]})
    result = flow.run('frame-correction', 'owner', 'Define A')
    assert len(seen) == 2 and result['run']['model_calls_used'] == 6
    assert result['run']['status'] == 'completed'


@pytest.mark.parametrize('text', ['片段未含表格', '片段未给具体检测率数值',
    'Table 2数值未在片段中', '片段未含Fig.4/Tab.4的数值', '摘录中没有具体数值'])
def test_bare_passage_inventory_is_explicit_reading_scope(text):
    assert _bounded_absence_context(text, text, **absence_scope_features(ABSENCE_SCOPE_POLICY))
    assert not _bounded_absence_context(text, text, **absence_scope_features(LEVEL_REPORT_ABSENCE_SCOPE_POLICY))


@pytest.mark.parametrize('text,assertion', [
    ('片段介绍方法。未报告实验。', '未报告实验。'),
    ('片段介绍方法；但论文未做实验。', '但论文未做实验。'),
    ('片段未含表格；另一研究没有开展验证。', '另一研究没有开展验证。'),
    ('片段化模型没有报告实验。', '片段化模型没有报告实验。')])
def test_bare_scope_does_not_rescue_new_subject_or_new_sentence(text, assertion):
    assert not _bounded_absence_context(assertion, text, **absence_scope_features(ABSENCE_SCOPE_POLICY))
