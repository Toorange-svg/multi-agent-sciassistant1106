"""Reject optional rework without discarding independently approved evidence."""
import json
from dataclasses import replace

import pytest

from multi_agent_agents import AgentWorker
from multi_agent_pipeline_v2 import validate_gap_plan
from multi_agent_pipeline_v2 import LiteraturePipelineV2
from multi_agent_agents import ArtifactDirectory
from multi_agent_workflow import WorkflowStore
from test_multi_agent_pipeline_v2 import agents, pipeline
from tools.multi_agent_cli import _mock_agents


TARGETS = [{"gap_id": "g3-trainable-parameters", "group_id": "g3", "metric": "trainable parameters"}]
VALID_ROW = {**TARGETS[0], "query": "QLoRA trainable parameters adapter rank experimental setup"}


@pytest.mark.parametrize("rows", [
    None, [], [VALID_ROW] * 3, [None], [{**VALID_ROW, "query": 7}], [{**VALID_ROW, "query": " "}],
    [{**VALID_ROW, "query": "x" * 501}], [{**VALID_ROW, "query": " INITIAL QUERY "}],
    [VALID_ROW, VALID_ROW], [{**VALID_ROW, "group_id": "g2"}],
    [{**VALID_ROW, "gap_id": "g2-trainable-parameters"}], [{**VALID_ROW, "metric": "memory"}],
    [{**VALID_ROW, "source": "arxiv"}],
    [{**VALID_ROW, "gap_id": []}], [{**VALID_ROW, "metric": []}], [{**VALID_ROW, "group_id": {}}],
])
def test_gap_plan_invalid_forms_are_structured_rejections(rows):
    result = validate_gap_plan({"gaps": rows}, TARGETS, {"initial query"})
    assert result["valid"] is False and result["stage"] == "gap_plan"
    assert result["issues"] and result["recovery_action"] == "keep_prior_review_no_new_evidence_no_network"
    assert "QLoRA" not in json.dumps(result), "diagnostics must not echo private queries"


def test_unknown_gap_schema_cannot_be_used_as_recovery_permission():
    result = validate_gap_plan({"schema_version": "sciassistant.gap-search-plan/v99", "gaps": [VALID_ROW]}, TARGETS, set())
    assert result["valid"] is False and result["issues"] == [{"reason_code": "GAP_PLAN_SCHEMA_INVALID"}]


def test_historical_98abb_gap_extra_g2_is_rejected_despite_partial_coverage():
    actual_shape = {"gaps": [VALID_ROW, {"gap_id": "g2-trainable-parameters", "group_id": "g2",
        "metric": "trainable parameters", "query": "LoRA low-rank adaptation trainable parameters memory footprint GPT-3"}]}
    result = validate_gap_plan(actual_shape, TARGETS, set())
    assert result["issues"] == [{"row_index": 1, "reason_code": "GAP_TARGET_OUTSIDE_TICKET"}]
    assert validate_gap_plan({"gaps": [VALID_ROW]}, TARGETS, set())["valid"] is True


def test_gap_scope_uses_ticket_first_two_not_all_actionable_review_rows():
    targets = [{"gap_id": f"gap-{index}", "group_id": "g3", "metric": f"metric-{index}"} for index in range(3)]
    result = validate_gap_plan({"gaps": [{**targets[2], "query": "a new query"}]}, targets[:2], set())
    assert result["valid"] is False and result["issues"][0]["reason_code"] == "GAP_TARGET_OUTSIDE_TICKET"


@pytest.mark.parametrize("audit_reject", [False, True])
def test_eight_approved_packets_survive_extra_group_without_bypassing_audit(tmp_path, audit_reject):
    original = _mock_agents(source_scope="uploaded_pdf_and_arxiv")
    plan = {"groups": [{"id": group, "question": "LoRA QLoRA comparison", "queries": [group + " query"],
        "metrics": ["relation" if group == "g1" else "trainable parameters"]} for group in ("g1", "g2", "g3")]}
    packets = [{"evidence_id": "fixture-" + str(index), "group_id": group, "paper_id": "fixture-paper",
        "source": "uploaded_pdf", "excerpt": "Fixture: frozen base weights and trainable low-rank adapters.",
        "locator": {"page": index + 1}, "coverage_scope": "selected_chunks", "title": "Test fixture"}
        for index, group in enumerate(["g1"] * 3 + ["g2"] * 2 + ["g3"] * 3)]
    ids = {row["evidence_id"] for row in packets}
    review = {"schema_version": "sciassistant.evidence-review/v5", "coverage_status": "partial",
        "allowed_evidence_ids": sorted(ids), "conflicts": [], "decisions": [{"evidence_id": row["evidence_id"],
            "decision": "approved", "reason_code": "SUPPORTED", "detail": "Only a test fixture.",
            "group_ids": [row["group_id"]], "task_relevance": "direct_task_evidence", "source_domain": ""} for row in packets],
        "coverage": [{"gap_id": "g1-relation", "group_id": "g1", "metric": "relation", "status": "direct",
                      "evidence_ids": ["fixture-0"]},
            {"gap_id": "g2-trainable-parameters", "group_id": "g2", "metric": "trainable parameters",
             "status": "partial", "evidence_ids": ["fixture-3", "fixture-4"], "recommended_action": "qualified_answer"},
            {**TARGETS[0], "status": "missing", "evidence_ids": [], "recommended_action": "qualified_answer"}]}
    tool_calls = []
    class Tools:
        search_action = "request_research_search"
        def execute(self, requests, *, recovery=False, progress=None, **_):
            assert not recovery, "rejected gap plan cannot execute recovery tools"
            tool_calls.append(requests)
            result = {"evidence": packets, "observations": []}
            if progress: progress(result)
            return result
    def writer(packet):
        supplied = next(row["payload"]["evidence"] for row in packet["inputs"] if "evidence" in row["payload"])
        assert {row["evidence_id"] for row in supplied} == ids
        return original.writer.handler(packet)
    def auditor(packet):
        result = original.citation_auditor.handler(packet)
        if audit_reject:
            result["output"]["status"] = "needs_revision"
            result["output"]["rejected_claim_ids"] = ["claim-1"]
            result["output"]["claim_results"][0].update(decision="rejected", reason_code="UNSUPPORTED_CLAIM")
        return result
    workers = replace(original,
        planner=AgentWorker("planner", lambda _: {"output": plan}, ["create_research_plan"]),
        retriever=AgentWorker("retriever", lambda _: {"tool_requests": [{"request_id": group["id"],
            "action": "request_research_search", "arguments": {"group_id": group["id"],
            "source": "uploaded_pdf", "query": group["queries"][0]}} for group in plan["groups"]]}, ["request_research_search"]),
        reviewer=AgentWorker("reviewer", lambda _: {"output": review}, ["review_evidence"]),
        gap_analyst=AgentWorker("gap_analyst", lambda _: {"output": {"gaps": [VALID_ROW,
            {**VALID_ROW, "gap_id": "g2-trainable-parameters", "group_id": "g2"}]}}, ["create_gap_search_plan"]),
        writer=AgentWorker("writer", writer, ["write_approved_claims"]),
        citation_auditor=AgentWorker("citation_auditor", auditor, ["audit_citations"]))
    artifacts = ArtifactDirectory(tmp_path / "artifacts")
    result = LiteraturePipelineV2(WorkflowStore(tmp_path / "workflow.sqlite3"), artifacts, workers,
        Tools(), event_path=tmp_path / "events.jsonl").run("eight-retained", "owner", "Compare LoRA and QLoRA")
    assert result["run"]["status"] == ("failed" if audit_reject else "needs_review")
    assert result["run"]["failure_code"] == ("NO_AUDITED_CLAIMS" if audit_reject else None)
    assert len(tool_calls) == 1 and result["run"]["model_calls_used"] <= 10
    final = artifacts.get(result["final_artifact_id"])
    approved = artifacts.get(final["artifact_refs"]["approved"])["evidence"]
    publication = artifacts.get(final["artifact_refs"]["publication"])
    assert {row["evidence_id"] for row in approved} == ids
    assert all(row["published"] is not audit_reject for row in publication["claims"])


@pytest.mark.parametrize("interrupt", ["cancel", "deadline", "provider"])
def test_optional_gap_recovery_does_not_swallow_terminal_or_provider_failure(tmp_path, interrupt):
    configured, calls = agents(recovery=True)
    flow, store = pipeline(tmp_path, configured)
    def gap(_packet):
        if interrupt == "cancel":
            store.force_terminal("run-1", "cancelled", failure_code="USER_CANCELLED")
        if interrupt == "deadline":
            flow.deadline = 0
        if interrupt == "provider":
            return {"status": "failed", "error_code": "MODEL_HTTP_401"}
        return {"output": {"gaps": [{"group_id": "bad", "query": "private query"}]}}
    flow.agents = replace(configured, gap_analyst=AgentWorker("gap_analyst", gap, ["create_gap_search_plan"]))
    result = flow.run("run-1", "owner", "Compare A")
    expected = {"cancel": "cancelled", "deadline": "timed_out", "provider": "failed"}[interrupt]
    assert result["run"]["status"] == expected
    assert "writer" not in calls and "citation_auditor" not in calls


def test_no_approved_evidence_still_fails_without_answer_fabrication(tmp_path):
    configured, calls = agents(recovery=True)
    configured = replace(configured, gap_analyst=AgentWorker("gap_analyst", lambda _packet: {
        "output": {"gaps": [{"group_id": "outside", "query": "invalid target"}]}}, ["create_gap_search_plan"]))
    flow, _store = pipeline(tmp_path, configured, search=lambda *_args: {"status": "ok", "papers": []})
    result = flow.run("run-1", "owner", "Compare A")
    assert result["run"]["status"] == "failed" and result["run"]["failure_code"] == "INSUFFICIENT_EVIDENCE"
    assert result["direct_answer"] and "writer" not in calls
