"""Original-source opportunity, literal source framing and honest answer scope."""
from copy import deepcopy
import time

import pytest

from multi_agent_pipeline_v2 import prepare_primary_source_plan, prioritize_source_title_actions
from multi_agent_quality import PRIMARY_SOURCE_POLICY, answer_scope_summary, source_boundary_brief, citation_audit_input
from multi_agent_sources import AutoSourceExecutor, SEARCH_ACTION
from multi_agent_workflow import WorkflowError
from test_multi_agent_local_pdf import pdf
from test_multi_agent_sources import action, public_search

LORA = "LoRA: Low-Rank Adaptation of Large Language Models"
QLORA = "QLoRA: Efficient Finetuning of Quantized LLMs"


def plan():
    return {"groups": [{"id": "g1", "heading": "关系", "queries": ["QLoRA mechanism", "LoRA memory"],
        "source_hints": [QLORA, LORA]}]}


def test_primary_title_is_compiled_before_pdf_inside_same_two_query_quota():
    original = plan()
    before = deepcopy(original)
    compiled, report = prepare_primary_source_plan(original, "检索 LoRA 原始论文核对。", "uploaded_pdf_and_arxiv")
    assert original == before
    assert compiled["groups"][0]["queries"] == ["QLoRA mechanism", f'ti:"{LORA}"']
    assert len(report["targets"]) == 1 and report["targets"][0]["source_title_clue"] == LORA
    assert compiled["primary_source_policy"] == PRIMARY_SOURCE_POLICY


@pytest.mark.parametrize("scope,question", [
    ("uploaded_pdf", "检索 LoRA 原始论文"), ("arxiv", "解释 LoRA 机制"),
    ("uploaded_pdf_and_arxiv", "不必检索原始论文，只比较已上传的资料"),
    ("arxiv", "Do not search original papers; search reviews")])
def test_primary_not_forced_without_request_or_public_scope(scope, question):
    original = plan()
    compiled, report = prepare_primary_source_plan(original, question, scope)
    assert compiled == original and not report["targets"]


def test_original_title_not_duplicated_across_groups_and_exclusion_preserved():
    original = plan()
    original["groups"].append({**deepcopy(original["groups"][0]), "id": "g2"})
    compiled, report = prepare_primary_source_plan(original, "检索 LoRA 原始论文", "arxiv")
    assert len(report["targets"]) == 1 and len(compiled["groups"]) == 2
    original["groups"][0]["queries"][0] = 'abs:"LoRA" NOT ti:"LoRA original"'
    compiled, _ = prepare_primary_source_plan(original, "检索 LoRA 原始论文", "arxiv")
    assert compiled["groups"][0]["queries"] == original["groups"][0]["queries"]


def test_one_query_original_public_slot_does_not_invent_title_or_paper_id():
    original = plan()
    original["groups"][0]["queries"] = ["local passage"]
    compiled, report = prepare_primary_source_plan(original, "检索 LoRA 原始论文", "uploaded_pdf_and_arxiv")
    assert compiled["groups"][0]["queries"] == ["local passage", f'ti:"{LORA}"']
    assert "paper_id" not in str(report)
    original["groups"][0].pop("source_hints")
    compiled, report = prepare_primary_source_plan(original, "检索 LoRA 原始论文", "arxiv")
    assert compiled["groups"][0] == original["groups"][0] and not report["targets"]


def test_public_single_action_keeps_requested_original_with_same_method_entity():
    compiled, _ = prepare_primary_source_plan(plan(), "检索 LoRA 原始论文", "arxiv")
    request = {"request_id": "r1", "action": "request_arxiv_search", "arguments": {"group_id": "g1", "query": "LoRA memory"}}
    output, _ = prioritize_source_title_actions(compiled, [request], {"explicit_entities": ["LoRA"]})
    assert len(output) == 1 and output[0]["arguments"]["query"] == f'ti:"{LORA}"'


@pytest.mark.parametrize("proposal", ["local_only", "public_two", "public_one"])
def test_auto_original_action_keeps_local_and_permission_bounds(pdf, tmp_path, proposal):
    from multi_agent_pipeline_v2 import DeterministicLiteratureExecutor
    calls = []
    tool = AutoSourceExecutor(tmp_path / "run", pdf, allow_public=True, rag_mode="lexical",
        public_factory=lambda: DeterministicLiteratureExecutor(lambda query, limit: (calls.append(query) or public_search(query, limit))))
    compiled, _ = prepare_primary_source_plan(plan(), "检索 LoRA 原始论文", "uploaded_pdf_and_arxiv")
    tool.configure_plan(compiled)
    title_query = f'ti:"{LORA}"'
    if proposal == "local_only":
        requests = [action(query="QLoRA mechanism")]
    elif proposal == "public_two":
        requests = [action("arxiv", "QLoRA mechanism"), {**action("arxiv", title_query), "request_id": "r2"}]
    else:
        requests = [action("arxiv", "QLoRA mechanism")]
    local, public = tool._requests(requests, False, {"g1"})
    assert len(local) == len(public) == 1 and public[0]["arguments"]["query"] == title_query
    assert len(local) + len(public) <= 2
    result = tool.execute(requests, group_ids={"g1"}, deadline=time.monotonic() + 30)
    assert calls == [title_query] and tool.local.ingested and result["evidence"]
    assert not any(row.get("review_status") == "approved" for row in result["evidence"])


def test_original_policy_does_not_repair_illegal_public_request_or_expand_recovery(pdf, tmp_path):
    tool = AutoSourceExecutor(tmp_path / "run", pdf, allow_public=True, rag_mode="lexical")
    compiled, _ = prepare_primary_source_plan(plan(), "检索 LoRA 原始论文", "uploaded_pdf_and_arxiv")
    tool.configure_plan(compiled)
    with pytest.raises(WorkflowError, match="outside question-only plan"):
        tool._requests([action("arxiv", "private extracted keyword")], False, {"g1"})
    local, public = tool._requests([action(query="local recovery", gap_id="gap1")], True, {"g1"})
    assert len(local) == 1 and public == []
    compiled["primary_source_targets"][0]["query"] = "unplanned"
    with pytest.raises(WorkflowError, match="inside question-only plan"):
        tool.configure_plan(compiled)


def test_source_framing_quotes_not_automatic_causal_or_absence_verdict():
    from test_multi_agent_report_fields import draft, evidence
    sources = evidence()
    sources["evidence"][0]["excerpt"] = "Why adaptation is feasible. Different embedding distributions need adaptation.\nFigure 2: test set (12 000 samples)."
    original = deepcopy(sources)
    brief = source_boundary_brief(sources)
    assert any(c["category"] == "explanation_target" for c in brief["cues"])
    assert any(c["category"] == "reported_evaluation" for c in brief["cues"])
    for cue in brief["cues"]:
        assert cue["quote"] == sources["evidence"][0][cue["field"]][cue["start"]:cue["end"]]
    audit_input = citation_audit_input(draft(), sources)
    assert any("EXACT phenomenon" in q for q in audit_input["claims"][0]["semantic_review_questions"])
    assert sources == original and "decision" not in brief and "approved" not in audit_input["claims"][0]


def test_published_scope_not_filled_by_limitation_or_rejected_claim():
    from test_multi_agent_report_fields import draft, evidence
    from test_multi_agent_absence_basis import audit
    data, sources = draft(), evidence()
    data["claims"][0].update(group_id="g3", claim_type="technical")
    sources["evidence"][0].update(reviewed_group_ids=["g3"])
    planned = {"groups": [{"id": f"g{i}", "heading": title} for i, title in enumerate(["KV", "PagedAttention", "投机"], 1)]}
    checked = audit(data)
    result = answer_scope_summary(planned, data, sources, checked)
    assert [r["status"] for r in result["topics"]] == ["no_approved_evidence", "no_approved_evidence", "published_limited_content"]
    data["claims"][0]["claim_type"] = "limitation"
    assert answer_scope_summary(planned, data, sources, checked)["topics"][2]["status"] == "approved_but_no_published_core"


def test_scope_copy_is_metadata_outside_body_and_html_escaped():
    from multi_agent_status import describe_status, status_markdown, status_html
    display = describe_status("partial")
    display["answer_scope"] = {"topics": [{"title": "KV <script>bad</script>", "status": "no_approved_evidence"}]}
    assert "本次尚未形成" in status_markdown(display)
    html = status_html(display)
    assert "<script>" not in html and "&lt;script&gt;" in html


def test_local_planned_facets_offer_caption_recall_under_same_packet_budget(pdf, tmp_path):
    from multi_agent_local_pdf import LocalPdfRagExecutor
    from test_multi_agent_local_pdf import action as local_action
    tool = LocalPdfRagExecutor(tmp_path / "run", pdf, rag_mode="lexical")
    tool.configure_plan({"groups": [{"id": "g1", "core": ["CIFAKE"], "support": ["adaptation", "dataset"],
        "metrics": ["accuracy", "evaluation protocol"], "queries": ["CIFAKE accuracy"]}]})
    calls = []
    real = tool.services.search
    def search(query, **kwargs):
        calls.append(kwargs)
        return real(query, **kwargs)
    tool.services.search = search
    tool.execute(local_action(query="CIFAKE accuracy"), group_ids={"g1"}, deadline=time.monotonic()+30)
    assert calls[0]["limit"] == calls[0]["per_document"] == 4 and calls[0]["context_budget"] == 4000
    assert calls[0]["passage_queries"][0] == "CIFAKE accuracy test samples" and len(calls[0]["passage_queries"]) <= 3
    assert calls[0]["priority_passage_queries"] == ["CIFAKE accuracy test samples"]


def test_cross_source_notation_requires_first_formula_map_not_later_disclaimer():
    from multi_agent_live import ROLE_PROMPTS
    from multi_agent_quality import source_reasoning_questions
    assert "Symbols are SOURCE-LOCAL" in ROLE_PROMPTS["writer"]
    assert "P_target/P_draft" in ROLE_PROMPTS["writer"]
    assert any("FIRST use" in q and "fixed symbols" in q for q in source_reasoning_questions())


def test_cross_page_condition_instruction_is_in_existing_field_audit_input():
    from test_multi_agent_report_fields import draft, evidence
    item = citation_audit_input(draft(), evidence())["claims"][0]
    assert any("each factual clause" in q and "supporting approved page" in q for q in item["semantic_review_questions"])


def test_cleanup_worker_does_not_spin_when_global_config_is_cleared(monkeypatch):
    import threading
    from types import SimpleNamespace
    from deepdiver_v2.src.tools import mcp_server_standard as server
    captured, delays, cleaned = [], [], []
    class Thread:
        def __init__(self, *, target, daemon):
            captured.append(target)
        def start(self):
            pass
    def sleep(seconds):
        delays.append(seconds)
        if len(delays) == 1:
            server.config = None
        else:
            raise KeyboardInterrupt()
    async def cleanup():
        cleaned.append(True)
    monkeypatch.setattr(server, "config", SimpleNamespace(cleanup_interval_seconds=5))
    monkeypatch.setattr(server, "time", SimpleNamespace(sleep=sleep))
    monkeypatch.setattr(threading, "Thread", Thread)
    server.ThreadSafeSessionManager._start_cleanup_thread(SimpleNamespace(_cleanup_expired_sessions=cleanup))
    with pytest.raises(KeyboardInterrupt):
        captured[0]()
    assert delays == [5, 5] and cleaned == [True]


def test_public_mechanism_recall_offers_algorithm_not_only_intro_or_proof(tmp_path):
    from multi_agent_live import LiveArxivRagExecutor
    from test_multi_agent_live import make_search, request, create_pdf
    tool = LiveArxivRagExecutor(tmp_path / "run", tmp_path / "storage", rag_mode="lexical",
        search=make_search(), download=lambda _, folder: create_pdf(folder))
    tool.configure_plan({"groups": [{"id": "g1", "core": ["PagedAttention"],
        "support": ["memory", "layout", "sharing"], "metrics": ["mechanism"], "queries": ["PagedAttention memory"]}]})
    calls, real = [], tool.services.search
    def search(query, **kwargs):
        calls.append(kwargs)
        return real(query, **kwargs)
    tool.services.search = search
    tool.execute(request(), group_ids={"g1"}, deadline=time.monotonic()+30)
    assert calls[-1]["passage_queries"] == ["memory", "layout", "sharing"]
    assert calls[-1]["mechanism_passage_queries"] == ["memory", "layout", "sharing"]
    assert calls[-1]["limit"] == 4 and calls[-1]["per_document"] == 2 and calls[-1]["context_budget"] == 4000
