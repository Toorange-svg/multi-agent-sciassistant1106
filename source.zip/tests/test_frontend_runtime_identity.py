"""The user page does not expose deployment/runtime diagnostics."""
from pathlib import Path

HTML = Path(__file__).resolve().parents[1] / 'chatAi/ai_chat.html'


def test_runtime_banner_and_refresh_control_are_hidden():
    html = HTML.read_text(encoding='utf-8')
    assert 'id="runtime-version-notice"' not in html
    assert 'id="refresh-runtime-version"' not in html
    assert 'function runtimeVersionNotice' not in html
    assert 'function refreshRuntimeVersion' not in html


def test_open_source_link_lives_in_display_settings():
    html = HTML.read_text(encoding='utf-8')
    settings = html.split('<dialog id="chat-settings-dialog"', 1)[1].split('</dialog>', 1)[0]
    sidebar = html.split('<div id="sidebar"', 1)[-1].split('</div>', 1)[0]
    assert 'id="source-license-link"' in settings
    assert 'id="source-license-link"' not in sidebar
