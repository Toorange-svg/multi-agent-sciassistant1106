"""Read-only HTTP checker clones report data and excludes private state."""
import json
from contextlib import closing
from pathlib import Path
import sqlite3
from types import SimpleNamespace

import pytest

from tools.check_multi_agent_web_readonly import bundle_unchanged, check, copy_report_bundle


def report_bundle(tmp_path):
    source = tmp_path / "source"
    source.mkdir()
    (source / "manifest.json").write_text(json.dumps({"run_id": "abcdef012345"}), encoding="utf8")
    with closing(sqlite3.connect(source / "workflow.sqlite3")) as connection:
        connection.execute("CREATE TABLE fixture (value INTEGER)")
        connection.execute("INSERT INTO fixture VALUES (7)")
        connection.commit()
    for name, content in {"artifacts/final-result-fixture.json": b"{}", "pdf/doc/source.pdf": b"pdf-bytes",
                          "pages/evidence-1.png": b"page-bytes", "private_rag/evidence.sqlite3": b"private-index",
                          "pdf/doc/layout.json": b"private-parse", "pages/internal.bin": b"not-public"}.items():
        path = source / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
    return source


def test_copy_preserves_pdf_and_page_bytes_but_excludes_indexes_and_auxiliary_files(tmp_path):
    source = report_bundle(tmp_path)
    target = tmp_path / "copy"
    hashes = copy_report_bundle(source, target)
    assert len(hashes) == 5 and bundle_unchanged(source, hashes)
    assert (target / "pdf/doc/source.pdf").read_bytes() == b"pdf-bytes"
    assert (target / "pages/evidence-1.png").read_bytes() == b"page-bytes"
    assert not (target / "private_rag").exists()
    assert not (target / "pdf/doc/layout.json").exists() and not (target / "pages/internal.bin").exists()
    with closing(sqlite3.connect(target / "workflow.sqlite3")) as connection:
        assert connection.execute("SELECT value FROM fixture").fetchone() == (7,)


def test_original_changes_are_detected_without_modifying_source(tmp_path):
    source = report_bundle(tmp_path)
    hashes = copy_report_bundle(source, tmp_path / "copy")
    (source / "pages/evidence-1.png").write_bytes(b"changed")
    assert bundle_unchanged(source, hashes) is False


@pytest.mark.parametrize("damage", ["existing", "same", "nested", "missing_manifest", "missing_database", "malformed_database"])
def test_invalid_copy_or_overlap_is_rejected(tmp_path, damage):
    source = report_bundle(tmp_path)
    target = tmp_path / "copy"
    if damage == "existing": target.mkdir()
    if damage == "same": target = source
    if damage == "nested": target = source / "copy"
    if damage == "missing_manifest": (source / "manifest.json").unlink()
    if damage == "missing_database": (source / "workflow.sqlite3").unlink()
    if damage == "malformed_database": (source / "workflow.sqlite3").write_bytes(b"not sqlite")
    with pytest.raises((ValueError, sqlite3.Error)):
        copy_report_bundle(source, target)


def test_symlink_input_is_rejected_before_copy(tmp_path, monkeypatch):
    source = report_bundle(tmp_path)
    unsafe = source / "pages/evidence-1.png"
    original = Path.is_symlink
    monkeypatch.setattr(Path, "is_symlink", lambda path: path == unsafe or original(path))
    with pytest.raises(ValueError, match="unsafe report asset"):
        copy_report_bundle(source, tmp_path / "copy")
    assert not (tmp_path / "copy").exists()


def test_oversized_pdf_is_rejected_before_any_copy(tmp_path, monkeypatch):
    source = report_bundle(tmp_path)
    unsafe = source / "pdf/doc/source.pdf"
    original = Path.stat
    def stat(path, **kwargs):
        value = original(path, **kwargs)
        return SimpleNamespace(st_mode=value.st_mode, st_size=31 * 1024 * 1024) if path == unsafe else value
    monkeypatch.setattr(Path, "stat", stat)
    with pytest.raises(ValueError, match="invalid report input"):
        copy_report_bundle(source, tmp_path / "copy")
    assert not (tmp_path / "copy").exists()


def test_http_checker_requires_its_own_process(monkeypatch):
    import sys
    monkeypatch.setitem(sys.modules, "app", SimpleNamespace())
    with pytest.raises(ValueError, match="fresh process"):
        check("abcdef012345", "other")
