"""Field identifier membership does not imply semantic approval."""
from copy import deepcopy
import pytest
from multi_agent_quality import (DETAIL_CITATION_POLICY, check_field_citations,
    check_claim_revision, writer_revision_brief, citation_audit_input)
from multi_agent_pipeline_v2 import check_draft

A = "arxiv-2211-17192v2-c00004"
B = "arxiv-2302-01318v1-c00016"

def sample(field="qualification", mention="c00016"):
    draft = {"schema_version": "sciassistant.claim-draft/v2", "direct_answer": "回答",
        "detail_citation_policy": DETAIL_CITATION_POLICY, "claims": [{"claim_id": "c1",
        "text": "作者解释草稿与目标协作。", "scope_note": "", "qualification": "",
        "section": "direct_conclusion", "claim_type": "technical", "evidence_ids": [A],
        field: "该说明参见 " + mention}]}
    evidence = {"evidence": [{"evidence_id": key, "review_status": "approved",
        "paper_id": key.split("-c")[0], "excerpt": "The target verifies the draft tokens.",
        "locator": {"page": page}, "coverage_scope": "selected_chunks"}
        for key, page in ((A, 3), (B, 5))]}
    return draft, evidence

@pytest.mark.parametrize("field", ["text", "scope_note", "qualification"])
@pytest.mark.parametrize("mention", [B, "c00016", "arxiv-9999-12345v1-c00999", "c00999"])
def test_other_or_unknown_packet_in_each_field_not_cited(field, mention):
    draft, evidence = sample(field, mention)
    before = deepcopy((draft, evidence))
    rows = check_field_citations(draft, evidence)
    assert len(rows) == 1 and rows[0]["field"] == field
    assert rows[0]["reason"] == "UNAPPROVED_CITATION"
    assert rows[0]["automatic_citation_repair"] is False
    assert rows[0] in check_draft(draft, evidence)
    assert (draft, evidence) == before

def test_legitimate_full_or_suffix_membership_is_not_semantic_verdict():
    draft, evidence = sample(mention=A + " / c00004")
    assert check_field_citations(draft, evidence) == []
    enriched = citation_audit_input(draft, evidence)
    assert enriched["claims"][0]["field_evidence_checks"] == []
    assert any("EACH factual clause" in q for q in enriched["claims"][0]["semantic_review_questions"])

def test_same_paper_different_page_is_not_automatically_added():
    draft, evidence = sample()
    evidence["evidence"][1]["paper_id"] = evidence["evidence"][0]["paper_id"]
    assert check_field_citations(draft, evidence)[0]["candidate_evidence_ids"] == [B]
    assert draft["claims"][0]["evidence_ids"] == [A]

def test_new_citation_must_be_approved_even_if_id_in_claim():
    draft, evidence = sample()
    draft["claims"][0]["evidence_ids"].append(B)
    evidence["evidence"][1]["review_status"] = "rejected"
    assert check_field_citations(draft, evidence)

def test_ambiguous_suffix_not_auto_resolved_to_wrong_source():
    draft, evidence = sample(mention="c00004")
    evidence["evidence"].append({**evidence["evidence"][1], "evidence_id": "arxiv-2302-01318v1-c00004"})
    assert check_field_citations(draft, evidence) == []  # membership only, no source inference
    draft["claims"][0]["evidence_ids"] = [B]
    assert check_field_citations(draft, evidence)

def test_detail_repair_focus_preserves_core_but_requires_reaudit():
    draft, evidence = sample()
    feedback = {"code_issues": check_field_citations(draft, evidence), "model_audit": {}}
    brief = writer_revision_brief(draft, feedback, evidence)
    assert brief["targets"][0]["fields"][0]["field"] == "qualification"
    assert brief["targets"][0]["approved_candidate_sources"][0]["evidence_id"] == B
    assert brief["automatic_citation_repair"] is False
    assert check_claim_revision(draft, draft, feedback)["code_issues"]
    revised = deepcopy(draft)
    revised["claims"][0]["qualification"] = "仅描述已引用原文中的目标与草稿。"
    assert check_claim_revision(draft, revised, feedback)["code_issues"] == []
    assert check_field_citations(revised, evidence) == []

def test_rejected_model_body_cannot_be_rescued_by_detail_only_edit():
    draft, evidence = sample()
    feedback = {"code_issues": check_field_citations(draft, evidence), "model_audit": {
        "claim_results": [{"claim_id": "c1", "decision": "rejected", "reason_code": "UNSUPPORTED_CLAIM"}]}}
    revised = deepcopy(draft)
    revised["claims"][0]["qualification"] = "仅描述已引用片段。"
    assert check_claim_revision(draft, revised, feedback)["code_issues"]

def test_historical_policy_not_silently_reinterpreted():
    draft, evidence = sample()
    del draft["detail_citation_policy"]
    assert not any(r.get("policy") == DETAIL_CITATION_POLICY for r in check_draft(draft, evidence))

def test_actual_citation_repair_is_writer_action_not_validator_action():
    draft, evidence = sample()
    draft["claims"][0]["evidence_ids"].append(B)
    assert check_field_citations(draft, evidence) == []  # semantic audit still mandatory

def test_prose_like_chunk_substring_not_mistaken_as_identifier():
    draft, evidence = sample(mention="abc00016suffix")
    assert check_field_citations(draft, evidence) == []

@pytest.mark.parametrize("claim_type", ["technical", "comparative", "limitation"])
def test_non_quantitative_labels_do_not_hide_numeric_detail(claim_type):
    from multi_agent_quality import FIELD_QUANTITY_POLICY, QUANTITY_FEEDBACK_POLICY
    draft, evidence = sample(mention="原文")
    draft.update(field_quantity_policy=FIELD_QUANTITY_POLICY, quantity_feedback_policy=QUANTITY_FEEDBACK_POLICY)
    draft["claims"][0].update(claim_type=claim_type, qualification="使用 60,000 images，报告95%。")
    evidence["evidence"][1]["excerpt"] = "60 000 images achieved 95% accuracy."
    issues = [r for r in check_draft(draft, evidence) if r["reason"] == "UNSUPPORTED_NUMBER"]
    assert len(issues) == 1 and issues[0]["field_errors"][0]["field"] == "qualification"
    assert all(q["candidate_evidence_ids"] == [B] for q in issues[0]["field_errors"][0]["unsupported_quantities"])
    draft["claims"][0]["evidence_ids"].append(B)
    assert not any(r["reason"] == "UNSUPPORTED_NUMBER" for r in check_draft(draft, evidence))

@pytest.mark.parametrize("text", ["12000 samples", "12 000 samples", "12,000 images", "12000张"])
def test_explicit_item_count_normalizes_grouping(text):
    from decimal import Decimal
    from multi_agent_pipeline_v2 import _reported_item_counts
    assert _reported_item_counts(text) == {(Decimal(12000), "item_count")}

@pytest.mark.parametrize("text", ["256x256", "256×256 pixels", "p2/c00016", "20% images", "x1 samples"])
def test_dimensions_percentages_identifiers_not_item_counts(text):
    from multi_agent_pipeline_v2 import _reported_item_counts
    assert _reported_item_counts(text) == set()

def test_count_feedback_never_derives_complement_or_approves_metric():
    from multi_agent_pipeline_v2 import quantity_feedback
    draft, evidence = sample(mention="原文")
    draft["claims"][0]["qualification"] = "剩余80 samples"
    evidence["evidence"][0]["excerpt"] = "20 samples used for adaptation out of 100 samples."
    row = quantity_feedback(draft["claims"][0], {r["evidence_id"]: r for r in evidence["evidence"]}, include_counts=True)
    assert row and row["automatic_citation_repair"] is False
    assert row["field_errors"][0]["unsupported_quantities"][0]["value"] == "80"

def test_chinese_adjacent_identifier_is_still_an_explicit_reference():
    draft, evidence = sample(mention="原文")
    draft["claims"][0]["qualification"] = "参见c00016的说明"
    assert check_field_citations(draft, evidence)[0]["mentioned_evidence_id"] == "c00016"

def test_chinese_adjacent_full_identifier_is_not_ignored():
    draft, evidence = sample(mention="原文")
    draft["claims"][0]["qualification"] = "依据" + B + "所述"
    assert check_field_citations(draft, evidence)[0]["mentioned_evidence_id"] == B

def test_dimensions_followed_by_images_are_not_count_of_images():
    from multi_agent_pipeline_v2 import _reported_item_counts
    assert _reported_item_counts("256×256 images") == set()

def test_refuting_user_percentage_not_silently_treated_as_new_measurement():
    from multi_agent_quality import FIELD_QUANTITY_POLICY, QUANTITY_FEEDBACK_POLICY
    draft, evidence = sample(mention="原文")
    draft.update(field_quantity_policy=FIELD_QUANTITY_POLICY, quantity_feedback_policy=QUANTITY_FEEDBACK_POLICY)
    draft["claims"][0].update(claim_type="comparative", text="不能把不同实验写成泛化损失10%。")
    assert not any(r["reason"] == "UNSUPPORTED_NUMBER" for r in check_draft(draft, evidence))
    # This is not automatic scientific approval: quantitative reported claims
    # still undergo existing percentage checks and every field semantic audit.
    draft["claims"][0].update(claim_type="quantitative", text="作者报告10%。")
    assert any(r["reason"] == "UNSUPPORTED_NUMBER" for r in check_draft(draft, evidence))
