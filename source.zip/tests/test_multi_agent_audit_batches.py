"""Source partitioning cannot publish partial JSON or replace global review."""
from copy import deepcopy
import json
import time

import pytest

from multi_agent_agents import ArtifactDirectory
from multi_agent_audit_batches import (AUDIT_BATCH_POLICY, MAX_AUDIT_CLAIMS,
    GLOBAL_REVIEW_SCHEMA, source_batches, required_audit_calls, merge_source_audits,
    global_review_input)
from multi_agent_handoffs import AUDIT_JOB_POLICY
from multi_agent_pipeline_v2 import LiteraturePipelineV2, DeterministicLiteratureExecutor, PipelineExecutionError
from multi_agent_publication import PUBLICATION_POLICY, AUDIT_MATERIAL_POLICY, check_review, review_request
from multi_agent_quality import check_audit, publication_rejections
from multi_agent_workflow import WorkflowStore
from test_multi_agent_report_fields import draft as base_draft, evidence, audit as base_audit
from tools.multi_agent_cli import _mock_agents, _mock_search


def data(count=33):
    draft = base_draft()
    claim = {**draft['claims'][0], 'scope_note':'仅该设置。', 'qualification':'选定实验条件。',
        'requirement_ids':['r1']}
    draft.update(audit_delivery_policy=AUDIT_BATCH_POLICY, publication_review_policy=PUBLICATION_POLICY,
        audit_material_policy=AUDIT_MATERIAL_POLICY, audit_job_policy=AUDIT_JOB_POLICY)
    draft['claims'] = [{**deepcopy(claim), 'claim_id':f'c{i+1}', 'requirement_ids':['r1' if i%2==0 else 'r2']}
        for i in range(count)]
    ledger = {'requirements':[{'requirement_id':key,'question_quote':quote,'answer_kind':'mechanism'}
        for key,quote in [('r1','解释机制。'),('r2','比较条件。')]]}
    return draft,evidence(),ledger


def good_audit(draft):
    result = base_audit(draft)
    result['schema_version']='sciassistant.citation-audit/v7'
    for row in result['claim_results']:
        for field in row['field_results'].values(): field['absence_checks']=[]
    return result


def report_for(packet):
    request = packet['report_review_request']
    return {'schema_version':'sciassistant.report-review/v1',
        'requirements':[{'requirement_id':r['requirement_id'],
            'status':'answered' if r['eligible_claim_ids'] else 'unanswered',
            'claim_ids':r['eligible_claim_ids'], 'reason':'受控流程元数据，不证明科学结论。'} for r in request['requirements']],
        'consistency':{'reviewed_claim_ids':request['claim_ids'],'conflicts':[]}}


@pytest.mark.parametrize('count',[1,12,13,24,25,33,80])
def test_partition_preserves_every_field_and_dependency_without_a_length_target(count):
    draft,_,_=data(count)
    if count>12: draft['claims'][0]['depends_on_claim_ids']=['c13']
    before=deepcopy(draft)
    parts=source_batches(draft)
    assert [c for p in parts for c in p['draft']['claims']]==draft['claims']
    assert all(1<=len(p['claim_ids'])<=12 for p in parts)
    assert draft==before and all('publication_review_policy' not in p['draft'] for p in parts)
    assert required_audit_calls(draft)==(1 if count<=12 else len(parts)+1)


@pytest.mark.parametrize('fault',['truncated','missing','foreign_id','wrong_source','bad_field'])
def test_bad_source_batch_isolated_without_erasing_other_batches(fault):
    draft,sources,_=data()
    records=[]
    for i,part in enumerate(source_batches(draft)):
        audit=check_audit(good_audit(part['draft']),part['draft'],sources)
        if i==1:
            if fault=='truncated': audit={'contract_errors':['MODEL_OUTPUT_TRUNCATED']}
            elif fault=='missing': audit['claim_results'].pop()
            elif fault=='foreign_id': audit['claim_results'][0]['claim_id']='c1'
            elif fault=='wrong_source': audit['claim_results'][0]['evidence_ids']=['unknown']
            else: audit['claim_results'][0]['field_results']={}
        records.append({**part,'audit':audit})
    result=merge_source_audits(draft,sources,records)
    assert not result['contract_errors']
    assert set(result['source_unreviewed_claim_ids'])=={f'c{i}' for i in range(13,25)}
    assert set(publication_rejections(result,draft))==set(result['source_unreviewed_claim_ids'])
    assert len([r for r in result['claim_results'] if r['decision']=='approved'])==21


def test_invalid_witness_cannot_become_eligible_global_answer_candidate():
    draft,sources,ledger=data()
    records=[]
    for part in source_batches(draft):
        audit=good_audit(part['draft'])
        if part['batch_id']=='source-001': audit['claim_results'][0]['source_witnesses'][0]['quote']='This is an invented source quotation.'
        records.append({**part,'audit':audit})
    combined=merge_source_audits(draft,sources,records)
    assert 'c1' in publication_rejections(combined,draft)
    packet=global_review_input(ledger,draft,sources,combined)
    assert all('c1' not in r['eligible_claim_ids'] for r in packet['report_review_request']['requirements'])
    assert len(packet['claims'])==33 and len(packet['approved_source_catalog'])==1


def test_binding_feedback_identifies_exact_wrong_requirement_ids_without_rebinding():
    draft,_,ledger=data(2)
    packet={'report_review_request':review_request(ledger,draft)}
    review=report_for(packet)
    review['requirements'][0]['claim_ids']=['c1','c2']
    before=deepcopy((draft,review))
    checked=check_review(review,ledger,draft)
    issue=next(r for r in checked['diagnostics'] if r['reason']=='REPORT_REVIEW_BINDING_INVALID')
    assert issue['requirement_id']=='r1' and issue['invalid_claim_ids']==['c2'] and issue['eligible_claim_ids']==['c1']
    assert 'r1' not in checked['rows'] and 'r2' in checked['rows'] and (draft,review)==before


def seed_flow(tmp_path,count=33,limit=20,handler=None):
    draft,sources,ledger=data(count)
    artifacts=ArtifactDirectory(tmp_path/'artifacts')
    store=WorkflowStore(tmp_path/'workflow.sqlite3')
    agents=_mock_agents()
    phases=[]
    def auditor(packet):
        global_packet=next((i['payload'] for i in packet['inputs'] if i['payload'].get('schema_version')==GLOBAL_REVIEW_SCHEMA),None)
        if global_packet:
            phases.append(('global',len(global_packet['claims'])))
            result={'schema_version':'sciassistant.citation-audit/v7','status':'passed',
                'rejected_claim_ids':[],'issues':[],'claim_results':[], 'report_review':report_for(global_packet)}
            return handler('global',packet,result) if handler else {'output':result}
        audit_input=next(i['payload'] for i in packet['inputs'] if i['payload'].get('schema_version')=='sciassistant.citation-audit-input/v1')
        claims=[{**j['claim'],**j['claim']['report_fields']} for j in audit_input['audit_jobs']]
        phases.append(('source',len(claims)))
        result=good_audit({'claims':claims})
        if audit_input.get('report_review_request'): result['report_review']=report_for(audit_input)
        return handler('source',packet,result) if handler else {'output':result}
    agents.citation_auditor.handler=auditor
    flow=LiteraturePipelineV2(store,artifacts,agents,DeterministicLiteratureExecutor(_mock_search),
        event_path=tmp_path/'events.jsonl',report_profile='enhanced')
    refs={k:artifacts.put(k,v)['artifact_id'] for k,v in [('draft',draft),('approved',sources)]}
    flow._skill_ledger=ledger;flow._skill_load_records=[];flow._run_refs=refs;flow._revision_active=False
    flow.deadline=time.monotonic()+720
    store.create_run('audit-batches','owner',report_profile='enhanced',max_model_calls=limit)
    return flow,refs,draft,sources,ledger,phases


@pytest.mark.parametrize('count,expected',[(12,[('source',12)]),(13,[('source',12),('source',1),('global',13)]),
    (33,[('source',12),('source',12),('source',9),('global',33)])])
def test_formal_bounded_call_path_slices_sources_and_reviews_whole_report(tmp_path,count,expected):
    flow,refs,draft,sources,ledger,phases=seed_flow(tmp_path,count=count)
    _,audit=flow._audit('audit-batches','test',[refs['draft'],refs['approved']],draft,refs)
    assert phases==expected and not audit['contract_errors']
    assert not audit['report_review_validation']['errors'] and not publication_rejections(audit,draft)
    assert flow.store.get_run('audit-batches')['model_calls_used']==len(expected)
    assert flow.artifacts.get(refs['draft'])==draft


def test_one_truncated_batch_never_publishes_partial_json_and_keeps_other_valid_batches(tmp_path):
    def fail_first(_phase,packet,result):
        if _phase=='source' and result['claim_results'][0]['claim_id']=='c1':
            return {'status':'failed','error_code':'MODEL_OUTPUT_TRUNCATED'}
        return {'output':result}
    flow,refs,draft,_,_,phases=seed_flow(tmp_path,handler=fail_first)
    _,audit=flow._audit('audit-batches','test',[refs['draft'],refs['approved']],draft,refs)
    assert phases==[('source',12),('source',12),('source',12),('source',9),('global',33)]
    assert set(publication_rejections(audit,draft))=={f'c{i}' for i in range(1,13)}
    assert len([r for r in audit['claim_results'] if r['decision']=='approved'])==21
    assert flow.audit_protocol_retry_used and flow.store.get_run('audit-batches')['model_calls_used']==5


@pytest.mark.parametrize('limit,approved_count',[(1,0),(2,12),(3,24)])
def test_budget_reserves_global_review_and_marks_unreviewed_without_auto_approval(tmp_path,limit,approved_count):
    flow,refs,draft,_,_,phases=seed_flow(tmp_path,limit=limit)
    _,audit=flow._audit('audit-batches','test',[refs['draft'],refs['approved']],draft,refs)
    assert phases[-1]==('global',33) and flow.store.get_run('audit-batches')['model_calls_used']==limit
    assert len([r for r in audit['claim_results'] if r['decision']=='approved'])==approved_count
    assert len(audit['source_unreviewed_claim_ids'])==33-approved_count


def test_global_wrong_binding_gets_exact_feedback_once_not_source_reaudit(tmp_path):
    seen=[]
    def wrong_then_correct(phase,packet,result):
        if phase=='global':
            seen.append(1)
            if len(seen)==1: result['report_review']['requirements'][0]['claim_ids'].append('c2')
            else:
                feedback=next(i['payload'] for i in packet['inputs'] if i['payload'].get('report_review_diagnostics'))
                issue=next(r for r in feedback['report_review_diagnostics'] if r['reason']=='REPORT_REVIEW_BINDING_INVALID')
                assert issue['invalid_claim_ids']==['c2'] and 'c2' not in issue['eligible_claim_ids']
        return {'output':result}
    flow,refs,draft,_,_,phases=seed_flow(tmp_path,handler=wrong_then_correct)
    _,audit=flow._audit('audit-batches','test',[refs['draft'],refs['approved']],draft,refs)
    assert len(seen)==2 and len(phases)==5 and not audit['report_review_validation']['errors']
    assert not publication_rejections(audit,draft)


def test_global_result_cannot_add_source_approvals(tmp_path):
    def forbidden(phase,packet,result):
        if phase=='global': result['claim_results']=[{'claim_id':'c1','decision':'approved'}]
        return {'output':result}
    flow,refs,draft,_,_,phases=seed_flow(tmp_path,handler=forbidden)
    _,audit=flow._audit('audit-batches','test',[refs['draft'],refs['approved']],draft,refs)
    assert 'REPORT_REVIEW_PHASE_SOURCE_VERDICTS_FORBIDDEN' in audit['report_review_validation']['errors']
    assert audit['report_review'] is None and len(audit['claim_results'])==33


@pytest.mark.parametrize('error',['MODEL_HTTP_401','MODEL_HTTP_402','MODEL_HTTP_403','USER_CANCELLED'])
def test_global_auth_payment_cancel_errors_are_not_hidden_or_retried(tmp_path,error):
    def fatal(phase,packet,result):
        return {'status':'failed','error_code':error} if phase=='global' else {'output':result}
    flow,refs,draft,_,_,phases=seed_flow(tmp_path,handler=fatal)
    with pytest.raises(PipelineExecutionError) as exc:
        flow._audit('audit-batches','test',[refs['draft'],refs['approved']],draft,refs)
    assert exc.value.code==error and phases[-1]==('global',33) and len(phases)==4


def test_complete_workflow_publishes_33_without_a_count_target_or_extra_retrieval(tmp_path):
    from test_multi_agent_publication import flow_fixture
    flow,workers,artifacts=flow_fixture(tmp_path)
    original=workers.writer.handler
    def long_writer(packet):
        result=original(packet)
        base=result['output']['claims']
        result['output']['claims']=[{**deepcopy(base[i%len(base)]),'claim_id':f'c{i+1}'} for i in range(33)]
        return result
    workers.writer.handler=long_writer
    result=flow.run('long-source-audit','owner','解释机制。')
    assert result['run']['status']=='partial' and result['run']['model_calls_used']==8
    final=artifacts.get(result['final_artifact_id'])
    audit=artifacts.get(final['artifact_refs']['audit'])
    assert len(audit['claim_results'])==33 and not audit['contract_errors']
    assert not publication_rejections(audit,artifacts.get(final['artifact_refs']['draft']))
    plan=artifacts.get(final['artifact_refs']['audit_batches'])
    assert [len(p['claim_ids']) for p in plan['batches']]==[12,12,9]
    assert plan['whole_report_review']['status']=='completed'


def test_writer_revision_requires_full_new_source_audit_budget(tmp_path):
    from test_multi_agent_publication import flow_fixture
    flow,workers,artifacts=flow_fixture(tmp_path)
    writer=workers.writer.handler
    auditor=workers.citation_auditor.handler
    writes=[]
    def long_writer(packet):
        writes.append(1);result=writer(packet);base=result['output']['claims']
        result['output']['claims']=[{**deepcopy(base[i%len(base)]),'claim_id':f'c{i+1}'} for i in range(33)]
        return result
    def uncovered(packet):
        result=auditor(packet)
        if any(i['payload'].get('schema_version')==GLOBAL_REVIEW_SCHEMA for i in packet['inputs']):
            for row in result['output']['report_review']['requirements']:
                row.update(status='unanswered',claim_ids=[],reason='本次正文没有实际解释机制。')
        return result
    workers.writer.handler=long_writer;workers.citation_auditor.handler=uncovered
    result=flow.run('revision-budget','owner','解释机制。')
    assert len(writes)==1 and result['run']['model_calls_used']==8
    events=[json.loads(l) for l in (tmp_path/'events.jsonl').read_text(encoding='utf-8').splitlines()]
    skipped=next(e for e in events if e['event']=='writer_revision_skipped')
    assert skipped['required_model_calls']==6 and skipped['remaining_model_calls']==2


def test_26_claims_keep_one_real_global_json_correction_with_five_calls(tmp_path):
    global_calls=[]
    def invalid_first_global(phase,packet,result):
        if phase=='global':
            global_calls.append(1)
            if len(global_calls)==1:
                return {'status':'failed','error_code':'MODEL_JSON_INVALID'}
        return {'output':result}
    flow,refs,draft,_,_,phases=seed_flow(tmp_path,count=26,limit=5,handler=invalid_first_global)
    _,audit=flow._audit('audit-batches','全稿审查',[refs['draft'],refs['approved']],draft,refs)
    assert phases==[('source',12),('source',12),('source',2),('global',26),('global',26)]
    assert flow.store.get_run('audit-batches')['model_calls_used']==5
    assert flow.audit_protocol_retry_used and not audit['report_review_validation']['errors']
    assert not audit['source_unreviewed_claim_ids'] and not publication_rejections(audit,draft)


def test_whole_report_phase_can_find_a_conflict_between_first_and_last_batches(tmp_path):
    def conflict(phase,packet,result):
        if phase=='global':
            result['report_review']['consistency']['conflicts']=[{'claim_ids':['c1','c33'],
                'detail':'受控反例：首批与末批断言存在未解决冲突。'}]
        return {'output':result}
    flow,refs,draft,_,_,_=seed_flow(tmp_path,handler=conflict)
    _,audit=flow._audit('audit-batches','test',[refs['draft'],refs['approved']],draft,refs)
    assert audit['report_review_validation']['consistency_verified']
    assert audit['report_review_validation']['conflicts'][0]['claim_ids']==['c1','c33']


def test_batched_full_workflow_keeps_independent_body_and_does_not_send_transport_error_to_writer(tmp_path):
    from test_multi_agent_publication import flow_fixture
    flow,workers,artifacts=flow_fixture(tmp_path)
    writer=workers.writer.handler;auditor=workers.citation_auditor.handler
    writes=[]
    def long_writer(packet):
        writes.append(1);result=writer(packet);base=result['output']['claims']
        result['output']['claims']=[{**deepcopy(base[i%len(base)]),'claim_id':f'c{i+1}'} for i in range(33)]
        return result
    def fail_first(packet):
        inputs=[i['payload'] for i in packet['inputs']]
        if not any(p.get('schema_version')==GLOBAL_REVIEW_SCHEMA for p in inputs):
            d=next(p for p in inputs if p.get('schema_version')=='sciassistant.claim-draft/v4')
            if d['claims'][0]['claim_id'].endswith('-c1'):
                return {'status':'failed','error_code':'MODEL_OUTPUT_TRUNCATED'}
        return auditor(packet)
    workers.writer.handler=long_writer;workers.citation_auditor.handler=fail_first
    result=flow.run('transport-only','owner','解释机制。')
    assert result['run']['status']=='needs_review' and result['run']['failure_code'] is None
    assert result['run']['model_calls_used']==9 and len(writes)==1
    final=artifacts.get(result['final_artifact_id'])
    draft=artifacts.get(final['artifact_refs']['draft']);audit=artifacts.get(final['artifact_refs']['audit'])
    assert len(publication_rejections(audit,draft))==12
    assert len(draft['claims'])-len(publication_rejections(audit,draft))==21


def test_audit_batch_export_preserves_manifest_and_does_not_change_published_map(tmp_path):
    from multi_agent_report import export_run_report
    from test_multi_agent_publication import flow_fixture
    flow,workers,artifacts=flow_fixture(tmp_path)
    writer=workers.writer.handler
    def many(packet):
        result=writer(packet);base=result['output']['claims']
        result['output']['claims']=[{**deepcopy(base[i%len(base)]),'claim_id':f'c{i+1}'} for i in range(13)]
        return result
    workers.writer.handler=many
    result=flow.run('batch-export','owner','解释机制。')
    (tmp_path/'manifest.json').write_text(json.dumps({'final_artifact_id':result['final_artifact_id']}),encoding='utf-8')
    export_run_report(tmp_path)
    batch=json.loads((tmp_path/'audit_batches.json').read_text(encoding='utf-8'))
    assert [len(r['claim_ids']) for r in batch['batches']]==[12,1]
    assert len(json.loads((tmp_path/'claim_evidence_map.json').read_text(encoding='utf-8')))==13


@pytest.mark.parametrize('truncate_first',[False,True])
def test_real_model_adapter_projects_each_source_batch_and_never_accepts_length_reply(tmp_path,monkeypatch,truncate_first):
    from multi_agent_live import LiveModelClient,COMMON_PROMPT,whole_report_review_prompt
    from test_multi_agent_live import Response,config
    monkeypatch.setenv('MODEL_REQUEST_URL','https://example.test/v1/chat/completions')
    flow,refs,draft,_,_,_=seed_flow(tmp_path)
    observed=[]
    class FinishedResponse(Response):
        def __init__(self,output,finish):super().__init__(output);self.finish=finish
        def iter_content(self,**kwargs):
            yield json.dumps({'choices':[{'finish_reason':self.finish,'message':{'content':json.dumps(self.output)}}]}).encode()
    def post(_url,**kwargs):
        packet=json.loads(kwargs['json']['messages'][1]['content'])
        assert kwargs['json']['max_tokens']==8192
        global_packet=next((i['payload'] for i in packet['inputs'] if i['payload'].get('schema_version')==GLOBAL_REVIEW_SCHEMA),None)
        if global_packet:
            assert kwargs['json']['messages'][0]['content']==COMMON_PROMPT+whole_report_review_prompt('arxiv')
            observed.append(('global',len(global_packet['claims'])))
            output={'schema_version':'sciassistant.citation-audit/v7','status':'passed',
                'claim_results':[],'issues':[],'rejected_claim_ids':[],'report_review':report_for(global_packet)}
            return FinishedResponse({'output':output},'stop')
        material=next(i['payload'] for i in packet['inputs'] if i['payload'].get('schema_version')=='sciassistant.citation-audit-input/v1')
        assert 'claims' not in material and 'source_witness_options' not in material
        claims=[{**j['claim'],**j['claim']['report_fields']} for j in material['audit_jobs']]
        observed.append(('source',len(claims)))
        finish='length' if truncate_first and claims[0]['claim_id']=='c1' else 'stop'
        return FinishedResponse({'output':good_audit({'claims':claims})},finish)
    client=LiveModelClient(config(),post=post)
    flow.agents.citation_auditor.handler=lambda packet:client.call('citation_auditor',packet)
    _,audit=flow._audit('audit-batches','test',[refs['draft'],refs['approved']],draft,refs)
    assert observed[-1]==('global',33) and all(n<=12 for phase,n in observed if phase=='source')
    assert not audit['contract_errors'] and not audit['report_review_validation']['errors']
    rejected=publication_rejections(audit,draft)
    assert rejected==({f'c{i}' for i in range(1,13)} if truncate_first else set())
    assert flow.store.get_run('audit-batches')['model_calls_used']==(5 if truncate_first else 4)
