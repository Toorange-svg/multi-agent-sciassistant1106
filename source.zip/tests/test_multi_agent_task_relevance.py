"""Task-specific evidence, metadata and real follow-up Context boundaries."""
from copy import deepcopy
import json
from pathlib import Path
import time
from types import SimpleNamespace

import pytest

from multi_agent_pipeline_v2 import check_review, check_draft, recover_review_subset, ReviewContractError
from multi_agent_quality import answer_requirements, publication_window_decision, evidence_flow_diagnostics
from multi_agent_live import LiveArxivRagExecutor, LiveModelClient, normalize_live_result
from test_multi_agent_protocol_recovery import packet_set, reviewer_data
from test_multi_agent_pipeline_v2 import agents, pipeline
from test_multi_agent_live import config, create_pdf, request


def classified_review(relevance="direct_task_evidence"):
    data = reviewer_data()
    data["schema_version"] = "sciassistant.evidence-review/v4"
    data["decisions"][0]["task_relevance"] = relevance
    return data


@pytest.mark.parametrize("classification", ["direct_task_evidence", "adjacent_context"])
def test_classification_survives_normalization_and_strict_review(classification):
    data = classified_review(classification)
    output = normalize_live_result("reviewer", {"output": data})["output"]
    result = check_review(output, {"evidence": packet_set()["evidence"][:1]}, {"g1"})
    assert result["decisions"][0]["task_relevance"] == classification


@pytest.mark.parametrize("classification", [None, "generic", "unrelated"])
def test_unknown_or_unrelated_approval_cannot_enter_writer(classification):
    with pytest.raises(ReviewContractError):
        check_review(classified_review(classification), {"evidence": packet_set()["evidence"][:1]}, {"g1"})


def test_old_review_has_no_fabricated_task_classification():
    data = reviewer_data()
    output = normalize_live_result("reviewer", {"output": data})["output"]
    result = check_review(output, {"evidence": packet_set()["evidence"][:1]}, {"g1"})
    assert "task_relevance" not in result["decisions"][0]


def test_adjacent_background_cannot_make_direct_coverage_sufficient():
    data = classified_review("adjacent_context")
    data.update(coverage_status="sufficient", coverage=[{"group_id": "g1", "status": "direct", "evidence_ids": ["e1"]}])
    result = check_review(data, {"evidence": packet_set()["evidence"][:1]}, {"g1"})
    assert result["coverage"][0]["status"] == "indirect" and result["coverage_status"] == "partial"


def test_recovery_preserves_direct_item_but_quarantines_unrelated_approval():
    data = classified_review()
    data["allowed_evidence_ids"].append("e2")
    data["decisions"].append({**data["decisions"][0], "evidence_id": "e2", "task_relevance": "unrelated"})
    checked, report = recover_review_subset(data, packet_set(), {"g1"})
    assert checked["allowed_evidence_ids"] == ["e1"]
    assert report["quarantined_evidence_ids"] == ["e2"]
    assert checked["decisions"][0]["task_relevance"] == "direct_task_evidence"


@pytest.mark.parametrize("claim_type", ["quantitative", "comparative"])
def test_adjacent_task_measurements_cannot_become_target_results(claim_type):
    evidence = {"evidence": [{**packet_set()["evidence"][0], "task_relevance": "adjacent_context", "excerpt": "accuracy 90%"}]}
    draft = {"direct_answer": "Answer", "claims": [{"claim_id": "c1", "text": "检测准确率90%",
                "claim_type": claim_type, "evidence_ids": ["e1"]}]}
    assert {r["reason"] for r in check_draft(draft, evidence)} == {"ADJACENT_EVIDENCE_NOT_TASK_RESULT"}
    evidence["evidence"][0]["task_relevance"] = "direct_task_evidence"
    assert check_draft(draft, evidence) == []


def test_adjacent_mechanism_background_and_limitation_are_still_allowed():
    evidence = {"evidence": [{**packet_set()["evidence"][0], "task_relevance": "adjacent_context"}]}
    for kind in ("technical", "limitation"):
        assert not check_draft({"direct_answer": "A", "claims": [{"claim_id": "c1", "text": "背景机制",
            "claim_type": kind, "evidence_ids": ["e1"]}]}, evidence)


@pytest.mark.parametrize("question,basis", [("2024～2026年的论文", "published_at"),
                                           ("2024 至 2026 年更新的论文", "updated_at")])
def test_explicit_year_range_uses_real_requested_date_basis(question, basis):
    window = answer_requirements(question)["publication_window"]
    assert window["basis"] == basis
    assert publication_window_decision({basis: "2025-06-12T10:00:00Z"}, window) == "in_scope"
    assert publication_window_decision({basis: "2023-12-31T10:00:00Z"}, window) == "outside_requested_years"
    assert publication_window_decision({"paper_id": "2506.00001v1", "year": 2025}, window) == "date_unknown"
    assert publication_window_decision({basis: "2025-99-88"}, window) == "date_invalid"


@pytest.mark.parametrize("question", ["最近重要论文", "2026年的模型", "参数规模2024到2026是否可能", "没有日期要求"])
def test_no_unrequested_time_filter(question):
    assert answer_requirements(question)["publication_window"] is None


def test_search_records_exclusions_without_pdf_or_model_calls(tmp_path):
    papers = [{"paper_id": "2401.00001v1", "title": "A", "published_at": "2024-01-02T00:00:00Z"},
              {"paper_id": "2301.00001v1", "title": "B", "published_at": "2023-01-02T00:00:00Z"},
              {"paper_id": "2501.00001v1", "title": "C", "year": 2025}]
    executor = LiveArxivRagExecutor(tmp_path / "run", tmp_path / "storage", rag_mode="lexical",
                                    search=lambda *_a, **_k: {"status": "ok", "papers": papers})
    executor.configure_source_clues(answer_requirements("2024～2026年论文"))
    executor.retrieval_deadline = time.monotonic() + 30
    result = executor._search("attention", 5)
    assert len(result["papers"]) == 1 and executor.pdf_reads == 0
    record = json.loads((tmp_path / "run/tools/search_catalog.jsonl").read_text())
    assert {r["reason_code"] for r in record["date_exclusions"]} == {"date_unknown", "outside_requested_years"}
    assert record["papers"][0]["published_at"].startswith("2024")


def test_publication_metadata_survives_pdf_index_and_cache(tmp_path):
    search = lambda *_a, **_k: {"status": "ok", "papers": [{"paper_id": "2309.06180", "title": "PagedAttention",
        "abstract": "memory management", "published_at": "2023-09-12T00:00:00Z", "updated_at": "2024-01-01T00:00:00Z"}]}
    first = LiveArxivRagExecutor(tmp_path / "first", tmp_path / "storage", rag_mode="lexical", search=search,
                                 download=lambda _id, folder: create_pdf(folder))
    result = first.execute(request(), group_ids={"g1"}, deadline=time.monotonic() + 30)
    assert result["evidence"][0]["published_at"] == "2023-09-12T00:00:00Z"
    second = LiveArxivRagExecutor(tmp_path / "second", tmp_path / "storage", rag_mode="lexical", search=search,
                                  download=lambda *_: pytest.fail("cached document must not download"))
    cached = second.execute(request(), group_ids={"g1"}, deadline=time.monotonic() + 30)
    assert cached["evidence"][0]["updated_at"] == "2024-01-01T00:00:00Z"


def test_bad_top_level_followup_cannot_discard_independent_old_approval(tmp_path):
    configured, _ = agents()
    flow, store = pipeline(tmp_path, configured)
    store.create_run("retention", "owner")
    prior = check_review(reviewer_data(), {"evidence": packet_set()["evidence"][:1]}, {"g1"})
    invalid = {**classified_review(), "coverage": "invalid"}
    retained = flow._validated_followup_review("retention", invalid, prior, packet_set(), {"g1"}, None, {})
    assert retained["allowed_evidence_ids"] == ["e1"] and retained["coverage_status"] == "needs_review"


def test_approved_paper_counts_merge_versions_not_evidence_packets():
    evidence = {"evidence": [{"evidence_id": "e1", "paper_id": "2309.06180v1"},
                             {"evidence_id": "e2", "paper_id": "2309.06180v2"}]}
    counts = evidence_flow_diagnostics({}, evidence, {"allowed_evidence_ids": ["e1", "e2"]}, {}, {})["counts"]
    assert counts["presented"] == 2 and counts["approved_papers"] == 1


def test_context_export_is_published_only_exclusive_and_read_only(tmp_path):
    from tools.multi_agent_cli import main, context_command
    assert main(["run", "--mode", "mock", "--query", "首问", "--run-id", "context-test",
                 "--output-root", str(tmp_path / "runs")]) == 0
    directory = tmp_path / "runs/context-test"
    before = {p: p.read_bytes() for p in directory.rglob("*.json")}
    destination = tmp_path / "context.json"
    args = SimpleNamespace(run_dir=str(directory), output=str(destination))
    assert context_command(args) == 0
    context = json.loads(destination.read_text(encoding="utf-8"))
    assert context["previous_question"] == "首问" and context["paper_ids"] == ["0000.00000"]
    assert context["evidence_policy"] == "context_only_retrieve_again"
    assert answer_requirements("追问", context)["context_sha256"]
    assert before == {p: p.read_bytes() for p in directory.rglob("*.json")}
    with pytest.raises(FileExistsError):
        context_command(args)
    with pytest.raises(ValueError):
        context_command(SimpleNamespace(run_dir=str(directory), output=str(directory / "new.json")))


def test_json_diagnostics_record_positions_not_model_text(monkeypatch):
    monkeypatch.setenv("MODEL_REQUEST_URL", "https://example.test/v1/chat/completions")
    class Response:
        status_code = 200
        def iter_content(self, **_kwargs):
            yield json.dumps({"choices": [{"message": {"content": '{"canary-private":'}, "finish_reason": "length"}]}).encode()
        def raise_for_status(self):
            pass
        def close(self):
            pass
    result = LiveModelClient(config(), post=lambda *_a, **_k: Response()).call("planner", {"deadline_at": time.time() + 20, "inputs": []})
    assert result["error_code"] == "MODEL_OUTPUT_TRUNCATED"
    assert result["output"]["parse_error_type"] == "JSONDecodeError"
    assert isinstance(result["output"]["error_position"], int)
    assert "canary-private" not in json.dumps(result)


def test_context_export_rejects_run_with_all_claims_blocked(tmp_path):
    from tools.multi_agent_cli import main, context_command
    from multi_agent_agents import ArtifactDirectory
    main(["run", "--mode", "mock", "--query", "Q", "--run-id", "blocked", "--output-root", str(tmp_path / "runs")])
    directory = tmp_path / "runs/blocked"
    manifest = json.loads((directory / "manifest.json").read_text())
    store = ArtifactDirectory(directory / "artifacts")
    final = store.get(manifest["final_artifact_id"])
    final["artifact_refs"]["audit"] = store.put("bad-audit", {"schema_version": "sciassistant.citation-audit/v3",
        "status": "passed", "claim_results": [], "rejected_claim_ids": [], "issues": []})["artifact_id"]
    manifest["final_artifact_id"] = store.put("final-result", final)["artifact_id"]
    (directory / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    with pytest.raises(ValueError, match="no published claims"):
        context_command(SimpleNamespace(run_dir=str(directory), output=str(tmp_path / "context.json")))
    assert not (tmp_path / "context.json").exists()


def test_cli_and_web_ledger_preserve_relevance_and_dates(tmp_path, monkeypatch):
    from multi_agent_report import export_run_report
    import multi_agent_web as adapter
    configured, _ = agents()
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("0123456789ab", "owner", "Q")
    final = flow.artifacts.get(result["final_artifact_id"])
    refs = final["artifact_refs"]
    approved = flow.artifacts.get(refs["approved"])
    approved["evidence"][0].update(published_at="2024-01-01T00:00:00Z", updated_at="2025-02-01T00:00:00Z", task_relevance="direct_task_evidence")
    approved["evidence"][0].update(source_domain="测试领域", source_scope_policy="reviewer-v5-visible-domain/v1")
    approved["evidence"][0].update(reviewed_group_ids=["g1", "g2"], topic_association_policy="planned-topics-semantic-review/v1")
    approved["evidence"][0]["excerpt"] = "Original reviewed context. " * 180 + " COCO_AFTER_CHAR_4000"
    from multi_agent_evidence import source_attribution_hint
    approved["evidence"][0]["source_attribution"] = source_attribution_hint(approved["evidence"][0])
    refs["approved"] = flow.artifacts.put("approved-evidence", approved)["artifact_id"]
    final_id = flow.artifacts.put("final-result", final)["artifact_id"]
    (tmp_path / "manifest.json").write_text(json.dumps({"run_id": "0123456789ab", "final_artifact_id": final_id}), encoding="utf-8")
    export_run_report(tmp_path)
    ledger = json.loads((tmp_path / "evidence_ledger.json").read_text(encoding="utf-8"))
    monkeypatch.setattr(adapter, "run_directory", lambda _task: tmp_path)
    monkeypatch.setattr(adapter, "progress", lambda _task: {})
    web_ledger = adapter.report("0123456789ab")["references"]
    for field in ("published_at", "updated_at", "task_relevance", "excerpt", "source_domain", "source_scope_policy", "reviewed_group_ids", "topic_association_policy", "source_attribution"):
        assert ledger[0][field] == web_ledger[0][field] == approved["evidence"][0][field]
    assert "COCO_AFTER_CHAR_4000" in ledger[0]["excerpt"]
    assert ledger[0]["excerpt_truncated"] is web_ledger[0]["excerpt_truncated"] is False
