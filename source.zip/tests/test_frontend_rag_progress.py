"""Unified in-chat progress with DOM/polling substitutes, not a browser test."""
import json
from pathlib import Path
import shutil
import subprocess

import pytest

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "chatAi/multi_agent_rag.js").read_text("utf-8")
HTML = (ROOT / "chatAi/ai_chat.html").read_text("utf-8")
DOM = r'''
const vm=require('node:vm');
function el(tag, cls='') {
  const n={tag, className:cls, children:[],dataset:{},events:{},hidden:false,open:false,
    append(...items){for(const x of items){x.remove();this.children.push(x);x.parentElement=this;x.parentNode=this;}},
    remove(){if(this.parentElement){const p=this.parentElement;p.children=p.children.filter(x=>x!==this);}this.parentElement=null;this.parentNode=null;},
    addEventListener(k,f){this.events[k]=f;},setAttribute(k,v){this[k]=v;},
    querySelectorAll(s){const selectors=s.split(',');const out=[];const visit=x=>{for(const c of x.children){if(selectors.some(t=>c.className.split(' ').includes(t.slice(1))))out.push(c);visit(c);}};visit(this);return out;},
    querySelector(s){return this.querySelectorAll(s)[0]||null;}};
  n.classList={add(c){if(!n.className.split(' ').includes(c))n.className+=' '+c;}};
  Object.defineProperty(n,'innerHTML',{set(){throw Error('unsafe HTML');}});
  return n;
}
function placeholder(){const loading=el('div'),bubble=el('div'),stop=el('button','science-stop-btn');
  const label=el('span','science-status-label');label.textContent='正在思考…';
  const elapsed=el('span','science-elapsed');elapsed.dataset.started='123';
  bubble.append(el('i','fa-spinner'),label,elapsed,stop);loading.append(bubble);el('main').append(loading);
  return {loading,bubble,stop};}
const window={currentSessionId:'s1',userToken:'fixture',location:{search:''},addEventListener(){}};
const document={createElement:el,getElementById(){return null}};
const context={window,document,URLSearchParams,DOMException,setInterval(){}};
vm.runInNewContext(SOURCE,context);
'''


def run_node(body, extra=""):
    node = shutil.which("node")
    if not node:
        pytest.skip("Node required; this is not browser acceptance")
    script = "const SOURCE=" + json.dumps(SOURCE) + ";\n" + DOM + extra + body
    proc = subprocess.run([node, "-"], input=script, text=True, encoding="utf-8",
                          capture_output=True, timeout=10)
    assert proc.returncode == 0, proc.stderr
    return json.loads(proc.stdout)


@pytest.mark.parametrize("status,workflow,phase,title", [
    ("submitting", None, None, "正在提交科研问题"),
    ("queued", "retrieving", "pdf_index", "排队等待分析"),
    ("running", None, None, "正在初始化科研分析"),
    ("running", "created", None, "正在规划"),
    ("running", "retrieving", "pdf_download", "正在下载原文"),
    ("running", "retrieving", "pdf_parse", "正在解析原文"),
    ("running", "retrieving", "pdf_index", "正在建立检索索引"),
    ("running", "reviewing", "pdf_index", "正在审查证据"),
    ("running", "writing", "pdf_index", "正在撰写回答"),
    ("running", "auditing", "pdf_index", "正在审计引用"),
])
def test_one_progress_card_preserves_cancel_and_uses_correct_stage(status, workflow, phase, title):
    task = dict(processing_mode="multi_agent_rag", status=status, elapsed_seconds=50,
                execution=dict(workflow_status=workflow, model_calls=2, model_call_limit=10,
                               time_budget_seconds=360, reading_progress=dict(
                                   phase=phase, queries_finished=4, papers_attempted=5, papers_indexed=3)))
    data = run_node(r'''
const {loading,stop}=placeholder();let cancelled=0;stop.addEventListener('click',()=>cancelled++);
const task=TASK; for(let i=0;i<4;i++)window.MultiAgentRagUI.update(task,loading);
const details=loading.querySelector('.rag-progress-details');stop.events.click();
console.log(JSON.stringify({cards:loading.querySelectorAll('.rag-progress-panel').length,
 legacy:loading.querySelectorAll('.science-status-label,.science-elapsed,.rag-budget,.rag-reading-progress,.fa-spinner').length,
 stage:loading.querySelector('.rag-progress-stage').textContent,hidden:details.hidden,expanded:details.open,
 budget:loading.querySelector('.rag-progress-budget').textContent,reading:loading.querySelector('.rag-progress-reading').textContent,
 limits:loading.querySelector('.rag-progress-limits').textContent,
 sameStop:loading.querySelector('.science-stop-btn')===stop,cancelled,live:loading.querySelector('.rag-progress-stage')['aria-live']}));
'''.replace("TASK", json.dumps(task)))
    assert data["cards"] == 1 and data["legacy"] == 0
    assert data["stage"] == title and data["live"] == "polite"
    assert data["sameStop"] and data["cancelled"] == 1 and not data["expanded"]
    assert not data["hidden"]
    assert "2/10" in data["budget"] and "360" not in data["budget"]
    assert "大约 360" in data["limits"] and "15篇" in data["limits"]
    assert "超过300秒不再启动补查" in data["limits"] and "实际耗时可能更长" in data["limits"]
    assert "执行时限" not in data["limits"]
    if status in {"queued", "submitting"}:
        assert "50 秒" not in data["budget"] and "正在排队" in data["budget"]
    else:
        assert "50 秒" in data["budget"]
    assert "已尝试读取 5 篇" in data["reading"] and "已索引 3" in data["reading"]
    assert "5/15" not in data["reading"] and "已读取 5" not in data["reading"]


def test_unknown_usage_not_fabricated_and_backend_limits_respected():
    data = run_node(r'''
const {loading}=placeholder();
window.MultiAgentRagUI.update({processing_mode:'multi_agent_rag',status:'running'},loading);
const unknown=loading.querySelector('.rag-progress-budget').textContent;
window.MultiAgentRagUI.update({processing_mode:'multi_agent_rag',status:'running',elapsed_seconds:12,
 execution:{model_calls:3,model_call_limit:8,time_budget_seconds:240}},loading);
console.log(JSON.stringify({unknown,current:loading.querySelector('.rag-progress-budget').textContent,
 limits:loading.querySelector('.rag-progress-limits').textContent,
 hidden:loading.querySelector('.rag-progress-details').hidden}));
''')
    assert "—/10" in data["unknown"] and "待同步" in data["unknown"]
    assert "3/8" in data["current"] and "240 秒" not in data["current"] and not data["hidden"]
    assert "240 秒" in data["limits"]


def test_other_modes_untouched_and_expanded_details_preserved():
    data = run_node(r'''
const old=placeholder();const ignored=window.MultiAgentRagUI.update({processing_mode:'literature_answer'},old.loading);
const {loading}=placeholder();const task={processing_mode:'multi_agent_rag',status:'running',execution:{reading_progress:{}}};
window.MultiAgentRagUI.update(task,loading);const details=loading.querySelector('.rag-progress-details');details.open=true;
window.MultiAgentRagUI.update(task,loading);
console.log(JSON.stringify({ignored,oldLabel:!!old.loading.querySelector('.science-status-label'),
 oldCards:old.loading.querySelectorAll('.rag-progress-panel').length,expanded:details.open}));
''')
    assert not data["ignored"] and data["oldLabel"] and data["oldCards"] == 0
    assert data["expanded"]


def test_missing_read_counts_are_not_displayed_as_zero_success():
    data = run_node(r'''
const {loading}=placeholder();
window.MultiAgentRagUI.update({processing_mode:'multi_agent_rag',status:'running',execution:{reading_progress:{}}},loading);
console.log(JSON.stringify({reading:loading.querySelector('.rag-progress-reading').textContent}));
''')
    assert "待同步" in data["reading"] and "0 篇" not in data["reading"]


def test_polling_updates_rebuilt_placeholder_and_removes_it_on_terminal():
    source = "async function pollScienceTask(" + HTML.split("async function pollScienceTask(", 1)[1].split(
        "function contextSearchResultMarkdown", 1)[0]
    data = run_node(r'''
const original=placeholder(),replacement=placeholder();
let fetches=0,renderedStage;
window.pendingSessions={s1:{spinner:original.loading,loading:true}};
context.setTimeout=fn=>fn();
context.fetch=async()=>({ok:true,json:async()=>{
 fetches++;if(fetches===1){window.pendingSessions.s1.spinner=replacement.loading;
 return {id:'abc',status:'running',processing_mode:'multi_agent_rag',execution:{workflow_status:'writing'}};}
 renderedStage=replacement.loading.querySelector('.rag-progress-stage').textContent;
 return {id:'abc',status:'partial',processing_mode:'multi_agent_rag'};}});
context.scienceTaskMarkdown=()=> 'answer';context.addMessage=()=>null;
context.saveResultToDB=()=>{};context.showToast=()=>{};
vm.runInNewContext(POLL,context);
(async()=>{await context.pollScienceTask({id:'abc',status:'running',processing_mode:'multi_agent_rag'},'s1',original.loading,{});
 console.log(JSON.stringify({renderedStage,removed:!replacement.loading.parentNode,
 loading:window.pendingSessions.s1.loading,snapshot:window.pendingSessions.s1.scienceTask}));})();
'''.replace("POLL", json.dumps(source)))
    assert data["renderedStage"] == "正在撰写回答"
    assert data["removed"] and not data["loading"] and data["snapshot"] is None


def test_submit_resume_and_small_screen_contracts():
    css = (ROOT / "chatAi/multi_agent_rag.css").read_text("utf-8")
    assert "update(submitting, loadingDiv)" in HTML
    assert "update(latestScienceTask, pending)" in HTML
    assert "if (!handled && target" in HTML
    assert ".rag-progress-header{display:flex;align-items:center;flex-wrap:wrap;" in css
    assert ".rag-progress-details[hidden]{display:none}" in css
    assert ".rag-progress-header .science-stop-btn{flex-shrink:0;" in css


@pytest.mark.parametrize('profile,target,cutoff,limit', [('standard',360,300,10),('enhanced',720,600,20)])
def test_progress_uses_selected_profile_during_queue_and_execution(profile,target,cutoff,limit):
    task = {'processing_mode':'multi_agent_rag','status':'queued','report_profile':profile,'execution':{}}
    result = run_node(r'''
const {loading}=placeholder();window.MultiAgentRagUI.update(TASK,loading);
console.log(JSON.stringify({limits:loading.querySelector('.rag-progress-limits').textContent,
 budget:loading.querySelector('.rag-progress-budget').textContent}));
'''.replace('TASK', json.dumps(task)))
    assert f'大约 {target} 秒' in result['limits']
    assert f'超过{cutoff}秒' in result['limits']
    assert f'/{limit}' in result['budget']
