"""Execute the selection helper and real history/delete handlers in Node.

This verifies async state contracts, not browser layout or screenshots.
"""
import json
from pathlib import Path
import shutil
import subprocess

import pytest

ROOT = Path(__file__).resolve().parents[1]


def execute(source, harness, scenario):
    node = shutil.which("node")
    if not node:
        pytest.skip("Node required")
    script = "const SOURCE=" + json.dumps(source) + ";const SCENARIO=" + json.dumps(scenario) + ";\n" + harness
    result = subprocess.run([node, "-"], input=script, text=True, encoding="utf8", capture_output=True, timeout=10)
    assert result.returncode == 0, result.stderr
    return json.loads(result.stdout)


@pytest.mark.parametrize("scenario", ["refresh", "other_account", "late_account", "manual_selection", "deleted",
    "invalid_id", "invalid_json", "active", "disabled_storage", "logout", "clear", "new_tab"])
def test_restore_requires_authenticated_list_and_current_identity(scenario):
    source = (ROOT / "chatAi/conversation_selection.js").read_text(encoding="utf8")
    harness = r'''
const vm=require('node:vm'),storage=new Map(),key='sciassistant.active-conversation/v1';
let clicks=0;
function page() {
 const window={chatSessionOwnerId:'alice',userToken:'secret-canary',currentSessionId:null,
  sessionStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)}};
 vm.runInNewContext(SOURCE,{window});return window;
}
let window=page();window.ConversationSelection.remember('s1');
const saved=storage.get(key);
// Simulate a reload with a fresh JS heap and the same tab-local storage.
window=page();let checkpoint=window.ConversationSelection.checkpoint();
let nodes=[{dataset:{id:'s1'},click(){clicks++;window.currentSessionId='s1';window.ConversationSelection.remember('s1');}}];
if(SCENARIO==='other_account'){window.chatSessionOwnerId='bob';window.userToken='b';checkpoint=window.ConversationSelection.checkpoint();}
if(SCENARIO==='late_account')window.userToken='new-token';
if(SCENARIO==='manual_selection'){window.currentSessionId='s2';window.ConversationSelection.remember('s2');window.currentSessionId=null;}
if(SCENARIO==='deleted')nodes=[];
if(SCENARIO==='invalid_id')storage.set(key,JSON.stringify({owner:'alice',session:'../../private'}));
if(SCENARIO==='invalid_json')storage.set(key,'{broken');
if(SCENARIO==='active')window.currentSessionId='s2';
if(SCENARIO==='disabled_storage')window.sessionStorage={getItem(){throw Error('denied');},setItem(){throw Error('denied');},removeItem(){throw Error('denied');}};
if(SCENARIO==='logout')window.ConversationSelection.forget();
if(SCENARIO==='clear')window.ConversationSelection.remember(null);
if(SCENARIO==='new_tab')storage.clear();
const restored=window.ConversationSelection.restore(nodes,checkpoint);
// Disabled storage also cannot break ordinary selection/clear.
if(SCENARIO==='disabled_storage'){window.ConversationSelection.remember('s2');window.ConversationSelection.forget();}
console.log(JSON.stringify({restored,clicks,current:window.currentSessionId,saved,retained:storage.has(key)}));
'''
    result = execute(source, harness, scenario)
    assert json.loads(result["saved"]) == {"owner": "alice", "session": "s1"}
    assert "secret-canary" not in result["saved"]
    if scenario == "refresh":
        assert result["restored"] and result["clicks"] == 1 and result["current"] == "s1"
    else:
        assert not result["restored"] and result["clicks"] == 0
    if scenario in {"deleted", "logout", "clear", "new_tab"}:
        assert not result["retained"]


def test_restored_session_uses_server_pdf_binding_without_reupload():
    source = (ROOT / "chatAi/conversation_selection.js").read_text(encoding="utf8")
    pdf = (ROOT / "chatAi/pdf_session.js").read_text(encoding="utf8")
    harness = "const PDF=" + json.dumps(pdf) + ";\n" + r'''
const vm=require('node:vm'),requests=[],saved=new Map();
const window={currentSessionId:null,userToken:'a',chatSessionOwnerId:'alice',selectedTab:'research',
 sessionStorage:{getItem:k=>saved.get(k)||null,setItem:(k,v)=>saved.set(k,v),removeItem:k=>saved.delete(k)}};
vm.runInNewContext(SOURCE,{window});window.ConversationSelection.remember('s1');
// A fresh selection controller, as on reload; only storage survives.
vm.runInNewContext(SOURCE,{window});
const el=()=>({hidden:true,children:[],replaceChildren(...items){this.children=items;},setAttribute(){},addEventListener(){}}),host=el();
const context={window,DOMException,AbortController,document:{getElementById:id=>id==='research-processing-mode'?{value:'pdf_local'}:host,
 createElement:el,querySelectorAll:()=>[]},fetch:async url=>{requests.push(url);return {ok:true,json:async()=>({attachment:{filename:'科研论文.pdf',source_task_id:'aaaaaaaaaaaa'}})};}};
vm.runInNewContext(PDF,context);
let restorePromise;
window.ConversationSelection.restore([{dataset:{id:'s1'},click(){window.currentSessionId='s1';restorePromise=window.SciencePdfSession.changed();}}],window.ConversationSelection.checkpoint());
(async()=>{
 await restorePromise;const form={values:[],append(k,v){this.values.push([k,v]);}};
 await window.SciencePdfSession.append(form,'s1','pdf_local',null);
 console.log(JSON.stringify({requests,values:form.values,current:window.currentSessionId,hidden:host.hidden,chip:host.children[0].textContent}));
})().catch(e=>{process.stderr.write(String(e));process.exit(1);});
'''
    result = execute(source, harness, "refresh_pdf")
    assert result["current"] == "s1" and not result["hidden"]
    assert "科研论文.pdf" in result["chip"]
    assert result["values"] == [["pdf_source_task_id", "aaaaaaaaaaaa"]]
    assert result["requests"] == ["/5000/api/science/conversations/s1/pdf-attachment"] * 2


DOM = r'''
const vm=require('node:vm'),requests=[],messages=[],timers=[],toasts=[];
const classes=()=>({add(){},remove(){},contains(){return false;}});
const element=id=>({dataset:{id},classList:classes(),querySelector(){return {classList:classes()};},
 addEventListener(_name,fn){this.click=()=>fn.call(this);},getAttribute(){return id;},remove(){this.removed=true;}});
const a=element('s1'),b=element('s2');
let clears=0;
const chatMessages={appendChild(){},querySelector(){return null;},scrollTop:0,scrollHeight:10};
Object.defineProperty(chatMessages,'innerHTML',{set(){clears++;messages.length=0;}});
const initialPrompt={classList:classes()},inputContainer={classList:classes()},scrollToBottomBtn={classList:classes()},
 submitButton={},sessionDeleteModal={classList:classes()};
const window={currentSessionId:'s1',userToken:'a',chatSessionOwnerId:'alice',SessionList:[],
 sessionStorage:{getItem(){return null;},setItem(){},removeItem(){}},
 SciencePdfSession:{changed(){window.ConversationSelection.remember(window.currentSessionId);}}};
const document={getElementById:id=>id==='cancel-button'?{classList:classes()}:null,querySelectorAll:()=>[a,b]};
const fetch=(_url,_init)=>new Promise((resolve,reject)=>requests.push({resolve,reject}));
const context={window,document,chatMessages,initialPrompt,inputContainer,scrollToBottomBtn,submitButton,
 sessionDeleteModal,currentDeletingSession:a,fetch,console:{error(){},warn(){}},
 sciAssistantDebug(){},updateConversationExportState(){},showToast:(msg,type)=>toasts.push(type),
 addMessage:text=>messages.push(text),restoreScienceEvidenceDownload(){},
 setTimeout:fn=>timers.push(fn)};
vm.runInNewContext(HELPER,context);vm.runInNewContext(SOURCE,context);
const flush=async()=>{await new Promise(resolve=>setImmediate(resolve));};
'''


@pytest.mark.parametrize("scenario", ["current", "late_session", "late_account", "aba", "late_error", "late_scroll"])
def test_history_handler_does_not_render_stale_messages_or_write_error_to_db(scenario):
    html = (ROOT / "chatAi/ai_chat.html").read_text(encoding="utf8")
    source = html.split("function addSessionClickEvent(session) {", 1)[1].split("// 为会话菜单按钮绑定事件", 1)[0]
    source = "function addSessionClickEvent(session) {" + source
    assert "saveResultToDB" not in source
    helper = (ROOT / "chatAi/conversation_selection.js").read_text(encoding="utf8")
    harness = "const HELPER=" + json.dumps(helper) + ";\n" + DOM + r'''
(async()=>{
 context.addSessionClickEvent(a);context.addSessionClickEvent(b);a.click();
 if(['late_session','aba','late_error'].includes(SCENARIO))b.click();
 if(SCENARIO==='aba')a.click();
 if(SCENARIO==='late_account')window.userToken='b';
 if(SCENARIO==='late_error')requests[0].reject(Error('private-canary'));
 else requests[0].resolve({ok:true,json:async()=>({messages:[{content:'OLD',from_who:'user'}]})});
 await flush();
 if(SCENARIO==='late_scroll'){b.click();chatMessages.scrollTop=7;timers.forEach(fn=>fn());}
 console.log(JSON.stringify({messages,scroll:chatMessages.scrollTop,clears}));
})().catch(e=>{process.stderr.write(String(e));process.exit(1);});
'''
    result = execute(source, harness, scenario)
    assert result["messages"] == (["OLD"] if scenario == "current" else [])
    if scenario == "late_scroll":
        assert result["scroll"] == 7


@pytest.mark.parametrize("scenario", ["active", "other", "error", "late_account", "new_dialog"])
def test_delete_checks_success_and_does_not_clear_another_conversation(scenario):
    html = (ROOT / "chatAi/ai_chat.html").read_text(encoding="utf8")
    source = "function confirmDeleteSession() {" + html.split("function confirmDeleteSession() {", 1)[1].split("// 取消删除会话", 1)[0]
    helper = (ROOT / "chatAi/conversation_selection.js").read_text(encoding="utf8")
    harness = "const HELPER=" + json.dumps(helper) + ";\n" + DOM + r'''
(async()=>{
 messages.push('EXISTING');
 if(SCENARIO==='other')window.currentSessionId='s2';
 context.confirmDeleteSession();
 if(SCENARIO==='late_account')window.userToken='b';
 if(SCENARIO==='new_dialog')context.currentDeletingSession=b;
 requests[0].resolve({ok:SCENARIO!=='error'});await flush();
 console.log(JSON.stringify({aRemoved:!!a.removed,bRemoved:!!b.removed,current:window.currentSessionId,
  dialog:context.currentDeletingSession?.dataset.id||null,messages,clears,toasts}));
})().catch(e=>{process.stderr.write(String(e));process.exit(1);});
'''
    result = execute(source, harness, scenario)
    assert not result["bRemoved"]
    if scenario in {"active", "new_dialog"}:
        assert result["aRemoved"] and result["current"] is None and result["clears"] == 1
    elif scenario == "other":
        assert result["aRemoved"] and result["current"] == "s2" and result["messages"] == ["EXISTING"]
    else:
        assert not result["aRemoved"] and result["current"] == "s1" and result["messages"] == ["EXISTING"]
    if scenario == "new_dialog":
        assert result["dialog"] == "s2"
    if scenario == "error":
        assert result["toasts"] == ["error"]


def test_selection_hooks_and_runtime_packaging():
    html = (ROOT / "chatAi/ai_chat.html").read_text(encoding="utf8")
    helper = (ROOT / "chatAi/pdf_session.js").read_text(encoding="utf8")
    from runtime_identity import IDENTITY_FILES
    from tools.cloud_release import REQUIRED
    name = "chatAi/conversation_selection.js"
    assert name in IDENTITY_FILES and name in REQUIRED
    assert html.index('/chatAi/conversation_selection.js') < html.index('/chatAi/pdf_session.js')
    assert "ConversationSelection?.remember(session)" in helper
    auth = html.split("if (userToken && username) {", 1)[1].split("} else {", 1)[0]
    assert auth.index("window.userToken = userToken") < auth.index("getList(userId)")
    assert "window.chatSessionOwnerId = String(userId || '')" in auth
    assert "ConversationSelection?.forget()" in html
    assert "ConversationSelection?.restore(chatHistory.querySelectorAll('.chat-session'), selectionCheckpoint)" in html
    for name in ("Dockerfile.cloud", "Dockerfile.account.cloud"):
        assert "COPY chatAi /app/chatAi" in (ROOT / name).read_text(encoding="utf8")
        assert "!chatAi/*.js" in (ROOT / (name + ".dockerignore")).read_text(encoding="utf8")
