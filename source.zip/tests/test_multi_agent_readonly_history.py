"""Inspection/replay cannot checkpoint live WAL or replace historical reports."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

import pytest

from tools import multi_agent_cli as cli


def tree(path):
    return {str(p.relative_to(path)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in path.rglob('*') if p.is_file()}


def run_fixture(tmp_path):
    assert cli.main(['run', '--mode', 'mock', '--query', 'read-only question',
                     '--run-id', 'history', '--output-root', str(tmp_path)]) == 0
    return tmp_path / 'history'


def test_inspect_preserves_uncheckpointed_wal_and_reads_latest_run(tmp_path, capsys):
    directory = run_fixture(tmp_path)
    db = directory / 'workflow.sqlite3'
    # Abruptly exiting this isolated helper leaves a genuine committed WAL.
    result = subprocess.run([sys.executable, '-c',
        "import sqlite3,sys,os;c=sqlite3.connect(sys.argv[1]);"
        "c.execute('PRAGMA journal_mode=WAL');"
        "c.execute('UPDATE workflow_run SET model_calls_used=7');c.commit();os._exit(0)",
        str(db)], timeout=20)
    assert result.returncode == 0 and Path(str(db) + '-wal').is_file()
    before = tree(directory)
    capsys.readouterr()
    assert cli.inspect_command(SimpleNamespace(run_dir=directory)) == 0
    assert json.loads(capsys.readouterr().out)['run']['model_calls_used'] == 7
    assert tree(directory) == before
    from tools.inspect_research_quality import inspect_run
    assert inspect_run(directory)['model_calls'] == 7
    assert tree(directory) == before


def test_inspect_missing_storage_does_not_create_empty_db(tmp_path):
    directory = tmp_path / 'missing'
    directory.mkdir()
    (directory / 'manifest.json').write_text('{"run_id":"missing"}')
    before = tree(directory)
    with pytest.raises(ValueError, match='INSPECTION_STORAGE_MISSING'):
        cli.inspect_command(SimpleNamespace(run_dir=directory))
    assert tree(directory) == before


def test_replay_preserves_recorded_export_and_reports_mismatch(tmp_path, capsys):
    directory = run_fixture(tmp_path)
    (directory / 'final_answer.md').write_text('historical export; do not replace', encoding='utf-8')
    before = tree(directory)
    capsys.readouterr()
    assert cli.replay_command(SimpleNamespace(run_dir=directory)) == 0
    result = json.loads(capsys.readouterr().out)
    assert result['source_run_modified'] is False
    assert result['recorded_exports_match']['final_answer.md'] is False
    assert tree(directory) == before


def test_replay_explicit_destination_creates_separate_exports(tmp_path, capsys):
    directory = run_fixture(tmp_path)
    before = tree(directory)
    output = tmp_path / 'separate-replay'
    assert cli.replay_command(SimpleNamespace(run_dir=directory, output_dir=output)) == 0
    assert (output / 'final_answer.md').is_file() and tree(directory) == before
    with pytest.raises(ValueError, match='REPLAY_OUTPUT_INVALID'):
        cli.replay_command(SimpleNamespace(run_dir=directory, output_dir=output))
    with pytest.raises(ValueError, match='REPLAY_OUTPUT_INVALID'):
        cli.replay_command(SimpleNamespace(run_dir=directory, output_dir=directory / 'nested'))


def test_replay_missing_report_requires_explicit_destination(tmp_path):
    directory = run_fixture(tmp_path)
    (directory / 'final_answer.md').unlink()
    before = tree(directory)
    with pytest.raises(ValueError, match='REPLAY_REPORT_MISSING'):
        cli.replay_command(SimpleNamespace(run_dir=directory))
    assert tree(directory) == before
