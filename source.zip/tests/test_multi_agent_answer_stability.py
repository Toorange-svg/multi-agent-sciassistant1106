"""Less accidental refusal, without relaxing evidence or inventing verdicts."""
from copy import deepcopy

import pytest

from multi_agent_quality import (ABSENCE_SCOPE_POLICY, REPORT_REFERENCE_POLICY,
    check_audit, publication_rejections, audit_witness_options, report_evidence,
    WITNESS_CHOICE_POLICY, resolve_witness_choices, answer_requirements, scope_plan_to_question)
from multi_agent_live import canonical_arxiv_query
from multi_agent_pipeline_v2 import render_claims
from deepdiver_v2.src.arxiv_query import validate_arxiv_query
from test_multi_agent_absence_basis import audit, absence
from test_multi_agent_report_fields import draft, evidence, QUOTE


@pytest.mark.parametrize("text", [
    "所选 vLLM/PagedAttention 片段未报告生成质量指标。",
    "所选 vLLM/PagedAttention 片段（第1页）未报告生成质量指标。",
    "LoRA 原始论文的直接文本未出现在本批证据中。",
    "LoRA 原始论文的显存开销数值未在证据集中。",
    "本批证据未包含原始方法论文的全文。",
    "不代表全文未报告这些内容。",
    "不能据此判断论文未报告相关实验。",
    "这些独立观察不能识别跨实验分数差异的原因。",
])
def test_visible_scope_and_non_inference_not_magic_phrase(text):
    data, sources = draft(), evidence()
    data["absence_scope_policy"] = ABSENCE_SCOPE_POLICY
    data["claims"][0]["qualification"] = text
    value = absence(audit(data), text)
    before = deepcopy((data, sources, value))
    checked = check_audit(value, data, sources)
    assert not checked["absence_issues"] and not checked["contract_errors"]
    assert not publication_rejections(checked, data)
    assert (data, sources, value) == before


def test_same_sentence_visible_scope_not_other_fields():
    data = draft()
    data["absence_scope_policy"] = ABSENCE_SCOPE_POLICY
    data["claims"][0]["qualification"] = "所选片段给出不同设置的观察，而非同一对照实验下的统一节省比例。"
    checked = check_audit(absence(audit(data), "而非同一对照实验下的统一节省比例。"), data, evidence())
    assert not checked["absence_issues"]
    data["claims"][0]["qualification"] = "而非同一对照实验下的统一节省比例。"
    assert check_audit(absence(audit(data), data["claims"][0]["qualification"]), data, evidence())["absence_issues"]


@pytest.mark.parametrize("text", ["论文未报告生成质量指标。", "论文只报告准确率，未给出泛化指标。",
    "三者均未报告配对评估。", "这并非经过统一对照验证的机制。",
    "所选片段未提供指标，但论文未报告任何检验。",
    "论文未报告相关检验，而所选片段只解释机制。",
    "作者没有做配对实验，所选片段给出两个数据集。"])
def test_actual_whole_paper_negatives_and_compound_omission_still_rejected(text):
    data = draft()
    data["absence_scope_policy"] = ABSENCE_SCOPE_POLICY
    data["claims"][0]["qualification"] = text
    checked = check_audit(absence(audit(data), text), data, evidence())
    assert checked["absence_issues"] and publication_rejections(checked, data) == {"c1"}


def test_other_sentence_and_legacy_policy_do_not_rescue_assertions():
    data = draft()
    text = "所选片段只覆盖部分信息。未给出配对实验。"
    data["claims"][0]["qualification"] = text
    data["absence_scope_policy"] = ABSENCE_SCOPE_POLICY
    assert check_audit(absence(audit(data), "未给出配对实验。"), data, evidence())["absence_issues"]
    data.pop("absence_scope_policy")
    text = "所选 vLLM 片段未报告指标。"
    data["claims"][0]["qualification"] = text
    assert check_audit(absence(audit(data), text), data, evidence())["absence_issues"]


def test_scope_recognition_does_not_license_invented_quote_or_number():
    data = draft()
    data["absence_scope_policy"] = ABSENCE_SCOPE_POLICY
    data["claims"][0]["qualification"] = "不代表全文未报告这些内容。"
    value = absence(audit(data), data["claims"][0]["qualification"])
    value["claim_results"][0]["source_witnesses"][0]["quote"] = "An invented experiment says accuracy is exactly 99.9 percent."
    checked = check_audit(value, data, evidence())
    assert checked["witness_issues"] and publication_rejections(checked, data) == {"c1"}


def test_correction_options_are_exact_approved_slices_not_a_repaired_verdict():
    data, sources = draft(), evidence()
    sources["evidence"][0]["excerpt"] = QUOTE + " " + "Reported measured accuracy is 95 percent in this specific dataset. " * 8
    value = audit(data)
    value["claim_results"][0]["source_witnesses"][0]["quote"] = sources["evidence"][0]["excerpt"]
    before = deepcopy((value, data, sources))
    checked = check_audit(value, data, sources)
    assert publication_rejections(checked, data) == {"c1"}
    options = audit_witness_options(checked, data, sources)["options"]
    assert options
    for row in options:
        assert 20 <= len(row["quote"].strip()) <= 350
        assert row["quote"] == sources["evidence"][0]["excerpt"][row["start_char"]:row["end_char"]]
    assert publication_rejections(checked, data) == {"c1"}
    assert (value, data, sources) == before


@pytest.mark.parametrize("bad", [None, True, "bad", [None], [{"evidence_id": "unknown", "quote": QUOTE}]])
def test_invalid_witness_container_does_not_crash_correction(bad):
    data, value, sources = draft(), audit(draft()), evidence()
    value["claim_results"][0]["source_witnesses"] = bad
    checked = check_audit(value, data, sources)
    assert audit_witness_options(checked, data, sources)["options"] == []
    assert publication_rejections(checked, data) == {"c1"}


@pytest.mark.parametrize("title", [
    "Reciprocal Rank Fusion outperforms Condorcet and individual Rank Learning Methods",
    "BM25 and Beyond: A Study of Term Weighting and Query Expansion",
    "Research on Sparse OR Dense Retrieval",
])
def test_exact_titles_conjunctions_remain_literals(title):
    query = f'ti:"{title}"'
    assert validate_arxiv_query(query) == (True, "ok")
    assert canonical_arxiv_query(query) == query


def test_nested_field_expression_still_rejected_and_fallback_never_searches_ti():
    assert not validate_arxiv_query('ti:"ti:Transformer AND abs:attention"')[0]
    repaired = canonical_arxiv_query('ti:"ti:Transformer AND abs:attention"')
    assert 'ti:"ti"' not in repaired and 'ti:"abs"' not in repaired


def test_only_published_claims_get_numbered_references_without_deleting_evidence():
    data, sources = draft(), evidence()
    sources["evidence"].insert(0, {**deepcopy(sources["evidence"][0]), "evidence_id": "unused"})
    before = deepcopy(sources)
    data["report_reference_policy"] = REPORT_REFERENCE_POLICY
    assert [e["evidence_id"] for e in report_evidence(data, sources, set())] == ["e1"]
    rendered = render_claims(data, sources)
    assert "[1]" in rendered and "[2]" not in rendered
    assert report_evidence(data, sources, {"c1"}) == []
    assert sources == before
    data.pop("report_reference_policy")
    assert "[2]" in render_claims(data, sources)  # historical numbering unchanged


def choice_input():
    data, sources = draft(), evidence()
    data["witness_choice_policy"] = WITNESS_CHOICE_POLICY
    value = audit(data)
    value["claim_results"][0]["source_witnesses"][0]["quote"] = QUOTE + " Invented extra text. " * 20
    checked = check_audit(value, data, sources)
    menu = audit_witness_options(checked, data, sources)
    assert menu["options"]
    option = menu["options"][0]
    value["claim_results"][0]["source_witnesses"] = [{"evidence_id": option["evidence_id"], "quote_id": option["quote_id"]}]
    return data, sources, value, menu


def test_explicit_choice_resolves_only_exact_source_and_preserves_raw_decision():
    data, sources, value, menu = choice_input()
    before = deepcopy((data, sources, value, menu))
    resolved, receipt = resolve_witness_choices(value, menu, data, sources)
    assert receipt["resolutions"] and not receipt["semantic_auto_approval"]
    assert not check_audit(resolved, data, sources)["witness_issues"]
    assert resolved["claim_results"][0]["decision"] == value["claim_results"][0]["decision"]
    assert (data, sources, value, menu) == before


@pytest.mark.parametrize("fault", ["unknown", "different_claim", "different_source", "extra_key", "changed_quote", "unapproved", "legacy"])
def test_forged_choice_is_not_resolved_or_published(fault):
    data, sources, value, menu = choice_input()
    selection = value["claim_results"][0]["source_witnesses"][0]
    if fault == "unknown":
        selection["quote_id"] = "invented"
    elif fault == "different_claim":
        menu["options"][0]["claim_id"] = "other"
    elif fault == "different_source":
        selection["evidence_id"] = "other"
    elif fault == "extra_key":
        selection["quote"] = QUOTE
    elif fault == "changed_quote":
        menu["options"][0]["quote"] = "Invented measured accuracy is exactly 99 percent."
    elif fault == "unapproved":
        sources["evidence"][0]["review_status"] = "pending"
    else:
        data.pop("witness_choice_policy")
    resolved, receipt = resolve_witness_choices(value, menu, data, sources)
    assert not receipt["resolutions"]
    assert publication_rejections(check_audit(resolved, data, sources), data) == {"c1"}


@pytest.mark.parametrize("question", [
    "解释 NF4、双重量化与分页优化器分别解决什么问题？哪些参数会更新？区分存储格式与计算精度，不能把显存节省当作推理加速。",
    "哪些参数会更新？不要求性能或显存数字。",
    "自注意力怎样计算？解释QKV。不要给性能排名或通用百分比。",
])
def test_negative_constraints_and_update_are_not_benchmark_or_better_questions(question):
    requirements = answer_requirements(question)
    assert not requirements["evaluation_requested"]
    assert requirements["question_kind"] == "method_overview"
    assert not requirements["requested_measurement_families"]
    plan = {"groups": [{"id": "g1", "metrics": ["mechanism", "accuracy", "latency", "memory"]}]}
    scoped, _ = scope_plan_to_question(plan, requirements)
    assert scoped["groups"][0]["metrics"] == ["mechanism"]


@pytest.mark.parametrize("question", ["比较哪种方法更快，报告吞吐与显存。", "分别能降低多少延迟？给出模型和实验条件。",
    "不必给统一百分比，但请比较论文实际准确率和生成质量。"])
def test_actual_measurement_requests_are_preserved(question):
    requirements = answer_requirements(question)
    assert requirements["evaluation_requested"] and requirements["requested_measurement_families"]


def test_full_workflow_auditor_choice_uses_existing_retry_not_auto_approval(tmp_path):
    from test_multi_agent_pipeline_v2 import agents, pipeline
    configured, calls = agents()
    data = draft()
    data["claims"][0]["evidence_ids"] = ["arxiv-1"]
    def writer(_):
        calls.append("writer")
        return {"output": data}
    configured.writer.handler = writer
    seen = []
    def auditor(packet):
        calls.append("citation_auditor")
        value = audit(data)
        if not seen:
            value["claim_results"][0]["source_witnesses"][0]["quote"] = QUOTE + " Excessively long quote. " * 20
        else:
            report = next(i["payload"] for i in packet["inputs"] if i["payload"].get("stage") == "citation_auditor")
            option = report["source_witness_options"]["options"][0]
            value["claim_results"][0]["source_witnesses"] = [{"evidence_id": option["evidence_id"], "quote_id": option["quote_id"]}]
        seen.append(value)
        return {"output": value}
    configured.citation_auditor.handler = auditor
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {"status": "ok", "papers": [{"paper_id": "1", "title": "Paper", "abstract": QUOTE}]})
    result = flow.run("explicit-choice", "owner", "Define A")
    assert result["run"]["status"] == "completed"
    assert result["run"]["model_calls_used"] == 6 and calls.count("writer") == 1 and len(seen) == 2
    final = flow.artifacts.get(result["final_artifact_id"])
    assert flow.artifacts.get(final["artifact_refs"]["witness_resolution"])["resolutions"]


@pytest.mark.parametrize("fault", ["rate_limited", "source_unreachable", "deadline_skipped"])
def test_source_failure_can_retrieve_verified_public_pdf_cache(tmp_path, fault):
    import time
    from multi_agent_live import LiveArxivRagExecutor
    from test_multi_agent_live import create_pdf, make_search, request
    warm = LiveArxivRagExecutor(tmp_path / "warm", tmp_path / "storage", rag_mode="lexical",
        search=make_search(), download=lambda _, folder: create_pdf(folder))
    assert warm.execute(request(), group_ids={"g1"}, deadline=time.monotonic() + 30)["evidence"]
    cold_network = LiveArxivRagExecutor(tmp_path / "offline", tmp_path / "storage", rag_mode="lexical",
        search=lambda *_args, **_kw: {"status": fault, "papers": []},
        download=lambda *_: pytest.fail("cache must not download"), parse=lambda *_: pytest.fail("cache must not reparse"))
    # The registry can verify this complete title, not arbitrary title/abstract
    # Boolean constraints synthesized from a plain query.
    cached_request = request()
    cached_request[0]["arguments"]["query"] = 'ti:"PagedAttention"'
    result = cold_network.execute(cached_request, group_ids={"g1"}, deadline=time.monotonic() + 30)
    assert result["evidence"] and all(e["paper_id"] == "2309.06180" for e in result["evidence"])
    assert any(o.get("upstream_status") == fault and o.get("retrieval_origin") == "verified_local_public_cache" for o in result["observations"])
    assert not any(e.get("review_status") == "approved" for e in result["evidence"])


@pytest.mark.parametrize("fault", ["modified_pdf", "date_filter", "disabled", "private_registry", "oversize_pdf"])
def test_cached_fallback_does_not_use_stale_private_or_date_unknown_source(tmp_path, fault, monkeypatch):
    import time
    import json
    from multi_agent_live import LiveArxivRagExecutor
    from test_multi_agent_live import create_pdf, make_search, request
    warm = LiveArxivRagExecutor(tmp_path / "warm", tmp_path / "storage", rag_mode="lexical",
        search=make_search(), download=lambda _, folder: create_pdf(folder))
    warm.execute(request(), group_ids={"g1"}, deadline=time.monotonic() + 30)
    folder = next(warm.documents.root.iterdir())
    if fault == "modified_pdf":
        # Materialize a different valid PDF without changing its registry hash.
        import fitz
        with fitz.open(folder / "source.pdf") as doc:
            doc[0].insert_text((50, 100), "different valid PDF bytes")
            doc.saveIncr()
    elif fault == "oversize_pdf":
        from pathlib import Path
        from types import SimpleNamespace
        original_stat = Path.stat
        def limited_stat(path, **kwargs):
            if path == folder / "source.pdf" and kwargs.get("follow_symlinks", True):
                return SimpleNamespace(st_size=30 * 1024 * 1024 + 1)
            return original_stat(path, **kwargs)
        monkeypatch.setattr(Path, "stat", limited_stat)
    elif fault == "private_registry":
        registry = json.loads((folder / "metadata.json").read_text(encoding="utf-8"))
        registry["paper_id"] = "uploaded-private"
        (folder / "metadata.json").write_text(json.dumps(registry), encoding="utf-8")
    offline = LiveArxivRagExecutor(tmp_path / "offline", tmp_path / "storage", rag_mode="lexical",
        search=lambda *_args, **_kw: {"status": "disabled" if fault == "disabled" else "rate_limited", "papers": []})
    if fault == "date_filter":
        offline.source_clues["publication_window"] = {"first_year": 2026, "last_year": 2026}
    assert not offline.execute(request(), group_ids={"g1"}, deadline=time.monotonic() + 30)["evidence"]
