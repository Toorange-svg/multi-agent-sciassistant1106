from evidence_fallback import should_use_general_fallback, wrap_general_fallback


def test_evidence_failure_uses_general_fallback():
    assert should_use_general_fallback("failed", "INSUFFICIENT_EVIDENCE", 0, 0)
    assert should_use_general_fallback("needs_review", "NO_AUDITED_CLAIMS", 0, 2)


def test_empty_review_without_published_claims_uses_fallback():
    assert should_use_general_fallback("needs_review", "", 0, 0)
    assert should_use_general_fallback("needs_review", "", 0, 5)
    assert not should_use_general_fallback("completed", "", 0, 0)


def test_operational_failures_are_not_hidden_as_general_answers():
    assert not should_use_general_fallback("failed", "MODEL_HTTP_402", 0, 0)
    assert not should_use_general_fallback("cancelled", "USER_CANCELLED", 0, 0)
    assert not should_use_general_fallback("timed_out", "WEB_RAG_TIMEOUT", 0, 0)
    assert should_use_general_fallback("failed", "WEB_RAG_EXECUTION_FAILED", 0, 0)


def test_fallback_has_explicit_boundary():
    text = wrap_general_fallback("通用解释", reason="来源不可达")
    assert "降级回答" in text
    assert "不代表上传 PDF、检索结果或已批准引用中的结论" in text
    assert text.endswith("通用解释")
