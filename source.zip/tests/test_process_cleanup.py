"""Process cleanup order plus real short-timeout/cancel tree verification."""
import json
import os
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from unittest.mock import Mock, patch

import process_cleanup
import web_app


class FakeProcess:
    def __init__(self, pid=123):
        self.pid = pid
        self.alive = True
        self.actions = []
    def poll(self):
        return None if self.alive else 0
    def terminate(self):
        self.actions.append("terminate")
        self.alive = False
    def kill(self):
        self.actions.append("kill")
        self.alive = False
    def wait(self, timeout):
        self.actions.append("wait")
        if self.alive:
            raise subprocess.TimeoutExpired("fixture", timeout)
        return 0


class CleanupOrderTests(unittest.TestCase):
    def test_windows_tree_is_killed_before_parent(self):
        process = FakeProcess()
        def taskkill(*args, **kwargs):
            self.assertTrue(process.alive)
            self.assertNotIn("terminate", process.actions)
            self.assertEqual(args[0], ["taskkill", "/F", "/T", "/PID", "123"])
            self.assertEqual(kwargs["timeout"], 5)
            process.alive = False
            return Mock(returncode=0)
        with patch.object(process_cleanup.os, "name", "nt"), patch.object(process_cleanup.subprocess, "CREATE_NO_WINDOW", 0, create=True), patch.object(process_cleanup.subprocess, "run", side_effect=taskkill) as run:
            result = process_cleanup.terminate_process_tree(process)
            again = process_cleanup.terminate_process_tree(process)
        self.assertEqual(result["status"], "confirmed")
        self.assertEqual(again, result)
        run.assert_called_once()
        self.assertNotIn("terminate", process.actions)

    def test_taskkill_timeout_falls_back_without_claiming_tree_success(self):
        process = FakeProcess()
        with patch.object(process_cleanup.os, "name", "nt"), patch.object(process_cleanup.subprocess, "CREATE_NO_WINDOW", 0, create=True), patch.object(process_cleanup.subprocess, "run", side_effect=subprocess.TimeoutExpired("private-token", 5)):
            result = process_cleanup.terminate_process_tree(process)
        self.assertEqual(result["status"], "partial")
        self.assertTrue(result["parent_stopped"])
        self.assertFalse(result["tree_stop_confirmed"])
        self.assertNotIn("private-token", json.dumps(result))

    def test_exited_parent_is_not_reused_as_a_kill_target(self):
        process = FakeProcess()
        process.alive = False
        with patch.object(process_cleanup.os, "name", "nt"), patch.object(process_cleanup.subprocess, "run") as run:
            result = process_cleanup.terminate_process_tree(process)
        run.assert_not_called()
        self.assertEqual(result["status"], "partial")
        self.assertFalse(result["tree_stop_confirmed"])

    def test_concurrent_cleanup_executes_tree_command_once(self):
        process = FakeProcess()
        entered, release = threading.Event(), threading.Event()
        def taskkill(*args, **kwargs):
            entered.set()
            release.wait(2)
            process.alive = False
            return Mock(returncode=0)
        with patch.object(process_cleanup.os, "name", "nt"), patch.object(process_cleanup.subprocess, "CREATE_NO_WINDOW", 0, create=True), patch.object(process_cleanup.subprocess, "run", side_effect=taskkill) as run:
            with ThreadPoolExecutor(max_workers=2) as executor:
                first = executor.submit(process_cleanup.terminate_process_tree, process)
                self.assertTrue(entered.wait(1))
                second = executor.submit(process_cleanup.terminate_process_tree, process)
                release.set()
                self.assertEqual(first.result(), second.result())
        run.assert_called_once()

    def test_owned_posix_group_is_used_even_if_parent_exited(self):
        process = FakeProcess()
        process.alive = False
        process._sciassistant_process_group = process.pid
        with patch.object(process_cleanup.os, "name", "posix"), patch.object(process_cleanup.os, "getpgrp", return_value=999, create=True), patch.object(process_cleanup.os, "killpg", create=True) as killpg, patch.object(process_cleanup.signal, "SIGKILL", 9, create=True):
            result = process_cleanup.terminate_process_tree(process)
        killpg.assert_called_once_with(123, 9)
        self.assertEqual(result["status"], "confirmed")

    def test_never_kills_callers_posix_group(self):
        process = FakeProcess()
        process._sciassistant_process_group = process.pid
        with patch.object(process_cleanup.os, "name", "posix"), patch.object(process_cleanup.os, "getpgrp", return_value=123, create=True), patch.object(process_cleanup.os, "killpg", create=True) as killpg:
            result = process_cleanup.terminate_process_tree(process)
        killpg.assert_not_called()
        self.assertEqual(result["status"], "partial")

    def test_failed_parent_cleanup_is_reported_safely(self):
        process = FakeProcess(pid=None)
        process.terminate = Mock(side_effect=PermissionError("private-token"))
        process.kill = Mock(side_effect=PermissionError("private-token"))
        result = process_cleanup.terminate_process_tree(process)
        self.assertEqual(result["status"], "failed")
        self.assertFalse(result["parent_stopped"])
        self.assertNotIn("private-token", json.dumps(result))


def pid_alive(pid):
    if os.name == "nt":
        import ctypes
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.OpenProcess.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_uint32]
        kernel.OpenProcess.restype = ctypes.c_void_p
        kernel.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
        kernel.CloseHandle.argtypes = [ctypes.c_void_p]
        handle = kernel.OpenProcess(0x100000, False, pid)
        if not handle:
            return False
        try:
            return kernel.WaitForSingleObject(handle, 0) == 258
        finally:
            kernel.CloseHandle(handle)
    try:
        os.kill(pid, 0)
        stat = Path(f"/proc/{pid}/stat")
        return not stat.exists() or stat.read_text().split()[2] != "Z"
    except ProcessLookupError:
        return False


class RealTaskCleanupTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.root = Path(self.directory.name)
        self.tree = self.root / "tree"
        self.tree.mkdir()
        self.old_tasks = web_app.TASKS.copy()
        self.old_processes = web_app._RETRIEVAL_PROCESSES.copy()
        self.old_log, self.old_state = web_app.LOG_DIR, web_app.TASK_STATE_DIR
        web_app.LOG_DIR = self.root / "logs"
        web_app.TASK_STATE_DIR = self.root / "state"
        web_app.LOG_DIR.mkdir()
        web_app.TASK_STATE_DIR.mkdir()
        self.task_id = "cleanup-canary"
        with web_app.TASK_LOCK:
            web_app.TASKS.clear()
            web_app.TASKS[self.task_id] = {"id": self.task_id, "status": "running",
                "created_at": web_app._now(), "updated_at": web_app._now()}
        self.process = None
        self.fixture = Path(__file__).parent / "fixtures" / "heartbeat_tree.py"
        self.original_popen = subprocess.Popen

    def tearDown(self):
        if self.process and self.process.poll() is None:
            web_app._terminate_subprocess_tree(self.process)
        # Only fixture PIDs created under this test's temporary directory.
        for file in self.tree.glob("pid-*.txt"):
            pid = int(file.read_text())
            if pid_alive(pid):
                if os.name == "nt":
                    subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)], timeout=5,
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                        creationflags=subprocess.CREATE_NO_WINDOW)
                else:
                    os.kill(pid, 9)
        with web_app.TASK_LOCK:
            web_app.TASKS.clear()
            web_app.TASKS.update(self.old_tasks)
            web_app._RETRIEVAL_PROCESSES.clear()
            web_app._RETRIEVAL_PROCESSES.update(self.old_processes)
        web_app.LOG_DIR, web_app.TASK_STATE_DIR = self.old_log, self.old_state
        self.directory.cleanup()

    def spawn_fixture(self, command, stream):
        fixture_command = ([str(self.fixture.with_suffix(".cmd")), sys.executable, str(self.tree)]
                           if os.name == "nt" else [sys.executable, str(self.fixture), str(self.tree), "2"])
        self.process = self.original_popen(fixture_command,
            stdout=stream, stderr=subprocess.STDOUT,
            **({"start_new_session": True} if os.name != "nt" else {}))
        if os.name != "nt":
            self.process._sciassistant_process_group = self.process.pid
        deadline = time.monotonic() + 5
        while len(list(self.tree.glob("beat-*.txt"))) != 3 and time.monotonic() < deadline:
            time.sleep(0.03)
        self.assertEqual(len(list(self.tree.glob("beat-*.txt"))), 3)
        return self.process

    def assert_tree_stopped(self):
        pids = [int(file.read_text()) for file in self.tree.glob("pid-*.txt")]
        self.assertEqual(len(pids), 3)
        deadline = time.monotonic() + 1
        while any(pid_alive(pid) for pid in pids) and time.monotonic() < deadline:
            time.sleep(0.02)
        self.assertTrue(all(not pid_alive(pid) for pid in pids))
        sizes = {p.name: p.stat().st_size for p in self.tree.glob("beat-*.txt")}
        time.sleep(0.25)
        self.assertEqual(sizes, {p.name: p.stat().st_size for p in self.tree.glob("beat-*.txt")})
        self.assertNotIn(self.task_id, web_app._RETRIEVAL_PROCESSES)
        result = web_app.TASKS[self.task_id]["execution"]["process_cleanup"]
        self.assertEqual(result["status"], "confirmed")
        self.assertTrue(result["parent_stopped"])
        self.assertFalse(result["remote_mcp_cancelled"])
        response = web_app.app.test_client().get(f"/api/tasks/{self.task_id}/evidence?format=json")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["lifecycle"]["execution"]["process_cleanup"]["status"], "confirmed")

    def test_short_timeout_stops_real_parent_child_grandchild(self):
        with patch.object(web_app, "_spawn_research_process", side_effect=self.spawn_fixture), patch.dict(os.environ, {"WEB_TASK_TIMEOUT": "0"}):
            web_app._run_query_task(self.task_id, "offline cleanup canary")
        self.assertEqual(web_app.TASKS[self.task_id]["status"], "failed")
        self.assertEqual(web_app.TASKS[self.task_id]["execution"]["failure_stage"], "research_timeout")
        self.assertEqual(web_app.TASKS[self.task_id]["execution"]["process_cleanup"]["reason"], "research_timeout")
        self.assert_tree_stopped()

    def test_bounded_paper_deadline_stops_real_tree_and_exports_budget(self):
        started = time.monotonic()
        with patch.object(web_app, "_spawn_research_process", side_effect=self.spawn_fixture), patch.dict(
            os.environ,
            {"WEB_TASK_TIMEOUT": "1", "ARXIV_PAPER_TASK_TIMEOUT": "240"},
        ):
            web_app._run_query_task(
                self.task_id,
                "解析 arXiv 论文 2105.05233",
                query_mode="paper_evidence",
                pdf_parse_mode="local",
            )

        elapsed = time.monotonic() - started
        task = web_app.TASKS[self.task_id]
        execution = task["execution"]
        self.assertEqual(task["status"], "failed")
        self.assertEqual(execution["workflow"], "bounded_paper_v1")
        self.assertEqual(execution["time_budget_seconds"], 1)
        self.assertEqual(execution["failure_stage"], "research_timeout")
        self.assertEqual(execution["process_cleanup"]["reason"], "research_timeout")
        self.assertGreaterEqual(elapsed, 0.5)
        self.assertLess(elapsed, 8)

        response = web_app.app.test_client().get(f"/api/tasks/{self.task_id}/evidence?format=json")
        self.assertEqual(response.status_code, 200)
        evidence_execution = response.get_json()["lifecycle"]["execution"]
        self.assertEqual(evidence_execution["workflow"], "bounded_paper_v1")
        self.assertEqual(evidence_execution["time_budget_seconds"], 1)
        self.assertEqual(evidence_execution["failure_stage"], "research_timeout")
        self.assert_tree_stopped()

    def test_cancel_stops_real_tree_and_preserves_unrelated_process(self):
        unrelated = self.original_popen([sys.executable, "-c", "import time; time.sleep(15)"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            with patch.object(web_app, "_spawn_research_process", side_effect=self.spawn_fixture):
                with ThreadPoolExecutor(max_workers=1) as executor:
                    worker = executor.submit(web_app._run_query_task, self.task_id, "offline cleanup canary")
                    deadline = time.monotonic() + 5
                    while self.task_id not in web_app._RETRIEVAL_PROCESSES and time.monotonic() < deadline:
                        time.sleep(0.03)
                    self.assertIn(self.task_id, web_app._RETRIEVAL_PROCESSES)
                    response = web_app.app.test_client().post(f"/api/tasks/{self.task_id}/cancel")
                    self.assertEqual(response.status_code, 200)
                    worker.result(timeout=8)
            self.assertEqual(web_app.TASKS[self.task_id]["status"], "cancelled")
            self.assert_tree_stopped()
            self.assertIsNone(unrelated.poll())
        finally:
            unrelated.terminate()
            unrelated.wait(timeout=5)

    def test_cancel_before_registration_stops_real_tree(self):
        def spawn_and_cancel(command, stream):
            process = self.spawn_fixture(command, stream)
            web_app._cancel_task(self.task_id)
            return process
        with patch.object(web_app, "_spawn_research_process", side_effect=spawn_and_cancel):
            web_app._run_query_task(self.task_id, "offline cleanup canary")
        self.assertEqual(web_app.TASKS[self.task_id]["status"], "cancelled")
        self.assertTrue(web_app.TASKS[self.task_id]["cancellation"]["late_spawn_termination_requested"])
        self.assert_tree_stopped()

    def test_worker_wait_exception_stops_real_tree(self):
        def spawn_then_fail(command, stream):
            process = self.spawn_fixture(command, stream)
            original_wait = process.wait
            first = [True]
            def wait(timeout):
                if first:
                    first.pop()
                    raise RuntimeError("private-token C:/private/file")
                return original_wait(timeout=timeout)
            process.wait = wait
            return process
        with patch.object(web_app, "_spawn_research_process", side_effect=spawn_then_fail):
            web_app._run_query_task(self.task_id, "offline cleanup canary")
        task = web_app.TASKS[self.task_id]
        self.assertEqual(task["status"], "failed")
        self.assertEqual(task["execution"]["failure_stage"], "research_worker")
        self.assertNotIn("private-token", json.dumps(task))
        self.assert_tree_stopped()
