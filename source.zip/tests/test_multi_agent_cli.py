from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_cli_mock_run_inspect_and_replay(tmp_path):
    command = [sys.executable, str(ROOT / "tools" / "multi_agent_cli.py"), "run",
               "--query", "mock question", "--mode", "mock", "--run-id", "run-test",
               "--output-root", str(tmp_path)]
    completed = subprocess.run(command, cwd=ROOT, text=True, capture_output=True, timeout=30)
    assert completed.returncode == 0, completed.stderr
    run_dir = tmp_path / "run-test"
    for name in ("manifest.json", "events.jsonl", "workflow.sqlite3", "final_answer.md",
                 "final_answer.html", "references.json", "claim_evidence_map.json",
                 "evidence_ledger.json", "citation_audit.json", "run_report.md", "console.log"):
        assert (run_dir / name).is_file(), name
    for name in ("agents", "tools", "rework_tickets", "artifacts"):
        assert (run_dir / name).is_dir(), name
    report = (run_dir / "final_answer.html").read_text(encoding="utf-8")
    assert 'href="#evidence-1"' in report
    assert 'id="evidence-1"' in report
    inspected = subprocess.run([sys.executable, str(ROOT / "tools" / "multi_agent_cli.py"), "inspect",
                                "--run-dir", str(run_dir)], cwd=ROOT, text=True, capture_output=True, timeout=30)
    assert inspected.returncode == 0
    assert json.loads(inspected.stdout)["run"]["model_calls_used"] == 5
    replay = subprocess.run([sys.executable, str(ROOT / "tools" / "multi_agent_cli.py"), "replay",
                             "--run-dir", str(run_dir)], cwd=ROOT, text=True, capture_output=True, timeout=30)
    assert replay.returncode == 0
    # Re-run a role against the exact recorded structured inputs, not a chat log.
    role_output = tmp_path / "reviewer-repeat"
    repeated = subprocess.run([
        sys.executable, str(ROOT / "tools" / "multi_agent_cli.py"), "agent",
        "--mode", "mock", "--role", "reviewer", "--from-run", str(run_dir),
        "--call-number", "3", "--output-dir", str(role_output),
    ], cwd=ROOT, text=True, capture_output=True, timeout=30)
    assert repeated.returncode == 0, repeated.stderr
    source_call = json.loads((run_dir / "agents" / "03-reviewer.json").read_text(encoding="utf-8"))
    source_payloads = [json.loads((run_dir / "artifacts" / f"{key}.json").read_text(encoding="utf-8"))
                       for key in source_call["input"]["input_artifact_ids"]]
    repeated_payloads = [json.loads(path.read_text(encoding="utf-8"))
                         for path in (role_output / "artifacts").glob("agent-input-data-*.json")]
    assert sorted(map(lambda item: json.dumps(item, sort_keys=True), source_payloads)) == sorted(
        map(lambda item: json.dumps(item, sort_keys=True), repeated_payloads))


def test_cli_live_rejects_invalid_configuration_before_calls(tmp_path):
    completed = subprocess.run([sys.executable, str(ROOT / "tools" / "multi_agent_cli.py"), "run",
                                "--query", "q", "--mode", "live", "--output-root", str(tmp_path),
                                "--rag-mode", "lexical", "--storage-root", str(tmp_path / "storage")],
                               cwd=ROOT, text=True, capture_output=True, timeout=30,
                               env={**os.environ, "MODEL_REQUEST_URL": "invalid-model-endpoint"})
    assert completed.returncode == 2
    assert "LIVE_CONFIGURATION_INVALID" in completed.stdout


def test_cli_can_execute_each_agent_contract_independently(tmp_path):
    input_path = tmp_path / "input.json"
    input_path.write_text('{"question":"test"}', encoding="utf-8")
    for role in ("planner", "retriever", "reviewer", "gap_analyst", "writer", "citation_auditor"):
        output = tmp_path / role
        completed = subprocess.run([
            sys.executable, str(ROOT / "tools" / "multi_agent_cli.py"), "agent",
            "--role", role, "--input-json", str(input_path), "--output-dir", str(output),
            "--run-id", f"run-{role.replace('_', '-')}",
        ], cwd=ROOT, text=True, capture_output=True, timeout=30)
        assert completed.returncode == 0, completed.stderr
        assert json.loads((output / "agent_result.json").read_text(encoding="utf-8"))["status"] == "completed"
