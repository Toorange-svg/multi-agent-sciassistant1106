"""Regression of ba192's observable contracts, without model/network or old-run writes."""
from copy import deepcopy
import json

import pytest

from multi_agent_quality import AUDIT_SCHEMA, answer_requirements, check_audit, publication_rejections
from multi_agent_pipeline_v2 import check_review, ReviewContractError, prioritize_named_entity_actions
from multi_agent_status import describe_status


def draft():
    return {"direct_answer": "Definitions", "claims": [
        {"claim_id": "c1", "text": "Definition", "evidence_ids": ["e1"]},
        {"claim_id": "c2", "text": "Relationship", "evidence_ids": ["e2"]},
        {"claim_id": "c3", "text": "Ambiguous numeric attribution", "evidence_ids": ["e3"]}]}


def audit():
    return {"schema_version": AUDIT_SCHEMA, "status": "needs_revision", "rejected_claim_ids": ["c3"],
            "issues": [{"claim_id": "c3", "reason_code": "UNSUPPORTED_NUMBER"}],
            "claim_results": [{"claim_id": f"c{i}", "decision": "approved" if i < 3 else "rejected",
                               "reason_code": "SUPPORTED" if i < 3 else "UNSUPPORTED_NUMBER",
                               "detail": "Checked exact excerpt and attribution", "evidence_ids": [f"e{i}"]} for i in range(1, 4)]}


def test_explicit_partial_audit_retains_only_independently_approved_claims():
    assert check_audit(audit(), draft())["contract_errors"] == []
    assert publication_rejections(audit(), draft()) == {"c3"}


@pytest.mark.parametrize("mutation", [
    lambda a: a.update(status="passed"),
    lambda a: a.update(rejected_claim_ids=[]),
    lambda a: a.update(rejected_claim_ids=["c3", "c1"]),
    lambda a: a.update(issues=[]),
    lambda a: a["issues"].append({"claim_id": "c1", "reason_code": "SUPPORTED"}),
    lambda a: a["issues"].append({"claim_id": "c1", "reason_code": "UNSUPPORTED_NUMBER", "detail": "Supported. No issue."}),
    lambda a: a["claim_results"].pop(),
    lambda a: a["claim_results"].append(deepcopy(a["claim_results"][0])),
    lambda a: a["claim_results"][0].update(evidence_ids=["unknown"]),
    lambda a: a["claim_results"][0].update(detail=""),
    lambda a: a["claim_results"][0].update(decision="approved", reason_code="UNSUPPORTED_NUMBER"),
    lambda a: a["claim_results"][0].update(evidence_ids=[[]]),
    lambda a: a.update(rejected_claim_ids={"not": "ids"}),
    lambda a: a.update(issues=["not a row"]),
    lambda a: a["issues"][0].update(reason_code="CITATION_MISMATCH"),
])
def test_inconsistent_audit_blocks_all_instead_of_guessing_approval(mutation):
    data = audit()
    mutation(data)
    assert check_audit(data, draft())["contract_errors"]
    assert publication_rejections(data, draft()) == {"c1", "c2", "c3"}


def test_historical_ba192_mixed_supported_errors_and_empty_rejections_stays_blocked():
    old = {"schema_version": "sciassistant.citation-audit/v1", "status": "needs_revision", "rejected_claim_ids": [],
           "issues": [{"claim_id": "c1", "reason_code": "UNSUPPORTED_NUMBER", "detail": "Supported. No issue."}]}
    assert "AUDIT_LEGACY_AMBIGUOUS_ISSUE" in check_audit(old, draft())["contract_errors"]
    assert publication_rejections(old, draft()) == {"c1", "c2", "c3"}
    assert publication_rejections({"status": "passed"}, draft()) == set()  # old mock compatibility


def test_rejected_premise_removes_dependent_claim_but_not_independent_definition():
    data = draft()
    data["claims"][1]["depends_on_claim_ids"] = ["c3"]
    assert publication_rejections(audit(), data) == {"c2", "c3"}


def test_invalid_and_circular_claim_dependencies_are_code_rejected():
    from multi_agent_pipeline_v2 import check_draft
    data = draft()
    data["claims"][0]["depends_on_claim_ids"] = ["c2"]
    data["claims"][1]["depends_on_claim_ids"] = ["c1"]
    evidence = {"evidence": [{"evidence_id": f"e{i}"} for i in range(1, 4)]}
    assert {r["claim_id"] for r in check_draft(data, evidence) if r["reason"] == "INVALID_CLAIM_DEPENDENCY"} == {"c1", "c2"}
    data["claims"][0]["depends_on_claim_ids"] = [[]]
    assert any(r["reason"] == "INVALID_CLAIM_DEPENDENCY" for r in check_draft(data, evidence))
    assert publication_rejections(audit(), data) == {"c1", "c2", "c3"}


def review():
    return {"schema_version": "sciassistant.evidence-review/v3", "coverage_status": "partial",
            "allowed_evidence_ids": ["target"], "coverage": [], "decisions": [
                {"evidence_id": "target", "decision": "approved", "reason_code": "SUPPORTED",
                 "detail": "The excerpt defines XAIGID-RewardBench and its evaluator role.", "group_ids": ["g1"]},
                {"evidence_id": "background", "decision": "rejected", "reason_code": "IRRELEVANT",
                 "detail": "MineAgent does not define this named benchmark.", "group_ids": ["g1"]}]}


@pytest.mark.parametrize("mutation", [
    lambda r: r["decisions"].pop(),
    lambda r: r["decisions"][1].update(reason_code="REASON_NOT_PROVIDED"),
    lambda r: r["decisions"][0].update(detail=""),
    lambda r: r["decisions"][1].update(reason_code="SUPPORTED"),
    lambda r: r["decisions"][0].update(group_ids=["unknown"]),
])
def test_new_review_cannot_silently_omit_target_or_invent_rejection_reason(mutation):
    data = review()
    mutation(data)
    with pytest.raises(ReviewContractError):
        check_review(data, {"evidence": [{"evidence_id": "target"}, {"evidence_id": "background"}]}, {"g1"})


def test_explicit_definition_evidence_is_not_required_to_have_numeric_results():
    checked = check_review(review(), {"evidence": [{"evidence_id": "target"}, {"evidence_id": "background"}]}, {"g1"})
    assert checked["allowed_evidence_ids"] == ["target"]
    assert "defines XAIGID" in checked["decisions"][0]["detail"]


def test_followup_entities_intent_and_old_sources_are_only_revalidation_clues():
    q = "SOTA多模态大模型和XAIGID-RewardBench详细解释各自的定义以及二者的关系"
    req = answer_requirements(q, {"paper_ids": ["2511.12363v1"]})
    assert req["question_kind"] == "definition_relation"
    assert req["requested_dimensions"] == ["definition", "role", "relation"]
    assert req["explicit_entities"] == ["SOTA", "XAIGID-RewardBench"]
    plan = {"groups": [{"id": "g1", "question": "XAIGID-RewardBench定义", "core": ["XAIGID-RewardBench"]}]}
    actions = [{"request_id": "r1", "action": "request_arxiv_search", "arguments": {"group_id": "g1", "query": "MLLM judge accuracy"}}]
    changed, decisions = prioritize_named_entity_actions(plan, actions, req)
    assert changed[0]["arguments"]["query"] == '(ti:"XAIGID-RewardBench" OR abs:"XAIGID-RewardBench")'
    assert len(changed) == len(actions) and actions[0]["arguments"]["query"] == "MLLM judge accuracy"
    assert decisions and req["evidence_policy"] == "clues_only_retrieve_and_review_again"
    again, decisions = prioritize_named_entity_actions(plan, changed, req)
    assert again == changed and not decisions


def test_quantitative_question_is_not_reclassified_as_simple_definition():
    assert answer_requirements("PagedAttention是什么，降低多少延迟？")["question_kind"] == "quantitative"


def test_query_pinning_does_not_promote_generic_english_words_or_urls():
    from multi_agent_quality import distinctive_entities
    assert distinctive_entities(["definition", "throughput", "https", "SOTA", "MLLM", "PagedAttention", "XAIGID-RewardBench"]) == ["PagedAttention", "XAIGID-RewardBench"]


def test_status_explains_model_findings_and_protocol_failure_separately():
    data = audit()
    data["contract_errors"] = ["AUDIT_ISSUES_INCOMPLETE"]
    display = describe_status("needs_review", audit=data)
    assert any("c3" in item and "数字" in item for item in display["audit_findings"])
    assert any("相互矛盾" in item for item in display["audit_findings"])


def test_pipeline_receives_followup_clues_at_retrieval_and_review_and_preserves_safe_partial(tmp_path):
    from test_multi_agent_pipeline_v2 import agents, pipeline
    configured, calls = agents(partial=True)
    original_retriever = configured.retriever.handler
    original_reviewer = configured.reviewer.handler
    def inspect_inputs(handler, packet):
        payloads = [p["payload"] for p in packet["inputs"]]
        assert any(p.get("question") == "XAIGID-RewardBench是什么？" for p in payloads)
        assert any(p.get("previous_paper_ids") == ["2511.12363v1"] for p in payloads)
        return handler(packet)
    configured.retriever.handler = lambda p: inspect_inputs(original_retriever, p)
    configured.reviewer.handler = lambda p: inspect_inputs(original_reviewer, p)
    flow, _ = pipeline(tmp_path, configured)
    context = {"schema_version": "sciassistant.followup-context/v1", "previous_question": "AI detection?",
               "previous_answer": "Previous unverified summary", "paper_ids": ["2511.12363v1"],
               "evidence_policy": "context_only_retrieve_again"}
    result = flow.run("followup", "owner", "XAIGID-RewardBench是什么？", conversation_context=context)
    assert result["run"]["status"] == "partial" and result["run"]["model_calls_used"] == 5
    assert calls.count("writer") == calls.count("citation_auditor") == 1


def test_partial_publication_and_exports_share_exact_same_claim_mapping(tmp_path):
    from test_multi_agent_pipeline_v2 import agents, pipeline
    from multi_agent_report import export_run_report
    configured, calls = agents(partial=True)
    def writer(_packet):
        calls.append("writer")
        data = draft()
        for c in data["claims"]:
            c.update(evidence_ids=["arxiv-1"], confidence="low")
        data["claims"][-1]["text"] = "DO-NOT-PUBLISH"
        return {"output": data}
    def auditor(_packet):
        calls.append("citation_auditor")
        data = audit()
        for r in data["claim_results"]:
            r["evidence_ids"] = ["arxiv-1"]
        return {"output": data}
    configured.writer.handler, configured.citation_auditor.handler = writer, auditor
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("limited", "owner", "Define A")
    assert result["run"]["status"] == "needs_review"
    assert calls.count("writer") == calls.count("citation_auditor") == 2
    assert "Definition[1]" in result["direct_answer"] and "DO-NOT-PUBLISH" not in result["direct_answer"]
    export_run_report(tmp_path)
    mapping = json.loads((tmp_path / "claim_evidence_map.json").read_text())
    assert {c["claim_id"] for c in mapping} == {"c1", "c2"}
    diagnostic = json.loads((tmp_path / "evidence_flow_diagnostics.json").read_text(encoding="utf-8"))
    assert diagnostic["counts"]["published_claims"] == 2
    assert diagnostic["claims"][-1]["published"] is False
    assert "DO-NOT-PUBLISH" not in (tmp_path / "final_answer.html").read_text(encoding="utf-8")


def test_initial_incomplete_review_gets_only_one_budgeted_repair(tmp_path):
    from test_multi_agent_pipeline_v2 import agents, pipeline
    configured, calls = agents(partial=True)
    original = configured.reviewer.handler
    attempts = []
    def reviewer(packet):
        data = original(packet)
        attempts.append(1)
        data["output"]["schema_version"] = "sciassistant.evidence-review/v3"
        if len(attempts) == 2:
            assert any(p["payload"].get("reason_code") == "REVIEW_DECISIONS_INCOMPLETE" for p in packet["inputs"])
            data["output"]["decisions"] = [{"evidence_id": "arxiv-1", "decision": "approved",
                "reason_code": "SUPPORTED", "detail": "This excerpt supports the definition", "group_ids": ["g1"]}]
        return data
    configured.reviewer.handler = reviewer
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("review-repair", "owner", "Define A")
    assert result["run"]["status"] == "partial" and len(attempts) == 2
    assert result["run"]["model_calls_used"] == 6
    assert "REVIEW_DECISIONS_INCOMPLETE" in (tmp_path / "events.jsonl").read_text()


def test_writer_revision_closes_specific_audit_issue_without_approving_old_rejected_number(tmp_path):
    from test_multi_agent_pipeline_v2 import agents, pipeline
    configured, calls = agents(partial=True)
    iterations = []
    def writer(packet):
        calls.append("writer")
        iterations.append(1)
        data = draft()
        if len(iterations) == 2:
            feedback = next(p["payload"] for p in packet["inputs"] if p["payload"].get("schema_version") == "sciassistant.citation-feedback/v1")
            assert feedback["model_audit"]["rejected_claim_ids"] == ["c3"]
            data["claims"] = data["claims"][:2]
        for c in data["claims"]:
            c.update(evidence_ids=["arxiv-1"], confidence="low")
        return {"output": data}
    def auditor(packet):
        calls.append("citation_auditor")
        data = audit()
        if len(iterations) == 2:
            data.update(status="passed", rejected_claim_ids=[], issues=[], claim_results=data["claim_results"][:2])
        for r in data["claim_results"]:
            r["evidence_ids"] = ["arxiv-1"]
        return {"output": data}
    configured.writer.handler, configured.citation_auditor.handler = writer, auditor
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("issue-closed", "owner", "Define A")
    assert result["run"]["status"] == "partial" and result["run"]["model_calls_used"] == 7
    assert "Ambiguous numeric attribution" not in result["direct_answer"]
    assert calls.count("writer") == calls.count("citation_auditor") == 2


def test_second_incomplete_review_is_not_automatically_approved(tmp_path):
    from test_multi_agent_pipeline_v2 import agents, pipeline
    configured, calls = agents()
    original = configured.reviewer.handler
    def reviewer(packet):
        data = original(packet)
        data["output"]["schema_version"] = "sciassistant.evidence-review/v3"
        return data
    configured.reviewer.handler = reviewer
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("invalid-review", "owner", "Define A")
    assert result["run"]["status"] == "failed"
    assert result["run"]["failure_code"] == "REVIEW_DECISIONS_INCOMPLETE"
    assert calls.count("reviewer") == 2 and "writer" not in calls


def test_previously_cited_sources_do_not_override_current_named_entity_relevance(tmp_path):
    from multi_agent_live import LiveArxivRagExecutor
    executor = LiveArxivRagExecutor(tmp_path / "run", tmp_path / "storage", rag_mode="lexical")
    executor.configure_plan({"groups": [{"id": "g1", "core": ["XAIGID-RewardBench"]}]})
    executor.configure_source_clues(answer_requirements("XAIGID-RewardBench是什么？", {"paper_ids": ["2511.12363v1", "2412.17339v1"]}))
    executor.group_queries = {"g1": ["XAIGID-RewardBench"]}
    executor.candidates = {
        "2412.17339": {"paper_id": "2412.17339v1", "title": "MineAgent", "excerpt": "Mining task agents", "group_ids": ["g1"]},
        "2511.12363": {"paper_id": "2511.12363v1", "title": "RewardBench", "excerpt": "XAIGID-RewardBench evaluates explanations", "group_ids": ["g1"]}}
    queue = executor._reading_queue()
    assert queue[0][2]["paper_id"] == "2511.12363v1"
    assert executor.pdf_reads == 0 and executor.ingested == set()
