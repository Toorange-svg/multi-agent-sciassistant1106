import importlib.util
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('source_publication', ROOT / 'agpl_sources_development_20261025/publish_release.py')
publisher = importlib.util.module_from_spec(spec)
spec.loader.exec_module(publisher)


def test_publication_targets_only_clean_repository_and_reviewed_asset():
    assert publisher.REPO == 'Toorange-svg/multi-agent-sciassistant'
    assert publisher.TAG == 'sources-a3ce456'
    assert publisher.SHA == '54c8b7ae55d7aec6a5ff92114585192d4ac552bbbdad05ff39731263125cc5d0'
    assert 'sci1.0' not in publisher.API
    assert 'automatically generated Source code ZIP' in publisher.README


def test_credential_is_not_sent_to_unexpected_host(monkeypatch):
    monkeypatch.setattr(publisher.urllib.request, 'urlopen', lambda *a, **k: pytest.fail('unexpected network'))
    with pytest.raises(ValueError, match='UNEXPECTED_GITHUB_API_HOST'):
        publisher.request('https://example.invalid/upload', 'test-only-secret')


def test_wrong_archive_cannot_trigger_publication(tmp_path, monkeypatch):
    source = tmp_path / 'wrong.zip'
    source.write_bytes(b'unreviewed')
    monkeypatch.setattr(publisher, 'ARCHIVE', source)
    monkeypatch.setattr(publisher, 'credentials', lambda: pytest.fail('credentials requested before hash check'))
    with pytest.raises(ValueError, match='REVIEWED_ARCHIVE_HASH_MISMATCH'):
        publisher.publish()


def test_existing_readme_is_not_silently_overwritten(tmp_path, monkeypatch):
    import base64
    import hashlib
    source = tmp_path / 'reviewed.zip'
    source.write_bytes(b'reviewed')
    monkeypatch.setattr(publisher, 'ARCHIVE', source)
    monkeypatch.setattr(publisher, 'SHA', hashlib.sha256(b'reviewed').hexdigest())
    monkeypatch.setattr(publisher, 'credentials', lambda: 'test-only-secret')
    calls = []

    def request(url, token, *args, **kwargs):
        calls.append(url)
        assert not args and not kwargs
        return {'private': False, 'full_name': publisher.REPO, 'permissions': {'push': True}}

    monkeypatch.setattr(publisher, 'request', request)
    monkeypatch.setattr(publisher, 'optional', lambda *a: {'content': base64.b64encode(b'other work').decode()})
    with pytest.raises(ValueError, match='EXISTING_README_DIFFERS'):
        publisher.publish()
    assert calls == [publisher.API]
