"""Real PowerShell parser and pure safety checks; no live process is terminated."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

import pytest

ROOT = Path(__file__).resolve().parents[1]
PS = shutil.which("powershell.exe") or shutil.which("pwsh")


def powershell(command):
    if not PS or os.name != "nt":
        pytest.skip("Windows PowerShell checks")
    proc = subprocess.run([PS, "-NoProfile", "-Command", command], capture_output=True,
                          text=True, encoding="utf-8", errors="replace", timeout=25, cwd=ROOT)
    assert proc.returncode == 0, proc.stderr + proc.stdout
    return proc.stdout


def test_launcher_and_safety_helper_parse():
    result = powershell(r'''
    $count=0
    foreach($path in @('bin/windows/start_chat_5000.ps1','bin/windows/chat_service_safety.ps1')) {
        $tokens=$null; $errors=$null
        [System.Management.Automation.Language.Parser]::ParseFile((Resolve-Path $path),[ref]$tokens,[ref]$errors)|Out-Null
        $count += $errors.Count
    }
    @{errors=$count}|ConvertTo-Json -Compress
    ''')
    assert json.loads(result)["errors"] == 0


def test_process_scope_and_action_matrix():
    result = powershell(r'''
    . ./bin/windows/chat_service_safety.ps1
    $root='C:\projects\multi agent'
    $python='"C:\projects\multi agent\venv\Scripts\python.exe"'
    $good=[pscustomobject]@{Name='python.exe';CommandLine=($python+' "C:\projects\multi agent\app.py"')}
    $wrong=[pscustomobject]@{Name='python.exe';CommandLine=($python+' "C:\projects\other\app.py"')}
    $relative=[pscustomobject]@{Name='python.exe';CommandLine=($python+' .\app.py')}
    $inline=[pscustomobject]@{Name='python.exe';CommandLine=($python+' -c "C:\projects\multi agent\app.py"')}
    [ordered]@{good=(Test-GatewayProcess $good $root);wrong=(Test-GatewayProcess $wrong $root);
        relative=(Test-GatewayProcess $relative $root);inline=(Test-GatewayProcess $inline $root);
        missing=(Get-GatewayAction $false $false $false $false $false);
        reuse=(Get-GatewayAction $true $true $true $false $true);
        stale=(Get-GatewayAction $true $true $false $false $false);
        foreign=(Get-GatewayAction $true $false $true $true $false);
        active=(Get-GatewayAction $true $true $false $true $true);
        restart=(Get-GatewayAction $true $true $false $true $false)}|ConvertTo-Json -Compress
    ''')
    result = json.loads(result)
    assert result == {"good": True, "wrong": False, "relative": False, "inline": False,
        "missing": "start", "reuse": "reuse", "stale": "refuse_stale_version",
        "foreign": "refuse_foreign_or_ambiguous", "active": "refuse_active_tasks", "restart": "restart"}


def test_one_click_update_only_restarts_confirmed_idle_stale_gateway():
    result = powershell(r'''
    . ./bin/windows/chat_service_safety.ps1
    [ordered]@{
        idle_stale=(Get-GatewayAction $true $true $false $false $false $true);
        active_stale=(Get-GatewayAction $true $true $false $false $true $true);
        active_current=(Get-GatewayAction $true $true $true $false $true $true);
        foreign_stale=(Get-GatewayAction $true $false $false $false $false $true);
        foreign_current=(Get-GatewayAction $true $false $true $false $false $true);
        missing=(Get-GatewayAction $false $false $false $false $false $true)
    }|ConvertTo-Json -Compress
    ''')
    assert json.loads(result) == {
        "idle_stale": "restart", "active_stale": "refuse_active_tasks",
        "active_current": "reuse", "foreign_stale": "refuse_foreign_or_ambiguous",
        "foreign_current": "refuse_foreign_or_ambiguous", "missing": "start",
    }


def _isolated_launcher(tmp_path):
    scripts = tmp_path / "bin" / "windows"
    scripts.mkdir(parents=True)
    for name in ("start_chat_5000.ps1", "chat_service_safety.ps1"):
        shutil.copyfile(ROOT / "bin/windows" / name, scripts / name)
    return scripts / "start_chat_5000.ps1"


def test_double_click_lock_prevents_second_launcher_from_migrating_or_starting(tmp_path):
    launcher = _isolated_launcher(tmp_path)
    logs = tmp_path / "logs"
    logs.mkdir()
    quoted = lambda value: "'" + str(value).replace("'", "''") + "'"
    result = powershell(f'''
    $env:SCIASSISTANT_PYTHON={quoted(sys.executable)}
    $lock=[IO.File]::Open({quoted(logs / 'chat_5000_launcher.lock')},
        [IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    try {{
        $messages = & {quoted(PS or 'powershell.exe')} -NoProfile -File {quoted(launcher)} -UpdateIfIdle -NoBrowser 2>&1
        $code=$LASTEXITCODE
    }} finally {{ $lock.Dispose() }}
    @{{exit_code=$code}}|ConvertTo-Json -Compress
    ''')
    assert json.loads(result)["exit_code"] == 2
    assert sorted(p.name for p in logs.iterdir()) == ["chat_5000_launcher.lock"]


def test_missing_environment_has_plain_error_without_powershell_stack(tmp_path):
    if not PS or os.name != "nt":
        pytest.skip("Windows PowerShell")
    launcher = _isolated_launcher(tmp_path)
    env = {**os.environ, "SCIASSISTANT_PYTHON": str(tmp_path / "missing.exe")}
    proc = subprocess.run([PS, "-NoProfile", "-File", str(launcher), "-UpdateIfIdle", "-NoBrowser"],
                          capture_output=True, text=True, encoding="utf-8", errors="replace",
                          timeout=25, cwd=tmp_path, env=env)
    assert proc.returncode == 1
    assert "setup_windows.cmd" in proc.stdout
    assert "CategoryInfo" not in proc.stdout + proc.stderr
    assert "FullyQualifiedErrorId" not in proc.stdout + proc.stderr
    assert not (tmp_path / "logs").exists()


@pytest.mark.parametrize("payload,expected", [('{"status":"partial"}', False),
    ('{"status":"running"}', True), ('{"status":"needs_clarification"}', True), ('{"status":"unknown"}', True), ('invalid', True)])
def test_active_task_guard_with_actual_snapshots(tmp_path, payload, expected):
    (tmp_path / "task.json").write_text(payload, encoding="utf-8-sig")
    directory = str(tmp_path).replace("'", "''")
    result = powershell(". ./bin/windows/chat_service_safety.ps1; @{active=(Test-ActiveTaskSnapshots '" + directory + "')}|ConvertTo-Json -Compress")
    assert json.loads(result)["active"] is expected


def test_environment_only_does_not_run_schema_or_services():
    proc = subprocess.run([PS, "-NoProfile", "-File", str(ROOT / "bin/windows/start_chat_5000.ps1"), "-CheckEnvironmentOnly"],
                          capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=25, cwd=ROOT) if PS and os.name == "nt" else None
    if proc is None:
        pytest.skip("Windows PowerShell")
    assert proc.returncode == 0, proc.stderr
    assert "Environment check passed. No service was started." in proc.stdout
    assert "Checking account database schema" not in proc.stdout


def test_multiagent_batch_wrapper_environment_check_without_false_started_message():
    if os.name != "nt":
        pytest.skip("Windows batch launcher")
    proc = subprocess.run(["cmd.exe", "/d", "/c", "start_multiagent_web.cmd", "-CheckEnvironmentOnly"],
                          input="\n", capture_output=True, text=True, encoding="utf-8", errors="replace",
                          timeout=25, cwd=ROOT)
    assert proc.returncode == 0, proc.stderr
    assert "Environment check passed. No service was started." in proc.stdout
    assert "5000 聊天网页已启动" not in proc.stdout
    assert "Checking account database schema" not in proc.stdout


def test_no_wildcard_kill_or_mcp_restart_and_absolute_launch():
    source = (ROOT / "bin/windows/start_chat_5000.ps1").read_text(encoding="utf-8")
    assert 'Stop-ProjectProcesses' not in source and 'Stop-ListeningProcess' not in source
    assert source.count('Stop-Process -Id') == 1 and 'Stop-Process -Id $fresh.ProcessId' in source
    assert '$fresh.CreationDate -ne $owner.CreationDate' in source
    assert 'Start-Process -FilePath $Python -WindowStyle Hidden' in source
    assert "(Join-Path $Root 'app.py')" in source
    assert 'api/readyz' in source and '-MaximumRedirection 0' in source
    assert '[switch]$StatusOnly' in source and '[switch]$RestartGateway' in source
