"""Read-only probe: how is_limitation_query classifies question forms.

Calls only existing functions. It changes no decision logic and writes no
state; it prints which LIMITATION_QUERY_TERMS term fired for each input so the
"challenges" versus "limitations" distinction can be measured before any
change to the gate is considered.

    venv\\Scripts\\python.exe tests\\probes\\probe_limitation_terms.py
"""
from __future__ import annotations

import sys
from pathlib import Path

# This file lives in tests/probes/, two levels below the repository root.
ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from deepdiver_v2.src.query_router import (  # noqa: E402
    LIMITATION_QUERY_TERMS,
    _has_direct_architecture_limitation,
    is_limitation_query,
    requested_concepts,
)

# Inputs named in the task, plus controls that show where the boundary sits.
PROBES = [
    # The fixture under investigation.
    ("What are the key challenges of retrieval augmented generation?", "fixture: expected accept"),
    # The same question phrased with an explicit limitation word.
    ("What are the limitations of RAG?", "control: explicit limitation"),
    # Chinese forms.
    ("Transformer 的局限性有哪些？", "fixture: Chinese + ASCII term"),
    ("Transformer 有哪些不足？", "control: Chinese, no ASCII term"),
    # Architecturally identical to the first, but with a named architecture.
    ("What are the challenges of Transformer?", "control: challenges + named arch"),
    # No requested concept at all, so the gate cannot fire.
    ("What are the key challenges of climate modelling?", "control: no concept alias"),
    # Positive controls that must keep firing.
    ("Explain the limitations of the Transformer architecture", "fixture: must stay limitation"),
    ("Representational Strengths and Limitations of Transformers", "fixture: must stay limitation"),
    ("根据 arXiv 上的文章解释 CNN 的局限性", "fixture: must stay limitation"),
]


def matched_terms(query: str) -> list[str]:
    lowered = str(query or "").lower()
    return [term for term in LIMITATION_QUERY_TERMS if term in lowered]


def main() -> int:
    print("=" * 100)
    print("PROBE: is_limitation_query classification (read-only)")
    print("=" * 100)
    print(f"LIMITATION_QUERY_TERMS ({len(LIMITATION_QUERY_TERMS)} entries):")
    print(f"  {LIMITATION_QUERY_TERMS}")
    print()
    print(f"{'is_limitation':<14} {'concepts':<22} {'fired':<22} query")
    print("-" * 100)
    for query, label in PROBES:
        fired = matched_terms(query)
        concepts = sorted(requested_concepts(query))
        flag = is_limitation_query(query)
        print(f"{str(flag):<14} {','.join(concepts) or '-':<22} {','.join(fired) or '-':<22} {query}")
        print(f"{'':<14} {'':<22} {'':<22} [{label}]")
    print()
    print("=" * 100)
    print("PROBE: does the strict limitation path reject an otherwise-accepted paper?")
    print("=" * 100)
    paper = (
        "unifying retrieval and generation: a survey on rag in nlp "
        "this survey covers retrieval augmented generation in natural language processing."
    )
    for query, _label in PROBES[:5]:
        requested = sorted(requested_concepts(query))
        strict = _has_direct_architecture_limitation(paper, requested)
        print(
            f"  is_limitation={str(is_limitation_query(query)):<6} "
            f"strict_path_passes={str(strict):<6} {query[:60]}"
        )
    print()
    print(
        "A row showing is_limitation=True together with strict_path_passes=False\n"
        "is a paper the strict limitation gate would reject."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
