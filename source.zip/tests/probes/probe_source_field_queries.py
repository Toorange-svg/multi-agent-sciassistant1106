"""Read-only probe: do HAL and Zenodo support field-scoped queries?

Requirement 3 is conditional: use field limits only where the platform
actually supports them. This measures hit counts and top titles for free-text
versus field-scoped syntax so the decision is based on observed behaviour
rather than on an assumption about each platform's query language.

    venv\\Scripts\\python.exe tests\\probes\\probe_source_field_queries.py
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

USER_AGENT = "SciAssistant-literature-gateway/1.0"
TERM = "world models"

HAL_URL = "https://api.archives-ouvertes.fr/search/"
ZENODO_URL = "https://zenodo.org/api/records"

HAL_VARIANTS = [
    ("free text", TERM),
    ("title_t:(...)", f"title_t:({TERM})"),
    ("title_t + abstract_t", f"title_t:({TERM}) OR abstract_t:({TERM})"),
    ('title_t:"..."', f'title_t:"{TERM}"'),
    ("text_t:(...)", f"text_t:({TERM})"),
]

ZENODO_VARIANTS = [
    ("free text", TERM),
    ('title:"..."', f'title:"{TERM}"'),
    ("title:(...)", f"title:({TERM})"),
    ('title + description', f'title:({TERM}) OR description:({TERM})'),
]


def fetch(url: str, params: dict) -> tuple[int, str, object]:
    try:
        response = requests.get(
            url, params=params,
            headers={"User-Agent": USER_AGENT, "Accept": "application/json"},
            timeout=20,
        )
        return response.status_code, "", response
    except requests.RequestException as exc:
        return 0, f"{type(exc).__name__}: {exc}", None


def hal_probe() -> None:
    print("=" * 92)
    print("HAL - api.archives-ouvertes.fr (Solr-based)")
    print("=" * 92)
    for label, query in HAL_VARIANTS:
        status, err, response = fetch(HAL_URL, {
            "q": query, "wt": "json", "rows": 5,
            "fl": "docid,title_s,producedDateY_i",
        })
        if response is None:
            print(f"  {label:<24} TRANSPORT ERROR {err}")
            time.sleep(2)
            continue
        try:
            body = response.json()
            docs = (body.get("response") or {}).get("docs") or []
            total = (body.get("response") or {}).get("numFound")
        except Exception:
            docs, total = [], None
            print(f"  {label:<24} HTTP {status} NON-JSON: {response.text[:120]!r}")
            time.sleep(2)
            continue
        print(f"  {label:<24} HTTP {status}  numFound={total}  returned={len(docs)}")
        for doc in docs[:2]:
            title = doc.get("title_s")
            if isinstance(title, list):
                title = title[0] if title else ""
            print(f"        - {str(title)[:74]}")
        time.sleep(2)


def zenodo_probe() -> None:
    print()
    print("=" * 92)
    print("ZENODO - zenodo.org/api/records (Elasticsearch-backed)")
    print("=" * 92)
    for label, query in ZENODO_VARIANTS:
        status, err, response = fetch(ZENODO_URL, {
            "q": query, "size": 5, "sort": "bestmatch",
        })
        if response is None:
            print(f"  {label:<24} TRANSPORT ERROR {err}")
            time.sleep(2)
            continue
        try:
            body = response.json()
        except Exception:
            print(f"  {label:<24} HTTP {status} NON-JSON: {response.text[:120]!r}")
            time.sleep(2)
            continue
        hits = (body.get("hits") or {})
        docs = hits.get("hits") or []
        print(f"  {label:<24} HTTP {status}  total={hits.get('total')}  returned={len(docs)}")
        for doc in docs[:2]:
            meta = doc.get("metadata") or {}
            print(f"        - {str(meta.get('title'))[:74]}")
        time.sleep(2)


def techrxiv_probe() -> None:
    print()
    print("=" * 92)
    print("TECHRXIV - current block status")
    print("=" * 92)
    for url in ("https://www.techrxiv.org/search", "https://techrxiv.org/search"):
        status, err, response = fetch(url, {"q": TERM})
        if response is None:
            print(f"  {url:<44} TRANSPORT ERROR {err}")
        else:
            print(f"  {url:<44} HTTP {status}")
        time.sleep(2)


if __name__ == "__main__":
    print(f"probe term: {TERM!r}")
    print()
    hal_probe()
    zenodo_probe()
    techrxiv_probe()
