"""Cloud parsing contract tests: isolated accounts, transport, geometry and CLI."""
import io
import json
import subprocess
import sys
import time
from pathlib import Path

import pytest
import app as account
import web_app as web
from test_multi_agent_local_pdf import pdf, gateway, headers, action
from multi_agent_local_pdf import LocalPdfRagExecutor, pdf_parser_options
from multi_agent_rag import build_chunks
from tools.multi_agent_parse_pdf import parse_document, cloud_blocks, DeadlineHttp
from user_credentials import ProviderCapability, provider_scope

ROOT = Path(__file__).resolve().parents[1]


def test_parser_client_import_does_not_load_legacy_agents_or_construct_mcp(tmp_path):
    source = ('import sys;sys.path.insert(0,'+repr(str(ROOT))+');'
              'from deepdiver_v2.src.tools.llama_vision_client import LlamaVisionClient;'
              'assert not any(n.endswith((".mcp_tools", ".mcp_server_standard", ".normalizer")) for n in sys.modules)')
    result = subprocess.run([sys.executable, '-I', '-c', source], cwd=tmp_path,
                            capture_output=True, timeout=15)
    assert result.returncode == 0, result.stderr.decode(errors='replace')


def test_real_cloud_client_uses_bounded_transport_verbs_for_complete_protocol(pdf, monkeypatch):
    """Do not inject cloud_parser: exercise the real client's HTTP interface."""
    import requests
    monkeypatch.setenv('LLAMA_CLOUD_API_KEY', 'llx-fixture-no-real-key')
    calls = []
    class Reply:
        status_code = 200
        def __init__(self, body): self.payload = json.dumps(body).encode()
        def iter_content(self, _size): return iter([self.payload])
        def json(self): return json.loads(self._content)
        def close(self): pass
    def request(_session, method, url, **kwargs):
        calls.append((method, url, kwargs))
        assert kwargs['verify'] and kwargs['allow_redirects'] is False and kwargs['timeout'] <= 15
        if method == 'post' and url.endswith('/files'): return Reply({'id': 'fixture-file'})
        if method == 'post' and url.endswith('/parse'): return Reply({'id': 'fixture-job'})
        if method == 'get':
            return Reply({'job': {'status': 'COMPLETED'}, 'markdown': {'pages': [
                {'page_number': 1, 'success': True, 'markdown': 'first page original text'},
                {'page_number': 2, 'success': True, 'markdown': 'second page original text'}]}})
        assert method == 'delete'
        return Reply({})
    monkeypatch.setattr(requests.Session, 'request', request)
    parsed = parse_document(pdf, 'llama_full', True, local_parser=local_result)
    assert parsed['success'] and parsed['parser_summary']['actual'] == 'llama_full'
    assert [item[0] for item in calls] == ['post', 'post', 'get', 'delete']
    assert [block['page'] for block in parsed['layout_blocks']] == [1, 2]
    assert all(block['bbox'] is None for block in parsed['layout_blocks'])


@pytest.mark.parametrize('verb', ['get', 'post', 'delete'])
def test_transport_verb_helpers_cannot_bypass_origin_guard(verb):
    transport = DeadlineHttp(time.monotonic()+2)
    try:
        with pytest.raises(ValueError, match='LLAMA_ENDPOINT_REJECTED'):
            getattr(transport, verb)('https://untrusted.invalid/private')
    finally:
        transport.close()


@pytest.mark.parametrize("mode", ["llama_full", "hybrid"])
@pytest.mark.parametrize("consent", [False, "true", 1, None])
def test_cloud_requires_actual_boolean_consent(mode, consent):
    with pytest.raises(ValueError):
        pdf_parser_options(True, mode, consent)


def test_no_pdf_no_cloud_and_mock_never_charges(tmp_path):
    with pytest.raises(ValueError, match="LLAMA_PDF_REQUIRED"):
        pdf_parser_options(False, "llama_full", True)
    assert pdf_parser_options(False)["pdf_parse_mode"] == "local"


def local_result(*args, **kwargs):
    return {"success": True, "layout_blocks": [
        {"page": 1, "text": "Native PagedAttention memory", "bbox": [1, 2, 30, 40]}]}


def cloud_result(*args, **kwargs):
    return {"status": "completed", "page_markdown": ["Cloud PagedAttention memory bounded scientific evidence", "Cloud throughput results"]}


@pytest.mark.parametrize("mode,expected", [("llama_full", 2), ("hybrid", 3)])
def test_cloud_page_only_and_hybrid_native_boxes(pdf, monkeypatch, mode, expected):
    monkeypatch.setenv("LLAMA_CLOUD_API_KEY", "llx-fixture-no-real-key")
    parsed = parse_document(pdf, mode, True, local_parser=local_result, cloud_parser=cloud_result)
    assert parsed["success"] and len(parsed["layout_blocks"]) == expected
    chunks = build_chunks("doc", "paper", "title", parsed["layout_blocks"])
    cloud = [row for row in chunks if row.get("parser_provenance")]
    assert len(cloud) == 2 and all(row["bbox"] is None for row in cloud)
    assert {row["page"] for row in cloud} == {1, 2}
    if mode == "hybrid":
        assert chunks[0]["bbox"] == [1, 2, 30, 40]


@pytest.mark.parametrize("pages", [None, [], ["one"], ["one", ""], ["a", "b", "c"], [4, 5]])
def test_cloud_must_preserve_complete_page_mapping(pages):
    with pytest.raises(ValueError, match="LLAMA_PAGE_MAPPING_INVALID"):
        cloud_blocks({"page_markdown": pages}, 2)


def test_hybrid_fallback_is_explicit_and_full_is_not_silent(pdf, monkeypatch):
    monkeypatch.setenv("LLAMA_CLOUD_API_KEY", "llx-fixture")
    def fail(*args, **kwargs):
        raise RuntimeError("secret-provider-error-/private/canary")
    hybrid = parse_document(pdf, "hybrid", True, local_parser=local_result, cloud_parser=fail)
    assert hybrid["success"] and hybrid["parser_summary"]["actual"] == "local"
    assert hybrid["parser_summary"]["warning_code"] == "LLAMA_PARSE_FAILED"
    full = parse_document(pdf, "llama_full", True, local_parser=local_result, cloud_parser=fail)
    assert full == {"success": False, "error_code": "LLAMA_PARSE_FAILED"}
    assert "canary" not in json.dumps([hybrid, full])


def test_owner_missing_key_never_uses_global_key(pdf, monkeypatch):
    monkeypatch.setenv("LLAMA_CLOUD_API_KEY", "llx-another-user")
    with provider_scope(ProviderCapability("bob", {})):
        parsed = parse_document(pdf, "hybrid", True,
            local_parser=lambda *a, **k: pytest.fail("missing account key must fail before parsing"),
            cloud_parser=lambda *a, **k: pytest.fail("must not call global provider"))
    assert parsed["error_code"] == "LLAMA_USER_KEY_REQUIRED"


@pytest.mark.parametrize("mode", ["llama_full", "hybrid"])
def test_gateway_cloud_propagates_and_reuse_needs_new_consent(gateway, pdf, mode):
    _, launched = gateway
    client = account.app.test_client()
    response = client.post("/api/science/tasks", headers=headers(), data={
        "query": "explain", "conversation_id": "chat-a", "processing_mode": "multi_agent_rag",
        "pdf_parse_mode": mode, "llama_cloud_consent": "true",
        "pdf": (io.BytesIO(pdf.read_bytes()), "source.pdf")})
    assert response.status_code == 202, response.json
    task = response.json["task"]
    assert task["pdf_parse_mode"] == mode and task["llama_cloud_consent"] is True
    assert launched[-1][0][1] is web._run_multi_agent_rag_task
    again = {"query": "followup", "conversation_id": "chat-a", "processing_mode": "multi_agent_rag",
        "pdf_parse_mode": mode, "pdf_source_task_id": task["id"]}
    assert client.post("/api/science/tasks", headers=headers(), json=again).json["error"] == "LLAMA_CLOUD_CONSENT_REQUIRED"
    assert client.post("/api/science/tasks", headers=headers("bob"), json=again).status_code == 404


def test_gateway_missing_real_user_llama_key(gateway, pdf, monkeypatch):
    monkeypatch.setattr(web, "_missing_task_configuration", lambda mode: ["LLAMA_CLOUD_API_KEY"])
    response = account.app.test_client().post("/api/science/tasks", headers=headers(), data={
        "query": "explain", "processing_mode": "multi_agent_rag", "pdf_parse_mode": "llama_full",
        "llama_cloud_consent": "true", "pdf": (io.BytesIO(pdf.read_bytes()), "source.pdf")})
    assert response.status_code == 400 and response.json["error_code"] == "USER_PROVIDER_KEY_REQUIRED"
    assert not gateway[1]


def test_web_command_carries_mode_not_key(pdf, tmp_path, monkeypatch):
    import multi_agent_web
    monkeypatch.setenv("SCIASSISTANT_MULTI_AGENT_WEB_RUN_ROOT", str(tmp_path / "runs"))
    command = multi_agent_web.command("abcdef012345", tmp_path / "q", pdf=pdf,
        pdf_parse_mode="hybrid", llama_cloud_consent=True)
    assert command[command.index("--pdf-parse-mode") + 1] == "hybrid"
    assert "--llama-cloud-consent" in command and not any("llx-" in v for v in command)


def test_fts_retains_cloud_provenance_without_native_bbox(pdf, tmp_path):
    result = {"success": True, "layout_blocks": cloud_blocks(cloud_result(), 2),
        "parser_summary": {"requested": "llama_full", "actual": "llama_full", "cloud_status": "completed"}}
    executor = LocalPdfRagExecutor(tmp_path / "run", pdf, rag_mode="lexical",
        pdf_parse_mode="llama_full", llama_cloud_consent=True, parse=lambda _: result)
    snapshot = executor.execute(action(), group_ids={"g1"}, deadline=time.monotonic() + 20)
    assert snapshot["evidence"]
    for item in snapshot["evidence"]:
        assert item["parser_provenance"]["original_review_required"] is True
        assert item["locator"]["page"] in {1, 2} and item["locator"]["bbox"] is None
    assert executor.reading_summary()["parser_summary"]["actual"] == "llama_full"


@pytest.mark.parametrize("url", ["http://api.cloud.llamaindex.ai/test", "https://evil.invalid/test",
    "https://api.cloud.llamaindex.ai@evil.invalid/test", "https://api.cloud.llamaindex.ai:444/test"])
def test_transport_rejects_other_origins(url):
    http = DeadlineHttp(time.monotonic() + 5)
    try:
        with pytest.raises(ValueError, match="LLAMA_ENDPOINT_REJECTED"):
            http.request("get", url)
    finally:
        http.close()


def test_cli_rejects_cloud_in_mock_before_run_creation(pdf, tmp_path):
    command = [sys.executable, str(ROOT / "tools/multi_agent_cli.py"), "run", "--mode", "mock",
        "--pdf", str(pdf), "--pdf-parse-mode", "hybrid", "--llama-cloud-consent",
        "--query", "explain", "--output-root", str(tmp_path / "runs")]
    result = subprocess.run(command, capture_output=True, timeout=20)
    assert result.returncode == 2 and not (tmp_path / "runs").exists()


def test_official_v2_page_structure_and_bad_page_numbers():
    from deepdiver_v2.src.tools.llama_vision_client import _extract_page_markdown
    pages = [{"page_number": 1, "success": True, "markdown": "first"},
             {"page_number": 2, "success": True, "markdown": "second"}]
    assert _extract_page_markdown({"markdown": {"pages": pages}}) == ["first", "second"]
    assert not _extract_page_markdown({"markdown": {"pages": list(reversed(pages))}})
    pages[1]["success"] = False
    assert not _extract_page_markdown({"markdown": {"pages": pages}})


def test_transport_deadline_redirect_and_body_limit(monkeypatch):
    class Reply:
        status_code = 302
        closed = False
        def iter_content(self, _): return iter([b"{}"])
        def close(self): self.closed = True
    http = DeadlineHttp(time.monotonic() + 5)
    reply, calls = Reply(), []
    monkeypatch.setattr(http.session, "request", lambda *a, **k: (calls.append(k) or reply))
    try:
        with pytest.raises(ValueError, match="LLAMA_REDIRECT_REJECTED"):
            http.request("get", "https://api.cloud.llamaindex.ai/api/v2/parse/job")
        assert reply.closed and calls[0]["verify"] and not calls[0]["allow_redirects"]
        assert calls[0]["timeout"] <= 5 and http.session.trust_env is False
        reply.status_code = 200
        reply.iter_content = lambda _: iter([b"x" * (8 * 1024 * 1024 + 1)])
        with pytest.raises(ValueError, match="LLAMA_RESPONSE_LIMIT"):
            http.request("get", "https://api.cloud.llamaindex.ai/api/v2/parse/job")
        http.deadline = time.monotonic() - 1
        with pytest.raises(TimeoutError):
            http.request("get", "https://api.cloud.llamaindex.ai/api/v2/parse/job")
    finally:
        http.close()


def test_cloud_six_roles_and_exports_keep_provenance(pdf, tmp_path):
    from tools.multi_agent_cli import _mock_agents
    from multi_agent_agents import ArtifactDirectory
    from multi_agent_pipeline_v2 import LiteraturePipelineV2
    from multi_agent_workflow import WorkflowStore
    from multi_agent_report import export_run_report
    run = tmp_path / "run"
    executor = LocalPdfRagExecutor(run, pdf, rag_mode="lexical", pdf_parse_mode="llama_full",
        llama_cloud_consent=True, parse=lambda _: {"success": True,
            "layout_blocks": cloud_blocks(cloud_result(), 2)})
    artifacts = ArtifactDirectory(run / "artifacts")
    pipeline = LiteraturePipelineV2(WorkflowStore(run / "workflow.sqlite3"), artifacts,
        _mock_agents(source_scope="uploaded_pdf"), executor, event_path=run / "events.jsonl")
    result = pipeline.run("cloud-test", "alice", "PagedAttention memory throughput")
    assert result["run"]["status"] == "partial"
    roles = [json.loads(line).get("role") for line in (run / "events.jsonl").read_text().splitlines()
             if json.loads(line).get("event") == "agent_started"]
    assert roles == ["planner", "retriever", "reviewer", "writer", "citation_auditor"]
    (run / "manifest.json").write_text(json.dumps({"run_id": "cloud-test",
        "report_presentation_policy": "evidence-sidebar-compact-coverage/v2",
        "final_artifact_id": result["final_artifact_id"]}))
    export_run_report(run)
    references = json.loads((run / "references.json").read_text(encoding="utf-8"))
    assert references and all(row["parser_provenance"]["parser"] == "llamaparse" for row in references)
    assert "LlamaCloud 转写片段" in (run / "final_answer.md").read_text(encoding="utf-8-sig")


@pytest.mark.parametrize("expired", [False, True])
def test_owned_parser_child_environment_deadline_and_termination(pdf, tmp_path, monkeypatch, expired):
    import process_cleanup
    captured, stopped = {}, []
    class Child:
        pid = 42424242
        returncode = None
        def poll(self): return self.returncode
        def wait(self, timeout):
            captured["timeout"] = timeout
            if expired: raise subprocess.TimeoutExpired("parser", timeout)
            Path(captured["argv"][3]).write_text(json.dumps({"success": True,
                "layout_blocks": cloud_blocks(cloud_result(), 2)}), encoding="utf-8")
            self.returncode = 0
    child = Child()
    def spawn(argv, **kwargs):
        captured.update(argv=argv, env=kwargs["env"])
        return child
    monkeypatch.setattr(subprocess, "Popen", spawn)
    monkeypatch.setattr(process_cleanup, "terminate_process_tree", lambda process: stopped.append(process))
    executor = LocalPdfRagExecutor(tmp_path / "run", pdf, rag_mode="lexical",
        pdf_parse_mode="llama_full", llama_cloud_consent=True)
    executor.retrieval_deadline = time.monotonic() + 40
    with provider_scope(ProviderCapability("alice", {"LLAMA_CLOUD_API_KEY": "llx-account-fixture"})):
        if expired:
            with pytest.raises(Exception, match="LLAMA_PARSE_DEADLINE"):
                executor._parse(pdf)
        else:
            assert executor._parse(pdf)["success"]
    assert 0 < captured["timeout"] <= 25
    assert captured["env"]["LLAMA_CLOUD_API_KEY"] == "llx-account-fixture"
    assert "llx-account-fixture" not in " ".join(captured["argv"])
    assert "--cloud-consent" in captured["argv"]
    assert bool(stopped) is expired
