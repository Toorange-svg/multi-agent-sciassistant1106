"""One reversible outer-envelope repair cannot change science or tool authority."""
from copy import deepcopy
import json
import time

import pytest

from multi_agent_agents import AgentContractError, AgentWorker, ArtifactDirectory, make_agent_input
from multi_agent_live import (decode_model_envelope, json_syntax_diagnostic, LiveModelClient,
    ROLE_OUTPUT_SCHEMAS, MODEL_ENVELOPE_POLICY)
from test_multi_agent_live import config


def document():
    return {'status': 'completed', 'output': {'schema_version': ROLE_OUTPUT_SCHEMAS['citation_auditor'],
        'status': 'passed', 'issues': [], 'rejected_claim_ids': [], 'claim_results': []}}


@pytest.mark.parametrize('tail', [',"tool_requests":[]}', ', "tool_requests" : [ ] }'])
def test_complete_auditor_envelope_with_only_external_empty_tool_tail_is_recoverable(tail):
    value = document()
    raw = json.dumps(value, ensure_ascii=False)+tail
    assert len(',"tool_requests":[]}') == 20
    result, repaired = decode_model_envelope(raw, 'citation_auditor', 'stop')
    assert result == {**value, 'tool_requests': []}
    assert result['output'] == value['output'] and repaired == 'AUDITOR_EMPTY_TOOL_TAIL'


@pytest.mark.parametrize('fault', ['second_object', 'actions', 'unknown_field', 'duplicate_tools',
    'failed_status', 'non_object_output', 'content_damage', 'plain_suffix', 'missing_close'])
def test_other_invalid_json_is_never_guessed_or_first_object_extracted(fault):
    value = document()
    tail = ',"tool_requests":[]}'
    if fault == 'second_object': tail = '{"status":"failed"}'
    elif fault == 'actions': tail = ',"tool_requests":[{"action":"open_url"}]}'
    elif fault == 'unknown_field': tail = ',"new_field":[]}'
    elif fault == 'duplicate_tools': value['tool_requests'] = []
    elif fault == 'failed_status': value['status'] = 'failed'
    elif fault == 'non_object_output': value['output'] = []
    elif fault == 'plain_suffix': tail = 'Use the earlier result.'
    raw = json.dumps(value)+tail
    if fault == 'content_damage': raw = raw.replace('"passed"', '"pas"sed"')
    elif fault == 'missing_close': raw = json.dumps(value)[:-2]+tail
    with pytest.raises(AgentContractError): decode_model_envelope(raw, 'citation_auditor', 'stop')


@pytest.mark.parametrize('role,finish', [('writer','stop'),('reviewer','stop'),
    ('citation_auditor','length'),('citation_auditor','unknown'),('citation_auditor','content_filter')])
def test_repair_cannot_expand_role_tools_or_accept_truncation(role,finish):
    with pytest.raises(AgentContractError):
        decode_model_envelope(json.dumps(document())+',"tool_requests":[]}',role,finish)


def test_valid_scientific_strings_and_embedded_tail_literals_stay_byte_semantically_equal():
    value = document()
    value['output']['quoted_literal'] = 'Formula q−p; ,"tool_requests":[]} is quoted data, not a command.'
    before = deepcopy(value)
    result, repair = decode_model_envelope(json.dumps(value), 'citation_auditor', 'stop')
    assert result == before and repair is None


def test_failure_diagnostics_classify_tail_structure_without_persisting_content():
    raw = json.dumps(document())+',"tool_requests":[]}'
    with pytest.raises(json.JSONDecodeError) as error: json.loads(raw)
    diagnostic = json_syntax_diagnostic(error.value)
    assert diagnostic['extra_data_char_count'] == 20 and diagnostic['extra_data_empty_tool_tail']
    assert raw not in str(diagnostic)


def test_live_adapter_and_worker_persist_repair_metadata_not_raw_provider_content(monkeypatch,tmp_path):
    monkeypatch.setenv('MODEL_REQUEST_URL','https://example.test/v1/chat/completions')
    raw = json.dumps(document())+',"tool_requests":[]}'
    class Response:
        status_code = 200
        def raise_for_status(self): pass
        def close(self): pass
        def iter_content(self, **kwargs):
            yield json.dumps({'choices':[{'finish_reason':'stop','message':{'content':raw}}]}).encode()
    client = LiveModelClient(config(),post=lambda *a,**k:Response())
    worker = AgentWorker('citation_auditor',lambda packet:client.call('citation_auditor',packet),['audit_citations'])
    store = ArtifactDirectory(tmp_path/'artifacts')
    result = worker.run(make_agent_input(run_id='envelope-test',role='citation_auditor',goal='Test format only',
        input_artifact_ids=[],remaining_model_calls=10,deadline_at=time.time()+20),store)
    assert result['status'] == 'completed'
    deliveries = [json.loads(p.read_text(encoding='utf-8')) for p in (tmp_path/'artifacts').glob('model-delivery-*.json')]
    assert len(deliveries) == 1 and deliveries[0]['json_framing_repair'] == 'AUDITOR_EMPTY_TOOL_TAIL'
    assert client.prompt_metadata()['citation_auditor']['json_envelope_policy'] == MODEL_ENVELOPE_POLICY
    assert all(raw not in p.read_text(encoding='utf-8') for p in (tmp_path/'artifacts').glob('*.json'))
