"""Question requirements and source-domain visibility, with no paid calls."""
from copy import deepcopy
from dataclasses import replace
import json

import pytest

from multi_agent_agents import AgentContractError
from multi_agent_evidence import excerpt_content_scope
from multi_agent_live import normalize_live_result
from multi_agent_pipeline_v2 import check_review, check_draft, recover_review_subset, ReviewContractError
from multi_agent_quality import answer_requirements, scope_plan_to_question, attach_reviewed_source_scope
from multi_agent_pipeline_v2 import actionable_review_gaps
from test_multi_agent_task_relevance import classified_review
from test_multi_agent_protocol_recovery import packet_set
from test_multi_agent_pipeline_v2 import agents, pipeline, worker
from test_multi_agent_protocol_recovery import audit_data


def domain_review(domain="人脸Deepfake检测"):
    review = classified_review("adjacent_context")
    review["schema_version"] = "sciassistant.evidence-review/v5"
    review["decisions"][0]["source_domain"] = domain
    return review


def test_v5_domain_is_preserved_and_old_v4_is_not_rewritten():
    evidence = {"evidence": packet_set()["evidence"][:1]}
    output = normalize_live_result("reviewer", {"output": domain_review()}, require_current=True)["output"]
    assert check_review(output, evidence, {"g1"})["decisions"][0]["source_domain"] == "人脸Deepfake检测"
    legacy = normalize_live_result("reviewer", {"output": classified_review("adjacent_context")})["output"]
    assert "source_domain" not in check_review(legacy, evidence, {"g1"})["decisions"][0]
    with pytest.raises(AgentContractError, match="unknown role output schema"):
        normalize_live_result("reviewer", {"output": legacy}, require_current=True)


@pytest.mark.parametrize("domain", [None, "", "  ", 12, "字" * 81])
def test_v5_background_needs_bounded_explicit_domain(domain):
    with pytest.raises(ReviewContractError, match="REVIEW_SOURCE_DOMAIN"):
        check_review(domain_review(domain), {"evidence": packet_set()["evidence"][:1]}, {"g1"})


def test_unknown_version_cannot_bypass_new_review_requirements():
    data = domain_review()
    data["schema_version"] = "sciassistant.evidence-review/v99"
    with pytest.raises(ReviewContractError, match="REVIEW_SCHEMA_UNKNOWN"):
        check_review(data, {"evidence": packet_set()["evidence"][:1]}, {"g1"})


def test_bad_new_domain_does_not_discard_independent_good_subset():
    data = domain_review()
    data["allowed_evidence_ids"].append("e2")
    data["decisions"].append({**data["decisions"][0], "evidence_id": "e2", "source_domain": ""})
    checked, report = recover_review_subset(data, packet_set(), {"g1"})
    assert checked["allowed_evidence_ids"] == ["e1"] and report["quarantined_evidence_ids"] == ["e2"]
    assert checked["decisions"][0]["source_domain"] == "人脸Deepfake检测"


def test_v5_cross_planned_topic_recovery_preserves_retrieval_provenance():
    data = domain_review()
    data["decisions"][0]["group_ids"] = ["g1", "g2"]
    evidence = packet_set()
    original = deepcopy(evidence)
    recovered, report = recover_review_subset(data, evidence, {"g1", "g2"})
    assert recovered["allowed_evidence_ids"] == ["e1"]
    assert recovered["decisions"][0]["group_ids"] == ["g1", "g2"]
    assert report["topic_association_policy"] == "planned-topics-semantic-review/v1"
    assert evidence == original
    data["decisions"][0]["group_ids"] = ["g1", "not-planned"]
    recovered, _report = recover_review_subset(data, evidence, {"g1", "g2"})
    assert recovered["allowed_evidence_ids"] == []


def scoped_packets(mixed=False):
    rows = [{**packet_set()["evidence"][0], "task_relevance": "adjacent_context", "source_domain": "人脸Deepfake检测",
             "source_scope_policy": "reviewer-v5-visible-domain/v1"}]
    if mixed:
        rows.append({**packet_set()["evidence"][1], "task_relevance": "direct_task_evidence"})
    return {"evidence": rows}


def draft(note="", mixed=False):
    return {"schema_version": "sciassistant.claim-draft/v2", "direct_answer": "回答", "claims": [{"claim_id": "c1", "text": "CNN与ViT共同构成分类器。",
        "claim_type": "technical", "evidence_ids": ["e1", "e2"] if mixed else ["e1"],
        "qualification": "在人脸Deepfake检测中实现，不代表通用生成图像效果。", "scope_note": note}]}


@pytest.mark.parametrize("mixed", [False, True])
def test_hiding_source_domain_in_details_is_not_enough(mixed):
    errors = check_draft(draft(mixed=mixed), scoped_packets(mixed))
    assert errors == [{"claim_id": "c1", "reason": "SOURCE_DOMAIN_NOT_VISIBLE",
                       "required_source_domains": ["人脸Deepfake检测"]}]
    assert not check_draft(draft("该示例属于人脸Deepfake检测。", mixed), scoped_packets(mixed))


def test_visible_domain_cannot_legalize_adjacent_performance_numbers():
    value = draft("人脸Deepfake检测")
    value["claims"][0]["claim_type"] = "comparative"
    assert {r["reason"] for r in check_draft(value, scoped_packets())} == {"ADJACENT_EVIDENCE_NOT_TASK_RESULT"}


def test_only_boundary_limitation_can_avoid_repeating_domain():
    value = draft()
    value["claims"][0].update(claim_type="limitation", section="evidence_boundary", text="本轮领域覆盖不完整。")
    assert not check_draft(value, scoped_packets())
    value["claims"][0]["claim_type"] = "technical"
    assert check_draft(value, scoped_packets())


def test_old_scoped_packets_do_not_get_invented_domain_guards():
    data = scoped_packets()
    data["evidence"][0].pop("source_scope_policy")
    assert not check_draft(draft(), data)


@pytest.mark.parametrize("question", ["什么是SOTA多模态大模型？和XAIGID-RewardBench有什么关系？",
                                     "判断AI生成图片是什么技术？和ViT有关系吗？"])
def test_qualitative_question_does_not_require_unasked_benchmarks(question):
    plan = {"groups": [{"id": "g1", "queries": ["original query"], "metrics": ["definition", "accuracy", "ranking", "latency"]}]}
    original = deepcopy(plan)
    scoped, report = scope_plan_to_question(plan, answer_requirements(question))
    assert scoped["groups"][0]["metrics"] == ["definition"]
    assert scoped["groups"][0]["queries"] == ["original query"] and plan == original
    assert report["changes"][0]["unrequested_metrics"] == ["accuracy", "ranking", "latency"]
    assert report["evidence_auto_approval"] is False


@pytest.mark.parametrize("question,metric", [("ViT准确率是多少？", "accuracy"), ("SOTA模型排名是怎样的？", "ranking"),
                                     ("定义ViT并解释检测性能", "accuracy"), ("对比KV缓存量化和投机解码吞吐", "throughput"),
                                     ("KV缓存量化能降低多少延迟？", "latency")])
def test_user_requested_evaluation_is_never_removed(question, metric):
    plan = {"groups": [{"id": "g1", "metrics": [metric]}]}
    scoped, report = scope_plan_to_question(plan, answer_requirements(question))
    assert scoped == plan and not report["changes"]


def test_empty_after_scoping_uses_qualitative_dimension_not_fake_evidence():
    scoped, report = scope_plan_to_question({"groups": [{"id": "g1", "metrics": ["accuracy"]}]}, answer_requirements("ViT是什么？"))
    assert scoped["groups"][0]["metrics"] == ["definition"]
    assert report["changes"] and report["evidence_auto_approval"] is False


@pytest.mark.parametrize("include_domain", [True, False])
@pytest.mark.parametrize("coverage_mode", ["indirect", "partial_qualified", "missing_no_capacity"])
def test_workflow_passes_scoped_plan_and_domain_then_uses_independent_audit(tmp_path, include_domain, coverage_mode):
    configured, calls = agents()
    raw_plan = {"groups": [{"id": "g1", "question": "A", "queries": ["A"],
                            "metrics": ["definition", "latency", "accuracy"]}]}
    observed = {}

    def planner(_packet):
        calls.append("planner")
        return {"output": raw_plan}

    def reviewer(packet):
        calls.append("reviewer")
        plan = next(i["payload"] for i in packet["inputs"] if "groups" in i["payload"])
        assert plan["groups"][0]["metrics"] == ["definition"]
        value = domain_review()
        value["allowed_evidence_ids"] = ["arxiv-1"]
        value["decisions"][0]["evidence_id"] = "arxiv-1"
        status = "indirect" if coverage_mode == "indirect" else "partial" if coverage_mode == "partial_qualified" else "missing"
        value["coverage"] = [{"group_id": "g1", "metric": "definition", "status": status,
                              "evidence_ids": [] if status == "missing" else ["arxiv-1"], "recommended_action": "qualified_answer"}]
        return {"output": value}

    def writer_handler(packet):
        calls.append("writer")
        approved = next(i["payload"] for i in packet["inputs"] if "evidence" in i["payload"])
        observed["approved"] = approved
        claim = {"claim_id": "c1", "text": "在人脸Deepfake检测中可使用ViT特征。" if include_domain else "可以使用ViT特征。", "claim_type": "technical",
                 "evidence_ids": ["arxiv-1"], "confidence": "low", "section": "direct_conclusion", "scope_note": ""}
        return {"output": {"schema_version": "sciassistant.claim-draft/v2", "direct_answer": "先回答问题", "claims": [claim]}}

    def auditor(packet):
        calls.append("citation_auditor")
        draft = next(i["payload"] for i in packet["inputs"] if "claims" in i["payload"])
        if not include_domain:
            assert "原文适用范围：人脸Deepfake检测" in draft["claims"][0]["scope_note"]
        return {"output": audit_data(draft)}

    configured = replace(configured, planner=worker("planner", planner, "create_research_plan"),
                         reviewer=worker("reviewer", reviewer, "review_evidence"),
                         writer=worker("writer", writer_handler, "write_approved_claims"),
                         citation_auditor=worker("citation_auditor", auditor, "audit_citations"))
    flow, _store = pipeline(tmp_path, configured)
    if coverage_mode == "missing_no_capacity":
        flow.executor.reading_summary = lambda: {"papers_attempted": 15, "paper_limit": 15, "batches_used": 3,
                                                 "batch_limit": 3, "remaining_candidates": 1}
    result = flow.run("domain-flow", "owner", "什么是ViT？")
    final = flow.artifacts.get(result["final_artifact_id"])
    assert result["run"]["status"] == "partial" and result["run"]["model_calls_used"] == 5
    assert calls == ["planner", "retriever", "reviewer", "writer", "citation_auditor"]
    assert "人脸Deepfake检测" in result["direct_answer"]
    assert observed["approved"]["evidence"][0]["source_domain"] == "人脸Deepfake检测"
    assert observed["approved"]["evidence"][0]["source_scope_policy"] == "reviewer-v5-visible-domain/v1"
    assert observed["approved"]["evidence"][0]["reviewed_group_ids"] == ["g1"]
    assert observed["approved"]["evidence"][0]["topic_association_policy"] == "planned-topics-semantic-review/v1"
    assert flow.artifacts.get(final["artifact_refs"]["plan_scope_validation"])["changes"]
    assert flow.artifacts.get(final["artifact_refs"]["audit"])["contract_errors"] == []
    scope_format = flow.artifacts.get(final["artifact_refs"]["source_scope_format"])
    assert bool(scope_format["changes"]) is not include_domain
    raw_writer = flow.artifacts.get(next(p.stem for p in (tmp_path / "artifacts").glob("writer-output-*.json")))
    assert raw_writer["claims"][0]["scope_note"] == ""
    assert raw_plan["groups"][0]["metrics"] == ["definition", "latency", "accuracy"]
    if coverage_mode == "missing_no_capacity":
        events = [json.loads(line) for line in (tmp_path / "events.jsonl").read_text(encoding="utf-8").splitlines()]
        assert any(e.get("reason_code") == "PDF_READING_CAPACITY_EXHAUSTED" for e in events)


@pytest.mark.parametrize("before,after,page,expected", [
    ("1 Introduction\nAuthors\n", "Overview body without a repeated heading.", 1, "mixed_abstract_body"),
    ("1 The University\n2 Another University\n", "Only a summary.", 1, "abstract_only"),
    ("Title\nAuthors\n", "Summary\n1 Introduction\nBody", 3, "mixed_abstract_body"),
    ("Title\n", "Summary only.", 3, "abstract_only"),
])
def test_body_before_abstract_is_distinct_from_numbered_affiliations(before, after, page, expected):
    value = {"excerpt": before + "Abstract\n" + after, "locator": {"page": page}}
    assert excerpt_content_scope(value) == expected


def test_domain_copy_is_formatting_not_evidence_or_factual_repair():
    raw = draft()
    original = deepcopy(raw)
    formatted, log = attach_reviewed_source_scope(raw, scoped_packets())
    assert raw == original and formatted["claims"][0]["text"] == raw["claims"][0]["text"]
    assert formatted["claims"][0]["evidence_ids"] == ["e1"]
    assert "原文适用范围：人脸Deepfake检测" in formatted["claims"][0]["scope_note"]
    assert not check_draft(formatted, scoped_packets())
    assert log["semantic_auto_approval"] is False and log["audit_required"] is True
    again, second = attach_reviewed_source_scope(formatted, scoped_packets())
    assert again == formatted and not second["changes"]
    raw["claims"][0]["claim_type"] = "comparative"
    value, _log = attach_reviewed_source_scope(raw, scoped_packets())
    assert {r["reason"] for r in check_draft(value, scoped_packets())} == {"ADJACENT_EVIDENCE_NOT_TASK_RESULT"}


@pytest.mark.parametrize("mutation", [
    lambda value: value["claims"][0].update(evidence_ids=["unapproved"]),
    lambda value: value["claims"][0].update(scope_note="边" * 600),
    lambda value: value.update(schema_version="sciassistant.claim-draft/v1"),
])
def test_domain_formatter_never_clears_invalid_citations_or_truncates_conditions(mutation):
    raw = draft()
    mutation(raw)
    original = deepcopy(raw)
    result, report = attach_reviewed_source_scope(raw, scoped_packets())
    assert result == original and not report["changes"]


def test_v5_qualified_partial_with_valid_support_is_not_a_research_gap():
    value = domain_review()
    row = {"group_id": "g1", "metric": "role", "status": "partial", "evidence_ids": ["e1"],
           "recommended_action": "qualified_answer"}
    value["coverage"] = [row]
    assert actionable_review_gaps(value) == []
    for changed in ({"status": "missing"}, {"evidence_ids": []}, {"evidence_ids": ["unapproved"]},
                    {"recommended_action": "targeted_search"}):
        value["coverage"] = [{**row, **changed}]
        assert actionable_review_gaps(value) == value["coverage"]
    value["schema_version"] = "sciassistant.evidence-review/v4"
    value["coverage"] = [row]
    assert actionable_review_gaps(value) == [row]


def test_domain_formatting_does_not_bypass_an_independent_rejection():
    from multi_agent_quality import publication_rejections, check_audit
    value, _log = attach_reviewed_source_scope(draft(), scoped_packets())
    rejected = audit_data(value)
    rejected.update(status="needs_revision", rejected_claim_ids=["c1"],
                    issues=[{"claim_id": "c1", "reason_code": "UNSUPPORTED_NUMBER"}])
    rejected["claim_results"][0].update(decision="rejected", reason_code="UNSUPPORTED_NUMBER")
    assert not check_audit(rejected, value)["contract_errors"]
    assert publication_rejections(rejected, value) == {"c1"}
