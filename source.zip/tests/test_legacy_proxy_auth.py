"""Legacy proxy routes must not bypass the account JWT boundary."""
import os
import tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest import TestCase, mock

import requests

import app as account_app


class LegacyProxyAuthorizationTests(TestCase):
    def setUp(self):
        self.auth_version = mock.patch.object(
            account_app, "_current_auth_version", return_value=0)
        self.auth_version.start()
        self.addCleanup(self.auth_version.stop)
        from user_credentials import CredentialStore
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        store = CredentialStore(Path(temporary.name)/'keys.sqlite3', 'test-provider-secret-not-shared')
        store.update('owner-a', {'deepseek_keys':['provider-only']})
        self.provider_store = mock.patch.object(account_app, '_provider_store', return_value=store)
        self.provider_store.start(); self.addCleanup(self.provider_store.stop)

    def _headers(self, user_id="owner-a"):
        token = account_app.generate_token(user_id, f"user-{user_id}")
        return {"Authorization": f"Bearer {token}"}

    def test_deepdiver_proxy_requires_a_bearer_token_before_forwarding(self):
        with mock.patch.object(account_app, "_proxy_request") as forward:
            response = account_app.app.test_client().get("/8000/api/concurrency")
        self.assertEqual(response.status_code, 401)
        forward.assert_not_called()

    def test_model_proxy_requires_a_bearer_token_before_forwarding(self):
        with mock.patch.object(account_app, "_proxy_request") as forward:
            response = account_app.app.test_client().post("/8088/v1/chat/completions", json={})
        self.assertEqual(response.status_code, 401)
        forward.assert_not_called()

    def test_authorized_legacy_deepdiver_is_retired_without_user_scope(self):
        upstream_response = (b'{"ok":true}', 200, [("Content-Type", "application/json")])
        with mock.patch.object(account_app, "_proxy_request", return_value=upstream_response) as forward:
            response = account_app.app.test_client().get(
                "/8000/api/concurrency", headers=self._headers()
            )
        self.assertEqual(response.status_code, 410)
        self.assertEqual(response.json['error'], 'LEGACY_SERVICE_NOT_USER_ISOLATED')
        forward.assert_not_called()

    def test_authorized_model_proxy_still_forwards_the_request(self):
        upstream_response = (b'{"ok":true}', 200, [("Content-Type", "application/json")])
        with mock.patch.dict(os.environ, {"CHAT_API_BASE": "https://model-upstream.invalid"}, clear=False):
            with mock.patch.object(account_app, "_proxy_request", return_value=upstream_response) as forward:
                response = account_app.app.test_client().post(
                    "/8088/v1/chat/completions", json={"model": "legacy"}, headers=self._headers()
                )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(forward.call_args.args[:2], ("https://model-upstream.invalid", "v1/chat/completions"))
        self.assertEqual(
            forward.call_args.kwargs["excluded_request_headers"],
            {"authorization", "origin", "referer", "cookie", "x-forwarded-for", "x-real-ip"},
        )

    def test_deepdiver_proxy_does_not_forward_account_jwt(self):
        upstream = SimpleNamespace(content=b"ok", status_code=200, headers={})
        with mock.patch.object(account_app.http_requests, "request", return_value=upstream) as request_mock:
            response = account_app.app.test_client().get("/8000/api/concurrency", headers=self._headers())
        self.assertEqual(response.status_code, 410)
        request_mock.assert_not_called()

    def test_model_proxy_replaces_account_jwt_with_configured_provider_token(self):
        upstream = SimpleNamespace(content=b"ok", status_code=200, headers={})
        env = {"CHAT_API_BASE": "https://model-upstream.invalid", "MODEL_REQUEST_TOKEN": "provider-only"}
        with mock.patch.dict(os.environ, env, clear=False):
            with mock.patch.object(account_app.http_requests, "request", return_value=upstream) as request_mock:
                response = account_app.app.test_client().post(
                    "/8088/v1/chat/completions", json={"model": "legacy"}, headers=self._headers()
                )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(request_mock.call_args.kwargs["headers"].get("Authorization"), "Bearer provider-only")
        self.assertFalse(request_mock.call_args.kwargs["allow_redirects"])

    def test_proxy_upstream_configuration_rejects_ssrf_and_credentials_before_request(self):
        unsafe = (
            "http://169.254.169.254/latest/meta-data",
            "http://10.0.0.5/model",
            "https://user:secret@provider.invalid/v1",
            "https://provider.invalid/v1?token=secret",
            "file:///private/path",
        )
        for target in unsafe:
            with self.subTest(target=target), mock.patch.dict(
                os.environ, {"CHAT_API_BASE": target}, clear=False,
            ), mock.patch.object(account_app.http_requests, "request") as request_mock:
                response = account_app.app.test_client().post(
                    "/8088/v1/chat/completions", json={}, headers=self._headers())
                self.assertEqual(response.status_code, 503)
                self.assertEqual(response.get_json()["error"], "UPSTREAM_CONFIGURATION_INVALID")
                request_mock.assert_not_called()

    def test_deepdiver_base_must_be_literal_ipv4_loopback(self):
        for target in ("http://localhost:8000", "http://192.168.1.2:8000", "https://127.0.0.1:8000"):
            with self.subTest(target=target), mock.patch.dict(
                os.environ, {"DEEPDIVER_API_BASE": target}, clear=False,
            ), mock.patch.object(account_app.http_requests, "request") as request_mock:
                response = account_app.app.test_client().get(
                    "/8000/api/concurrency", headers=self._headers())
                self.assertEqual(response.status_code, 410)
                with self.assertRaises(RuntimeError):
                    account_app._validated_upstream_base(target, local_only=True)
                request_mock.assert_not_called()

    def test_upstream_redirect_is_rejected_without_location_or_body_leak(self):
        upstream = SimpleNamespace(
            content=b"private redirect body",
            status_code=302,
            headers={"Location": "http://169.254.169.254/private"},
        )
        with account_app.app.test_request_context("/8000/api/concurrency"), mock.patch.object(
            account_app.http_requests, "request", return_value=upstream,
        ) as request_mock:
            response, status = account_app._proxy_request(
                "http://127.0.0.1:8000", "api/concurrency")
        self.assertEqual(status, 502)
        self.assertEqual(response.get_json()["error"], "UPSTREAM_REDIRECT_REJECTED")
        self.assertNotIn("Location", response.headers)
        self.assertNotIn("private redirect body", response.get_data(as_text=True))
        self.assertFalse(request_mock.call_args.kwargs["allow_redirects"])

    def test_proxy_rejects_ambiguous_or_traversal_target_paths(self):
        with account_app.app.test_request_context("/8000/test"):
            for path in ("../private", "v1//models", "https://evil.invalid/x", "v1\\models"):
                response, status = account_app._proxy_request("http://127.0.0.1:8000", path)
                self.assertEqual(status, 400)
                self.assertEqual(response.get_json()["error"], "INVALID_UPSTREAM_PATH")

    def test_upstream_transport_failure_is_safe_for_clients_and_routine_logs(self):
        target = "http://private-upstream.internal:9411/token=should-not-leak"
        error = requests.ConnectionError("credential=should-not-leak")
        with account_app.app.test_request_context("/8000/api/concurrency"), mock.patch.object(
            account_app.http_requests, "request", side_effect=error,
        ), mock.patch.object(account_app.logger, "warning") as warning:
            response, status = account_app._proxy_request(target, "api/concurrency")

        self.assertEqual(status, 503)
        payload = response.get_json()
        self.assertEqual(payload, {
            "success": False,
            "error": "UPSTREAM_UNAVAILABLE",
            "message": "所需服务暂时不可用，请稍后重试。",
        })
        rendered = response.get_data(as_text=True)
        self.assertNotIn("private-upstream", rendered)
        self.assertNotIn("should-not-leak", rendered)
        warning.assert_called_once_with(
            "Proxy upstream unavailable: method=%s error_type=%s", "GET", "ConnectionError"
        )


if __name__ == "__main__":
    import unittest

    unittest.main()
