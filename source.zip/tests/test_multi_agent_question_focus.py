"""Literal symbol context and question-bound requirements, without approval."""
from copy import deepcopy
import pytest

import pdf_pipeline as pdf
from multi_agent_quality import answer_requirements, scope_plan_to_question, reported_condition_records
from multi_agent_live import ROLE_PROMPT_SUFFIXES, PROMPT_VERSION
from test_multi_agent_table_context import line, raw


def script_block(text='2', x=290):
    glyph = line(text, x, 106, 4)
    glyph['bbox'][3] = 112  # Smaller script font, not an ordinary text cell.
    return raw([glyph, line('of the first quantization', x+10, 101, 100)])


def test_small_script_links_sentence_across_pdf_blocks_without_inventing_notation():
    first = raw([line('Constants cFP32', 100, 100, 195)])
    following = script_block()
    result = pdf._join_script_linked_blocks([first, following])
    assert len(result) == 1
    text = result[0]['text']
    assert 'Constants cFP32 2 of the first quantization' == text
    assert 'c1' not in text and '^{FP32}' not in text


def test_true_column_gutter_is_not_a_script_join():
    left = raw([line('A left column paragraph.', 100, 100, 160)])
    right = script_block(x=320)
    assert len(pdf._join_script_linked_blocks([left, right])) == 2


def test_repaired_text_is_never_replaced_by_unrepaired_layout():
    first = raw([line('Broken encoding cFP32', 100, 100, 195)])
    first['text'] = 'Repaired source cFP32'
    result = pdf._join_script_linked_blocks([first, script_block()])
    assert len(result) == 2 and result[0]['text'] == first['text']


def test_ordinary_paragraphs_are_not_joined_merely_because_they_overlap_in_y():
    first = raw([line('First normal paragraph.', 100, 100, 195)])
    next_one = raw([line('Second normal paragraph.', 300, 101, 180)])
    assert len(pdf._join_script_linked_blocks([first, next_one])) == 2


def test_table_focus_does_not_require_an_efficiency_tradeoff():
    question = '请解释Table 3的模型、数据集和指标，比较88.6和40.1能否直接比较。'
    requirements = answer_requirements(question)
    assert requirements['answer_focus']['source_anchors'] == ['Table 3']
    plan = {'groups': [{'id': 'g1', 'queries': ['fixed'], 'metrics': ['comparison', 'tradeoffs', 'memory', 'throughput']}]}
    before = deepcopy(plan)
    effective, diagnostics = scope_plan_to_question(plan, requirements)
    assert effective['groups'][0]['metrics'] == ['comparison']
    assert plan == before and not diagnostics['evidence_auto_approval']


def test_explicit_table_memory_and_tradeoff_requests_are_retained():
    requirements = answer_requirements('请对比Table 3的显存与吞吐权衡。')
    plan = {'groups': [{'id': 'g1', 'metrics': ['tradeoffs', 'memory', 'throughput']}]}
    assert scope_plan_to_question(plan, requirements)[0] == plan


def test_empty_table_plan_falls_back_to_interpretation_not_another_fake_benchmark():
    requirements = answer_requirements('Table 3说明什么？')
    plan = {'groups': [{'id': 'g1', 'metrics': ['tradeoffs', 'latency']}]}
    assert scope_plan_to_question(plan, requirements)[0]['groups'][0]['metrics'] == ['interpretation']


@pytest.mark.parametrize('question,formal', [
    ('解释NF4和双重量化怎么工作，不需要完整公式推导。', False),
    ('解释双重量化公式的c1/c2符号和层级。', True),
    ('请推导这个机制。', True),
])
def test_formal_notation_is_only_required_when_requested(question, formal):
    focus = answer_requirements(question)['answer_focus']
    assert focus['formal_notation_requested'] is formal
    assert focus['report_length_limit'] is None


def test_negative_table_request_does_not_create_positive_source_anchor():
    assert answer_requirements('只解释机制，不需要Table 3或额外性能表。')['answer_focus']['source_anchors'] == []


def test_symbol_role_context_is_literal_approved_source_not_automatic_truth():
    text = ('Constants cFP32 2 of the first quantization are inputs. '
            'The second level of quantization constants cFP32 1 is also stored.')
    item = {'evidence_id': 'e1', 'paper_id': 'p1', 'review_status': 'approved', 'excerpt': text}
    records = reported_condition_records({'evidence': [item]})
    row = next(r for r in records if r['aspect'] == 'symbol_role_definitions')
    assert row['quote'] == text[row['start']:row['end']] and not row['is_scientific_verdict']
    item['review_status'] = 'rejected'
    assert reported_condition_records({'evidence': [item]}) == []


def test_role_prompts_do_not_treat_subscripts_as_stage_order():
    assert PROMPT_VERSION.endswith('/v107')
    assert 'subscript 1 does NOT automatically mean' in ROLE_PROMPT_SUFFIXES['writer']
    assert 'data-type quote alone cannot support' in ROLE_PROMPT_SUFFIXES['citation_auditor']
    assert 'gaps ONLY when' in ROLE_PROMPT_SUFFIXES['reviewer']
