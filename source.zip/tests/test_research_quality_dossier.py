"""Read-only diagnostic export is not approval or source-run repair."""
import hashlib
import json
import subprocess
import sys

from multi_agent_agents import ArtifactDirectory
from tools.inspect_research_quality import dossier


def make_run(tmp_path):
    directory = tmp_path / 'source'; directory.mkdir()
    store = ArtifactDirectory(directory / 'artifacts')
    refs = {}
    refs['question'] = store.put('question', {'question': '解释量化开销'})['artifact_id']
    refs['plan'] = store.put('research-plan', {'groups': [{'id': 'g1', 'question': '开销', 'metrics': ['memory']}]})['artifact_id']
    refs['approved'] = store.put('approved', {'evidence': [{'evidence_id': 'e1', 'review_status': 'approved',
        'source': 'uploaded_pdf', 'locator': {'page': 5}, 'excerpt': 'Quantization constants add overhead.'}]})['artifact_id']
    refs['draft'] = store.put('draft-answer', {'claims': [{'claim_id': 'c1', 'text': '量化常数开销。',
        'scope_note': '', 'qualification': '仅本设置。', 'evidence_ids': ['e1']}]})['artifact_id']
    refs['audit'] = store.put('audit', {'claim_results': [{'claim_id': 'c1', 'decision': 'approved',
        'source_witnesses': [{'evidence_id': 'e1', 'quote': 'Quantization constants add overhead.'}]}]})['artifact_id']
    refs['publication'] = store.put('publication', {'claims': [{'claim_id': 'c1', 'published': True}]})['artifact_id']
    final = store.put('final-result', {'run_id': 'test', 'status': 'partial', 'artifact_refs': refs})
    (directory / 'manifest.json').write_text(json.dumps({'run_id': 'test', 'final_artifact_id': final['artifact_id'],
        'provider_private_response': 'LEAK_SENTINEL', 'prompts': {'writer': {'version': 'prompt/v51'}}}), encoding='utf8')
    (directory / 'claim_evidence_map.json').write_text('[{"claim_id":"c1"}]', encoding='utf8')
    (directory / 'events.jsonl').write_text(json.dumps({'event': 'agent_started', 'role': 'writer', 'call_number': 4,
        'provider_private_response': 'LEAK_SENTINEL'}) + '\n', encoding='utf8')
    return directory


def hashes(directory):
    return {str(p.relative_to(directory)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in directory.rglob('*') if p.is_file()}


def test_dossier_preserves_exact_fields_sources_and_does_not_grade(tmp_path):
    root = make_run(tmp_path); before = hashes(root)
    result = dossier(root)
    assert result['publication_matches_export'] and result['published_claims'] == 1
    assert result['prompt_version'] == 'prompt/v51'
    assert result['claims'][0]['fields']['qualification'] == '仅本设置。'
    assert result['claims'][0]['evidence'][0]['locator'] == {'page': 5}
    assert result['claims'][0]['independent_scientific_review'] == 'not_performed'
    assert not result['automatic_scientific_approval'] and result['model_calls_added'] == 0
    assert 'LEAK_SENTINEL' not in json.dumps(result) and hashes(root) == before


def test_mismatched_export_is_recorded_not_repaired(tmp_path):
    root = make_run(tmp_path); (root / 'claim_evidence_map.json').write_text('[]')
    before = hashes(root)
    result = dossier(root)
    assert result['publication_matches_export'] is False and result['claims'][0]['published'] is True
    assert result['claims'][0]['in_exported_map'] is False and hashes(root) == before


def test_cli_refuses_writing_into_source_or_overwriting(tmp_path):
    root = make_run(tmp_path); before = hashes(root)
    tool = __import__('pathlib').Path(__file__).resolve().parents[1] / 'tools/inspect_research_quality.py'
    for output in (root / 'new.json', root / 'manifest.json'):
        process = subprocess.run([sys.executable, str(tool), '--run-dir', str(root), '--output', str(output)],
                                 capture_output=True, text=True, timeout=20)
        assert process.returncode == 2 and 'QUALITY_DOSSIER_INPUT_INVALID' in process.stdout
    assert hashes(root) == before
