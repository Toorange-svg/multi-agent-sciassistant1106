"""Deployment guardrails for the process-local research task executor."""
import os
from unittest import TestCase, mock

import web_app


class TaskWorkerGuardTests(TestCase):
    def test_default_single_worker_is_accepted(self):
        with mock.patch.dict(os.environ, {}, clear=True):
            self.assertEqual(web_app._configured_task_worker_count(), 1)

    def test_explicit_multi_worker_setting_is_rejected(self):
        with mock.patch.dict(os.environ, {"SCIASSISTANT_TASK_WORKERS": "2"}, clear=True):
            with self.assertRaisesRegex(RuntimeError, "只能由一个进程执行"):
                web_app._configured_task_worker_count()

    def test_common_cloud_worker_setting_is_rejected(self):
        with mock.patch.dict(os.environ, {"WEB_CONCURRENCY": "3"}, clear=True):
            with self.assertRaisesRegex(RuntimeError, "WEB_CONCURRENCY=3"):
                web_app._configured_task_worker_count()

    def test_health_reports_single_process_execution_boundary(self):
        response = web_app.app.test_client().get("/api/health")
        self.assertEqual(response.status_code, 200)
        execution = response.get_json()["task_execution"]
        self.assertEqual(execution["worker_count"], 1)
        self.assertEqual(execution["queue_scope"], "single_process")
        self.assertFalse(execution["multi_worker_safe"])


if __name__ == "__main__":
    import unittest

    unittest.main()
