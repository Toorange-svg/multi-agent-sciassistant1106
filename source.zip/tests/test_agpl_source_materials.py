import hashlib
import io
import json
from pathlib import Path
import tarfile
import zipfile

import pytest

from tools import prepare_agpl_sources as sources


def test_wrong_project_archive_rejected_before_network(tmp_path, monkeypatch):
    archive = tmp_path / 'wrong.zip'
    archive.write_bytes(b'not the selected release')
    monkeypatch.setattr(sources.urllib.request, 'urlopen', lambda *a, **k: pytest.fail('unexpected network'))
    with pytest.raises(ValueError, match='PROJECT_ARCHIVE_MISMATCH'):
        sources.collect(archive, tmp_path / 'output')
    assert not (tmp_path / 'output').exists()


def test_existing_output_never_overwritten(tmp_path, monkeypatch):
    (tmp_path / 'keep').write_text('original', 'utf-8')
    with pytest.raises(ValueError, match='OUTPUT_ALREADY_EXISTS'):
        sources.collect(tmp_path / 'unused.zip', tmp_path)
    assert (tmp_path / 'keep').read_text('utf-8') == 'original'


def test_download_existing_bad_hash_refused(tmp_path, monkeypatch):
    path = tmp_path / 'source.tar.gz'
    path.write_bytes(b'bad')
    monkeypatch.setattr(sources.urllib.request, 'urlopen', lambda *a, **k: pytest.fail('unexpected network'))
    with pytest.raises(ValueError, match='EXISTING_SOURCE_HASH_MISMATCH'):
        sources.download('https://unused.invalid', path, 'a' * 64, 100)


def test_download_cached_hash_reused_without_network(tmp_path, monkeypatch):
    path = tmp_path / 'source.tar.gz'
    path.write_bytes(b'good')
    monkeypatch.setattr(sources.urllib.request, 'urlopen', lambda *a, **k: pytest.fail('unexpected network'))
    sources.download('https://unused.invalid', path, hashlib.sha256(b'good').hexdigest(), 100)


def test_project_scope_is_explicit_and_does_not_claim_published():
    text = (Path(__file__).resolve().parents[1] / 'deploy/agpl/SOURCE_README.md').read_text('utf-8')
    assert sources.FINGERPRINT in text
    assert '未发布' in text and '所有第三方组件合规证明' in text
    assert '不要把旧Toorange-svg/sci1.0私密仓库直接公开' in text
