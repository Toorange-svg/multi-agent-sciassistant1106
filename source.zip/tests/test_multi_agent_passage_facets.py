"""Planned local facets improve coverage, never approval or public permissions."""
from copy import deepcopy

import pytest

from multi_agent_rag import EvidenceStore, HybridRetriever, RagError, build_chunks
from multi_agent_live import LiveArxivRagExecutor, ROLE_PROMPTS


def indexed_store(tmp_path):
    store = EvidenceStore(tmp_path / "evidence.sqlite3")
    ids = {}
    texts = {
        "original-a": ["Visual backbone architecture transformer dimensions.",
                       "Contrastive image text pretraining aligns paired representations."],
        "original-b": ["Visual backbone architecture transformer dimensions of another model.",
                       "Self supervised distillation uses a student and an EMA teacher."],
        "crowded": ["Visual backbone architecture transformer dimensions medical classification."]}
    for doc, paragraphs in texts.items():
        chunks = build_chunks(doc, doc, "Backbone", [{"text": text, "page": i+1, "bbox": [1, 2, 3, 4]}
                                                   for i, text in enumerate(paragraphs)])
        store.index_document({"document_id": doc, "paper_id": doc, "title": "Backbone", "content_hash": doc}, chunks)
        ids[doc] = [chunk["chunk_id"] for chunk in chunks]
    return store, ids


class ArchitectureFirst:
    def rerank(self, query, chunks):
        return [c["chunk_id"] for c in sorted(chunks, key=lambda c: ("architecture" not in c["text"], c["chunk_id"]))]


def search_options():
    return dict(limit=4, per_document=2, document_ids={"original-a", "original-b", "crowded"},
                representative_document_ids=["original-a", "original-b"],
                passage_queries=["contrastive image text pretraining", "self supervised distillation"])


def test_local_facets_reserve_complementary_passages_from_representatives(tmp_path):
    store, ids = indexed_store(tmp_path)
    original = deepcopy(search_options())
    packets = HybridRetriever(store, reranker=ArchitectureFirst()).search("backbone architecture", **original)
    assert {p["evidence_id"] for p in packets} == set(ids["original-a"] + ids["original-b"])
    assert [p["document_id"] for p in packets[:2]] == ["original-a", "original-b"]
    assert sum(p["retrieval"]["complementary_representative"] for p in packets) == 2
    assert all(p["locator"]["page"] and p["locator"]["bbox"] for p in packets)
    assert all("review_status" not in p for p in packets)
    assert original == search_options()


@pytest.mark.parametrize("options", [dict(limit=1), dict(per_document=1), dict(context_budget=1), dict(document_ids=set())])
def test_facets_do_not_override_packet_document_or_context_limits(tmp_path, options):
    store, _ = indexed_store(tmp_path)
    configured = {**search_options(), **options}
    packets = HybridRetriever(store).search("backbone", **configured)
    assert len(packets) <= configured["limit"]
    assert all(sum(p["document_id"] == q["document_id"] for q in packets) <= configured["per_document"] for p in packets)
    if options.get("context_budget") == 1 or options.get("document_ids") == set():
        assert packets == []


def test_facet_terms_only_in_title_do_not_create_complementary_passage(tmp_path):
    store = EvidenceStore(tmp_path / "e.sqlite3")
    chunks = build_chunks("doc", "doc", "Contrastive pretraining", [
        {"text": "The paragraph explains transformer architecture.", "page": 1},
        {"text": "Another paragraph describes computation unrelated to learning objectives.", "page": 2}])
    store.index_document({"document_id": "doc", "paper_id": "doc", "title": "Contrastive pretraining", "content_hash": "x"}, chunks)
    packets = HybridRetriever(store).search("architecture", document_ids={"doc"},
        representative_document_ids=["doc"], passage_queries=["contrastive pretraining"])
    assert not any(p["retrieval"]["complementary_representative"] for p in packets)


@pytest.mark.parametrize("bad", ["one query", [""], [42], ["x" * 501], ["x\nquery"], ["a", "b", "c", "d"], None])
def test_bad_facet_input_rejected_before_retrieval(tmp_path, bad, monkeypatch):
    store = EvidenceStore(tmp_path / "e.sqlite3")
    def forbidden(*args, **kwargs):
        raise AssertionError("invalid input must not reach store")
    monkeypatch.setattr(store, "lexical_search", forbidden)
    with pytest.raises(RagError):
        HybridRetriever(store).search("valid", passage_queries=bad)


def test_duplicate_facets_do_not_repeat_embeddings_or_search(tmp_path):
    store, _ = indexed_store(tmp_path)
    class Embedding:
        calls = []
        def embed_query(self, value):
            self.calls.append(value)
            return [1.0, 0.0]
    class Vectors:
        calls = []
        def search(self, value, **options):
            self.calls.append(options)
            return []
    embed, vector = Embedding(), Vectors()
    HybridRetriever(store, embed, vector, vector_required=True).search("backbone", document_ids={"original-a"},
        passage_queries=["contrastive pretraining", "contrastive pretraining", "backbone"])
    assert embed.calls == ["backbone", "contrastive pretraining"]
    assert len(vector.calls) == 2
    assert all(row["document_ids"] == {"original-a"} for row in vector.calls)


def test_facet_recall_cannot_leak_outside_allowed_document_set(tmp_path, monkeypatch):
    store, ids = indexed_store(tmp_path)
    def malicious(*args, **kwargs):
        return [(ids["crowded"][0], 1.0), (ids["original-a"][1], 0.5)]
    monkeypatch.setattr(store, "lexical_search", malicious)
    packets = HybridRetriever(store).search("architecture", document_ids={"original-a"},
        representative_document_ids=["crowded", "original-a"], passage_queries=["contrastive pretraining"])
    assert packets and all(p["document_id"] == "original-a" for p in packets)


def test_public_executor_uses_only_current_planned_support_for_local_facets(tmp_path):
    observed = []
    store = EvidenceStore(tmp_path / "e.sqlite3")
    services = HybridRetriever(store)
    def search(query, **options):
        observed.append(options)
        return [{"evidence_id": "e1", "paper_id": "2103.00020v1", "title": "Study", "text": "A passage", "locator": {"page": 1}}]
    services.search = search
    executor = LiveArxivRagExecutor(tmp_path / "run", tmp_path / "storage", rag_mode="lexical", services=services)
    support = ["contrastive image text", "self supervised distillation", "patch embedding", "fourth not queried"]
    executor.configure_plan({"groups": [{"id": "g1", "core": ["CLIP"], "question": "architecture", "support": support}]})
    executor.group_queries = {"g1": ["initial public action"]}
    executor.candidates = {"2103.00020": {"paper_id": "2103.00020v1", "title": "Study", "group_ids": ["g1"]}}
    executor.ingested = {"arxiv-2103-00020v1"}
    before = deepcopy(executor.group_queries)
    assert len(executor._select_packets()) == 1
    assert observed[0]["passage_queries"] == support[:3]
    assert observed[0]["limit"] == 4 and observed[0]["context_budget"] == 4000
    assert executor.group_queries == before


def test_writer_and_auditor_distinguish_family_version_and_requested_detail():
    assert "model FAMILY" in ROLE_PROMPTS["writer"]
    assert "unasked implementation sizes" in ROLE_PROMPTS["writer"]
    assert "every member of a family" in ROLE_PROMPTS["citation_auditor"]


def test_generic_overlap_does_not_mark_a_specialized_facet_as_covered(tmp_path):
    store = EvidenceStore(tmp_path / "e.sqlite3")
    chunks = build_chunks("doc", "doc", "Image text model", [
        {"text": "Image text representations describe the visual architecture.", "page": 1},
        {"text": "Contrastive image text pre-training aligns matching pairs.", "page": 2}])
    store.index_document({"document_id": "doc", "paper_id": "doc", "title": "Image text model", "content_hash": "x"}, chunks)
    packets = HybridRetriever(store, reranker=ArchitectureFirst()).search("visual architecture",
        limit=2, document_ids={"doc"}, representative_document_ids=["doc"],
        passage_queries=["contrastive image text pretraining"])
    assert len(packets) == 2
    assert packets[0]["retrieval"]["matched_passage_facets"] == []
    assert packets[1]["retrieval"]["complementary_representative"]


def test_bibliography_is_not_promoted_as_complementary_method_evidence(tmp_path):
    store = EvidenceStore(tmp_path / "e.sqlite3")
    chunks = build_chunks("doc", "doc", "Model", [
        {"text": "Visual backbone architecture dimensions.", "page": 1},
        {"text": "Contrastive image text training aligns matching pairs.", "page": 2},
        {"text": "[1] Author. Contrastive image text training. arXiv:1234.56789\n"
                 "[2] Author. Contrastive image text training. In Proceedings, 2020.", "page": 3}])
    store.index_document({"document_id": "doc", "paper_id": "doc", "title": "Model", "content_hash": "x"}, chunks)
    packets = HybridRetriever(store, reranker=ArchitectureFirst()).search("architecture", limit=2,
        document_ids={"doc"}, representative_document_ids=["doc"], passage_queries=["contrastive image text training"])
    assert [p["locator"]["page"] for p in packets] == [1, 2]
    assert packets[1]["retrieval"]["complementary_representative"]


def test_explicit_bibliography_question_keeps_reference_list_available(tmp_path):
    store = EvidenceStore(tmp_path / "e.sqlite3")
    chunks = build_chunks("doc", "doc", "Study", [{"text":
        "[1] Author. References contrastive learning. arXiv:1234.56789\n"
        "[2] Author. References contrastive training. In Proceedings, 2020.", "page": 3}])
    store.index_document({"document_id": "doc", "paper_id": "doc", "title": "Study", "content_hash": "x"}, chunks)
    packets = HybridRetriever(store).search("references", document_ids={"doc"},
        representative_document_ids=["doc"], passage_queries=["references contrastive"])
    assert packets and packets[0]["retrieval"]["matched_passage_facets"] == ["references contrastive"]


def test_inline_citations_do_not_hide_actual_method_passage(tmp_path):
    store = EvidenceStore(tmp_path / "e.sqlite3")
    chunks = build_chunks("doc", "doc", "Model", [
        {"text": "Visual backbone architecture dimensions.", "page": 1},
        {"text": "Contrastive image text training uses paired examples [1] Author describes the loss; "
                 "[2] Author discusses negative pairs.", "page": 2}])
    store.index_document({"document_id": "doc", "paper_id": "doc", "title": "Model", "content_hash": "x"}, chunks)
    packets = HybridRetriever(store, reranker=ArchitectureFirst()).search("architecture", limit=2,
        document_ids={"doc"}, representative_document_ids=["doc"], passage_queries=["contrastive image text training"])
    assert [p["locator"]["page"] for p in packets] == [1, 2]
    assert packets[1]["retrieval"]["complementary_representative"]


def test_deadline_stops_additional_facets_but_preserves_base_recall(tmp_path, monkeypatch):
    store, _ = indexed_store(tmp_path)
    from multi_agent_rag import time
    monkeypatch.setattr(time, "monotonic", lambda: 100.0)
    packets = HybridRetriever(store).search("architecture", document_ids={"original-a"},
        passage_queries=["contrastive pretraining"], deadline_monotonic=90.0)
    assert packets
    assert all(p["retrieval"]["executed_passage_queries"] == [] and p["retrieval"]["passage_deadline_skipped"] for p in packets)
    assert not any(p["retrieval"]["complementary_representative"] for p in packets)
