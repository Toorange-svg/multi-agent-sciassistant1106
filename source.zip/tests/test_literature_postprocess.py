"""Regression tests for cross-source deduplication, reranking and sufficiency.

These are offline and deterministic. The cases mirror the real duplication the
retrieval chain produces: the same paper reached through arXiv, HAL and Zenodo
arrives as three separate records, because the chain keys candidates by
``source:paper_id``.
"""
import unittest

from deepdiver_v2.src.literature_sources import (
    INSUFFICIENT_EVIDENCE_NOTICE,
    assess_evidence_sufficiency,
    citation_label,
    deduplicate,
    rerank_papers,
)


def _paper(source, paper_id, title, **extra):
    paper = {"source": source, "paper_id": paper_id, "title": title, "abstract": ""}
    paper.update(extra)
    return paper


class CrossSourceDeduplicationTests(unittest.TestCase):
    def test_same_paper_from_three_sources_collapses_to_one(self):
        papers = [
            _paper("zenodo", "15718283", "Looped World Models", doi="10.1234/loop"),
            _paper("hal", "hal-05663714", "Looped World Models", doi="10.1234/LOOP"),
            _paper("arxiv", "2606.18208v1", "Looped World Models", doi="10.1234/loop"),
        ]
        result = deduplicate(papers)
        self.assertEqual(len(result), 1)
        # arXiv outranks HAL and Zenodo.
        self.assertEqual(result[0]["source"], "arxiv")
        self.assertEqual(sorted(result[0]["duplicate_sources"]), ["hal", "zenodo"])

    def test_title_and_author_link_records_without_a_doi(self):
        papers = [
            _paper("hal", "hal-1", "World Action Models: A Survey",
                   authors=["Qiuhong Shen"]),
            _paper("zenodo", "99", "World Action Models: A Survey",
                   authors=["Qiuhong Shen"]),
        ]
        result = deduplicate(papers)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["source"], "hal")

    def test_same_title_different_first_author_stays_separate(self):
        papers = [
            _paper("hal", "hal-1", "A Study of World Models", authors=["Alice Chen"]),
            _paper("hal", "hal-2", "A Study of World Models", authors=["Bob Ng"]),
        ]
        self.assertEqual(len(deduplicate(papers)), 2)

    def test_newest_arxiv_version_wins(self):
        papers = [
            _paper("arxiv", "2606.18208v1", "Looped World Models"),
            _paper("arxiv", "2606.18208v2", "Looped World Models"),
        ]
        result = deduplicate(papers)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["paper_id"], "2606.18208v2")

    def test_merged_record_keeps_metadata_only_one_copy_had(self):
        papers = [
            _paper("arxiv", "2606.18208v1", "Looped World Models"),
            _paper("hal", "hal-9", "Looped World Models", doi="10.1234/loop",
                   fulltext_urls=["https://hal.science/hal-9/document"]),
        ]
        result = deduplicate(papers)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["source"], "arxiv")
        # The DOI and the HAL full-text link survive the merge.
        self.assertEqual(result[0]["doi"], "10.1234/loop")
        self.assertEqual(result[0]["fulltext_urls"], ["https://hal.science/hal-9/document"])

    def test_different_papers_are_not_collapsed(self):
        papers = [
            _paper("arxiv", "2401.00001", "Retrieval Augmented Generation",
                   authors=["A One"]),
            _paper("hal", "hal-77", "Sparse Attention for Finance",
                   authors=["B Two"]),
        ]
        self.assertEqual(len(deduplicate(papers)), 2)

    def test_url_links_records_that_differ_in_title_case(self):
        papers = [
            _paper("zenodo", "1", "World Models", landing_url="https://zenodo.org/records/1"),
            _paper("zenodo", "2", "World Models ", landing_url="https://zenodo.org/records/1/"),
        ]
        self.assertEqual(len(deduplicate(papers)), 1)


class RerankTests(unittest.TestCase):
    def _candidate(self, paper_id, title, abstract="", score=0.5, **extra):
        paper = _paper("arxiv", paper_id, title, abstract=abstract, **extra)
        paper["relevance"] = {"accepted": True, "score": score}
        return paper

    def test_rerank_never_changes_the_accepted_verdict(self):
        papers = [
            self._candidate("2401.00001", "A generic paper", score=0.9),
            self._candidate("2401.00002", "Survey of limitations", score=0.4),
        ]
        ranked, _ = rerank_papers("world models", papers)
        self.assertEqual(sorted(item["relevance"]["accepted"] for item in ranked), [True, True])
        self.assertEqual(len(ranked), 2)

    def test_evidence_terms_outrank_a_higher_gate_score(self):
        papers = [
            self._candidate("2401.00001", "A generic paper", score=0.80),
            self._candidate("2401.00002", "Survey of limitations",
                            abstract="We analyse drawbacks and shortcomings.", score=0.78),
        ]
        ranked, _ = rerank_papers("world models", papers)
        self.assertEqual(ranked[0]["paper_id"], "2401.00002")

    def test_single_incidental_mention_is_demoted(self):
        papers = [
            self._candidate("2401.00001", "Unrelated topic",
                            abstract="We mention world once.", score=0.50),
            self._candidate("2401.00002", "Another topic",
                            abstract="Nothing relevant here.", score=0.50),
        ]
        ranked, diagnostics = rerank_papers("world models", papers, concepts=["world", "models"])
        self.assertFalse(diagnostics["relation_word_present"])
        self.assertIn("weak_single_mention", ranked[1]["rerank"]["adjustments"])

    def test_relation_question_disables_the_weak_match_penalty(self):
        papers = [
            self._candidate("2401.00001", "DoRA vs LoRA",
                            abstract="We mention lora once.", score=0.50),
        ]
        ranked, diagnostics = rerank_papers("How does DoRA differ from LoRA?", papers,
                                            concepts=["lora"])
        self.assertTrue(diagnostics["relation_word_present"])
        self.assertNotIn("weak_single_mention", ranked[0]["rerank"]["adjustments"])

    def test_category_penalty_only_when_the_user_named_a_category(self):
        papers = [self._candidate("2401.00001", "Some paper", score=0.60,
                                  categories=["cs.CV"])]
        # No category in the question -> no penalty at all.
        _, diagnostics = rerank_papers("world models", papers)
        self.assertEqual(diagnostics["category_tokens_from_question"], [])
        ranked, _ = rerank_papers("world models", papers)
        self.assertNotIn("category_mismatch", ranked[0]["rerank"]["adjustments"])
        # Question names cs.CL, paper declares cs.CV -> penalty.
        ranked, diagnostics = rerank_papers("cs.CL question about parsing", papers)
        self.assertEqual(diagnostics["category_tokens_from_question"], ["cs.cl"])
        self.assertIn("category_mismatch", ranked[0]["rerank"]["adjustments"])

    def test_rerank_score_is_bounded(self):
        papers = [self._candidate("2401.00001", "Survey limitations drawbacks",
                                  abstract="weakness analysis", score=1.0)]
        ranked, _ = rerank_papers("world models", papers)
        self.assertLessEqual(ranked[0]["rerank"]["rerank_score"], 1.0)
        self.assertGreaterEqual(ranked[0]["rerank"]["rerank_score"], 0.0)


class SufficiencyTests(unittest.TestCase):
    def test_below_threshold_is_insufficient(self):
        result = assess_evidence_sufficiency([_paper("arxiv", "1", "One paper")])
        self.assertEqual(result["status"], "insufficient_evidence")
        self.assertEqual(result["paper_count"], 1)
        self.assertEqual(result["minimum_required"], 2)
        self.assertEqual(result["notice"], INSUFFICIENT_EVIDENCE_NOTICE)

    def test_empty_is_insufficient(self):
        self.assertEqual(assess_evidence_sufficiency([])["status"], "insufficient_evidence")

    def test_at_threshold_is_sufficient(self):
        papers = [_paper("arxiv", "1", "One"), _paper("arxiv", "2", "Two")]
        result = assess_evidence_sufficiency(papers)
        self.assertEqual(result["status"], "sufficient")
        self.assertEqual(result["notice"], "")

    def test_threshold_is_configurable(self):
        papers = [_paper("arxiv", "1", "One")]
        self.assertEqual(assess_evidence_sufficiency(papers, minimum=1)["status"], "sufficient")


class CitationLabelTests(unittest.TestCase):
    def test_labels_use_source_and_id(self):
        self.assertEqual(citation_label({"source": "arxiv", "paper_id": "2401.12345"}),
                         "[arXiv:2401.12345]")
        self.assertEqual(citation_label({"source": "hal", "paper_id": "hal-9"}), "[HAL:hal-9]")
        self.assertEqual(citation_label({"source": "zenodo", "paper_id": "15718283"}),
                         "[Zenodo:15718283]")

    def test_missing_id_yields_no_marker(self):
        self.assertEqual(citation_label({"source": "arxiv", "paper_id": ""}), "")


if __name__ == "__main__":
    unittest.main()
