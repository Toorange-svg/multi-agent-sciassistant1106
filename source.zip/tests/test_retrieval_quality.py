import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
for entry in (ROOT, ROOT / "deepdiver_v2"):
    if str(entry) not in sys.path:
        sys.path.insert(0, str(entry))

from deepdiver_v2.src.query_router import score_literature_relevance  # noqa: E402
from tools.retrieval_debug_app import _plain_terms, _semantic_gate_rows  # noqa: E402


class RetrievalQualityTests(unittest.TestCase):
    def test_debug_gate_includes_planner_english_terms_for_chinese_question(self):
        search = {
            "arxiv": {"papers": [{
                "paper_id": "2401.00001",
                "source": "arxiv",
                "title": "World Models for Physical Dynamics",
                "abstract": "We study learned world models and physical dynamics.",
            }]}
        }
        rows = _semantic_gate_rows("世界模型有什么优势？", search, "world models advantages")
        self.assertEqual(rows[0]["scoring_status"], "ok")
        self.assertTrue(rows[0]["accepted"])

    def test_electrical_transformer_is_rejected_for_ai_limitation_query(self):
        result = score_literature_relevance(
            "What are the limitations of the Transformer architecture?",
            {
                "paper_id": "hal-electrical",
                "title": "Assessment of dynamic transformer rating considering current and temperature limitations",
                "abstract": "We study power transformer ratings, current, and temperature limitations.",
            },
        )
        self.assertFalse(result["accepted"])
        self.assertIn(result["rejection_reason"], {"domain_mismatch", "no_direct_limitation_evidence"})

    def test_peft_candidate_without_domain_adaptation_evidence_is_rejected(self):
        result = score_literature_relevance(
            "How does parameter-efficient fine-tuning affect domain adaptation?",
            {
                "paper_id": "pe-clip",
                "title": "PE-CLIP: Parameter-Efficient Fine-Tuning for Facial Expression Recognition",
                "abstract": "We adapt CLIP for facial expression recognition with parameter-efficient fine-tuning.",
            },
        )
        self.assertFalse(result["accepted"])
        self.assertEqual(result["rejection_reason"], "missing_relation_evidence")

    def test_free_text_terms_drop_generic_relation_words(self):
        self.assertEqual(_plain_terms('attention method analysis evaluation transformer'), 'attention transformer')


if __name__ == "__main__":
    unittest.main()
