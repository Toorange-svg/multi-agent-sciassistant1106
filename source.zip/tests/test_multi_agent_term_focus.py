"""Source-bound terminology, exact assertion selection and question scope."""
from copy import deepcopy
from dataclasses import replace
import json

import pytest

from multi_agent_quality import (TERM_BINDING_POLICY, ABSENCE_CHOICE_POLICY,
    source_term_definitions, check_term_family_aliases, absence_assertion_options,
    resolve_absence_choices, answer_requirements, scope_plan_to_question, answer_focus_brief,
    citation_audit_input, check_audit, publication_rejections, check_claim_revision)
from multi_agent_quality import (SHORT_CHOICE_POLICY,WITNESS_CHOICE_POLICY,AUDIT_QUOTE_MENU_POLICY,
    initial_audit_witness_options,resolve_witness_choices)
from test_multi_agent_report_fields import draft, evidence, QUOTE
from test_multi_agent_absence_basis import audit

VARIANT = 'We propose 4-bit NormalFloat (NF4) quantization.'
FAMILY = 'We term the resulting type k-bit NormalFloat (NFk).'
BAD = 'NF4（k-bit NormalFloat，NFk）用于权重量化。'
GOOD = 'NF4（4-bit NormalFloat）是该k-bit NormalFloat家族的4-bit实例。'


def terms(text=BAD):
    data, sources = draft(), evidence()
    data['term_binding_policy'] = TERM_BINDING_POLICY
    data['claims'][0].update(text=text,scope_note='',qualification='仅所引定义。',evidence_ids=['e1','e2'])
    sources['evidence'][0]['excerpt'] = VARIANT
    sources['evidence'].append({**sources['evidence'][0],'evidence_id':'e2','excerpt':FAMILY})
    return data, sources


def selected():
    data, sources = draft(), evidence()
    data['absence_choice_policy'] = ABSENCE_CHOICE_POLICY
    data['claims'][0].update(text='所选片段未提供统一对照，因此不作因果归因。',scope_note='',qualification='仅所引片段。')
    menu = absence_assertion_options(data)
    option = next(r for r in menu['options'] if r['field']=='text')
    value = audit(data)
    value['claim_results'][0]['field_results']['text']['absence_checks'] = [
        {'assertion_id':option['assertion_id'],'basis':'selected_excerpts','witness_index':None}]
    return data,sources,value,menu


def test_literal_definitions_exact_offsets_without_inventing_widths():
    data,sources = terms()
    before = deepcopy((data,sources))
    definitions = source_term_definitions(sources)
    assert [(r['alias'],r['width']) for r in definitions['records']] == [('NF4','4'),('NFk','k')]
    by_id = {r['evidence_id']:r for r in sources['evidence']}
    for row in definitions['records']:
        assert row['quote'] == by_id[row['evidence_id']]['excerpt'][row['start']:row['end']]
        assert not row['scientific_verdict']
    assert (data,sources) == before


@pytest.mark.parametrize('field',['text','scope_note','qualification'])
def test_alias_confusion_is_field_specific_not_rescued_by_correct_body(field):
    data,sources = terms(GOOD)
    data['claims'][0][field] = BAD
    issues = check_term_family_aliases(data,sources)
    assert len(issues)==1 and issues[0]['field']==field
    assert issues[0]['reason']=='TERM_FAMILY_ALIAS_CONFUSION'
    assert len(issues[0]['source_witnesses'])==2 and not issues[0]['automatic_rewrite']


@pytest.mark.parametrize('text',[GOOD,'NF4（4-bit NormalFloat），其家族记为NFk。',
    'NF4（NFk家族的一个实例）用于量化。','NF4（k-bit推广记为NFk）用于量化。',
    '不能称NF4（k-bit NormalFloat，NFk）为同义名。','NF4属于k-bit NormalFloat家族。',
    'NF4（k=4的NormalFloat）用于量化。'])
def test_specialization_membership_refutation_and_prose_are_not_alias_identity(text):
    assert not check_term_family_aliases(*terms(text))


@pytest.mark.parametrize('fault',['legacy','uncited_variant','uncited_family','unapproved',
    'cross_paper','conflicting_variant','conflicting_family','no_definition'])
def test_unknown_ambiguous_or_uncited_definitions_cannot_supply_a_verdict(fault):
    data,sources = terms()
    if fault=='legacy': data.pop('term_binding_policy')
    elif fault=='uncited_variant': data['claims'][0]['evidence_ids']=['e2']
    elif fault=='uncited_family': data['claims'][0]['evidence_ids']=['e1']
    elif fault=='unapproved': sources['evidence'][0]['review_status']='pending'
    elif fault=='cross_paper': sources['evidence'][1]['paper_id']='other'
    elif fault=='no_definition': sources['evidence'][0]['excerpt']='We use NF4.'
    else:
        sources['evidence'].append({**sources['evidence'][0],'evidence_id':'e3',
            'excerpt':'We define 8-bit OtherFloat (NF4).' if fault=='conflicting_variant' else 'We define 8-bit OtherFloat (NFk).'})
        data['claims'][0]['evidence_ids'].append('e3')
    assert not check_term_family_aliases(data,sources)


def test_generic_labels_and_source_widths_not_hardcoded_nf4_answers():
    data,sources = terms('WF6（m-bit WidgetFloat，WFm）用于量化。')
    sources['evidence'][0]['excerpt']='We use 6-bit WidgetFloat (WF6).'
    sources['evidence'][1]['excerpt']='We define m-bit WidgetFloat (WFm).'
    assert check_term_family_aliases(data,sources)
    data['claims'][0]['text']='WF6（6-bit WidgetFloat）属于WFm家族。'
    assert not check_term_family_aliases(data,sources)


def test_model_approval_does_not_override_literal_contradiction_and_repair_is_not_approval():
    data,sources = terms()
    value = audit(data)
    value['claim_results'][0]['source_witnesses']=[{'evidence_id':'e1','quote':VARIANT}]
    checked=check_audit(value,data,sources)
    checked['code_issues']=check_term_family_aliases(data,sources)
    assert not checked['contract_errors'] and publication_rejections(checked,data)=={'c1'}
    revised=deepcopy(data); revised['claims'][0]['qualification']=GOOD
    assert check_claim_revision(data,revised,{'code_issues':checked['code_issues']})['code_issues']
    revised['claims'][0]['text']=GOOD
    assert not check_claim_revision(data,revised,{'code_issues':checked['code_issues']})['code_issues']


def test_exact_assertion_id_retains_comma_scope_and_verdict_without_mutation():
    data,sources,value,menu=selected()
    before=deepcopy((data,sources,value,menu))
    normalized,resolution=resolve_absence_choices(value,menu,data)
    check=normalized['claim_results'][0]['field_results']['text']['absence_checks'][0]
    assert check['assertion']==data['claims'][0]['text'] and '，因此' in check['assertion']
    assert normalized['status']==value['status'] and len(resolution['resolutions'])==1
    assert not resolution['semantic_auto_approval']
    assert not check_audit(normalized,data,sources)['contract_errors']
    assert (data,sources,value,menu)==before


@pytest.mark.parametrize('fault',['unknown','different_claim','different_field','changed_field',
    'changed_menu_text','bool_offset','negative_offset','float_offset','missing_menu','extra_key'])
def test_bad_assertion_choices_are_not_repaired_or_published(fault):
    data,sources,value,menu=selected()
    choice=value['claim_results'][0]['field_results']['text']['absence_checks'][0]
    option=menu['options'][0]
    if fault=='unknown': choice['assertion_id']='absence-text-unknown'
    elif fault=='different_claim': value['claim_results'][0]['claim_id']='other'
    elif fault=='different_field': value['claim_results'][0]['field_results']['qualification']['absence_checks']=[choice.copy()]
    elif fault=='changed_field': data['claims'][0]['text']+=' 新字段。'
    elif fault=='changed_menu_text': option['assertion']='different text'
    elif fault=='bool_offset': option['start_char']=False
    elif fault=='negative_offset': option['start_char']=-1
    elif fault=='float_offset': option['start_char']=0.0
    elif fault=='missing_menu': menu['options']=[]
    elif fault=='extra_key': choice['assertion']='invented'
    normalized,_=resolve_absence_choices(value,menu,data)
    assert publication_rejections(check_audit(normalized,data,sources),data)=={'c1'}


def test_verdict_basis_and_witness_indices_are_never_filled_by_a_choice():
    data,sources,value,menu=selected()
    choice=value['claim_results'][0]['field_results']['text']['absence_checks'][0]
    choice['basis']='unverified'
    normalized,_=resolve_absence_choices(value,menu,data)
    assert normalized['claim_results'][0]['field_results']['text']['absence_checks'][0]['basis']=='unverified'
    assert publication_rejections(check_audit(normalized,data,sources),data)=={'c1'}


def test_menu_is_not_a_report_limit_or_an_absence_detector():
    data,_,_,_=selected()
    data['claims']=[{**data['claims'][0],'claim_id':f'c{i}'} for i in range(60)]
    assert len(absence_assertion_options(data)['options'])==48 and len(data['claims'])==60
    data['claims'][0]['text']='不能由这组数值推断因果。'
    assert absence_assertion_options(data)['options'] # Candidate only, no judgment.


def test_short_absence_handle_keeps_claim_field_and_exact_current_text_binding():
    data,sources,_,_=selected(); data['short_choice_policy']=SHORT_CHOICE_POLICY
    menu=absence_assertion_options(data); option=next(r for r in menu['options'] if r['field']=='text')
    assert option['choice_label']=='c1-text-a-1'
    value=audit(data)
    value['claim_results'][0]['field_results']['text']['absence_checks']=[
        {'choice_label':option['choice_label'],'basis':'selected_excerpts','witness_index':None}]
    normalized,receipt=resolve_absence_choices(value,menu,data)
    assert len(receipt['resolutions'])==1
    assert normalized['claim_results'][0]['field_results']['text']['absence_checks'][0]['assertion']==data['claims'][0]['text']
    assert not check_audit(normalized,data,sources)['contract_errors']


@pytest.mark.parametrize('fault',['other_claim','other_field','unknown','wrong_source','tampered_quote','old_policy'])
def test_short_source_handle_never_relaxes_source_or_claim_checks(fault):
    data,sources=draft(),evidence()
    data.update(short_choice_policy=SHORT_CHOICE_POLICY,witness_choice_policy=WITNESS_CHOICE_POLICY,
                audit_quote_menu_policy=AUDIT_QUOTE_MENU_POLICY)
    menu=initial_audit_witness_options(data,sources); option=menu['options'][0]
    value=audit(data)
    selection={'evidence_id':'e1','choice_label':option['choice_label']}
    if fault=='other_claim': selection['choice_label']='c2-i-1'
    elif fault=='other_field': selection['choice_label']='c1-text-a-1'
    elif fault=='unknown': selection['choice_label']='c1-i-999'
    elif fault=='wrong_source': selection['evidence_id']='other'
    elif fault=='tampered_quote': option['quote']='not the source'
    elif fault=='old_policy': data.pop('short_choice_policy')
    value['claim_results'][0]['source_witnesses']=[selection]
    normalized,_=resolve_witness_choices(value,menu,data,sources)
    assert publication_rejections(check_audit(normalized,data,sources),data)=={'c1'}


@pytest.mark.parametrize('phase',['i','r'])
def test_initial_and_correction_labels_survive_identical_quote_id_deduplication(phase):
    data,sources=draft(),evidence()
    data.update(short_choice_policy=SHORT_CHOICE_POLICY,witness_choice_policy=WITNESS_CHOICE_POLICY,
                audit_quote_menu_policy=AUDIT_QUOTE_MENU_POLICY)
    option=initial_audit_witness_options(data,sources)['options'][0]
    menu={'options':[option,{**option,'choice_label':'c1-r-1'}]}
    value=audit(data)
    value['claim_results'][0]['source_witnesses']=[{'evidence_id':'e1','choice_label':f'c1-{phase}-1'}]
    normalized,receipt=resolve_witness_choices(value,menu,data,sources)
    assert len(receipt['resolutions'])==1
    assert not check_audit(normalized,data,sources)['contract_errors']


@pytest.mark.parametrize('question,keep',[
    ('解释Table 3的模型与指标。',False),
    ('比较Table 3并检查置信区间、显著性与方差。',True),
])
def test_unasked_statistical_plan_obligations_removed_but_explicit_requests_retained(question,keep):
    plan={'groups':[{'id':'g1','metrics':['comparison','variance','confidence_interval','statistical_significance']}]}
    original=deepcopy(plan)
    scoped,_=scope_plan_to_question(plan,answer_requirements(question))
    assert scoped==plan if keep else scoped['groups'][0]['metrics']==['comparison']
    assert plan==original


def test_focus_brief_does_not_erase_evidence_or_essential_boundaries():
    req=answer_requirements('解释Table 3，不需要完整公式推导。')
    plan={'groups':[{'id':'g1','question':'read table','metrics':['comparison']}]}
    before=deepcopy((req,plan))
    brief=answer_focus_brief(req,plan)
    assert 'confidence_intervals' in brief['not_mandatory_for_this_question']
    assert not brief['automatic_claim_removal'] and not brief['evidence_auto_approval']
    assert (req,plan)==before


@pytest.mark.parametrize('question,requested',[
    ('解释冻结底座是否参与反向传播。',False),
    ('请推导LoRA梯度公式。',True),
    ('解释偏导数符号。',True),
])
def test_prose_backpropagation_is_not_a_request_for_partial_derivative_notation(question,requested):
    assert answer_requirements(question)['answer_focus']['derivative_notation_requested'] is requested


@pytest.mark.parametrize('payload,reason,schema_present',[
    ({'output':{'schema_version':'unknown-version','groups':[]}},'ROLE_SCHEMA_VERSION_INVALID',False),
    ({'output':{'schema_version':'sciassistant.research-plan/v7','groups':[{'id':'g1','core':{'bad':'shape'}}]}},'PLAN_TERMS_INVALID',True),
])
def test_live_schema_diagnostic_has_static_reason_and_checks_output_not_root(payload,reason,schema_present):
    from multi_agent_live import LiveModelClient
    from test_multi_agent_live import Response,config
    client=LiveModelClient(config(),post=lambda *_a,**_k:Response(payload))
    value=client.call('planner',{'deadline_at':__import__('time').time()+60,'inputs':[]})
    assert value['error_code']=='MODEL_SCHEMA_REJECTED'
    assert value['output']['format_reason']==reason
    assert value['output']['expected_schema_present'] is schema_present
    assert 'unknown-version' not in json.dumps(value)


@pytest.mark.parametrize('scope',['arxiv','uploaded_pdf','uploaded_pdf_and_arxiv'])
def test_prompt_metadata_hash_is_the_complete_contract_actually_sent(scope):
    from multi_agent_live import LiveModelClient
    from test_multi_agent_live import Response,config
    import hashlib
    captured=[]
    def post(_url,**kwargs):
        captured.append(kwargs['json']['messages'][0]['content'])
        from test_multi_agent_live import typed_plan_fixture
        return Response({'output': typed_plan_fixture()})
    client=LiveModelClient(config(),post=post)
    value=client.call('planner',{'deadline_at':__import__('time').time()+60,
        'inputs':[{'payload':{'source_scope':scope}}]})
    assert value.get('error_code') is None
    assert 'REQUIRED RETURN CONTRACT' in captured[0]
    assert hashlib.sha256(captured[0].encode()).hexdigest()==client.prompt_metadata(source_scope=scope)['planner']['sha256']
    assert ('In uploaded_pdf-only scope use source_hints=[]' in captured[0]) is (scope=='uploaded_pdf')


def test_formal_workflow_uses_explicit_assertion_choice_on_first_audit_in_five_calls(tmp_path):
    from test_multi_agent_pipeline_v2 import agents,pipeline
    configured,calls=agents()
    data,_,_,_=selected(); data['claims'][0]['evidence_ids']=['arxiv-1']
    def writer(_):
        calls.append('writer'); return {'output':data}
    def auditor(packet):
        calls.append('citation_auditor')
        supplied=next(r['payload'] for r in packet['inputs'] if r['payload'].get('schema_version')=='sciassistant.citation-audit-input/v1')
        option=next(r for r in supplied['absence_assertion_options']['options'] if r['field']=='text')
        witness=supplied['source_witness_options']['options'][0]
        value=audit(data)
        value['claim_results'][0]['source_witnesses']=[{'evidence_id':'arxiv-1','choice_label':witness['choice_label']}]
        value['claim_results'][0]['field_results']['text']['absence_checks']=[
            {'choice_label':option['choice_label'],'basis':'selected_excerpts','witness_index':None}]
        return {'output':value}
    configured.writer.handler,configured.citation_auditor.handler=writer,auditor
    flow,_=pipeline(tmp_path,configured,search=lambda *_:{'status':'ok','papers':[{'paper_id':'1','title':'Source','abstract':QUOTE}]})
    result=flow.run('absence-id','owner','解释该方法')
    assert result['run']['model_calls_used']==5 and result['run']['status']=='completed'
    events=[json.loads(l) for l in (tmp_path/'events.jsonl').read_text().splitlines()]
    assert any(r['event']=='audit_absence_choices_resolved' and r['phase']=='initial' for r in events)
    assert not any(r['event']=='audit_protocol_retry' for r in events)


def test_formal_workflow_repairs_literal_family_confusion_and_reaudits(tmp_path):
    from test_multi_agent_pipeline_v2 import agents,pipeline,worker
    configured,calls=agents(partial=True)
    seen=[]
    def writer(_):
        calls.append('writer'); seen.append(1)
        data,_=terms(BAD if len(seen)==1 else GOOD)
        data['claims'][0].update(evidence_ids=['arxiv-1'],confidence='low',qualification='仅所选摘要定义。')
        return {'output':data}
    configured=replace(configured,writer=worker('writer',writer,'write_approved_claims'))
    flow,_=pipeline(tmp_path,configured,search=lambda *_:{'status':'ok','papers':[
        {'paper_id':'1','title':'Types','abstract':VARIANT+' '+FAMILY}]})
    result=flow.run('term-repair','owner','解释类型的关系。')
    assert calls.count('writer')==calls.count('citation_auditor')==2
    assert result['run']['model_calls_used']==7
    assert GOOD in result['direct_answer'] and BAD not in result['direct_answer']
