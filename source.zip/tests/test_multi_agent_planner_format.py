"""A malformed Planner reply can be regenerated once, never patched or approved."""
import copy
import json
import time

import pytest

from multi_agent_live import LiveModelClient
from multi_agent_pipeline_v2 import PipelineExecutionError
from test_multi_agent_live import Response, config, add_typed_report_review
from test_multi_agent_pipeline_v2 import agents, pipeline


@pytest.mark.parametrize("error", ["MODEL_JSON_INVALID", "MODEL_SCHEMA_REJECTED"])
def test_planner_correction_has_own_budget_and_identical_inputs(tmp_path, error):
    configured, calls = agents()
    valid = configured.planner.handler
    seen = []
    def planner(packet):
        seen.append(copy.deepcopy(packet))
        return {"status": "failed", "error_code": error} if len(seen) == 1 else valid(packet)
    configured.planner.handler = planner
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("planner-repair", "owner", "Compare A")
    assert result["run"]["status"] == "completed"
    assert result["run"]["model_calls_used"] == 6
    assert seen[0]["inputs"] == seen[1]["inputs"]
    assert seen[1]["remaining_model_calls"] == seen[0]["remaining_model_calls"] - 1
    assert calls == ["planner", "retriever", "reviewer", "writer", "citation_auditor"]
    records = sorted(p.name for p in (tmp_path / "agents").glob("*-planner.json"))
    assert records == ["01-planner.json", "02-planner.json"]
    events = [json.loads(line) for line in (tmp_path / "events.jsonl").read_text().splitlines()]
    retries = [row for row in events if row["event"] == "agent_format_retry"]
    assert len(retries) == 1 and retries[0]["role"] == "planner"
    assert retries[0]["reason_code"] == error


def test_real_adapter_invalid_json_then_complete_plan(tmp_path, monkeypatch):
    monkeypatch.setenv("MODEL_REQUEST_URL", "https://example.test/v1/chat/completions")
    configured, _ = agents()
    valid = configured.planner.handler
    responses = []
    class BrokenResponse(Response):
        def iter_content(self, **kwargs):
            yield json.dumps({"choices": [{"finish_reason": "stop", "message": {
                "content": '{"output":{"queries":["ti:"ViT""]}}'}}]}).encode()
    def post(_url, **kwargs):
        packet = json.loads(kwargs["json"]["messages"][1]["content"])
        from test_multi_agent_live import typed_plan_fixture
        response = BrokenResponse(None) if not responses else Response({'output': typed_plan_fixture()})
        responses.append(response)
        return response
    client = LiveModelClient(config(), post=post)
    configured.planner.handler = lambda packet: client.call("planner", packet)
    from tests.test_multi_agent_sections import good_draft
    configured.writer.handler = lambda p: {'output': good_draft(next(i['payload'] for i in p['inputs']
        if i['payload'].get('schema_version') == 'sciassistant.writer-job/v1'))}
    add_typed_report_review(configured)
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("adapter-repair", "owner", "Compare A")
    assert result["run"]["status"] == "completed"
    assert result["run"]["model_calls_used"] == 6
    assert len(responses) == 2 and all(row.closed for row in responses)
    events = [json.loads(line) for line in (tmp_path/'events.jsonl').read_text().splitlines()]
    assert len([e for e in events if e['event']=='agent_started' and e['role']=='citation_auditor']) == 1
    assert not any(e['event']=='audit_protocol_retry' for e in events)


@pytest.mark.parametrize("error", ["MODEL_HTTP_429", "MODEL_SERVICE_UNAVAILABLE",
                                  "MODEL_OUTPUT_TRUNCATED", "AGENT_CONTRACT_REJECTED",
                                  "AGENT_DEADLINE_EXCEEDED"])
def test_planner_does_not_retry_non_format_failures(tmp_path, error):
    configured, _ = agents()
    configured.planner.handler = lambda _: {"status": "failed", "error_code": error}
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("planner-failure", "owner", "Compare A")
    assert result["run"]["model_calls_used"] == 1
    assert result["run"]["failure_code"] == error
    assert not flow.planner_format_retry_used


def test_planner_correction_failure_uses_literal_question_fallback(tmp_path):
    configured, _ = agents()
    configured.planner.handler = lambda _: {"status": "failed", "error_code": "MODEL_JSON_INVALID"}
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("planner-double-failure", "owner", "Compare A")
    assert result["run"]["status"] == "completed"
    assert result["run"]["model_calls_used"] == 6
    events = [json.loads(line) for line in (tmp_path/'events.jsonl').read_text().splitlines()]
    assert any(event["event"] == "planner_format_fallback" for event in events)


@pytest.mark.parametrize("reserve", ["time", "calls", "used"])
def test_planner_correction_preserves_retrieval_review_and_answer_reserves(tmp_path, reserve):
    configured, _ = agents()
    configured.planner.handler = lambda _: {"status": "failed", "error_code": "MODEL_JSON_INVALID"}
    flow, store = pipeline(tmp_path, configured)
    store.create_run("planner-reserve", "owner")
    flow.deadline = time.monotonic() + (200 if reserve == "time" else 360)
    if reserve == "calls":
        for _ in range(5):
            store.reserve_model_call("planner-reserve", "planner")
    if reserve == "used":
        flow.planner_format_retry_used = True
    before = store.get_run("planner-reserve")["model_calls_used"]
    with pytest.raises(PipelineExecutionError, match="MODEL_JSON_INVALID"):
        flow._invoke("planner-reserve", "planner", "planning", [])
    assert store.get_run("planner-reserve")["model_calls_used"] == before + 1
    assert store.get_run("planner-reserve")["model_calls_used"] <= 10
