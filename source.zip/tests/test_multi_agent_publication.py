"""Publication coverage must use actual audited claims, never draft counts."""
from copy import deepcopy
import json
import pytest

from multi_agent_publication import (PUBLICATION_POLICY, AUDIT_MATERIAL_POLICY, audit_material,
    review_request, check_review, coverage, recovery_brief, conflict_issues, retain_untargeted_claims,
    delivery_markdown)
from multi_agent_quality import publication_rejections, check_audit
from multi_agent_agents import ArtifactDirectory, AgentContractError
from test_multi_agent_report_fields import draft as base_draft, evidence, audit as base_audit


def data():
    ledger={'requirements':[{'requirement_id':'r1','question_quote':'解释机制。','answer_kind':'mechanism'},
        {'requirement_id':'r2','question_quote':'给出实验方案。','answer_kind':'proposal'},
        {'requirement_id':'r3','question_quote':'保留适用条件。','answer_kind':'constraint'}]}
    draft=base_draft()
    a=draft['claims'][0]
    a.update(requirement_ids=['r1'],claim_id='c1')
    draft['claims'].append({**deepcopy(a),'claim_id':'c2','requirement_ids':['r2'],'text':'尚未执行的实验方案。'})
    review={'schema_version':'sciassistant.report-review/v1','requirements':[
        {'requirement_id':'r1','status':'answered','claim_ids':['c1'],'reason':'具体解释了机制。'},
        {'requirement_id':'r2','status':'answered','claim_ids':['c2'],'reason':'具体方案有因素和判据。'}],
        'consistency':{'reviewed_claim_ids':['c1','c2'],'conflicts':[]}}
    return ledger,draft,review


def test_requirement_review_uses_original_order_and_ignores_global_guidance_as_answer():
    ledger,draft,review=data()
    request=review_request(ledger,draft)
    assert [r['requirement_id'] for r in request['requirements']]==['r1','r2']
    assert request['claim_ids']==['c1','c2'] and not request['semantic_auto_approval']
    result=coverage(ledger,draft,{'report_review':review},set())
    assert [r['status'] for r in result['requirements']]==['answered','answered','guidance']
    assert result['all_content_answered'] and not result['semantic_auto_approval']


@pytest.mark.parametrize('rowstatus',['answered','limited'])
def test_isolated_answer_cannot_be_counted_from_draft_self_report(rowstatus):
    ledger,draft,review=data()
    review['requirements'][1]['status']=rowstatus
    result=coverage(ledger,draft,{'report_review':review},{'c2'})
    assert result['requirements'][1]['status']=='unanswered'
    assert result['unresolved_requirement_ids']==['r2'] and not result['all_content_answered']


def test_partial_dependency_loss_downgrades_semantic_coverage_not_auto_limited():
    ledger,draft,review=data()
    draft['claims'].append({**deepcopy(draft['claims'][1]),'claim_id':'c3'})
    review['requirements'][1]['claim_ids'].append('c3')
    review['consistency']['reviewed_claim_ids'].append('c3')
    result=coverage(ledger,draft,{'report_review':review},{'c2'})
    assert result['requirements'][1]['status']=='needs_review'
    assert result['requirements'][1]['published_claim_ids']==['c3']


@pytest.mark.parametrize('bad',[None,{},[],True,{'schema_version':'unknown'}])
def test_missing_review_preserves_claims_but_never_claims_answered(bad):
    ledger,draft,_=data()
    original=deepcopy(draft)
    result=coverage(ledger,draft,{'report_review':bad},set())
    assert result['review_errors'] and all(r['status']=='needs_review' for r in result['requirements'][:2])
    assert draft==original


@pytest.mark.parametrize('mutate',[
    lambda v:v['requirements'].append(deepcopy(v['requirements'][0])),
    lambda v:v['requirements'].pop(),
    lambda v:v['requirements'][0].update(requirement_id='unknown'),
    lambda v:v['requirements'][0].update(claim_ids=['unknown']),
    lambda v:v['requirements'][0].update(claim_ids=['c2']),
    lambda v:v['requirements'][0].update(claim_ids=['c1','c1']),
    lambda v:v['requirements'][0].update(status='answered',claim_ids=[]),
    lambda v:v['requirements'][0].update(status='unanswered',claim_ids=['c1']),
    lambda v:v['requirements'][0].update(reason=''),
    lambda v:v['requirements'][0].update(reason='x'*801),
    lambda v:v['requirements'][0].update(claim_ids=[{}]),
    lambda v:v['requirements'][0].update(requirement_id=[]),
    lambda v:v['requirements'][0].update(extra='forged'),
])
def test_invalid_coverage_never_guesses_completed_requirements(mutate):
    ledger,draft,review=data()
    mutate(review)
    assert check_review(review,ledger,draft)['errors']
    assert not coverage(ledger,draft,{'report_review':review},set())['all_content_answered']


def test_one_invalid_row_does_not_erase_independent_valid_review_row():
    ledger,draft,review=data()
    review['requirements'][1]['claim_ids']=['unknown']
    result=coverage(ledger,draft,{'report_review':review},set())
    assert result['requirements'][0]['status']=='answered' and result['requirements'][1]['status']=='needs_review'


def test_lexical_disclaimer_with_correct_binding_not_automatically_answered():
    ledger,draft,review=data()
    draft['claims'][1]['text']='没有证据。'
    review['requirements'][1].update(status='unanswered',claim_ids=[],reason='只有缺项提示，没有实验设计。')
    result=coverage(ledger,draft,{'report_review':review},set())
    assert result['requirements'][1]['status']=='unanswered'
    # A model can still wrongly say answered: retain this semantic counterexample.
    review['requirements'][1].update(status='answered',claim_ids=['c2'])
    assert coverage(ledger,draft,{'report_review':review},set())['all_content_answered']
    assert not result['semantic_auto_approval']


@pytest.mark.parametrize('fault',['missing_ids','unknown_id','duplicate','no_detail','same_id','not_list'])
def test_invalid_consistency_cannot_invent_scientific_rejections(fault):
    ledger,draft,review=data()
    item={'claim_ids':['c1','c2'],'detail':'首段与结尾给出相反的同条件结论。'}
    review['consistency']['conflicts']=[item]
    if fault=='missing_ids':review['consistency']['reviewed_claim_ids']=[]
    elif fault=='unknown_id':item['claim_ids']=['c1','unknown']
    elif fault=='duplicate':review['consistency']['reviewed_claim_ids']=['c1','c1']
    elif fault=='no_detail':item['detail']=''
    elif fault=='same_id':item['claim_ids']=['c1','c1']
    else:review['consistency']['conflicts']=True
    checked=check_review(review,ledger,draft)
    assert not checked['consistency_verified'] and not conflict_issues(checked)


def test_actual_cross_section_conflict_isolates_claims_and_dependent_consequence():
    ledger,draft,review=data()
    draft['claims'].append({**deepcopy(draft['claims'][0]),'claim_id':'c3','depends_on_claim_ids':['c1']})
    review['consistency']['reviewed_claim_ids'].append('c3')
    review['consistency']['conflicts']=[{'claim_ids':['c1','c2'],'detail':'同条件数值排序互相矛盾。'}]
    checked=check_review(review,ledger,draft)
    a=base_audit(draft)
    a['code_issues']=conflict_issues(checked)
    assert publication_rejections(a,draft)=={'c1','c2','c3'}


def test_unchanged_conflicting_assertions_cannot_reappear_by_new_consistent_label():
    from multi_agent_quality import check_claim_revision
    ledger,draft,review=data()
    review['consistency']['conflicts']=[{'claim_ids':['c1','c2'],'detail':'明确相反断言。'}]
    feedback={'model_audit':base_audit(draft),'code_issues':conflict_issues(check_review(review,ledger,draft))}
    assert len(check_claim_revision(draft,draft,feedback)['code_issues'])==2
    revised=deepcopy(draft);revised['claims']=revised['claims'][:1]
    assert not check_claim_revision(draft,revised,feedback)['code_issues']
    renamed=deepcopy(draft);renamed['claims'][1]['claim_id']='renamed'
    assert check_claim_revision(draft,renamed,feedback)['code_issues']


def test_recovery_has_only_actual_unresolved_asks_and_approved_sources_no_new_tools():
    ledger,draft,review=data()
    delivery=coverage(ledger,draft,{'report_review':review},{'c2'})
    brief=recovery_brief(delivery,{'evidence':[{'evidence_id':'a','review_status':'approved'},
        {'evidence_id':'b','review_status':'rejected'}]})
    assert [r['requirement_id'] for r in brief['requirements']]==['r2']
    assert brief['allowed_evidence_ids']==['a'] and brief['uses_existing_writer_revision_round']
    assert brief['full_reaudit_required'] and 'tool_requests' not in brief


def test_retention_only_independent_approved_untargeted_content_before_reaudit():
    _,draft,_=data()
    revised=deepcopy(draft);revised['claims']=[]
    result,receipt=retain_untargeted_claims(draft,revised,{'c1','c2'},['r2'])
    assert [c['claim_id'] for c in result['claims']]==['c1']
    assert receipt['full_reaudit_required'] and not receipt['automatic_publication']
    assert revised['claims']==[]


def test_retention_never_adds_missing_ineligible_dependency_or_overwrites_new_text():
    _,draft,_=data()
    draft['claims'][0]['depends_on_claim_ids']=['c2']
    revised=deepcopy(draft);revised['claims']=[]
    result,_=retain_untargeted_claims(draft,revised,{'c1'},[])
    assert not result['claims']
    revised['claims']=[{**deepcopy(draft['claims'][0]),'text':'新修订内容'}]
    result,_=retain_untargeted_claims(draft,revised,{'c1'},[])
    assert result['claims'][0]['text']=='新修订内容'


def test_audit_compaction_removes_duplicates_not_source_job_or_choice_content(tmp_path):
    value={'claims':[{'text':'same'*90000}], 'audit_jobs':[{'claim_id':'c1','claim':{'text':'same'*90000},
        'source_witness_options':[{'quote':'Original exact quotation','quote_id':'q1'}]}],
        'source_witness_options':{'options':[{'quote':'Original exact quotation','quote_id':'q1'}]},
        'approved_source_catalog':[{'excerpt':'complete original '*20000}],
        'report_review_request':{'requirements':[{'question_quote':'原问题'}]}}
    original=deepcopy(value)
    compact=audit_material(value)
    assert compact['audit_jobs']==value['audit_jobs'] and compact['approved_source_catalog']==value['approved_source_catalog']
    assert compact['report_review_request']==value['report_review_request']
    assert compact['audit_material']['policy']==AUDIT_MATERIAL_POLICY and not compact['audit_material']['source_or_claim_truncated']
    assert value==original and 'claims' not in compact
    # The existing safety ceiling is unchanged; oversized unreduced data is rejected.
    store=ArtifactDirectory(tmp_path)
    with pytest.raises(AgentContractError,match='artifact exceeds size limit'):store.put('large',{'text':'x'*1000001})
    with pytest.raises(AgentContractError,match='artifact exceeds size limit'):store.put('unpacked',value)
    store.put('compact',compact)


def test_markdown_checklist_has_each_actual_ask_and_specific_incomplete_reason():
    ledger,draft,review=data()
    result=coverage(ledger,draft,{'report_review':review},{'c2'})
    text=delivery_markdown(result)
    assert '解释机制。' in text and '给出实验方案。' in text and '未完成' in text
    assert '保留适用条件。' not in text and 'c2' not in text


def flow_fixture(tmp_path):
    from tools.multi_agent_cli import _mock_agents,_mock_search
    from multi_agent_workflow import WorkflowStore
    from multi_agent_pipeline_v2 import LiteraturePipelineV2,DeterministicLiteratureExecutor
    workers=_mock_agents()
    artifacts=ArtifactDirectory(tmp_path/'artifacts')
    flow=LiteraturePipelineV2(WorkflowStore(tmp_path/'workflow.sqlite3'),artifacts,workers,
        DeterministicLiteratureExecutor(_mock_search),event_path=tmp_path/'events.jsonl')
    return flow,workers,artifacts


def test_missing_report_metadata_correction_cannot_erase_source_approved_body(tmp_path):
    flow,workers,artifacts=flow_fixture(tmp_path)
    original=workers.citation_auditor.handler
    calls=[]
    def missing(packet):
        calls.append(1)
        result=original(packet)
        result['output'].pop('report_review')
        return result
    workers.citation_auditor.handler=missing
    result=flow.run('meta-missing','owner','解释机制。')
    assert result['run']['status']=='needs_review' and result['run']['failure_code'] is None
    assert len(calls)==2 and result['run']['model_calls_used']==6
    final=artifacts.get(result['final_artifact_id'])
    delivery=artifacts.get(final['artifact_refs']['publication_coverage'])
    assert delivery['review_errors'] and not delivery['all_content_answered']
    assert '这是仅用于验证分节流水线的有限回答' in result['direct_answer']


def test_real_workflow_one_bounded_coverage_repair_then_full_reaudit(tmp_path):
    flow,workers,artifacts=flow_fixture(tmp_path)
    audit=workers.citation_auditor.handler
    writer=workers.writer.handler
    calls=[];writes=[]
    def incomplete_then_complete(packet):
        calls.append(1)
        result=audit(packet)
        if len(calls)==1:
            for row in result['output']['report_review']['requirements']:
                row.update(status='unanswered',claim_ids=[],reason='当前文字没有真正解释用户所问机制。')
        return result
    def write(packet):
        writes.append(1)
        if len(writes)==2:
            recovery=next(i['payload'] for i in packet['inputs'] if i['payload'].get('schema_version')=='sciassistant.publication-recovery/v1')
            assert recovery['requirements'] and recovery['full_reaudit_required']
            assert 'tool_requests' not in recovery
        return writer(packet)
    workers.writer.handler=write
    workers.citation_auditor.handler=incomplete_then_complete
    result=flow.run('coverage-repair','owner','解释机制。')
    assert result['run']['status']=='partial' and result['run']['model_calls_used']==7
    assert len(calls)==2 and len(writes)==2
    final=artifacts.get(result['final_artifact_id'])
    delivery=artifacts.get(final['artifact_refs']['publication_coverage'])
    assert delivery['all_content_answered']


def test_unresolved_asks_stop_after_one_repair_and_exports_keep_incomplete_reasons(tmp_path):
    from multi_agent_report import export_run_report
    flow,workers,artifacts=flow_fixture(tmp_path)
    original=workers.citation_auditor.handler
    calls=[]
    def incomplete(packet):
        calls.append(1);result=original(packet)
        for row in result['output']['report_review']['requirements']:
            row.update(status='unanswered',claim_ids=[],reason='原文不足以给出所要求的实验方案。')
        return result
    workers.citation_auditor.handler=incomplete
    result=flow.run('still-incomplete','owner','给出实验方案。')
    assert result['run']['status']=='partial' and result['run']['model_calls_used']==7 and len(calls)==2
    final=artifacts.get(result['final_artifact_id'])
    delivery=artifacts.get(final['artifact_refs']['publication_coverage'])
    assert delivery['unresolved_requirement_ids'] and not delivery['all_content_answered']
    # Minimal manifest for the ordinary export path; no live source access.
    (tmp_path/'manifest.json').write_text(json.dumps({'final_artifact_id':result['final_artifact_id']}),encoding='utf-8')
    export_run_report(tmp_path)
    md=(tmp_path/'final_answer.md').read_text(encoding='utf-8-sig')
    html=(tmp_path/'final_answer.html').read_text(encoding='utf-8')
    assert '用户要求交付清单' in md and '未完成' in md and 'report-delivery' in html
    assert '原文不足以给出所要求的实验方案。' in md and '原文不足以给出所要求的实验方案。' in html


@pytest.mark.parametrize('error', ['MODEL_SERVICE_UNAVAILABLE','MODEL_HTTP_502','MODEL_HTTP_503','MODEL_HTTP_504','MODEL_HTTP_402','MODEL_HTTP_401','MODEL_HTTP_403'])
def test_optional_recovery_transient_preserves_approved_sources_but_auth_and_payment_stop(tmp_path,error):
    from multi_agent_pipeline_v2 import PipelineExecutionError
    flow,workers,artifacts=flow_fixture(tmp_path)
    review=workers.reviewer.handler
    retriever=workers.retriever.handler
    calls=[]
    def partial(packet):
        result=review(packet)
        result['output']['coverage'][0].update(status='partial',metric='definition',recommended_action='search_more')
        return result
    def source(packet):
        calls.append(1)
        if len(calls)>1: return {'status':'failed','error_code':error}
        return retriever(packet)
    workers.reviewer.handler=partial
    workers.retriever.handler=source
    def gap(packet):
        targets=next(i['payload']['targets'] for i in packet['inputs']
            if i['payload'].get('schema_version')=='sciassistant.gap-targets/v1')
        return {'output':{'gaps':[{**r,'query':'specific supplementary evidence'} for r in targets]}}
    workers.gap_analyst.handler=gap
    result=flow.run('transient-recovery','owner','解释机制。')
    assert len(calls)==2, 'The fixture must reach the actual recovery Retriever, not reject its Gap plan earlier.'
    if error in {'MODEL_HTTP_402','MODEL_HTTP_401','MODEL_HTTP_403'}:
        assert result['run']['status']=='failed' and result['run']['failure_code']==error
    else:
        assert result['run']['status']=='needs_review' and result['run']['failure_code'] is None
        assert '有限回答' in result['direct_answer']
