"""Development-only evidence and debug downloads are hidden from the user UI."""
from pathlib import Path
import shutil
import subprocess

import pytest


HTML_PATH = Path(__file__).resolve().parents[1] / 'chatAi/ai_chat.html'
RAG_PATH = Path(__file__).resolve().parents[1] / 'chatAi' / 'multi_agent_rag.js'


def test_development_evidence_download_entries_are_removed():
    html = HTML_PATH.read_text(encoding='utf-8')
    rag = RAG_PATH.read_text(encoding='utf-8')
    for marker in ('appendScienceEvidenceDownload', 'restoreScienceEvidenceDownload',
                   '验收证据包', '运行与验收证据', '完整调试 Markdown', '下载 JSON 运行证据包'):
        assert marker not in html
        assert marker not in rag
    assert '/export?format=md' in html


def test_inline_frontend_scripts_parse_in_node():
    node = shutil.which('node')
    if not node:
        pytest.skip('Node required for JavaScript syntax verification')
    source = RAG_PATH.read_text(encoding='utf-8')
    checked = subprocess.run([node, '--check', '-'], input=source, text=True,
                             capture_output=True, encoding='utf-8', timeout=10)
    assert checked.returncode == 0, checked.stderr
