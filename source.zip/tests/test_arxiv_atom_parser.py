from pathlib import Path
import sys

import pytest

ROOT = Path(__file__).resolve().parents[1]
for entry in (str(ROOT), str(ROOT / "deepdiver_v2")):
    if entry not in sys.path:
        sys.path.insert(0, entry)

from deepdiver_v2.src.arxiv_atom import (  # noqa: E402
    ArxivAtomError, MAX_AUTHOR_NAME_CHARS, MAX_AUTHORS, MAX_CATEGORIES,
    MAX_CATEGORY_CHARS, MAX_DOI_CHARS, MAX_SUMMARY_CHARS, MAX_TITLE_CHARS,
    parse_arxiv_atom, read_bounded_arxiv_response,
)
from deepdiver_v2.src.tools.mcp_tools import _papers_from_arxiv_atom  # noqa: E402

ATOM = b"""<?xml version="1.0" encoding="UTF-8"?>
<feed xmlns="http://www.w3.org/2005/Atom" xmlns:arxiv="http://arxiv.org/schemas/atom">
  <entry>
    <id>https://arxiv.org/abs/2401.00001v2</id>
    <updated>2024-01-02T03:04:05Z</updated>
    <published>2024-01-01T01:02:03Z</published>
    <title>  A\n  bounded   parser  </title>
    <summary>XML text with &amp; escaped content.</summary>
    <author><name>Alice Example</name></author>
    <author><name>Bob Example</name></author>
    <link href="https://arxiv.org/abs/2401.00001v2" type="text/html"/>
    <link href="https://arxiv.org/pdf/2401.00001v2" type="application/pdf" title="pdf"/>
    <category term="cs.AI"/>
    <arxiv:doi>10.1000/example</arxiv:doi>
  </entry>
</feed>"""


def test_atom_parser_preserves_product_fields():
    entries = parse_arxiv_atom(ATOM)
    assert entries == [{
        "id": "https://arxiv.org/abs/2401.00001v2",
        "paper_id": "2401.00001v2",
        "title": "A bounded parser",
        "summary": "XML text with & escaped content.",
        "published": "2024-01-01T01:02:03Z",
        "updated": "2024-01-02T03:04:05Z",
        "authors": ["Alice Example", "Bob Example"],
        "links": [
            {"href": "https://arxiv.org/abs/2401.00001v2", "type": "text/html", "rel": "", "title": ""},
            {"href": "https://arxiv.org/pdf/2401.00001v2", "type": "application/pdf", "rel": "", "title": "pdf"},
        ],
        "categories": ["cs.AI"],
        "doi": "10.1000/example",
    }]


def test_mcp_adapter_keeps_dates_pdf_categories_and_doi():
    paper = _papers_from_arxiv_atom(ATOM)[0]
    assert paper["paper_id"] == "2401.00001v2"
    assert paper["authors"] == "Alice Example; Bob Example"
    assert paper["pdf_url"] == "https://arxiv.org/pdf/2401.00001v2"
    assert paper["published_date"] == "2024-01-01T01:02:03"
    assert paper["updated_date"] == "2024-01-02T03:04:05"
    assert paper["categories"] == "cs.AI"
    assert paper["doi"] == "10.1000/example"


def test_literature_adapter_preserves_publication_and_revision_separately(monkeypatch):
    from deepdiver_v2.src import literature_sources
    class Response:
        headers = {}
        def iter_content(self, **_kwargs):
            yield ATOM
        def close(self):
            pass
    monkeypatch.setattr(literature_sources, "_request", lambda *_a, **_k: Response())
    paper = literature_sources._arxiv("attention", 5)[0]
    assert paper["published_at"] == "2024-01-01T01:02:03Z"
    assert paper["updated_at"] == "2024-01-02T03:04:05Z"


def test_untrusted_atom_urls_cannot_replace_official_paper_links():
    poisoned = ATOM.replace(
        b"https://arxiv.org/abs/2401.00001v2",
        b"https://evil.example/abs/2401.00001v2",
    ).replace(
        b"https://arxiv.org/pdf/2401.00001v2",
        b"https://evil.example/collect.pdf",
    )
    paper = _papers_from_arxiv_atom(poisoned)[0]
    assert paper["url"] == "https://arxiv.org/abs/2401.00001v2"
    assert paper["pdf_url"] == "https://arxiv.org/pdf/2401.00001v2"
    parsed = parse_arxiv_atom(poisoned)[0]
    assert "evil.example" not in str(parsed)
    assert parsed["id"] == "https://arxiv.org/abs/2401.00001v2"


@pytest.mark.parametrize("bad_id", ["../private", "2401.00001?token=secret", "https://evil.example/x"])
def test_invalid_atom_identifiers_are_ignored(bad_id):
    payload = ATOM.replace(b"https://arxiv.org/abs/2401.00001v2", bad_id.encode("utf-8"))
    assert parse_arxiv_atom(payload) == []


def test_duplicate_atom_identifiers_are_emitted_once():
    entry = ATOM.split(b"<entry>", 1)[1].split(b"</entry>", 1)[0]
    duplicated = ATOM.replace(b"</feed>", b"<entry>" + entry + b"</entry></feed>")
    entries = parse_arxiv_atom(duplicated)
    assert len(entries) == 1
    assert entries[0]["paper_id"] == "2401.00001v2"


def test_invalid_atom_timestamps_are_empty_not_current_time():
    invalid = ATOM.replace(b"2024-01-01T01:02:03Z", b"not-a-date").replace(
        b"2024-01-02T03:04:05Z", b"still-not-a-date",
    )
    entry = parse_arxiv_atom(invalid)[0]
    paper = _papers_from_arxiv_atom(invalid)[0]
    assert entry["published"] == entry["updated"] == ""
    assert paper["published_date"] == paper["updated_date"] == ""


def test_far_future_atom_timestamps_are_ignored():
    future = ATOM.replace(b"2024-01-01T01:02:03Z", b"2999-01-01T00:00:00Z").replace(
        b"2024-01-02T03:04:05Z", b"2999-01-02T00:00:00Z",
    )
    entry = parse_arxiv_atom(future)[0]
    assert entry["published"] == entry["updated"] == ""


def test_atom_entry_fields_are_bounded_before_product_use():
    authors = "".join(f"<author><name>{'a' * 300}</name></author>" for _ in range(MAX_AUTHORS + 2))
    categories = "".join(f"<category term=\"{'c' * 100}\"/>" for _ in range(MAX_CATEGORIES + 2))
    payload = f"""<feed xmlns=\"http://www.w3.org/2005/Atom\" xmlns:arxiv=\"http://arxiv.org/schemas/atom\">
      <entry><id>https://arxiv.org/abs/2401.00001</id>
      <title>{'t' * (MAX_TITLE_CHARS + 1)}</title>
      <summary>{'s' * (MAX_SUMMARY_CHARS + 1)}</summary>{authors}{categories}
      <arxiv:doi>{'d' * (MAX_DOI_CHARS + 1)}</arxiv:doi></entry></feed>""".encode("utf-8")
    entry = parse_arxiv_atom(payload)[0]
    assert len(entry["title"]) == MAX_TITLE_CHARS
    assert len(entry["summary"]) == MAX_SUMMARY_CHARS
    assert len(entry["authors"]) == MAX_AUTHORS
    assert all(len(author) == MAX_AUTHOR_NAME_CHARS for author in entry["authors"])
    assert len(entry["categories"]) == MAX_CATEGORIES
    assert all(len(category) == MAX_CATEGORY_CHARS for category in entry["categories"])
    assert len(entry["doi"]) == MAX_DOI_CHARS


@pytest.mark.parametrize("payload,code", [
    (b"", "empty_atom_document"),
    (b"<html/>", "invalid_atom_root"),
    (b"<feed>", "invalid_atom_xml"),
    (b"<!DOCTYPE feed><feed/>", "unsafe_atom_declaration"),
    (b"<!ENTITY x 'x'><feed/>", "unsafe_atom_declaration"),
])
def test_invalid_or_unsafe_xml_fails_with_stable_error(payload, code):
    with pytest.raises(ArxivAtomError, match=f"^{code}$"):
        parse_arxiv_atom(payload)


def test_size_and_entry_count_are_bounded_before_use():
    with pytest.raises(ArxivAtomError, match="^atom_document_too_large$"):
        parse_arxiv_atom(b"<feed/>" + b" " * 20, max_bytes=10)
    with pytest.raises(ArxivAtomError, match="^too_many_atom_entries$"):
        parse_arxiv_atom(
            b'<feed xmlns="http://www.w3.org/2005/Atom"><entry/><entry/></feed>',
            max_entries=1,
        )


class _StreamResponse:
    def __init__(self, chunks, headers=None):
        self.chunks = chunks
        self.headers = headers or {}

    def iter_content(self, chunk_size):
        assert chunk_size > 0
        yield from self.chunks


def test_streamed_response_is_bounded_before_full_buffering():
    response = _StreamResponse([b"<feed/>"])
    assert read_bounded_arxiv_response(response, max_bytes=10) == b"<feed/>"
    with pytest.raises(ArxivAtomError, match="^atom_document_too_large$"):
        read_bounded_arxiv_response(
            _StreamResponse([b"a" * 8, b"b" * 8]), max_bytes=10,
        )
    with pytest.raises(ArxivAtomError, match="^atom_document_too_large$"):
        read_bounded_arxiv_response(
            _StreamResponse([], {"Content-Length": "11"}), max_bytes=10,
        )


def test_production_and_cloud_locks_have_no_feedparser_sdist_chain():
    production = (ROOT / "deepdiver_v2" / "src" / "tools" / "mcp_tools.py").read_text(encoding="utf-8")
    requirements = (ROOT / "deepdiver_v2" / "requirements.txt").read_text(encoding="utf-8").lower()
    constraints = (ROOT / "deepdiver_v2" / "constraints.cloud.txt").read_text(encoding="utf-8").lower()
    hashes = (ROOT / "deepdiver_v2" / "requirements.cloud.hashes.txt").read_text(encoding="utf-8").lower()
    notice = (ROOT / "NOTICE").read_text(encoding="utf-8").lower()
    assert "feedparser" not in production
    for content in (requirements, constraints, hashes, notice):
        assert "feedparser" not in content
        assert "sgmllib3k" not in content
