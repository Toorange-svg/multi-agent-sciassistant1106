"""Real isolated PDF/page coordinates; no network, model or live task storage."""
import copy
import math
import re

import pytest

from multi_agent_report import _source_view, source_preview_geometry


def fixture_pdf(path, *, rotation=0, cropped=False, duplicate=False):
    fitz = pytest.importorskip("pymupdf")
    path.parent.mkdir(parents=True, exist_ok=True)
    with fitz.open() as document:
        page = document.new_page(width=400, height=600)
        page.insert_text((80, 110), "Evidence anchor")
        if duplicate:
            page.insert_text((80, 200), "Evidence anchor")
        if cropped:
            page.set_cropbox(fitz.Rect(40, 60, 360, 540))
        page.set_rotation(rotation)
        document.save(path)
    return path


@pytest.mark.parametrize("rotation", [0, 90, 180, 270])
@pytest.mark.parametrize("cropped", [False, True])
def test_display_box_matches_real_rotated_pixels_without_changing_locator(tmp_path, rotation, cropped):
    fitz = pytest.importorskip("pymupdf")
    pdf = fixture_pdf(tmp_path / "pdf/paper/source.pdf", rotation=rotation, cropped=cropped)
    with fitz.open(pdf) as document:
        page = document[0]
        original_box = list(page.search_for("Evidence anchor")[0])
        locator = {"page": 1, "bbox": original_box, "anchor_text": "Evidence anchor"}
        original_locator = copy.deepcopy(locator)
        display = source_preview_geometry(page, locator)
        assert locator == original_locator
        assert display["coordinate_space"] == "rendered_page_points"
        assert display["page_size"] == [page.rect.width, page.rect.height]
        assert display["bbox"] == pytest.approx(list(fitz.Rect(original_box) * page.rotation_matrix))
        assert display["highlight_method"] == "bbox"
        # Independently check actual dark rendered text pixels inside the box.
        pixels = page.get_pixmap(colorspace=fitz.csGRAY, alpha=False)
        x0, y0, x1, y1 = display["bbox"]
        selected = [pixels.pixel(x, y)[0]
                    for y in range(max(0, math.floor(y0)), min(pixels.height, math.ceil(y1)))
                    for x in range(max(0, math.floor(x0)), min(pixels.width, math.ceil(x1)))]
        assert selected and min(selected) < 50
        link = _source_view(tmp_path, {"document_id": "paper", "citation": 1, "locator": locator})
        assert link == "source-1.html"
        body = (tmp_path / link).read_text(encoding="utf-8")
        assert f'left:{100 * x0 / page.rect.width:.3f}%' in body
        assert f'top:{100 * y0 / page.rect.height:.3f}%' in body
        assert "已按页面旋转转换" in body
        assert (tmp_path / "pages/evidence-1.png").exists()


@pytest.mark.parametrize("rotation", [0, 90, 270])
def test_missing_bbox_uses_only_unique_real_anchor_and_labels_provenance(tmp_path, rotation):
    fitz = pytest.importorskip("pymupdf")
    pdf = fixture_pdf(tmp_path / "pdf/paper/source.pdf", rotation=rotation)
    locator = {"page": 1, "bbox": None, "anchor_text": "Evidence anchor"}
    with fitz.open(pdf) as document:
        result = source_preview_geometry(document[0], locator)
    assert result["highlight_method"] == "anchor_text" and result["bbox"]
    assert locator["bbox"] is None
    assert "不是原始解析坐标" in result["notice"]
    _source_view(tmp_path, {"document_id": "paper", "citation": 1, "locator": locator})
    assert "本页唯一原文锚点匹配" in (tmp_path / "source-1.html").read_text(encoding="utf-8")


@pytest.mark.parametrize("anchor,duplicate", [(None, False), ("not in paper", False), ("Evidence anchor", True)])
def test_page_only_fallback_does_not_claim_or_draw_highlight(tmp_path, anchor, duplicate):
    fitz = pytest.importorskip("pymupdf")
    pdf = fixture_pdf(tmp_path / "pdf/paper/source.pdf", duplicate=duplicate)
    locator = {"page": 1, "bbox": None, "anchor_text": anchor}
    with fitz.open(pdf) as document:
        result = source_preview_geometry(document[0], locator)
    assert result["bbox"] is None and result["highlight_method"] == "none"
    _source_view(tmp_path, {"document_id": "paper", "citation": 1, "locator": locator})
    body = (tmp_path / "source-1.html").read_text(encoding="utf-8")
    assert "border:3px" not in body
    assert "黄色框" not in body
    assert "人工核对" in body
    if duplicate:
        assert "出现多处或跨行" in body


@pytest.mark.parametrize("box", [
    [True, 1, 30, 40], [0, 0, float("nan"), 40], [0, 0, float("inf"), 40],
    [90, 90, 20, 20], [0, 0, 0, 0], [1000, 1000, 1100, 1100], [1, 2, 3], "invalid",
])
def test_invalid_source_box_cannot_become_fake_highlight(tmp_path, box):
    fitz = pytest.importorskip("pymupdf")
    pdf = fixture_pdf(tmp_path / "pdf/paper/source.pdf")
    with fitz.open(pdf) as document:
        result = source_preview_geometry(document[0], {"page": 1, "bbox": box})
    assert result["bbox"] is None and result["highlight_method"] == "none"


def test_clipped_box_stays_inside_rendered_page(tmp_path):
    fitz = pytest.importorskip("pymupdf")
    pdf = fixture_pdf(tmp_path / "pdf/paper/source.pdf", rotation=90)
    with fitz.open(pdf) as document:
        result = source_preview_geometry(document[0], {"bbox": [-10, -10, 100, 100]})
    box, size = result["bbox"], result["page_size"]
    assert 0 <= box[0] < box[2] <= size[0]
    assert 0 <= box[1] < box[3] <= size[1]


def test_anchor_is_escaped_and_boolean_page_is_not_valid(tmp_path):
    fixture_pdf(tmp_path / "pdf/paper/source.pdf")
    _source_view(tmp_path, {"document_id": "paper", "citation": 1,
                           "locator": {"page": 1, "anchor_text": '<script>alert(1)</script>'}})
    body = (tmp_path / "source-1.html").read_text(encoding="utf-8")
    assert '<script>' not in body and '&lt;script&gt;' in body
    assert _source_view(tmp_path, {"document_id": "paper", "citation": 2,
                                 "locator": {"page": True}}) == "pdf/paper/source.pdf"
    assert not (tmp_path / "source-2.html").exists()
