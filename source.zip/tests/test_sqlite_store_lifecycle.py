"""Use real isolated SQLite files, retaining handles so GC cannot fake cleanup."""
from concurrent.futures import ThreadPoolExecutor
import sqlite3

import pytest

from multi_agent_rag import EvidenceStore, RagError, build_chunks
from multi_agent_workflow import (
    WorkflowBudgetExceeded, WorkflowError, WorkflowStore, WorkflowStoreError,
)
from science_pdf_sessions import PdfSessions


@pytest.fixture
def tracked_connections(monkeypatch):
    original = sqlite3.connect
    handles = []

    class TrackedConnection(sqlite3.Connection):
        close_calls = 0

        def close(self):
            self.close_calls += 1
            return super().close()

    def connect(*args, **kwargs):
        kwargs["factory"] = TrackedConnection
        connection = original(*args, **kwargs)
        handles.append(connection)
        return connection

    monkeypatch.setattr(sqlite3, "connect", connect)
    yield handles
    # Clean up even when running these tests against the old leaking code.
    for connection in handles:
        sqlite3.Connection.close(connection)


def assert_closed(handles):
    assert handles
    for connection in handles:
        assert connection.close_calls == 1
        with pytest.raises(sqlite3.ProgrammingError, match="closed database"):
            sqlite3.Connection.execute(connection, "SELECT 1")


def document(version="v1"):
    metadata = {"document_id": "doc-1", "paper_id": "2309.06180", "title": "vLLM",
                "official_url": "https://arxiv.org/abs/2309.06180", "content_hash": version}
    chunks = build_chunks("doc-1", "2309.06180", "vLLM", [
        {"text": "PagedAttention reduces fragmentation.", "page": 2,
         "bbox": [10, 20, 200, 50], "section": "Evaluation"},
    ])
    return metadata, chunks


def test_workflow_all_public_operations_close_without_gc(tmp_path, tracked_connections):
    store = WorkflowStore(tmp_path / "workflow.sqlite3", clock=lambda: 1000.0)
    store.create_run("run-1", "owner-1")
    assert_closed(tracked_connections)
    store.transition("run-1", "planned")
    store.assert_active("run-1")
    store.reserve_model_call("run-1", "planner")
    store.add_artifact("run-1", "research_plan", {
        "schema_version": 1,
        "groups": [{"id": "g1", "question": "Serving", "queries": ["PagedAttention"], "priority": 1}],
        "assumptions": [], "out_of_scope": [],
    })
    store.record_event("run-1", "query", "completed", {"candidates": 1})
    for _ in range(50):
        assert store.get_run("run-1")["model_calls_used"] == 1
        assert len(store.list_artifacts("run-1")) == 1
        assert store.list_stages("run-1")
        assert store.remaining_seconds("run-1") == 360
    assert store.force_terminal("run-1", "cancelled")["status"] == "cancelled"
    assert_closed(tracked_connections)
    # Reopening persisted state does not reschedule a model call.
    assert WorkflowStore(store.path).get_run("run-1")["status"] == "cancelled"
    assert_closed(tracked_connections)


def test_evidence_cache_search_update_delete_close_handles(tmp_path, tracked_connections):
    store = EvidenceStore(tmp_path / "evidence.sqlite3")
    assert_closed(tracked_connections)
    metadata, chunks = document()
    assert store.index_document(metadata, chunks)
    assert not store.index_document(metadata, chunks)
    for _ in range(50):
        assert store.document_hash("doc-1") == "v1"
        hits = store.lexical_search("PagedAttention")
        found = store.get_chunks([hits[0][0]])[0]
        assert found["page"] == 2
        assert found["bbox"] == [10, 20, 200, 50]
    metadata["content_hash"] = "v2"
    assert store.index_document(metadata, chunks)
    assert store.delete_document("doc-1") == [chunks[0]["chunk_id"]]
    assert store.document_hash("doc-1") is None
    assert store.lexical_search("PagedAttention") == []
    assert_closed(tracked_connections)


def test_pdf_bindings_close_and_keep_generation_and_account_boundaries(tmp_path, tracked_connections):
    store = PdfSessions(tmp_path / "pdf.sqlite3")
    first = store.reserve("owner-1", "session-1")
    assert store.bind("owner-1", "session-1", first, "pdf-1")
    for _ in range(50):
        assert store.get("owner-1", "session-1") == "pdf-1"
        assert store.get("owner-2", "session-1") is None
    second = store.reserve("owner-1", "session-1", detach=True)
    assert second > first
    assert not store.bind("owner-1", "session-1", first, "stale-pdf")
    assert store.get("owner-1", "session-1") is None
    assert_closed(tracked_connections)


@pytest.mark.parametrize("operation", ["create", "transition", "reserve", "event", "terminal"])
def test_workflow_write_failure_rolls_back_and_releases_connection(tmp_path, tracked_connections, monkeypatch, operation):
    store = WorkflowStore(tmp_path / "workflow.sqlite3", clock=lambda: 1000.0)
    if operation != "create":
        store.create_run("run-1", "owner-1")
    before = store.list_stages("run-1") if operation != "create" else []

    def fail_event(*args, **kwargs):
        raise WorkflowError("injected event failure")

    monkeypatch.setattr(store, "_append_stage", fail_event)
    actions = {
        "create": lambda: store.create_run("run-1", "owner-1"),
        "transition": lambda: store.transition("run-1", "planned"),
        "reserve": lambda: store.reserve_model_call("run-1", "planner"),
        "event": lambda: store.record_event("run-1", "query", "completed"),
        "terminal": lambda: store.force_terminal("run-1", "cancelled"),
    }
    with pytest.raises(WorkflowError, match="injected event failure"):
        actions[operation]()
    if operation == "create":
        with pytest.raises(WorkflowError, match="not found"):
            store.get_run("run-1")
    else:
        row = store.get_run("run-1")
        assert row["status"] == "created"
        assert row["model_calls_used"] == 0
        assert store.list_stages("run-1") == before
    assert_closed(tracked_connections)


def test_failed_evidence_replacement_preserves_original_chunks_and_fts(tmp_path, tracked_connections):
    store = EvidenceStore(tmp_path / "evidence.sqlite3")
    metadata, chunks = document()
    store.index_document(metadata, chunks)
    metadata["content_hash"] = "v2"
    invalid = dict(chunks[0], schema_version="unknown")
    with pytest.raises(RagError, match="invalid evidence chunk"):
        store.index_document(metadata, [invalid])
    assert store.document_hash("doc-1") == "v1"
    assert store.get_chunks([chunks[0]["chunk_id"]]) == chunks
    assert store.lexical_search("PagedAttention")
    assert_closed(tracked_connections)


@pytest.mark.parametrize("kind", ["workflow", "evidence", "pdf"])
def test_setup_failure_closes_before_returning_safe_error(tmp_path, tracked_connections, monkeypatch, kind):
    original = sqlite3.connect

    def broken_connect(*args, **kwargs):
        connection = original(*args, **kwargs)
        def fail_setup(*args, **kwargs):
            raise sqlite3.OperationalError("injected setup failure")
        connection.execute = fail_setup
        return connection

    monkeypatch.setattr(sqlite3, "connect", broken_connect)
    if kind == "workflow":
        with pytest.raises(WorkflowStoreError, match="^workflow storage unavailable$"):
            WorkflowStore(tmp_path / "workflow.sqlite3").create_run("run-1", "owner-1")
    elif kind == "evidence":
        with pytest.raises(sqlite3.OperationalError):
            EvidenceStore(tmp_path / "evidence.sqlite3")
    else:
        with pytest.raises(sqlite3.OperationalError):
            PdfSessions(tmp_path / "pdf.sqlite3").get("owner-1", "session-1")
    assert_closed(tracked_connections)


@pytest.mark.parametrize("kind", ["workflow", "evidence"])
@pytest.mark.parametrize("exception", [KeyboardInterrupt, SystemExit])
def test_interrupted_transaction_rolls_back_and_closes(tmp_path, tracked_connections, kind, exception):
    store = (WorkflowStore(tmp_path / "workflow.sqlite3") if kind == "workflow"
             else EvidenceStore(tmp_path / "evidence.sqlite3"))
    with pytest.raises(exception):
        with store._connection() as connection:
            connection.execute("CREATE TABLE interrupt_probe (id INTEGER)")
            connection.execute("BEGIN IMMEDIATE")
            connection.execute("INSERT INTO interrupt_probe VALUES (1)")
            raise exception()
    with store._connection() as connection:
        assert connection.execute("SELECT COUNT(*) FROM interrupt_probe").fetchone()[0] == 0
    assert_closed(tracked_connections)


def test_real_concurrent_budget_and_polling_stay_atomic(tmp_path):
    path = tmp_path / "workflow.sqlite3"
    store = WorkflowStore(path, clock=lambda: 1000.0)
    store.create_run("run-1", "owner-1")

    def reserve(index):
        worker = WorkflowStore(path, clock=lambda: 1000.0)
        worker.get_run("run-1")
        worker.list_stages("run-1")
        try:
            return worker.reserve_model_call("run-1", f"role-{index}").call_number
        except WorkflowBudgetExceeded:
            return None

    with ThreadPoolExecutor(max_workers=4) as executor:
        issued = list(executor.map(reserve, range(20)))
    assert sorted(number for number in issued if number is not None) == list(range(1, 11))
    run = store.get_run("run-1")
    assert run["model_calls_used"] == 10
    assert run["failure_code"] == "MODEL_CALL_BUDGET_EXCEEDED"
    # A fresh writer can take the file lock without waiting for garbage collection.
    connection = sqlite3.connect(path, timeout=0.1)
    try:
        connection.execute("BEGIN IMMEDIATE")
        connection.rollback()
        assert connection.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()[0] == 0
    finally:
        connection.close()
