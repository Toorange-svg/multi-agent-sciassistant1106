"""Smaller wire contracts improve delivery, never scientific approval."""
from copy import deepcopy
import json
import time

import pytest

from multi_agent_agents import AgentContractError
from multi_agent_live import (LiveModelClient, planner_handoff_diagnostics,
    normalize_global_review, whole_report_review_prompt, ROLE_PROMPTS)
from multi_agent_audit_batches import GLOBAL_REVIEW_SCHEMA
from multi_agent_quality import publication_rejections
from test_multi_agent_live import config, typed_plan_fixture, Response
from test_multi_agent_audit_batches import seed_flow, report_for, good_audit


class FinishedResponse(Response):
    def __init__(self, text, finish='stop'):
        super().__init__(None)
        self.text, self.finish = text, finish

    def iter_content(self, **kwargs):
        yield json.dumps({'choices':[{'finish_reason':self.finish,
            'message':{'content':self.text}}]}).encode()


def test_planner_diagnostic_does_not_repeat_links_already_aligned_by_code():
    plan = typed_plan_fixture()
    plan['premise_checks'] = [{'check_id':'p1','group_id':'g1','kind':'factual_assumption',
        'origin':'user_statement','question_quote':'A','assumption':'expanded A'}]
    plan['segment_dispositions'] = {'s1':['foreign'], 'credential-canary':['u1']}
    before = deepcopy(plan)
    diagnostic = planner_handoff_diagnostics({'output':plan}, 'A')
    assert diagnostic['handoff_issues'] == [{'path':'premise_checks[0]',
        'reason':'USER_STATEMENT_MUST_BE_LITERAL_NOT_EXPANDED'}]
    assert diagnostic['handoff_shape']['groups'] == 1
    assert diagnostic['diagnosed_after_literal_segment_alignment']
    assert 'credential-canary' not in json.dumps(diagnostic) and plan == before


def test_group_limit_diagnostic_keeps_shape_counts_without_dropping_user_requests():
    plan = typed_plan_fixture()
    plan['groups'] *= 4
    diagnostic = planner_handoff_diagnostics(plan, 'A')
    assert diagnostic['handoff_shape']['groups'] == 4 and diagnostic['handoff_group_limit'] == 3
    assert diagnostic['handoff_shape']['user_requirements'] == 1
    assert diagnostic['handoff_issues'][0]['reason'] == 'ONE_TO_THREE_TYPED_GROUPS_REQUIRED'
    assert 'Require 1-3 RESEARCH groups' in ROLE_PROMPTS['planner']


@pytest.mark.parametrize('with_question', [True,False])
def test_unknown_model_key_cannot_be_saved_as_a_diagnostic_field_path(with_question):
    plan=typed_plan_fixture()
    plan['segment_dispositions']={'credential-canary':['u1']}
    diagnostic=planner_handoff_diagnostics(plan, 'A' if with_question else None)
    assert 'credential-canary' not in json.dumps(diagnostic)


@pytest.mark.parametrize('url,model,setting,enabled', [
    ('https://api.deepseek.com/chat/completions','deepseek-chat',None,True),
    ('https://api.deepseek.com/v1/chat/completions','deepseek-flash',None,True),
    ('https://api.deepseek.com/chat/completions','deepseek-chat','0',False),
    ('https://proxy.example.test/v1/chat/completions','deepseek-chat',None,False),
    ('https://api.deepseek.com.example.test/chat/completions','deepseek-chat',None,False),
    ('https://example.test/v1/chat/completions','test-model','1',True),
    ('https://api.deepseek.com:8443/chat/completions','deepseek-chat',None,False),
    ('https://api.deepseek.com/chat/completions','unknown-model',None,False),
])
def test_json_mode_uses_documented_endpoint_or_explicit_option_only(monkeypatch,url,model,setting,enabled):
    monkeypatch.delenv('MODEL_REQUEST_URL',raising=False)
    monkeypatch.delenv('SCIASSISTANT_MODEL_JSON_MODE',raising=False)
    if setting is not None:monkeypatch.setenv('SCIASSISTANT_MODEL_JSON_MODE',setting)
    cfg=config(url);cfg.model_name=model
    seen=[]
    def post(_url,**kwargs):
        seen.append(kwargs['json'])
        return FinishedResponse(json.dumps({'status':'completed','output':typed_plan_fixture()}))
    client=LiveModelClient(cfg,post=post)
    packet={'deadline_at':time.time()+60,'inputs':[]}
    result=client.call('planner',packet)
    assert result['status'] == 'completed'
    assert ('response_format' in seen[0]) == enabled
    assert (client.prompt_metadata()['planner']['json_output_mode']!='disabled') == enabled
    assert len(seen)==1


def test_json_mode_configuration_changes_fingerprint_without_probing(monkeypatch):
    monkeypatch.setenv('MODEL_REQUEST_URL','https://example.test/v1/chat/completions')
    monkeypatch.delenv('SCIASSISTANT_MODEL_JSON_MODE',raising=False)
    first=LiveModelClient(config(),post=lambda *a,**k:pytest.fail('No capability probe'))
    monkeypatch.setenv('SCIASSISTANT_MODEL_JSON_MODE','1')
    second=LiveModelClient(config(),post=lambda *a,**k:pytest.fail('No capability probe'))
    assert first.fingerprint!=second.fingerprint


def review_wire():
    return {'status':'completed','output':{'schema_version':'sciassistant.report-review/v1',
        'requirements':[], 'consistency':{'reviewed_claim_ids':[], 'conflicts':[]}},'tool_requests':[]}


def test_global_shape_example_is_serialized_valid_json_not_a_scientific_default():
    prompt=whole_report_review_prompt()
    example=prompt.split('SHAPE EXAMPLE, not a decision or a list to copy: ',1)[1].split('. Output ONLY',1)[0]
    decoded=json.loads(example)
    assert decoded==review_wire() | {'output':{**review_wire()['output'], 'requirements':[
        {'requirement_id':'copy_actual_requirement_id','status':'unanswered','claim_ids':[],
         'reason':'Replace with an independently assessed specific reason.'}]}}
    out=normalize_global_review(review_wire())
    assert out['output']['claim_results']==[] and out['output']['issues']==[]
    assert out['output']['report_review']==review_wire()['output']


@pytest.mark.parametrize('fault',['source_verdicts','tool','status','extra_envelope'])
def test_global_projection_refuses_new_source_verdicts_or_actions(fault):
    wire=review_wire()
    if fault=='source_verdicts':wire['output']['claim_results']=[{'claim_id':'c1','decision':'approved'}]
    elif fault=='tool':wire['tool_requests']=[{'action':'request_arxiv_search'}]
    elif fault=='status':wire['status']='failed'
    else:wire['reasoning_content']='credential-canary'
    with pytest.raises(AgentContractError):normalize_global_review(wire)


def test_global_wire_schema_not_accepted_during_a_source_audit(monkeypatch):
    monkeypatch.setenv('MODEL_REQUEST_URL','https://example.test/v1/chat/completions')
    client=LiveModelClient(config(),post=lambda *a,**k:FinishedResponse(json.dumps(review_wire())))
    result=client.call('citation_auditor',{'deadline_at':time.time()+60,'inputs':[]})
    assert result['error_code']=='MODEL_SCHEMA_REJECTED'


@pytest.mark.parametrize('failure',['bad_json','length'])
def test_whole_report_correction_receives_safe_actual_format_diagnostic(tmp_path,monkeypatch,failure):
    monkeypatch.setenv('MODEL_REQUEST_URL','https://example.test/v1/chat/completions')
    flow,refs,draft,*_=seed_flow(tmp_path)
    calls=[]
    def post(_url,**kwargs):
        packet=json.loads(kwargs['json']['messages'][1]['content'])
        global_input=next((i['payload'] for i in packet['inputs'] if i['payload'].get('schema_version')==GLOBAL_REVIEW_SCHEMA),None)
        if not global_input:
            material=next(i['payload'] for i in packet['inputs'] if i['payload'].get('schema_version')=='sciassistant.citation-audit-input/v1')
            claims=[{**j['claim'],**j['claim']['report_fields']} for j in material['audit_jobs']]
            return FinishedResponse(json.dumps({'output':good_audit({'claims':claims})}))
        calls.append(packet)
        if len(calls)==1:
            return FinishedResponse('{"status":"completed","output":', 'length' if failure=='length' else 'stop')
        diagnostics=[i['payload'] for i in packet['inputs'] if i['payload'].get('schema_version')=='sciassistant.model-format-diagnostic/v1']
        assert len(diagnostics)==1 and diagnostics[0]['json_syntax_issue']=='EXPECTED_VALUE'
        assert diagnostics[0]['parse_at_end'] and diagnostics[0]['finish_reason']==('length' if failure=='length' else 'stop')
        wire=review_wire();wire['output']=report_for(global_input)
        return FinishedResponse(json.dumps(wire))
    client=LiveModelClient(config(),post=post)
    flow.agents.citation_auditor.handler=lambda p:client.call('citation_auditor',p)
    _,audit=flow._audit('audit-batches','test',[refs['draft'],refs['approved']],draft,refs)
    assert flow.store.get_run('audit-batches')['model_calls_used']==5
    assert len(calls)==2 and not audit['report_review_validation']['errors']
    assert not publication_rejections(audit,draft)


def test_global_wire_does_not_rebind_wrong_requirement_or_approve_on_valid_json(tmp_path,monkeypatch):
    monkeypatch.setenv('MODEL_REQUEST_URL','https://example.test/v1/chat/completions')
    flow,refs,draft,*_=seed_flow(tmp_path)
    def post(_url,**kwargs):
        packet=json.loads(kwargs['json']['messages'][1]['content'])
        global_input=next((i['payload'] for i in packet['inputs'] if i['payload'].get('schema_version')==GLOBAL_REVIEW_SCHEMA),None)
        if global_input:
            wire=review_wire();wire['output']=report_for(global_input)
            wire['output']['requirements'][0]['claim_ids']=['nonexistent']
            return FinishedResponse(json.dumps(wire))
        material=next(i['payload'] for i in packet['inputs'] if i['payload'].get('schema_version')=='sciassistant.citation-audit-input/v1')
        claims=[{**j['claim'],**j['claim']['report_fields']} for j in material['audit_jobs']]
        return FinishedResponse(json.dumps({'output':good_audit({'claims':claims})}))
    client=LiveModelClient(config(),post=post)
    flow.agents.citation_auditor.handler=lambda p:client.call('citation_auditor',p)
    _,audit=flow._audit('audit-batches','test',[refs['draft'],refs['approved']],draft,refs)
    assert 'REPORT_REVIEW_BINDING_INVALID' in audit['report_review_validation']['errors']
    assert 'r1' not in audit['report_review_validation']['rows']
    assert not publication_rejections(audit,draft)  # No invented source rejection.
