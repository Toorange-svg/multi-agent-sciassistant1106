"""Account schema migration is narrow, idempotent and fail closed."""

import json
from unittest import mock

import pymysql
import pytest

import account_schema as schema

_DEFAULT_AUTH_METADATA = object()


class FakeCursor:
    def __init__(self, connection):
        self.connection = connection
        self.result = None

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def execute(self, sql, params=()):
        normalized = " ".join(sql.split())
        self.connection.statements.append((normalized, params))
        if "GET_LOCK" in normalized:
            self.result = {"acquired": self.connection.lock_result}
        elif "RELEASE_LOCK" in normalized:
            self.result = {"released": 1}
        elif "information_schema.COLUMNS" in normalized and "auth_version" in normalized:
            self.result = self.connection.auth_metadata
        elif "information_schema.COLUMNS" in normalized:
            self.result = self.connection.metadata.pop(0) if self.connection.metadata else None
        elif "information_schema.TABLES" in normalized:
            self.result = {"present": 1} if self.connection.reset_table_exists else None
        elif "information_schema.SCHEMA_PRIVILEGES" in normalized:
            self.results = self.connection.schema_privileges.get(params[1], [])
        elif "information_schema.USER_PRIVILEGES" in normalized:
            self.results = self.connection.global_privileges.get(params[0], [])
        elif normalized.startswith("ALTER TABLE"):
            if self.connection.alter_error:
                raise self.connection.alter_error
            self.connection.alter_count += 1
            if "ADD COLUMN `auth_version`" in normalized:
                self.connection.auth_metadata = auth_column()
            self.result = None
        elif normalized.startswith("CREATE TABLE IF NOT EXISTS `password_reset_tokens`"):
            self.connection.reset_table_exists = True
            self.connection.reset_table_create_count += 1
        elif normalized.startswith(("CREATE USER", "ALTER USER", "REVOKE ", "GRANT ")):
            self.result = None
        else:
            raise AssertionError(f"unexpected SQL: {normalized}")

    def fetchone(self):
        return self.result

    def fetchall(self):
        return getattr(self, "results", [])


class FakeConnection:
    def __init__(self, *metadata, lock_result=1, alter_error=None,
                 schema_privileges=None, global_privileges=None,
                 reset_table_exists=True, auth_metadata=_DEFAULT_AUTH_METADATA):
        self.metadata = list(metadata)
        self.lock_result = lock_result
        self.alter_error = alter_error
        self.statements = []
        self.alter_count = 0
        self.commits = 0
        self.closed = False
        self.schema_privileges = schema_privileges or {}
        self.global_privileges = global_privileges or {}
        self.reset_table_exists = reset_table_exists
        self.reset_table_create_count = 0
        self.auth_metadata = (
            auth_column() if auth_metadata is _DEFAULT_AUTH_METADATA else auth_metadata
        )

    def cursor(self):
        return FakeCursor(self)

    def commit(self):
        self.commits += 1

    def close(self):
        self.closed = True


def column(length=255, data_type="varchar", nullable="NO"):
    return {
        "DATA_TYPE": data_type,
        "CHARACTER_MAXIMUM_LENGTH": length,
        "IS_NULLABLE": nullable,
    }


def auth_column(data_type="int", column_type="int unsigned", nullable="NO", default="0"):
    return {
        "DATA_TYPE": data_type,
        "COLUMN_TYPE": column_type,
        "IS_NULLABLE": nullable,
        "COLUMN_DEFAULT": default,
    }


def test_check_ready_is_read_only():
    connection = FakeConnection(column(255))
    report = schema.check_schema(connection, "chatai")
    assert report["status"] == "ready" and not report["changed"]
    assert all("ALTER TABLE" not in sql for sql, _ in connection.statements)


def test_check_short_column_reports_migration_required_without_alter():
    connection = FakeConnection(column(128))
    report = schema.check_schema(connection, "chatai")
    assert report["status"] == "migration_required"
    assert report["password_column"]["actual_length"] == 128
    assert connection.alter_count == connection.commits == 0


def test_check_requires_password_reset_table():
    connection = FakeConnection(column(255), reset_table_exists=False)
    report = schema.check_schema(connection, "chatai")
    assert report["status"] == "migration_required"
    assert report["password_reset_table_ready"] is False


def test_check_requires_auth_version_column():
    connection = FakeConnection(column(255), auth_metadata=None)
    report = schema.check_schema(connection, "chatai")
    assert report["status"] == "migration_required"
    assert report["auth_version_column_ready"] is False


def test_migrate_adds_auth_version_once_and_verifies():
    connection = FakeConnection(column(255), column(255), auth_metadata=None)
    report = schema.migrate_schema(connection, "chatai")
    assert report["status"] == "migrated" and report["changed"]
    assert report["auth_version_column_ready"] is True
    sql = [statement for statement, _ in connection.statements]
    assert sql.count(schema.AUTH_VERSION_COLUMN_SQL) == 1


@pytest.mark.parametrize("metadata", [
    auth_column(column_type="int"),
    auth_column(nullable="YES"),
    auth_column(default="1"),
    auth_column(data_type="bigint", column_type="bigint unsigned"),
])
def test_unsupported_auth_version_column_fails_closed(metadata):
    connection = FakeConnection(column(255), auth_metadata=metadata)
    with pytest.raises(schema.SchemaFailure, match="AUTH_VERSION_COLUMN_UNSUPPORTED"):
        schema.migrate_schema(connection, "chatai")
    assert connection.alter_count == connection.commits == 0


def test_migrate_widens_once_verifies_and_releases_lock():
    connection = FakeConnection(column(128), column(255))
    report = schema.migrate_schema(connection, "chatai")
    assert report["status"] == "migrated" and report["changed"]
    assert connection.alter_count == connection.commits == 1
    sql = [statement for statement, _ in connection.statements]
    assert sql[0].startswith("SELECT GET_LOCK")
    assert sql[-1].startswith("SELECT RELEASE_LOCK")
    assert sql.count("ALTER TABLE `users` MODIFY COLUMN `password` VARCHAR(255) NOT NULL") == 1


def test_migrate_is_idempotent_when_already_ready():
    connection = FakeConnection(column(255), column(255))
    report = schema.migrate_schema(connection, "chatai")
    assert report["status"] == "ready" and not report["changed"]
    assert connection.alter_count == connection.commits == 0


def test_migrate_creates_missing_password_reset_table_and_verifies():
    connection = FakeConnection(column(255), column(255), reset_table_exists=False)
    report = schema.migrate_schema(connection, "chatai")
    assert report["status"] == "migrated" and report["changed"]
    assert report["password_reset_table_ready"] is True
    assert connection.reset_table_create_count == connection.commits == 1


@pytest.mark.parametrize("metadata,code", [
    (None, "PASSWORD_COLUMN_MISSING"),
    (column(128, "text"), "PASSWORD_COLUMN_UNSUPPORTED"),
    (column(128, nullable="YES"), "PASSWORD_COLUMN_UNSUPPORTED"),
    (column(None), "PASSWORD_COLUMN_UNSUPPORTED"),
])
def test_unexpected_schema_is_rejected_without_ddl(metadata, code):
    connection = FakeConnection(metadata)
    with pytest.raises(schema.SchemaFailure, match=code):
        schema.migrate_schema(connection, "chatai")
    assert connection.alter_count == connection.commits == 0
    assert any("RELEASE_LOCK" in sql for sql, _ in connection.statements)


def test_lock_contention_rejects_without_inspection_or_ddl():
    connection = FakeConnection(column(128), lock_result=0)
    with pytest.raises(schema.SchemaFailure, match="MIGRATION_LOCK_UNAVAILABLE"):
        schema.migrate_schema(connection, "chatai")
    assert len(connection.statements) == 1
    assert connection.alter_count == 0


def test_failed_post_migration_verification_fails_closed():
    connection = FakeConnection(column(128), column(128))
    with pytest.raises(schema.SchemaFailure, match="MIGRATION_VERIFICATION_FAILED"):
        schema.migrate_schema(connection, "chatai")
    assert connection.alter_count == connection.commits == 1
    assert any("RELEASE_LOCK" in sql for sql, _ in connection.statements)


def test_run_check_uses_exit_two_for_required_migration(monkeypatch):
    connection = FakeConnection(column(128))
    monkeypatch.setenv("MYSQL_DATABASE", "private-db-canary")
    report, code = schema.run("check", connector=lambda **_kwargs: connection)
    assert code == 2 and report["status"] == "migration_required"
    assert connection.closed
    assert "private-db-canary" not in json.dumps(report)


def test_database_errors_are_redacted(monkeypatch):
    secret = "private-db-password-canary"
    monkeypatch.setenv("MYSQL_PASSWORD", secret)

    def fail(**_kwargs):
        raise pymysql.MySQLError(f"host and password: {secret}")

    report, code = schema.run("migrate", connector=fail)
    assert code == 1
    assert report["error"] == "DATABASE_OPERATION_FAILED"
    assert secret not in json.dumps(report)


def test_transient_connection_failure_retries_with_bounded_delay(monkeypatch):
    secret = "private-transient-password-canary"
    monkeypatch.setenv("MYSQL_PASSWORD", secret)
    connection = FakeConnection(column(255))
    outcomes = [
        pymysql.OperationalError(2003, f"temporary host failure {secret}"),
        pymysql.OperationalError(2006, f"server restart {secret}"),
        connection,
    ]
    calls = []
    delays = []

    def connect(**_kwargs):
        calls.append(1)
        outcome = outcomes.pop(0)
        if isinstance(outcome, Exception):
            raise outcome
        return outcome

    report, code = schema.run("check", connector=connect, sleeper=delays.append)
    assert code == 0 and report["status"] == "ready"
    assert len(calls) == 3
    assert delays == [schema.DATABASE_OPERATION_RETRY_DELAY_SECONDS] * 2
    assert secret not in json.dumps(report)
    assert connection.closed


def test_transient_mid_operation_disconnect_retries_whole_idempotent_action():
    interrupted = FakeConnection(
        column(128),
        alter_error=pymysql.OperationalError(2013, "lost during restart"),
    )
    recovered = FakeConnection(column(255), column(255))
    outcomes = iter((interrupted, recovered))
    delays = []

    report, code = schema.run(
        "migrate",
        connector=lambda **_kwargs: next(outcomes),
        sleeper=delays.append,
    )
    assert code == 0 and report["status"] == "ready"
    assert delays == [schema.DATABASE_OPERATION_RETRY_DELAY_SECONDS]
    assert interrupted.closed and recovered.closed


def test_transient_connection_retry_exhaustion_is_bounded_and_redacted(monkeypatch):
    secret = "retry-exhaustion-canary"
    calls = []
    delays = []

    def fail(**_kwargs):
        calls.append(1)
        raise pymysql.OperationalError(2003, f"cannot connect {secret}")

    report, code = schema.run("provision", connector=fail, sleeper=delays.append)
    assert code == 1 and report["error"] == "DATABASE_OPERATION_FAILED"
    assert len(calls) == schema.DATABASE_OPERATION_ATTEMPTS
    assert len(delays) == schema.DATABASE_OPERATION_ATTEMPTS - 1
    assert secret not in json.dumps(report)


def test_authentication_failure_is_not_retried(monkeypatch):
    secret = "wrong-root-password-canary"
    calls = []
    delays = []

    def fail(**_kwargs):
        calls.append(1)
        raise pymysql.OperationalError(1045, f"access denied {secret}")

    report, code = schema.run("provision", connector=fail, sleeper=delays.append)
    assert code == 1 and report["error"] == "DATABASE_OPERATION_FAILED"
    assert len(calls) == 1 and delays == []
    assert secret not in json.dumps(report)


def test_alter_permission_error_is_redacted_and_lock_is_released(monkeypatch):
    secret = "private-grant-canary"
    connection = FakeConnection(
        column(128),
        alter_error=pymysql.MySQLError(f"ALTER denied: {secret}"),
    )
    report, code = schema.run("migrate", connector=lambda **_kwargs: connection)
    assert code == 1 and report["error"] == "DATABASE_OPERATION_FAILED"
    assert secret not in json.dumps(report)
    assert any("RELEASE_LOCK" in sql for sql, _ in connection.statements)
    assert connection.closed


def test_fixed_ddl_and_metadata_query_do_not_interpolate_database_name():
    connection = FakeConnection(column(128), column(255))
    schema.migrate_schema(connection, "db_name_canary")
    metadata_calls = [(sql, params) for sql, params in connection.statements
                      if "information_schema.COLUMNS" in sql]
    assert metadata_calls and all(params == ("db_name_canary",) for _, params in metadata_calls)
    assert all("db_name_canary" not in sql for sql, _ in connection.statements)


def provisioned_connection(app="app_user", migration="migration_user"):
    def rows(privileges):
        return [{"PRIVILEGE_TYPE": privilege} for privilege in privileges]
    return FakeConnection(
        schema_privileges={
            schema._grantee(app): rows(schema.APP_PRIVILEGES),
            schema._grantee(migration): rows(schema.MIGRATION_PRIVILEGES),
        },
        global_privileges={
            schema._grantee(app): rows(["USAGE"]),
            schema._grantee(migration): rows(["USAGE"]),
        },
    )


def test_provision_reconciles_exact_users_and_privileges_without_secret_report():
    connection = provisioned_connection()
    report = schema.provision_runtime_identities(
        connection, "chatai", "app_user", "app-password-canary",
        "migration_user", "migration-password-canary",
    )
    assert report == {
        "schema": schema.REPORT_SCHEMA,
        "status": "provisioned",
        "identities_separate": True,
        "application_privileges_exact": True,
        "migration_privileges_exact": True,
        "global_privileges_absent": True,
    }
    serialized = json.dumps(report)
    assert "password-canary" not in serialized and "app_user" not in serialized
    sql = [statement for statement, _ in connection.statements]
    assert sum(statement.startswith("CREATE USER") for statement in sql) == 2
    assert sum(statement.startswith("ALTER USER") for statement in sql) == 2
    assert sum(statement.startswith("REVOKE ALL") for statement in sql) == 2
    assert any("GRANT SELECT, INSERT, UPDATE, DELETE" in statement for statement in sql)
    assert any("GRANT SELECT, ALTER, CREATE" in statement for statement in sql)
    assert sql[-1].startswith("SELECT RELEASE_LOCK")


@pytest.mark.parametrize("database,app,migration,code", [
    ("bad-name", "app_user", "migration_user", "DATABASE_NAME_UNSUPPORTED"),
    ("chatai", "bad-user", "migration_user", "DATABASE_USER_UNSUPPORTED"),
    ("chatai", "root", "migration_user", "DATABASE_IDENTITIES_NOT_SEPARATE"),
    ("chatai", "same_user", "same_user", "DATABASE_IDENTITIES_NOT_SEPARATE"),
])
def test_provision_rejects_unsafe_or_overlapping_identities(database, app, migration, code):
    connection = provisioned_connection(app, migration)
    with pytest.raises(schema.SchemaFailure, match=code):
        schema.provision_runtime_identities(
            connection, database, app, "app-password", migration, "migration-password")
    assert connection.statements == []


def test_provision_rejects_equal_passwords_before_lock():
    connection = provisioned_connection()
    with pytest.raises(schema.SchemaFailure, match="DATABASE_PASSWORDS_NOT_SEPARATE"):
        schema.provision_runtime_identities(
            connection, "chatai", "app_user", "same-password",
            "migration_user", "same-password",
        )
    assert connection.statements == []


def test_provision_fails_when_exact_privileges_cannot_be_verified():
    connection = FakeConnection(
        schema_privileges={
            schema._grantee("app_user"): [{"PRIVILEGE_TYPE": "SELECT"}],
            schema._grantee("migration_user"): [{"PRIVILEGE_TYPE": "ALTER"}],
        },
    )
    with pytest.raises(schema.SchemaFailure, match="PRIVILEGE_VERIFICATION_FAILED"):
        schema.provision_runtime_identities(
            connection, "chatai", "app_user", "app-password",
            "migration_user", "migration-password",
        )
    assert any("RELEASE_LOCK" in sql for sql, _ in connection.statements)


def test_run_provision_reads_env_but_redacts_all_identity_values(monkeypatch):
    connection = provisioned_connection("app_canary", "migration_canary")
    values = {
        "MYSQL_DATABASE": "chatai",
        "MYSQL_APP_USER": "app_canary",
        "MYSQL_APP_PASSWORD": "private-app-password",
        "MYSQL_MIGRATION_USER": "migration_canary",
        "MYSQL_MIGRATION_PASSWORD": "private-migration-password",
    }
    for key, value in values.items():
        monkeypatch.setenv(key, value)
    report, code = schema.run("provision", connector=lambda **_kwargs: connection)
    assert code == 0 and report["status"] == "provisioned"
    serialized = json.dumps(report)
    assert all(value not in serialized for value in values.values())
    assert connection.closed
