"""Bounded Windows directory publication; integrity checks remain unchanged."""
import json
from pathlib import Path

import pytest

from tools import account_backup as backup
from test_account_backup import make_export, build_bundle


def blocked(code=5):
    error = PermissionError('private-path-and-credential-canary')
    error.winerror = code
    return error


@pytest.mark.parametrize('operation', ['create', 'restore'])
@pytest.mark.parametrize('code', [5, 32, 33])
def test_transient_windows_block_retries_publication_and_keeps_verified_bytes(tmp_path, monkeypatch, operation, code):
    source, database, bundle = build_bundle(tmp_path)
    output = tmp_path / ('new-bundle' if operation == 'create' else 'restored')
    original = backup.os.rename
    attempts, delays = [], []
    def rename(staged, target):
        attempts.append((staged, target))
        assert staged.parent == target.parent
        if len(attempts) == 1:
            raise blocked(code)
        return original(staged, target)
    monkeypatch.setattr(backup, '_WINDOWS', True)
    monkeypatch.setattr(backup.os, 'rename', rename)
    monkeypatch.setattr(backup.time, 'sleep', delays.append)
    report = (backup.create_bundle(source, database, output) if operation == 'create'
              else backup.restore_stage(bundle, output))
    assert report['passed'] and backup.verify_bundle(output)['passed']
    assert len(attempts) == 2 and delays == [0.05]
    assert (output / 'payload/database.sql').read_bytes() == database.read_bytes()
    assert not list(tmp_path.glob('.' + output.name + '.partial-*'))


@pytest.mark.parametrize('operation', ['create', 'restore'])
def test_persistent_block_is_bounded_redacted_and_removes_only_own_staging(tmp_path, monkeypatch, operation):
    source, database, bundle = build_bundle(tmp_path)
    output = tmp_path / 'blocked-output'
    sentinel = tmp_path / 'unrelated-keep.txt'
    sentinel.write_text('keep', encoding='utf8')
    calls, delays = [], []
    def rename(*args):
        calls.append(args)
        raise blocked()
    monkeypatch.setattr(backup, '_WINDOWS', True)
    monkeypatch.setattr(backup.os, 'rename', rename)
    monkeypatch.setattr(backup.time, 'sleep', delays.append)
    function, args = ((backup.create_bundle, (source, database, output)) if operation == 'create'
                      else (backup.restore_stage, (bundle, output)))
    report = backup._run_safely(operation, function, *args)
    assert not report['passed'] and report['checks'][0]['check'] == 'directory_publish_busy'
    assert len(calls) == 4 and delays == [0.05, 0.1, 0.2]
    assert 'private-path-and-credential-canary' not in json.dumps(report)
    assert not output.exists() and not list(tmp_path.glob('.blocked-output.partial-*'))
    assert sentinel.read_text(encoding='utf8') == 'keep'
    assert backup.verify_bundle(bundle)['passed']


@pytest.mark.parametrize('windows,code', [(False, 5), (False, 32), (True, 13), (True, None)])
def test_other_platform_or_error_never_gets_blind_permission_retries(tmp_path, monkeypatch, windows, code):
    staged, target = tmp_path / '.stage', tmp_path / 'target'
    staged.mkdir()
    calls, delays = [], []
    def rename(*args):
        calls.append(args)
        raise blocked(code)
    monkeypatch.setattr(backup, '_WINDOWS', windows)
    monkeypatch.setattr(backup.os, 'rename', rename)
    monkeypatch.setattr(backup.time, 'sleep', delays.append)
    with pytest.raises(PermissionError):
        backup._publish_staged_directory(staged, target, 'output_target_invalid')
    assert len(calls) == 1 and not delays and staged.is_dir() and not target.exists()


def test_target_appearing_during_rename_is_not_removed_or_retried(tmp_path, monkeypatch):
    staged, target = tmp_path / '.stage', tmp_path / 'target'
    staged.mkdir()
    calls, delays = [], []
    def rename(*args):
        calls.append(args)
        target.mkdir()
        (target / 'keep.txt').write_text('keep', encoding='utf8')
        raise blocked(32)
    monkeypatch.setattr(backup, '_WINDOWS', True)
    monkeypatch.setattr(backup.os, 'rename', rename)
    monkeypatch.setattr(backup.time, 'sleep', delays.append)
    with pytest.raises(backup.BackupError, match='output_target_invalid'):
        backup._publish_staged_directory(staged, target, 'output_target_invalid')
    assert len(calls) == 1 and not delays
    assert (target / 'keep.txt').read_text(encoding='utf8') == 'keep'


def test_preexisting_empty_target_is_not_replaced(tmp_path):
    staged, target = tmp_path / '.stage', tmp_path / 'target'
    staged.mkdir(); target.mkdir()
    with pytest.raises(backup.BackupError, match='restore_target_invalid'):
        backup._publish_staged_directory(staged, target, 'restore_target_invalid')
    assert staged.is_dir() and target.is_dir()


def test_publish_requires_sibling_staging(tmp_path):
    staged = tmp_path / 'different-parent' / '.stage'
    staged.mkdir(parents=True)
    with pytest.raises(backup.BackupError, match='publish_layout_invalid'):
        backup._publish_staged_directory(staged, tmp_path / 'target', 'output_target_invalid')


def test_retry_does_not_make_later_tampering_acceptable(tmp_path, monkeypatch):
    source, database = make_export(tmp_path)
    output = tmp_path / 'bundle'
    original, calls = backup.os.rename, []
    def rename(*args):
        calls.append(args)
        if len(calls) == 1:
            raise blocked(5)
        return original(*args)
    monkeypatch.setattr(backup, '_WINDOWS', True)
    monkeypatch.setattr(backup.os, 'rename', rename)
    monkeypatch.setattr(backup.time, 'sleep', lambda _: None)
    assert backup.create_bundle(source, database, output)['passed']
    path = output / 'payload/database.sql'
    path.write_bytes(path.read_bytes() + b'tampered')
    report = backup.verify_bundle(output)
    assert not report['passed'] and report['checks'][0]['check'] == 'bundle_integrity_failed'
