"""Failed revisions cannot erase exact previously reviewed independent text."""
from copy import deepcopy
import json

import pytest

from multi_agent_pipeline_v2 import LiteraturePipelineV2, DeterministicLiteratureExecutor, PipelineExecutionError
from multi_agent_agents import ArtifactDirectory, AgentContractError
from multi_agent_workflow import WorkflowStore
from multi_agent_sections import (REVISION_DELIVERY_POLICY, MAX_REVISION_JOBS, revision_jobs,
    merge_revision_jobs, writer_job_issues, merge_writer_batches, writer_jobs)
from multi_agent_quality import check_audit, publication_rejections
from multi_agent_publication import review_request
from test_multi_agent_audit_batches import seed_flow, good_audit, report_for
from test_multi_agent_sections import composition, good_draft
from tools.multi_agent_cli import _mock_agents, _mock_search
from multi_agent_skills import skill_bundle, skill_catalog


def test_revision_skill_no_longer_contradicts_the_scoped_job():
    row=next(s for s in skill_bundle('writer',revision=True)['skills'] if s['skill_id']=='report-revision')
    assert row['version']==3
    assert any('writer-job' in s and 'only the assigned section patch' in s and 'Otherwise' in s for s in row['instructions'])
    assert next(s for s in skill_catalog()['skills'] if s['skill_id']=='report-revision')['sha256']==row['sha256']


def checkpoint_flow(tmp_path, count=3):
    flow, refs, value, sources, ledger, _ = seed_flow(tmp_path, count=count)
    for status in ['planned', 'retrieving', 'reviewing', 'writing', 'auditing']:
        flow.store.transition('audit-batches', status)
    value['revision_delivery_policy'] = REVISION_DELIVERY_POLICY
    if count>1:
        value['claims'][1]['depends_on_claim_ids'] = ['c1']
    refs['draft'] = flow.artifacts.put('draft', value)['artifact_id']
    raw = good_audit(value)
    raw['report_review'] = report_for({'report_review_request':review_request(ledger,value)})
    # A local literal fault must keep c1 and its dependent blocked after restore.
    raw['claim_results'][0]['source_witnesses'][0]['quote'] = 'An invented quotation that is absent from the source.'
    checked = check_audit(raw,value,sources)
    return flow, refs, value, sources, checked


@pytest.mark.parametrize('code', ['MODEL_OUTPUT_TRUNCATED','MODEL_JSON_INVALID','MODEL_SCHEMA_REJECTED',
    'REVISION_REAUDIT_BUDGET_UNAVAILABLE'])
def test_restore_rechecks_original_fields_and_dependencies_not_revision_text(tmp_path, code):
    flow, refs, value, sources, audit = checkpoint_flow(tmp_path)
    flow._reviewed_checkpoint('audit-batches', value, sources, audit, {'status':'completed'}, refs, True)
    assert refs.get('reviewed_checkpoint')
    prior_ref=refs['draft']
    flow.store.transition('audit-batches','writing')
    flow._revision_active=True
    changed=deepcopy(value)
    changed['claims'][2]['text']='Unaudited replacement must NEVER be published.'
    refs['draft']=flow.artifacts.put('new-draft',changed)['artifact_id']
    answer=flow._restore_reviewed_checkpoint('audit-batches',refs,PipelineExecutionError(code))
    assert answer and 'Unaudited replacement' not in answer and refs['draft']==prior_ref
    restored=flow.artifacts.get(refs['audit'])
    assert publication_rejections(restored,value)=={'c1','c2'}
    decision=flow.artifacts.get(refs['publication'])
    assert [r['claim_id'] for r in decision['claims'] if r['published']]==['c3']
    assert flow.store.get_run('audit-batches')['status']=='needs_review'
    assert flow.store.get_run('audit-batches')['failure_code'] is None
    assert flow.artifacts.get(refs['revision_fallback'])['new_revision_claims_published'] is False


@pytest.mark.parametrize('kind', ['no_valid_claim','invalid_contract','missing_global','global_conflict'])
def test_no_checkpoint_without_a_complete_usable_original_audit(tmp_path, kind):
    flow,refs,value,sources,audit=checkpoint_flow(tmp_path)
    if kind=='no_valid_claim':
        for r in audit['claim_results']:r['source_witnesses'][0]['quote']='Invented quotation with no literal support.'
    elif kind=='invalid_contract':audit['rejected_claim_ids']=['foreign']
    elif kind=='missing_global':audit.pop('report_review')
    else:audit['report_review']['consistency']['reviewed_claim_ids'].pop()
    flow._reviewed_checkpoint('audit-batches',value,sources,audit,{'status':'completed'},refs,True)
    assert 'reviewed_checkpoint' not in refs


@pytest.mark.parametrize('kind', ['owner','run','ledger','current_sources','source_bytes','cancelled'])
def test_checkpoint_context_or_cancellation_mismatch_cannot_restore(tmp_path,kind):
    flow,refs,value,sources,audit=checkpoint_flow(tmp_path)
    flow._reviewed_checkpoint('audit-batches',value,sources,audit,{'status':'completed'},refs,True)
    flow.store.transition('audit-batches','writing');flow._revision_active=True
    if kind in {'owner','run'}:
        saved=flow.artifacts.get(refs['reviewed_checkpoint'])
        saved['owner_ref' if kind=='owner' else 'run_id']='another'
        refs['reviewed_checkpoint']=flow.artifacts.put('reviewed-checkpoint',saved)['artifact_id']
    elif kind=='ledger':flow._skill_ledger={**flow._skill_ledger,'changed':True}
    elif kind=='current_sources':
        refs['approved']=flow.artifacts.put('approved',{'evidence':[]})['artifact_id']
    elif kind=='source_bytes':
        saved=flow.artifacts.get(refs['reviewed_checkpoint'])
        (flow.artifacts.root/(saved['artifact_refs']['draft']+'.json')).write_text('{}',encoding='utf-8')
    else:flow.store.force_terminal('audit-batches','cancelled',failure_code='USER_CANCELLED')
    assert flow._restore_reviewed_checkpoint('audit-batches',refs,PipelineExecutionError('MODEL_OUTPUT_TRUNCATED')) is None
    assert 'publication' not in refs


@pytest.mark.parametrize('code',['MODEL_SERVICE_UNAVAILABLE','MODEL_HTTP_ERROR','AGENT_CONTRACT_REJECTED','TIME_BUDGET_EXCEEDED'])
def test_infrastructure_or_authority_failures_do_not_use_format_recovery(tmp_path,code):
    flow,refs,value,sources,audit=checkpoint_flow(tmp_path)
    flow._reviewed_checkpoint('audit-batches',value,sources,audit,{'status':'completed'},refs,True)
    flow._revision_active=True
    assert flow._restore_reviewed_checkpoint('audit-batches',refs,PipelineExecutionError(code)) is None


def revision_data():
    outline,dossiers,sources=composition()
    initial=writer_jobs(outline,dossiers,'enhanced',20)
    value=merge_writer_batches(outline,[(j,good_draft(j),f'draft-{i}') for i,j in enumerate(initial)])
    for c in value['claims']:c['assertion_mode']='reported_fact'
    target=next(c for c in value['claims'] if c['report_section_id']!='summary')
    feedback={'code_issues':[{'claim_id':target['claim_id'],'reason':'READING_SCOPE_OVERSTATED','field':'scope_note'}],
        'model_audit':{'rejected_claim_ids':[]}}
    jobs=revision_jobs(value,sources,feedback,None)
    return value,sources,jobs,target


def test_jobs_are_one_section_patches_not_a_whole_report_rewrite():
    value,sources,jobs,target=revision_data()
    assert len(jobs)==1 and len(jobs[0]['sections'])==1
    assert jobs[0]['target_claim_ids']==[target['claim_id']]
    assert jobs[0]['requirement_ids'] and not jobs[0]['initial_batch']
    before=deepcopy(value)
    patch={**value,'claims':[{**target,'scope_note':'本次所引片段未提供此实验信息。'}]}
    merged=merge_revision_jobs(value,[(jobs[0],patch,'patch-1')])
    assert len(merged['claims'])==len(value['claims'])
    assert all(c==next(r for r in merged['claims'] if r['claim_id']==c['claim_id'])
        for c in value['claims'] if c['claim_id']!=target['claim_id'])
    assert value==before
    assert merge_revision_jobs(value,[(jobs[0],{**patch,'claims':[]},'empty')])['claims']==value['claims']


@pytest.mark.parametrize('kind',['foreign_id','untargeted','binding','group','duplicate'])
def test_patch_cannot_replace_independent_claims_or_rebind_existing_ids(kind):
    value,sources,jobs,target=revision_data();job=jobs[0]
    row=deepcopy(target)
    if kind=='foreign_id':row['claim_id']='not-a-declared-new-prefix'
    elif kind=='untargeted':row['claim_id']=next(k for k in job['external_claim_ids'])
    elif kind=='binding':row['requirement_ids']=[]
    elif kind=='group':row['group_id']='foreign'
    patch={**value,'claims':[row,row] if kind=='duplicate' else [row]}
    with pytest.raises(ValueError):merge_revision_jobs(value,[(job,patch,'bad')])


def test_external_dependency_context_is_not_a_source_or_approval():
    value,sources,jobs,target=revision_data();job=jobs[0]
    row={**target,'claim_id':job['new_claim_prefix']+'1','depends_on_claim_ids':[job['external_claim_ids'][0]]}
    patch={**value,'claims':[row]}
    assert not writer_job_issues(patch,job)
    assert writer_job_issues(patch,{**job,'revision_delivery_policy':'unknown'})
    merged=merge_revision_jobs(value,[(job,patch,'patch')])
    assert merged['claims'][-1]['depends_on_claim_ids']==row['depends_on_claim_ids']
    assert len(merged['claims'])==len(value['claims'])+1


@pytest.mark.parametrize('fault', [None, 'sensitive_input'])
def test_scoped_writer_uses_formal_invoke_and_never_masks_authority_errors(tmp_path, fault):
    flow,refs,_,_,_,_=seed_flow(tmp_path)
    value,sources,jobs,target=revision_data()
    feedback={'code_issues':[{'claim_id':target['claim_id'],'reason':'READING_SCOPE_OVERSTATED','field':'scope_note'}],
        'model_audit':{'rejected_claim_ids':[]}}
    refs.update({k:flow.artifacts.put(k,v)['artifact_id'] for k,v in [
        ('draft',value),('approved',sources),('citation_feedback',feedback),
        ('question',{'text':'原问题。'}),('requirements',{'requirements':[]}),('answer_focus_brief',{'notes':[]})]})
    if fault:
        def forbidden(*args,**kwargs):raise AgentContractError('sensitive input rejected')
        flow._invoke=forbidden
        with pytest.raises(AgentContractError):
            flow._write_revision_sections('audit-batches',value,sources,None,refs)
        return
    def writer(packet):
        selected=next(i['payload'] for i in packet['inputs'] if i['artifact_id'].startswith('revision-draft-slice-'))
        assert [c['claim_id'] for c in selected['claims']]==[target['claim_id']]
        return {'output':{**selected,'claims':[{**target,'scope_note':'仅所选片段未提供该数据。'}]}}
    flow.agents.writer.handler=writer
    result=flow._write_revision_sections('audit-batches',value,sources,None,refs)
    assert result['claims']!=value['claims'] and len(result['claims'])==len(value['claims'])
    assert flow.store.get_run('audit-batches')['model_calls_used']==1
    assert flow.artifacts.get(refs['writer_revision_batches'])['jobs'][0]['status']=='completed'


@pytest.mark.parametrize('limit,accepted', [(5,False),(6,True)])
def test_revision_growth_from_24_to_26_reserves_full_audit_and_correction(tmp_path,limit,accepted):
    from multi_agent_audit_batches import AUDIT_BATCH_POLICY
    flow,refs,_,_,_,_=seed_flow(tmp_path,limit=limit)
    value,sources,_,target=revision_data()
    value['audit_delivery_policy']=AUDIT_BATCH_POLICY
    while len(value['claims'])<24:
        value['claims'].append({**deepcopy(value['claims'][-1]),'claim_id':f'padding-{len(value["claims"])}'})
    before=deepcopy(value)
    feedback={'code_issues':[{'claim_id':target['claim_id'],'reason':'READING_SCOPE_OVERSTATED','field':'scope_note'}],
        'model_audit':{'rejected_claim_ids':[]}}
    refs.update({k:flow.artifacts.put(k,v)['artifact_id'] for k,v in [
        ('draft',value),('approved',sources),('citation_feedback',feedback),
        ('question',{'text':'原问题。'}),('requirements',{'requirements':[]}),('answer_focus_brief',{'notes':[]})]})
    def writer(packet):
        job=next(i['payload'] for i in packet['inputs'] if i['payload'].get('schema_version')=='sciassistant.writer-job/v1')
        selected=next(i['payload'] for i in packet['inputs'] if i['artifact_id'].startswith('revision-draft-slice-'))
        changed={**target,'scope_note':'仅本次所选片段。'}
        additions=[{**changed,'claim_id':job['new_claim_prefix']+str(i)} for i in (1,2)]
        return {'output':{**selected,'claims':[changed,*additions]}}
    flow.agents.writer.handler=writer
    if accepted:
        merged=flow._write_revision_sections('audit-batches',value,sources,None,refs)
        assert len(merged['claims'])==26
        assert flow._revision_audit_reserve(merged)==5
    else:
        with pytest.raises(PipelineExecutionError) as exc:
            flow._write_revision_sections('audit-batches',value,sources,None,refs)
        assert exc.value.code=='REVISION_REAUDIT_BUDGET_UNAVAILABLE'
        row=flow.artifacts.get(refs['writer_revision_batches'])['jobs'][0]
        assert row['status']=='deferred_budget' and row['merged_claim_count']==26
        assert row['required_audit_model_calls']==5 and row['remaining_model_calls']==4
        assert row['patch_applied'] is False
        assert len(flow.artifacts.get(row['patch_artifact_id'])['claims'])==3
    assert value==before and flow.artifacts.get(refs['draft'])==before
    assert flow.store.get_run('audit-batches')['model_calls_used']==1


def test_next_revision_job_uses_already_merged_growth_without_spending_audit_calls(tmp_path):
    from multi_agent_audit_batches import AUDIT_BATCH_POLICY
    flow,refs,_,_,_,_=seed_flow(tmp_path,limit=6)
    value,sources,_,first=revision_data()
    value['audit_delivery_policy']=AUDIT_BATCH_POLICY
    second=next(c for c in value['claims'] if c['report_section_id'] not in ('summary',first['report_section_id']))
    while len(value['claims'])<24:
        value['claims'].append({**deepcopy(value['claims'][-1]),'claim_id':f'padding-{len(value["claims"])}'})
    feedback={'code_issues':[{'claim_id':c['claim_id'],'reason':'READING_SCOPE_OVERSTATED','field':'scope_note'}
        for c in (first,second)],'model_audit':{'rejected_claim_ids':[]}}
    refs.update({k:flow.artifacts.put(k,v)['artifact_id'] for k,v in [
        ('draft',value),('approved',sources),('citation_feedback',feedback),
        ('question',{'text':'原问题。'}),('requirements',{'requirements':[]}),('answer_focus_brief',{'notes':[]})]})
    def writer(packet):
        job=next(i['payload'] for i in packet['inputs'] if i['payload'].get('schema_version')=='sciassistant.writer-job/v1')
        selected=next(i['payload'] for i in packet['inputs'] if i['artifact_id'].startswith('revision-draft-slice-'))
        original=selected['claims'][0]
        return {'output':{**selected,'claims':[original,*[
            {**original,'claim_id':job['new_claim_prefix']+str(i)} for i in (1,2)]]}}
    flow.agents.writer.handler=writer
    merged=flow._write_revision_sections('audit-batches',value,sources,None,refs)
    assert len(merged['claims'])==26
    assert flow.store.get_run('audit-batches')['model_calls_used']==1
    manifest=flow.artifacts.get(refs['writer_revision_batches'])
    assert len(manifest['jobs'])==1 and manifest['unattempted_sections']


@pytest.mark.parametrize('error',['MODEL_OUTPUT_TRUNCATED','MODEL_SERVICE_UNAVAILABLE'])
def test_complete_workflow_failed_revision_preserves_only_audited_body_for_format_errors(tmp_path,error):
    workers=_mock_agents();original_audit=workers.citation_auditor.handler;original_writer=workers.writer.handler
    def reviewer(packet):
        result=original_audit(packet);value=result['output'];row=value['claim_results'][0]
        row.update(decision='rejected',reason_code='UNSUPPORTED_NUMBER')
        value.update(status='needs_revision',rejected_claim_ids=[row['claim_id']],
            issues=[{'claim_id':row['claim_id'],'reason_code':'UNSUPPORTED_NUMBER'}])
        return result
    def writer(packet):
        job=next(i['payload'] for i in packet['inputs'] if i['payload'].get('schema_version')=='sciassistant.writer-job/v1')
        if not job['initial_batch']:return {'status':'failed','error_code':error}
        return original_writer(packet)
    workers.citation_auditor.handler=reviewer;workers.writer.handler=writer
    store=WorkflowStore(tmp_path/'workflow.sqlite3');artifacts=ArtifactDirectory(tmp_path/'artifacts')
    flow=LiteraturePipelineV2(store,artifacts,workers,DeterministicLiteratureExecutor(_mock_search),
        event_path=tmp_path/'events.jsonl',report_profile='enhanced')
    result=flow.run('revision-closure','owner','请解释A。请比较A和B。')
    final=artifacts.get(result['final_artifact_id'])
    if error=='MODEL_OUTPUT_TRUNCATED':
        assert final['status']=='needs_review' and final['failure_code'] is None
        assert final['artifact_refs'].get('revision_fallback')
        decisions=artifacts.get(final['artifact_refs']['publication'])['claims']
        assert sum(r['published'] for r in decisions)==1
        assert result['run']['model_calls_used']==7
    else:
        assert final['status']=='failed' and final['failure_code']==error
        assert 'revision_fallback' not in final['artifact_refs']
