"""Explicit source choices reduce copying faults, never decide support."""
from copy import deepcopy
import json
import time

import pytest

from multi_agent_quality import (AUDIT_QUOTE_MENU_POLICY, WITNESS_CHOICE_POLICY,
    ABSENCE_SCOPE_POLICY, PREVIOUS_ABSENCE_SCOPE_POLICY,
    initial_audit_witness_options, resolve_witness_choices, citation_audit_input,
    check_audit, publication_rejections, answer_requirements, scope_plan_to_question)
from test_multi_agent_report_fields import draft, evidence, QUOTE
from test_multi_agent_absence_basis import audit, absence


def inputs():
    data, sources = draft(), evidence()
    data.update(audit_quote_menu_policy=AUDIT_QUOTE_MENU_POLICY, witness_choice_policy=WITNESS_CHOICE_POLICY)
    return data, sources


def test_initial_menu_is_opt_in_exact_bounded_and_does_not_change_sources():
    data, sources = inputs()
    source = sources['evidence'][0]
    source['excerpt'] = ('A source description. ' + QUOTE + ' ' +
        'The datatype uses asymmetric quantiles and removes a duplicated zero. ' * 20)
    before = deepcopy((data, sources))
    menu = citation_audit_input(data, sources)['source_witness_options']
    assert 1 <= len(menu['options']) <= 24 and not menu['semantic_auto_approval']
    for row in menu['options']:
        assert row['claim_id'] == 'c1' and row['evidence_id'] == 'e1'
        assert 20 <= len(row['quote'].strip()) <= 300
        assert source['excerpt'][row['start_char']:row['end_char']] == row['quote']
    assert menu == initial_audit_witness_options(data, sources)
    assert (data, sources) == before
    data.pop('audit_quote_menu_policy')
    assert 'source_witness_options' not in citation_audit_input(data, sources)


@pytest.mark.parametrize('fault', ['uncited', 'unapproved', 'missing_id', 'bad_text'])
def test_no_initial_choices_from_unknown_or_unapproved_sources(fault):
    data, sources = inputs()
    if fault == 'uncited': data['claims'][0]['evidence_ids'] = ['other']
    if fault == 'unapproved': sources['evidence'][0]['review_status'] = 'pending'
    if fault == 'missing_id': sources['evidence'][0].pop('evidence_id')
    if fault == 'bad_text': sources['evidence'][0].update(excerpt=None, text=None)
    assert not initial_audit_witness_options(data, sources)['options']


def test_menu_limits_are_input_choices_not_a_report_claim_limit():
    data, sources = inputs()
    data['claims'] = [{**deepcopy(data['claims'][0]), 'claim_id': f'c{i}'} for i in range(40)]
    menu = initial_audit_witness_options(data, sources)
    assert len(menu['options']) == 24 and len(data['claims']) == 40
    assert len({row['claim_id'] for row in menu['options']}) == 24


def choose():
    data, sources = inputs()
    menu = initial_audit_witness_options(data, sources)
    value = audit(data)
    option = menu['options'][0]
    value['claim_results'][0]['source_witnesses'] = [
        {'evidence_id': option['evidence_id'], 'quote_id': option['quote_id']}]
    return data, sources, value, menu


def test_first_audit_choice_needs_explicit_selection_and_keeps_model_verdict():
    data, sources, value, menu = choose()
    before = deepcopy((data, sources, value, menu))
    assert publication_rejections(check_audit(value, data, sources), data) == {'c1'}
    normalized, receipt = resolve_witness_choices(value, menu, data, sources)
    assert len(receipt['resolutions']) == 1 and not receipt['semantic_auto_approval']
    assert not publication_rejections(check_audit(normalized, data, sources), data)
    assert normalized['claim_results'][0]['decision'] == value['claim_results'][0]['decision']
    assert (data, sources, value, menu) == before


@pytest.mark.parametrize('fault', ['negative', 'bool', 'float', 'missing', 'quote', 'hash', 'uncited', 'other_claim'])
def test_forged_or_malformed_initial_option_stays_blocked(fault):
    data, sources, value, menu = choose()
    option = menu['options'][0]
    if fault == 'negative': option['start_char'] = -1
    if fault == 'bool': option['start_char'] = False
    if fault == 'float': option['end_char'] = float(option['end_char'])
    if fault == 'missing': option.pop('claim_id')
    if fault == 'quote': option['quote'] = 'A fabricated experimental number is 100 percent.'
    if fault == 'hash':
        option['quote_id'] = 'quote-fabricated'
        value['claim_results'][0]['source_witnesses'][0]['quote_id'] = option['quote_id']
    if fault == 'uncited': data['claims'][0]['evidence_ids'] = ['other']
    if fault == 'other_claim': option['claim_id'] = 'c2'
    normalized, receipt = resolve_witness_choices(value, menu, data, sources)
    assert not receipt['resolutions']
    assert publication_rejections(check_audit(normalized, data, sources), data) == {'c1'}


def test_quote_choice_does_not_override_a_rejection_or_four_quote_limit():
    data, sources, value, menu = choose()
    row = value['claim_results'][0]
    row.update(decision='rejected', reason_code='UNSUPPORTED_CLAIM')
    row['field_results']['text'].update(status='unsupported', detail='结论超出证据。')
    value.update(status='needs_review', rejected_claim_ids=['c1'],
                 issues=[{'claim_id':'c1', 'reason_code':'UNSUPPORTED_CLAIM'}])
    normalized, _ = resolve_witness_choices(value, menu, data, sources)
    assert normalized['claim_results'][0]['decision'] == 'rejected'
    assert publication_rejections(check_audit(normalized, data, sources), data) == {'c1'}
    data, sources, value, menu = choose()
    value['claim_results'][0]['source_witnesses'] *= 5
    normalized, _ = resolve_witness_choices(value, menu, data, sources)
    assert publication_rejections(check_audit(normalized, data, sources), data) == {'c1'}


def test_full_workflow_uses_initial_choices_without_an_extra_call(tmp_path):
    from test_multi_agent_pipeline_v2 import agents, pipeline
    configured, calls = agents()
    data = draft(); data['claims'][0]['evidence_ids'] = ['arxiv-1']
    def writer(_):
        calls.append('writer'); return {'output': data}
    def auditor(packet):
        calls.append('citation_auditor')
        audit_input = next(row['payload'] for row in packet['inputs']
                          if row['payload'].get('schema_version') == 'sciassistant.citation-audit-input/v1')
        option = audit_input['source_witness_options']['options'][0]
        value = audit(data)
        value['claim_results'][0]['source_witnesses'] = [
            {'evidence_id': option['evidence_id'], 'quote_id': option['quote_id']}]
        return {'output': value}
    configured.writer.handler, configured.citation_auditor.handler = writer, auditor
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {'status':'ok', 'papers':[
        {'paper_id':'1','title':'Method','abstract':QUOTE}]})
    result = flow.run('initial-quote', 'owner', 'Explain the method')
    assert result['run']['status'] == 'completed' and result['run']['model_calls_used'] == 5
    assert calls.count('writer') == calls.count('citation_auditor') == 1
    events = [json.loads(line) for line in (tmp_path/'events.jsonl').read_text().splitlines()]
    resolutions = [row for row in events if row.get('event') == 'audit_witness_choices_resolved']
    assert len(resolutions) == 1 and resolutions[0]['phase'] == 'initial'
    assert not any(row.get('event') == 'audit_protocol_retry' for row in events)


@pytest.mark.parametrize('question,derivation,uncertainty,causal', [
    ('解释冻结底座是否参与反向传播。不需要完整公式推导、随机种子或置信区间。', False, False, False),
    ('区分 c1/c2 的符号和层级，不需要完整推导。', False, False, False),
    ('请推导该公式，并给出置信区间与因果归因。', True, True, True),
])
def test_question_focus_separates_symbols_proofs_and_actual_inference(question, derivation, uncertainty, causal):
    focus = answer_requirements(question)['answer_focus']
    assert focus['derivation_requested'] is derivation
    assert focus['uncertainty_estimation_requested'] is uncertainty
    assert focus['causal_inference_requested'] is causal
    if '符号' in question: assert focus['formal_notation_requested']


def test_concept_plan_keeps_mechanism_not_unasked_proof():
    plan = {'groups':[{'id':'g1','metrics':['mechanism','formal_derivation','complete_formula']}]}
    scoped, _ = scope_plan_to_question(plan, answer_requirements('说明机制：哪些参数会更新？不需要公式推导。'))
    assert scoped['groups'][0]['metrics'] == ['mechanism']
    scoped, _ = scope_plan_to_question(plan, answer_requirements('说明机制并推导完整公式。'))
    assert scoped['groups'][0]['metrics'] == plan['groups'][0]['metrics']


@pytest.mark.parametrize('field,assertion', [
    ('附录 E 不在本次已批准片段内。', '附录 E 不在本次已批准片段内。'),
    ('已批准片段中未见该测量。', '已批准片段中未见该测量。'),
    ('表题取自第7页 Table 3 的选中区域；该区域未说明各行配置。', '该区域未说明各行配置。'),
    ('该段为实验设置描述，未给出表3各单元格数值。', '该段为实验设置描述，未给出表3各单元格数值。'),
])
def test_v4_resolves_explicit_text_antecedent_not_magic_phrase(field, assertion):
    data, sources = inputs(); data['absence_scope_policy'] = ABSENCE_SCOPE_POLICY
    data['claims'][0]['qualification'] = field
    value = absence(audit(data), assertion)
    assert not check_audit(value, data, sources)['absence_issues']
    data['absence_scope_policy'] = PREVIOUS_ABSENCE_SCOPE_POLICY
    assert check_audit(value, data, sources)['absence_issues']  # No reinterpretation of v3.


@pytest.mark.parametrize('field,assertion', [
    ('该区域未给出验证。', '该区域未给出验证。'),
    ('我们检查研究选中的区域；该区域未发现样本。', '该区域未发现样本。'),
    ('表题取自第7页 Table 3 的选中区域。该区域未说明配置。', '该区域未说明配置。'),
    ('表题取自第7页 Table 3 的选中区域；该区域说明论文未做过验证。', '该区域说明论文未做过验证。'),
    ('已批准片段说明作者没有做任何实验。', '已批准片段说明作者没有做任何实验。'),
    ('该段时间没有报告样本。', '该段时间没有报告样本。'),
])
def test_v4_does_not_borrow_other_sentence_or_new_paper_subject(field, assertion):
    data, sources = inputs(); data['absence_scope_policy'] = ABSENCE_SCOPE_POLICY
    data['claims'][0]['qualification'] = field
    checked = check_audit(absence(audit(data), assertion), data, sources)
    assert checked['absence_issues'] and publication_rejections(checked, data) == {'c1'}


def test_v3_basic_alias_and_v4_cross_field_boundary_remain():
    data, sources = inputs(); data['absence_scope_policy'] = PREVIOUS_ABSENCE_SCOPE_POLICY
    data['claims'][0]['qualification'] = '该片段未说明配置。'
    assert not check_audit(absence(audit(data), '该片段未说明配置。'), data, sources)['absence_issues']
    data['absence_scope_policy'] = ABSENCE_SCOPE_POLICY
    data['claims'][0].update(text='第7页 Table 3 的选中区域给出配置。', qualification='该区域未说明配置。')
    assert check_audit(absence(audit(data), '该区域未说明配置。'), data, sources)['absence_issues']


@pytest.mark.parametrize('query,expected', [('frozen base backward propagation', True), ('Table 3 GLUE RougeL', False)])
def test_requested_local_role_facet_uses_existing_private_quota(tmp_path, monkeypatch, query, expected):
    import pymupdf
    from multi_agent_local_pdf import LocalPdfRagExecutor
    path = tmp_path / 'input.pdf'
    with pymupdf.open() as doc:
        page = doc.new_page(); page.insert_text((50,70), 'We backpropagate gradients through a frozen model.')
        doc.save(path)
    executor = LocalPdfRagExecutor(tmp_path/'run', path, rag_mode='lexical')
    captured = []
    search = executor.services.search
    def capture(*args, **kwargs):
        captured.append(kwargs); return search(*args, **kwargs)
    monkeypatch.setattr(executor.services, 'search', capture)
    executor.execute([{'request_id':'r1','action':'request_document_search',
                       'arguments':{'query':query, 'group_id':'g1'}}],
                      group_ids={'g1'}, deadline=time.monotonic()+30)
    config = captured[0]
    assert ('frozen backpropagates gradients backward' in config['passage_queries']) is expected
    assert len(config['passage_queries']) <= 3 and config['limit'] == 4 and config['context_budget'] == 4000
    assert config['document_ids'] == {executor.document_id} and not executor.source_context['public_search_allowed']
