"""Reuse verified indexed title across planned topics, not public permissions."""
from copy import deepcopy
import pytest

from multi_agent_live import LiveArxivRagExecutor, INDEXED_SOURCE_REUSE_POLICY, ROLE_PROMPTS, ROLE_PROMPT_SUFFIXES
from multi_agent_rag import EvidenceStore,HybridRetriever,build_chunks


def configured(tmp_path, *, title='Original Method', hint='Original Method', indexed=True):
    store=EvidenceStore(tmp_path/'index.sqlite3')
    chunks=build_chunks('arxiv-1234-56789v1','1234.56789v1',title,[
        {'text':'The original mechanism masks subsequent positions and shifts output embeddings.','page':3,'bbox':[1,2,3,4]}])
    store.index_document({'document_id':'arxiv-1234-56789v1','paper_id':'1234.56789v1','title':title,'content_hash':'x'},chunks)
    flow=LiveArxivRagExecutor(tmp_path/'run',tmp_path/'storage',rag_mode='lexical',services=HybridRetriever(store),evidence_store=store)
    flow.configure_plan({'groups':[{'id':'g1','core':['original']},
        {'id':'g2','core':['mechanism'],'support':['masks subsequent positions'],'source_hints':[hint]}]})
    flow.group_queries={'g1':['architecture'],'g2':['masking']}
    flow.candidates={'1234.56789':{'paper_id':'1234.56789v1','title':title,'group_ids':['g1'],
        'evidence_id':'arxiv-1234.56789v1','abstract':'A public abstract about the mechanism.'}}
    flow.ingested={'arxiv-1234-56789v1'} if indexed else set()
    return flow


def test_indexed_source_requested_by_both_topics_can_supply_different_mechanism_passages(tmp_path):
    flow=configured(tmp_path)
    before=deepcopy((flow.candidates,flow.group_queries,flow.plan_groups))
    rows=flow._select_packets()
    assert len(rows)==1 and rows[0]['group_ids']==['g1','g2']
    assert rows[0]['locator']['page']==3 and 'review_status' not in rows[0]
    reuse=rows[0]['retrieval']['indexed_source_reuses'][0]
    assert reuse['policy']==INDEXED_SOURCE_REUSE_POLICY and reuse['new_public_requests']==0
    assert reuse['original_search_group_ids']==['g1'] and reuse['planned_target_group_id']=='g2'
    assert (flow.candidates,flow.group_queries,flow.plan_groups)==before
    assert flow.pdf_reads==0 and not flow.observations


@pytest.mark.parametrize('title,hint,indexed',[
    ('Follow-up to Original Method','Original Method',True),
    ('Original Methods','Original Method',True),
    ('Original Method','Different Method',True),
    ('Original Method','',True),
    ('Original Method','Original Method',False)])
def test_no_reuse_without_exact_verified_planned_title_and_completed_index(tmp_path,title,hint,indexed):
    flow=configured(tmp_path,title=title,hint=hint,indexed=indexed)
    assert not any('g2' in row['group_ids'] for row in flow._select_packets())


def test_reuse_is_bounded_by_the_existing_packet_and_context_quotas(tmp_path):
    flow=configured(tmp_path)
    observed=[]
    def spy(query,**kwargs):
        observed.append(kwargs);return []
    flow.services.search=spy
    flow._select_packets()
    assert len(observed)==2
    assert all(o['limit']==4 and o['per_document']==2 and o['context_budget']==4000 for o in observed)
    assert all(len(o['passage_queries'])<=3 for o in observed)


def test_normalization_does_not_require_a_literal_case_or_punctuation_spelling(tmp_path):
    flow=configured(tmp_path,title='Original: METHOD!',hint='original method')
    assert any('g2' in row['group_ids'] for row in flow._select_packets())


def test_attribution_contrast_is_not_an_instruction_to_ignore_actual_missing_experiments():
    prompt=ROLE_PROMPTS['citation_auditor']+ROLE_PROMPT_SUFFIXES['citation_auditor']
    assert 'source identity from missing research' in prompt
    assert 'Actual statements of absent experiments/verification still need a valid absence basis' in prompt
