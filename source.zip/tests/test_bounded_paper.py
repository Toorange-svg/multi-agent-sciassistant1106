"""Offline limits plus actual HTTP MCP/model -> CLI -> Web evidence contract."""
import json
import os
import sys
import subprocess
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

import pytest
import requests

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "deepdiver_v2"))

from deepdiver_v2.src import bounded_paper as paper
from deepdiver_v2.src import model_key_pool as pool
from deepdiver_v2.src.tools.mcp_client import MCPClientResult
import web_app


QUERY = "解析 arXiv 2105.05233 的方法和局限"
ANSWER = "## 主要方法\n\n该研究使用视觉注意力分析图像内容 [1]。实验方法来自所提供的论文证据，不额外补充外部资料。\n\n## 局限\n\n所给文本不含可靠图表，图表结论仍需要人工查看原 PDF [1]。"


def envelope(paper_id="2105.05233", text="Method: visual attention. Results need verification.", success=True):
    return {"success": success, "data": {"paper_id": paper_id, "local_paper": text,
        "parse_quality": {"warnings": [], "status": "ok"},
        "parser_status": {"parser": "local", "page_count": 2, "text_page_count": 2,
                          "content_length": len(text), "extraction_status": "success"},
        "parse_metadata": {"page_count": 2, "pages": []}, "source_integrity": {}},
        "metadata": {}}


@pytest.fixture
def isolated(monkeypatch, tmp_path):
    monkeypatch.setenv("MODEL_REQUEST_TOKEN", "offline-placeholder")
    monkeypatch.setenv("MODEL_REQUEST_TOKENS", "")
    monkeypatch.setenv("MODEL_KEY_POOL_STATE_PATH", str(tmp_path / "keys.sqlite3"))
    monkeypatch.setenv("SCIASSISTANT_DIAGNOSTICS_PATH", str(tmp_path / "diag.jsonl"))
    monkeypatch.setenv("ARXIV_PAPER_TASK_TIMEOUT", "240")
    monkeypatch.setenv("ARXIV_PAPER_CONTEXT_CHARS", "48000")
    pool.reset_model_key_pool()
    yield tmp_path
    pool.reset_model_key_pool()


def config(url="http://127.0.0.1/unused"):
    return SimpleNamespace(model_name="offline", pdf_parse_mode="local",
        get_custom_llm_config=lambda: {"url": url, "token": "offline-placeholder"})


def run(payload=None, answer=ANSWER, **kwargs):
    client = Mock()
    # Exercise the real nested transport shape, not a flat convenience dict.
    client.call_tool.return_value = MCPClientResult(success=True, data=payload or envelope())
    model = Mock()
    model.return_value.json.return_value = {"choices": [{"message": {"content": answer}}]}
    result = paper.run_bounded_paper(QUERY, config(), client_factory=lambda _: client, model_post=model, **kwargs)
    return result, client, model


def test_success_reads_once_writes_once_and_closes(isolated):
    result, client, model = run()
    assert result["success"]
    assert result["result"]["paper_read_count"] == result["result"]["model_call_count"] == 1
    client.call_tool.assert_called_once_with("arxiv_read_paper", {"paper_id": "2105.05233", "pdf_parse_mode": "local"})
    client.close.assert_called_once()
    assert model.call_count == 1
    assert model.call_args.kwargs["max_key_attempts"] == 2
    assert "证据使用范围" in result["result"]["final_answer"]
    assert result["result"]["citation_check"]["status"] == "verified"


@pytest.mark.parametrize("payload,stage", [
    (envelope(success=False), "paper_read"),
    (envelope(paper_id="2201.00001"), "paper_read"),
    (envelope(text=""), "paper_parse"),
    ({"success": True, "data": {"paper_id": "2105.05233", "local_paper": "unsafe"}}, "paper_read"),
])
def test_bad_evidence_stops_without_model_or_re_read(isolated, payload, stage):
    result, client, model = run(payload)
    assert not result["success"]
    assert result["result"]["failure_stage"] == stage
    assert client.call_tool.call_count == 1
    model.assert_not_called()


def test_model_exception_is_safe_no_retry(isolated):
    client = Mock()
    client.call_tool.return_value = MCPClientResult(success=True, data=envelope())
    model = Mock(side_effect=RuntimeError("Authorization: Bearer private-credential C:\\private\\file"))
    result = paper.run_bounded_paper(QUERY, config(), client_factory=lambda _: client, model_post=model)
    assert result["result"]["failure_stage"] == "paper_model"
    assert model.call_count == 1
    assert "private-credential" not in json.dumps(result)
    assert "private-credential" not in (isolated / "diag.jsonl").read_text(encoding="utf-8")
    client.close.assert_called_once()


@pytest.mark.parametrize("query", ["arXiv:2105.05233 只基于 PDF 输出解析状态", "arXiv:2105.05233 PDF-only 版式解析边界测试"])
def test_diagnostic_only_queries_do_not_use_answer_model(isolated, query):
    client, model = Mock(), Mock()
    client.call_tool.return_value = MCPClientResult(success=True, data=envelope())
    result = paper.run_bounded_paper(query, config(), client_factory=lambda _: client, model_post=model)
    assert result["success"]
    assert result["result"]["model_call_count"] == 0
    assert "解析" in result["result"]["final_answer"]
    model.assert_not_called()


def test_missing_configuration_fails_before_reading(isolated):
    factory = Mock()
    result = paper.run_bounded_paper(QUERY, config(url=""), client_factory=factory)
    assert result["result"]["failure_stage"] == "paper_configuration"
    factory.assert_not_called()


@pytest.mark.parametrize("answer", ["", "short", None])
def test_empty_or_invalid_model_report_not_success(isolated, answer):
    result, client, model = run(answer=answer)
    assert result["result"]["failure_stage"] == "paper_model"
    assert model.call_count == client.call_tool.call_count == 1


def test_late_model_report_does_not_claim_success(isolated):
    ticks = iter([0, 0, 0, 0, 0, 241, 241, 241])
    result, _, model = run(clock=lambda: next(ticks, 241))
    assert result["result"]["failure_stage"] == "paper_deadline"
    assert model.call_count == 1


def test_context_truncation_is_visible_and_partial(isolated, monkeypatch):
    monkeypatch.setenv("ARXIV_PAPER_CONTEXT_CHARS", "4000")
    result, _, _ = run(envelope(text="method " * 2000))
    assert result["success"] and result["result"]["completion_status"] == "partial"
    assert "不能宣称全文分析完成" in result["result"]["final_answer"]
    assert result["result"]["source_coverage"][0]["selected_chars"] <= 4000


def test_budget_setting_is_clamped_and_invalid_value_safe(monkeypatch):
    for value, expected in [("0", 30), ("9999", 900), ("invalid", 240)]:
        monkeypatch.setenv("ARXIV_PAPER_TASK_TIMEOUT", value)
        assert paper.paper_time_budget() == expected


def test_truncation_samples_head_tail_and_anchor(isolated):
    text = "HEAD " + "x" * 4000 + "important method anchor " + "y" * 4000 + " TAIL"
    excerpt, coverage = paper.select_context(text, "important anchor", 6400)
    assert "HEAD" in excerpt and "TAIL" in excerpt and "important method anchor" in excerpt
    assert coverage["selected_chars"] <= 6400
    assert coverage["source_chars"] == len(text) and coverage["context_truncated"]
    # A non-multiple cap must not sample away text which actually fits.
    short_text = "head " + "x" * 3490 + " tail"
    excerpt, coverage = paper.select_context(short_text, "method", 4000)
    assert coverage["selected_chars"] == len(short_text)
    assert not coverage["context_truncated"]


def test_missing_inline_citations_not_masked_by_generated_references(isolated):
    result, _, _ = run(answer=ANSWER.replace("[1]", ""))
    assert result["result"]["citation_check"]["status"] == "unverified"
    assert result["result"]["completion_status"] == "partial"


def test_numeric_verification_uses_inline_canonical_text(isolated):
    result, _, _ = run(answer=ANSWER + " 实验报告准确率为 97.654%。")
    assert result["result"]["numeric_check"]["status"] == "unverified"
    assert result["result"]["numeric_check"]["unverified_tokens"]


def test_read_finished_after_deadline_does_not_start_writing(isolated):
    ticks = iter([0, 0, 0, 241, 241, 241])
    result, client, model = run(clock=lambda: next(ticks, 241))
    assert result["result"]["failure_stage"] == "paper_deadline"
    model.assert_not_called()


def test_two_papers_once_each_and_more_than_two_rejected(isolated):
    client = Mock()
    client.call_tool.side_effect = lambda _, args: MCPClientResult(success=True, data=envelope(args["paper_id"]))
    model = Mock()
    model.return_value.json.return_value = {"choices": [{"message": {"content": ANSWER}}]}
    result = paper.run_bounded_paper(QUERY + " 对比 2201.00001", config(), client_factory=lambda _: client, model_post=model)
    assert result["success"] and client.call_tool.call_count == 2 and model.call_count == 1
    factory = Mock()
    result = paper.run_bounded_paper(QUERY + " 2201.00001 2201.00002", config(), client_factory=factory)
    assert result["result"]["failure_stage"] == "paper_input"
    factory.assert_not_called()


def test_route_is_scoped_and_deduplicates_ids():
    assert paper.paper_ids(QUERY + " 2105.05233") == ["2105.05233"]
    assert paper.uses_bounded_paper(QUERY, "paper_evidence", "local")
    assert not paper.uses_bounded_paper(QUERY, "paper_evidence", "hybrid")
    assert not paper.uses_bounded_paper(QUERY, "science_literature", "local")
    assert not paper.uses_bounded_paper("检索视觉注意力论文", "paper_evidence", "local")


def test_key_attempt_cap_and_budget(isolated):
    with patch.dict(os.environ, {"MODEL_REQUEST_TOKENS": "offline-a;offline-b;offline-c"}), \
         patch.object(pool.requests, "post") as post:
        response = requests.Response()
        response.status_code = 429
        response.headers["Retry-After"] = "60"
        post.return_value = response
        result = pool.post_model_request("http://127.0.0.1/unused", max_key_attempts=2)
        assert result.status_code == 429 and post.call_count == 2
    with patch.object(pool.requests, "post") as post:
        with pytest.raises(requests.Timeout):
            pool.post_model_request("http://127.0.0.1/unused", deadline=-1)
        post.assert_not_called()


def test_budget_recomputed_between_key_attempts(isolated):
    with patch.dict(os.environ, {"MODEL_REQUEST_TOKENS": "offline-a;offline-b"}), \
         patch.object(pool.time, "monotonic", side_effect=[0, 1, 7]), \
         patch.object(pool.requests, "post", side_effect=[requests.Timeout(), requests.Timeout()]) as post:
        with pytest.raises(requests.Timeout):
            pool.post_model_request("http://127.0.0.1/unused", deadline=10, timeout=(60, 60), max_key_attempts=2)
        assert [call.kwargs["timeout"] for call in post.call_args_list] == [(9, 9), (3, 3)]


@pytest.fixture
def http_services(isolated):
    state = {"tools": [], "models": [], "fail_read": False}

    class Handler(BaseHTTPRequestHandler):
        def reply(self, payload):
            body = json.dumps(payload).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            self.reply({"status": "healthy"})

        def do_POST(self):
            data = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            if self.path == "/model":
                state["models"].append(data)
                self.reply({"choices": [{"message": {"content": ANSWER}}]})
                return
            method = data["method"]
            result = {}
            if method == "tools/list":
                result = {"tools": [{"name": "arxiv_read_paper", "inputSchema": {"type": "object"}}]}
            if method == "tools/call":
                state["tools"].append(data["params"])
                payload = envelope(data["params"]["arguments"]["paper_id"], success=not state["fail_read"])
                result = {"content": [{"type": "text", "text": json.dumps(payload)}]}
            self.reply({"jsonrpc": "2.0", "id": data["id"], "result": result})

        def log_message(self, *_):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    address = f"http://127.0.0.1:{server.server_port}"
    try:
        with patch.dict(os.environ, {"MCP_SERVER_URL": address + "/mcp", "MODEL_REQUEST_URL": address + "/model",
                                  "MODEL_NAME": "offline", "MCP_USE_STDIO": "false", "AGENT_SESSION_ID": ""}):
            yield state, address
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)


def test_actual_http_transport_nested_envelope(http_services):
    state, address = http_services
    result = paper.run_bounded_paper(QUERY, config(address + "/model"))
    assert result["success"], result
    assert len(state["tools"]) == len(state["models"]) == 1


@pytest.mark.parametrize("fail_read", [False, True])
def test_real_cli_through_web_worker_exports_bounded_execution(isolated, http_services, fail_read):
    state, _ = http_services
    state["fail_read"] = fail_read
    task_id = "bounded-offline-canary"
    with patch.object(web_app, "LOG_DIR", isolated), patch.object(web_app, "TASK_STATE_DIR", isolated), \
         patch.dict(web_app.TASKS, {task_id: {"id": task_id, "status": "queued", "created_at": web_app._now()}}), \
         patch.dict(os.environ, {"PYTHONUTF8": "1", "WEB_TASK_TIMEOUT": "900"}):
        web_app._run_query_task(task_id, QUERY, query_mode="paper_evidence")
        task = web_app.TASKS[task_id]
        assert task["status"] == ("failed" if fail_read else "completed"), task.get("output")
        execution = task["execution"]
        assert execution["runtime"]["component"] == "research_web"
        assert execution["runtime"]["source_complete"] is True
        assert execution["runtime"]["instance_id"] == web_app._RESEARCH_RUNTIME.snapshot()["instance_id"]
        assert execution["workflow"] == "bounded_paper_v1"
        assert execution["time_budget_seconds"] == 240
        assert execution["paper_read_count"] == 1
        assert execution["model_call_count"] == (0 if fail_read else 1)
        if fail_read:
            assert execution["failure_stage"] == "paper_read"
        else:
            assert task["answer_quality_summary"]["manual_review_required"]
        evidence = web_app._task_evidence_payload(task)
        assert evidence["lifecycle"]["execution"]["workflow"] == "bounded_paper_v1"
        assert evidence["lifecycle"]["execution"]["runtime"] == execution["runtime"]
        assert evidence["build"]["exporter_runtime"]["instance_id"] == execution["runtime"]["instance_id"]
        assert execution["report_status"] == ("failed" if fail_read else "completed")
        test_client = web_app.app.test_client()
        exported = test_client.get(f"/api/tasks/{task_id}/evidence?format=json")
        assert exported.status_code == 200
        assert exported.get_json()["lifecycle"]["execution"]["model_call_count"] == execution["model_call_count"]
        markdown = test_client.get(f"/api/tasks/{task_id}/evidence?format=md")
        assert markdown.status_code == 200 and "bounded_paper_v1" in markdown.get_data(as_text=True)
        assert json.loads((isolated / (task_id + ".json")).read_text(encoding="utf-8"))["execution"] == execution
    assert len(state["tools"]) == 1
    assert len(state["models"]) == (0 if fail_read else 1)


def test_diagnostics_allowlist_preserves_counts_not_prompt_or_paths(isolated):
    path = isolated / "injected.jsonl"
    path.write_text(json.dumps({"stage": "paper_context", "details": {
        "source_chars": 80000, "selected_chars": 4000, "context_truncated": True,
        "paper_read_count": True, "model_call_count": -1, "prompt": "secret", "path": "private"}}))
    event = web_app._read_diagnostic_events(path)[0]
    assert event["selected_chars"] == 4000 and event["context_truncated"]
    assert not {"prompt", "path", "paper_read_count", "model_call_count"}.intersection(event)


def test_pytest_pool_isolation_ignores_live_state_path(tmp_path):
    sentinel = tmp_path / "live-state-canary"
    sentinel.write_text("unchanged", encoding="utf-8")
    script = """
import os,runpy,sys
from pathlib import Path
live = Path(os.environ['MODEL_KEY_POOL_STATE_PATH'])
live_tasks = os.environ['SCIASSISTANT_TASK_STATE_DIR']
runpy.run_path(sys.argv[1])
assert os.environ['SCIASSISTANT_TASK_STATE_DIR'] != live_tasks
from deepdiver_v2.src import model_key_pool
assert model_key_pool._state_path() != live
model_key_pool.reset_model_key_pool()
assert live.read_text(encoding='utf-8') == 'unchanged'
print('isolated')
"""
    result = subprocess.run([sys.executable, "-c", script, str(ROOT / "tests/conftest.py")],
        cwd=ROOT, env={**os.environ, "MODEL_KEY_POOL_STATE_PATH": str(sentinel), "SCIASSISTANT_TASK_STATE_DIR": str(tmp_path / 'live-tasks')},
        capture_output=True, text=True, timeout=10)
    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == "isolated"
