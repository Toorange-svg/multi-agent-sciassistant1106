from __future__ import annotations

import json

import pytest

from multi_agent_rag import (
    CHUNK_SCHEMA,
    DocumentStore,
    EvidenceStore,
    HybridRetriever,
    RagIndexer,
    RagDependencyError,
    RagError,
    build_chunks,
)


def blocks():
    return [
        {"text": "1 Introduction", "page": 1, "bbox": [10, 10, 100, 25], "block_type": "heading_candidate"},
        {"text": "PagedAttention reduces KV-cache fragmentation in serving systems.", "page": 1,
         "bbox": [10, 30, 300, 55], "section": "1 Introduction", "block_type": "text_block"},
        {"text": "Table 2 Throughput results", "page": 2, "bbox": [10, 10, 250, 30],
         "section": "2 Evaluation", "table_id": "Table-2", "block_type": "table_caption"},
        {"text": "The evaluation reports throughput, not a universal single-request latency percentage.",
         "page": 2, "bbox": [10, 35, 300, 65], "section": "2 Evaluation", "block_type": "text_block"},
    ]


def metadata(content_hash="hash-v1"):
    return {"document_id": "doc-1", "paper_id": "2309.06180", "title": "vLLM",
            "official_url": "https://arxiv.org/abs/2309.06180", "content_hash": content_hash}


def test_structure_aware_chunks_preserve_locators_and_links():
    chunks = build_chunks("doc-1", "2309.06180", "vLLM", blocks(), target_tokens=25, overlap_tokens=5)
    assert len(chunks) >= 2
    assert all(chunk["schema_version"] == CHUNK_SCHEMA for chunk in chunks)
    assert chunks[0]["page"] == 1
    assert any(chunk["table_id"] == "Table-2" for chunk in chunks)
    assert chunks[0]["next_chunk_id"] == chunks[1]["chunk_id"]
    assert chunks[1]["previous_chunk_id"] == chunks[0]["chunk_id"]
    assert chunks[-1]["anchor_text"]


def test_document_store_rejects_path_traversal_and_non_pdf(tmp_path):
    store = DocumentStore(tmp_path / "documents")
    with pytest.raises(RagError):
        store.put("../escape", metadata())
    with pytest.raises(RagError):
        store.put("doc-1", metadata(), pdf_bytes=b"not pdf")
    folder = store.put("doc-1", metadata(), pdf_bytes=b"%PDF-1.7\n%%EOF")
    assert (folder / "source.pdf").is_file()
    saved = json.loads((folder / "metadata.json").read_text(encoding="utf-8"))
    assert saved["paper_id"] == "2309.06180"


def test_evidence_store_is_incremental_and_fts_locatable(tmp_path):
    store = EvidenceStore(tmp_path / "evidence.sqlite3")
    chunks = build_chunks("doc-1", "2309.06180", "vLLM", blocks(), target_tokens=25, overlap_tokens=5)
    assert store.index_document(metadata(), chunks) is True
    assert store.index_document(metadata(), chunks) is False
    results = store.lexical_search("PagedAttention fragmentation", limit=5)
    assert results
    selected = store.get_chunks([results[0][0]])[0]
    assert selected["page"] == 1
    assert selected["bbox"] is not None
    assert store.index_document(metadata("hash-v2"), chunks) is True
    removed = store.delete_document("doc-1")
    assert removed
    assert store.lexical_search("PagedAttention", limit=5) == []


class FakeEmbedding:
    model_name = "fake"
    dimension = 2

    def embed(self, texts):
        return [[1.0, 0.0] for _ in texts]


class FakeVectorStore:
    def __init__(self):
        self.upserts = 0
        self.deleted = []

    def upsert(self, chunks, vectors):
        self.upserts += 1

    def search(self, vector, *, limit):
        return [("doc-1-c00002", 0.9), ("doc-1-c00001", 0.8)]

    def delete_document(self, document_id):
        self.deleted.append(document_id)


def test_hybrid_retrieval_returns_bounded_evidence_packets(tmp_path):
    store = EvidenceStore(tmp_path / "evidence.sqlite3")
    chunks = build_chunks("doc-1", "2309.06180", "vLLM", blocks(), target_tokens=25, overlap_tokens=5)
    store.index_document(metadata(), chunks)
    retriever = HybridRetriever(store, FakeEmbedding(), FakeVectorStore(), vector_required=True)
    packets = retriever.search("single request latency", limit=2, per_document=2)
    assert 1 <= len(packets) <= 2
    assert all(packet["schema_version"] == "sciassistant.evidence-packet/v1" for packet in packets)
    assert packets[0]["locator"]["anchor_text"]
    assert packets[0]["retrieval"]["vector_used"] is True


def test_vector_required_never_silently_falls_back(tmp_path):
    store = EvidenceStore(tmp_path / "evidence.sqlite3")
    with pytest.raises(RagDependencyError):
        HybridRetriever(store, vector_required=True).search("query")


def test_indexer_reuses_content_hash_and_does_not_reembed_unchanged_document(tmp_path):
    store = EvidenceStore(tmp_path / "evidence.sqlite3")
    vector = FakeVectorStore()
    indexer = RagIndexer(store, FakeEmbedding(), vector, vector_required=True)
    first = indexer.index(metadata(), blocks())
    second = indexer.index(metadata(), blocks())
    assert first["changed"] is True and first["vector_indexed"] is True
    assert second["changed"] is False and second["vector_indexed"] is False
    assert vector.upserts == 1
    assert vector.deleted == ["doc-1"]


def test_required_vector_index_rolls_back_lexical_document(tmp_path):
    store = EvidenceStore(tmp_path / "evidence.sqlite3")
    indexer = RagIndexer(store, vector_required=True)
    with pytest.raises(RagDependencyError):
        indexer.index(metadata(), blocks())
    assert store.lexical_search("PagedAttention") == []


def test_long_block_is_split_without_discarding_tail_or_locator():
    from multi_agent_rag import _token_estimate
    text = "PagedAttention memory throughput. " * 800 + " UNIQUE_TAIL_MARKER"
    chunks = build_chunks("doc-1", "2309.06180", "vLLM", [{"text": text, "page": 4,
                           "bbox": [10, 20, 400, 700]}], target_tokens=200, overlap_tokens=30)
    assert len(chunks) > 5
    assert "UNIQUE_TAIL_MARKER" in chunks[-1]["text"]
    assert all(_token_estimate(chunk["text"]) <= 200 for chunk in chunks)
    assert all(chunk["page"] == 4 and chunk["bbox"] for chunk in chunks)


def test_hybrid_scope_prevents_retrieving_other_cached_documents(tmp_path):
    store = EvidenceStore(tmp_path / "evidence.sqlite3")
    for doc_id in ("doc-1", "doc-other"):
        meta = {**metadata(), "document_id": doc_id}
        store.index_document(meta, build_chunks(doc_id, meta["paper_id"], "vLLM", blocks()))
    packets = HybridRetriever(store).search("PagedAttention", document_ids={"doc-1"})
    assert packets and all(packet["document_id"] == "doc-1" for packet in packets)
    assert HybridRetriever(store).search("PagedAttention", document_ids=set()) == []


def test_embedding_change_reindexes_same_pdf(tmp_path):
    store = EvidenceStore(tmp_path / "evidence.sqlite3")
    vector = FakeVectorStore()
    embedding = FakeEmbedding()
    indexer = RagIndexer(store, embedding, vector, vector_required=True)
    assert indexer.index(metadata(), blocks())["changed"]
    embedding.model_name = "fake-new-version"
    assert indexer.index(metadata(), blocks())["changed"]
    assert vector.upserts == 2


def test_failed_embedding_does_not_leave_false_index_success(tmp_path):
    store = EvidenceStore(tmp_path / "evidence.sqlite3")
    vector = FakeVectorStore()
    class BrokenEmbedding(FakeEmbedding):
        def embed(self, texts):
            raise RuntimeError("embedding failed")
    with pytest.raises(RuntimeError):
        RagIndexer(store, BrokenEmbedding(), vector, vector_required=True).index(metadata(), blocks())
    assert store.lexical_search("PagedAttention") == []
    result = RagIndexer(store, FakeEmbedding(), vector, vector_required=True).index(metadata(), blocks())
    assert result["vector_indexed"] is True


def test_coordinated_deletion_removes_document_fts_and_vectors(tmp_path):
    evidence = EvidenceStore(tmp_path / "evidence.sqlite3")
    vector = FakeVectorStore()
    documents = DocumentStore(tmp_path / "documents")
    documents.put("doc-1", metadata(), pdf_bytes=b"%PDF-1.7\n%%EOF")
    indexer = RagIndexer(evidence, FakeEmbedding(), vector, vector_required=True)
    indexer.index(metadata(), blocks())
    assert indexer.delete_document("doc-1", documents=documents)
    assert documents.pdf_path("doc-1") is None
    assert evidence.lexical_search("PagedAttention") == []
    assert vector.deleted[-1] == "doc-1"
