"""Question logic checks are source-bound suggestions, never automatic verdicts."""
from copy import deepcopy
import json

import pytest

from multi_agent_quality import (PREMISE_CHECK_POLICY, PREMISE_KINDS, PREMISE_VERDICTS,
    question_premise_brief, checked_premise_assessments, answer_requirements, answer_focus_brief)
from multi_agent_pipeline_v2 import check_review
from multi_agent_live import ROLE_PROMPTS, normalize_live_result
from test_multi_agent_pipeline_v2 import agents, pipeline


def plan(kind="task_relation", question="Does method A help task B?"):
    return {"groups": [{"id": "g1", "question": question, "queries": ["A original task", "A B relation"]}],
        "premise_checks": [{"check_id": "p1", "group_id": "g1", "kind": kind, "assumption": question}]}


def review(verdict="task_mismatch", ids=None):
    return {"coverage_status": "partial", "allowed_evidence_ids": ["e1"], "coverage": [], "conflicts": [],
        "premise_assessments": [{"check_id": "p1", "verdict": verdict,
            "evidence_ids": ["e1"] if ids is None else ids, "reason": "The cited source establishes the original task, not universal utility."}]}


@pytest.mark.parametrize("kind", sorted(PREMISE_KINDS))
def test_general_logic_categories_do_not_require_a_detr_special_case(kind):
    value = question_premise_brief(plan(kind))
    assert value["checks"][0]["kind"] == kind
    assert value["policy"] == PREMISE_CHECK_POLICY and not value["semantic_auto_approval"]
    assert value["suspicions_are_not_findings"]
    assert "DETR" not in " ".join(value["rules"])


@pytest.mark.parametrize("bad", [None, {}, "p1", [None], [{"check_id": []}],
    [{"check_id": "p1", "group_id": [], "kind": "task_relation", "assumption": "x"}],
    [{"check_id": "p1", "group_id": "g1", "kind": [], "assumption": "x"}],
    [{"check_id": "p1", "group_id": "g1", "kind": "task_relation", "assumption": "x" * 601}]])
def test_invalid_optional_plan_checks_are_isolated_not_repaired(bad):
    value = plan(); value["premise_checks"] = bad
    result = question_premise_brief(value)
    assert result["checks"] == [] and result["validation_issues"]


def test_duplicate_targets_are_all_quarantined():
    value = plan(); value["premise_checks"] *= 2
    result = question_premise_brief(value)
    assert result["checks"] == [] and len(result["validation_issues"]) == 2


@pytest.mark.parametrize("verdict", sorted(PREMISE_VERDICTS))
def test_valid_judgments_remain_advice_and_require_independent_claim_audit(verdict):
    value = review(verdict)
    before = deepcopy(value)
    checked = checked_premise_assessments(value, plan())
    assert checked["assessments"][0]["verdict"] == verdict
    assert not checked["semantic_auto_approval"] and checked["corrections_require_claim_citation_audit"]
    assert value == before


@pytest.mark.parametrize("verdict", ["supported", "contradicted", "task_mismatch"])
def test_definitive_judgment_without_approved_source_is_not_allowed(verdict):
    result = checked_premise_assessments(review(verdict, []), plan())
    assert not result["assessments"]
    assert result["validation_issues"][0]["reason_code"] == "PREMISE_VERDICT_WITHOUT_EVIDENCE"


@pytest.mark.parametrize("ids", [["unknown"], ["e1", "rejected"], ["e1", "e1"], [["e1"]]])
def test_unknown_rejected_duplicate_or_malformed_ids_never_establish_a_premise(ids):
    result = checked_premise_assessments(review(ids=ids), plan())
    assert not result["assessments"] and result["validation_issues"]


def test_other_group_approval_is_not_a_premise_evidence_shortcut():
    value = review()
    value["decisions"] = [{"evidence_id": "e1", "group_ids": ["g2"]}]
    checked = checked_premise_assessments(value, plan())
    assert checked["validation_issues"][0]["reason_code"] == "PREMISE_EVIDENCE_TOPIC_MISMATCH"


def test_duplicate_assessments_cannot_select_the_more_favorable_verdict():
    value = review(); value["premise_assessments"] *= 2
    assert not checked_premise_assessments(value, plan())["assessments"]


def test_unknown_check_cannot_invent_a_topic():
    value = review(); value["premise_assessments"][0]["check_id"] = "new-topic"
    result = checked_premise_assessments(value, plan())
    assert not result["assessments"] and result["unresolved_check_ids"] == ["p1"]


@pytest.mark.parametrize("verdict", ["unverified", "needs_clarification"])
def test_missing_sources_can_record_uncertainty_but_not_a_negative_result(verdict):
    result = checked_premise_assessments(review(verdict, []), plan())
    assert result["assessments"][0]["verdict"] == verdict and result["unresolved_check_ids"] == ["p1"]


def test_a_hypothetical_is_not_a_false_factual_assertion():
    result = checked_premise_assessments(review("contradicted"), plan("hypothetical"))
    assert result["validation_issues"][0]["reason_code"] == "PREMISE_HYPOTHETICAL_IS_NOT_AN_ASSERTION"
    assert not result["assessments"]


@pytest.mark.parametrize("question", ["DETR 对 AI 生成图片的检测有什么帮助？", "ViT 对 AI 生图检测有什么帮助？"])
def test_role_questions_are_not_automatically_quantitative_benchmarks(question):
    requirements = answer_requirements(question)
    assert requirements["question_kind"] == "definition_relation"
    assert requirements["question_premise_policy"] == PREMISE_CHECK_POLICY
    assert requirements["requested_measurement_families"] == []
    assert not question_premise_brief({"groups": []})["checks"]


@pytest.mark.parametrize("question", ["冻结底座为什么仍然需要反向传播？", "假设只在本地训练，有哪些限制？",
    "不要假定准确率提升意味着因果关系。", "没有找到证据，能否断言论文不存在？"])
def test_question_words_do_not_deterministically_label_a_user_wrong(question):
    brief = answer_focus_brief(answer_requirements(question), {"groups": []})
    assert brief["question_premises"]["checks"] == []
    assert not brief["question_premises"]["semantic_auto_approval"]


def test_optional_bad_assessment_does_not_discard_valid_reviewed_definitions():
    value = review(ids=["unapproved"])
    sources = {"evidence": [{"evidence_id": "e1", "group_id": "g1", "excerpt": "Method A detects objects.",
                              "locator": {"page": 1}}]}
    checked = check_review(value, sources, {"g1"}, plan=plan())
    assert checked["allowed_evidence_ids"] == ["e1"] and checked["coverage_status"] == "partial"
    assert checked["premise_assessments"] == []
    assert checked["premise_assessment_validation"]["validation_issues"]


def test_legacy_review_stays_unchanged_when_no_optional_fields_exist():
    value = {k: v for k, v in review().items() if k != "premise_assessments"}
    sources = {"evidence": [{"evidence_id": "e1", "excerpt": "Method A detects objects.", "locator": {"page": 1}}]}
    checked = check_review(value, sources, {"g1"})
    assert "premise_assessments" not in checked and "premise_assessment_validation" not in checked


@pytest.mark.parametrize("question,kind,verdict", [
    ("DETR 对 AI 生图检测有什么帮助？", "task_relation", "task_mismatch"),
    ("ViT 可以帮助 AI 生图检测吗？", "task_relation", "supported"),
    ("冻结参数是否意味着不反传？", "factual_assumption", "contradicted"),
    ("相关性提升是否证明因果改善？", "causal_assumption", "unverified"),
    ("从 85% 到 95% 是否提升 10%？", "numerical_assumption", "needs_clarification"),
    ("完全不联网但要查询最新公开论文", "conflicting_constraints", "needs_clarification"),
    ("文中的 DETR 指什么？", "ambiguous_reference", "needs_clarification"),
    ("假设有完美检测器，如何评估？", "hypothetical", "unverified")])
def test_full_workflow_routes_structured_checks_without_extra_agent_calls(tmp_path, question, kind, verdict):
    configured, calls = agents(partial=True)
    old_planner, old_review, old_writer = configured.planner.handler, configured.reviewer.handler, configured.writer.handler
    def planner(packet):
        value = old_planner(packet)
        value["output"]["premise_checks"] = plan(kind, question)["premise_checks"]
        value["output"]["premise_checks"][0].update(question_quote=question,
            origin="hypothetical" if kind == "hypothetical" else "constraint" if kind == "conflicting_constraints"
            else "user_statement" if verdict == "contradicted" else "open_question")
        return value
    def reviewer(packet):
        brief = next(r["payload"] for r in packet["inputs"] if r["payload"].get("schema_version") == "sciassistant.answer-focus-brief/v1")
        assert brief["question_premises"]["checks"][0]["kind"] == kind
        value = old_review(packet)
        value["output"]["premise_assessments"] = [{"check_id": "p1", "verdict": verdict,
            "evidence_ids": ["arxiv-1"], "reason": "Source-bound fixture; not a real scientific verdict."}]
        return value
    def writer(packet):
        current = next(r["payload"] for r in packet["inputs"] if "allowed_evidence_ids" in r["payload"])
        assert current["premise_assessments"][0]["verdict"] == verdict
        return old_writer(packet)
    configured.planner.handler, configured.reviewer.handler, configured.writer.handler = planner, reviewer, writer
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("premise-run", "owner-1", question)
    assert result["run"]["status"] == "partial" and result["run"]["model_calls_used"] == 5
    assert calls == ["planner", "retriever", "reviewer", "writer", "citation_auditor"]
    events = [json.loads(line) for line in (tmp_path/"events.jsonl").read_text(encoding="utf8").splitlines()]
    event = next(r for r in events if r["event"] == "question_premises_reviewed")
    assert event["assessed_count"] == 1 and not event["semantic_auto_approval"]


def test_prompts_cover_correction_and_overcorrection_without_bypassing_audit():
    assert "counter-evidence" in ROLE_PROMPTS["planner"]
    assert "private-PDF" in ROLE_PROMPTS["retriever"]
    assert "NOT contradicted" in ROLE_PROMPTS["reviewer"]
    assert "precise cited correction" in ROLE_PROMPTS["writer"]
    assert "Reviewer verdict is not a source" in ROLE_PROMPTS["citation_auditor"]


@pytest.mark.parametrize("role", ["planner", "reviewer"])
def test_live_output_whitelist_preserves_only_structured_premise_fields(role):
    if role == "planner":
        from multi_agent_report_contracts import REPORT_PLAN_SCHEMA as PLAN_SCHEMA
        data = {"schema_version": PLAN_SCHEMA, **plan()}
        data['groups'][0].update(kind='research', question_quote='Does method A help task B?',
            evidence_needs=[{'entity':'A','question_quote':'A','aspect':'definition','source_title':''}])
        data.update(user_requirements=[{'id':'u1','question_quote':'Does method A help task B?','answer_kind':'relation',
            'research_group_ids':[data['groups'][0]['id']],'report_obligation_ids':[]}],segment_dispositions={'s1':['u1']})
        key, values = "premise_checks", {"check_id", "group_id", "kind", "assumption"}
    else:
        data = {"schema_version": "sciassistant.evidence-review/v5", **review(), "decisions": []}
        key, values = "premise_assessments", {"check_id", "verdict", "evidence_ids", "reason"}
    data[key][0]["hidden_override"] = "must not become authority"
    normalized = normalize_live_result(role, {"output": data}, require_current=True)["output"]
    assert key in normalized and len(normalized[key]) == 1
    assert set(normalized[key][0]) == values


@pytest.mark.parametrize("field", ["scope_note", "qualification"])
@pytest.mark.parametrize("empty", ["", "  "])
def test_empty_not_applicable_missing_list_is_syntactic_only_and_new_policy_only(field, empty):
    from test_multi_agent_report_fields import draft, evidence
    from test_multi_agent_absence_basis import audit
    from multi_agent_quality import EMPTY_FIELD_ABSENCE_POLICY, check_audit, publication_rejections
    data = draft()
    data["claims"][0][field] = empty
    raw = audit(data)
    raw["claim_results"][0]["field_results"][field]["status"] = "not_applicable"
    del raw["claim_results"][0]["field_results"][field]["absence_checks"]
    before = deepcopy(raw)
    legacy = check_audit(raw, data, evidence())
    assert "AUDIT_FIELD_RESULTS_INVALID" in legacy["contract_errors"]
    data["empty_field_absence_policy"] = EMPTY_FIELD_ABSENCE_POLICY
    checked = check_audit(raw, data, evidence())
    assert checked["contract_errors"] == []
    assert not publication_rejections(checked, data) and raw == before


@pytest.mark.parametrize("status,value", [("supported", ""), ("not_applicable", "A factual negative"),
    ("not_applicable", None)])
def test_empty_field_exception_never_hides_nonempty_text_or_invents_a_verdict(status, value):
    from test_multi_agent_report_fields import draft, evidence
    from test_multi_agent_absence_basis import audit
    from multi_agent_quality import EMPTY_FIELD_ABSENCE_POLICY, check_audit
    data = draft(); data["empty_field_absence_policy"] = EMPTY_FIELD_ABSENCE_POLICY
    raw = audit(data)
    data["claims"][0]["scope_note"] = value
    raw["claim_results"][0]["field_results"]["scope_note"].update(status=status)
    del raw["claim_results"][0]["field_results"]["scope_note"]["absence_checks"]
    assert check_audit(raw, data, evidence())["contract_errors"]


def identity_inputs():
    data = review("contradicted")
    first, second = "Alpha is an object detector.", "Beta is an image classifier."
    data["premise_assessments"][0]["definitions"] = [
        {"entity": "Alpha", "evidence_id": "e1", "quote": first},
        {"entity": "Beta", "evidence_id": "e1", "quote": second}]
    sources = {"evidence": [{"evidence_id": "e1", "excerpt": first + " " + second}]}
    return data, plan("ambiguous_reference", "Are Alpha and Beta the same method?"), sources


def test_two_definition_provenance_does_not_automatically_prove_identity_or_difference():
    data, target, sources = identity_inputs()
    result = checked_premise_assessments(data, target, sources)
    assert len(result["assessments"]) == 1 and len(result["assessments"][0]["definitions"]) == 2
    assert not result["semantic_auto_approval"]


@pytest.mark.parametrize("damage", ["missing", "one_name", "duplicate", "unknown_name", "missing_source", "substring", "noncontiguous", "unknown_id"])
def test_one_sided_or_fabricated_definition_cannot_establish_nonidentity(damage):
    data, target, sources = identity_inputs()
    row = data["premise_assessments"][0]
    if damage == "missing": del row["definitions"]
    elif damage == "one_name": row["definitions"] = row["definitions"][:1]
    elif damage == "duplicate": row["definitions"][1] = dict(row["definitions"][0])
    elif damage == "unknown_name": row["definitions"][1]["entity"] = "Gamma"
    elif damage == "missing_source": sources["evidence"][0]["excerpt"] = "Alpha is an object detector."
    elif damage == "substring":
        row["definitions"][1]["quote"] = "BetterBeta is an image classifier."
        sources["evidence"][0]["excerpt"] += " BetterBeta is an image classifier."
    elif damage == "noncontiguous": row["definitions"][1]["quote"] = "Beta is an image classifier but Alpha is not."
    elif damage == "unknown_id": row["definitions"][1]["evidence_id"] = "e2"
    result = checked_premise_assessments(data, target, sources)
    assert not result["assessments"] and result["unresolved_check_ids"] == ["p1"]
    assert result["validation_issues"]
    assert data["allowed_evidence_ids"] == ["e1"]
