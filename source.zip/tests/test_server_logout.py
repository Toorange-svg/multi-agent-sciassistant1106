"""Server-confirmed logout revokes every JWT for the authenticated account."""

from unittest import mock

import pymysql

import app as gateway


class LogoutCursor:
    def __init__(self, connection):
        self.connection = connection
        self.rowcount = 0

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def execute(self, sql, params=()):
        self.connection.statements.append((" ".join(sql.split()), params))
        if self.connection.error:
            raise self.connection.error
        self.rowcount = self.connection.rowcount


class LogoutConnection:
    def __init__(self, *, rowcount=1, error=None):
        self.rowcount = rowcount
        self.error = error
        self.statements = []
        self.commits = 0
        self.rollbacks = 0
        self.closed = False

    def cursor(self):
        return LogoutCursor(self)

    def commit(self):
        self.commits += 1

    def rollback(self):
        self.rollbacks += 1

    def close(self):
        self.closed = True


def _headers(version=3):
    token = gateway.generate_token(7, "person", version)
    return {"Authorization": f"Bearer {token}"}


def test_logout_requires_authentication_without_database_write():
    with mock.patch.object(gateway, "get_db_connection") as database:
        response = gateway.app.test_client().post("/api/logout")
    assert response.status_code == 401
    database.assert_not_called()


def test_logout_atomically_increments_matching_generation_and_closes_connection():
    connection = LogoutConnection()
    with mock.patch.object(gateway, "_current_auth_version", return_value=3), \
         mock.patch.object(gateway, "get_db_connection", return_value=connection):
        response = gateway.app.test_client().post("/api/logout", headers=_headers())
    assert response.status_code == 200
    assert response.get_json()["success"] is True
    assert connection.commits == 1 and connection.rollbacks == 0 and connection.closed
    assert len(connection.statements) == 1
    sql, params = connection.statements[0]
    assert "auth_version = auth_version + 1" in sql
    assert "WHERE id = %s AND auth_version = %s" in sql
    assert params == ("7", 3)


def test_concurrent_or_replayed_logout_fails_without_commit():
    connection = LogoutConnection(rowcount=0)
    with mock.patch.object(gateway, "_current_auth_version", return_value=3), \
         mock.patch.object(gateway, "get_db_connection", return_value=connection):
        response = gateway.app.test_client().post("/api/logout", headers=_headers())
    assert response.status_code == 401
    assert connection.commits == 0 and connection.rollbacks == 1 and connection.closed


def test_logout_database_failure_is_redacted_and_keeps_token_retryable():
    connection = LogoutConnection(error=pymysql.MySQLError("private-db-host-canary"))
    with mock.patch.object(gateway, "_current_auth_version", return_value=3), \
         mock.patch.object(gateway, "get_db_connection", return_value=connection):
        response = gateway.app.test_client().post("/api/logout", headers=_headers())
    assert response.status_code == 503
    assert response.get_json()["error"] == "认证服务暂时不可用，请稍后重试"
    assert "private-db-host-canary" not in response.get_data(as_text=True)
    assert connection.commits == 0 and connection.rollbacks == 1 and connection.closed


def test_old_token_is_rejected_after_logout_without_entering_business_route():
    with mock.patch.object(gateway, "_current_auth_version", return_value=4), \
         mock.patch.object(gateway, "get_db_connection") as database:
        response = gateway.app.test_client().post("/api/logout", headers=_headers(3))
    assert response.status_code == 401
    database.assert_not_called()


def test_frontend_waits_for_server_logout_before_clearing_credentials():
    html = (gateway.BASE_DIR / "chatAi" / "ai_chat.html").read_text(encoding="utf-8")
    section = html[html.index("function clearStoredLogin()"):
                   html.index("// 获取用户ID的辅助函数")]
    assert "await fetch('/5000/api/logout', { method: 'POST' })" in section
    assert "response.status !== 401" in section
    assert section.index("await fetch(") < section.index("clearStoredLogin();")
    assert "button.disabled = false" in section
    assert "安全退出暂时失败" in section
    assert 'title="安全退出所有设备"' in html
