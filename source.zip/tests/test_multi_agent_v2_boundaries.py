from __future__ import annotations

import json
import threading
import time
from http.server import ThreadingHTTPServer
from urllib.error import HTTPError
from urllib.request import urlopen

import pytest

from multi_agent_agents import AgentContractError, AgentWorker, ArtifactDirectory
from multi_agent_pipeline_v2 import check_draft, check_review, DeterministicLiteratureExecutor
from multi_agent_report import export_run_report
from multi_agent_workflow import WorkflowError
from tools.multi_agent_cli import report_handler
from test_multi_agent_pipeline_v2 import agents, pipeline


def test_writer_and_auditor_cannot_read_rejected_evidence(tmp_path):
    configured, _ = agents()
    def reviewer(packet):
        return {"output": {"coverage_status": "partial", "allowed_evidence_ids": ["arxiv-1"], "coverage": [], "conflicts": []}}
    def writer(packet):
        records = next(x["payload"]["evidence"] for x in packet["inputs"] if "evidence" in x["payload"])
        assert [x["evidence_id"] for x in records] == ["arxiv-1"]
        assert "REJECTED_CANARY" not in json.dumps(packet)
        return {"output": {"direct_answer": "approved", "claims": [{"claim_id": "c1", "text": "Approved evidence", "evidence_ids": ["arxiv-1"]}]}}
    configured.reviewer.handler = reviewer
    configured.writer.handler = writer
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {"status": "ok", "papers": [
        {"paper_id": "1", "title": "approved", "abstract": "evidence"},
        {"paper_id": "2", "title": "rejected", "abstract": "REJECTED_CANARY"},
    ]})
    assert flow.run("run-1", "owner-1", "compare")["run"]["status"] == "partial"
    export_run_report(tmp_path)
    refs = json.loads((tmp_path / "references.json").read_text(encoding="utf-8"))
    assert len(refs) == 1 and refs[0]["evidence_id"] == "arxiv-1"


def test_unknown_claim_and_unsupported_number_cannot_pass_even_if_model_auditor_passes(tmp_path):
    configured, calls = agents()
    configured.writer.handler = lambda _: {"output": {"direct_answer": "Latency falls 98%.", "claims": [
        {"claim_id": "c1", "text": "Latency falls 98%", "claim_type": "quantitative", "evidence_ids": ["arxiv-1"]},
        {"claim_id": "c2", "text": "Forged result", "evidence_ids": ["not-approved"]},
    ]}}
    flow, store = pipeline(tmp_path, configured)
    result = flow.run("run-1", "owner-1", "compare")
    assert result["run"]["status"] == "failed"
    assert result["run"]["failure_code"] == "NO_AUDITED_CLAIMS"
    assert result["run"]["model_calls_used"] == 7
    assert "98%" not in result["direct_answer"] and "Forged" not in result["direct_answer"]
    assert len(list((tmp_path / "rework_tickets").glob("*.json"))) == 1


@pytest.mark.parametrize("status", ["not_reported", "not_comparable", "conflicting"])
def test_research_limitations_are_partial_or_review_not_failure(status):
    review = {"coverage_status": "sufficient", "allowed_evidence_ids": ["e1"], "coverage": [
        {"group_id": "g1", "status": status, "evidence_ids": ["e1"]}], "conflicts": []}
    out = check_review(review, {"evidence": [{"evidence_id": "e1"}]}, {"g1"})
    assert out["coverage_status"] == ("needs_review" if status == "conflicting" else "partial")


def test_tool_permissions_are_checked_before_any_network_request():
    executor = DeterministicLiteratureExecutor(lambda *_: pytest.fail("no network"))
    with pytest.raises(WorkflowError):
        executor.execute([{"request_id": "r1", "action": "request_arxiv_search", "arguments": {
            "query": "q", "group_id": "unknown"}}], group_ids={"g1"})


def test_completed_queries_survive_later_query_failure(tmp_path):
    configured, _ = agents()
    configured.retriever.handler = lambda _: {"output": {}, "tool_requests": [
        {"request_id": f"r{i}", "action": "request_arxiv_search", "arguments": {"query": f"q{i}", "group_id": "g1"}} for i in range(2)]}
    def search(query, limit):
        if query == "q1":
            raise RuntimeError("secret internal failure")
        return {"status": "ok", "papers": [{"paper_id": "1", "title": "Paper", "abstract": "Evidence"}]}
    flow, store = pipeline(tmp_path, configured, search=search)
    assert flow.run("run-1", "owner-1", "compare")["run"]["status"] == "failed"
    assert list((tmp_path / "artifacts").glob("evidence-set-*.json"))
    assert store.get_run("run-1")["status"] != "retrieving"
    export_run_report(tmp_path)
    assert "secret internal failure" not in (tmp_path / "final_answer.md").read_text(encoding="utf-8")


def test_artifact_tampering_is_rejected(tmp_path):
    artifacts = ArtifactDirectory(tmp_path)
    ref = artifacts.put("data", {"value": 1})
    (tmp_path / (ref["artifact_id"] + ".json")).write_text('{"value":2}', encoding="utf-8")
    with pytest.raises(AgentContractError, match="checksum"):
        artifacts.get(ref["artifact_id"])


def test_artifact_text_redacts_credentials_and_absolute_paths(tmp_path):
    artifacts = ArtifactDirectory(tmp_path)
    ref = artifacts.put("data", {"excerpt": "Authorization: Bearer secret-canary C:\\Users\\Example\\private.txt /home/example/private.txt"})
    payload = artifacts.get(ref["artifact_id"])
    assert "secret-canary" not in payload["excerpt"]
    assert "Example" not in payload["excerpt"] and "/home/" not in payload["excerpt"]
    assert "[REDACTED_PATH]" in payload["excerpt"]
    configured, _ = agents()
    flow, _ = pipeline(tmp_path / "run", configured)
    flow._event({"event": "retrieval_query", "query": "Authorization: Bearer secret-canary C:\\Users\\Example\\private.txt"})
    for filename in ("events.jsonl", "console.log"):
        logged = (tmp_path / "run" / filename).read_text(encoding="utf-8")
        assert "secret-canary" not in logged and "Example" not in logged


def test_deadline_after_late_agent_is_terminal(tmp_path):
    configured, _ = agents()
    configured.planner.handler = lambda _: (time.sleep(1.05) or {"output": {"groups": [{"id": "g1"}]}})
    flow, store = pipeline(tmp_path, configured)
    flow.time_budget_seconds = 1
    result = flow.run("run-1", "owner-1", "compare")
    assert result["run"]["status"] == "timed_out"
    assert result["run"]["model_calls_used"] == 1
    assert list((tmp_path / "artifacts").glob("final-result-*.json"))


def test_report_server_blocks_database_artifacts_and_directory_listing(tmp_path):
    (tmp_path / "final_answer.html").write_text("report", encoding="utf-8")
    (tmp_path / "workflow.sqlite3").write_text("private", encoding="utf-8")
    server = ThreadingHTTPServer(("127.0.0.1", 0), report_handler(tmp_path))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f"http://127.0.0.1:{server.server_port}"
    try:
        assert urlopen(base + "/final_answer.html", timeout=5).read() == b"report"
        for path in ("/", "/workflow.sqlite3", "/artifacts/", "/%2e%2e/.env"):
            with pytest.raises(HTTPError) as exc:
                urlopen(base + path, timeout=5)
            assert exc.value.code == 404
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)
