"""Dimensions must not masquerade as speedups; semantic audit remains required."""
from copy import deepcopy
from decimal import Decimal

import pytest

from multi_agent_pipeline_v2 import _reported_quantities, check_draft
from multi_agent_quality import check_audit, publication_rejections


@pytest.mark.parametrize("dimensions", ["256×256", "256 × 256", "256x256", "256 X 256", "32×32×3"])
def test_dimensions_do_not_create_multiplier_claims(dimensions):
    assert _reported_quantities("image size " + dimensions) == set()


@pytest.mark.parametrize("multiplier", ["2.51x", "2.51X", "2.51×", "2.51 × faster"])
def test_standalone_multiplier_remains_checked(multiplier):
    assert _reported_quantities(multiplier) == {(Decimal("2.51"), "multiplier")}


def test_mixed_dimensions_do_not_erase_actual_reported_ratios():
    assert _reported_quantities("256×256 images, 2.35× throughput, 12％ accuracy") == {
        (Decimal("2.35"), "multiplier"), (Decimal("12"), "%")}


def fixture(text, scope=""):
    draft = {"schema_version": "sciassistant.claim-draft/v2", "direct_answer": "Comparison",
             "claims": [{"claim_id": "c1", "text": text, "scope_note": scope, "qualification": "",
                         "claim_type": "quantitative", "evidence_ids": ["e1"], "confidence": "medium"}]}
    evidence = {"evidence": [{"evidence_id": "e1", "excerpt": "+15.05mAP and +25.90% acc; +19.49mAP and +23.39% acc.",
                              "source_scope": "full_text", "locator": {"page": 2}}]}
    return draft, evidence


def test_supported_percentages_with_resolution_note_do_not_raise_false_multiplier_error():
    draft, evidence = fixture("Reported +25.90% and +23.39% accuracy improvements.", "Evaluated with 256×256 images.")
    before = deepcopy((draft, evidence))
    assert "UNSUPPORTED_NUMBER" not in {row["reason"] for row in check_draft(draft, evidence)}
    assert (draft, evidence) == before
    # Passing a lexical quantity check does not constitute a semantic verdict.
    incomplete = check_audit({"schema_version": "sciassistant.citation-audit/v3", "status": "passed",
                              "claim_results": [], "issues": [], "rejected_claim_ids": []}, draft)
    assert incomplete["contract_errors"] and publication_rejections(incomplete, draft) == {"c1"}


@pytest.mark.parametrize("unsupported", ["25.91%", "256× faster", "23.39×", "2.51× faster"])
def test_missing_percentages_or_standalone_multipliers_remain_blocked(unsupported):
    draft, evidence = fixture(unsupported, "256x256 images.")
    assert {row["reason"] for row in check_draft(draft, evidence)} == {"UNSUPPORTED_NUMBER"}


def test_numeric_boundaries_do_not_match_suffix_of_other_numbers():
    assert (Decimal("12"), "%") not in _reported_quantities("112%")


def test_separate_claim_fields_do_not_turn_unsupported_speedup_into_dimensions():
    draft, evidence = fixture("256×", "256x256 images.")
    draft["claims"][0]["qualification"] = "23.39% accuracy is a different metric."
    assert {row["reason"] for row in check_draft(draft, evidence)} == {"UNSUPPORTED_NUMBER"}


def test_separate_evidence_packets_do_not_erase_supported_multiplier():
    draft, evidence = fixture("2×", "256x256 images.")
    evidence["evidence"][0]["excerpt"] = "Reported speedup 2×"
    evidence["evidence"].append({"evidence_id": "e2", "excerpt": "256x256 images.",
                                 "source_scope": "full_text", "locator": {"page": 3}})
    draft["claims"][0]["evidence_ids"].append("e2")
    assert check_draft(draft, evidence) == []


def test_dimension_only_evidence_does_not_support_standalone_speedup():
    draft, evidence = fixture("256× faster")
    evidence["evidence"][0]["excerpt"] = "256×256 images."
    assert {row["reason"] for row in check_draft(draft, evidence)} == {"UNSUPPORTED_NUMBER"}
