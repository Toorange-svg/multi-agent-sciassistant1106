"""Inline split answer/evidence with identity guards. DOM substitutes, not screenshots."""
import json
from pathlib import Path
import shutil
import subprocess

import pytest

ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.parametrize("scenario", ["chat", "reader", "failed", "legacy", "wrong_mode", "late_report", "escape", "account_changed"])
def test_one_answer_and_guarded_evidence_drawer(scenario):
    node = shutil.which("node")
    if not node:
        pytest.skip("Node required for frontend DOM substitute tests")
    source = (ROOT / "chatAi/multi_agent_rag.js").read_text(encoding="utf8")
    harness = r'''
const vm=require('node:vm'), nodes=[], listeners={}, intervals=[], downloads=[];
let release, modalCalls=0, drawerCalls=0, requestCount=0;
function matches(n, selector) {
 if(selector.startsWith('#')) return n.id===selector.slice(1);
 if(selector.startsWith('[data-rag-report-task=')) return n.dataset.ragReportTask===selector.split('"')[1];
 const [tag,cls]=selector.split('.');
 return (!tag||n.tag===tag)&&(!cls||(n.className||'').split(' ').includes(cls));
}
function el(tag) {
 const n={tag,tagName:tag.toUpperCase(),children:[],dataset:{},events:{},style:{setProperty(){}},open:false,
  getBoundingClientRect(){return {width:1000};},setAttribute(){},
  append(...items){for(const x of items){x.remove();this.children.push(x);x.parent=this;x.removed=false;}},
  remove(){if(this.parent) this.parent.children=this.parent.children.filter(x=>x!==this);this.parent=null;this.removed=true;},
  replaceWith(x){const p=this.parent,i=p.children.indexOf(this);this.remove();x.remove();p.children.splice(i,0,x);x.parent=p;x.removed=false;},
  querySelectorAll(selector){return this.children.flatMap(c=>[...(matches(c,selector)?[c]:[]),...c.querySelectorAll(selector)]);},
  querySelector(selector){return this.querySelectorAll(selector)[0]||null;},
  addEventListener(k,fn){this.events[k]=fn;},show(){drawerCalls++;},showModal(){modalCalls++;},
  focus(){this.focused=true;},scrollIntoView(){this.scrolled=true;},classList:{toggle(){}},
  click(){if(this.download)downloads.push(this.download);return this.events.click?.();}};
 Object.defineProperty(n,'childNodes',{get(){return this.children;}});
 Object.defineProperty(n,'textContent',{get(){return this._text||this.children.map(x=>x.textContent).join('');},set(v){this._text=String(v);this.children=[];}});
 Object.defineProperty(n,'innerHTML',{set(){throw Error('unsafe HTML');}});
 nodes.push(n);return n;
}
const text=(tag,s,cls)=>{const n=el(tag);n.textContent=s;if(cls)n.className=cls;return n;};
const container=el('div'), message=el('div'), returnFocus=el('button');container.append(message);
const window={currentSessionId:'s1',userToken:'fixture',innerWidth:1366,location:{search:''},addEventListener(k,fn){listeners[k]=fn;},removeEventListener(){}};
message.append(text('p','ONLY_CHAT_ANSWER [1]'));
if(SCENARIO==='legacy'||SCENARIO==='wrong_mode') {
 const legacy=el('div');legacy.className='science-report-sections';
 for(const [title,value] of [['科研分析报告','LEGACY_MAIN'],['原文记录','LEGACY_SCOPE']]) {
  const section=el('details');section.className='science-report-section';
  const body=el('div');body.className='science-report-body';body.append(text('p',value));
  section.append(text('summary',title),body);legacy.append(section);
 }
 message.append(legacy,text('div','LEGACY_DOWNLOADS','download-container'));
}
const context={window,document:{body:el('body'),activeElement:returnFocus,createElement:el,
 getElementById:()=>container,createTreeWalker:()=>({nextNode:()=>false})},NodeFilter:{SHOW_TEXT:4},
 AbortController,DOMException,URLSearchParams,setInterval:fn=>intervals.push(fn),setTimeout(){},
 URL:{createObjectURL:()=> 'blob:fixture',revokeObjectURL(){}},
 fetch:async(url)=>{requestCount++;return {ok:true,status:200,json:async()=>{
  if(SCENARIO==='late_report')await new Promise(r=>release=r);
  return {status:'partial',direct_answer:'VIEWER_BODY [1]',coverage:[],
   claims:[{text:'Claim',scope_note:'Visible scope',qualification:'REVIEW_DETAIL',evidence_ids:['e1']}],
   references:[{citation:1,evidence_id:'e1',title:'Source',locator:{page:2},excerpt:'APPROVED_EXCERPT'}]};
 },blob:async()=>{if(SCENARIO==='late_download')await new Promise(r=>release=r);return {};}};}};
vm.runInNewContext(SOURCE,context);
const tick=async()=>{for(let i=0;i<5;i++)await new Promise(r=>setImmediate(r));};
(async()=>{
 const task={id:'abcdef012345',status:SCENARIO==='failed'?'failed':'partial',processing_mode:SCENARIO==='wrong_mode'?'literature':'multi_agent_rag',report_available:SCENARIO!=='failed',execution:{model_calls:6}};
 window.MultiAgentRagUI.attach(task,'s1',message);window.MultiAgentRagUI.attach(task,'s1',message);
 const pending=SCENARIO==='reader'?window.MultiAgentRagUI.open(task.id,null,true)
  :['chat','legacy','late_report','escape'].includes(SCENARIO)?window.MultiAgentRagUI.open(task.id,1):null;
 await tick();
 if(SCENARIO==='late_report'){window.currentSessionId='s2';intervals.forEach(fn=>fn());release();}
 await pending;
 if(SCENARIO==='late_download') {
  const button=message.querySelectorAll('button').find(n=>n.textContent==='下载 JSON 运行证据包');
  const wait=button.events.click();await tick();window.userToken=null;release();await wait;
 }
 if(SCENARIO==='escape')listeners.keydown({key:'Escape'});
 if(SCENARIO==='account_changed') {
  window.userToken='different-account';
  for(const button of message.querySelectorAll('button'))await button.click();
 }
 const dialogs=context.document.body.querySelectorAll('dialog');
 console.log(JSON.stringify({modalCalls,drawerCalls,requestCount,dialogs:dialogs.length,downloads,
  footers:message.querySelectorAll('.rag-report-card').length,
  overviewFirst:message.querySelector('.rag-response-column')?.children[0]?.className?.includes('rag-outcome-panel'),
  columns:message.querySelector('.rag-chat-workspace')?.children.map(n=>n.className),
  bodyBeforeTools:message.querySelector('.rag-response-column')?.children.findIndex(n=>n.className==='rag-answer-body') < message.querySelector('.rag-response-column')?.children.findIndex(n=>n.className==='rag-report-tools'),
  menus:message.querySelectorAll('.rag-download-menu').map(m=>({open:m.open,buttons:m.querySelectorAll('button').length})),
  legacy:message.querySelectorAll('.science-report-sections').length,
  oldDownloads:message.querySelectorAll('.download-container').length,message:message.textContent,
  viewerBodies:dialogs.flatMap(d=>d.querySelectorAll('.rag-linked-answer')).map(n=>n.textContent),
  viewerPanels:dialogs.flatMap(d=>d.querySelectorAll('.rag-outcome-panel')).length,
  viewerMenus:dialogs.flatMap(d=>d.querySelectorAll('.rag-download-menu')).length,
  source:dialogs.some(d=>d.textContent.includes('APPROVED_EXCERPT')),
  focused:!!returnFocus.focused}));
})().catch(e=>{console.error(e);process.exit(1);});
'''
    script = "const SOURCE=" + json.dumps(source) + ";const SCENARIO=" + json.dumps(scenario) + ";\n" + harness
    result = subprocess.run([node, "-"], input=script, capture_output=True, text=True, encoding="utf8", timeout=10)
    assert result.returncode == 0, result.stderr
    data = json.loads(result.stdout)
    if scenario == "wrong_mode":
        assert data["footers"] == 0 and data["legacy"] == data["oldDownloads"] == 1
        return
    assert data["footers"] == 1 and "ONLY_CHAT_ANSWER" in data["message"]
    assert data["overviewFirst"]
    assert data["columns"] == ["rag-source-column", "rag-column-resizer", "rag-report-card rag-response-column"]
    assert data["bodyBeforeTools"]
    assert data["menus"] == ([] if scenario == "failed" else [{"open": False, "buttons": 3}])
    if scenario == "reader":
        # The task-center entry reuses a currently mounted chat answer, not a
        # second modal copy. Standalone deep links are tested separately.
        assert data["modalCalls"] == data["drawerCalls"] == data["dialogs"] == 0
        assert "APPROVED_EXCERPT" in data["message"]
    elif scenario in {"chat", "legacy"}:
        assert data["drawerCalls"] == data["modalCalls"] == data["dialogs"] == 0
        assert "APPROVED_EXCERPT" in data["message"]
        assert data["viewerBodies"] == [] and data["viewerPanels"] == data["viewerMenus"] == 0
        if scenario == "legacy":
            assert data["legacy"] == data["oldDownloads"] == 0
            assert "LEGACY_MAIN" in data["message"] and "LEGACY_SCOPE" in data["message"]
    elif scenario == "late_report":
        assert data["dialogs"] == 0 and "APPROVED_EXCERPT" not in data["message"]
    elif scenario == "escape":
        assert data["dialogs"] == 0 and "APPROVED_EXCERPT" in data["message"]
    elif scenario == "late_download":
        assert data["downloads"] == []
    elif scenario == "account_changed":
        assert data["requestCount"] == 1 and data["downloads"] == [] and data["dialogs"] == 0


def test_chat_uses_only_body_for_rag_and_keeps_old_report_renderer():
    html = (ROOT / "chatAi/ai_chat.html").read_text(encoding="utf8")
    assert "!displayOptions.multiAgentRag" in html
    assert "multiAgentRag: task.processing_mode === 'multi_agent_rag'" in html
    assert "task.processing_mode !== 'multi_agent_rag'" in html
    node = shutil.which("node")
    if not node:
        pytest.skip("Node needed for extracted body formatter")
    start = html.index("function scienceTaskMarkdown(")
    end = html.index("\n        function ", start + 10)
    function = html[start:end]
    script = function + "\nconsole.log(JSON.stringify(scienceTaskMarkdown({processing_mode:'multi_agent_rag',answer:'BODY_ONLY',sections:{report:'DUPLICATE',summary:'OLD_SUMMARY'}})));"
    result = subprocess.run([node, "-"], input=script, capture_output=True, text=True, encoding="utf8", timeout=10)
    assert result.returncode == 0, result.stderr
    assert json.loads(result.stdout) == "BODY_ONLY"


@pytest.mark.parametrize("mode,accepted", [("multi_agent_rag", True), ("literature", True), ("multi_agent_rag", False)])
def test_cancel_uses_unified_rag_footer_only_after_backend_acceptance(mode, accepted):
    node = shutil.which("node")
    if not node:
        pytest.skip("Node needed for extracted cancel handler")
    html = (ROOT / "chatAi/ai_chat.html").read_text(encoding="utf8")
    start = html.index("async function cancelScienceTaskFromUI(")
    end = html.index("async function pollScienceTask(", start)
    script = "const MODE=" + json.dumps(mode) + ";const ACCEPTED=" + json.dumps(accepted) + ";\n" + r'''
let legacy=0, attached=[], aborted=false;
const window={currentSessionId:'s1',scienceActiveTaskIds:{s1:'abcdef012345'},
 pendingSessions:{s1:{scienceTask:{processing_mode:MODE,id:'abcdef012345',execution:{model_calls:2}}}},
 MultiAgentRagUI:{attach:(task,session)=>attached.push({task,session})}};
const fetch=async()=>({ok:ACCEPTED}),showToast=()=>{},appendScienceEvidenceDownload=()=>legacy++;
''' + html[start:end] + r'''
(async()=>{await cancelScienceTaskFromUI('s1',{abort(){aborted=true;}},null);
console.log(JSON.stringify({legacy,attached,aborted}));})().catch(e=>{console.error(e);process.exit(1);});
'''
    result = subprocess.run([node, "-"], input=script, capture_output=True, text=True, encoding="utf8", timeout=10)
    assert result.returncode == 0, result.stderr
    data = json.loads(result.stdout)
    assert data["aborted"]
    assert data["legacy"] == 0
    assert len(data["attached"]) == (1 if accepted and mode == "multi_agent_rag" else 0)
    if data["attached"]:
        assert data["attached"][0]["task"]["status"] == "cancelled"
        assert data["attached"][0]["task"]["execution"]["model_calls"] == 2
