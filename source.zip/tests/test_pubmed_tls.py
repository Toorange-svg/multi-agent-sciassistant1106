from pathlib import Path
import sys
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]
for entry in (str(ROOT), str(ROOT / "deepdiver_v2")):
    if entry not in sys.path:
        sys.path.insert(0, entry)

from deepdiver_v2.src.tools.mcp_tools import (  # noqa: E402
    MCPTools, get_pubmed_metadata, search_pubmed,
)


class _Response:
    def __init__(self, *, content=b"", text=""):
        self.status_code = 200
        self.content = content
        self.text = text

    def raise_for_status(self):
        return None

    def json(self):
        return {"collection": []}


def test_pubmed_and_pmc_requests_require_tls_verification():
    tools = MCPTools.__new__(MCPTools)
    responses = [
        _Response(content=b"<root><ArticleId IdType='pmc'>PMC123</ArticleId></root>"),
        _Response(text="Safe PMC article text"),
    ]
    with patch("deepdiver_v2.src.tools.mcp_tools.requests.get", side_effect=responses) as get:
        result = tools.get_pubmed_article("123")

    assert result.success is True
    assert get.call_count == 2
    assert all(call.kwargs["verify"] is True for call in get.call_args_list)


def test_legacy_pubmed_search_and_metadata_require_tls_verification():
    responses = [
        _Response(content=b"<eSearchResult><IdList><Id>123</Id></IdList></eSearchResult>"),
        _Response(content=b"<root><Article><ArticleTitle>Title</ArticleTitle></Article></root>"),
    ]
    with patch("deepdiver_v2.src.tools.mcp_tools.requests.get", side_effect=responses) as get:
        assert search_pubmed("https://eutils.ncbi.nlm.nih.gov/example") == ["123"]
        assert get_pubmed_metadata("123")["PMID"] == "123"

    assert all(call.kwargs["verify"] is True for call in get.call_args_list)


def test_medrxiv_search_and_download_require_tls_verification(tmp_path):
    tools = MCPTools.__new__(MCPTools)
    tools.BASE_URL = "https://api.medrxiv.org/details/medrxiv"
    tools.max_retries = 1
    tools.timeout = 1

    class Session:
        def __init__(self):
            self.calls = []

        def get(self, *_args, **kwargs):
            self.calls.append(kwargs)
            return _Response(content=b"PDF", text="", )

    tools.session = Session()
    tools.medrxiv_search("medicine", max_results=1)
    output = tools.medrxiv_download_pdf("10.1101/example", str(tmp_path))

    assert Path(output).is_file()
    assert all(call["verify"] is True for call in tools.session.calls)
