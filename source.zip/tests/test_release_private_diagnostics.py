"""One-off local diagnostics cannot be source or image release inputs."""
from pathlib import Path

import pytest

from tools.freeze_release import PRIVATE_OPERATOR_TOOLS, allowed


@pytest.mark.parametrize('name', ['tools/_dbq.py', 'tools/_backfill.py', 'tools/_backfill2.py',
    'tools/_check_answer.py', 'tools/_list_sessions.py', 'tools/__private.py',
    'tools/_private/public.py', 'tools/pkg/_private/query.py'])
def test_private_diagnostics_rejected_even_when_they_are_tracked(name):
    assert not allowed(name)


@pytest.mark.parametrize('name', ['tools/__init__.py', 'tools/pkg/__init__.py',
    'tools/user_server.py', 'tools/multi_agent_cli.py', 'tools/rag_cloud.py'])
def test_reviewed_runtime_tools_and_package_initializers_still_allowed(name):
    assert allowed(name)


@pytest.mark.parametrize('name', ['.dockerignore', 'Dockerfile.account.cloud.dockerignore',
    'Dockerfile.cloud.dockerignore'])
def test_image_contexts_reject_private_tool_scripts(name):
    text = (Path(__file__).resolve().parents[1]/name).read_text(encoding='utf-8-sig')
    assert 'tools/_*.py' in text and 'tools/_*/**' in text
    assert text.rindex('tools/_*.py') < text.rindex('!tools/__init__.py')


@pytest.mark.parametrize('name', sorted(PRIVATE_OPERATOR_TOOLS))
def test_fixed_account_operator_scripts_are_not_release_inputs(name):
    assert not allowed(name)


@pytest.mark.parametrize('name', ['.dockerignore', 'Dockerfile.account.cloud.dockerignore',
    'Dockerfile.cloud.dockerignore'])
def test_image_contexts_exclude_fixed_account_operator_scripts(name):
    text = (Path(__file__).resolve().parents[1]/name).read_text(encoding='utf-8-sig')
    assert PRIVATE_OPERATOR_TOOLS <= set(text.splitlines())
