"""PDF parser resource budgets and public error-contract regressions."""

import json
from pathlib import Path
import subprocess
from unittest import mock

import fitz
import pdf_pipeline


CANARY = r"pdf-secret-canary token=plain C:\Users\private\paper.pdf /tmp/private/paper.pdf"


def _make_pdf(path: Path, pages: int = 1, text: str = "bounded scientific evidence"):
    document = fitz.open()
    for index in range(pages):
        page = document.new_page()
        page.insert_text((72, 72), f"{text} page {index + 1}")
    document.save(path)
    document.close()


def test_real_pdf_page_limit_fails_closed_without_partial_text(tmp_path, monkeypatch):
    pdf = tmp_path / "three-pages.pdf"
    _make_pdf(pdf, pages=3)
    monkeypatch.setattr(pdf_pipeline, "PDF_PARSE_CACHE_DIR", tmp_path / "cache")
    monkeypatch.setattr(pdf_pipeline, "PDF_PARSE_MAX_PAGES", 2)

    result = pdf_pipeline.parse_pdf(pdf, enable_ocr=False)
    assert result["success"] is False
    assert result["extraction_status"] == "resource_limited"
    assert result["error_code"] == "PDF_PAGE_LIMIT_EXCEEDED"
    assert result["resource_limit"] == {"name": "max_pages", "limit": 2, "observed": 3}
    assert result["text"] == "" and result["pages"] == []


def test_real_pdf_text_limit_fails_closed_without_partial_text(tmp_path, monkeypatch):
    pdf = tmp_path / "large-text.pdf"
    _make_pdf(pdf, text="\n".join(f"scientific evidence line {index}" for index in range(20)))
    monkeypatch.setattr(pdf_pipeline, "PDF_PARSE_CACHE_DIR", tmp_path / "cache")
    monkeypatch.setattr(pdf_pipeline, "PDF_PARSE_MAX_TEXT_CHARS", 100)

    result = pdf_pipeline.parse_pdf(pdf, enable_ocr=False)
    assert result["success"] is False
    assert result["error_code"] == "PDF_TEXT_LIMIT_EXCEEDED"
    assert result["resource_limit"]["limit"] == 100
    assert result["resource_limit"]["observed"] > 100
    assert result["content_length"] == 0


def test_success_cache_is_revalidated_when_runtime_budget_is_reduced(tmp_path, monkeypatch):
    pdf = tmp_path / "cached-two-pages.pdf"
    _make_pdf(pdf, pages=2)
    monkeypatch.setattr(pdf_pipeline, "PDF_PARSE_CACHE_DIR", tmp_path / "cache")
    monkeypatch.setattr(pdf_pipeline, "PDF_PARSE_MAX_PAGES", 10)
    first = pdf_pipeline.parse_pdf(pdf, enable_ocr=False)
    assert first["success"] is True and first["cache_hit"] is False

    monkeypatch.setattr(pdf_pipeline, "PDF_PARSE_MAX_PAGES", 1)
    second = pdf_pipeline.parse_pdf(pdf, enable_ocr=False)
    assert second["success"] is False
    assert second["error_code"] == "PDF_PAGE_LIMIT_EXCEEDED"
    assert second.get("cache_hit") is not True


def test_all_parser_failures_use_codes_without_exception_details(tmp_path, monkeypatch):
    pdf = tmp_path / "broken.pdf"
    pdf.write_bytes(b"%PDF-not-a-real-document")
    monkeypatch.setattr(pdf_pipeline, "PDF_PARSE_CACHE_DIR", tmp_path / "cache")

    with (
        mock.patch("fitz.open", side_effect=RuntimeError(CANARY)),
        mock.patch("pdfminer.high_level.extract_text", side_effect=RuntimeError(CANARY)),
        mock.patch("pypdf.PdfReader", side_effect=RuntimeError(CANARY)),
    ):
        result = pdf_pipeline.parse_pdf(pdf, enable_ocr=False)

    serialized = json.dumps(result)
    assert result["success"] is False
    assert result["error_code"] == "PDF_PARSE_FAILED"
    assert result["parser_failures"] == [
        {"parser": "pymupdf", "error_code": "PARSER_FAILED"},
        {"parser": "pdfminer.six", "error_code": "PARSER_FAILED"},
        {"parser": "pypdf", "error_code": "PARSER_FAILED"},
    ]
    assert "pdf-secret-canary" not in serialized
    assert "private" not in serialized


def test_ocr_failure_redacts_exception_and_engine_path(tmp_path, monkeypatch):
    pdf = tmp_path / "ocr.pdf"
    pdf.write_bytes(b"%PDF-not-a-real-document")
    monkeypatch.setattr(pdf_pipeline, "_find_tesseract", lambda: r"C:\private\tesseract.exe")
    with mock.patch("fitz.open", side_effect=RuntimeError(CANARY)):
        result = pdf_pipeline._ocr_pdf(pdf, page_count_hint=4)

    serialized = json.dumps(result)
    assert result["error_code"] == "OCR_PROCESSING_FAILED"
    assert result["error"] == "OCR processing failed."
    assert result["ocr_engine"] == "tesseract.exe"
    assert "pdf-secret-canary" not in serialized
    assert "private" not in serialized


def test_ocr_page_limit_rejects_before_starting_subprocess(tmp_path, monkeypatch):
    pdf = tmp_path / "ocr-many-pages.pdf"
    _make_pdf(pdf, pages=3)
    monkeypatch.setattr(pdf_pipeline, "PDF_PARSE_MAX_OCR_PAGES", 2)
    monkeypatch.setattr(pdf_pipeline, "_find_tesseract", lambda: r"C:\private\tesseract.exe")
    with mock.patch("subprocess.run") as run:
        result = pdf_pipeline._ocr_pdf(pdf)
    assert result["error_code"] == "PDF_OCR_PAGE_LIMIT_EXCEEDED"
    assert result["resource_limit"] == {"name": "max_ocr_pages", "limit": 2, "observed": 3}
    run.assert_not_called()


def test_ocr_page_timeout_returns_stable_resource_error(tmp_path, monkeypatch):
    pdf = tmp_path / "ocr-timeout.pdf"
    _make_pdf(pdf)
    monkeypatch.setattr(pdf_pipeline, "_find_tesseract", lambda: r"C:\private\tesseract.exe")
    monkeypatch.setattr(pdf_pipeline, "PDF_PARSE_OCR_PAGE_TIMEOUT_SECONDS", 3)
    with mock.patch(
        "subprocess.run",
        side_effect=subprocess.TimeoutExpired(["tesseract"], timeout=3, output=CANARY),
    ):
        result = pdf_pipeline._ocr_pdf(pdf)
    serialized = json.dumps(result)
    assert result["error_code"] == "PDF_OCR_PAGE_TIMEOUT"
    assert result["resource_limit"] == {
        "name": "ocr_page_timeout_seconds", "limit": 3, "observed": 3,
    }
    assert "pdf-secret-canary" not in serialized


def test_ocr_render_pixel_limit_rejects_before_allocating_pixmap(tmp_path, monkeypatch):
    pdf = tmp_path / "huge-page.pdf"
    document = fitz.open()
    document.new_page(width=4000, height=4000)
    document.save(pdf)
    document.close()
    monkeypatch.setattr(pdf_pipeline, "_find_tesseract", lambda: r"C:\private\tesseract.exe")
    monkeypatch.setattr(pdf_pipeline, "PDF_PARSE_MAX_RENDER_PIXELS", 1000)
    with mock.patch("subprocess.run") as run:
        result = pdf_pipeline._ocr_pdf(pdf, dpi=200)
    assert result["error_code"] == "PDF_OCR_RENDER_LIMIT_EXCEEDED"
    assert result["resource_limit"]["name"] == "max_render_pixels"
    assert result["resource_limit"]["observed"] > 1000
    run.assert_not_called()


def test_metadata_surfaces_budget_code_without_parser_exception_text():
    parsed = pdf_pipeline._resource_limit_result(
        "PDF_PAGE_LIMIT_EXCEEDED",
        "PDF exceeds the configured page limit.",
        "max_pages",
        10,
        11,
        page_count=11,
        parser="pymupdf",
    )
    metadata = pdf_pipeline.build_parse_metadata(parsed)
    assert metadata["error_code"] == "PDF_PAGE_LIMIT_EXCEEDED"
    assert metadata["resource_limit"] == {"name": "max_pages", "limit": 10, "observed": 11}
    assert metadata["parse_error"] == "PDF exceeds the configured page limit."
    assert metadata["risk_summary"]["level"] == "critical"
    assert "resource_limited" in metadata["risk_summary"]["failure_modes"]


def test_invalid_or_unbounded_environment_values_fall_back_or_cap(monkeypatch):
    monkeypatch.setenv("PDF_LIMIT_TEST", "not-an-int")
    assert pdf_pipeline._bounded_env_int("PDF_LIMIT_TEST", 50, 100) == 50
    monkeypatch.setenv("PDF_LIMIT_TEST", "0")
    assert pdf_pipeline._bounded_env_int("PDF_LIMIT_TEST", 50, 100) == 50
    monkeypatch.setenv("PDF_LIMIT_TEST", "999999")
    assert pdf_pipeline._bounded_env_int("PDF_LIMIT_TEST", 50, 100) == 100


def test_pdf_budgets_are_wired_into_compose_and_example_envs():
    root = Path(__file__).resolve().parents[1]
    compose = (root / "docker-compose.account.cloud.yml").read_text(encoding="utf-8")
    local_example = (root / ".env.example").read_text(encoding="utf-8")
    cloud_example = (root / ".env.account.cloud.example").read_text(encoding="utf-8")
    variables = (
        "SCIASSISTANT_PDF_MAX_PAGES",
        "SCIASSISTANT_PDF_MAX_TEXT_CHARS",
        "SCIASSISTANT_PDF_MAX_OCR_PAGES",
        "SCIASSISTANT_PDF_MAX_TABLE_OCR_CHECKS",
        "SCIASSISTANT_PDF_OCR_PAGE_TIMEOUT_SECONDS",
        "SCIASSISTANT_PDF_OCR_TOTAL_TIMEOUT_SECONDS",
        "SCIASSISTANT_PDF_TABLE_OCR_TOTAL_TIMEOUT_SECONDS",
        "SCIASSISTANT_PDF_MAX_RENDER_PIXELS",
    )
    for variable in variables:
        assert compose.count(f"      {variable}:") == 2
        assert f"{variable}=" in local_example
        assert f"{variable}=" in cloud_example
