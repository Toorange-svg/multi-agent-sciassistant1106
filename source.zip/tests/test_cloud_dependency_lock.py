"""Cloud dependency resolution must be reproducible and observable."""
import hashlib
import json
from pathlib import Path
import shutil
import sys

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tools import cloud_release, dependency_lock, generate_cloud_hash_lock
from runtime_identity import IDENTITY_FILES


REQUIREMENTS = ROOT / "deepdiver_v2/requirements.txt"
CLOUD_REQUIREMENTS = ROOT / "deepdiver_v2/requirements.cloud.txt"
CONSTRAINTS = ROOT / "deepdiver_v2/constraints.cloud.txt"
HASH_REQUIREMENTS = ROOT / "deepdiver_v2/requirements.cloud.hashes.txt"


def test_committed_cloud_lock_is_strict_complete_and_stable():
    report = dependency_lock.check_lock(
        REQUIREMENTS, CLOUD_REQUIREMENTS, CONSTRAINTS, HASH_REQUIREMENTS)
    assert report["passed"], report
    assert report["package_count"] == 85
    assert report["sha256"] == hashlib.sha256(HASH_REQUIREMENTS.read_bytes()).hexdigest()
    assert report["constraints_sha256"] == hashlib.sha256(CONSTRAINTS.read_bytes()).hexdigest()
    assert len(report["sha256"]) == 64


def test_lock_has_only_sorted_exact_registry_pins():
    packages, errors = dependency_lock.parse_constraints(CONSTRAINTS)
    assert not errors
    assert list(packages) == sorted(packages)
    assert all(name == dependency_lock.canonical_name(name) for name in packages)
    text = "\n".join(line for line in CONSTRAINTS.read_text(encoding="utf-8").splitlines()
                     if line.strip() and not line.lstrip().startswith("#"))
    assert "://" not in text and " @ " not in text and ";" not in text
    assert packages["litellm"] == "1.95.0"
    assert packages["pymupdf"] == "1.28.2"
    assert packages["gunicorn"] == "26.2.0"


def test_artifact_lock_has_one_strict_sha256_per_linux_amd64_package():
    hashes, errors = dependency_lock.parse_hash_requirements(HASH_REQUIREMENTS)
    packages, _ = dependency_lock.parse_constraints(CONSTRAINTS)
    assert not errors and set(hashes) == set(packages)
    assert all(hashes[name][0] == version for name, version in packages.items())
    assert all(len(digest) == 64 for _version, digest in hashes.values())
    header = HASH_REQUIREMENTS.read_text(encoding="utf-8").splitlines()[:2]
    assert any("linux/amd64" in line and "CPython 3.11" in line for line in header)


@pytest.mark.parametrize("bad_line", [
    "demo==1.0", "demo==1.0 --hash=sha256:short",
    "demo==1.0 --hash=md5:" + "0" * 32,
    "demo==1.0 --hash=sha256:" + "A" * 64,
])
def test_artifact_lock_rejects_missing_or_malformed_sha256(tmp_path, bad_line):
    path = tmp_path / "hashes.txt"
    path.write_text(bad_line + "\n", encoding="utf-8")
    _packages, errors = dependency_lock.parse_hash_requirements(path)
    assert errors


def test_offline_generator_binds_exact_artifact_bytes(tmp_path):
    constraints = tmp_path / "constraints.txt"
    constraints.write_text("demo==1.0\n", encoding="utf-8")
    wheelhouse = tmp_path / "wheelhouse"
    wheelhouse.mkdir()
    artifact = wheelhouse / "demo-1.0-py3-none-any.whl"
    artifact.write_bytes(b"artifact-canary")
    output = tmp_path / "hashes.txt"
    report = generate_cloud_hash_lock.generate(
        constraints, wheelhouse, output, "linux/amd64")
    expected = hashlib.sha256(b"artifact-canary").hexdigest()
    assert report["package_count"] == 1 and report["artifact_count"] == 1
    assert f"demo==1.0 --hash=sha256:{expected}" in output.read_text(encoding="utf-8")
    artifact.write_bytes(b"tampered")
    assert expected != hashlib.sha256(artifact.read_bytes()).hexdigest()


@pytest.mark.parametrize("bad_line", [
    "requests>=2.32.5", "requests @ https://invalid.example/pkg.whl",
    "requests==2.32.5; python_version > '3'", "-e ../local-package",
])
def test_lock_rejects_ranges_urls_markers_and_editable_sources(tmp_path, bad_line):
    lock = tmp_path / "constraints.txt"
    lock.write_text(bad_line + "\n", encoding="utf-8")
    _, errors = dependency_lock.parse_constraints(lock)
    assert errors


def test_lock_rejects_missing_direct_dependency(tmp_path):
    lock = tmp_path / "constraints.txt"
    lock.write_text("gunicorn==26.2.0\n", encoding="utf-8")
    report = dependency_lock.check_lock(
        REQUIREMENTS, CLOUD_REQUIREMENTS, lock, HASH_REQUIREMENTS)
    assert not report["passed"]
    assert next(item for item in report["checks"]
                if item["check"] == "all_direct_dependencies_constrained")["passed"] is False


def test_installed_verification_detects_mismatch_and_unlocked_packages(tmp_path, monkeypatch):
    locked, _ = dependency_lock.parse_constraints(CONSTRAINTS)
    monkeypatch.setattr(dependency_lock, "installed_packages", lambda: {
        **locked, "pip": "24.0", "setuptools": "79.0.1", "wheel": "0.46.3"})
    output = tmp_path / "record.json"
    report = dependency_lock.verify_installed(
        CONSTRAINTS, HASH_REQUIREMENTS, output, cloud_release.BASE_IMAGE, "linux/amd64")
    assert report["passed"] and output.is_file()
    record = json.loads(output.read_text(encoding="utf-8"))
    assert record["sha256"] == report["sha256"]
    assert record["constraints_sha256"] == report["constraints_sha256"]
    assert record["base_image"] == cloud_release.BASE_IMAGE
    assert record["platform"] == "linux/amd64"
    monkeypatch.setattr(dependency_lock, "installed_packages", lambda: {
        **locked, "requests": "0.0.0", "unlocked-canary": "1.0"})
    assert not dependency_lock.verify_installed(CONSTRAINTS, HASH_REQUIREMENTS)["passed"]


def test_both_cloud_images_pin_base_and_install_only_through_lock():
    for name in ("Dockerfile.account.cloud", "Dockerfile.cloud"):
        dockerfile = (ROOT / name).read_text(encoding="utf-8")
        assert cloud_release.BASE_IMAGE in dockerfile
        assert "--require-hashes --no-deps -r deepdiver_v2/requirements.cloud.hashes.txt" in dockerfile
        assert 'test "$TARGETPLATFORM" = "linux/amd64"' in dockerfile
        assert "dependency_lock.py check" in dockerfile
        assert "dependency_lock.py verify-installed" in dockerfile
        assert "pip check" in dockerfile
        assert "pip install --no-cache-dir gunicorn" not in dockerfile
        assert "COPY . " not in dockerfile


def test_account_context_and_root_context_include_lock_inputs():
    account_rules = (ROOT / "Dockerfile.account.cloud.dockerignore").read_text(encoding="utf-8").splitlines()
    root_rules = (ROOT / ".dockerignore").read_text(encoding="utf-8").splitlines()
    for item in ("!deepdiver_v2/requirements.cloud.txt", "!deepdiver_v2/constraints.cloud.txt",
                 "!deepdiver_v2/requirements.cloud.hashes.txt"):
        assert item in account_rules and item in root_rules
    assert "!tools/dependency_lock.py" in account_rules
    research_rules = (ROOT / "Dockerfile.cloud.dockerignore").read_text(encoding="utf-8").splitlines()
    assert research_rules[1] == "**"
    for item in ("!deepdiver_v2/requirements.cloud.txt", "!deepdiver_v2/constraints.cloud.txt",
                 "!deepdiver_v2/requirements.cloud.hashes.txt", "!tools/dependency_lock.py",
                 "**/.env", "**/*.sql", "**/*.pdf"):
        assert item in research_rules


def test_image_gate_rejects_missing_or_tampered_dependency_record(tmp_path):
    for name in cloud_release.REQUIRED + IDENTITY_FILES + ("deepdiver_v2/env.template",):
        target = tmp_path / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, target)
    # Copy published assets only: a developer checkout can contain private SQL.
    manifest = json.loads((ROOT / 'chatAi/assets/manifest.json').read_text(encoding='utf8'))
    for row in manifest['files']:
        target = tmp_path / 'chatAi' / row['path']
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / 'chatAi' / row['path'], target)
    for relative in ("deepdiver_v2/src", "deepdiver_v2/config"):
        for source in (ROOT / relative).rglob("*.py"):
            target = tmp_path / source.relative_to(ROOT)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
    (tmp_path / ".dependency-lock.json").write_text(json.dumps({
        "schema": "sciassistant.dependency-lock/v2",
        "sha256": hashlib.sha256((tmp_path / "deepdiver_v2/requirements.cloud.hashes.txt").read_bytes()).hexdigest(),
        "constraints_sha256": hashlib.sha256((tmp_path / "deepdiver_v2/constraints.cloud.txt").read_bytes()).hexdigest(),
        "package_count": 85, "python": "3.11.14", "base_image": cloud_release.BASE_IMAGE,
        "platform": "linux/amd64",
    }), encoding="utf-8")
    assert cloud_release.file_checks(tmp_path, image=True)["passed"]
    record = tmp_path / ".dependency-lock.json"
    record.write_text(json.dumps({"schema": "sciassistant.dependency-lock/v2",
                                  "sha256": "0" * 64,
                                  "constraints_sha256": hashlib.sha256(
                                      (tmp_path / "deepdiver_v2/constraints.cloud.txt").read_bytes()).hexdigest(),
                                  "package_count": 85, "base_image": cloud_release.BASE_IMAGE,
                                  "platform": "linux/amd64"}), encoding="utf-8")
    assert not cloud_release.file_checks(tmp_path, image=True)["passed"]
