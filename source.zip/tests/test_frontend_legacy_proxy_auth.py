"""Guard browser JWT injection for same-origin legacy compatibility routes."""
from pathlib import Path
from unittest import TestCase


HTML_PATH = Path(__file__).resolve().parents[1] / "chatAi" / "ai_chat.html"


class FrontendLegacyProxyAuthTests(TestCase):
    @classmethod
    def setUpClass(cls):
        cls.html = HTML_PATH.read_text(encoding="utf-8")

    def test_fetch_wrapper_covers_only_same_origin_account_and_legacy_routes(self):
        start = self.html.index("const sciAssistantFetch = window.fetch.bind(window);")
        section = self.html[start : start + 1200]
        self.assertIn("new URL(url, window.location.origin)", section)
        self.assertIn("5000\\/api", section)
        self.assertIn("8000", section)
        self.assertIn("8088", section)
        self.assertIn("resolvedUrl.origin !== window.location.origin", section)
        self.assertIn("headers.set('Authorization', `Bearer ${token}`)", section)


if __name__ == "__main__":
    import unittest

    unittest.main()
