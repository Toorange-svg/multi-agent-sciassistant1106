from copy import deepcopy

import pytest

from tools.check_premise_artifacts import reference_provenance


def inputs():
    source = {'evidence_id': 'e1', 'excerpt': 'An abstract describing the task.',
        'review_status': 'approved', 'locator': {}, 'evidence_strength': 'abstract_only'}
    ref = {**source, 'evidence_strength': 'abstract_only', 'excerpt_truncated': False}
    return [ref], {'evidence': [source]}


def test_approved_abstract_provenance_is_not_fulltext_localization():
    refs, approved = inputs()
    before = deepcopy((refs, approved))
    result = reference_provenance(refs, approved)
    assert result['all_provenance_valid']
    assert not result['all_fulltext_located'] and not result['semantic_support_verified']
    assert (refs, approved) == before


@pytest.mark.parametrize('field,value', [('evidence_id', 'invented'), ('excerpt', 'changed'),
    ('review_status', 'rejected'), ('excerpt_truncated', True), ('locator', {'page': 99})])
def test_mismatches_not_hidden_by_abstract_classification(field, value):
    refs, approved = inputs()
    refs[0] = {**refs[0], field: value}
    assert not reference_provenance(refs, approved)['all_provenance_valid']


def test_duplicate_ids_and_unapproved_sources_rejected():
    refs, approved = inputs()
    assert not reference_provenance(refs * 2, approved)['all_provenance_valid']
    approved['evidence'][0]['review_status'] = 'rejected'
    assert not reference_provenance(refs, approved)['all_provenance_valid']


def test_only_exact_documented_prefix_is_permitted():
    refs, approved = inputs()
    approved['evidence'][0]['excerpt'] = 'x' * 16001
    refs[0].update(excerpt='x' * 16000, excerpt_truncated=True)
    assert reference_provenance(refs, approved)['all_provenance_valid']
    refs[0]['excerpt'] = 'x' * 15999
    assert not reference_provenance(refs, approved)['all_provenance_valid']


def test_page_located_abstract_is_not_fulltext_and_strength_cannot_be_upgraded():
    refs, approved = inputs()
    locator = {'page': 1, 'bbox': [1, 2, 3, 4]}
    refs[0]['locator'] = locator
    approved['evidence'][0].update(locator=locator, evidence_strength='abstract_only')
    result = reference_provenance(refs, approved)
    assert result['all_provenance_valid'] and result['page_located_count'] == 1
    assert not result['all_fulltext_located'] and result['fulltext_located_count'] == 0
    refs[0]['evidence_strength'] = 'fulltext_located'
    changed = reference_provenance(refs, approved)
    assert not changed['all_fulltext_located'] and not changed['all_provenance_valid']
    approved['evidence'][0]['evidence_strength'] = 'fulltext_located'
    assert reference_provenance(refs, approved)['all_fulltext_located']


def test_no_references_is_not_evidence_of_fulltext_localization():
    result = reference_provenance([], {'evidence': []})
    assert not result['all_fulltext_located'] and result['fulltext_located_count'] == 0
