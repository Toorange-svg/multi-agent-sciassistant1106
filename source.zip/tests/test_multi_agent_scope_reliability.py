"""Recognize local reading scope without approving false absence or old tasks."""
from copy import deepcopy
from dataclasses import replace
import json

import pytest

from multi_agent_quality import (ABSENCE_SCOPE_POLICY, LEGACY_ABSENCE_SCOPE_POLICY,
    CONDITION_DENIAL_POLICY, AUDIT_CONTEXT_POLICY, audit_revision_context,
    check_audit, check_condition_denials, check_claim_revision,
    citation_audit_input, publication_rejections, answer_requirements, scope_plan_to_question)
from multi_agent_pipeline_v2 import check_draft
from test_multi_agent_report_fields import draft, evidence, QUOTE
from test_multi_agent_absence_basis import audit, absence

SOURCE = ('This second step yields the quantized quantization constants. '
          'We use 8-bit Floats with a blocksize of 256 for the second quantization '
          'as no performance degradation is observed for 8-bit quantization, in line with earlier results.')
BAD = '所选片段中第二级块大小与 c1 的完整公式被截断。'


@pytest.mark.parametrize('text', [
    '本片段未给出该均值本身的数据类型或存储方式。',
    '该片段未给出端到端显存或训练速度测量。',
    '该片段给出的是通用量化定义，未涉及 c2 的第二次量化。',
    '该片段未给出 cFP8_2 或 cFP32_1 的具体角色。',
    '该片段为 QLoRA 方法总览，未展开 c2 的第二次量化细节。',
    '此摘录未提供该项测试。', '该原文片段没有给出重复实验。',
    '这些片段中未见显著性检验、置信区间或统一排名。',
    '上述原文片段未给出该均值的存储方式。', '以上摘录没有包含该项测试。',
    '当前片段未给出实验细节。', '下列摘录未报告该结果。',
    'This excerpt does not provide the seed.', 'These passages do not report that experiment.',
    '本片段不能证明论文未做过该实验。', '该片段不代表论文未做该实验。',
    'This excerpt cannot prove that the paper did not conduct that experiment.',
])
def test_local_aliases_do_not_cause_false_unscoped_rejection(text):
    data, sources = draft(), evidence()
    data['absence_scope_policy'] = ABSENCE_SCOPE_POLICY
    data['claims'][0]['qualification'] = text
    value = absence(audit(data), text)
    original = deepcopy((data, sources, value))
    checked = check_audit(value, data, sources)
    assert not checked['contract_errors'] and not checked['absence_issues']
    assert (data, sources, value) == original


@pytest.mark.parametrize('text', [
    '本片段说明论文未做该实验。', '该片段表明作者没有给出任何验证。',
    '该片段提供结果，但论文未报告任何对照。', '该片段提供结果，而作者没有报告任何对照。',
    '论文没有报告该指标。', '全文未提供该项结果。', '三者均未报告该项结果。',
    '该片段未提供信息。论文没有报告对照。',
    'This excerpt shows the paper did not conduct that experiment.',
    '这些片段表明作者未给出任何验证。', '上述片段提供结果，论文没有报告任何对照。',
])
def test_alias_does_not_rescue_changed_paper_subject_or_unscoped_absence(text):
    data = draft(); data['absence_scope_policy'] = ABSENCE_SCOPE_POLICY
    data['claims'][0]['qualification'] = text
    checked = check_audit(absence(audit(data), text), data, evidence())
    assert checked['absence_issues'] and publication_rejections(checked, data) == {'c1'}


def test_partial_assertion_keeps_same_sentence_subject_not_other_field():
    data = draft(); data['absence_scope_policy'] = ABSENCE_SCOPE_POLICY
    data['claims'][0]['qualification'] = '该片段给出方法，未给出对照细节。'
    assert not check_audit(absence(audit(data), '未给出对照细节。'), data, evidence())['absence_issues']
    data['claims'][0]['qualification'] = '该片段给出方法，论文未给出对照细节。'
    assert check_audit(absence(audit(data), '未给出对照细节。'), data, evidence())['absence_issues']
    data['claims'][0].update(scope_note='该片段给出方法。', qualification='未给出对照细节。')
    assert check_audit(absence(audit(data), '未给出对照细节。'), data, evidence())['absence_issues']


def test_v2_and_no_policy_keep_old_semantics_while_v3_is_explicit():
    data = draft(); text = '该片段未给出对照细节。'
    data['claims'][0]['qualification'] = text
    for policy in (None, LEGACY_ABSENCE_SCOPE_POLICY, ABSENCE_SCOPE_POLICY):
        data['absence_scope_policy'] = policy
        checked = check_audit(absence(audit(data), text), data, evidence())
        assert bool(checked['absence_issues']) == (policy != ABSENCE_SCOPE_POLICY)
        enriched = citation_audit_input(data, evidence())
        if policy == ABSENCE_SCOPE_POLICY:
            assert enriched['absence_scope_policy'] == policy
            assert '本片段/该片段' in enriched['absence_check_instructions']


def condition_inputs(text='双重量化再次量化常数。', qualification=BAD):
    data, sources = draft(), evidence()
    data['condition_denial_policy'] = CONDITION_DENIAL_POLICY
    data['claims'][0].update(text=text, scope_note='', qualification=qualification)
    sources['evidence'][0]['excerpt'] = SOURCE
    return data, sources


@pytest.mark.parametrize('field', ['text', 'scope_note', 'qualification'])
def test_printed_condition_contradiction_has_exact_field_and_source_offsets(field):
    data, sources = condition_inputs(qualification='仅所选片段。')
    data['claims'][0][field] = BAD
    before = deepcopy((data, sources))
    issues = check_condition_denials(data, sources)
    assert len(issues) == 1 and issues[0]['field'] == field
    assert issues[0]['reason'] == 'EXPLICIT_CONDITION_DENIED' and not issues[0]['automatic_rewrite']
    quote = issues[0]['source_witnesses'][0]
    assert quote['quote'] == SOURCE[quote['start']:quote['end']] and quote['reported_value'] == '256'
    assert (data, sources) == before


@pytest.mark.parametrize('text', ['所选片段未给出第二次量化的块大小。', '第二次量化块大小未给出。', BAD])
def test_explicit_denial_of_readable_blocksize_rejected(text):
    assert check_condition_denials(*condition_inputs(qualification=text))


@pytest.mark.parametrize('text', [
    '第二级块大小为256，所选公式不完整。', '所选片段未给出 c1 的完整公式。',
    '所选片段未给出第二级块大小的调参敏感性。',
    '所选片段未给出第二级块大小与性能的因果关系。',
    '不能说第二级块大小被截断。',
])
def test_explicit_value_does_not_prove_full_formula_design_or_tuning(text):
    assert not check_condition_denials(*condition_inputs(qualification=text))


@pytest.mark.parametrize('fault', ['uncited', 'unapproved', 'other_condition', 'conflicting', 'multiple_papers'])
def test_no_verdict_from_another_or_ambiguous_source(fault):
    data, sources = condition_inputs()
    if fault == 'uncited': data['claims'][0]['evidence_ids'] = ['elsewhere']
    if fault == 'unapproved': sources['evidence'][0]['review_status'] = 'pending'
    if fault == 'other_condition': sources['evidence'][0]['excerpt'] = 'We use a blocksize of 256 for the first quantization.'
    if fault in {'conflicting', 'multiple_papers'}:
        sources['evidence'].append({**sources['evidence'][0], 'evidence_id': 'e2',
            'paper_id': 'p2' if fault == 'multiple_papers' else 'p1',
            'excerpt': SOURCE if fault == 'multiple_papers' else SOURCE.replace('256', '128')})
        data['claims'][0]['evidence_ids'].append('e2')
    assert not check_condition_denials(data, sources)


def test_condition_policy_and_precise_detail_repair_not_automatic_approval():
    data, sources = condition_inputs()
    issues = [row for row in check_draft(data, sources) if row['reason'] == 'EXPLICIT_CONDITION_DENIED']
    assert issues
    old = deepcopy(data); old.pop('condition_denial_policy')
    assert not any(row['reason'] == 'EXPLICIT_CONDITION_DENIED' for row in check_draft(old, sources))
    revised = deepcopy(data); revised['claims'][0]['scope_note'] = '实际块大小是256。'
    assert check_claim_revision(data, revised, {'code_issues': issues})['code_issues']
    revised['claims'][0]['qualification'] = '所选原文给出第二次量化块大小256；完整公式仍需原文核对。'
    assert not check_condition_denials(revised, sources)
    assert not check_claim_revision(data, revised, {'code_issues': issues})['code_issues']


@pytest.mark.parametrize('extra_fault', [False, True])
def test_matching_model_and_code_detail_rejection_does_not_force_body_rewrite(extra_fault):
    from test_multi_agent_report_fields import audit as field_audit, reject
    data, sources = condition_inputs()
    model = reject(field_audit(data))
    for row in model['claim_results']:
        row['source_witnesses'][0]['quote'] = SOURCE[:150]
    checked = check_audit(model, data, sources)
    assert not checked['contract_errors']
    issues = check_condition_denials(data, sources)
    if extra_fault:
        issues.append({'claim_id':'c1', 'reason':'UNSUPPORTED_NUMBER', 'field':'text'})
    revised = deepcopy(data)
    revised['claims'][0]['qualification'] = '所选片段给出第二次量化的块大小256。'
    result = check_claim_revision(data, revised, {'model_audit':checked, 'code_issues':issues})
    assert bool(result['code_issues']) == extra_fault
    assert result['changed_claims_still_require_audit']


def test_comparison_does_not_implicitly_demand_tradeoffs_but_explicit_ones_remain():
    assert answer_requirements('根据Table 3比较88.6和40.1的指标归属')['requested_dimensions'] == ['comparison']
    assert answer_requirements('比较这两种方法的优缺点')['requested_dimensions'] == ['comparison', 'tradeoffs']
    assert answer_requirements('比较这两种方法，不需要讨论取舍')['requested_dimensions'] == ['comparison']


def test_table_labels_do_not_require_unasked_complete_formalism():
    plan = {'groups': [{'id':'g1','metrics':['comparison','formal_definition','full_derivation']}]}
    original = deepcopy(plan)
    scoped, changes = scope_plan_to_question(plan, answer_requirements('比较Table 3的指标归属。'))
    assert scoped['groups'][0]['metrics'] == ['comparison'] and changes['changes']
    scoped, _ = scope_plan_to_question(plan, answer_requirements('比较Table 3，推导其中公式的形式化定义。'))
    assert scoped == plan == original


def test_full_workflow_local_alias_needs_no_writer_rework(tmp_path):
    from test_multi_agent_pipeline_v2 import agents, pipeline, worker
    configured, calls = agents(partial=True)
    def writer(_packet):
        calls.append('writer')
        data = draft(); data['claims'][0].update(evidence_ids=['arxiv-1'], confidence='low',
                                                scope_note='', qualification='该片段未提供该项对照细节。')
        return {'output': data}
    def auditor(packet):
        calls.append('citation_auditor')
        data = next(row['payload'] for row in packet['inputs'] if row['payload'].get('claims'))
        return {'output': absence(audit(data), data['claims'][0]['qualification'])}
    configured = replace(configured, writer=worker('writer', writer, 'write_approved_claims'),
                         citation_auditor=worker('citation_auditor', auditor, 'audit_citations'))
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {'status': 'ok', 'papers': [
        {'paper_id':'1', 'title':'Method', 'abstract': QUOTE, 'landing_url':'https://arxiv.org/abs/1'}]})
    result = flow.run('alias', 'owner', '解释方法。')
    assert result['run']['status'] == 'partial' and result['run']['model_calls_used'] == 5
    assert calls.count('writer') == calls.count('citation_auditor') == 1


def test_full_workflow_corrects_detail_without_discarding_supported_core(tmp_path):
    from test_multi_agent_pipeline_v2 import agents, pipeline, worker
    configured, calls = agents(partial=True)
    revisions = []
    def writer(_packet):
        calls.append('writer'); revisions.append(1)
        note = BAD if len(revisions) == 1 else '所选片段给出第二次量化块大小256，完整公式需另外核对。'
        data, _ = condition_inputs(qualification=note)
        data['claims'][0].update(evidence_ids=['arxiv-1'], confidence='low')
        return {'output': data}
    contexts = []
    def auditor(packet):
        calls.append('citation_auditor')
        payloads = [row['payload'] for row in packet['inputs']]
        if len(revisions) > 1:
            assert not any(row.get('schema_version') == 'sciassistant.citation-feedback/v1' for row in payloads)
            context = next(row for row in payloads if row.get('policy') == AUDIT_CONTEXT_POLICY)
            contexts.append(context)
            assert context['current_claim_ids'] == ['c1'] and not context['semantic_auto_approval']
            assert context['prior_issues_not_current_verdicts'][0]['reason'] == 'EXPLICIT_CONDITION_DENIED'
            current = next(row for row in payloads if row.get('schema_version') == 'sciassistant.claim-draft/v2')
            assert BAD != current['claims'][0]['qualification']
        return {'output': {'status':'passed'}}
    configured = replace(configured, writer=worker('writer', writer, 'write_approved_claims'),
                         citation_auditor=worker('citation_auditor', auditor, 'audit_citations'))
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {'status': 'ok', 'papers': [
        {'paper_id':'1', 'title':'Method', 'abstract': SOURCE, 'landing_url':'https://arxiv.org/abs/1'}]})
    result = flow.run('condition', 'owner', '解释方法。')
    assert calls.count('writer') == calls.count('citation_auditor') == 2
    assert result['run']['model_calls_used'] == 7 and BAD not in result['direct_answer']
    assert result['run']['status'] in {'partial', 'needs_review'}
    assert len(contexts) == 1


def test_revision_context_preserves_issues_not_prior_verdicts_or_absence_structures():
    data = draft()
    feedback = {'code_issues':[{'claim_id':'c1','field':'qualification','reason':'EXPLICIT_CONDITION_DENIED',
                               'detail':'核对该字段的缺项断言。','expected_field_value':'STALE_FIELD'}],
                'model_audit': {'claim_results':[
                    {'claim_id':'c1','decision':'approved','field_results':{'qualification':{'absence_checks':[
                        {'assertion':'STALE_ASSERTION'}]}},'source_witnesses':[{'quote':'STALE_QUOTE'}]},
                    {'claim_id':'c2','decision':'rejected','reason_code':'UNSUPPORTED_NUMBER','detail':'待核对数字。',
                     'field_results':{'text':{'status':'unsupported'}}}]}}
    before = deepcopy((data, feedback))
    context = audit_revision_context(data, feedback, 'draft-answer-current')
    assert context['current_draft_artifact_id'] == 'draft-answer-current'
    assert context['current_claim_ids'] == ['c1']
    assert len(context['prior_issues_not_current_verdicts']) == 2
    assert 'STALE_' not in json.dumps(context)
    assert (data, feedback) == before
