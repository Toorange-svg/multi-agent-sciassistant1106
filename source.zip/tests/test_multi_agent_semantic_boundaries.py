"""Source cues assist semantic judgments; never invent a verdict or fact."""
from copy import deepcopy

import pytest

from multi_agent_quality import source_boundary_brief, citation_audit_input, primary_assertion, check_semantic_boundaries, SEMANTIC_BOUNDARY_POLICY, publication_rejections
from multi_agent_live import ROLE_PROMPTS, PROMPT_VERSION


def source(key="e1", paper="2103.00020v1", status="approved", text=None):
    return {"evidence_id": key, "paper_id": paper, "review_status": status,
            "excerpt": text or "We consider two different architectures for the image encoder. For the first, we use ResNet-50.",
            "locator": {"page": 4}}


def draft(text="CLIP和DINOv2都以ViT为图像骨干。但CLIP还存在ResNet变体。"):
    return {"schema_version": "sciassistant.claim-draft/v2", "claims": [{
        "claim_id": "c1", "text": text, "scope_note": "这是后置范围说明。", "qualification": "审查备注。",
        "claim_type": "technical", "evidence_ids": ["e1"]}]}


def test_exact_offsets_provenance_and_inputs_not_changed():
    data = {"evidence": [source()]}
    before = deepcopy(data)
    brief = source_boundary_brief(data)
    cue = brief["cues"][0]
    assert cue["quote"] == data["evidence"][0][cue["field"]][cue["start"]:cue["end"]]
    assert cue["evidence_id"] == "e1" and cue["page"] == 4
    assert data == before
    assert "decision" not in cue and "facts" not in brief


@pytest.mark.parametrize("status", ["pending", "rejected", None])
def test_unapproved_text_never_becomes_boundary_evidence(status):
    assert source_boundary_brief({"evidence": [source(status=status)]})["cues"] == []


@pytest.mark.parametrize("category,text", [
    ("architecture_options", "For the second architecture we use a Vision Transformer."),
    ("experiment_settings", "Few-shot adaptation with 20% of the custom dataset reaches 85%."),
    ("modal_strength", "Fine-tuning often induces forgetting and may overfit seen artifacts."),
    ("component_roles", "A frozen teacher supervises the trainable student with LoRA.")])
def test_cues_are_verbatim_questions_not_generated_conditions(category, text):
    cue = next(r for r in source_boundary_brief({"evidence": [source(text=text)]})["cues"] if r["category"] == category)
    assert cue["quote"] in text
    assert cue["review_question"] and "verdict" not in cue


def test_same_paper_other_approved_chunks_can_limit_convenient_quote():
    data = {"evidence": [source(text="We train an image encoder and a text encoder."),
                         source("e2"), source("e3", paper="other"), source("e4", status="pending")]}
    result = citation_audit_input(draft(), data)
    row = result["claims"][0]
    assert row["primary_assertion"] == "CLIP和DINOv2都以ViT为图像骨干。"
    assert [r["evidence_id"] for r in row["source_boundary_cues"]] == ["e2"]
    assert row["evidence_ids"] == ["e1"]  # Counter-context isn't a new approval/citation.
    assert [r["evidence_id"] for r in row["source_context"]] == ["e1"]


@pytest.mark.parametrize("text,expected", [
    ("CLIP的ViT变体使用ViT；另有ResNet选项。", "CLIP的ViT变体使用ViT"),
    ("本文准确率95%。另一设置85%。", "本文准确率95%。"),
    ("Accuracy is 95.5%. Another experiment differs.", "Accuracy is 95.5%."),
    ("在所审查的ViT变体中，编码器采用ViT。", "在所审查的ViT变体中，编码器采用ViT。"),
    ("这些方法都使用ViT，但存在其他配置。", "这些方法都使用ViT，")])
def test_opening_separate_from_later_repair_but_initial_conditions_kept(text, expected):
    assert primary_assertion(text) == expected


def test_limits_and_dedup_do_not_change_rag_packets():
    rows = [source(str(i), text="We consider two different architectures. Frozen teacher may use few-shot adaptation.") for i in range(30)]
    rows[0]["text"] = rows[0]["excerpt"]
    data = {"evidence": rows}
    before = deepcopy(data)
    brief = source_boundary_brief(data)
    assert len(brief["cues"]) == 12
    assert all(len(r["quote"]) <= 340 for r in brief["cues"])
    keys = [(r["evidence_id"], r["category"]) for r in brief["cues"]]
    assert len(set(keys)) == len(keys)
    assert data == before


def test_no_cues_is_not_semantic_approval_and_metadata_not_source():
    row = source(text="Measured results are reported in the paper.")
    row["title"] = "Two different architectures and few-shot adaptation"
    brief = source_boundary_brief({"evidence": [row]})
    assert not brief["cues"]
    assert "automatic rejection or approval" in brief["instructions"]


def test_prompt_and_audit_input_require_evidence_first_boundary_comparison():
    assert PROMPT_VERSION.endswith("/v107")
    assert "ONE principal assertion" in ROLE_PROMPTS["writer"]
    assert "primary_assertion" in ROLE_PROMPTS["citation_auditor"]
    assert "different datasets" in ROLE_PROMPTS["writer"]
    result = citation_audit_input(draft(), {"evidence": [source()]})
    assert "same-paper" in result["semantic_comparison_policy"]
    assert result["claims"][0]["semantic_review_questions"]
    assert "decision" not in result["claims"][0]


@pytest.mark.parametrize("text", [
    "CLIP和DINOv2都以ViT为图像骨干。CLIP也有ResNet选项。",
    "CLIP 与 DINOv2 都属于以 ViT 作为图像编码器骨干的预训练视觉模型家族，但目标不同。",
    "CLIP的图像编码器采用ViT。",
    "CLIP与DINOv2都不是ViT本身，而是把ViT用作图像骨干的模型家族：CLIP也有ResNet选项。",
    "CLIP and DINOv2 both use ViT backbones."])
def test_explicit_source_alternative_blocks_known_universal_assertion(text):
    issues = check_semantic_boundaries(draft(text), {"evidence": [source()]})
    assert issues[0]["reason"] == "OVERSTATED_SCOPE"
    assert "two different architectures" in issues[0]["contrary_source_quote"]


@pytest.mark.parametrize("text", [
    "CLIP的ViT变体和DINOv2都使用ViT骨干。",
    "CLIP:ViT与DINOv2都使用ViT。",
    "CLIP图像编码器可选ResNet或ViT，DINOv2采用ViT。",
    "CLIP并非所有图像编码器都采用ViT。",
    "CLIP和DINOv2是否都采用ViT？",
    "不能说CLIP都采用ViT骨干。",
    "本轮证据未提供CLIP图像编码器采用ViT变体的明确描述。",
    "以ViT为骨干的CLIP模型和DINOv2都使用ViT。",
    "ViT是一类架构，CLIP是一类图文预训练方法。"])
def test_variant_options_negation_and_question_not_misblocked(text):
    assert check_semantic_boundaries(draft(text), {"evidence": [source()]}) == []


@pytest.mark.parametrize("change", ["missing", "unapproved", "title_only", "uncited_other_paper"])
def test_guard_needs_actual_related_approved_counter_context(change):
    rows = [source()]
    if change == "missing": rows = []
    elif change == "unapproved": rows[0]["review_status"] = "pending"
    elif change == "title_only": rows[0].update(title=rows[0]["excerpt"], excerpt="Contrastive training is used.")
    else: rows = [source(text="Image representations are trained."), source("e2", paper="unrelated")]
    assert check_semantic_boundaries(draft(), {"evidence": rows}) == []


def test_two_architectures_in_other_paper_not_a_clip_family_fact():
    assert check_semantic_boundaries(draft(), {"evidence": [source(paper="different-method")]}) == []


def test_same_paper_contrary_chunk_and_no_input_or_citation_mutation():
    data = draft()
    evidence = {"evidence": [source(text="Contrastive training is used."), source("e2")]}
    before = deepcopy((data, evidence))
    issues = check_semantic_boundaries(data, evidence)
    assert issues[0]["contrary_evidence_id"] == "e2"
    assert (data, evidence) == before


def test_guard_only_opted_new_draft_and_publication_dependencies_stay_local():
    from multi_agent_pipeline_v2 import check_draft
    data = {**draft(), "direct_answer": "有证据的回答。"}
    evidence = {"evidence": [source()]}
    assert not any(r["reason"] == "OVERSTATED_SCOPE" for r in check_draft(data, evidence))
    data["semantic_boundary_policy"] = SEMANTIC_BOUNDARY_POLICY
    issues = check_draft(data, evidence)
    assert any(r["reason"] == "OVERSTATED_SCOPE" for r in issues)
    data["claims"] += [{**data["claims"][0], "claim_id": "independent", "text": "CLIP采用图文对比训练。"},
                       {**data["claims"][0], "claim_id": "dependent", "depends_on_claim_ids": ["c1"]}]
    from test_multi_agent_protocol_recovery import audit_data
    audit = audit_data(data, schema="sciassistant.citation-audit/v3")
    audit["code_issues"] = check_semantic_boundaries(data, evidence)
    assert publication_rejections(audit, data) == {"c1", "dependent"}


@pytest.mark.parametrize("text", [
    "We train a series of 5 ResNets and 3 Vision Transformers. For the Vision Transformers we train a ViT-B/32.",
    "We train a series of 5\nResNets and 3 Vision\nTransformers.",
    "We train five ResNets and three ViTs.",
    "For the second architecture, we experiment with the recently introduced Vision Transformer (ViT). For the ResNet image encoders we scale width.",
])
def test_training_or_second_architecture_options_not_only_one_fixed_phrase(text):
    evidence = {"evidence": [source(text=text)]}
    issues = check_semantic_boundaries(draft(), evidence)
    assert issues[0]["reason"] == "OVERSTATED_SCOPE"
    assert issues[0]["policy"].endswith("/v2")
    for witness in issues[0]["contrary_source_witnesses"]:
        assert witness["quote"] == text[witness["start"]:witness["end"]]


@pytest.mark.parametrize("text", [
    "For the second architecture we use a Vision Transformer. A ResNet baseline is compared.",
    "We compare against five ResNets and three Vision Transformers.",
    "Related work trains five ResNets. We use a ViT.",
    "We train a ResNet classifier for a separate task and compare it against a ViT.",
])
def test_mention_or_comparator_not_mixed_clip_training_fact(text):
    assert check_semantic_boundaries(draft(), {"evidence": [source(text=text)]}) == []


def test_strong_training_option_cue_not_crowded_by_second_architecture():
    text = ("For the second architecture we use a Vision Transformer. " + "Text description. " * 100
            + "We train a series of 5 ResNets and 3 Vision Transformers.")
    cue = source_boundary_brief({"evidence": [source(text=text)]})["cues"][0]
    assert "5 ResNets and 3 Vision Transformers" in cue["quote"]
    assert cue["quote"] == text[cue["start"]:cue["end"]]


def test_old_v1_opt_in_not_rechecked_under_v2_rules():
    from multi_agent_pipeline_v2 import check_draft
    data = {**draft(), "direct_answer": "旧回答。",
            "semantic_boundary_policy": "source-backed-clip-family-regression-guard/v1"}
    assert not any(r["reason"] == "OVERSTATED_SCOPE" for r in check_draft(data, {"evidence": [source()]}))


@pytest.mark.parametrize("repair", [True, False])
def test_workflow_model_pass_does_not_override_training_options_guard(tmp_path, repair):
    from test_multi_agent_pipeline_v2 import agents, pipeline
    from test_multi_agent_scientific_scope import audit
    from multi_agent_quality import WITNESS_AUDIT_SCHEMA
    configured, calls = agents()
    actual = "We train a series of 5 ResNets and 3 Vision Transformers."
    drafts = []
    def writer(packet):
        calls.append("writer")
        drafts.append(packet)
        evidence = next(r["payload"] for r in packet["inputs"] if "evidence" in r["payload"])
        key = evidence["evidence"][0]["evidence_id"]
        data = draft("CLIP和DINOv2都以ViT为图像骨干。")
        data["direct_answer"] = "原文研究包括不同架构。"
        data["claims"][0].update(evidence_ids=[key], confidence="low", scope_note="依据所选摘要，未核查全文。")
        if len(drafts) > 1 and repair:
            data["claims"][0]["text"] = "CLIP的图像编码器包括ResNet和ViT架构选项。"
        data["claims"].append({**data["claims"][0], "claim_id": "independent", "text": "作者训练了不同架构的图像编码器。"})
        return {"output": data}
    def auditor(packet):
        calls.append("citation_auditor")
        data = next(r["payload"] for r in packet["inputs"] if "claims" in r["payload"])
        value = audit(data)
        value["schema_version"] = WITNESS_AUDIT_SCHEMA
        for row in value["claim_results"]:
            row["source_witnesses"] = [{"evidence_id": row["evidence_ids"][0], "quote": actual}]
        return {"output": value}
    configured.writer.handler = writer
    configured.citation_auditor.handler = auditor
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {"status": "ok", "papers": [
        {"paper_id": "2103.00020v1", "title": "Paper", "abstract": actual}]})
    result = flow.run("variant-repair", "owner", "Explain CLIP")
    assert calls.count("writer") == calls.count("citation_auditor") == 2
    assert result["run"]["model_calls_used"] == 7
    feedback = next(r["payload"] for r in drafts[1]["inputs"] if "code_issues" in r["payload"])
    assert any(r["reason"] == "OVERSTATED_SCOPE" for r in feedback["code_issues"])
    assert result["run"]["status"] == ("completed" if repair else "needs_review")
    assert ("CLIP和DINOv2都以ViT为图像骨干" in result["direct_answer"]) is False
