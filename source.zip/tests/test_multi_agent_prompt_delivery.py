"""Prompt wording is a delivery aid, never source evidence or automatic approval."""
import hashlib
import time

import pytest

from multi_agent_live import (COMMON_PROMPT, PROMPT_VERSION, ROLE_OUTPUT_LIMITS,
    ROLE_OUTPUT_SCHEMAS, LiveModelClient, effective_role_prompt, whole_report_review_prompt)
from test_multi_agent_live import config, Response


MODES = [{}, {'local_source': True}, {'mixed_source': True}]


@pytest.mark.parametrize('mode', MODES)
@pytest.mark.parametrize('marker', [
    'FIELD PLACEMENT:', 'INSIDE text', 'NOT 验证损失达到峰值',
    'ADVICE:', 'DEPENDENCIES:', 'CLOSING:', 'FINAL CHECK:',
])
def test_writer_gets_actionable_delivery_rules_in_all_source_modes(mode, marker):
    assert marker in effective_role_prompt('writer', **mode)


@pytest.mark.parametrize('mode', MODES)
def test_no_legacy_writing_targets_or_permissions_added(mode):
    text = effective_role_prompt('writer', **mode)
    assert '3-8 focused' not in text and '1-3 concise' not in text
    assert 'no target claim count or report length' in text
    assert 'Never remove a genuinely necessary dependency' in text
    assert 'No new unsupported fact may enter a summary' in text
    assert 'do not add checklist fields' in text
    assert 'printed optima and a final deployment choice' in effective_role_prompt('planner', **mode)
    auditor = effective_role_prompt('citation_auditor', **mode)
    assert 'Never approve a wrong field merely to preserve report coverage' in auditor
    assert 'distinguish a delivery gap from fabricated data' in auditor


@pytest.mark.parametrize('source_scope', ['arxiv', 'uploaded_pdf', 'mixed'])
def test_report_review_distinguishes_hidden_table_from_main_delivery(source_scope):
    text = whole_report_review_prompt(source_scope)
    assert 'cells appear only in qualification' in text
    assert 'both requested closing halves' in text
    assert "experiment's operational decision rule" in text
    assert 'only from its exact' in text.lower()
    assert 'CANNOT approve or reject source fields' in text


def test_actual_request_and_metadata_include_new_prompt_without_budget_change(monkeypatch):
    monkeypatch.setenv('MODEL_REQUEST_URL', 'https://example.test/v1/chat/completions')
    observed = {}
    def post(_url, **kwargs):
        observed.update(kwargs)
        return Response({'output': {'schema_version': ROLE_OUTPUT_SCHEMAS['writer']}})
    client = LiveModelClient(config(), post=post)
    client.call('writer', {'deadline_at': time.time()+20, 'inputs': []})
    actual = observed['json']['messages'][0]['content']
    assert actual == COMMON_PROMPT + effective_role_prompt('writer')
    assert 'FIELD PLACEMENT:' in actual
    assert PROMPT_VERSION.endswith('/v107')
    assert client.prompt_metadata()['writer']['sha256'] == hashlib.sha256(actual.encode()).hexdigest()
    assert observed['json']['max_tokens'] == ROLE_OUTPUT_LIMITS['writer'] == 8192
    assert observed['max_key_attempts'] == 1


@pytest.mark.parametrize('role', ['planner', 'writer', 'citation_auditor'])
@pytest.mark.parametrize('mode', MODES)
def test_action_summary_precedes_schema_reference_in_actual_effective_prompt(role, mode):
    text = effective_role_prompt(role, **mode)
    assert text.startswith('本轮操作摘要')
    assert text.index('本轮操作摘要') < text.index('Output {')
    assert '既有schema' in text


def test_writer_opening_defines_json_table_and_does_not_supply_paper_answers():
    from multi_agent_live import ROLE_DELIVERY_OPENINGS
    text = ROLE_DELIVERY_OPENINGS['writer']
    assert '\\n' in text and 'claim.text' in text
    assert '损失最优=最低' in text and 'qualification留空' in text
    for answer in ('70.38', '1.16', 'r=4', 'r=16'):
        assert answer not in text
