"""Visible cited-material scope is not scientific entailment or legacy migration."""
from copy import deepcopy

import pytest

from multi_agent_quality import (ABSENCE_SCOPE_POLICY, SOURCE_IDENTITY_ABSENCE_SCOPE_POLICY,
    check_audit, citation_audit_input, publication_rejections)
from test_multi_agent_report_fields import draft, evidence
from test_multi_agent_absence_basis import audit, absence


@pytest.mark.parametrize('text', [
    '按本次所引证据的输入输出定义推断，两个任务输出不同，这是尚未验证的适配设想。',
    '本轮所引用的证据没有提供直接应用实验。',
    '本次已引用的原文证据未给出该指标。',
    '本轮已审阅证据未提供这项对照。',
    'The evidence cited in this answer does not report that comparison.',
])
@pytest.mark.parametrize('field', ['text', 'scope_note', 'qualification'])
def test_new_policy_recognizes_explicit_current_cited_material(text, field):
    data, sources = draft(), evidence()
    data['absence_scope_policy'] = ABSENCE_SCOPE_POLICY
    data['claims'][0][field] = text
    raw = absence(audit(data), text, field=field)
    before = deepcopy((data, sources, raw))
    checked = check_audit(raw, data, sources)
    assert not checked['contract_errors'] and not checked['absence_issues']
    assert (data, sources, raw) == before
    # The legacy rule must still reproduce the historical scope rejection.
    data['absence_scope_policy'] = SOURCE_IDENTITY_ABSENCE_SCOPE_POLICY
    assert check_audit(raw, data, sources)['absence_issues']


@pytest.mark.parametrize('text', [
    '所有证据证明论文没有报告任何实验。',
    '按本次所引证据判断，论文未报告任何对照。',
    '本次所引证据未提供该结果。论文没有做过验证。',
    '已知证据未报告直接应用。',
    'The evidence cited in this answer shows the paper did not report any test.',
])
def test_scope_is_not_global_evidence_or_permission_for_whole_paper_absence(text):
    data = draft(); data['absence_scope_policy'] = ABSENCE_SCOPE_POLICY
    data['claims'][0]['text'] = text
    checked = check_audit(absence(audit(data), text, field='text'), data, evidence())
    assert checked['absence_issues'] and publication_rejections(checked, data) == {'c1'}


def test_separate_field_or_sentence_does_not_rescue_scope_and_audit_rejection_remains():
    data = draft(); data['absence_scope_policy'] = ABSENCE_SCOPE_POLICY
    data['claims'][0].update(text='本次所引证据描述两个任务。', qualification='未提供应用验证。')
    raw = absence(audit(data), '未提供应用验证。')
    assert check_audit(raw, data, evidence())['absence_issues']
    data['claims'][0]['qualification'] = '本次所引证据描述两个任务。未提供应用验证。'
    assert check_audit(raw, data, evidence())['absence_issues']
    text = '按本次所引证据推断，原模型不能直接输出真伪标签。'
    data['claims'][0].update(text=text, qualification='')
    raw = absence(audit(data), text, field='text')
    row = raw['claim_results'][0]
    row.update(decision='rejected', reason_code='UNSUPPORTED_EXTRAPOLATION', detail='任务定义不足以证明不能适配。')
    row['field_results']['text'].update(status='unsupported', detail='推断过强。')
    raw.update(status='needs_revision', rejected_claim_ids=['c1'], issues=[
        {'claim_id':'c1', 'reason_code':'UNSUPPORTED_EXTRAPOLATION', 'detail':'推断过强。'}])
    checked = check_audit(raw, data, evidence())
    assert not checked['absence_issues']
    assert publication_rejections(checked, data) == {'c1'}


def test_new_audit_input_requests_task_support_not_lexical_auto_approval():
    data = draft(); data['absence_scope_policy'] = ABSENCE_SCOPE_POLICY
    instructions = citation_audit_input(data, evidence())['absence_check_instructions']
    assert 'must still be rejected' in instructions
    assert '本次所引证据' in instructions
