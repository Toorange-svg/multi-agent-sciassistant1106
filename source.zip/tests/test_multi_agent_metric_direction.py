"""A literal optimum inversion is repair feedback, not an automatic fact."""
from copy import deepcopy
import pytest
from multi_agent_quality import check_metric_direction, METRIC_DIRECTION_POLICY, check_claim_revision
from multi_agent_pipeline_v2 import check_draft
from test_multi_agent_report_fields import draft, evidence, audit


SOURCE = "Unlike on GPT-3, here the performance peaks at r = 16 for validation loss and r = 4 for BLEU."

def inputs(text="验证损失在 r=16 达到峰值，BLEU 在 r=4 达到峰值。"):
    data, sources = draft(), evidence()
    data["claims"][0]["text"] = text
    data["claims"][0]["scope_note"] = ""
    data["claims"][0]["qualification"] = "所选表格说明。"
    sources["evidence"][0]["excerpt"] = SOURCE
    return data, sources


@pytest.mark.parametrize("field", ["text", "scope_note", "qualification"])
def test_cited_author_performance_optimum_does_not_support_loss_maximum(field):
    data, sources = inputs("原文报告实验结果。")
    data["claims"][0][field] = "验证损失在 r=16 达到峰值。"
    before = deepcopy((data, sources))
    issues = check_metric_direction(data, sources)
    assert len(issues) == 1 and issues[0]["field"] == field
    assert issues[0]["reason"] == "METRIC_DIRECTION_INVERTED"
    quote = issues[0]["source_witnesses"][0]
    assert quote["quote"] == SOURCE[quote["start"]:quote["end"]]
    assert not issues[0]["automatic_rewrite"] and (data, sources) == before


@pytest.mark.parametrize("text", [
    "验证损失达到最高。", "Validation loss peaks at rank 16.", "training loss is highest."])
def test_explicit_wrong_metric_direction_is_feedback(text):
    data, sources = inputs(text)
    # Only the corresponding metric is eligible; a different metric still
    # requires model review rather than a deterministic accusation.
    if "training" in text:
        sources["evidence"][0]["excerpt"] = SOURCE.replace("validation", "training")
    assert check_metric_direction(data, sources)


@pytest.mark.parametrize("text", [
    "验证损失最低，BLEU达到峰值。", "validation loss is lowest, BLEU is highest.",
    "不能写验证损失达到峰值。", "并非验证损失最高。", "Do not say validation loss peaks.",
    "性能在r=16最优，但表中有并列。", "r=16与32的验证损失并列最低。"])
def test_correct_direction_ties_and_refutations_are_not_rejected(text):
    data, sources = inputs(text)
    assert not check_metric_direction(data, sources)


@pytest.mark.parametrize("kind", ["unknown", "rejected", "uncited", "actual_loss_peak"])
def test_no_accusation_without_this_claims_approved_counter_source(kind):
    data, sources = inputs()
    if kind == "unknown":
        sources["evidence"][0]["excerpt"] = "We measure validation loss."
    elif kind == "rejected":
        sources["evidence"][0]["review_status"] = "rejected"
    elif kind == "uncited":
        data["claims"][0]["evidence_ids"] = ["other"]
    else:
        sources["evidence"][0]["excerpt"] = "Validation loss peaks at r=16; this is worse."
    assert not check_metric_direction(data, sources)


def test_new_workflow_opt_in_does_not_reinterpret_historical_draft():
    data, sources = inputs()
    assert not any(x["reason"] == "METRIC_DIRECTION_INVERTED" for x in check_draft(data, sources))
    data["metric_direction_policy"] = METRIC_DIRECTION_POLICY
    assert any(x["reason"] == "METRIC_DIRECTION_INVERTED" for x in check_draft(data, sources))


@pytest.mark.parametrize("text", ["训练损失达到峰值。", "困惑度达到最高。"])
def test_other_metric_is_not_accused_by_validation_loss_source(text):
    data, sources = inputs(text)
    assert not check_metric_direction(data, sources)


def test_detail_only_direction_repair_requires_actual_field_edit_and_reaudit():
    data, sources = inputs("主文报告作者实验。")
    data["claims"][0]["qualification"] = "验证损失达到峰值。"
    issues = check_metric_direction(data, sources)
    feedback = {"model_audit": audit(data), "code_issues": issues}
    unchanged = deepcopy(data)
    assert check_claim_revision(unchanged, data, feedback)["code_issues"]
    revised = deepcopy(data)
    revised["claims"][0]["qualification"] = "所选表格需核对最低损失及并列值。"
    assert not check_claim_revision(revised, data, feedback)["code_issues"]
    assert not check_metric_direction(revised, sources)  # This is not semantic approval.
