"""The historical task-center and acceptance export are not user-facing."""
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / 'chatAi/multi_agent_rag.js').read_text(encoding='utf-8')
HTML = (ROOT / 'chatAi/ai_chat.html').read_text(encoding='utf-8')


def test_task_center_and_acceptance_exports_have_no_user_entry():
    for marker in ('openTasks', '任务中心', '我的科研任务', '运行与验收证据', '下载 JSON 运行证据包', '验收证据包'):
        assert marker not in SOURCE
        assert marker not in HTML


def test_user_facing_report_download_and_evidence_view_remain():
    assert 'function reportDownloads' in SOURCE
    assert '打开回答与引用' in SOURCE or '原文证据' in SOURCE
    assert '/export?format=${format}' in SOURCE
    assert '定位原文证据' in SOURCE
