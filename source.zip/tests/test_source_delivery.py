import os
from pathlib import Path

from flask import Flask
import pytest

from source_delivery import install, source_status


FINGERPRINT = 'a' * 64


def settings():
    return {'PYMUPDF_LICENSE_MODE': 'agpl', 'PYMUPDF_AGPL_OBLIGATIONS_CONFIRMED': 'true',
            'PYMUPDF_CORRESPONDING_SOURCE_CONFIRMED': 'true',
            'PYMUPDF_SOURCE_URL': 'https://downloads.sciassistant.org/releases/source.zip',
            'SCIASSISTANT_SOURCE_ARCHIVE_SHA256': 'b' * 64,
            'SCIASSISTANT_SOURCE_FINGERPRINT': FINGERPRINT}


@pytest.mark.parametrize('url', ['http://downloads.sciassistant.org/a.zip', 'file:///private.env',
    'https://user:password@host.org/a.zip', 'https://host.org/a.zip?token=secret',
    'https://host.org/a.zip#private', 'https://127.0.0.1/a.zip', 'https://192.168.0.1/a.zip',
    'https://localhost/a.zip', 'https://host.local/a.zip', 'https://example.org/source.zip',
    'https://host.invalid/a.zip', 'https://host.org:444/a.zip', 'https://host.org:bad/a.zip',
    'https://host.org/"<script>', 'https://host.org/\na.zip'])
def test_unsafe_source_url_not_exposed(url):
    values = settings(); values['PYMUPDF_SOURCE_URL'] = url
    result = source_status(values, FINGERPRINT)
    assert not result['ready'] and result['url'] is None


@pytest.mark.parametrize('key,value', [
    ('PYMUPDF_AGPL_OBLIGATIONS_CONFIRMED', 'false'),
    ('PYMUPDF_CORRESPONDING_SOURCE_CONFIRMED', 'false'),
    ('PYMUPDF_LICENSE_MODE', 'review-required'),
    ('SCIASSISTANT_SOURCE_ARCHIVE_SHA256', 'bad'),
    ('SCIASSISTANT_SOURCE_FINGERPRINT', 'c' * 64),
])
def test_missing_confirmation_hash_or_stale_version_fails_closed(key, value):
    values = settings(); values[key] = value
    assert not source_status(values, FINGERPRINT)['ready']


def client(tmp_path, monkeypatch, configured=True):
    for name, value in settings().items():
        if configured:
            monkeypatch.setenv(name, value)
        else:
            monkeypatch.delenv(name, raising=False)
    (tmp_path/'LICENSE').write_text('original license', encoding='utf8')
    (tmp_path/'NOTICE').write_text('original notice', encoding='utf8')
    (tmp_path/'private.env').write_text('MUST_NOT_LEAK', encoding='utf8')
    app = Flask(__name__)
    identity = type('Identity', (), {'fingerprint': FINGERPRINT})()
    install(app, identity, tmp_path)
    return app.test_client()


def test_public_entry_matches_running_version_and_is_not_private_download_api(tmp_path, monkeypatch):
    http = client(tmp_path, monkeypatch)
    response = http.get('/open-source')
    assert response.status_code == 200
    assert settings()['PYMUPDF_SOURCE_URL'] in response.text
    assert FINGERPRINT in response.text and 'b'*64 in response.text
    assert response.headers['Cache-Control'] == 'no-store'
    assert http.get('/open-source/notices/LICENSE').text == 'original license'
    assert http.get('/open-source/notices/NOTICE').status_code == 200
    for target in ['private.env', 'source.zip', '%2e%2e%2fprivate.env', 'logs/user_credentials.sqlite3']:
        response = http.get('/open-source/notices/'+target)
        assert response.status_code == 404 and 'MUST_NOT_LEAK' not in response.text


def test_unconfigured_entry_does_not_advertise_a_download(tmp_path, monkeypatch):
    response = client(tmp_path, monkeypatch, False).get('/open-source')
    assert response.status_code == 503
    assert '源码交付尚未配置完成' in response.text
    assert 'id="corresponding-source-link"' not in response.text


def test_production_gateway_has_public_entry_without_database_or_token(monkeypatch):
    import app as gateway
    for name in settings(): monkeypatch.delenv(name, raising=False)
    with gateway.app.test_client() as http:
        assert http.get('/open-source').status_code == 503
        assert http.get('/open-source/notices/LICENSE').status_code == 200
        assert http.get('/open-source/notices/NOTICE').status_code == 200


def test_delivery_code_is_packaged_and_visible_before_and_after_login():
    from tools.freeze_release import allowed
    from runtime_identity import IDENTITY_FILES
    root = Path(__file__).resolve().parents[1]
    assert 'source_delivery.py' in IDENTITY_FILES and allowed('source_delivery.py')
    for name in ('Dockerfile.account.cloud', 'Dockerfile.cloud'):
        assert 'COPY source_delivery.py /app/' in (root/name).read_text(encoding='utf8')
        assert '!source_delivery.py' in (root/(name+'.dockerignore')).read_text(encoding='utf8')
    for name in ('ai_chat.html', 'login.html'):
        assert 'id="source-license-link" href="/open-source"' in (root/'chatAi'/name).read_text(encoding='utf8')
    compose = (root/'docker-compose.account.cloud.yml').read_text(encoding='utf8')
    for key in settings():
        assert key+':' in compose


def test_research_browser_probe_uses_static_css_and_actual_profile():
    source = (Path(__file__).resolve().parents[1]/'tools/check_research_web_browser.cjs').read_text(encoding='utf8')
    assert "typeof tailwind" not in source
    assert "getComputedStyle(probe).display==='flex'" in source
    assert "locator('#research-processing-mode').selectOption" not in source
    assert "locator('#research-report-profile').selectOption('standard')" in source
