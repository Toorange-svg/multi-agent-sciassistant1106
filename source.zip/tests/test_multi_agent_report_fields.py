"""Explicit report-field contracts and bounded revision, without semantic auto-approval."""
from copy import deepcopy

import pytest

from multi_agent_agents import AgentContractError
from multi_agent_live import normalize_live_result, ROLE_OUTPUT_SCHEMAS
from multi_agent_quality import (
    FIELD_AUDIT_SCHEMA, ABSENCE_AUDIT_SCHEMA, WITNESS_AUDIT_SCHEMA, REPORT_FIELDS, SCOPE_CHECKS,
    check_audit, check_claim_revision, citation_audit_input, publication_rejections,
    writer_revision_brief,
)
from test_multi_agent_pipeline_v2 import agents, pipeline


QUOTE = "Few-shot adaptation on this dataset achieved the reported accuracy."


def draft():
    return {"schema_version": "sciassistant.claim-draft/v2", "direct_answer": "有限回答",
        "claims": [{"claim_id": "c1", "text": "作者报告了该设置下的结果。",
            "scope_note": "仅该设置。", "qualification": "仅所选片段，不能认定全文没有验证。",
            "claim_type": "technical", "evidence_ids": ["e1"], "group_id": "g1",
            "section": "direct_conclusion"}]}


def evidence():
    return {"evidence": [{"evidence_id": "e1", "paper_id": "p1", "review_status": "approved",
        "coverage_scope": "selected_chunks", "excerpt": QUOTE, "locator": {"page": 1}}]}


def audit(data):
    return {"schema_version": FIELD_AUDIT_SCHEMA, "status": "passed", "issues": [],
        "rejected_claim_ids": [], "claim_results": [{
            "claim_id": c["claim_id"], "decision": "approved", "reason_code": "SUPPORTED",
            "detail": "所有报告字段在所选片段支持范围内。", "evidence_ids": c["evidence_ids"],
            "scope_checks": dict.fromkeys(SCOPE_CHECKS, "supported"),
            "source_witnesses": [{"evidence_id": c["evidence_ids"][0], "quote": QUOTE}],
            "field_results": {field: {"status": "supported" if c.get(field, "").strip()
                                     else "not_applicable", "detail": "逐字段核查。"}
                              for field in REPORT_FIELDS}
        } for c in data["claims"]]}


def reject(value, *, field="qualification", claim_id="c1", finding="unsupported"):
    row = next(r for r in value["claim_results"] if r["claim_id"] == claim_id)
    row["field_results"][field] = {"status": finding, "detail": "该字段越过所选片段阅读范围。"}
    row.update(decision="rejected", reason_code="READING_SCOPE_OVERSTATED")
    value.update(status="needs_revision")
    value["rejected_claim_ids"].append(claim_id)
    value["issues"].append({"claim_id": claim_id, "reason_code": "READING_SCOPE_OVERSTATED",
                            "detail": "仅该字段需要修订；不代表正文自动通过。"})
    return value


def feedback(data=None):
    data = data or draft()
    return {"model_audit": check_audit(reject(audit(data)), data, evidence()), "code_issues": []}


def test_current_contract_preserves_exact_fields_and_never_infers_approval():
    data, sources = draft(), evidence()
    before = deepcopy((data, sources))
    value = audit(data)
    value["schema_version"] = ABSENCE_AUDIT_SCHEMA
    for row in value["claim_results"]:
        for field in row["field_results"].values():
            field["absence_checks"] = []
    normalized = normalize_live_result("citation_auditor", {"output": value}, require_current=True)["output"]
    assert normalized == value
    assert ROLE_OUTPUT_SCHEMAS["citation_auditor"] == ABSENCE_AUDIT_SCHEMA
    assert check_audit(value, data, sources)["contract_errors"] == []
    enriched = citation_audit_input(data, sources)
    assert enriched["required_field_results"] == list(REPORT_FIELDS)
    assert enriched["claims"][0]["report_fields"] == {k: data["claims"][0][k] for k in REPORT_FIELDS}
    assert (data, sources) == before


@pytest.mark.parametrize("bad", [None, [], {}, {"text": {}},
    {**dict.fromkeys(REPORT_FIELDS, {"status": "supported", "detail": "x"}), "invented": {}}])
def test_missing_or_extra_field_results_never_filled(bad):
    data, value = draft(), audit(draft())
    value["claim_results"][0]["field_results"] = bad
    normalized = normalize_live_result("citation_auditor", {"output": value})["output"]
    assert normalized["claim_results"][0]["field_results"] == bad
    assert "AUDIT_FIELD_RESULTS_INVALID" in check_audit(normalized, data)["contract_errors"]
    assert publication_rejections(normalized, data) == {"c1"}


@pytest.mark.parametrize("bad", [None, [], {}, {"status": "supported"}, {"status": "supported", "detail": ""},
    {"status": "supported", "detail": " "}, {"status": "supported", "detail": "x" * 801},
    {"status": "maybe", "detail": "x"}, {"status": [], "detail": "x"},
    {"status": "supported", "detail": 1}, {"status": "supported", "detail": "x", "extra": True}])
def test_invalid_field_status_or_detail_rejected(bad):
    data, value = draft(), audit(draft())
    value["claim_results"][0]["field_results"]["qualification"] = bad
    assert "AUDIT_FIELD_RESULTS_INVALID" in check_audit(value, data)["contract_errors"]


@pytest.mark.parametrize("field", REPORT_FIELDS)
def test_nonempty_field_cannot_be_skipped_and_empty_cannot_be_supported(field):
    data = draft()
    value = audit(data)
    value["claim_results"][0]["field_results"][field]["status"] = "not_applicable"
    assert "AUDIT_FIELD_APPLICABILITY_INVALID" in check_audit(value, data)["contract_errors"]
    data["claims"][0][field] = ""
    value["claim_results"][0]["field_results"][field]["status"] = "supported"
    assert "AUDIT_FIELD_APPLICABILITY_INVALID" in check_audit(value, data)["contract_errors"]
    value["claim_results"][0]["field_results"][field]["status"] = "not_applicable"
    assert not check_audit(value, data)["contract_errors"]


@pytest.mark.parametrize("finding", ["unsupported", "needs_review"])
@pytest.mark.parametrize("field", REPORT_FIELDS)
def test_body_scope_and_detail_each_affect_whole_verdict(field, finding):
    data, value = draft(), audit(draft())
    value["claim_results"][0]["field_results"][field]["status"] = finding
    assert "AUDIT_FIELD_VERDICT_INCONSISTENT" in check_audit(value, data)["contract_errors"]
    assert publication_rejections(value, data) == {"c1"}


def test_whole_rejection_cannot_contradict_all_supported_fields():
    data = draft()
    value = reject(audit(data))
    value["claim_results"][0]["field_results"]["qualification"]["status"] = "supported"
    assert "AUDIT_FIELD_VERDICT_INCONSISTENT" in check_audit(value, data)["contract_errors"]


def test_rejected_detail_blocks_claim_and_dependency_not_independent_claim():
    data = draft()
    data["claims"] += [{**data["claims"][0], "claim_id": "c2"},
        {**data["claims"][0], "claim_id": "c3", "depends_on_claim_ids": ["c1"]}]
    value = check_audit(reject(audit(data)), data, evidence())
    assert value["contract_errors"] == [] and not value["witness_issues"]
    assert publication_rejections(value, data) == {"c1", "c3"}


@pytest.mark.parametrize("bad_quote", ["", "x" * 351, "Unrelated invented evidence that the source never reports."])
def test_supported_body_of_rejected_claim_still_requires_literal_witness(bad_quote):
    data = draft()
    value = reject(audit(data))
    value["claim_results"][0]["source_witnesses"][0]["quote"] = bad_quote
    checked = check_audit(value, data, evidence())
    assert checked["witness_issues"]
    updated = deepcopy(data)
    updated["claims"][0]["qualification"] = "仅在所选片段中未见验证证据。"
    result = check_claim_revision(data, updated, {"model_audit": checked, "code_issues": []})
    assert result["code_issues"][0]["reason"] == "UNCHANGED_UNSUPPORTED_CLAIM"


def test_missing_witness_cannot_prove_detail_only_exception():
    data = draft()
    value = reject(audit(data))
    value["claim_results"][0]["source_witnesses"] = []
    checked = check_audit(value, data, evidence())
    assert checked["witness_issues"][0]["reason"] == "AUDIT_SOURCE_WITNESSES_INVALID"


def test_legacy_v5_readable_without_field_migration_but_new_live_rejects_it():
    data = draft()
    value = audit(data)
    value["schema_version"] = WITNESS_AUDIT_SCHEMA
    del value["claim_results"][0]["field_results"]
    before = deepcopy(value)
    assert not check_audit(value, data, evidence())["contract_errors"]
    normalize_live_result("citation_auditor", {"output": value})
    with pytest.raises(AgentContractError):
        normalize_live_result("citation_auditor", {"output": value}, require_current=True)
    assert value == before


def test_exact_detail_revision_requires_reaudit_not_automatic_publication():
    data = draft()
    revised = deepcopy(data)
    revised["claims"][0]["qualification"] = "本次所选片段未提供对照，不能据此判断全文不存在。"
    result = check_claim_revision(data, revised, feedback(data))
    assert result["code_issues"] == []
    assert result["changed_claims_still_require_audit"] is True
    assert result["semantic_auto_approval"] is False
    assert result["resolution_targets"][0]["change_status"] == "edited_located_fields_requires_semantic_reaudit"
    assert publication_rejections(feedback(data)["model_audit"], data) == {"c1"}


@pytest.mark.parametrize("mutation", [
    lambda c: None,
    lambda c: c.update(claim_id="renamed"),
    lambda c: c.update(confidence="high"),
    lambda c: c.update(scope_note="changed unrelated scope"),
    lambda c: c.update(qualification=""),
    lambda c: c.update(qualification=" 仅所选片段，不能认定全文没有验证。 "),
])
def test_metadata_rename_or_wrong_field_edit_does_not_repair_detail(mutation):
    data, revised = draft(), draft()
    mutation(revised["claims"][0])
    assert check_claim_revision(data, revised, feedback(data))["code_issues"]


@pytest.mark.parametrize("field", ["text", "scope_note"])
def test_unsupported_body_or_scope_cannot_use_detail_only_exception(field):
    data = draft()
    value = reject(audit(data))
    value["claim_results"][0]["field_results"][field]["status"] = "unsupported"
    revised = deepcopy(data)
    revised["claims"][0]["qualification"] = "已改变详情但不能挽救正文。"
    checked = check_audit(value, data, evidence())
    assert not checked["contract_errors"]
    assert check_claim_revision(data, revised, {"model_audit": checked, "code_issues": []})["code_issues"]


def test_model_field_feedback_is_precise_without_rewriting_or_approving():
    data = draft()
    before = deepcopy(data)
    brief = writer_revision_brief(data, feedback(data), evidence())
    assert [r["field"] for r in brief["targets"][0]["fields"]] == ["qualification"]
    assert not brief["semantic_auto_approval"] and not brief["automatic_citation_repair"]
    assert data == before


@pytest.mark.parametrize("body_supported", [True, False])
def test_new_reason_name_cannot_bypass_v6_field_localization(body_supported):
    data = draft()
    value = reject(audit(data))
    value["claim_results"][0]["reason_code"] = "SPECIFIC_DETAIL_SCOPE_FAULT"
    value["issues"][0]["reason_code"] = "SPECIFIC_DETAIL_SCOPE_FAULT"
    if not body_supported:
        value["claim_results"][0]["field_results"]["text"]["status"] = "unsupported"
    checked = check_audit(value, data, evidence())
    assert not checked["contract_errors"]
    revised = deepcopy(data)
    revised["claims"][0]["qualification"] = "所选片段未提供验证，不对全文作否定。"
    result = check_claim_revision(data, revised, {"model_audit": checked, "code_issues": []})
    assert bool(result["code_issues"]) is not body_supported
    assert result["changed_claims_still_require_audit"] is True


@pytest.mark.parametrize("fix_detail", [True, False])
def test_full_workflow_detail_only_rework_always_runs_second_audit(tmp_path, fix_detail):
    configured, calls = agents()
    original = draft()
    original["claims"][0]["evidence_ids"] = ["arxiv-1"]
    original["claims"][0]["qualification"] = "这是未经任何对照实验验证的机制。"
    seen_drafts = []

    def writer(packet):
        calls.append("writer")
        data = deepcopy(original)
        if seen_drafts and fix_detail:
            brief = next(i["payload"] for i in packet["inputs"]
                         if i["payload"].get("schema_version") == "sciassistant.writer-revision-brief/v1")
            assert [r["field"] for r in brief["targets"][0]["fields"]] == ["qualification"]
            data["claims"][0]["qualification"] = "所选片段未提供对照，无法判断全文是否验证。"
        seen_drafts.append(deepcopy(data))
        return {"output": data}

    audit_calls = []
    def auditor(packet):
        calls.append("citation_auditor")
        data = next(i["payload"] for i in packet["inputs"] if "claims" in i["payload"])
        value = audit(data)
        if not audit_calls or not fix_detail:
            reject(value)
        audit_calls.append(deepcopy(value))
        return {"output": value}

    configured.writer.handler, configured.citation_auditor.handler = writer, auditor
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {"status": "ok", "papers": [
        {"paper_id": "1", "title": "Paper", "abstract": QUOTE}]})
    result = flow.run("detail-rework", "owner", "Define A")
    assert calls.count("writer") == calls.count("citation_auditor") == 2
    assert result["run"]["model_calls_used"] == 7
    assert seen_drafts[0]["claims"][0]["text"] == seen_drafts[1]["claims"][0]["text"]
    assert seen_drafts[0]["claims"][0]["evidence_ids"] == seen_drafts[1]["claims"][0]["evidence_ids"]
    final = flow.artifacts.get(result["final_artifact_id"])
    publication = flow.artifacts.get(final["artifact_refs"]["publication"])
    published = [r for r in publication["claims"] if r["published"]]
    assert bool(published) is fix_detail
    assert result["run"]["status"] == ("completed" if fix_detail else "failed")
    if not fix_detail:
        assert result["run"]["failure_code"] == "NO_AUDITED_CLAIMS"


def test_missing_field_protocol_routes_to_auditor_once_not_writer(tmp_path):
    configured, calls = agents()
    configured.writer.handler = lambda _: {"output": {**draft(), "claims": [
        {**draft()["claims"][0], "evidence_ids": ["arxiv-1"]}]}}
    count = []
    def auditor(packet):
        calls.append("citation_auditor")
        data = next(i["payload"] for i in packet["inputs"] if "claims" in i["payload"])
        value = audit(data)
        if not count:
            del value["claim_results"][0]["field_results"]["qualification"]
        else:
            report = next(i["payload"] for i in packet["inputs"]
                if i["payload"].get("schema_version") == "sciassistant.validation-report/v1")
            assert report["expected_field_results"]["fields"] == list(REPORT_FIELDS)
        count.append(1)
        return {"output": value}
    configured.citation_auditor.handler = auditor
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {"status": "ok", "papers": [
        {"paper_id": "1", "title": "Paper", "abstract": QUOTE}]})
    result = flow.run("field-protocol", "owner", "Define A")
    assert result["run"]["model_calls_used"] == 6
    assert len(count) == 2 and result["run"]["status"] == "completed"
