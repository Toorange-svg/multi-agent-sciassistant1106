"""Disk-cache tests for pdf_pipeline.parse_pdf.

A cached parse must return the same text and page structure as a fresh
parse, must be keyed by file content plus the OCR flag, and must not cache
failures.
"""
import copy
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import pdf_pipeline


class PdfParseCacheTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self._old_dir = pdf_pipeline.PDF_PARSE_CACHE_DIR
        pdf_pipeline.PDF_PARSE_CACHE_DIR = Path(tmp.name)
        self.addCleanup(self._restore)

    def _restore(self):
        pdf_pipeline.PDF_PARSE_CACHE_DIR = self._old_dir

    @staticmethod
    def _make_pdf(path: Path, marker: str = "Transformer attention limitations test page."):
        import fitz
        doc = fitz.open()
        page = doc.new_page()
        page.insert_text((72, 72), marker)
        doc.save(str(path))
        doc.close()

    def test_second_parse_hits_cache_with_identical_content(self):
        pdf = Path(self._old_dir.parent) / "k_cache_probe.pdf"
        try:
            self._make_pdf(pdf)
            first = pdf_pipeline.parse_pdf(pdf)
            self.assertFalse(first.get("cache_hit"))
            second = pdf_pipeline.parse_pdf(pdf)
            self.assertTrue(second.get("cache_hit"))
            self.assertEqual(first["text"], second["text"])
            self.assertEqual(first["pages"], second["pages"])
            self.assertEqual(first["page_count"], second["page_count"])
        finally:
            pdf.unlink(missing_ok=True)

    def test_ocr_flag_selects_a_distinct_entry(self):
        pdf = Path(self._old_dir.parent) / "k_cache_probe.pdf"
        try:
            self._make_pdf(pdf)
            first = pdf_pipeline.parse_pdf(pdf, enable_ocr=False)
            self.assertFalse(first.get("cache_hit"))
            again = pdf_pipeline.parse_pdf(pdf, enable_ocr=False)
            self.assertTrue(again.get("cache_hit"))
            other_flag = pdf_pipeline.parse_pdf(pdf, enable_ocr=True)
            self.assertFalse(other_flag.get("cache_hit"))
        finally:
            pdf.unlink(missing_ok=True)

    def test_failures_are_not_cached(self):
        missing = Path(tempfile.gettempdir()) / "k_cache_missing.pdf"
        missing.unlink(missing_ok=True)
        result = pdf_pipeline.parse_pdf(missing)
        self.assertFalse(result.get("success"))
        # A second call retries the real filesystem instead of replaying the
        # failure from the cache.
        self.assertFalse(pdf_pipeline.parse_pdf(missing).get("cache_hit"))

    def test_deleted_source_fails_honestly_without_cache(self):
        # The cache key is the file's content hash, so a deleted source cannot
        # be looked up: the call must fail honestly instead of guessing which
        # cached record (if any) used to belong to it.
        pdf = Path(self._old_dir.parent) / "k_cache_probe.pdf"
        try:
            self._make_pdf(pdf)
            pdf_pipeline.parse_pdf(pdf)
            pdf.unlink()
            result = pdf_pipeline.parse_pdf(pdf)
            self.assertFalse(result.get("success"))
            self.assertIn("does not exist", str(result.get("error")))
        finally:
            pdf.unlink(missing_ok=True)


if __name__ == "__main__":
    unittest.main()
