"""Robustness regressions for malformed input and external-service failures."""

import io
import subprocess
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

import requests

import web_app


class TaskInputRobustnessTests(unittest.TestCase):
    def setUp(self):
        self.client = web_app.app.test_client()

    def test_non_string_query_returns_json_400(self):
        response = self.client.post("/api/tasks", json={
            "query": 123,
            "processing_mode": "general_answer",
            "pdf_parse_mode": "local",
        })
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.content_type, "application/json")
        self.assertIn("文本字符串", response.get_json()["error"])

    def test_oversized_query_is_rejected_before_starting_task(self):
        response = self.client.post("/api/tasks", json={
            "query": "问" * (web_app.MAX_QUERY_LENGTH + 1),
            "processing_mode": "general_answer",
            "pdf_parse_mode": "local",
        })
        self.assertEqual(response.status_code, 413)
        payload = response.get_json()
        self.assertEqual(payload["max_query_length"], web_app.MAX_QUERY_LENGTH)
        self.assertIn("问题过长", payload["error"])

    def test_malformed_json_returns_json_400(self):
        response = self.client.post(
            "/api/tasks", data="{not-json", content_type="application/json",
        )
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.content_type, "application/json")

    def test_request_entity_too_large_returns_json(self):
        old_limit = web_app.app.config["MAX_CONTENT_LENGTH"]
        web_app.app.config["MAX_CONTENT_LENGTH"] = 100
        try:
            response = self.client.post("/api/tasks", data={
                "query": "解析",
                "pdf_parse_mode": "local",
                "pdf": (io.BytesIO(b"x" * 200), "oversized.pdf"),
            })
        finally:
            web_app.app.config["MAX_CONTENT_LENGTH"] = old_limit
        self.assertEqual(response.status_code, 413)
        self.assertEqual(response.content_type, "application/json")
        self.assertIn("50 MB", response.get_json()["error"])


class ExternalFailureRobustnessTests(unittest.TestCase):
    def setUp(self):
        self.old_log_dir = web_app.LOG_DIR
        self.tempdir = tempfile.TemporaryDirectory()
        web_app.LOG_DIR = Path(self.tempdir.name)
        with web_app.TASK_LOCK:
            self.old_tasks = web_app.TASKS.copy()
            web_app.TASKS.clear()

    def tearDown(self):
        with web_app.TASK_LOCK:
            web_app.TASKS.clear()
            web_app.TASKS.update(self.old_tasks)
        web_app.LOG_DIR = self.old_log_dir
        self.tempdir.cleanup()

    def _put_task(self, task_id):
        with web_app.TASK_LOCK:
            web_app.TASKS[task_id] = {
                "id": task_id,
                "status": "queued",
                "created_at": web_app._now(),
                "updated_at": web_app._now(),
            }

    @mock.patch.object(web_app, "post_model_request", side_effect=requests.ConnectionError("secret-host.invalid"))
    def test_general_chat_network_failure_is_clear_and_redacted(self, _post):
        task_id = "network-failure"
        self._put_task(task_id)
        # A transport-failure test must not depend on private project .env.
        config = SimpleNamespace(model_name='test-model', get_custom_llm_config=lambda: {
            'url': 'https://model.invalid/v1/chat/completions', 'token': '', 'timeout': 1})
        with mock.patch.object(web_app, 'get_config', return_value=config):
            web_app._run_general_chat_task(task_id, "你好")
        _post.assert_called_once()
        task = web_app.TASKS[task_id]
        self.assertEqual(task["status"], "failed")
        self.assertIn("网络连接异常", task["message"])
        self.assertNotIn("secret-host.invalid", task["message"])
        self.assertNotIn("secret-host.invalid", task["answer"])

    def test_research_subprocess_timeout_finishes_failed(self):
        task_id = "subprocess-timeout"
        self._put_task(task_id)
        fake_process = mock.Mock()
        fake_process.wait.side_effect = [
            subprocess.TimeoutExpired(cmd="run_demo.cmd", timeout=0),
            None,
        ]
        with mock.patch.dict("os.environ", {"WEB_TASK_TIMEOUT": "0"}), mock.patch.object(
            web_app.subprocess, "Popen", return_value=fake_process,
        ), mock.patch.object(web_app, "check_shared_mcp"):
            web_app._run_query_task(task_id, "量子纠缠是什么")
        task = web_app.TASKS[task_id]
        self.assertEqual(task["status"], "failed")
        self.assertIn("分析超时", task["message"])
        self.assertEqual(task["returncode"], -1)

    def test_http_provider_errors_have_stable_user_messages(self):
        expected = {
            401: "认证失败",
            402: "额度不足",
            429: "请求过于频繁",
            503: "暂时不可用",
        }
        for status, marker in expected.items():
            with self.subTest(status=status):
                response = requests.Response()
                response.status_code = status
                error = requests.HTTPError(response=response)
                self.assertIn(marker, web_app._user_facing_model_error(error))


class TaskLaunchFailureTests(unittest.TestCase):
    """Every failed launch must become an observable, safe terminal task."""

    def setUp(self):
        self.tempdir = tempfile.TemporaryDirectory()
        self.old_log_dir = web_app.LOG_DIR
        self.old_state_dir = web_app.TASK_STATE_DIR
        web_app.LOG_DIR = Path(self.tempdir.name) / "logs"
        web_app.LOG_DIR.mkdir()
        web_app.TASK_STATE_DIR = Path(self.tempdir.name) / "task_state"
        web_app.TASK_STATE_DIR.mkdir()
        with web_app.TASK_LOCK:
            self.old_tasks = web_app.TASKS.copy()
            self.old_queue = list(web_app._RETRIEVAL_QUEUE)
            self.old_active = set(web_app._RETRIEVAL_ACTIVE)
            web_app.TASKS.clear()
            web_app._RETRIEVAL_QUEUE.clear()
            web_app._RETRIEVAL_ACTIVE.clear()

    def tearDown(self):
        with web_app.TASK_LOCK:
            web_app.TASKS.clear()
            web_app.TASKS.update(self.old_tasks)
            web_app._RETRIEVAL_QUEUE.clear()
            web_app._RETRIEVAL_QUEUE.extend(self.old_queue)
            web_app._RETRIEVAL_ACTIVE.clear()
            web_app._RETRIEVAL_ACTIVE.update(self.old_active)
        web_app.LOG_DIR = self.old_log_dir
        web_app.TASK_STATE_DIR = self.old_state_dir
        self.tempdir.cleanup()

    def _put_task(self, task_id):
        with web_app.TASK_LOCK:
            web_app.TASKS[task_id] = {
                "id": task_id,
                "query": "安全启动测试",
                "status": "queued",
                "created_at": web_app._now(),
                "updated_at": web_app._now(),
            }

    def test_retrieval_thread_start_failure_releases_slot_and_exports_evidence(self):
        task_id = "thread-start-failure"
        self._put_task(task_id)
        with mock.patch.object(web_app.threading.Thread, "start", side_effect=RuntimeError(
            "Authorization: Bearer should-not-leak"
        )):
            web_app._enqueue_retrieval_task(task_id, lambda: None)

        with web_app.TASK_LOCK:
            task = dict(web_app.TASKS[task_id])
            self.assertNotIn(task_id, web_app._RETRIEVAL_ACTIVE)
            self.assertEqual(list(web_app._RETRIEVAL_QUEUE), [])
        self.assertEqual(task["status"], "failed")
        self.assertEqual(task["execution"]["failure_stage"], "retrieval_thread")
        self.assertIn("未能启动", task["message"])
        self.assertNotIn("should-not-leak", task["answer"])
        self.assertEqual(task["state_timeline"][-1]["to"], "failed")

        response = web_app.app.test_client().get(f"/api/tasks/{task_id}/evidence?format=json")
        self.assertEqual(response.status_code, 200)
        payload = response.get_json()
        self.assertEqual(payload["task"]["status"], "failed")
        self.assertEqual(payload["lifecycle"]["execution"]["failure_stage"], "retrieval_thread")
        self.assertNotIn("should-not-leak", response.get_data(as_text=True))

    def test_research_spawn_error_has_stable_terminal_failure(self):
        task_id = "research-spawn-failure"
        self._put_task(task_id)
        with mock.patch.object(web_app, "check_shared_mcp"), mock.patch.object(web_app.subprocess, "Popen", side_effect=OSError(
            "C:\\private\\provider-token-should-not-leak"
        )):
            web_app._run_query_task(task_id, "量子纠缠是什么")
        task = web_app.TASKS[task_id]
        self.assertEqual(task["status"], "failed")
        self.assertEqual(task["execution"]["failure_stage"], "research_worker")
        self.assertIn("未能完成", task["message"])
        self.assertNotIn("provider-token-should-not-leak", task["message"])
        self.assertNotIn("provider-token-should-not-leak", task["answer"])

    def test_pdf_parse_error_has_stable_terminal_failure(self):
        task_id = "pdf-parse-failure"
        self._put_task(task_id)
        with mock.patch.object(web_app, "parse_pdf", side_effect=OSError(
            "C:\\private\\parse-token-should-not-leak"
        )):
            web_app._parse_upload_task(task_id, Path(self.tempdir.name) / "missing.pdf", "local")
        task = web_app.TASKS[task_id]
        self.assertEqual(task["status"], "failed")
        self.assertEqual(task["execution"]["failure_stage"], "pdf_parse")
        self.assertIn("PDF 解析未能完成", task["message"])
        self.assertNotIn("parse-token-should-not-leak", task["answer"])

    def test_unsuccessful_pdf_result_does_not_expose_parser_error(self):
        task_id = "pdf-invalid-result"
        self._put_task(task_id)
        with mock.patch.object(web_app, "parse_pdf", return_value={
            "success": False,
            "error": "C:\\private\\corrupt-file-token-should-not-leak",
        }):
            web_app._parse_upload_task(task_id, Path(self.tempdir.name) / "invalid.pdf", "local")
        task = web_app.TASKS[task_id]
        self.assertEqual(task["status"], "failed")
        self.assertEqual(task["execution"]["failure_stage"], "pdf_parse_result")
        self.assertNotIn("corrupt-file-token-should-not-leak", task["message"])
        self.assertNotIn("corrupt-file-token-should-not-leak", task["answer"])

    def test_upload_save_failure_returns_terminal_task_not_500(self):
        client = web_app.app.test_client()
        with mock.patch.object(web_app, "_missing_task_configuration", return_value=[]), mock.patch(
            "werkzeug.datastructures.file_storage.FileStorage.save",
            side_effect=OSError("C:\\private\\upload-token-should-not-leak"),
        ):
            response = client.post("/api/tasks", data={
                "query": "请分析上传文件",
                "pdf_parse_mode": "local",
                "pdf": (io.BytesIO(b"fake pdf"), "canary.pdf"),
            })
        self.assertEqual(response.status_code, 202)
        task = response.get_json()["task"]
        self.assertEqual(task["status"], "failed")
        self.assertEqual(task["execution"]["failure_stage"], "upload_save")
        self.assertIn("PDF 保存失败", task["message"])
        self.assertNotIn("upload-token-should-not-leak", response.get_data(as_text=True))


class TaskCancellationTests(unittest.TestCase):
    def setUp(self):
        self.old_tasks = web_app.TASKS.copy()
        with web_app.TASK_LOCK:
            web_app.TASKS.clear()
            web_app._RETRIEVAL_QUEUE.clear()
            web_app._RETRIEVAL_ACTIVE.clear()
            web_app._RETRIEVAL_PROCESSES.clear()
            web_app.TASKS["cancel-me"] = {
                "id": "cancel-me",
                "status": "running",
                "created_at": web_app._now(),
                "updated_at": web_app._now(),
            }

    def tearDown(self):
        with web_app.TASK_LOCK:
            web_app._RETRIEVAL_QUEUE.clear()
            web_app._RETRIEVAL_ACTIVE.clear()
            web_app._RETRIEVAL_PROCESSES.clear()
            web_app.TASKS.clear()
            web_app.TASKS.update(self.old_tasks)

    def test_cancel_endpoint_marks_running_task_cancelled(self):
        response = web_app.app.test_client().post("/api/tasks/cancel-me/cancel")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["task"]["status"], "cancelled")
        self.assertTrue(web_app.TASKS["cancel-me"]["cancel_requested"])

    def test_cancelled_task_evidence_bundle_is_downloadable_and_redacted(self):
        with web_app.TASK_LOCK:
            web_app.TASKS["cancel-me"].update({
                "query": "测试 Authorization: Bearer secret-value",
                "timeline": [{"stage": "search", "token": "secret-value"}],
            })
        web_app.app.test_client().post("/api/tasks/cancel-me/cancel")

        json_response = web_app.app.test_client().get("/api/tasks/cancel-me/evidence?format=json")
        self.assertEqual(json_response.status_code, 200)
        self.assertIn("attachment;", json_response.headers["Content-Disposition"])
        payload = json_response.get_json()
        self.assertEqual(payload["schema"], "sciassistant.acceptance-evidence/v1")
        self.assertEqual(payload["task"]["status"], "cancelled")
        self.assertTrue(payload["task"]["cancel_requested"])
        self.assertEqual(payload["diagnostic_summary"]["timeline"][0]["token"], "[REDACTED]")
        self.assertNotIn("secret-value", json_response.get_data(as_text=True))

        markdown_response = web_app.app.test_client().get("/api/tasks/cancel-me/evidence?format=md")
        self.assertEqual(markdown_response.status_code, 200)
        self.assertIn("SciAssistant 验收证据包", markdown_response.get_data(as_text=True))

    def test_cancelled_worker_does_not_spawn_subprocess(self):
        web_app._cancel_task("cancel-me")
        with mock.patch.object(web_app.subprocess, "Popen") as popen:
            web_app._run_query_task("cancel-me", "量子纠缠是什么")
        popen.assert_not_called()

    def test_cancel_between_spawn_and_registration_terminates_immediately(self):
        """A cancellation racing Popen must not leave an unregistered child alive."""
        fake_process = mock.Mock()
        fake_process.poll.return_value = None
        fake_process.wait.return_value = None

        def spawn_then_cancel(*_args, **_kwargs):
            # The endpoint cannot see the process yet, exactly matching the
            # production race that previously deferred cleanup to polling.
            web_app._cancel_task("cancel-me")
            return fake_process

        with mock.patch.object(web_app, "check_shared_mcp"), mock.patch.object(web_app.subprocess, "Popen", side_effect=spawn_then_cancel):
            web_app._run_query_task("cancel-me", "量子纠缠是什么")

        fake_process.terminate.assert_called_once()
        self.assertEqual(web_app.TASKS["cancel-me"]["status"], "cancelled")
        self.assertNotIn("cancel-me", web_app._RETRIEVAL_PROCESSES)

    def test_late_worker_failure_cannot_overwrite_cancelled_status(self):
        """Cancellation wins even when Popen fails while the worker unwinds."""

        def cancel_then_fail(*_args, **_kwargs):
            web_app._cancel_task("cancel-me")
            raise OSError("simulated spawn failure")

        with mock.patch.object(web_app, "check_shared_mcp"), mock.patch.object(web_app.subprocess, "Popen", side_effect=cancel_then_fail):
            web_app._run_query_task("cancel-me", "量子纠缠是什么")

        task = web_app.TASKS["cancel-me"]
        self.assertEqual(task["status"], "cancelled")
        self.assertTrue(task["cancel_requested"])

    def test_cancelled_presearch_does_not_launch_full_worker(self):
        """A completed pre-search must not hand a cancelled task to the CLI."""

        def cancel_then_return(*_args, **_kwargs):
            web_app._cancel_task("cancel-me")
            return [], {"requested_concepts": [], "covered_concepts": []}, None

        with mock.patch(
            "deepdiver_v2.cli.demo._search_relevant_literature",
            side_effect=cancel_then_return,
        ), mock.patch.object(web_app, "_run_query_task") as run_worker:
            web_app._prepare_query_task("cancel-me", "量子纠缠是什么")

        run_worker.assert_not_called()
        self.assertEqual(web_app.TASKS["cancel-me"]["status"], "cancelled")


if __name__ == "__main__":
    unittest.main()
