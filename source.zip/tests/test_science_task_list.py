"""Owner-first task discovery without importing/restarting the research service."""
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest
import app as account
import web_app as web

A = "aaaaaaaaaaaa"
B = "bbbbbbbbbbbb"
C = "cccccccccccc"


@pytest.fixture
def store(tmp_path, monkeypatch):
    monkeypatch.setenv("SCIASSISTANT_WEB_BASE", "")
    monkeypatch.setattr(account, "SCIENCE_TASK_STATE_DIR", tmp_path)
    monkeypatch.setattr(account, "_SCIENCE_TASK_OWNERS", {A: "alice", B: "bob", C: "alice"})
    monkeypatch.setattr(account, "_current_auth_version", lambda _id: 0)
    monkeypatch.setattr(web, "TASKS", {})
    # No chat-database recovery/discovery. JWT checking is substituted above.
    monkeypatch.setattr(account, "get_db_connection", lambda: pytest.fail("must not discover through chat DB"))
    for index, key in enumerate((A, B, C)):
        task = {"id": key, "query": f"canary-{key}", "status": "partial" if key == A else "failed",
                "processing_mode": "multi_agent_rag", "created_at": "2026-10-09T00:00:00Z",
                "updated_at": "2026-10-09T00:01:00Z", "execution": {"model_calls": 8},
                "report_available": key == A, "answer": "not in overview",
                "diagnostics_path": "C:/private/logs/x", "conversation_id": ""}
        path = tmp_path / f"{key}.json"
        path.write_text(json.dumps(task), encoding="utf-8-sig")
        os.utime(path, (100 + index, 100 + index))
    return tmp_path


def get(owner="alice", query=""):
    headers = {"Authorization": "Bearer " + account.generate_token(owner, owner)} if owner else {}
    return account.app.test_client().get("/api/science/tasks" + query, headers=headers)


def test_only_owned_snapshots_no_chat_no_user_claim(store):
    before = {p.name: p.read_bytes() for p in store.iterdir()}
    response = get(query="?user_id=bob&owner=bob")
    assert response.status_code == 200
    data = response.get_json()
    assert data["read_only"] and data["schema_version"] == "sciassistant.task-list/v1"
    assert [row["id"] for row in data["tasks"]] == [C, A]
    assert B not in response.get_data(as_text=True)
    assert all("answer" not in row and "diagnostics_path" not in row and "owner" not in row for row in data["tasks"])
    assert before == {p.name: p.read_bytes() for p in store.iterdir()}
    assert [row["id"] for row in get("bob").get_json()["tasks"]] == [B]
    assert get(None).status_code == 401


def test_pagination_and_filters_scan_without_duplicate(store):
    first = get(query="?limit=1").get_json()
    assert first["tasks"][0]["id"] == C and first["next_offset"] == 1
    second = get(query="?limit=1&offset=1").get_json()
    assert second["tasks"][0]["id"] == A and second["next_offset"] is None
    filtered = get(query="?status=partial&mode=multi_agent_rag").get_json()
    assert [t["id"] for t in filtered["tasks"]] == [A]
    assert get(query="?status=running").get_json()["tasks"] == []


@pytest.mark.parametrize("query", ["?limit=0", "?limit=26", "?offset=-1", "?offset=x", "?offset=100001",
                                        "?status=secret", "?mode=../../private"])
def test_invalid_parameters_are_rejected(store, query):
    assert get(query=query).status_code == 400


def test_live_state_beats_snapshot_without_mutation(store, monkeypatch):
    task = json.loads((store / f"{A}.json").read_text(encoding="utf-8-sig"))
    task.update(status="running", report_available=False, execution={"model_calls": 2})
    monkeypatch.setattr(web, "TASKS", {A: task})
    before = (store / f"{A}.json").read_bytes()
    data = get(query="?status=running").get_json()
    assert data["tasks"][0]["model_calls"] == 2
    assert not data["tasks"][0]["report_available"]
    assert (store / f"{A}.json").read_bytes() == before


def test_sensitive_or_long_question_is_redacted(store):
    task = json.loads((store / f"{A}.json").read_text(encoding="utf-8-sig"))
    task["query"] = "C:/private/model.key token=canary-token Bearer canary-bearer " + "q" * 1000
    task["execution"]["model_calls"] = 999
    (store / f"{A}.json").write_text(json.dumps(task))
    response = get()
    assert "canary-token" not in response.text and "canary-bearer" not in response.text
    assert "C:/private" not in response.text
    row = next(t for t in response.get_json()["tasks"] if t["id"] == A)
    assert len(row["query"]) == 500 and row["model_calls"] == 0


def test_corrupt_oversized_mismatched_snapshots_fail_closed(store):
    (store / f"{A}.json").write_text('{"id":"wrong"}')
    (store / f"{C}.json").write_text("x" * 5_000_001)
    result = get().get_json()
    assert result["tasks"] == [] and result["unavailable_count"] == 2
    # A file without an authoritative binding never enters discovery.
    (store / "dddddddddddd.json").write_text('{"id":"dddddddddddd","status":"completed"}')
    assert get().get_json()["total_owned"] == 2


def test_symlink_never_reads_outside_owned_store(store, monkeypatch):
    original = Path.is_symlink
    monkeypatch.setattr(Path, "is_symlink", lambda path: path.name == f"{A}.json" or original(path))
    data = get().get_json()
    assert [t["id"] for t in data["tasks"]] == [C] and data["unavailable_count"] == 1


def test_remote_mode_explicitly_unavailable(store, monkeypatch):
    monkeypatch.setenv("SCIASSISTANT_WEB_BASE", "http://127.0.0.1:5050")
    response = get()
    assert response.status_code == 503 and "5050" not in response.text


def test_owner_archive_limit_is_bounded(store, monkeypatch):
    monkeypatch.setattr(account, "_SCIENCE_TASK_OWNERS", {f"{i:012x}": "alice" for i in range(2001)})
    assert get().status_code == 503


def test_fresh_process_owner_restore_lists_api_only_task_without_loading_web(store):
    owners = store / "owners.json"
    owners.write_text(json.dumps({A: "alice", B: "bob", C: "alice"}), encoding="utf-8-sig")
    before = {p.name: p.read_bytes() for p in store.iterdir()}
    env = dict(os.environ, SCIASSISTANT_TASK_STATE_DIR=str(store), SCIASSISTANT_TASK_OWNER_STATE_PATH=str(owners), SCIASSISTANT_WEB_BASE="")
    script = r'''
import json, sys, app
app._current_auth_version=lambda uid: 0
def forbidden():
    raise AssertionError("must not access chat DB")
app.get_db_connection=forbidden
client=app.app.test_client()
results={}
for name in ("alice","bob",None):
    headers={"Authorization":"Bearer "+app.generate_token(name,name)} if name else {}
    response=client.get("/api/science/tasks",headers=headers)
    results[str(name)]={"status":response.status_code,"ids":[t["id"] for t in (response.get_json().get("tasks") or [])]}
results["web_imported"]="web_app" in sys.modules
print("CHECK:"+json.dumps(results))
'''
    proc = subprocess.run([sys.executable, "-c", script], cwd=Path(account.__file__).parent, env=env,
                          capture_output=True, text=True, encoding="utf-8", timeout=20)
    assert proc.returncode == 0, proc.stderr
    result = json.loads(proc.stdout.split("CHECK:", 1)[1])
    assert result["alice"]["status"] == 200 and set(result["alice"]["ids"]) == {A, C}
    assert result["bob"]["ids"] == [B] and result["None"]["status"] == 401
    assert not result["web_imported"]
    assert before == {p.name: p.read_bytes() for p in store.iterdir()}
