"""Shared MCP authentication and diagnostic-surface regressions."""

import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
from types import SimpleNamespace
import urllib.error
import urllib.request
from unittest import mock

import pytest
from starlette.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "deepdiver_v2"))
from src.tools import mcp_client
from src.tools import mcp_server_standard as server


SECRET = "offline-mcp-canary-" + "s" * 40


def test_non_loopback_bind_requires_a_strong_shared_secret(monkeypatch):
    monkeypatch.delenv("MCP_SHARED_SECRET", raising=False)
    assert server._validate_mcp_auth_configuration("127.0.0.1") is None
    for host in ("0.0.0.0", "192.168.1.20", "mcp"):
        with pytest.raises(RuntimeError, match="MCP_SHARED_SECRET_REQUIRED"):
            server._validate_mcp_auth_configuration(host)

    for value in ("short", "change-me", "REPLACE_WITH_A_HIGH_ENTROPY_SHARED_SECRET",
                  "REPLACE_WITH_A_PRIVATE_HIGH_ENTROPY_MCP_SECRET"):
        monkeypatch.setenv("MCP_SHARED_SECRET", value)
        with pytest.raises(RuntimeError, match="MCP_SHARED_SECRET_INVALID"):
            server._validate_mcp_auth_configuration("127.0.0.1")

    monkeypatch.setenv("MCP_SHARED_SECRET", SECRET)
    assert server._validate_mcp_auth_configuration("0.0.0.0") == SECRET


def test_mcp_and_diagnostics_require_bearer_but_health_is_minimal(monkeypatch, tmp_path):
    monkeypatch.setenv("MCP_SHARED_SECRET", SECRET)
    monkeypatch.setattr(server, "config", server.ServerConfig(
        host="127.0.0.1", base_workspace_dir=str(tmp_path / "workspaces")))
    app = server.create_app()
    with TestClient(app) as client:
        health = client.get("/health")
        assert health.status_code == 200
        assert health.json() == {
            "status": "healthy", "version": "1.0.0", "authentication_required": True}
        assert "session_stats" not in health.text and "workspace" not in health.text

        for path, method in (("/mcp", "post"), ("/tracking", "get"), ("/rate-limits", "get")):
            response = getattr(client, method)(path)
            assert response.status_code == 401
            assert response.json() == {"error": "MCP_AUTHENTICATION_REQUIRED"}
            assert response.headers["cache-control"] == "no-store"

        authorized = client.get(
            "/rate-limits", headers={"Authorization": f"Bearer {SECRET}"})
        assert authorized.status_code == 404
        assert authorized.json()["error"] == "Global tool rate limiter not initialized"


def test_mcp_client_adds_only_configured_shared_secret(monkeypatch):
    response = SimpleNamespace(
        status_code=200,
        headers={"content-type": "application/json"},
        json=lambda: {"result": {}},
        text='{"result":{}}',
    )
    http = mock.Mock()
    http.post.return_value = response
    client = mcp_client.MCPClient.__new__(mcp_client.MCPClient)
    client.server_url = "http://127.0.0.1:6274/mcp"
    client.retry_config = mcp_client.RetryConfig(max_retries=0)
    client._request_id = 0
    client._session_id = None
    client._get_http_client = mock.Mock(return_value=http)

    monkeypatch.setenv("MCP_SHARED_SECRET", SECRET)
    assert client._make_request("tools/list").success
    assert http.post.call_args.kwargs["headers"]["Authorization"] == f"Bearer {SECRET}"

    monkeypatch.delenv("MCP_SHARED_SECRET", raising=False)
    assert client._make_request("tools/list").success
    assert "Authorization" not in http.post.call_args.kwargs["headers"]


def test_sse_does_not_enable_wildcard_browser_cors():
    source = (ROOT / "deepdiver_v2/src/tools/mcp_server_standard.py").read_text(encoding="utf-8")
    assert '"Access-Control-Allow-Origin": "*"' not in source


def test_real_isolated_service_requires_secret_for_initialize():
    with socket.socket() as reservation:
        reservation.bind(("127.0.0.1", 0))
        port = reservation.getsockname()[1]
    with tempfile.TemporaryDirectory() as directory:
        environment = {
            **os.environ,
            "MCP_SHARED_SECRET": SECRET,
            "MCP_SERVER_LOG_PATH": str(Path(directory) / "mcp.log"),
            "MODEL_REQUEST_URL": "http://127.0.0.1:9/offline",
            "MODEL_REQUEST_TOKEN": "offline-unused",
            "PYTHONUTF8": "1",
        }
        command = [
            sys.executable, "-u", str(ROOT / "tools/run_mcp_service.py"),
            "--host", "127.0.0.1", "--port", str(port),
            "--workspace-dir", str(Path(directory) / "workspaces"),
        ]
        with open(os.devnull, "w") as stream:
            process = subprocess.Popen(command, cwd=ROOT, env=environment,
                                       stdout=stream, stderr=subprocess.STDOUT)
            try:
                health_url = f"http://127.0.0.1:{port}/health"
                deadline = time.monotonic() + 25
                while time.monotonic() < deadline:
                    assert process.poll() is None, "isolated MCP exited before healthy"
                    try:
                        with urllib.request.urlopen(health_url, timeout=1) as response:
                            health = response.read().decode("utf-8")
                        if '"authentication_required":true' in health.replace(" ", ""):
                            break
                    except OSError:
                        time.sleep(0.1)
                else:
                    pytest.fail("isolated MCP did not become healthy")

                body = b'{"jsonrpc":"2.0","id":1,"method":"initialize","params":{}}'
                unauthenticated = urllib.request.Request(
                    f"http://127.0.0.1:{port}/mcp", data=body,
                    headers={"Content-Type": "application/json"}, method="POST")
                with pytest.raises(urllib.error.HTTPError) as denied:
                    urllib.request.urlopen(unauthenticated, timeout=3)
                assert denied.value.code == 401

                authenticated = urllib.request.Request(
                    f"http://127.0.0.1:{port}/mcp", data=body,
                    headers={
                        "Content-Type": "application/json",
                        "Authorization": f"Bearer {SECRET}",
                    }, method="POST")
                with urllib.request.urlopen(authenticated, timeout=5) as response:
                    assert response.status == 200
                    assert response.headers.get("Access-Control-Allow-Origin") is None
            finally:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=5)


def test_real_network_bind_without_secret_fails_before_listening(tmp_path):
    with socket.socket() as reservation:
        reservation.bind(("127.0.0.1", 0))
        port = reservation.getsockname()[1]
    environment = {**os.environ, "PYTHONUTF8": "1",
                   "MCP_SERVER_LOG_PATH": str(tmp_path / "mcp.log")}
    environment.pop("MCP_SHARED_SECRET", None)
    command = [
        sys.executable, "-u", str(ROOT / "deepdiver_v2/src/tools/mcp_server_standard.py"),
        "--host", "0.0.0.0", "--port", str(port),
        "--workspace-dir", str(tmp_path / "workspaces"),
    ]
    completed = subprocess.run(command, cwd=ROOT, env=environment,
                               capture_output=True, text=True, timeout=20)
    output = completed.stdout + completed.stderr
    assert completed.returncode == 2
    assert "MCP_AUTH_CONFIGURATION_INVALID" in output
    assert "Traceback" not in output
    assert str(tmp_path) not in output
    with socket.socket() as client:
        client.settimeout(1)
        assert client.connect_ex(("127.0.0.1", port)) != 0
