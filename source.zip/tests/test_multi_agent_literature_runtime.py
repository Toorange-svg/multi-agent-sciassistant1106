from __future__ import annotations

from multi_agent_literature import LiteratureRoles
from multi_agent_literature_runtime import execute_multi_agent_literature


def _plan(_question):
    return {"schema_version": 1, "groups": [{"id": "g1", "question": "A", "queries": ["A"], "priority": 1}],
            "assumptions": [], "out_of_scope": []}


def _retrieve(group):
    return {"schema_version": 1, "records": [{
        "evidence_id": "evidence-1", "group_id": group["id"], "paper_id": "2401.00001", "title": "Paper A",
        "source": "arxiv", "publication_date": None, "claim_support": [], "excerpt": "excerpt",
        "fulltext_available": True, "provenance": {"retrieval_run_id": "retrieval-1"},
    }]}


def _review(_plan, _evidence):
    return {"schema_version": 1, "coverage_status": "partial", "supported_claims": ["claim-1"],
            "unsupported_questions": ["B"], "conflicts": [], "allowed_evidence_ids": ["evidence-1"]}


def _write(_question, _review, _evidence, _audit=None):
    return {"schema_version": 1, "answer": "A has direct evidence.", "coverage_status": "partial",
            "unresolved_questions": ["B"],
            "claim_evidence_map": [{"claim_id": "claim-1", "evidence_ids": ["evidence-1"]}]}


def _audit(draft, _review):
    return {"schema_version": 1, "status": "passed", "rejected_claim_ids": [],
            "claim_results": [{"claim_id": item["claim_id"], "evidence_ids": item["evidence_ids"], "status": "supported"}
                              for item in draft["claim_evidence_map"]]}


def test_runtime_returns_safe_partial_answer_and_deterministic_references(tmp_path):
    result = execute_multi_agent_literature(
        task_id="task-001", question="Compare A and B", state_path=str(tmp_path / "workflow.sqlite3"),
        roles=LiteratureRoles(_plan, _retrieve, _review, _write, _audit),
    )
    assert result["success"] is True
    assert result["completion_status"] == "partial"
    assert "证据覆盖不完整" in result["final_answer"]
    assert "未解决：" in result["final_answer"]
    assert "[1] Paper A (arxiv:2401.00001)" in result["final_answer"]
    assert result["workflow_summary"]["model_calls_used"] == 4
