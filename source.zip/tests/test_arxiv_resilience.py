import os
import sys
import tempfile
import unittest
from pathlib import Path
from contextlib import closing
from unittest.mock import patch

import requests

# mcp_tools imports normalizer, whose top-level ``from config.logging_config
# import ...`` resolves against the deepdiver_v2 directory itself. Both the
# repo root and deepdiver_v2 must be on sys.path for the suite to run without
# an external PYTHONPATH (see tools/run_tests.cmd).
_ROOT = Path(__file__).resolve().parents[1]
for _entry in (str(_ROOT), str(_ROOT / "deepdiver_v2")):
    if _entry not in sys.path:
        sys.path.insert(0, _entry)

from deepdiver_v2.src.tools import mcp_tools as mcp_tools_module  # noqa: E402
from deepdiver_v2.src.tools.mcp_tools import MCPTools, MCPToolResult  # noqa: E402


ATOM_FEED = b"""<?xml version="1.0" encoding="UTF-8"?>
<feed xmlns="http://www.w3.org/2005/Atom">
  <entry>
    <id>https://arxiv.org/abs/2401.00001v1</id>
    <updated>2024-01-01T00:00:00Z</updated>
    <published>2024-01-01T00:00:00Z</published>
    <title>World Models for Physical Dynamics</title>
    <summary>We study learned physical dynamics in world models.</summary>
    <author><name>Test Author</name></author>
    <link href="https://arxiv.org/pdf/2401.00001v1" type="application/pdf"/>
    <category term="cs.AI"/>
  </entry>
</feed>"""


class _Response:
    def __init__(self, status_code, content=b""):
        self.status_code = status_code
        self.content = content
        self.headers = {}

    def raise_for_status(self):
        if self.status_code >= 400:
            raise requests.HTTPError(f"HTTP {self.status_code}", response=self)


class _Session:
    def __init__(self, status_code=200):
        self.urls = []
        self.requests = []
        self.status_code = status_code

    def get(self, url, **kwargs):
        self.urls.append(url)
        self.requests.append(kwargs)
        return _Response(self.status_code, ATOM_FEED if self.status_code == 200 else b"")


class _FailingSession:
    def get(self, *_args, **_kwargs):
        raise requests.ConnectionError("proxy-pass-canary C:\\private\\network.txt")


class ArxivResilienceTests(unittest.TestCase):
    def test_redirect_alias_is_not_retried_after_primary_429(self):
        tools = MCPTools.__new__(MCPTools)
        tools.session = _Session(429)
        with patch.object(tools, "_reserve_arxiv_request", return_value=(True, 0.0)), patch.dict(
            os.environ, {"ARXIV_MAX_QUERY_VARIANTS": "1"}
        ):
            result = tools.arxiv_search("world models physical dynamics", max_results=5)

        self.assertFalse(result.success)
        self.assertEqual(tools.session.urls, ["https://export.arxiv.org/api/query"])

    def test_successful_query_uses_one_official_endpoint(self):
        tools = MCPTools.__new__(MCPTools)
        tools.session = _Session(200)
        with patch.object(tools, "_reserve_arxiv_request", return_value=(True, 0.0)), patch.dict(
            os.environ, {"ARXIV_MAX_QUERY_VARIANTS": "1"}
        ):
            result = tools.arxiv_search("world models physical dynamics", max_results=5)

        self.assertTrue(result.success)
        self.assertEqual(len(result.data["papers"]), 1)
        self.assertEqual(tools.session.urls, ["https://export.arxiv.org/api/query"])
        self.assertFalse(tools.session.requests[0]["allow_redirects"])

    def test_metadata_redirect_is_refused_without_following_target(self):
        tools = MCPTools.__new__(MCPTools)
        tools.session = _Session(302)
        with patch.object(tools, "_reserve_arxiv_request", return_value=(True, 0.0)), patch.dict(
            os.environ, {"ARXIV_MAX_QUERY_VARIANTS": "1"}
        ):
            result = tools.arxiv_search("world models physical dynamics", max_results=5)

        self.assertFalse(result.success)
        self.assertEqual(tools.session.urls, ["https://export.arxiv.org/api/query"])
        self.assertFalse(tools.session.requests[0]["allow_redirects"])
        self.assertIn("request failed", " ".join(result.metadata["warnings"]))

    def test_transport_failure_does_not_reflect_exception_text(self):
        tools = MCPTools.__new__(MCPTools)
        tools.session = _FailingSession()
        with patch.object(tools, "_reserve_arxiv_request", return_value=(True, 0.0)), \
             patch.object(tools, "_start_arxiv_network_cooldown", return_value=3.0), \
             patch.dict(os.environ, {"ARXIV_MAX_QUERY_VARIANTS": "1"}):
            result = tools.arxiv_search("world models physical dynamics", max_results=5)

        warnings = " ".join(result.metadata["warnings"])
        self.assertFalse(result.success)
        self.assertIn("network unavailable", warnings)
        self.assertNotIn("proxy-pass-canary", warnings)
        self.assertNotIn("private\\network.txt", warnings)

    def test_request_schedule_is_persisted_outside_the_process(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(
            mcp_tools_module, "_ARXIV_STATE_DB", Path(directory) / "state.sqlite3"
        ), patch.dict(os.environ, {"ARXIV_MIN_REQUEST_INTERVAL": "3"}), patch.object(
            mcp_tools_module.time, "sleep"
        ) as sleep:
            self.assertEqual(MCPTools._reserve_arxiv_request(), (True, 0.0))
            self.assertEqual(MCPTools._reserve_arxiv_request(), (True, 0.0))
            self.assertTrue(sleep.called)
            self.assertGreater(sleep.call_args.args[0], 0)

    def test_pdf_pacing_deadline_rejects_without_reserving_another_slot(self):
        import sqlite3
        with tempfile.TemporaryDirectory() as directory, patch.object(
            mcp_tools_module, "_ARXIV_STATE_DB", Path(directory) / "state.sqlite3"
        ), patch.dict(os.environ, {"ARXIV_MIN_REQUEST_INTERVAL": "10"}):
            MCPTools._reserve_arxiv_request()
            with closing(sqlite3.connect(str(mcp_tools_module._ARXIV_STATE_DB))) as connection:
                before = connection.execute("SELECT next_request_at FROM arxiv_state").fetchone()[0]
            with self.assertRaises(TimeoutError):
                MCPTools._reserve_arxiv_request(max_wait_seconds=0.1)
            with closing(sqlite3.connect(str(mcp_tools_module._ARXIV_STATE_DB))) as connection:
                after = connection.execute("SELECT next_request_at FROM arxiv_state").fetchone()[0]
            self.assertEqual(before, after)


class _EmptySearchTools:
    def __init__(self):
        self.calls = []

    def arxiv_search(self, query, max_results=5):
        self.calls.append((query, max_results))
        return MCPToolResult(success=True, data={"papers": []}, metadata={})


def _hermetic(source, query, limit=5):
    """Stand-in for literature_sources.search_source: no network, no records.

    Without this patch the multi-source loop reaches Zenodo, TechRxiv and HAL
    for real, which made this module depend on the network and take about a
    minute to run.
    """
    return {"source": source, "status": "ok", "http_status": 200,
            "elapsed_ms": 0, "retry_count": 0, "retry_count_is_exact": True,
            "error": None, "disabled_reason": None, "disabled_at": None,
            "papers": []}


class LiteratureBatchLimitTests(unittest.TestCase):
    """Contract for the multi-source search budget.

    The budget has three separate limits, and the paper cap is what ends a
    search early in practice: four sources returning three papers each reach
    fifteen within two rounds. These tests pin each limit so the two magic
    numbers that used to live in the caller cannot drift apart again.
    """

    BROAD_QUERY = (
        "Compare several general machine learning architectures, mechanisms, "
        "limitations, training methods, evaluations, robustness, deployment "
        "costs, and empirical evidence across multiple tasks."
    )
    NARROW_QUERY = "What are the optimization tradeoffs of state space models?"

    def _run(self, query):
        from deepdiver_v2.cli import demo
        from deepdiver_v2.cli.demo import _search_relevant_literature

        tools = _EmptySearchTools()
        original = demo.search_source
        demo.search_source = _hermetic
        try:
            _, diagnostics, _ = _search_relevant_literature(query, "arxiv", tools, config=None)
        finally:
            demo.search_source = original
        return tools, diagnostics

    def test_every_arxiv_batch_requests_the_per_round_cap(self):
        from deepdiver_v2.src.query_router import MAX_RESULTS_PER_ROUND

        tools, _ = self._run(self.BROAD_QUERY)
        self.assertTrue(tools.calls, "the search should have issued at least one arxiv batch")
        self.assertTrue(all(cap == MAX_RESULTS_PER_ROUND for _, cap in tools.calls))

    def test_rounds_never_exceed_the_configured_round_limit(self):
        from deepdiver_v2.src.query_router import LITERATURE_MAX_ROUNDS

        tools, diagnostics = self._run(self.BROAD_QUERY)
        # One arxiv batch per round, so the call count is the round count.
        self.assertLessEqual(len(tools.calls), LITERATURE_MAX_ROUNDS)
        # round_stats holds one entry per (round, source).
        self.assertLessEqual(diagnostics["search_rounds"], LITERATURE_MAX_ROUNDS * 4)

    def test_broad_question_may_use_more_query_routes_than_a_narrow_one(self):
        from deepdiver_v2.src.query_router import (
            LITERATURE_BROAD_MAX_QUERIES,
            LITERATURE_MAX_ROUNDS,
            MAX_SEARCH_ROUNDS,
        )

        broad_tools, broad_diag = self._run(self.BROAD_QUERY)
        narrow_tools, narrow_diag = self._run(self.NARROW_QUERY)

        self.assertGreaterEqual(LITERATURE_BROAD_MAX_QUERIES, MAX_SEARCH_ROUNDS)
        # The broad question is long enough to qualify for the wider budget.
        self.assertTrue(broad_diag["broad_evidence_request"])
        self.assertFalse(narrow_diag["broad_evidence_request"])
        self.assertLessEqual(len(broad_tools.calls), LITERATURE_MAX_ROUNDS)
        self.assertLessEqual(len(narrow_tools.calls), LITERATURE_MAX_ROUNDS)

    def test_candidate_pool_cap_is_a_configured_value(self):
        from deepdiver_v2.src.query_router import LITERATURE_MAX_CANDIDATE_PAPERS

        # Guards the two magic numbers that used to be a bare 15 and a bare
        # range(1, 6) in the caller.
        self.assertGreater(LITERATURE_MAX_CANDIDATE_PAPERS, 0)


if __name__ == "__main__":
    unittest.main()
