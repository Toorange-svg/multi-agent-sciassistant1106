import sys
import unittest
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch

import requests

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from deepdiver_v2.src import literature_sources as ls  # noqa: E402


class Response:
    def __init__(self, status, headers=None, content=b"ok"):
        self.status_code = status
        self.headers = headers or {}
        self.content = content

    def raise_for_status(self):
        if self.status_code >= 400:
            raise requests.HTTPError(f"HTTP {self.status_code}", response=self)


class LiteratureRetryTests(unittest.TestCase):
    def setUp(self):
        self.responses = []

        class Connection:
            def execute(self, *_args, **_kwargs):
                return None

            def commit(self):
                return None

        connection = Connection()

        @contextmanager
        def slot(_source):
            yield connection

        self.slot = slot

    def test_429_retry_after_is_honored_without_double_sleep(self):
        self.responses = [Response(429, {"Retry-After": "7"}), Response(200)]

        def get(*_args, **_kwargs):
            return self.responses.pop(0)

        with patch.object(ls, "_source_slot", self.slot), patch.object(ls, "record_source_success"), \
             patch.object(ls.time, "sleep") as sleep, patch.object(ls.requests, "get", side_effect=get):
            response = ls._request("arxiv", "https://example.test", timeout=1)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response._sci_attempts, 2)
        # The cooldown slot carries Retry-After; _request must not sleep a
        # second time and thereby double the server's requested delay.
        sleep.assert_not_called()

    def test_server_error_uses_exponential_backoff(self):
        self.responses = [Response(503), Response(503), Response(200)]

        def get(*_args, **_kwargs):
            return self.responses.pop(0)

        with patch.object(ls, "_source_slot", self.slot), patch.object(ls, "record_source_success"), \
             patch.object(ls.time, "sleep") as sleep, patch.object(ls.requests, "get", side_effect=get):
            response = ls._request("hal", "https://example.test", timeout=1)

        self.assertEqual(response._sci_attempts, 3)
        self.assertEqual([call.args[0] for call in sleep.call_args_list], [5.0, 10.0])

    def test_transport_failure_reports_exact_attempt_on_exception(self):
        error = requests.ConnectionError("offline")
        with patch.object(ls, "_source_slot", self.slot), patch.object(ls.time, "sleep"), \
             patch.object(ls.requests, "get", side_effect=error):
            with self.assertRaises(requests.ConnectionError) as raised:
                ls._request("zenodo", "https://example.test", timeout=1)
        self.assertEqual(raised.exception._sci_attempts, 3)

    def test_arxiv_redirect_is_not_followed_or_recorded_as_success(self):
        response = Response(302, {"Location": "https://unexpected.example/"})
        with patch.object(ls, "_source_slot", self.slot), patch.object(ls, "record_source_success") as success, \
             patch.object(ls.requests, "get", return_value=response) as get:
            with self.assertRaisesRegex(requests.HTTPError, "arXiv redirect refused"):
                ls._request("arxiv", "https://export.arxiv.org/api/query", timeout=1)

        self.assertFalse(get.call_args.kwargs["allow_redirects"])
        success.assert_not_called()


if __name__ == "__main__":
    unittest.main()
