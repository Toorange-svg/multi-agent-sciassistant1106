"""Collection-time test isolation must never overwrite live ownership bindings."""
import json
import os
from pathlib import Path
import subprocess
import sys

import app as account


def test_owner_stores_are_isolated_before_account_import():
    state_root = Path(os.environ["SCIASSISTANT_TASK_STATE_DIR"]).parent.resolve()
    for path in (account.SCIENCE_TASK_OWNER_STATE_PATH, account.CONTEXT_FILE_OWNER_STATE_PATH):
        assert path.resolve().parent == state_root
        assert not path.resolve().is_relative_to(account.LOG_DIR.resolve())


def test_nested_pytest_preserves_supplied_owner_and_active_task_sentinels(tmp_path):
    """Run the formerly destructive real test with caller paths set to sentinels."""
    tasks = tmp_path / "caller-tasks"
    tasks.mkdir()
    paths = {
        "SCIASSISTANT_TASK_OWNER_STATE_PATH": tmp_path / "caller-owners.json",
        "SCIASSISTANT_CONTEXT_FILE_OWNER_STATE_PATH": tmp_path / "caller-context-owners.json",
        "SCIASSISTANT_TASK_STATE_DIR": tasks,
    }
    snapshots = {
        paths["SCIASSISTANT_TASK_OWNER_STATE_PATH"]: {"real-task": "real-owner"},
        paths["SCIASSISTANT_CONTEXT_FILE_OWNER_STATE_PATH"]: {"real-file": "real-owner"},
        tasks / "active-task.json": {"id": "active-task", "status": "running"},
    }
    for path, payload in snapshots.items():
        path.write_text(json.dumps(payload), encoding="utf-8")
    before = {path: path.read_bytes() for path in snapshots}
    env = os.environ.copy()
    env.update({key: str(path) for key, path in paths.items()})
    env["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
    result = subprocess.run(
        [sys.executable, "-m", "pytest", "tests/test_science_evidence_proxy.py::ScienceEvidenceProxyTests::test_task_creation_binds_returned_task_id_to_jwt_owner", "-q"],
        cwd=account.BASE_DIR, env=env, capture_output=True, text=True,
        encoding="utf-8", errors="replace", timeout=40,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    assert "1 passed" in result.stdout
    assert {path: path.read_bytes() for path in snapshots} == before


def test_original_unisolated_fixture_reproduces_loss_only_in_sandbox(tmp_path):
    # Demonstrate the pre-fix side effect without touching a live owner file.
    owners = tmp_path / "sandbox-owners.json"
    owners.write_text(json.dumps({"real-task": "real-owner"}), encoding="utf-8")
    env = os.environ.copy()
    env["SCIASSISTANT_TASK_OWNER_STATE_PATH"] = str(owners)
    env["SCIASSISTANT_TASK_STATE_DIR"] = str(tmp_path / "sandbox-state")
    script = '''
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path.cwd() / "tests"))
from test_science_evidence_proxy import ScienceEvidenceProxyTests
import app as account
case = ScienceEvidenceProxyTests("test_task_creation_binds_returned_task_id_to_jwt_owner")
case.setUp()
try:
    # Reproduce the historical fixture by removing only its new write-path guard;
    # the target is explicitly this sandbox sentinel, never a live state file.
    account.SCIENCE_TASK_OWNER_STATE_PATH = Path(sys.argv[1])
    case.test_task_creation_binds_returned_task_id_to_jwt_owner()
finally:
    case.tearDown()
print(json.dumps(json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))))
'''
    result = subprocess.run([sys.executable, "-c", script, str(owners)], cwd=account.BASE_DIR,
        env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=40)
    assert result.returncode == 0, result.stderr
    overwritten = json.loads(result.stdout.strip().splitlines()[-1])
    assert overwritten == {"evidence-proxy": "owner-1", "new-task": "owner-1"}
