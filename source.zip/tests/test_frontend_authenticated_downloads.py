"""Regression checks for authenticated browser download entry points."""
from pathlib import Path
from unittest import TestCase


HTML_PATH = Path(__file__).resolve().parents[1] / "chatAi" / "ai_chat.html"


class FrontendAuthenticatedDownloadTests(TestCase):
    @classmethod
    def setUpClass(cls):
        cls.html = HTML_PATH.read_text(encoding="utf-8")

    def test_library_download_uses_authenticated_blob_request_not_token_url(self):
        start = self.html.index("async function downloadFile(fileId)")
        section = self.html[start : start + 800]
        self.assertIn("await downloadAuthenticatedFile(downloadUrl", section)
        self.assertIn("encodeURIComponent(fileId)", section)
        self.assertNotIn("?token=", section)
        self.assertNotIn("window.location.href = downloadUrl", section)

    def test_context_download_links_use_authenticated_blob_request(self):
        start = self.html.index("function renderSnippetList()")
        section = self.html[start : start + 5000]
        self.assertIn('list.addEventListener(\'click\'', self.html)
        self.assertIn('a[data-authenticated-context-download="true"]', self.html)
        self.assertIn("link.getAttribute('href')", self.html)
        self.assertEqual(section.count("authenticatedContextDownload = 'true'"), 2)
        self.assertNotIn("method: 'HEAD'", section)


if __name__ == "__main__":
    import unittest

    unittest.main()
