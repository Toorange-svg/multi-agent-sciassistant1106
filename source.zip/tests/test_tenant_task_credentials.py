import json
from pathlib import Path
from types import SimpleNamespace

import pytest
from flask import g

import app as account
import web_app as web
from user_credentials import CredentialStore, ProviderCapability, current_capability, provider_value, provider_scope


@pytest.fixture
def setup(tmp_path, monkeypatch):
    store=CredentialStore(tmp_path/'keys.sqlite3','test-owner-encryption-secret-123')
    owner=['a']
    def auth(): g.current_user_id=owner[0];return None
    monkeypatch.setattr(account,'_authenticate_current_request',auth)
    monkeypatch.setattr(account,'_provider_store',lambda:store)
    monkeypatch.setattr(account,'_LOCAL_SCIENCE_APP',web.app)
    monkeypatch.setattr(account,'_SCIENCE_TASK_OWNERS',{})
    monkeypatch.setattr(account,'SCIENCE_TASK_OWNER_STATE_PATH',tmp_path/'owners.json')
    monkeypatch.setattr(web,'TASK_STATE_DIR',tmp_path/'tasks')
    monkeypatch.setattr(web,'TASKS',{})
    monkeypatch.setattr(web,'_TASK_CREDENTIALS',{})
    monkeypatch.setenv('SCIASSISTANT_WEB_BASE','')
    monkeypatch.setenv('MODEL_REQUEST_URL','https://model.invalid/v1/chat/completions')
    monkeypatch.setenv('MODEL_NAME','test-model')
    monkeypatch.setenv('MODEL_REQUEST_TOKEN','forbidden-shared-key')
    monkeypatch.setenv('MODEL_REQUEST_TOKENS','forbidden-backup-key')
    monkeypatch.setenv('LLAMA_CLOUD_API_KEY','forbidden-shared-llama')
    return account.app.test_client(),store,owner,tmp_path


def test_unconfigured_registered_user_fails_before_task_not_borrowing_server(setup):
    client,store,owner,path=setup
    result=client.post('/api/science/tasks',json={'query':'你好','processing_mode':'general_answer'})
    assert result.status_code==400 and result.json['error_code']=='USER_PROVIDER_KEY_REQUIRED'
    assert not web.TASKS and not list((path/'tasks').glob('*.json'))
    assert not store.status(store.capability(owner[0]))['deepseek']['configured']


@pytest.mark.parametrize('mode',['literature_answer','multi_agent_literature','arxiv_paper'])
def test_shared_mcp_legacy_modes_cannot_bypass_tenant_keys(setup, mode):
    client,store,owner,path=setup
    store.update(owner[0],{'deepseek_keys':['own-key-not-mcp-key']})
    result=client.post('/api/science/tasks',json={'query':'论文问题','processing_mode':mode})
    assert result.status_code==410 and result.json['error']=='LEGACY_MODE_NOT_USER_ISOLATED'
    assert not web.TASKS
    account._SCIENCE_TASK_OWNERS['legacy-pending']='a'
    assert client.post('/api/science/tasks/legacy-pending/clarify',json={'choice':'custom','custom_scope':'resumed'}).status_code==410
    owner[0]='b'
    assert client.post('/api/science/tasks/legacy-pending/clarify',json={'choice':'custom','custom_scope':'resumed'}).status_code==404
    assert not web.TASKS and not web._TASK_CREDENTIALS


def test_two_created_tasks_snapshot_and_actual_worker_have_own_private_capabilities(setup,monkeypatch):
    client,store,owner,path=setup
    jobs=[]
    def start(task_id,worker,*args,stage): jobs.append((task_id,worker,args,stage));return True
    monkeypatch.setattr(web,'_start_background_task',start)
    ids=[]
    for who in ['a','b']:
        owner[0]=who
        store.update(who,{'deepseek_keys':['model-key-for-'+who],'llama_key':'llama-key-for-'+who})
        result=client.post('/api/science/tasks',json={'query':'你好','processing_mode':'general_answer','credential_user':'7','MODEL_REQUEST_TOKEN':'spoofed-key'})
        assert result.status_code==202
        task=result.json['task'];ids.append(task['id'])
        assert task['user_id']==who
        snapshot=(path/'tasks'/f"{task['id']}.json").read_text(encoding='utf8')
        assert 'model-key-for-' not in snapshot and 'llama-key-for-' not in snapshot and 'spoofed-key' not in snapshot
        def worker(task_id):
            assert current_capability().owner==who
            assert provider_value('MODEL_REQUEST_TOKEN')=='model-key-for-'+who
            from deepdiver_v2.config.config import get_config
            assert get_config().llama_cloud_api_key=='llama-key-for-'+who
            web._update(task_id,status='completed')
        web._execute_background_task(task['id'],worker,(task['id'],),'test')
        assert task['id'] not in web._TASK_CREDENTIALS
        assert current_capability() is None
    assert len(set(ids))==2


def test_caller_body_and_headers_cannot_make_capability(setup):
    client,store,owner,path=setup
    result=client.post('/api/science/tasks',json={'query':'你好','processing_mode':'general_answer','provider_credentials':{'owner':'7','MODEL_REQUEST_TOKEN':'spoofed-key'}},
        headers={'X-Provider-Owner':'7','X-Provider-Key':'spoofed-key'})
    assert result.status_code==400 and not web.TASKS
    with web.app.test_client() as direct:
        result=direct.post('/api/tasks',json={'query':'你好','processing_mode':'general_answer'},environ_overrides={'sciassistant.provider_credentials':{'owner':'7'}})
        assert result.status_code==403


def test_general_mode_academic_question_never_dispatches_shared_mcp(setup,monkeypatch):
    client,store,owner,path=setup
    store.update('a',{'deepseek_keys':['own-direct-model-key']})
    jobs=[]
    monkeypatch.setattr(web,'_start_background_task',lambda task_id,worker,*args,**kwargs:jobs.append(worker) or True)
    def forbidden(*args,**kwargs):
        raise AssertionError('shared research dispatch is forbidden')
    monkeypatch.setattr(web,'_enqueue_retrieval_task',forbidden)
    result=client.post('/api/science/tasks',json={'query':'比较Transformer和RNN的注意力机制研究进展','processing_mode':'general_answer'})
    assert result.status_code==202
    assert jobs==[web._run_general_chat_task]


@pytest.mark.parametrize('lost_cap', [None, ProviderCapability('b', {'MODEL_REQUEST_TOKEN':'wrong-owner-key'})])
def test_lost_or_wrong_queued_capability_never_runs_with_shared_credentials(setup,monkeypatch,lost_cap):
    client,store,owner,path=setup
    task_id='aaaaaaaaaaaa'
    web.TASKS[task_id]={'id':task_id,'user_id':'a','status':'cancelled'}
    if lost_cap is not None:
        web._TASK_CREDENTIALS[task_id]=lost_cap
    with pytest.raises(ValueError,match='TASK_PROVIDER_SCOPE_UNAVAILABLE'):
        web._worker_provider_capability(task_id)
    called=[]
    monkeypatch.setattr(web,'_fail_task_safely',lambda *args,**kwargs:None)
    web._execute_background_task(task_id,lambda:called.append(True),(),'test')
    assert called==[]
    assert current_capability() is None


def test_legacy_cache_listing_never_exposes_global_or_other_owner(setup, monkeypatch):
    client,store,owner,path=setup
    monkeypatch.setenv('SCIASSISTANT_WORKSPACE',str(path/'workspace'))
    for sub in ['literature/shared','users/a/literature/owner-a','users/b/literature/owner-b']:
        folder=path/'workspace'/sub;folder.mkdir(parents=True);(folder/'source.pdf').write_bytes(b'%PDF-1.4 fake')
    for who in ['a','b']:
        owner[0]=who
        result=client.get('/api/literature/papers')
        assert result.status_code==200 and [x['id'] for x in result.json['papers']]==['owner-'+who]
        assert client.delete('/api/literature/papers/owner-'+('b' if who=='a' else 'a')).status_code==404
    assert (path/'workspace/literature/shared/source.pdf').is_file()


def test_scoped_model_rotation_and_parse_cache_paths(tmp_path):
    from multi_agent_web import command,environment
    from pdf_pipeline import _pdf_parse_cache_path
    source=tmp_path/'source.pdf';source.write_bytes(b'%PDF test')
    with provider_scope(ProviderCapability('alice',{})):
        args=command('aaaaaaaaaaaa',tmp_path/'q.txt')
        assert '/users/alice' in args[args.index('--storage-root')+1].replace('\\','/')
        assert '/users/alice' in environment()['SCIASSISTANT_QDRANT_PATH'].replace('\\','/')
        assert '/users/alice' in str(_pdf_parse_cache_path(source,False)).replace('\\','/')
