"""Half-open recovery tests for disabled literature sources (A3).

A source disabled by repeated access blocks must come back on its own: after
a persisted cooldown the round's real query acts as the single probe, a
parseable response restores it fully, and a refused probe doubles the wait
without feeding the consecutive-block counter.
"""
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

import requests

from deepdiver_v2.src import literature_sources as ls


class HalfOpenTestBase(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self._old_state_db = ls.STATE_DB
        self._old_base = ls.HALF_OPEN_COOLDOWN_SECONDS
        self._old_cap = ls.HALF_OPEN_COOLDOWN_CAP
        ls.STATE_DB = Path(tmp.name) / "source_state.sqlite3"
        ls.HALF_OPEN_COOLDOWN_SECONDS = 100.0
        ls.HALF_OPEN_COOLDOWN_CAP = 1e12
        # These tests exercise the generic half-open machinery and use techrxiv
        # only as a sample source while mocking its adapter. The deployment
        # parks techrxiv statically; lift that for the duration of the test.
        self._static_patch = patch.object(ls, "STATIC_DISABLED_SOURCES", ())
        self._static_patch.start()
        self.addCleanup(self._restore)

    def _restore(self):
        ls.STATE_DB = self._old_state_db
        ls.HALF_OPEN_COOLDOWN_SECONDS = self._old_base
        ls.HALF_OPEN_COOLDOWN_CAP = self._old_cap
        self._static_patch.stop()

    def _ensure_row(self, source="techrxiv"):
        # In production the row is created by _source_slot before any request;
        # tests bypass the slot, so create it the same way.
        connection = ls._state_connection()
        try:
            connection.execute("INSERT OR IGNORE INTO source_state(source) VALUES (?)", (source,))
            connection.commit()
        finally:
            connection.close()

    def _disable_techrxiv(self):
        """Run the real disable path: three consecutive access blocks."""
        self._ensure_row()
        for _ in range(ls.ACCESS_BLOCK_THRESHOLD):
            ls.record_source_block("techrxiv")
        state = self._read_state()
        self.assertEqual(int(state["disabled"]), 1)

    def _read_state(self):
        connection = ls._state_connection()
        try:
            row = connection.execute(
                "SELECT disabled, consecutive_blocked, half_open_failures, "
                "cooldown_until, probe_claim_until FROM source_state WHERE source=?",
                ("techrxiv",),
            ).fetchone()
        finally:
            connection.close()
        keys = ("disabled", "consecutive_blocked", "half_open_failures",
                "cooldown_until", "probe_claim_until")
        return dict(zip(keys, row))

    def _set_state(self, **columns):
        sets = ", ".join(f"{name}=?" for name in columns)
        connection = ls._state_connection()
        try:
            connection.execute(
                f"UPDATE source_state SET {sets} WHERE source=?",
                (*columns.values(), "techrxiv"),
            )
            connection.commit()
        finally:
            connection.close()


class HalfOpenSkipTests(HalfOpenTestBase):
    def test_disabled_source_skips_while_cooling_down(self):
        self._disable_techrxiv()
        with patch.object(ls, "_techrxiv") as adapter:
            result = ls.search_source("techrxiv", "retrieval augmented generation", limit=3)
        adapter.assert_not_called()
        self.assertEqual(result["status"], "disabled")
        self.assertEqual(result["failure_status"], "access_blocked")
        self.assertEqual(result["half_open"], "cooldown_skip")
        self.assertIn("冷却", result["error"])
        self.assertIn("跳过", result["error"])

    def test_notice_reports_automatic_retry_plan(self):
        self._disable_techrxiv()
        notice = ls.disabled_source_notice("techrxiv")
        self.assertIn("自动", notice)
        self.assertIn("冷却", notice)
        self.assertIn("enable_source", notice)


class HalfOpenProbeTests(HalfOpenTestBase):
    def test_expired_cooldown_probes_real_query_and_recovers(self):
        self._disable_techrxiv()
        self._set_state(cooldown_until=0)
        with patch.object(ls, "_techrxiv", return_value=[]) as adapter:
            result = ls.search_source("techrxiv", "retrieval augmented generation", limit=3)
        # The probe is the round's real query — the adapter was called once
        # with it, no dedicated probe request exists.
        adapter.assert_called_once()
        self.assertEqual(result["status"], "ok")
        self.assertEqual(result["papers"], [])
        self.assertEqual(result["half_open"], "recovered")
        state = self._read_state()
        self.assertEqual(int(state["disabled"]), 0)
        self.assertEqual(int(state["consecutive_blocked"]), 0)
        self.assertEqual(int(state["half_open_failures"]), 0)
        self.assertEqual(float(state["cooldown_until"]), 0.0)

    def test_refused_probe_backs_off_without_counting_blocks(self):
        self._disable_techrxiv()
        self._set_state(cooldown_until=0)
        blocking = ls.ACCESS_BLOCK_THRESHOLD

        def refuse(query, limit):
            raise requests.HTTPError("403 Client Error", response=_FakeResponse(403))

        with patch.object(ls, "_techrxiv", side_effect=refuse):
            result = ls.search_source("techrxiv", "retrieval augmented generation", limit=3)
        self.assertEqual(result["status"], "access_blocked")
        self.assertEqual(result["half_open"], "probe_failed")
        self.assertIn("半开探测仍被拒", result["error"])
        # First refusal doubles the base: 100 * 2**1 = 200.
        self.assertEqual(result["half_open_retry_in_seconds"], 200)
        state = self._read_state()
        self.assertEqual(int(state["disabled"]), 1)
        # The probe failure must not feed the consecutive-block counter.
        self.assertEqual(int(state["consecutive_blocked"]), blocking)
        self.assertEqual(int(state["half_open_failures"]), 1)
        self.assertGreater(float(state["cooldown_until"]), time.time() + 150)

    def test_next_cooldown_stays_in_force_until_it_expires(self):
        self._disable_techrxiv()
        self._set_state(cooldown_until=0)

        def refuse(query, limit):
            raise requests.HTTPError("403 Client Error", response=_FakeResponse(403))

        with patch.object(ls, "_techrxiv", side_effect=refuse):
            ls.search_source("techrxiv", "query", limit=3)
        with patch.object(ls, "_techrxiv") as adapter:
            result = ls.search_source("techrxiv", "query", limit=3)
        adapter.assert_not_called()
        self.assertEqual(result["half_open"], "cooldown_skip")


class HalfOpenBackoffTests(HalfOpenTestBase):
    def test_backoff_doubles_and_caps(self):
        self._ensure_row()
        delays = [ls._record_half_open_failure("techrxiv") for _ in range(3)]
        self.assertEqual(delays, [200.0, 400.0, 800.0])
        ls.HALF_OPEN_COOLDOWN_CAP = 300.0
        self.assertEqual(ls._record_half_open_failure("techrxiv"), 300.0)
        state = self._read_state()
        self.assertEqual(int(state["half_open_failures"]), 4)

    def test_successful_probe_resets_backoff(self):
        self._disable_techrxiv()
        ls._record_half_open_failure("techrxiv")
        ls._record_half_open_failure("techrxiv")
        self._set_state(cooldown_until=0)
        with patch.object(ls, "_techrxiv", return_value=[]):
            ls.search_source("techrxiv", "query", limit=3)
        self.assertEqual(int(self._read_state()["half_open_failures"]), 0)
        # A later disable starts from the base cooldown again, not from 400s.
        self._disable_techrxiv()
        remaining = ls._half_open_remaining_seconds("techrxiv")
        self.assertAlmostEqual(remaining, 100.0, delta=5.0)


class _FakeResponse:
    def __init__(self, status_code):
        self.status_code = status_code


if __name__ == "__main__":
    unittest.main()
