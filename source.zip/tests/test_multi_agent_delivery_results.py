"""Question-owned deliverables and result retrieval, never evidence approval."""
import pytest
from multi_agent_quality import requested_answer_deliverables, answer_focus_brief, answer_requirements
from multi_agent_rag import EvidenceStore, HybridRetriever, build_chunks, RagError
from multi_agent_live import effective_role_prompt


@pytest.mark.parametrize('question,kind', [
    ('最后给出有条件的选型建议。', 'conditional_recommendation'),
    ('提出一个可以证伪的实验。', 'proposed_test'),
    ('请把条件推断与本文实测分开。', 'inference_vs_measurement'),
])
def test_deliverable_is_literal_and_not_an_automatic_verdict(question, kind):
    record = requested_answer_deliverables(question)
    row = next(x for x in record['items'] if x['kind'] == kind)
    assert question[row['start']:row['end']] == row['question_quote']
    assert not record['automatic_approval']


def test_simple_question_does_not_invent_deliverables_or_groups():
    question = 'QLoRA是什么？'
    assert requested_answer_deliverables(question)['items'] == []
    plan = {'groups': [{'id': 'g1', 'question': question, 'metrics': ['definition']}]}
    brief = answer_focus_brief(answer_requirements(question), plan)
    assert brief['requested_deliverables']['items'] == []
    assert len(brief['planned_obligations']) == 1


@pytest.mark.parametrize('bad', ['position accuracy', ['foreign'], [1], [None]])
def test_result_query_must_be_valid_existing_facet(tmp_path, bad):
    with pytest.raises(RagError, match='invalid result passage query'):
        HybridRetriever(EvidenceStore(tmp_path/'e.sqlite3')).search('position',
            passage_queries=['position accuracy'], result_passage_queries=bad)


def test_observed_result_precedes_experiment_design_without_approval(tmp_path):
    store = EvidenceStore(tmp_path/'e.sqlite3')
    chunks = build_chunks('doc', 'paper', 'Position study', [
        {'text': 'Position accuracy experiments use controlled document ordering and distracting documents.', 'page': 2},
        {'text': 'We observe position accuracy decreases when relevant information is in the middle.', 'page': 5},
    ])
    store.index_document({'document_id': 'doc', 'paper_id': 'paper', 'title': 'Position study', 'content_hash': 'x'}, chunks)
    class DesignFirst:
        def rerank(self, query, values):
            return [v['chunk_id'] for v in sorted(values, key=lambda v: v['page'])]
    options = dict(limit=1, per_document=1, document_ids={'doc'},
                   representative_document_ids=['doc'], passage_queries=['position accuracy'])
    retriever = HybridRetriever(store, reranker=DesignFirst())
    baseline = retriever.search('position accuracy documents', **options)
    changed = retriever.search('position accuracy documents', result_passage_queries=['position accuracy'], **options)
    assert baseline[0]['locator']['page'] == 2
    assert changed[0]['locator']['page'] == 5
    assert changed[0]['retrieval']['result_priority_applied']
    assert 'review_status' not in changed[0]
    assert changed[0]['text'] == chunks[1]['text']


def test_inference_prompt_does_not_equate_compute_and_state_precision():
    assert 'compute dtype does NOT determine' in effective_role_prompt('writer')
    assert 'claim AND field only' in effective_role_prompt('citation_auditor')
