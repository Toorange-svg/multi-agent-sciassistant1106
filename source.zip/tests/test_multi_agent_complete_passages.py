"""Complete units of evidence, never joined under an invented source ID."""
from copy import deepcopy

import pytest

from multi_agent_rag import EvidenceStore, HybridRetriever, RagError, build_chunks
from multi_agent_live import LiveArxivRagExecutor
from multi_agent_quality import (ABSENCE_SCOPE_POLICY, CONTEXTUAL_ABSENCE_SCOPE_POLICY,
    check_audit, publication_rejections)
from test_multi_agent_absence_basis import audit, absence
from test_multi_agent_report_fields import draft, evidence


def formula_store(tmp_path, *, valid=True, page=4):
    store = EvidenceStore(tmp_path / 'e.sqlite3')
    chunks = build_chunks('doc', 'paper', 'Method', [
        {'text': 'Our method freezes the base. For h = W0x, our modified forward pass yields:',
         'page': 4, 'bbox': [1, 2, 90, 30]},
        {'text': 'h = W0x + BAx', 'page': page, 'block_type': 'formula', 'bbox': [1, 31, 90, 50]},
        {'text': 'Other experiments describe datasets and configurations.', 'page': 6}])
    if not valid:
        chunks[1]['previous_chunk_id'] = None
    store.index_document({'document_id': 'doc', 'paper_id': 'paper', 'title': 'Method', 'content_hash': 'x'}, chunks)
    return store, chunks


@pytest.mark.parametrize('query', ['modified forward yields', 'BAx'])
def test_introducer_and_formula_selected_as_separate_reviewable_sources(tmp_path, query):
    store, chunks = formula_store(tmp_path)
    before = deepcopy(chunks)
    packets = HybridRetriever(store).search(query, limit=2, per_document=2, document_ids={'doc'})
    assert [p['evidence_id'] for p in packets] == [c['chunk_id'] for c in chunks[:2]]
    assert [p['text'] for p in packets] == [c['text'] for c in chunks[:2]]
    assert packets[0]['locator']['bbox'] != packets[1]['locator']['bbox']
    assert all(p['retrieval']['continuation']['evidence_ids'] == [c['chunk_id'] for c in chunks[:2]] for p in packets)
    assert all(p['retrieval']['continuation']['requires_independent_review'] for p in packets)
    assert all('review_status' not in p for p in packets)
    assert chunks == before


@pytest.mark.parametrize('options', [{'limit': 1}, {'per_document': 1}, {'context_budget': 1}])
def test_incomplete_pair_does_not_override_quotas(tmp_path, options):
    store, chunks = formula_store(tmp_path)
    packets = HybridRetriever(store).search('modified forward yields', document_ids={'doc'}, **options)
    assert not {c['chunk_id'] for c in chunks[:2]} & {p['evidence_id'] for p in packets}


@pytest.mark.parametrize('valid,page', [(False, 4), (True, 7)])
def test_broken_or_nonadjacent_pointer_is_not_spliced(tmp_path, valid, page):
    store, _ = formula_store(tmp_path, valid=valid, page=page)
    packets = HybridRetriever(store).search('modified forward', document_ids={'doc'})
    assert not any(p['retrieval'].get('continuation') for p in packets)


def test_page_boundary_pair_keeps_distinct_page_locations(tmp_path):
    store, _ = formula_store(tmp_path, page=5)
    packets = HybridRetriever(store).search('modified forward', limit=2, document_ids={'doc'})
    assert [p['locator']['page'] for p in packets] == [4, 5]


@pytest.mark.parametrize('keep', [0, 1])
def test_top_k_reranker_cannot_detach_formula_from_introducer(tmp_path, keep):
    store, chunks = formula_store(tmp_path)
    class TopOne:
        def rerank(self, query, values):
            return [chunks[keep]['chunk_id']]
    packets = HybridRetriever(store, reranker=TopOne()).search('modified forward BAx', limit=2, document_ids={'doc'})
    assert [p['evidence_id'] for p in packets] == [c['chunk_id'] for c in chunks[:2]]


def test_foreign_document_neighbor_cannot_cross_source_scope(tmp_path, monkeypatch):
    store, chunks = formula_store(tmp_path)
    get = store.get_chunks
    def foreign(keys):
        rows = get(keys)
        for row in rows:
            if row['chunk_id'] == chunks[1]['chunk_id']:
                row['document_id'] = 'foreign'
        return rows
    monkeypatch.setattr(store, 'get_chunks', foreign)
    packets = HybridRetriever(store).search('modified forward', document_ids={'doc'})
    assert all(p['document_id'] == 'doc' and not p['retrieval'].get('continuation') for p in packets)


def test_mechanism_body_precedes_intro_for_representative(tmp_path):
    store = EvidenceStore(tmp_path / 'e.sqlite3')
    chunks = build_chunks('doc', 'paper', 'Original source', [
        {'text': 'Transformer attention introduction. A popular general architecture.', 'page': 1},
        {'text': 'Decoder attention prevents future positions by masking out illegal connections.', 'page': 5}])
    store.index_document({'document_id': 'doc', 'paper_id': 'paper', 'title': 'Original source', 'content_hash': 'x'}, chunks)
    class IntroFirst:
        def rerank(self, query, values):
            return [v['chunk_id'] for v in sorted(values, key=lambda v: v['page'])]
    options = dict(limit=1, document_ids={'doc'}, representative_document_ids=['doc'],
                   passage_queries=['decoder mask masking'])
    base = HybridRetriever(store, reranker=IntroFirst()).search('Transformer attention', **options)
    changed = HybridRetriever(store, reranker=IntroFirst()).search('Transformer attention',
        mechanism_passage_queries=options['passage_queries'], **options)
    assert base[0]['locator']['page'] == 1
    assert changed[0]['locator']['page'] == 5
    assert changed[0]['retrieval']['mechanism_passage_selected']


def test_first_requested_mechanism_is_not_displaced_by_generic_intro_match(tmp_path):
    store = EvidenceStore(tmp_path / 'e.sqlite3')
    chunks = build_chunks('doc', 'paper', 'Original source', [
        {'text': 'Encoder decoder attention is our general architecture.', 'page': 1},
        {'text': 'Decoder attention prevents future information by masking out illegal connections.', 'page': 5}])
    store.index_document({'document_id': 'doc', 'paper_id': 'paper', 'title': 'Original source', 'content_hash': 'x'}, chunks)
    class IntroFirst:
        def rerank(self, query, values): return [v['chunk_id'] for v in sorted(values, key=lambda v: v['page'])]
    facets = ['decoder mask masking', 'encoder decoder attention']
    packets = HybridRetriever(store, reranker=IntroFirst()).search('encoder decoder attention',
        limit=1, document_ids={'doc'}, representative_document_ids=['doc'],
        passage_queries=facets, mechanism_passage_queries=facets)
    assert packets[0]['locator']['page'] == 5 and packets[0]['retrieval']['mechanism_priority_applied']


@pytest.mark.parametrize('bad', ['mask', ['unknown'], [3], ['x'] * 4, None])
def test_bad_mechanism_facet_is_rejected_before_store(tmp_path, monkeypatch, bad):
    store = EvidenceStore(tmp_path / 'e.sqlite3')
    monkeypatch.setattr(store, 'lexical_search', lambda *a, **k: pytest.fail('must validate before store'))
    with pytest.raises(RagError):
        HybridRetriever(store).search('x', passage_queries=['mask'], mechanism_passage_queries=bad)


def test_public_mechanism_queries_skip_title_and_do_not_create_network_actions(tmp_path):
    observed = []
    services = HybridRetriever(EvidenceStore(tmp_path / 'e.sqlite3'))
    def search(query, **options):
        observed.append(options)
        return []
    services.search = search
    executor = LiveArxivRagExecutor(tmp_path / 'run', tmp_path / 'storage', rag_mode='lexical', services=services)
    plan = {'groups': [{'id': 'g1', 'core': ['Transformer'], 'metrics': ['mechanism'],
        'source_hints': ['Attention Is All You Need'], 'question': 'Explain mask',
        'support': ['Attention Is All You Need', 'causal mask', 'decoder self-attention', 'next token']}]}
    executor.configure_plan(plan)
    executor.group_queries = {'g1': ['original public query']}
    executor.candidates = {'1706.03762': {'paper_id': '1706.03762v7', 'title': 'Attention Is All You Need',
        'group_ids': ['g1'], 'evidence_id': 'abstract-1706-03762v7'}}
    executor.ingested = {'arxiv-1706-03762v7'}
    before = deepcopy(executor.group_queries)
    executor._select_packets()
    assert observed[0]['passage_queries'] == ['causal mask masking', 'decoder self-attention', 'next token']
    assert observed[0]['mechanism_passage_queries'] == observed[0]['passage_queries']
    assert executor.group_queries == before


@pytest.mark.parametrize('text', [
    '该证据来自相邻来源（高效注意力机制与 KV 缓存推理优化），不是 Attention Is All You Need 原文。',
    '该证据来自相邻来源（高效注意力机制与 KV 缓存推理优化），不是 Attention Is All You Need 原文。 原文适用范围：高效注意力机制与KV缓存推理优化。',
    '不是 Attention Is All You Need 原文。',
    'This evidence comes from a later source, not the original Transformer paper.'])
def test_source_identity_contrast_is_not_full_paper_omission(text):
    data = draft()
    data['absence_scope_policy'] = ABSENCE_SCOPE_POLICY
    data['claims'][0]['qualification'] = text
    checked = check_audit(absence(audit(data), text), data, evidence())
    assert not checked['absence_issues'] and not publication_rejections(checked, data)
    # Historical drafts retain their own policy, not silently reinterpreted.
    data['absence_scope_policy'] = CONTEXTUAL_ABSENCE_SCOPE_POLICY
    assert check_audit(absence(audit(data), text), data, evidence())['absence_issues']


@pytest.mark.parametrize('text', [
    '该证据来自相邻来源，不是未报告对照实验的原文。',
    '不是原文，论文未报告对照实验。', '论文没有进行验证。',
    '该证据来自其他论文，不是原文；作者没有测试。', '不是经过统一对照验证的结论。'])
def test_real_absence_or_combined_scientific_negatives_still_rejected(text):
    data = draft()
    data['absence_scope_policy'] = ABSENCE_SCOPE_POLICY
    data['claims'][0]['qualification'] = text
    checked = check_audit(absence(audit(data), text), data, evidence())
    assert checked['absence_issues'] and publication_rejections(checked, data) == {'c1'}


def test_provenance_category_cannot_override_model_rejection_or_bad_witness():
    data = draft()
    data['absence_scope_policy'] = ABSENCE_SCOPE_POLICY
    text = '不是 Attention Is All You Need 原文。'
    data['claims'][0]['qualification'] = text
    value = absence(audit(data), text)
    value['claim_results'][0]['source_witnesses'][0]['quote'] = 'This invented witness is not in the approved source.'
    assert publication_rejections(check_audit(value, data, evidence()), data) == {'c1'}
