"""A fixed 402 notice is outside scientific prose and never retries a model."""
from copy import deepcopy
import hashlib
import json

import pytest

from multi_agent_agents import ArtifactDirectory
from multi_agent_report import export_run_report
from multi_agent_status import billing_notice, describe_status, status_html, status_markdown
from multi_agent_web import exported_report


@pytest.mark.parametrize('code', [None, '', 'MODEL_HTTP_401', 'MODEL_HTTP_403',
    'MODEL_HTTP_429', 'MODEL_HTTP_502', 'SOURCE_UNREACHABLE', '正文含402', '<script>402</script>'])
def test_other_failures_and_prose_are_not_billing(code):
    assert billing_notice(code) is None
    value = describe_status('failed', failure_code=code)
    assert 'billing_notice' not in value
    assert 'billing-alert' not in status_html(value)


@pytest.mark.parametrize('status', ['failed', 'partial', 'needs_review'])
def test_billing_is_fixed_separate_copy_not_a_scientific_verdict(status):
    display = describe_status(status, failure_code='MODEL_HTTP_402')
    assert display['title'] == describe_status(status)['title']
    assert display['billing_notice']['code'] == 'MODEL_HTTP_402'
    assert '余额不足' in display['billing_notice']['title']
    assert '当前账号' in display['billing_notice']['message']
    assert '仍可能计费' in display['billing_notice']['guidance']
    assert 'role="alert"' in status_html(display)
    assert 'HTTP 402' in status_markdown(display)


def test_forged_provider_copy_cannot_become_html_or_key_output():
    display = describe_status('failed')
    display['billing_notice'] = {'code': 'MODEL_HTTP_402', 'title': '<script>raw-provider</script>',
                                'message': 'Bearer private-canary'}
    for text in (status_html(display), status_markdown(display)):
        assert 'raw-provider' not in text and 'private-canary' not in text
        assert '余额不足' in text
    display['billing_notice'] = 'invalid'
    assert 'billing-alert' not in status_html(display)


@pytest.mark.parametrize('format_name', ['html', 'md', 'json'])
@pytest.mark.parametrize('location', ['root', 'execution', 'display'])
def test_web_export_keeps_body_status_and_billing_in_sync(format_name, location):
    data = {'status': 'failed', 'direct_answer': '安全说明哨兵。', 'references': [], 'claims': []}
    if location == 'root': data['failure_code'] = 'MODEL_HTTP_402'
    elif location == 'execution': data['execution'] = {'failure_code': 'MODEL_HTTP_402'}
    else: data['status_display'] = {'billing_notice': {'code': 'MODEL_HTTP_402'}}
    before = deepcopy(data)
    text = exported_report(data, format_name)[0].decode('utf-8-sig')
    assert '余额不足' in text and '安全说明哨兵。' in text
    assert data == before
    if format_name == 'json':
        value = json.loads(text)
        assert value['status'] == 'failed' and value['direct_answer'] == data['direct_answer']
    elif format_name == 'html':
        assert 'role="alert"' in text.split('<section id="answer"')[0]
        assert '余额不足' not in text.split('<section id="answer"')[1].split('</section>')[0]
    else:
        assert '余额不足' in text.split('## 回答正文')[0]


def test_web_report_and_cli_export_show_notice_without_modifying_final(tmp_path, monkeypatch):
    import multi_agent_web as adapter
    store = ArtifactDirectory(tmp_path / 'artifacts')
    final = {'run_id': 'abcdef012345', 'status': 'failed', 'failure_code': 'MODEL_HTTP_402',
             'direct_answer': '安全说明哨兵。', 'artifact_refs': {}}
    key = store.put('final-result', final)['artifact_id']
    (tmp_path / 'manifest.json').write_text(json.dumps({'run_id': final['run_id'],
        'final_artifact_id': key}), encoding='utf-8')
    path = tmp_path / 'artifacts' / (key+'.json')
    before = hashlib.sha256(path.read_bytes()).hexdigest()
    monkeypatch.setattr(adapter, 'run_directory', lambda _: tmp_path)
    monkeypatch.setattr(adapter, 'progress', lambda _: {'failure_code': 'MODEL_HTTP_402'})
    value = adapter.report(final['run_id'])
    assert value['failure_code'] == 'MODEL_HTTP_402'
    assert value['status_display']['billing_notice']['code'] == 'MODEL_HTTP_402'
    export_run_report(tmp_path)
    assert '余额不足' in (tmp_path/'final_answer.md').read_text(encoding='utf-8-sig')
    assert 'role="alert"' in (tmp_path/'final_answer.html').read_text(encoding='utf-8')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == before


def test_direct_chat_sets_a_structured_402_without_returning_exception(monkeypatch, tmp_path):
    from types import SimpleNamespace
    import requests
    import web_app as web
    response = requests.Response(); response.status_code = 402
    error = requests.HTTPError('private-provider-canary', response=response)
    updates = []
    monkeypatch.setattr(web, '_is_task_cancel_requested', lambda _: False)
    monkeypatch.setattr(web, 'LOG_DIR', tmp_path)
    monkeypatch.setattr(web, '_update', lambda _id, **values: updates.append(values))
    monkeypatch.setattr(web, 'get_config', lambda: SimpleNamespace(model_name='fixture-model',
        get_custom_llm_config=lambda: {'url': 'https://example.invalid', 'timeout': 5}))
    monkeypatch.setattr(web, 'provider_value', lambda *_args: '')
    monkeypatch.setattr(web, 'post_model_request', lambda *_args, **_kwargs: (_ for _ in ()).throw(error))
    web._run_general_chat_task('billing-fixture', '你好')
    assert any(v.get('failure_code') == 'MODEL_HTTP_402' for v in updates)
    assert 'private-provider-canary' not in json.dumps(updates)
