"""Title priority must not overwrite a different topic query with an alias."""
from copy import deepcopy

import pytest

from multi_agent_live import ROLE_PROMPTS
from multi_agent_pipeline_v2 import query_targets_title, prioritize_source_title_actions


@pytest.mark.parametrize("query,title", [
    ('(ti:"CNN-generated images are surprisingly easy to spot" OR abs:"CNN-generated images are surprisingly easy to spot")',
     'CNN-generated images are surprisingly easy to spot... for now'),
    ('(ti:"An Image is Worth 16x16 Words" OR abs:"An Image is Worth 16x16 Words")',
     'An Image is Worth 16x16 Words: Transformers for Image Recognition at Scale'),
    ('ti:"LOW RANK ADAPTATION OF LARGE LANGUAGE MODELS"', 'Low-Rank Adaptation of Large Language Models'),
    ('ti:"Attention Is All You Need"', 'Attention Is All You Need'),
    ('ti:"Deep Learning"', 'Deep Learning'),
    ('ti:"Not All Tokens Are Equal"', 'Not All Tokens Are Equal'),
])
def test_full_title_and_distinctive_prefix_are_already_targeted(query, title):
    assert query_targets_title(query, title)


@pytest.mark.parametrize("query,title", [
    ('abs:"ViT"', 'An Image is Worth 16x16 Words: Transformers for Image Recognition at Scale'),
    ('ti:"Vision Transformer"', 'Vision Transformer for Image Forensics'),
    ('abs:"large language models"', 'Low-Rank Adaptation of Large Language Models'),
    ('ti:"An Image is Worth"', 'An Image is Worth 16x16 Words: Transformers for Image Recognition at Scale'),
    ('NOT ti:"Attention Is All You Need"', 'Attention Is All You Need'),
    ('abs:"Need You All Is Attention"', 'Attention Is All You Need'),
])
def test_short_generic_interior_or_negative_clause_is_not_title_coverage(query, title):
    assert not query_targets_title(query, title)


def test_recorded_imgdet_queries_keep_other_detector_searches():
    plan = {"groups": [
        {"id": "g1", "source_hints": ['CNN-generated images are surprisingly easy to spot... for now']},
        {"id": "g2", "source_hints": ['An Image is Worth 16x16 Words: Transformers for Image Recognition at Scale']}]}
    requests = [{"request_id": f"r{i}", "action": "request_arxiv_search", "arguments": {"group_id": group, "query": query}}
        for i, (group, query) in enumerate([
            ('g1', '(ti:"CNN-generated images are surprisingly easy to spot" OR abs:"CNN-generated images are surprisingly easy to spot")'),
            ('g2', '(ti:"An Image is Worth 16x16 Words" OR abs:"An Image is Worth 16x16 Words")'),
            ('g1', '(ti:"Detecting and Simulating Artifacts in GAN Fake Images" OR abs:"Detecting and Simulating Artifacts in GAN Fake Images")'),
            ('g2', '(ti:"Dire" OR abs:"Dire") AND (abs:"Diffusion-Generated Image Detection" OR abs:"Vision Transformer")')], 1)]
    old = deepcopy((plan, requests))
    output, changes = prioritize_source_title_actions(plan, requests, {"explicit_entities": []})
    assert output == requests and (plan, requests) == old
    assert len(output) == 4
    assert len(changes) == 2
    assert all(c["query_replaced"] is False and c["reason_code"] == "PLANNED_TITLE_FRAGMENT_ALREADY_SEARCHED" for c in changes)
    assert {c["group_id"] for c in changes} == {"g1", "g2"}


def test_negative_query_not_overridden_by_positive_source_hint():
    requests = [{"request_id": f"r{i}", "action": "request_arxiv_search", "arguments": {"group_id": "g1", "query": q}}
                for i, q in enumerate(['abs:"Transformer" NOT ti:"Attention Is All You Need"', 'abs:"mechanism"'], 1)]
    plan = {"groups": [{"id": "g1", "source_hints": ["Attention Is All You Need"]}]}
    assert prioritize_source_title_actions(plan, requests, {"explicit_entities": []}) == (requests, [])


def test_public_prompt_preserves_topic_query_with_title_clue():
    prompt = ROLE_PROMPTS["retriever"]
    assert "do NOT fill both group slots with paper titles" in prompt
    assert "DETECTION terms" in prompt and "not the same" in prompt
    assert "Do not add a third query" in prompt
