"""Conservative fast path cannot bypass PDF, privacy, or research handling."""
import pytest

from deepdiver_v2.src.query_intent import request_route
import web_app as web
import multi_agent_web as adapter
from test_multi_agent_web import isolated


@pytest.mark.parametrize('question', ['你好', '您好！', '谢谢', '你是谁', 'hello!',
    '帮我写一封请假邮件', '请写一封感谢信', '讲个笑话', '写一首诗',
    '今天广州天气怎么样', '现在几点了', '1加1等于几', '计算2*3', '3.5除以2是多少'])
def test_clear_daily_request_is_direct(question):
    result = request_route(question)
    assert result['route'] == 'direct_answer'
    assert result['classifier_model_calls'] == 0


@pytest.mark.parametrize('question', ['你好，请解释Transformer的注意力机制',
    '天气预测中Transformer模型有什么优势', '怎么预测天气', '天气预测有哪些方法',
    '讲讲笑话生成算法的研究', '请分析这篇关于天气的论文', '写一段论文实验分析',
    '什么是DETR', '那它和刚才的方法有什么区别', '为什么会这样', '再解释一下',
    '你好，KV缓存量化有什么帮助？', '比较天气预报的神经网络模型', 'research on joke generation'])
def test_research_mixed_or_uncertain_remains_research(question):
    assert request_route(question)['route'] == 'research'


@pytest.mark.parametrize('question', ['你好', '今天广州天气怎么样', '帮我写一封请假邮件'])
def test_uploaded_document_never_silently_dropped(question):
    assert request_route(question, has_upload=True)['route'] == 'research'


def test_api_direct_path_does_not_require_rag_runtime_or_retrieval(isolated, monkeypatch):
    direct = []
    def forbidden(*args, **kwargs):
        raise AssertionError('direct greeting must not use retrieval or RAG readiness')
    monkeypatch.setattr(adapter, 'readiness', forbidden)
    monkeypatch.setattr(web, '_enqueue_retrieval_task', forbidden)
    monkeypatch.setattr(web, '_missing_task_configuration', lambda _: [])
    monkeypatch.setattr(web, '_start_background_task', lambda *args, **kwargs: direct.append(args))
    response = web.app.test_client().post('/api/tasks', json={'query': '你好', 'processing_mode': adapter.MODE})
    assert response.status_code == 202
    task = response.json['task']
    assert task['processing_mode'] == 'general_answer'
    assert task['query_mode'] == 'direct_llm'
    assert task['source_scope'] is None and not task['public_search_allowed']
    assert task['request_route']['route'] == 'direct_answer'
    assert direct[0][1] is web._run_general_chat_task


def test_api_mixed_question_and_followup_keep_rag(isolated, monkeypatch):
    jobs = []
    monkeypatch.setattr(adapter, 'readiness', lambda: {'ready': True})
    monkeypatch.setattr(web, '_missing_task_configuration', lambda _: [])
    monkeypatch.setattr(web, '_enqueue_retrieval_task', lambda *args, **kwargs: jobs.append(args))
    client = web.app.test_client()
    for q in ['你好，请解释Transformer', '那它和刚才的方法有什么区别']:
        response = client.post('/api/tasks', json={'query': q, 'processing_mode': adapter.MODE})
        assert response.status_code == 202
        assert response.json['task']['processing_mode'] == adapter.MODE
    assert all(args[1] is web._run_multi_agent_rag_task for args in jobs)


def test_new_multi_agent_question_defaults_to_public_search(isolated, monkeypatch):
    monkeypatch.setattr(adapter, 'readiness', lambda: {'ready': True})
    monkeypatch.setattr(web, '_missing_task_configuration', lambda _: [])
    monkeypatch.setattr(web, '_enqueue_retrieval_task', lambda *args, **kwargs: None)
    response = web.app.test_client().post('/api/tasks', json={
        'query': '生成式 AI 与世界模型有什么关系？', 'processing_mode': adapter.MODE})
    assert response.status_code == 202
    task = response.json['task']
    assert task['source_scope'] == 'arxiv'
    assert task['source_policy'] == 'public'
    assert task['public_search_allowed'] is True


def test_greeting_does_not_bypass_invalid_source_permission(isolated, monkeypatch):
    monkeypatch.setattr(web, '_missing_task_configuration', lambda _: [])
    response = web.app.test_client().post('/api/tasks', json={
        'query': '你好', 'processing_mode': adapter.MODE, 'source_policy': 'local'})
    assert response.status_code == 400 and not web.TASKS
