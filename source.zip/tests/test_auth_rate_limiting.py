"""Authentication throttles and fail-closed password-reset boundary."""
import json
from pathlib import Path
from unittest import mock

import pymysql
import pytest

import app as gateway
from request_limits import SlidingWindowLimiter


ROOT = Path(__file__).resolve().parents[1]


class FakeClock:
    def __init__(self):
        self.now = 100.0

    def __call__(self):
        return self.now


def test_sliding_window_retry_and_expiry():
    clock = FakeClock()
    limiter = SlidingWindowLimiter(clock=clock, max_keys=10)
    assert limiter.check_and_record([("opaque-a", 2, 60)]) == (True, 0)
    clock.now += 1
    assert limiter.check_and_record([("opaque-a", 2, 60)]) == (True, 0)
    clock.now += 1
    allowed, retry = limiter.check_and_record([("opaque-a", 2, 60)])
    assert not allowed and retry == 58
    clock.now = 161
    assert limiter.check_and_record([("opaque-a", 2, 60)]) == (True, 0)


def test_multi_bucket_check_is_atomic_and_capacity_is_bounded():
    clock = FakeClock()
    limiter = SlidingWindowLimiter(clock=clock, max_keys=2)
    assert limiter.check_and_record([("identity-a", 1, 60), ("client-a", 2, 60)]) == (True, 0)
    allowed, _ = limiter.check_and_record([("identity-a", 1, 60), ("client-a", 2, 60)])
    assert not allowed
    assert limiter.safe_snapshot()["client-a"] == 1  # Rejected request records neither bucket.
    clock.now += 1
    assert limiter.check_and_record([("identity-b", 1, 60)]) == (True, 0)
    assert len(limiter.safe_snapshot()) <= 2


def test_gateway_limit_keys_are_hmac_fingerprints_not_raw_identifiers():
    key = gateway._opaque_auth_limit_key("login", "identity", "PrivateUser@Example.org")
    assert key.startswith("login:identity:") and len(key.rsplit(":", 1)[1]) == 64
    assert "privateuser" not in key.lower() and "example" not in key.lower()


def test_login_identity_limit_returns_safe_429_before_more_database_work():
    limiter = SlidingWindowLimiter(clock=FakeClock(), max_keys=100)
    policy = {"login": {"identity": 2, "client": 10, "window": 60},
              "register": gateway._AUTH_LIMITS["register"]}
    client = gateway.app.test_client()
    with mock.patch.object(gateway, "_AUTH_RATE_LIMITER", limiter), \
         mock.patch.object(gateway, "_AUTH_LIMITS", policy), \
         mock.patch.object(gateway, "get_db_connection", side_effect=pymysql.MySQLError("private-db-canary")) as database:
        first = client.post("/api/login", json={"loginId": "target-user", "password": "wrong-password"})
        second = client.post("/api/login", json={"loginId": "TARGET-USER", "password": "wrong-password"})
        blocked = client.post("/api/login", json={"loginId": "target-user", "password": "wrong-password"})
    assert first.status_code == second.status_code == 503
    assert first.get_json()["error"] == second.get_json()["error"] == "DATABASE_UNAVAILABLE"
    assert blocked.status_code == 429 and blocked.headers["Retry-After"] == "60"
    assert blocked.get_json() == {"success": False, "error": "RATE_LIMITED", "message": "请求过于频繁，请稍后重试。"}
    assert database.call_count == 2
    assert "target-user" not in json.dumps(limiter.safe_snapshot()).lower()


def test_client_bucket_cannot_be_bypassed_with_rotating_identities():
    limiter = SlidingWindowLimiter(clock=FakeClock(), max_keys=100)
    policy = {"login": {"identity": 10, "client": 2, "window": 30},
              "register": gateway._AUTH_LIMITS["register"]}
    client = gateway.app.test_client()
    with mock.patch.object(gateway, "_AUTH_RATE_LIMITER", limiter), \
         mock.patch.object(gateway, "_AUTH_LIMITS", policy), \
         mock.patch.object(gateway, "get_db_connection", side_effect=pymysql.MySQLError("offline")) as database:
        assert client.post("/api/login", json={"loginId": "user-a", "password": "wrong"}).status_code == 503
        assert client.post("/api/login", json={"loginId": "user-b", "password": "wrong"}).status_code == 503
        blocked = client.post("/api/login", json={"loginId": "user-c", "password": "wrong"})
    assert blocked.status_code == 429 and database.call_count == 2


@pytest.mark.parametrize("path,payload", [
    ("/api/verify-credentials", {"username": "known", "email": "known@example.org"}),
    ("/api/reset-password", {"userId": 1, "newPassword": "new-secret", "confirmPassword": "new-secret"}),
])
def test_insecure_self_service_password_reset_is_disabled_without_database_access(path, payload):
    with mock.patch.object(gateway, "get_db_connection") as database:
        response = gateway.app.test_client().post(path, json=payload)
    assert response.status_code == 503
    assert response.get_json()["error"] == "PASSWORD_RESET_DISABLED"
    assert "userId" not in response.get_data(as_text=True)
    assert "new-secret" not in response.get_data(as_text=True)
    database.assert_not_called()


def test_malformed_login_is_rejected_without_consuming_limiter_or_database():
    limiter = SlidingWindowLimiter(clock=FakeClock(), max_keys=100)
    with mock.patch.object(gateway, "_AUTH_RATE_LIMITER", limiter), \
         mock.patch.object(gateway, "get_db_connection") as database:
        response = gateway.app.test_client().post("/api/login", data="not-json", content_type="application/json")
    assert response.status_code == 400
    assert limiter.safe_snapshot() == {}
    database.assert_not_called()


@pytest.mark.parametrize("path,payload", [
    ("/api/login", {"loginId": [], "password": "wrong"}),
    ("/api/login", {"loginId": "user", "password": {"nested": "wrong"}}),
    ("/api/register", {"username": [], "email": "x@example.org", "password": "123456", "confirmPassword": "123456"}),
])
def test_non_string_auth_fields_fail_before_limiter_and_database(path, payload):
    limiter = SlidingWindowLimiter(clock=FakeClock(), max_keys=100)
    with mock.patch.object(gateway, "_AUTH_RATE_LIMITER", limiter), \
         mock.patch.object(gateway, "get_db_connection") as database:
        response = gateway.app.test_client().post(path, json=payload)
    assert response.status_code == 400
    assert limiter.safe_snapshot() == {}
    database.assert_not_called()


def test_frontend_exposes_no_active_user_id_reset_authority():
    login = (ROOT / "chatAi/login.html").read_text(encoding="utf-8")
    forgot = (ROOT / "chatAi/forgot-password.html").read_text(encoding="utf-8")
    assert 'href="forgot-password.html"' in login
    assert "/5000/api/password-reset/request" in forgot
    assert "/5000/api/password-reset/confirm" in forgot
    assert "/5000/api/verify-credentials" not in forgot
    assert "/5000/api/reset-password" not in forgot
    assert "userId" not in forgot
