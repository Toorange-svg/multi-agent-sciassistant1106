import unittest

from deepdiver_v2.src.query_intent import analyze_query_intent


class QueryIntentTests(unittest.TestCase):
    def test_uploaded_section_question(self):
        result = analyze_query_intent(
            '上传的 PDF 中“Segment Anything Task”主要讲了什么？',
            has_upload=True,
        )
        self.assertEqual(result['task_type'], 'section_summary')
        self.assertEqual(result['scope'], 'uploaded_pdf')
        self.assertEqual(result['target'], 'Segment Anything Task')
        self.assertIn('section_context', result['evidence_requirements'])

    def test_experimental_question_requires_exact_evidence(self):
        result = analyze_query_intent('论文在 COCO 上的实验结果和指标是多少？')
        self.assertEqual(result['task_type'], 'experimental_evidence')
        self.assertTrue(result['requires_exact_values'])
        self.assertIn('page_reference', result['evidence_requirements'])

    def test_comparison_question(self):
        result = analyze_query_intent('比较 Transformer 和 RNN 的主要差异')
        self.assertEqual(result['task_type'], 'comparison')
        self.assertIn('comparison_dimensions', result['response_structure'])


if __name__ == '__main__':
    unittest.main()
