"""Source quotation != primary method verification; no network/model calls."""
from copy import deepcopy
import pytest

from multi_agent_evidence import source_attribution_hint


@pytest.mark.parametrize("heading", ["II. RELATED WORK", "2 Related Works", "Literature Review", "相关工作"])
def test_secondary_offsets_keep_own_contribution_separate(heading):
    text = "We propose our own detector.\n" + heading + "\nOtherMethod examines spectral patterns.\nIII. METHODS\nOur model uses RGB."
    row = {"excerpt": text, "title": "A detector", "locator": {"page": 2, "bbox": [0, 1, 2, 3]}}
    before = deepcopy(row)
    hint = source_attribution_hint(row)
    assert row == before and hint["primary_method_verified"] is False
    assert hint["classification"] == "mixed_primary_unverified_and_secondary"
    assert len(hint["secondary_ranges"]) == 1
    span = hint["secondary_ranges"][0]
    secondary = text[span["start"]:span["end"]]
    assert "OtherMethod" in secondary and "We propose" not in secondary and "Our model" not in secondary


@pytest.mark.parametrize("row,kind", [
    ({"excerpt": "Unknown body", "locator": {}}, "unclassified"),
    ({"excerpt": "Our experiment", "locator": {"section": "Results"}}, "unclassified"),
    ({"excerpt": "A summary", "title": "A Survey of Detectors"}, "secondary_summary"),
    ({"excerpt": "A summary", "title": "Reviewing Algorithms"}, "unclassified"),
    ({"excerpt": "Other methods", "locator": {"section": "Related Work"}}, "secondary_summary"),
    ({"excerpt": "RELATED WORK\nOther methods", "title": "Detector"}, "secondary_summary"),
    ({"excerpt": "The related work provides background within a sentence."}, "unclassified"),
    ({"excerpt": "", "locator": {"section": "Related Work"}}, "unclassified"),
])
def test_no_heading_is_not_a_primary_method_certificate(row, kind):
    hint = source_attribution_hint(row)
    assert hint["classification"] == kind and hint["primary_method_verified"] is False
    assert hint["policy"] == "quotation_match_is_not_primary_method_verification"


def test_known_secondary_passage_is_visible_to_auditor_and_not_rewritten():
    from multi_agent_live import ROLE_PROMPTS
    from multi_agent_quality import check_audit, publication_rejections
    excerpt = "Own contribution.\nII. RELATED WORK\nOtherMethod uses frequency features."
    hint = source_attribution_hint({"excerpt": excerpt})
    assert "OtherMethod" in excerpt[hint["secondary_ranges"][0]["start"]:]
    assert "source_attribution" in ROLE_PROMPTS["writer"] and "secondary_ranges" in ROLE_PROMPTS["citation_auditor"]
    claim = {"claim_id": "c1", "text": "OtherMethod原方法已核验使用频域。", "evidence_ids": ["e1"]}
    draft = {"claims": [claim]}
    audit = {"schema_version": "sciassistant.citation-audit/v3", "status": "needs_review",
             "rejected_claim_ids": ["c1"], "issues": [{"claim_id": "c1", "reason_code": "SECONDARY_ONLY_METHOD_DETAIL"}],
             "claim_results": [{"claim_id": "c1", "evidence_ids": ["e1"], "decision": "needs_review",
                                "reason_code": "SECONDARY_ONLY_METHOD_DETAIL", "detail": "Only a secondary paraphrase was read."}]}
    assert not check_audit(audit, draft)["contract_errors"]
    assert publication_rejections(audit, draft) == {"c1"}


@pytest.mark.parametrize("abstract,survey", [("", False), ("In this Review, we analyze detectors.", True)])
def test_live_selection_annotates_original_excerpt_without_auto_approval(tmp_path, abstract, survey):
    from multi_agent_live import LiveArxivRagExecutor
    from multi_agent_rag import EvidenceStore, HybridRetriever
    row = {"evidence_id": "e1", "paper_id": "2309.06180v1", "title": "A Detector",
           "text": "Own mechanism.\nII. RELATED WORK\nSome prior method.", "locator": {"page": 2}}
    services = HybridRetriever(EvidenceStore(tmp_path / "test.sqlite3"))
    services.search = lambda *_args, **_kwargs: [deepcopy(row)]
    executor = LiveArxivRagExecutor(tmp_path / "run", tmp_path / "store", rag_mode="lexical", services=services)
    executor.group_queries = {"g1": ['ti:"Detector"']}
    executor.candidates = {"2309.06180": {"paper_id": row["paper_id"], "title": row["title"], "abstract": abstract, "group_ids": ["g1"]}}
    executor.ingested = {"arxiv-2309-06180v1"}
    packet = executor._select_packets()[0]
    assert packet["excerpt"] == row["text"] and packet["locator"] == row["locator"]
    assert packet["source_attribution"]["classification"] == ("secondary_summary" if survey else "mixed_primary_unverified_and_secondary")
    assert packet["source_attribution"]["survey_abstract_hint"] is survey
    assert "review_status" not in packet
