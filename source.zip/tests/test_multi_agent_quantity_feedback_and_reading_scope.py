"""Precise repair feedback is not semantic approval or whole-paper verification."""
from copy import deepcopy
import json

import pytest

from multi_agent_pipeline_v2 import check_draft
from multi_agent_quality import (check_claim_revision, check_reading_scope,
    READING_SCOPE_POLICY, QUANTITY_FEEDBACK_POLICY, publication_rejections)
from test_multi_agent_quantity_dimensions import fixture


def example():
    draft, evidence = fixture("自建数据集适配20%样本后约85%。")
    draft["quantity_feedback_policy"] = QUANTITY_FEEDBACK_POLICY
    draft["claims"][0]["qualification"] = "剩余80%测试。"
    evidence["evidence"][0].update(excerpt="We adapt on 20% of samples and report 85% accuracy.",
        review_status="approved", coverage_scope="selected_chunks")
    evidence["evidence"].append({"evidence_id": "p1", "review_status": "approved",
        "excerpt": "Abstract accuracy about 85% on a different experiment.", "coverage_scope": "selected_chunks"})
    return draft, evidence


def test_precise_hidden_number_feedback_without_arithmetic_or_citation_repair():
    draft, evidence = example()
    before = deepcopy((draft, evidence))
    issue = check_draft(draft, evidence)[0]
    assert issue["feedback_policy"] == QUANTITY_FEEDBACK_POLICY
    assert issue["field_errors"] == [{"field": "qualification", "unsupported_quantities": [
        {"value": "80", "unit": "%", "candidate_evidence_ids": []}]}]
    assert issue["automatic_citation_repair"] is False
    json.dumps(issue)  # Decimal objects must not leak into persisted JSON.
    assert (draft, evidence) == before


@pytest.mark.parametrize("policy", [None, "printed-quantity-field-feedback/v0"])
def test_legacy_error_payload_unchanged_without_new_opt_in(policy):
    draft, evidence = example()
    draft["quantity_feedback_policy"] = policy
    assert check_draft(draft, evidence) == [{"claim_id": "c1", "reason": "UNSUPPORTED_NUMBER"}]


def test_other_approved_page_is_a_clue_not_automatic_support():
    draft, evidence = example()
    draft["claims"][0].update(text="本页另一实验约84%。", qualification="另页85%不可直接比较。")
    evidence["evidence"][0]["excerpt"] = "This page reports 84% accuracy."
    evidence["evidence"].append({"evidence_id": "pending", "review_status": "pending", "excerpt": "85%"})
    issue = check_draft(draft, evidence)[0]
    assert issue["field_errors"][0]["unsupported_quantities"][0]["candidate_evidence_ids"] == ["p1"]
    assert draft["claims"][0]["evidence_ids"] == ["e1"]
    draft["claims"][0]["evidence_ids"].append("p1")  # Writer must actually choose/cite the source.
    assert not check_draft(draft, evidence)


def test_field_only_repair_is_valid_edit_but_still_requires_audit():
    old, evidence = example()
    feedback = {"code_issues": check_draft(old, evidence)}
    revised = deepcopy(old)
    revised["claims"][0]["qualification"] = "剩余样本测试。"
    result = check_claim_revision(old, revised, feedback)
    assert result["code_issues"] == []
    assert result["resolution_targets"][0]["change_status"] == "edited_numeric_fields_requires_semantic_reaudit"
    assert result["semantic_auto_approval"] is False
    assert check_draft(revised, evidence) == []
    assert publication_rejections({}, revised) == {"c1"}  # No bypass of final audit.


@pytest.mark.parametrize("mutation", ["unchanged", "move", "other_bad", "model_reject", "legacy", "rename"])
def test_number_repairs_cannot_rescue_unsupported_assertions(mutation):
    old, evidence = example()
    feedback = {"code_issues": check_draft(old, evidence)}
    revised = deepcopy(old)
    if mutation == "move":
        revised["claims"][0].update(qualification="剩余样本测试。", scope_note="测试80%。")
    elif mutation == "other_bad":
        revised["claims"][0]["qualification"] = "测试81%。"
    elif mutation == "model_reject":
        revised["claims"][0]["qualification"] = "剩余样本测试。"
        feedback["model_audit"] = {"claim_results": [{"claim_id": "c1", "decision": "rejected",
            "reason_code": "UNSUPPORTED_NUMBER"}]}
    elif mutation == "legacy":
        revised["claims"][0]["qualification"] = "剩余样本测试。"
        feedback["code_issues"] = [{"claim_id": "c1", "reason": "UNSUPPORTED_NUMBER"}]
    elif mutation == "rename":
        revised["claims"][0]["claim_id"] = "renamed"
    problems = check_draft(revised, evidence) + check_claim_revision(old, revised, feedback)["code_issues"]
    assert problems


def test_main_number_still_requires_main_repair_not_only_note():
    old, evidence = example()
    old["claims"][0].update(text="测试80%。", qualification="")
    revised = deepcopy(old)
    revised["claims"][0]["qualification"] = "谨慎解释。"
    result = check_claim_revision(old, revised, {"code_issues": check_draft(old, evidence)})
    assert result["code_issues"][0]["reason"] == "UNCHANGED_UNSUPPORTED_CLAIM"


@pytest.mark.parametrize("text", ["论文未报告配对比较。", "论文没有定义泛化损失。", "本文未给出该指标。",
    "作者没有报告统一对照。", "The paper does not report that metric.", "The authors do not report that metric.",
    "根据所选片段，数据不可比。论文未报告对照。"])
def test_unscoped_absence_in_main_text_is_not_rescued_by_hidden_notes(text):
    draft, evidence = example()
    draft["claims"][0].update(text=text, claim_type="limitation", qualification="依据所选片段。")
    draft["reading_scope_policy"] = READING_SCOPE_POLICY
    issues = check_draft(draft, evidence)
    assert any(row["reason"] == "READING_SCOPE_OVERSTATED" for row in issues)


@pytest.mark.parametrize("text", ["所选原文片段中，论文未报告统一对照。", "本轮审查片段中作者未提供指标。",
    "In selected excerpts the paper does not report the metric.", "不能断言论文未报告指标。",
    "所选原文片段未提供该指标。", "论文报告两种不同设置。"])
def test_correctly_scoped_or_nonabsence_assertions_are_not_rejected(text):
    draft, evidence = example()
    draft["claims"][0]["text"] = text
    assert check_reading_scope(draft, evidence) == []


def test_reading_scope_new_policy_does_not_republish_history():
    draft, evidence = example()
    draft["claims"][0].update(text="论文没有定义指标。", qualification="", claim_type="limitation")
    original = deepcopy((draft, evidence))
    assert check_draft(draft, evidence) == []  # Old draft has no opt-in policy.
    assert (draft, evidence) == original
    draft["reading_scope_policy"] = READING_SCOPE_POLICY
    assert check_draft(draft, evidence)[0]["reason"] == "READING_SCOPE_OVERSTATED"


def test_page_location_is_not_full_reading_but_unknown_scope_not_inferred():
    draft, evidence = example()
    draft["claims"][0]["text"] = "论文未提供指标。"
    assert check_reading_scope(draft, evidence)
    evidence["evidence"][0].pop("coverage_scope")
    assert not check_reading_scope(draft, evidence)


def test_scope_note_whole_paper_absence_is_checked_independently():
    draft, evidence = example()
    draft["claims"][0].update(text="所选片段解释该实验。", scope_note="论文未报告对照。")
    assert check_reading_scope(draft, evidence)[0]["field"] == "scope_note"


@pytest.mark.parametrize("ids", [None, "e1"])
def test_invalid_citation_field_is_rejected_without_new_guard_crashing(ids):
    draft, evidence = example()
    draft["claims"][0].update(text="论文未报告指标。", evidence_ids=ids, claim_type="limitation")
    draft["reading_scope_policy"] = READING_SCOPE_POLICY
    assert any(row["reason"] == "UNAPPROVED_CITATION" for row in check_draft(draft, evidence))


@pytest.mark.parametrize("kind,repair", [("numeric", True), ("numeric", False), ("absence", True), ("absence", False)])
def test_workflow_repairs_actual_fault_once_without_audit_bypass(tmp_path, kind, repair):
    from test_multi_agent_pipeline_v2 import agents, pipeline
    from test_multi_agent_scientific_scope import audit
    from multi_agent_quality import WITNESS_AUDIT_SCHEMA
    configured, calls = agents()
    actual = "We adapt on 20% of the samples and report 85% accuracy; the remaining samples are used for testing."
    packets = []
    def writer(packet):
        calls.append("writer")
        packets.append(packet)
        source = next(row["payload"] for row in packet["inputs"] if "evidence" in row["payload"])
        key = source["evidence"][0]["evidence_id"]
        data, _ = example()
        data["claims"][0].update(evidence_ids=[key], confidence="low", section="direct_conclusion")
        if kind == "absence":
            data["claims"][0].update(text="论文未报告统一对照。", qualification="", claim_type="limitation")
        if len(packets) > 1 and repair:
            if kind == "absence":
                data["claims"][0]["text"] = "所选原文片段中，论文未报告统一对照。"
            else:
                data["claims"][0]["qualification"] = "剩余样本测试。"
        data["claims"].append({**data["claims"][0], "claim_id": "independent",
            "text": "本轮只核查所选摘要片段。", "qualification": "", "claim_type": "limitation"})
        return {"output": data}
    def auditor(packet):
        calls.append("citation_auditor")
        data = next(row["payload"] for row in packet["inputs"] if "claims" in row["payload"])
        value = audit(data)
        value["schema_version"] = WITNESS_AUDIT_SCHEMA
        for row in value["claim_results"]:
            row["source_witnesses"] = [{"evidence_id": row["evidence_ids"][0], "quote": actual}]
        return {"output": value}
    configured.writer.handler = writer
    configured.citation_auditor.handler = auditor
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {"status": "ok", "papers": [
        {"paper_id": "1", "title": "Paper", "abstract": actual}]})
    execute = flow.executor.execute
    def scoped_execute(*args, **kwargs):
        value = execute(*args, **kwargs)
        for row in value["evidence"]:
            row["coverage_scope"] = "abstract"
        return value
    flow.executor.execute = scoped_execute
    result = flow.run("repair", "owner", "Explain reported settings")
    assert calls.count("writer") == calls.count("citation_auditor") == 2
    assert result["run"]["model_calls_used"] == 7
    feedback = next(row["payload"] for row in packets[1]["inputs"] if "code_issues" in row["payload"])
    reason = "UNSUPPORTED_NUMBER" if kind == "numeric" else "READING_SCOPE_OVERSTATED"
    assert any(row["reason"] == reason for row in feedback["code_issues"])
    assert result["run"]["status"] == ("partial" if repair else "needs_review")
    assert "本轮只核查所选摘要片段" in result["direct_answer"]
