import concurrent.futures
import json
import os
from pathlib import Path
import sqlite3
import threading

import pytest
from flask import g

from user_credentials import CredentialStore, ProviderCapability, child_environment, provider_scope, provider_value


@pytest.fixture
def store(tmp_path):
    return CredentialStore(tmp_path / 'credentials.sqlite3', 'test-vault-secret-not-jwt-12345')


def test_encrypted_per_owner_persistence_no_status_echo(store):
    store.update('7', {'deepseek_keys': ['private-model-a-012345'], 'llama_key': 'private-llama-a-012345'})
    assert store.capability('8').values['MODEL_REQUEST_TOKEN'] == ''
    assert store.capability('7').values['MODEL_REQUEST_TOKEN'] == 'private-model-a-012345'
    assert b'private-model' not in store.path.read_bytes() and b'private-llama' not in store.path.read_bytes()
    status = json.dumps(store.status(store.capability('7')))
    assert 'private-' not in status and 'false' in status
    restored = CredentialStore(store.path, 'test-vault-secret-not-jwt-12345')
    assert restored.status(restored.capability('7'))['deepseek']['key_count'] == 1


def test_swap_rows_and_wrong_server_secret_fail_closed(store):
    store.update('7', {'deepseek_keys': ['model-a-private-12345']})
    with sqlite3.connect(store.path) as con:
        con.execute('INSERT INTO provider_keys SELECT ?,ciphertext FROM provider_keys WHERE owner=?', ('8','7'))
    with pytest.raises(ValueError, match='CREDENTIAL_STORAGE_UNAVAILABLE'):
        store.capability('8')
    with pytest.raises(ValueError, match='CREDENTIAL_STORAGE_UNAVAILABLE'):
        CredentialStore(store.path, 'wrong-encryption-secret-12345').capability('7')


@pytest.mark.parametrize('body', [None, [], {'user_id':'7'}, {'deepseek_keys':[]}, {'deepseek_keys':'key-value'},
    {'deepseek_keys':['short']}, {'deepseek_keys':['a\nheader-long-enough']}, {'deepseek_keys':['a'*513]},
    {'deepseek_keys':['key-long-enough']*11}, {'llama_key':'[REDACTED]'}, {'clear':['other']},
    {'llama_key':'llama-key-long-enough', 'clear':['llama']}])
def test_invalid_inputs_do_not_write_other_users_or_configs(store, body):
    with pytest.raises(ValueError): store.update('7', body)
    assert not store.path.exists()


def test_clear_and_update_are_independent_atomic_owner_operations(store):
    store.update('7', {'deepseek_keys':['owner-seven-key']})
    store.update('8', {'deepseek_keys':['owner-eight-key'], 'llama_key':'owner-eight-llama'})
    store.update('7', {'clear':['deepseek']})
    assert not store.status(store.capability('7'))['deepseek']['configured']
    assert store.capability('8').values['MODEL_REQUEST_TOKEN'] == 'owner-eight-key'
    store.update('8', {'llama_key':'new-owner-eight-llama'})
    assert store.capability('8').values['MODEL_REQUEST_TOKEN'] == 'owner-eight-key'


def test_migration_never_overwrites_existing_different_user_keys(store):
    store.update('7', {'deepseek_keys':['owner-seven-key']})
    with pytest.raises(ValueError, match='CREDENTIAL_MIGRATION_CONFLICT'):
        store.update('7', {'deepseek_keys':['shared-old-key']}, only_if_empty=True)
    store.update('7', {'deepseek_keys':['owner-seven-key']}, only_if_empty=True)
    assert store.capability('7').values['MODEL_REQUEST_TOKEN'] == 'owner-seven-key'


def test_empty_capability_cannot_fall_back_to_environment_or_headers(monkeypatch):
    # The legacy tools package also imports ``config.logging_config``. Match
    # the application launch path when this test is run without MCP tests.
    monkeypatch.syspath_prepend(str(Path(__file__).resolve().parents[1] / 'deepdiver_v2'))
    from deepdiver_v2.src.model_key_pool import configured_model_tokens, post_model_request
    monkeypatch.setenv('MODEL_REQUEST_TOKEN', 'server-shared-secret')
    monkeypatch.setenv('LLAMA_CLOUD_API_KEY', 'server-llama-secret')
    monkeypatch.setenv('OPENROUTER_API_KEY', 'llx-server-legacy-secret')
    with provider_scope(ProviderCapability('8', {})):
        assert configured_model_tokens({'Authorization':'Bearer server-header-secret'}) == []
        assert provider_value('LLAMA_CLOUD_API_KEY') == ''
        from deepdiver_v2.config.config import get_config
        assert not get_config().model_request_token and not get_config().llama_cloud_api_key
        from deepdiver_v2.src.tools.llama_vision_client import LlamaVisionConfig
        assert not LlamaVisionConfig.from_env().api_key
        with pytest.raises(ValueError, match='USER_PROVIDER_KEY_REQUIRED'):
            post_model_request('https://provider.invalid', headers={'Authorization':'Bearer fallback-secret'})


def test_two_threads_never_share_keys_or_mutate_process_environment(monkeypatch):
    from deepdiver_v2.src.model_key_pool import configured_model_tokens
    monkeypatch.setenv('MODEL_REQUEST_TOKEN', 'server-shared-secret')
    before = dict(os.environ); barrier = threading.Barrier(2)
    def run(owner):
        value = 'key-for-only-' + owner
        with provider_scope(ProviderCapability(owner, {'MODEL_REQUEST_TOKEN':value, 'LLAMA_CLOUD_API_KEY':'llama-for-'+owner})):
            barrier.wait()
            assert configured_model_tokens() == [value]
            child = child_environment(os.environ)
            assert child['MODEL_REQUEST_TOKEN'] == value
            assert child['LLAMA_CLOUD_API_KEY'] == 'llama-for-' + owner
            assert owner in child['MODEL_KEY_POOL_STATE_PATH']
            assert child['SCIASSISTANT_PROVIDER_OWNER'] == owner
            assert all(child.get(name)=='' for name in ['OPENROUTER_API_KEY','OPENAI_API_KEY','DEEPSEEK_API_KEY'])
    with concurrent.futures.ThreadPoolExecutor(2) as pool:
        list(pool.map(run, ['owner-a','owner-b']))
    assert dict(os.environ) == before


def test_empty_worker_scope_survives_config_dotenv_fallback(tmp_path):
    import subprocess,sys,shutil
    root=Path(__file__).resolve().parents[1]
    shutil.copyfile(root/'deepdiver_v2/config/config.py',tmp_path/'env_config.py')
    (tmp_path/'.env').write_text('MODEL_REQUEST_TOKEN=forbidden-shared-model\nLLAMA_CLOUD_API_KEY=llx-forbidden-shared-cloud\nOPENROUTER_API_KEY=llx-forbidden-legacy-cloud\n',encoding='utf8')
    with provider_scope(ProviderCapability('b',{})):
        environment=child_environment(os.environ)
    environment['PYTHONPATH']=str(root)
    result=subprocess.run([sys.executable,'-c',
        "import env_config; c=env_config.get_config(); assert not c.model_request_token; assert not c.llama_cloud_api_key;"
        "assert not env_config.config.model_request_token; assert not env_config.config.llama_cloud_api_key;print('scope_empty')"],
        cwd=tmp_path,env=environment,capture_output=True,timeout=20)
    assert result.returncode==0 and b'scope_empty' in result.stdout


def test_authenticated_api_self_scope_and_no_secret_echo(store, monkeypatch):
    import app as gateway
    owner = ['7']
    def auth():
        g.current_user_id = owner[0]
        return None
    monkeypatch.setattr(gateway, '_authenticate_current_request', auth)
    monkeypatch.setattr(gateway, '_provider_store', lambda:store)
    client = gateway.app.test_client()
    result = client.post('/api/account/provider-keys', json={'deepseek_keys':['owner-seven-secret-123']})
    assert result.status_code == 200 and b'owner-seven-secret' not in result.data
    owner[0]='8'
    assert not client.get('/api/account/provider-keys').json['deepseek']['configured']
    assert client.post('/api/account/provider-keys', json={'user_id':'7','clear':['deepseek']}).status_code == 400
    assert store.status(store.capability('7'))['deepseek']['configured']
    monkeypatch.setattr(gateway, '_authenticate_current_request', lambda: (gateway.jsonify(error='unauthorized'),401))
    assert client.get('/api/account/provider-keys').status_code == 401


def test_retire_exact_private_fields_preserves_other_configuration(tmp_path):
    from tools.migrate_account_provider_keys import retire_file
    path=tmp_path/'.env'
    path.write_text('MODEL_REQUEST_TOKEN="old-key"\nLLAMA_CLOUD_API_KEY="llama-key"\nMODEL_NAME="model"\nSECRET_KEY="server-secret"\n',encoding='utf8')
    assert retire_file(path)==2
    assert path.read_text()=='MODEL_NAME="model"\nSECRET_KEY="server-secret"\n'
    assert retire_file(path)==0
