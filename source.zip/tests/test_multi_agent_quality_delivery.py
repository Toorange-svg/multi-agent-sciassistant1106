"""Late asks and scoped false positives, without automatic scientific approval."""
from copy import deepcopy

import pytest

from multi_agent_quality import (check_metric_direction, PRINTED_METRIC_DIRECTION_POLICY,
    METRIC_DIRECTION_POLICY, COORDINATED_METRIC_DIRECTION_POLICY, PROCESSING_OBSERVATION_POLICY, check_audit,
    publication_rejections, citation_audit_input)
from multi_agent_pipeline_v2 import check_draft, render_claims
from multi_agent_report_contracts import compile_user_requirements, requirement_plan_issues, report_budget
from multi_agent_sections import (report_outline, section_dossiers, writer_jobs,
    merge_writer_batches, initial_delivery_budget)
from multi_agent_publication import coverage, review_request
from multi_agent_skills import skill_bundle
from multi_agent_live import effective_role_prompt
from test_multi_agent_metric_direction import inputs
from test_multi_agent_absence_basis import draft, evidence, audit, absence
from test_multi_agent_report_requirements import plan_for_case
from test_multi_agent_sections import good_draft


@pytest.mark.parametrize('field', ['text', 'scope_note', 'qualification'])
@pytest.mark.parametrize('text', [
    '验证损失的最小值（1.16）与BLEU的最大值（70.38），方向不同。',
    'validation loss is minimized and BLEU is highest.',
    '训练损失最小而准确率最高。',
    '困惑度最小和吞吐量最高，不能据此推广。',
])
def test_other_metrics_maximum_is_not_a_loss_maximum(field, text):
    data, sources = inputs('原文报告实验。')
    data['claims'][0].update(scope_note='', qualification='')
    data['claims'][0][field] = text
    source_metric = 'training loss' if '训练' in text else 'perplexity' if '困惑度' in text else 'validation loss'
    sources['evidence'][0]['excerpt'] = f'The performance peaks at r=16 for {source_metric} and r=4 for BLEU.'
    before = deepcopy((data, sources))
    assert check_metric_direction(data, sources, policy=PRINTED_METRIC_DIRECTION_POLICY)
    assert not check_metric_direction(data, sources)
    assert (data, sources) == before


@pytest.mark.parametrize('text', [
    '验证损失达到峰值而BLEU最小。',
    '验证损失最大时最优，BLEU也最高。',
    'BLEU最高而验证损失最高。',
    '验证损失最低，验证损失也达到峰值。',
])
def test_a_real_loss_inversion_is_still_rejected(text):
    data, sources = inputs(text)
    findings = check_metric_direction(data, sources)
    assert findings and findings[0]['reason'] == 'METRIC_DIRECTION_INVERTED'
    assert not findings[0]['automatic_rewrite']


def test_historical_metric_policy_dispatch_is_not_silently_upgraded():
    data, sources = inputs('验证损失最小与BLEU最大。')
    data['metric_direction_policy'] = PRINTED_METRIC_DIRECTION_POLICY
    assert any(r['reason'] == 'METRIC_DIRECTION_INVERTED' for r in check_draft(data, sources))
    data['metric_direction_policy'] = METRIC_DIRECTION_POLICY
    assert not any(r['reason'] == 'METRIC_DIRECTION_INVERTED' for r in check_draft(data, sources))


@pytest.mark.parametrize('text', [
    '验证损失最优为最小值1.16（非最大值1.23），BLEU取最大值。',
    '验证损失最低而非最高。',
    'validation loss is lowest, not highest.',
])
def test_negation_of_maximum_does_not_become_recommendation(text):
    data, sources = inputs(text)
    assert not check_metric_direction(data, sources)
    if '（非' in text:
        assert check_metric_direction(data, sources, policy=COORDINATED_METRIC_DIRECTION_POLICY)


@pytest.mark.parametrize('text', [
    '验证损失最低（非最大）但验证损失最高才最优。',
    '不是验证损失最低而是验证损失最高才最优。',
    '验证损失不是最高而是最大化最好。',
])
def test_negation_of_one_predicate_does_not_hide_later_inversion(text):
    data, sources = inputs(text)
    assert check_metric_direction(data, sources)


@pytest.mark.parametrize('field', ['text', 'scope_note', 'qualification'])
@pytest.mark.parametrize('text', [
    '数值来自解析文本，未做人工视觉核对。',
    '本次解析结果尚未人工逐页视觉复核。',
])
def test_manual_transcription_limit_is_not_paper_absence(field, text):
    data, sources = draft(), evidence()
    data['claims'][0][field] = text
    raw = absence(audit(data), text, field=field)
    before = deepcopy((raw, data, sources))
    assert check_audit(raw, data, sources)['absence_issues']
    data['processing_observation_policy'] = PROCESSING_OBSERVATION_POLICY
    checked = check_audit(raw, data, sources)
    assert not checked['absence_issues'] and not checked['contract_errors']
    assert not publication_rejections(checked, data)
    del data['processing_observation_policy']
    assert (raw, data, sources) == before


@pytest.mark.parametrize('text', [
    '未做人工视觉核对，原文未报告种子。',
    '论文未做人工视觉核对。',
    '数值未做人工视觉核对，也没有显著性检验。',
    '未经人工视觉复核；未提供置信区间。',
    '作者未做对照，但未做人工视觉核对。',
    '未做人工实验验证。',
])
def test_processing_words_cannot_hide_other_unsupported_omissions(text):
    data = draft()
    data['processing_observation_policy'] = PROCESSING_OBSERVATION_POLICY
    data['claims'][0]['qualification'] = text
    checked = check_audit(absence(audit(data), text), data, evidence())
    assert checked['absence_issues'] and publication_rejections(checked, data) == {'c1'}


@pytest.mark.parametrize('fault', ['witness', 'scientific_rejection'])
def test_processing_category_cannot_restore_an_unapproved_scientific_claim(fault):
    data = draft()
    data['processing_observation_policy'] = PROCESSING_OBSERVATION_POLICY
    data['claims'][0]['qualification'] = '未做人工视觉核对。'
    raw = absence(audit(data), data['claims'][0]['qualification'])
    if fault == 'witness':
        raw['claim_results'][0]['source_witnesses'][0]['quote'] = 'This quotation was never printed by the original author.'
    else:
        raw['status'] = 'needs_review'
        raw['rejected_claim_ids'] = ['c1']
        raw['issues'] = [{'claim_id': 'c1', 'reason_code': 'UNSUPPORTED_NUMBER', 'detail': '数值无依据。'}]
        raw['claim_results'][0].update(decision='rejected', reason_code='UNSUPPORTED_NUMBER')
        raw['claim_results'][0]['field_results']['text']['status'] = 'unsupported'
    assert publication_rejections(check_audit(raw, data, evidence()), data) == {'c1'}


def test_audit_packet_retains_fields_and_explicit_no_manual_attestation():
    data = draft()
    data['processing_observation_policy'] = PROCESSING_OBSERVATION_POLICY
    before = deepcopy(data)
    packet = citation_audit_input(data, evidence())
    assert 'No manual visual check is attested' in packet['processing_observation_instructions']
    assert packet['claims'][0]['report_fields']['text'] == data['claims'][0]['text']
    assert data == before


def closing_case():
    requirements = [
        {'question_quote': '解释机制。', 'answer_kind': 'mechanism'},
        {'question_quote': '提出可检验的重复实验。', 'answer_kind': 'evaluation_protocol'},
        {'question_quote': '最后单列结论与不能推出的结论。', 'answer_kind': 'conclusion_summary'},
        {'question_quote': '标题用中文。', 'answer_kind': 'report_structure'},
    ]
    case = {'question': ''.join(r['question_quote'] for r in requirements), 'requirements': requirements}
    plan = plan_for_case(case)
    ledger = compile_user_requirements(case['question'], plan)
    outline = report_outline(ledger, plan)
    sources = evidence()
    sources['evidence'][0]['reviewed_group_ids'] = ['g1']
    dossiers = section_dossiers(outline, sources, {'coverage': []})
    return case, plan, ledger, outline, dossiers, sources


@pytest.mark.parametrize('profile', ['standard', 'enhanced'])
def test_tail_conclusions_are_real_delivery_not_formatting_guidance(profile):
    case, plan, ledger, outline, dossiers, sources = closing_case()
    before = deepcopy((case, plan, ledger))
    closing = ledger['requirements'][2]
    assert outline['sections'][-1]['section_id'] == 'conclusions'
    assert outline['sections'][-1]['requirement_ids'] == [closing['requirement_id']]
    assert closing['requirement_id'] not in outline['guidance_requirement_ids']
    assert outline['guidance_requirement_ids'] == [ledger['requirements'][3]['requirement_id']]
    jobs = writer_jobs(outline, dossiers, profile, report_budget(profile)['model_call_limit'])
    assert [s for j in jobs for s in j['section_ids']] == [s['section_id'] for s in outline['sections']]
    assert all([r['section_id'] for r in j['delivery_checklist']] == j['section_ids'] for j in jobs)
    assert all('answer_kinds' in r and 'requested_table_rows_in_main_text' in r
               for j in jobs for r in j['delivery_checklist'])
    merged = merge_writer_batches(outline, [(j, good_draft(j), 'mock-raw') for j in jobs])
    request = review_request(ledger, merged)
    tail = next(r for r in request['requirements'] if r['requirement_id'] == closing['requirement_id'])
    assert tail['eligible_claim_ids']
    report = {'schema_version': 'sciassistant.report-review/v1', 'requirements': [
        {'requirement_id': r['requirement_id'], 'status': 'answered', 'claim_ids': r['eligible_claim_ids'],
         'reason': '受控结构测试，不证明回答语义。'} for r in request['requirements']],
        'consistency': {'reviewed_claim_ids': request['claim_ids'], 'conflicts': []}}
    # Blocking every tail claim must not leave the closing ask marked answered.
    blocked = set(tail['eligible_claim_ids'])
    delivered = coverage(ledger, merged, {'report_review': report}, blocked)
    row = next(r for r in delivered['requirements'] if r['requirement_id'] == closing['requirement_id'])
    assert row['status'] == 'unanswered'
    assert '本节尚未形成通过审查的内容' in render_claims(merged, sources, rejected=blocked)
    assert initial_delivery_budget(ledger, plan, profile)['content_requirement_count'] == 3
    assert (case, plan, ledger) == before


def test_closing_request_requires_planned_delivery_not_empty_guidance_bindings():
    case, plan, *_ = closing_case()
    plan['user_requirements'][2].update(research_group_ids=[], report_obligation_ids=[])
    assert any(r['reason'] == 'REQUIREMENT_HAS_NO_PLANNED_DELIVERY'
               for r in requirement_plan_issues(plan, case['question']))


@pytest.mark.parametrize('profile', ['standard', 'enhanced'])
def test_requested_table_rows_are_a_main_text_delivery_item_not_a_detail_only_item(profile):
    case, plan, ledger, _, _, sources = closing_case()
    ledger['requirements'][0]['answer_kind'] = 'table_reading'
    outline = report_outline(ledger, plan)
    dossiers = section_dossiers(outline, sources, {'coverage': []})
    jobs = writer_jobs(outline, dossiers, profile, report_budget(profile)['model_call_limit'])
    checklist = [r for j in jobs for r in j['delivery_checklist']]
    assert next(r for r in checklist if r['section_id'] == 'analysis-g1')['requested_table_rows_in_main_text']
    assert not next(r for r in checklist if r['section_id'] == 'summary')['requested_table_rows_in_main_text']
    assert not next(r for r in checklist if r['section_id'] == 'conclusions')['requested_table_rows_in_main_text']
    assert not any('target_word_count' in j or 'target_claim_count' in j for j in jobs)


def test_role_material_has_control_group_and_source_boundary_rules_without_new_authority():
    bundle = skill_bundle('writer', {'requirements': [{'answer_kind': 'evaluation_protocol'}]})
    skill = next(s for s in bundle['skills'] if s['skill_id'] == 'experimental-design')
    assert skill['version'] == 2
    assert any('not themselves a control group' in s for s in skill['instructions'])
    assert any('selected cited excerpts' in s for s in skill['instructions'])
    assert not bundle['allowed_actions_override'] and not bundle['semantic_auto_approval']
    assert 'conclusion_summary' in effective_role_prompt('planner')
    assert 'delivery_checklist' in effective_role_prompt('writer')


def test_standalone_partition_without_typed_ledger_keeps_ids_without_claiming_coverage():
    _, plan, ledger, outline, dossiers, _ = closing_case()
    outline['requirements'] = []
    jobs = writer_jobs(outline, dossiers, 'standard', 10)
    assert jobs[0]['requirement_ids'] == list(dict.fromkeys(
        r for s in outline['sections'] for r in s['requirement_ids']))
    assert all(r['answer_kinds'] == ['unclassified'] for r in jobs[0]['delivery_checklist'])
    assert all(not r['requested_table_rows_in_main_text'] for r in jobs[0]['delivery_checklist'])
    assert not outline['publication_coverage_verified'] and not outline['semantic_auto_approval']
