"""Unit tests for the web task status determination (web_app.py).

Regression coverage for the A1 defect: a source-level retrieval refusal
(techrxiv 403 etc.) inside the run_demo transcript used to trigger the
model-credential scan, turning successfully answered tasks into
"认证失败" failures and cutting the follow-up context inheritance.
"""
import unittest
import json
import tempfile
import threading
import time
from pathlib import Path

import web_app


# Mimics the real transcript shape: per-round literature diagnostics carrying
# literature_sources' own access-block wording.
_BLOCKED_SOURCE_TRANSCRIPT = """[.rounds]
{
  "round": 1,
  "source": "techrxiv",
  "query": "multimodal models",
  "returned": 0,
  "search_error": "3 consecutive access blocks (HTTP 401/403/406/451); re-enable manually with enable_source()"
}
[answer]
Restored analysis text."""


class CredentialErrorHintTests(unittest.TestCase):
    def test_source_access_block_is_not_a_credential_error(self):
        self.assertIsNone(web_app._credential_error_hint(_BLOCKED_SOURCE_TRANSCRIPT))

    def test_report_source_note_is_not_a_credential_error(self):
        # The report itself discloses the blocked source, with uppercase HTTP
        # wording inside Chinese prose (real task 0b85fe6fecad shape).
        report_note = (
            "**检索来源说明**：本轮检索覆盖 arxiv、zenodo、hal 三个来源；"
            "techrxiv 因连续访问受阻（HTTP 401/403/406/451）返回 0 条，未纳入证据。"
        )
        self.assertIsNone(web_app._credential_error_hint(report_note))

    def test_model_auth_failure_is_detected(self):
        transcript = (
            "Error: Direct LLM query unavailable after 3 retries: "
            "401 Client Error: Unauthorized for url: https://api.example.com/v1/chat/completions"
        )
        hint = web_app._credential_error_hint(transcript)
        self.assertIsNotNone(hint)
        self.assertIn("MODEL_REQUEST_TOKEN", hint)

    def test_blocked_source_does_not_mask_model_auth_failure(self):
        transcript = (
            '"search_error": "3 consecutive access blocks (HTTP 401/403/406/451)"\n'
            "Error: Direct LLM query unavailable after 3 retries: "
            "401 Client Error: Unauthorized for url: https://api.example.com"
        )
        hint = web_app._credential_error_hint(transcript)
        self.assertIsNotNone(hint)
        self.assertIn("MODEL_REQUEST_TOKEN", hint)

    def test_llama_error_maps_to_llama_key(self):
        hint = web_app._credential_error_hint("LlamaParse rejected the request: invalid api key")
        self.assertIsNotNone(hint)
        self.assertIn("LLAMA_CLOUD_API_KEY", hint)

    def test_empty_transcript_has_no_hint(self):
        self.assertIsNone(web_app._credential_error_hint(""))
        self.assertIsNone(web_app._credential_error_hint(None))


class HasUsableAnswerTests(unittest.TestCase):
    def test_real_answer_is_usable(self):
        self.assertTrue(web_app._has_usable_answer("这是一段真实的分析正文，超过兜底句长度。" * 3))

    def test_fallback_sentence_is_not_usable(self):
        fallback = "回答模型暂时不可用（已重试 3 次）。以下不使用虚构来源，仅说明当前无法生成可靠的通用回答。"
        self.assertFalse(web_app._has_usable_answer(fallback))

    def test_empty_answer_is_not_usable(self):
        self.assertFalse(web_app._has_usable_answer(""))
        self.assertFalse(web_app._has_usable_answer(None))


class TaskFailedVerdictTests(unittest.TestCase):
    def test_successful_task_with_blocked_source_completes(self):
        self.assertFalse(web_app._task_failed_verdict(0, _BLOCKED_SOURCE_TRANSCRIPT, "完整的分析正文。", None))

    def test_credential_hint_alongside_real_answer_completes(self):
        # The A1 shape: a real 12826-char answer plus a stray auth-like line.
        self.assertFalse(web_app._task_failed_verdict(
            0, _BLOCKED_SOURCE_TRANSCRIPT, "完整的分析正文。",
            "认证失败：请检查“回答模型 API Key”（MODEL_REQUEST_TOKEN）是否填写正确。",
        ))

    def test_credential_hint_with_fallback_answer_fails(self):
        fallback = "回答模型暂时不可用（已重试 3 次）。以下不使用虚构来源，仅说明当前无法生成可靠的通用回答。"
        self.assertTrue(web_app._task_failed_verdict(
            0, "401 Client Error: Unauthorized for url: https://api.example.com", fallback,
            "认证失败：请检查“回答模型 API Key”（MODEL_REQUEST_TOKEN）是否填写正确。",
        ))

    def test_credential_hint_with_no_answer_fails(self):
        self.assertTrue(web_app._task_failed_verdict(
            0, "401 Client Error: Unauthorized", "", "认证失败：请检查“回答模型 API Key”（MODEL_REQUEST_TOKEN）是否填写正确。",
        ))

    def test_final_status_failed_fails(self):
        self.assertTrue(web_app._task_failed_verdict(0, "Final Status: ❌ Failed", "任何正文", None))

    def test_nonzero_returncode_fails(self):
        self.assertTrue(web_app._task_failed_verdict(1, "", "任何正文", None))


class RetrievalQueueTests(unittest.TestCase):
    def setUp(self):
        self.old_limit = web_app.RETRIEVAL_MAX_CONCURRENT
        web_app.RETRIEVAL_MAX_CONCURRENT = 2
        with web_app.TASK_LOCK:
            self.old_tasks = web_app.TASKS.copy()
            web_app.TASKS.clear()
            web_app._RETRIEVAL_QUEUE.clear()
            web_app._RETRIEVAL_ACTIVE.clear()

    def tearDown(self):
        for event in getattr(self, "release", {}).values():
            event.set()
        deadline = time.time() + 2
        while time.time() < deadline:
            with web_app.TASK_LOCK:
                if not web_app._RETRIEVAL_ACTIVE:
                    break
            time.sleep(0.01)
        with web_app.TASK_LOCK:
            web_app._RETRIEVAL_QUEUE.clear()
            web_app._RETRIEVAL_ACTIVE.clear()
            web_app.TASKS.clear()
            web_app.TASKS.update(self.old_tasks)
        web_app.RETRIEVAL_MAX_CONCURRENT = self.old_limit

    def test_fifo_queue_caps_concurrency_and_reports_tasks_ahead(self):
        task_ids = ["queue-1", "queue-2", "queue-3"]
        self.started = {task_id: threading.Event() for task_id in task_ids}
        self.release = {task_id: threading.Event() for task_id in task_ids}

        def blocking_worker(task_id):
            self.started[task_id].set()
            self.release[task_id].wait(2)
            web_app._update(task_id, status="completed", message="done")

        with web_app.TASK_LOCK:
            for task_id in task_ids:
                web_app.TASKS[task_id] = {
                    "id": task_id,
                    "status": "queued",
                    "created_at": web_app._now(),
                    "updated_at": web_app._now(),
                }

        for task_id in task_ids:
            web_app._enqueue_retrieval_task(task_id, blocking_worker, task_id)

        self.assertTrue(self.started["queue-1"].wait(1))
        self.assertTrue(self.started["queue-2"].wait(1))
        self.assertFalse(self.started["queue-3"].is_set())
        with web_app.TASK_LOCK:
            self.assertEqual(web_app._RETRIEVAL_ACTIVE, {"queue-1", "queue-2"})
            self.assertEqual([job["task_id"] for job in web_app._RETRIEVAL_QUEUE], ["queue-3"])
            queued = dict(web_app.TASKS["queue-3"])
        self.assertEqual(queued["queue_ahead"], 2)
        self.assertEqual(queued["queue_position"], 3)
        self.assertIn("前面还有 2 个任务", queued["message"])

        self.release["queue-1"].set()
        self.assertTrue(self.started["queue-3"].wait(1))
        with web_app.TASK_LOCK:
            self.assertEqual(len(web_app._RETRIEVAL_ACTIVE), 2)
            self.assertIsNone(web_app.TASKS["queue-3"]["queue_ahead"])

        self.release["queue-2"].set()
        self.release["queue-3"].set()


if __name__ == "__main__":
    unittest.main()


class ExportSectionTests(unittest.TestCase):
    def test_configuration_notice_gets_its_own_section(self):
        task = {
            "report_title": "SciAssistant 科研报告",
            "sections": {
                "report": "分析正文。",
                "configuration_notice": "认证失败：请检查“回答模型 API Key”（MODEL_REQUEST_TOKEN）。",
                "partial_failure": "第 3 页表格解析不完整。",
            },
        }
        markdown = web_app._task_export_markdown(task)
        self.assertIn("## 配置与凭证提示", markdown)
        self.assertIn("认证失败", markdown)
        # The parsing-failure section must not carry credential text.
        partial = markdown.split("## 部分解析失败说明", 1)[1].split("## ", 1)[0]
        self.assertNotIn("认证失败", partial)

    def test_debug_export_contains_artifacts_and_redacts_secrets(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            log = root / "run.log"
            diagnostics = root / "events.jsonl"
            prefetch = root / "web_task_debug.prefetch.json"
            followup = root / "web_task_debug.followup.json"
            log.write_text("planner keyword\nAuthorization: Bearer secret-value\nFinal answer", encoding="utf-8")
            diagnostics.write_text(json.dumps({"stage": "search", "token": "secret-value"}, ensure_ascii=False) + "\n", encoding="utf-8")
            prefetch.write_text('{"papers": [{"title": "Test paper"}]}', encoding="utf-8")
            followup.write_text('{"paper_ids": ["2401.00001"]}', encoding="utf-8")
            task = {
                "task_id": "debug",
                "status": "completed",
                "query": "测试问题",
                "answer": "最终回答",
                "output": "planner output\nAuthorization: Bearer secret-value",
                "sections": {"report": "报告正文"},
                "log": str(log),
                "diagnostics_path": str(diagnostics),
                "timeline": [{"stage": "running"}],
            }
            # The helper derives sibling prefetch/follow-up artifacts from the
            # task id and LOG_DIR, so point it at the temporary directory.
            old_log_dir = web_app.LOG_DIR
            web_app.LOG_DIR = root
            try:
                markdown = web_app._task_debug_markdown(task)
            finally:
                web_app.LOG_DIR = old_log_dir
            self.assertIn("## 完整运行日志（脱敏）", markdown)
            self.assertIn("## 诊断事件 JSONL（脱敏）", markdown)
            self.assertIn("## 报告分段", markdown)
            self.assertIn("## 原始任务输出（脱敏）", markdown)
            self.assertIn("最终回答", markdown)
            self.assertNotIn("secret-value", markdown)
