"""Display sections are not approval boundaries; printed trends are source-bound."""
from copy import deepcopy

import pytest

from multi_agent_sections import (CROSS_SECTION_BINDING_POLICY, SECTION_POLICY, SECTION_DRAFT_SCHEMA,
    section_dossiers, writer_jobs, writer_job_issues, project_writer_job, merge_writer_batches,
    revision_job, revision_jobs, merge_revision_jobs)
from multi_agent_quality import (RANK_TABLE_TREND_POLICY, printed_rank_tables,
    check_rank_table_trends, citation_audit_input)
from multi_agent_pipeline_v2 import check_draft
from multi_agent_publication import review_request, coverage


TABLE = ('Rank r | val loss | BLEU\n\n'
    '1 | 2.5 | 10\n2 | 2.0 | 12\n3 | 2.0 | 11\n4 | 2.1 | 11.4\n5 | 2.2 | 10.9\n\n'
    'Table 3: A synthetic table for protocol tests, not a paper result.')


def sources(text=TABLE):
    return {'evidence': [{'evidence_id': 'e1', 'paper_id': 'synthetic', 'review_status': 'approved',
        'reviewed_group_ids': ['g1', 'g2'], 'group_id': 'g1', 'excerpt': text,
        'coverage_scope': 'selected_chunks', 'locator': {'page': 1, 'bbox': [1, 2, 3, 4]}}]}


def situation(*, versioned=True):
    outline = {'policy': SECTION_POLICY, 'question_sha256': 'a'*64,
        'guidance_requirement_ids': [], 'planned_group_ids': ['g1', 'g2'],
        'requirements': [{'requirement_id': rid, 'answer_kind': kind, 'question_quote': quote}
            for rid, kind, quote in [('r1', 'table_reading', '解释列。'), ('r2', 'table_reading', '列出最优。')]],
        'sections': [{'section_id': sid, 'title': sid, 'role': 'topic_analysis',
            'requirement_ids': [rid], 'research_group_ids': [gid]}
            for sid, rid, gid in [('a', 'r1', 'g1'), ('b', 'r2', 'g2')]]}
    if versioned:
        outline['cross_section_binding_policy'] = CROSS_SECTION_BINDING_POLICY
    evidence = sources()
    dossiers = section_dossiers(outline, evidence, {'coverage': []})
    job = writer_jobs(outline, dossiers, 'standard', 10)[0]
    data = {'schema_version': SECTION_DRAFT_SCHEMA, 'direct_answer': '待审草稿', 'claims': [{
        'claim_id': 'c1', 'report_section_id': 'a', 'section': 'topic_analysis',
        'requirement_ids': ['r1', 'r2'], 'evidence_ids': ['e1'], 'group_id': 'g1',
        'claim_type': 'technical', 'assertion_mode': 'reported_fact',
        'text': '原始表格的列读数与最优集合仍须审计。', 'scope_note': '', 'qualification': '',
        'depends_on_claim_ids': []}]}
    return outline, job, data, evidence


def test_cross_section_bindings_keep_exact_text_ids_and_sources_before_audit():
    outline, job, data, evidence = situation()
    before = deepcopy((job, data, evidence))
    assert writer_job_issues(data, job) == []
    projected = project_writer_job(data, job)
    assert projected['claims'] == data['claims'] and not projected.get('isolated_claims')
    merged = merge_writer_batches(outline, [(job, projected, 'raw')])
    assert merged['claims'][0]['claim_id'] == 'b1-c1'
    assert merged['claims'][0]['requirement_ids'] == ['r1', 'r2']
    assert not writer_job_issues(merged, revision_job(outline, evidence))
    assert not check_draft(merged, evidence)
    assert (job, data, evidence) == before


def test_unversioned_historical_jobs_keep_strict_section_bindings():
    _, job, data, _ = situation(versioned=False)
    assert 'cross_section_binding_policy' not in job
    assert writer_job_issues(data, job)[0]['reason'] == 'WRITER_SECTION_BINDING_INVALID'
    job['cross_section_binding_policy'] = 'unknown-policy'
    assert writer_job_issues(data, job)


@pytest.mark.parametrize('fault', ['unknown_requirement', 'no_own_requirement', 'foreign_batch',
    'duplicate_requirement', 'foreign_section', 'foreign_group', 'unapproved_source', 'foreign_dependency'])
def test_cross_binding_does_not_expand_job_source_or_dependency_authority(fault):
    _, job, data, _ = situation()
    c = data['claims'][0]
    if fault == 'unknown_requirement': c['requirement_ids'].append('forged')
    elif fault == 'no_own_requirement': c['requirement_ids'] = ['r2']
    elif fault == 'foreign_batch': job['requirement_ids'] = ['r1']
    elif fault == 'duplicate_requirement': c['requirement_ids'].append('r1')
    elif fault == 'foreign_section': c['report_section_id'] = 'outside'
    elif fault == 'foreign_group': c['group_id'] = 'outside'
    elif fault == 'unapproved_source': c['evidence_ids'] = ['outside']
    elif fault == 'foreign_dependency': c['depends_on_claim_ids'] = ['outside']
    assert writer_job_issues(data, job)
    assert not project_writer_job(data, job)['claims']


def test_valid_cross_binding_is_not_semantic_completion_or_citation_approval():
    outline, job, data, _ = situation()
    merged = merge_writer_batches(outline, [(job, data, 'raw')])
    ledger = {'requirements': outline['requirements']}
    request = review_request(ledger, merged)
    assert all(r['eligible_claim_ids'] == ['b1-c1'] for r in request['requirements'])
    review = {'schema_version': 'sciassistant.report-review/v1', 'requirements': [
        {'requirement_id': r['requirement_id'], 'status': 'limited', 'claim_ids': ['b1-c1'],
         'reason': '仅有结构合法的候选，尚未证明语义完整。'} for r in ledger['requirements']],
        'consistency': {'reviewed_claim_ids': ['b1-c1'], 'conflicts': []}}
    assert not coverage(ledger, merged, {'report_review': review}, set())['all_content_answered']
    blocked = coverage(ledger, merged, {'report_review': review}, {'b1-c1'})
    assert all(r['status'] == 'unanswered' for r in blocked['requirements'])


def test_scoped_revision_preserves_the_original_cross_bindings_without_editing_other_sections():
    outline, job, data, evidence = situation()
    merged = merge_writer_batches(outline, [(job, data, 'raw')])
    target = merged['claims'][0]
    feedback = {'code_issues': [{'claim_id': target['claim_id'], 'reason': 'READING_SCOPE_OVERSTATED'}]}
    jobs = revision_jobs(merged, evidence, feedback, None)
    assert len(jobs) == 1 and jobs[0]['section_ids'] == ['a']
    assert jobs[0]['requirement_ids'] == ['r1', 'r2']
    patch = {'schema_version': SECTION_DRAFT_SCHEMA, 'claims': [{**target, 'scope_note': '仅所选片段。'}]}
    updated = merge_revision_jobs(merged, [(jobs[0], patch, 'patch')])
    assert updated['claims'][0]['requirement_ids'] == target['requirement_ids']
    patch['claims'][0]['requirement_ids'] = ['r1']
    with pytest.raises(ValueError, match='UNTARGETED_CLAIM_CHANGED'):
        merge_revision_jobs(merged, [(jobs[0], patch, 'bad')])


def test_printed_table_records_retain_offsets_values_and_selected_scope():
    evidence = sources()
    before = deepcopy(evidence)
    record = printed_rank_tables(evidence)[0]
    assert len(record['rows']) == 5 and record['rows'][3]['values']['BLEU'] == '11.4'
    assert record['quote'] == TABLE[record['start']:record['end']]
    assert all(r['quote'] == TABLE[r['start']:r['end']] for r in record['rows'])
    assert not record['values_corrected_or_inferred'] and not record['semantic_auto_approval']
    assert evidence == before


@pytest.mark.parametrize('fault', ['rejected', 'malformed', 'duplicate_rank', 'unordered', 'not_numeric', 'short', 'oversized'])
def test_invalid_or_incomplete_pipe_tables_are_not_repaired_or_truncated(fault):
    text = TABLE
    if fault == 'malformed': text = text.replace('4 | 2.1 | 11.4', '4 | 2.1')
    elif fault == 'duplicate_rank': text = text.replace('4 | 2.1', '3 | 2.1')
    elif fault == 'unordered': text = text.replace('4 | 2.1', '2 | 2.1')
    elif fault == 'not_numeric': text = text.replace('11.4', 'eleven')
    elif fault == 'short': text = 'Rank r | val loss | BLEU\n1 | 1 | 2\n2 | 1 | 3'
    elif fault == 'oversized': text = 'Rank r | val loss | BLEU\n'+'\n'.join(f'{i} | 1 | 2' for i in range(1, 82))
    evidence = sources(text)
    if fault == 'rejected': evidence['evidence'][0]['review_status'] = 'rejected'
    assert printed_rank_tables(evidence) == []


@pytest.mark.parametrize('field', ['text', 'scope_note', 'qualification'])
def test_actual_cited_rebound_blocks_a_false_monotonic_claim_in_each_field(field):
    _, _, data, evidence = situation()
    data['rank_table_trend_policy'] = RANK_TABLE_TREND_POLICY
    data['claims'][0][field] = 'BLEU在r=2最高后随rank增大而下降。'
    findings = check_rank_table_trends(data, evidence)
    assert findings[0]['field'] == field
    assert [r['rank'] for r in findings[0]['counterexample_rows']] == ['3', '4']
    assert not findings[0]['automatic_rewrite']
    assert any(r['reason'] == 'PRINTED_TABLE_TREND_CONTRADICTION' for r in check_draft(data, evidence))
    packet = citation_audit_input(data, evidence)
    assert packet['printed_rank_tables'][0]['quote'] in TABLE


def test_refusal_of_a_different_clause_cannot_hide_a_later_false_trend():
    _, _, data, evidence = situation()
    data['rank_table_trend_policy'] = RANK_TABLE_TREND_POLICY
    data['claims'][0]['text'] = '不能推出rank越大越好：损失有波动，BLEU在r=2最高后随rank增大而下降。'
    assert check_rank_table_trends(data, evidence)


@pytest.mark.parametrize('text', ['BLEU在r=2后各值均低于此前峰值，但不是单调下降。',
    '不能说BLEU在r=2最高后随rank增大而下降。', 'BLEU在r=2后下降，但在r=4回升。',
    '如果BLEU随rank增大单调下降，需要检验。', 'BLEU是否随rank增大单调下降？',
    'BLEU总体随rank增大而下降。'])
def test_refutations_hypotheses_and_below_peak_observations_are_not_monotonic_assertions(text):
    _, _, data, evidence = situation()
    data['rank_table_trend_policy'] = RANK_TABLE_TREND_POLICY
    data['claims'][0]['text'] = text
    assert not check_rank_table_trends(data, evidence)


@pytest.mark.parametrize('case', ['legacy', 'uncited', 'other_table', 'actually_monotonic', 'proposal'])
def test_trend_guard_never_uses_an_uncited_or_ambiguous_table_or_reinterprets_history(case):
    _, _, data, evidence = situation()
    data['rank_table_trend_policy'] = RANK_TABLE_TREND_POLICY
    data['claims'][0]['text'] = 'BLEU随rank增大单调下降。'
    if case == 'legacy': data.pop('rank_table_trend_policy')
    elif case == 'uncited': data['claims'][0]['evidence_ids'] = ['not-e1']
    elif case == 'other_table': evidence['evidence'].append({**evidence['evidence'][0], 'evidence_id': 'e2'}); data['claims'][0]['evidence_ids'].append('e2')
    elif case == 'actually_monotonic': evidence['evidence'][0]['excerpt'] = 'Rank r | val loss | BLEU\n1 | 1 | 5\n2 | 1 | 4\n3 | 1 | 3'
    elif case == 'proposal': data['claims'][0]['assertion_mode'] = 'proposal'
    assert not check_rank_table_trends(data, evidence)


@pytest.mark.parametrize('kind', ['table_reading', 'conclusion_summary', 'evaluation_protocol'])
def test_requirement_review_receives_actual_completion_checks_without_automatic_verdict(kind):
    ledger = {'requirements': [{'requirement_id': 'r1', 'answer_kind': kind, 'question_quote': '原问题'}]}
    request = review_request(ledger, {'claims': []})
    assert request['requirements'][0]['completion_checks']
    assert not request['semantic_auto_approval']
    assert request['requirements'][0]['eligible_claim_ids'] == []
