"""Offline acceptance tests for two real-session source-resilience bugs.

Observed on 2026-09-19 in live web runs:

A. HAL silently returned zero hits for every multi-word adapter query. HAL is
   Solr-backed and ANDs bare terms inside a field clause, so
   ``title_t:(LoRA QLoRA core differences)`` matched nothing even though
   ``title_t:(LoRA OR QLoRA)`` matches plenty. The fix joins terms with OR.

B. Zenodo failed with a deterministic DNS name-resolution error
   (``NameResolutionError ... getaddrinfo failed``) yet was retried every
   round, burning ~15 s per round (5 rounds = ~75 s) on an identical,
   guaranteed failure. After one such failure the source must be skipped for
   the remaining rounds of the task, leaving the round to the other sources.
"""
from __future__ import annotations

import os
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "deepdiver_v2") not in sys.path:
    sys.path.insert(0, str(ROOT / "deepdiver_v2"))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from deepdiver_v2.cli import demo  # noqa: E402
from deepdiver_v2.src import literature_sources  # noqa: E402

DNS_ERROR = (
    "HTTPSConnectionPool(host='zenodo.org', port=443): Max retries exceeded "
    "with url: /api/records?q=LoRA+QLoRA&size=3 (Caused by NameResolutionError("
    "\"HTTPSConnection(host='zenodo.org', port=443): Failed to resolve "
    "'zenodo.org' ([Errno 11004] getaddrinfo failed)\"))"
)


def _offline_config():
    return SimpleNamespace(
        get_custom_llm_config=lambda: {"url": "", "token": "", "timeout": 20},
        model_name="offline-test",
    )


class HalQueryConstructionTests(unittest.TestCase):
    """Problem A: the HAL adapter must not AND every free-text term."""

    class _FakeResponse:
        def __init__(self):
            self.status_code = 200
            self.content = b"{}"

        def json(self):
            return {"response": {"docs": []}}

    def test_multi_word_query_uses_or_clause(self):
        captured = {}

        def fake_request(source, url, **kwargs):
            captured.update(kwargs.get("params") or {})
            return self._FakeResponse()

        with mock.patch.object(literature_sources, "_request", side_effect=fake_request):
            papers = literature_sources._hal("LoRA QLoRA core differences", 3)
        self.assertEqual(papers, [])
        q = captured.get("q", "")
        self.assertIn("title_t:", q)
        # Bare terms are OR-joined inside the field clause.
        self.assertIn("LoRA OR QLoRA", q)
        self.assertNotIn("title_t:(LoRA QLoRA", q)

    def test_single_term_keeps_single_token_clause(self):
        captured = {}

        def fake_request(source, url, **kwargs):
            captured.update(kwargs.get("params") or {})
            return self._FakeResponse()

        with mock.patch.object(literature_sources, "_request", side_effect=fake_request):
            literature_sources._hal("world model", 3)
        self.assertIn("title_t:(world OR model)", captured.get("q", ""))


class DeterministicUnreachableSkipTests(unittest.TestCase):
    """Problem B: a DNS-failed source is skipped for the rest of the task."""

    def test_zenodo_not_retried_after_dns_failure(self):
        query = "LoRA 与 QLoRA 的核心差异是什么？"
        zenodo_calls = []
        hal_calls = []

        def fake_arxiv_search(search_query, max_results=5):
            return SimpleNamespace(
                success=True, data={"papers": []}, error=None,
                metadata={"warnings": []},
            )

        def fake_search_source(source, adapter_query, limit=3):
            if source == "zenodo":
                zenodo_calls.append(adapter_query)
                return {"status": "source_unreachable", "papers": [],
                        "error": DNS_ERROR}
            if source == "hal":
                hal_calls.append(adapter_query)
                return {"status": "ok", "papers": [], "error": None}
            # techrxiv healthy-but-empty; arxiv never goes through this path.
            return {"status": "ok", "papers": [], "error": None}

        tools = SimpleNamespace(
            arxiv_cooldown_remaining=None,
            arxiv_search=fake_arxiv_search,
        )

        with tempfile.TemporaryDirectory() as tmp:
            diag_path = Path(tmp) / "diagnostics.jsonl"
            env = {
                "SCIASSISTANT_DIAGNOSTICS_PATH": str(diag_path),
                "MODEL_REQUEST_URL": "",
                "MODEL_REQUEST_TOKEN": "",
            }
            with mock.patch.dict(demo.CONVERSATION_CONTEXT, {"status": "none"}, clear=True), \
                 mock.patch.dict(os.environ, env, clear=False), \
                 mock.patch.object(demo, "get_config", return_value=_offline_config()), \
                 mock.patch.object(demo, "search_source", side_effect=fake_search_source), \
                 mock.patch.object(demo, "source_skip_reason", return_value=""), \
                 mock.patch.object(demo, "put_literature_cache", return_value=None):
                _, diagnostics, _ = demo._search_relevant_literature(
                    query, "arxiv", tools, config=None
                )

        # The DNS failure is deterministic: zenodo is called exactly once.
        self.assertEqual(len(zenodo_calls), 1, f"zenodo calls: {zenodo_calls}")
        # HAL keeps getting real chances in every round.
        self.assertGreaterEqual(len(hal_calls), 2)
        rounds = diagnostics.get("rounds") or []
        zenodo_rounds = [item for item in rounds if item["source"] == "zenodo"]
        self.assertEqual(zenodo_rounds[0]["source_status"], "source_unreachable")
        for item in zenodo_rounds[1:]:
            self.assertEqual(item["source_status"], "skipped")
            self.assertIn("DNS/name-resolution", item.get("search_error") or "")
        # The skip is not aggregated as a source failure.
        self.assertFalse(diagnostics.get("search_failed"))


class DegradedAnswerPrefixTests(unittest.TestCase):
    """The degraded-answer caveat must name the source that actually failed."""

    def test_names_actual_failed_source_not_hardcoded_arxiv(self):
        diagnostics = {
            "degraded_answer": {
                "reason": "preferred_source_failed_partial_evidence",
                "source_failures": [
                    {"source": "zenodo", "status": "source_unreachable",
                     "error": DNS_ERROR},
                ],
            }
        }
        prefix = demo._degraded_answer_prefix(diagnostics, 1)
        self.assertIn("文献源（zenodo）本次检索不可用", prefix)
        self.assertIn("1 篇经完整证据核验后可用的论文", prefix)
        self.assertNotIn("arXiv）本次检索不可用", prefix)

    def test_multiple_failed_sources_are_all_named(self):
        diagnostics = {
            "degraded_answer": {
                "reason": "preferred_source_failed_partial_evidence",
                "source_failures": [
                    {"source": "zenodo", "status": "source_unreachable", "error": DNS_ERROR},
                    {"source": "techrxiv", "status": "access_blocked", "error": "403"},
                ],
            }
        }
        prefix = demo._degraded_answer_prefix(diagnostics, 2)
        self.assertIn("文献源（zenodo、techrxiv）本次检索不可用", prefix)

    def test_returns_empty_when_not_degraded_path(self):
        self.assertEqual(demo._degraded_answer_prefix({}, 1), "")


class RefusalCountConsistencyTests(unittest.TestCase):
    """Refusal wording must not contradict the per-source breakdown."""

    def _sufficiency(self, paper_count, minimum=2):
        return {
            "status": "insufficient_evidence",
            "paper_count": paper_count,
            "minimum_required": minimum,
            "notice": "检索到的论文不足以回答该问题。",
        }

    def test_gate_accepted_shown_when_ledger_is_zero(self):
        # The evidence ledger can end at 0 while a source passed the relevance
        # gate (fulltext/semantic admission later rejected the paper). The
        # wording must say "其中 1 篇通过相关性门控…账本可用 0 篇", never
        # "均未通过" next to a breakdown claiming 1 passed.
        diagnostics = {
            "relevance_threshold": 0.35,
            "rounds": [_round("hal", 15, 1, "ok")],
            "candidate_scores": [
                {"paper_id": "hal-1", "title": "A paper", "score": 0.5,
                 "lexical_accepted": True, "final_accepted": True,
                 "rejection_reason": None},
                {"paper_id": "hal-2", "title": "B paper", "score": 0.2,
                 "lexical_accepted": False, "final_accepted": False,
                 "rejection_reason": "below_threshold"},
            ],
        }
        text = demo._build_insufficient_evidence_answer(diagnostics, self._sufficiency(0))
        self.assertIn("15 篇候选文献，其中 1 篇通过相关性门控", text)
        self.assertIn("证据账本构建后可用 0 篇", text)
        self.assertNotIn("均未通过相关性门控", text)
        # The per-source line still reports the gate-level number.
        self.assertIn("1 篇通过相关性门控", text)

    def test_gate_count_uses_lexical_layer_when_semantic_rejected(self):
        # final_accepted is False (semantic/fulltext stage rejected the paper)
        # but the relevance gate itself admitted it; the breakdown claims
        # "1 篇通过相关性门控", so the head must not say "均未通过".
        diagnostics = {
            "relevance_threshold": 0.35,
            "rounds": [_round("hal", 15, 1, "ok")],
            "candidate_scores": [
                {"paper_id": "hal-1", "title": "A paper", "score": 0.55,
                 "lexical_accepted": True, "final_accepted": False,
                 "rejection_reason": "named_object_missing",
                 "rejection_stage": "semantic"},
            ],
        }
        text = demo._build_insufficient_evidence_answer(diagnostics, self._sufficiency(0))
        self.assertIn("其中 1 篇通过相关性门控", text)
        self.assertNotIn("均未通过相关性门控", text)

    def test_zero_gate_keeps_old_wording(self):
        diagnostics = {
            "relevance_threshold": 0.35,
            "rounds": [_round("hal", 5, 0, "ok")],
            "candidate_scores": [],
        }
        text = demo._build_insufficient_evidence_answer(diagnostics, self._sufficiency(0))
        self.assertIn("均未通过相关性门控", text)


class DiagnosticsSnapshotTests(unittest.TestCase):
    """Failed rounds must still persist query-side audit data."""

    def test_snapshot_records_plan_rounds_and_scores(self):
        captured = {}

        def fake_record(stage, status, *, reason="", source="", **details):
            captured["stage"] = stage
            captured["status"] = status
            captured["details"] = details

        diagnostics = {
            "query_plan": [{"query": "training data size world model", "type": "llm"}],
            "requested_concepts": ["world model"],
            "rounds": [
                {"round": 1, "source": "hal", "adapter_query": "title_t:(training OR data)",
                 "returned": 15, "accepted_total": 1, "max_score": 0.5,
                 "source_status": "ok", "search_error": ""},
            ],
            "candidate_scores": [
                {"paper_id": "hal-1", "title": "A" * 200, "score": 0.5,
                 "final_accepted": True, "rejection_reason": None, "rejection_stage": None},
            ],
        }
        with mock.patch.object(demo, "record_diagnostic", side_effect=fake_record):
            demo._record_search_diagnostics_snapshot(diagnostics)
        self.assertEqual(captured["stage"], "search_diagnostics_snapshot")
        detail = captured["details"]
        self.assertEqual(detail["query_plan"][0]["query"], "training data size world model")
        self.assertEqual(detail["rounds"][0]["adapter_query"], "title_t:(training OR data)")
        self.assertEqual(detail["candidate_scores"][0]["paper_id"], "hal-1")
        # Long titles are truncated, not dropped.
        self.assertLessEqual(len(detail["candidate_scores"][0]["title"]), 120)
        # An empty diagnostics payload must not raise or emit anything.
        demo._record_search_diagnostics_snapshot(None)


def _round(source, returned, accepted, status, error="", skip_reason="", adapter_query="adapter-q"):
    item = {
        "round": 1, "source": source, "query": "q", "adapter_query": adapter_query,
        "returned": returned, "max_score": 0.4 if accepted else 0.1,
        "accepted_total": accepted, "source_status": status,
    }
    if error:
        item["search_error"] = error
    if skip_reason:
        item["skip_reason"] = skip_reason
    return item


class ArxivCooldownSkipTests(unittest.TestCase):
    """An active arXiv cooldown must skip the round, not re-report an error."""

    def test_arxiv_rounds_skipped_while_cooldown_active(self):
        query = "世界模型在自动驾驶中的应用主要面临哪些挑战？"
        arxiv_search_calls = []
        hal_calls = []

        def fake_arxiv_search(search_query, max_results=5):
            arxiv_search_calls.append(search_query)
            return SimpleNamespace(success=True, data={"papers": []}, error=None,
                                   metadata={"warnings": []})

        def fake_search_source(source, adapter_query, limit=3):
            if source == "hal":
                hal_calls.append(adapter_query)
                return {"status": "ok", "papers": [], "error": None}
            return {"status": "ok", "papers": [], "error": None}

        tools = SimpleNamespace(
            arxiv_cooldown_remaining=lambda: 5.0,
            arxiv_search=fake_arxiv_search,
        )

        with tempfile.TemporaryDirectory() as tmp:
            diag_path = Path(tmp) / "diagnostics.jsonl"
            env = {
                "SCIASSISTANT_DIAGNOSTICS_PATH": str(diag_path),
                "MODEL_REQUEST_URL": "",
                "MODEL_REQUEST_TOKEN": "",
            }
            with mock.patch.dict(demo.CONVERSATION_CONTEXT, {"status": "none"}, clear=True), \
                 mock.patch.dict(os.environ, env, clear=False), \
                 mock.patch.object(demo, "get_config", return_value=_offline_config()), \
                 mock.patch.object(demo, "search_source", side_effect=fake_search_source), \
                 mock.patch.object(demo, "source_skip_reason", return_value=""):
                _, diagnostics, _ = demo._search_relevant_literature(
                    query, "arxiv", tools, config=None
                )

        # arXiv never touched the network while its cooldown was active.
        self.assertEqual(arxiv_search_calls, [], f"calls: {arxiv_search_calls}")
        rounds = diagnostics.get("rounds") or []
        arxiv_rounds = [item for item in rounds if item["source"] == "arxiv"]
        self.assertGreaterEqual(len(arxiv_rounds), 2)
        for item in arxiv_rounds:
            self.assertEqual(item["source_status"], "cooling_skip")
            self.assertIn("cooldown", item.get("skip_reason") or "")
        # Other sources still get their real chances.
        self.assertGreaterEqual(len(hal_calls), 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
