"""Deployment regressions for container resource and privilege boundaries."""

from pathlib import Path

import yaml


ROOT = Path(__file__).resolve().parents[1]


def _compose(name):
    return yaml.safe_load((ROOT / name).read_text(encoding="utf-8"))


def _assert_python_hardening(service):
    assert service["user"] == "10001:10001"
    assert service["init"] is True
    assert service["read_only"] is True
    assert service["cap_drop"] == ["ALL"]
    assert service["security_opt"] == ["no-new-privileges:true"]
    assert service["tmpfs"] == ["/tmp:rw,noexec,nosuid,nodev,size=256m,mode=1777"]
    assert service["logging"] == {
        "driver": "json-file", "options": {"max-size": "10m", "max-file": "5"},
    }


def _assert_resource_limits(service, prefix, *, grace_period=None):
    assert service["mem_limit"].startswith(f"${{{prefix}_MEMORY_LIMIT:-")
    assert service["cpus"].startswith(f"${{{prefix}_CPU_LIMIT:-")
    assert service["pids_limit"].startswith(f"${{{prefix}_PIDS_LIMIT:-")
    if grace_period:
        assert service["stop_grace_period"] == grace_period


def test_account_python_services_are_non_root_read_only_and_capability_free():
    services = _compose("docker-compose.account.cloud.yml")["services"]
    for name in ("sciassistant-account", "mcp", "schema-provision", "schema-migrate"):
        _assert_python_hardening(services[name])


def test_account_stack_has_bounded_resources_and_log_rotation():
    services = _compose("docker-compose.account.cloud.yml")["services"]
    _assert_resource_limits(services["sciassistant-account"], "ACCOUNT", grace_period="45s")
    _assert_resource_limits(services["mcp"], "MCP", grace_period="30s")
    _assert_resource_limits(services["schema-provision"], "SCHEMA")
    _assert_resource_limits(services["schema-migrate"], "SCHEMA")
    _assert_resource_limits(services["database"], "MYSQL", grace_period="60s")
    assert services["database"]["logging"]["options"] == {"max-size": "10m", "max-file": "5"}


def test_read_only_services_have_only_explicit_writable_state_and_tmpfs():
    services = _compose("docker-compose.account.cloud.yml")["services"]
    assert set(services["sciassistant-account"]["volumes"]) == {
        "sciassistant_logs:/app/logs", "sciassistant_uploads:/app/uploads",
        "sciassistant_user_files:/app/user_files", "sciassistant_web_uploads:/app/web_uploads",
        "sciassistant_arxiv:/app/arxiv",
    }
    assert set(services["mcp"]["volumes"]) == {
        "sciassistant_logs:/app/logs", "sciassistant_arxiv:/app/arxiv",
    }
    for name in ("schema-provision", "schema-migrate"):
        assert "volumes" not in services[name]


def test_research_only_stack_is_loopback_and_hardened():
    services = _compose("docker-compose.cloud.yml")["services"]
    web = services["sciassistant-web"]
    assert web["env_file"] == ["${SCIASSISTANT_ENV_FILE:-.env}"]
    assert services["mcp"]["env_file"] == ["${SCIASSISTANT_ENV_FILE:-.env}"]
    assert web["ports"] == ["127.0.0.1:${RESEARCH_HOST_PORT:-5050}:5050"]
    assert "5050:5050" not in web["ports"]
    for name in ("sciassistant-web", "mcp"):
        _assert_python_hardening(services[name])
    assert (web["mem_limit"], web["cpus"], web["pids_limit"], web["stop_grace_period"]) == (
        "2g", 2.0, 256, "45s")
    assert (services["mcp"]["mem_limit"], services["mcp"]["cpus"],
            services["mcp"]["pids_limit"], services["mcp"]["stop_grace_period"]) == (
        "2g", 2.0, 256, "30s")


def test_examples_publish_secure_resource_defaults():
    account = (ROOT / ".env.account.cloud.example").read_text(encoding="utf-8")
    development = (ROOT / ".env.example").read_text(encoding="utf-8")
    for line in (
        "ACCOUNT_MEMORY_LIMIT=2g", "ACCOUNT_CPU_LIMIT=2.0", "ACCOUNT_PIDS_LIMIT=256",
        "MCP_MEMORY_LIMIT=2g", "MCP_CPU_LIMIT=2.0", "MCP_PIDS_LIMIT=256",
        "MYSQL_MEMORY_LIMIT=1g", "MYSQL_CPU_LIMIT=1.0", "MYSQL_PIDS_LIMIT=256",
        "SCHEMA_MEMORY_LIMIT=256m", "SCHEMA_CPU_LIMIT=0.5", "SCHEMA_PIDS_LIMIT=64",
    ):
        assert line in account
    for line in (
        "SCIASSISTANT_ENV_FILE=.env",
        "RESEARCH_HOST_PORT=5050",
    ):
        assert line in development
