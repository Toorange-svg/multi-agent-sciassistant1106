"""Offline process-tree fixture. No network, credentials or model calls."""
import subprocess
import os
import sys
import time
from pathlib import Path

root = Path(sys.argv[1])
depth = int(sys.argv[2])
(root / f"pid-{depth}.txt").write_text(str(os.getpid()))
if depth:
    subprocess.Popen([sys.executable, __file__, str(root), str(depth - 1)],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
while True:
    with (root / f"beat-{depth}.txt").open("a") as handle:
        handle.write("heartbeat\n")
    time.sleep(0.03)
