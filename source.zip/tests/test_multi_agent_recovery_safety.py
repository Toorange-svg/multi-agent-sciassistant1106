from __future__ import annotations

import copy
import json

import pytest

from multi_agent_pipeline_v2 import LiteraturePipelineV2, ReviewContractError, check_review
from multi_agent_report import export_run_report
from test_multi_agent_pipeline_v2 import agents, pipeline


def test_recovery_retains_immutable_approved_excerpts_within_budget():
    def records(prefix):
        return [{"evidence_id": f"{prefix}{i}", "group_id": f"g{i % 3}", "excerpt": "original evidence"}
                for i in range(12)]
    initial = {"evidence": records("old")}
    recovered = {"evidence": records("new") + [dict(initial["evidence"][11], excerpt="changed unreviewed text")]}
    retained = ["old2", "old5", "old8", "old11"]
    merged = LiteraturePipelineV2._merge_evidence(initial, recovered, retained_evidence_ids=retained)
    assert len(merged["evidence"]) <= 12
    by_id = {item["evidence_id"]: item for item in merged["evidence"]}
    assert set(retained).issubset(by_id)
    assert all(by_id[key]["excerpt"] == "original evidence" for key in retained)
    assert sum(item["group_id"] == "g2" for item in merged["evidence"]) <= 5
    assert any(item["evidence_id"].startswith("new") for item in merged["evidence"])


def test_recovery_bad_review_uses_only_prior_valid_approval(tmp_path):
    configured, calls = agents()
    reviews = []
    def reviewer(packet):
        reviews.append(1)
        return {"output": {"coverage_status": "partial",
            "allowed_evidence_ids": ["arxiv-1"] if len(reviews) == 1 else ["arxiv-2"],
            "conflicts": [], "coverage": [{"group_id": "g1", "status": "partial",
                                           "evidence_ids": ["arxiv-1"]}]}}
    def writer(packet):
        evidence = next(item["payload"]["evidence"] for item in packet["inputs"] if "evidence" in item["payload"])
        assert [item["evidence_id"] for item in evidence] == ["arxiv-1"]
        assert "UNAPPROVED_CANARY" not in json.dumps(packet)
        return {"output": {"direct_answer": "限定结论", "claims": [
            {"claim_id": "c1", "text": "限定结论", "evidence_ids": ["arxiv-1"]}]}}
    configured.reviewer.handler = reviewer
    configured.writer.handler = writer
    flow, _ = pipeline(tmp_path, configured, search=lambda *_: {"status": "ok", "papers": [
        {"paper_id": "1", "title": "Approved", "abstract": "Reliable evidence"},
        {"paper_id": "2", "title": "Rejected", "abstract": "UNAPPROVED_CANARY"}]})
    result = flow.run("run-1", "owner-1", "question")
    assert result["run"]["status"] == "needs_review"
    assert result["run"]["failure_code"] is None
    assert result["run"]["model_calls_used"] == 8
    assert calls.count("gap_analyst") == 1 and calls.count("retriever") == 2
    assert "首轮批准证据" not in result["direct_answer"] and "限定结论" in result["direct_answer"]
    events = [json.loads(line) for line in (tmp_path / "events.jsonl").read_text(encoding="utf-8").splitlines()]
    rejected = next(item for item in events if item["event"] == "recovery_review_rejected")
    assert rejected["reason_code"] == "REVIEW_COVERAGE_UNAPPROVED_EVIDENCE"
    assert list((tmp_path / "artifacts").glob("rejected-evidence-review-*.json"))
    export_run_report(tmp_path)
    exported = (tmp_path / "final_answer.html").read_text(encoding="utf-8")
    assert "首轮批准证据" in exported.split('<section id="answer">')[0]
    assert "首轮批准证据" not in exported.split('<section id="answer">')[1].split('</section>')[0]
    assert [item["evidence_id"] for item in json.loads((tmp_path / "references.json").read_text(encoding="utf-8"))] == ["arxiv-1"]


def test_bad_initial_review_remains_rejected_without_fallback(tmp_path):
    configured, calls = agents()
    configured.reviewer.handler = lambda _: {"output": {"coverage_status": "partial",
        "allowed_evidence_ids": ["invented"], "coverage": [], "conflicts": []}}
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("run-1", "owner-1", "question")
    assert result["run"]["status"] == "failed"
    assert result["run"]["failure_code"] == "REVIEW_APPROVED_EVIDENCE_UNKNOWN"
    assert "writer" not in calls
    export_run_report(tmp_path)
    assert json.loads((tmp_path / "references.json").read_text(encoding="utf-8")) == []
    assert "参考文献" not in (tmp_path / "final_answer.md").read_text(encoding="utf-8")


def test_no_prior_approved_evidence_cannot_enable_fallback(tmp_path):
    configured, calls = agents(recovery=True)
    seen = []
    def reviewer(_packet):
        seen.append(1)
        return {"output": {"coverage_status": "insufficient", "allowed_evidence_ids": [],
            "conflicts": [], "coverage": [] if len(seen) == 1 else [
                {"group_id": "g1", "status": "partial", "evidence_ids": ["arxiv-1"]}]}}
    configured.reviewer.handler = reviewer
    flow, _ = pipeline(tmp_path, configured)
    result = flow.run("run-1", "owner-1", "question")
    assert result["run"]["status"] == "failed"
    assert result["run"]["failure_code"] == "REVIEW_COVERAGE_UNAPPROVED_EVIDENCE"
    assert "writer" not in calls


def test_review_validation_does_not_mutate_raw_role_output():
    raw = {"coverage_status": "partial", "allowed_evidence_ids": ["e1"], "conflicts": [],
           "coverage": [{"group_id": "g1", "status": "not_reported", "evidence_ids": []}]}
    before = copy.deepcopy(raw)
    result = check_review(raw, {"evidence": [{"evidence_id": "e1"}]}, {"g1"})
    assert raw == before and result["coverage"][0]["status"] == "missing"


@pytest.mark.parametrize("bad_ids", [[{}], "e1"])
def test_malformed_coverage_ids_have_safe_diagnostic_code(bad_ids):
    with pytest.raises(ReviewContractError) as raised:
        check_review({"coverage_status": "partial", "allowed_evidence_ids": ["e1"], "conflicts": [],
                      "coverage": [{"group_id": "g1", "status": "partial", "evidence_ids": bad_ids}]},
                     {"evidence": [{"evidence_id": "e1"}]}, {"g1"})
    assert raised.value.code == "REVIEW_COVERAGE_IDS_INVALID"
