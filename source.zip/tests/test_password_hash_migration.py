"""Modern password storage and transparent legacy-hash migration."""

import hashlib
import re
from contextlib import nullcontext
from unittest import mock

import pytest
from werkzeug.security import generate_password_hash

import app as gateway
from request_limits import SlidingWindowLimiter


class AuthCursor:
    def __init__(self, connection):
        self.connection = connection
        self.rowcount = 0
        self._result = None

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def execute(self, sql, params=()):
        normalized = " ".join(sql.split()).lower()
        self.connection.statements.append((normalized, params))
        self.rowcount = 0
        if normalized.startswith("select id, username, password, auth_version from users"):
            self._result = self.connection.user
        elif normalized.startswith("select password from users where id"):
            self._result = ({"password": self.connection.current_password}
                            if self.connection.current_password is not None else None)
        elif normalized.startswith("update users set password"):
            self.connection.upgrade_value = params[0]
            self.connection.upgrade_expected = params[2]
            self.rowcount = self.connection.update_rowcount
            if self.rowcount == 1:
                self.connection.current_password = params[0]
        elif normalized.startswith("select id from users"):
            self._result = None
        elif normalized.startswith("insert into users"):
            self.connection.inserted_password = params[2]

    def fetchone(self):
        return self._result


class AuthConnection:
    def __init__(self, user=None, *, update_rowcount=1, current_password=None):
        self.user = user
        self.update_rowcount = update_rowcount
        self.current_password = current_password
        self.statements = []
        self.upgrade_value = None
        self.upgrade_expected = None
        self.inserted_password = None
        self.commits = 0
        self.rollbacks = 0
        self.closed = False

    def cursor(self):
        return AuthCursor(self)

    def commit(self):
        self.commits += 1

    def rollback(self):
        self.rollbacks += 1

    def close(self):
        self.closed = True


@pytest.fixture(autouse=True)
def isolated_auth_limiter():
    with mock.patch.object(gateway, "_AUTH_RATE_LIMITER", SlidingWindowLimiter(max_keys=1000)):
        yield


def _login(connection, password="correct horse battery staple"):
    with mock.patch.object(gateway, "get_db_connection", return_value=connection):
        return gateway.app.test_client().post(
            "/api/login",
            json={"loginId": "migration-user", "password": password},
        )


def test_new_hashes_are_scrypt_salted_and_verify():
    first = gateway.hash_password("a sufficiently long password")
    second = gateway.hash_password("a sufficiently long password")
    assert first.startswith(gateway.PASSWORD_HASH_METHOD + "$")
    assert first != second
    assert len(first) <= 255
    assert gateway.verify_password("a sufficiently long password", first) == (True, False)
    assert gateway.verify_password("wrong", first) == (False, False)


def test_legacy_sha256_is_verification_only_and_requests_upgrade():
    password = "legacy-password"
    legacy = hashlib.sha256(password.encode()).hexdigest()
    assert gateway.verify_password(password, legacy) == (True, True)
    assert gateway.verify_password("wrong", legacy) == (False, False)
    assert gateway.hash_password(password) != legacy


@pytest.mark.parametrize("stored", [None, "", "sha256$bad", "A" * 64, "scrypt:not-valid"])
def test_unknown_or_malformed_hashes_fail_closed(stored):
    assert gateway.verify_password("password", stored) == (False, False)


def test_changed_scrypt_parameters_are_accepted_and_rehashed():
    old = generate_password_hash("password", method="scrypt:16384:8:1")
    assert gateway.verify_password("password", old) == (True, True)


def test_legacy_login_atomically_upgrades_before_issuing_token():
    password = "correct horse battery staple"
    legacy = hashlib.sha256(password.encode()).hexdigest()
    connection = AuthConnection({"id": 17, "username": "migration-user", "password": legacy})
    response = _login(connection, password)
    assert response.status_code == 200
    assert response.get_json()["data"]["token"]
    assert connection.upgrade_expected == legacy
    assert connection.upgrade_value.startswith(gateway.PASSWORD_HASH_METHOD + "$")
    assert gateway.verify_password(password, connection.upgrade_value) == (True, False)
    assert connection.commits == 1 and connection.rollbacks == 0 and connection.closed


def test_modern_login_does_not_rewrite_hash():
    modern = gateway.hash_password("correct horse battery staple")
    connection = AuthConnection({"id": 18, "username": "migration-user", "password": modern})
    response = _login(connection)
    assert response.status_code == 200
    assert connection.upgrade_value is None
    assert connection.commits == 0


def test_failed_compare_and_swap_rechecks_concurrent_modern_hash():
    password = "correct horse battery staple"
    legacy = hashlib.sha256(password.encode()).hexdigest()
    current = gateway.hash_password(password)
    connection = AuthConnection(
        {"id": 19, "username": "migration-user", "password": legacy},
        update_rowcount=0,
        current_password=current,
    )
    response = _login(connection, password)
    assert response.status_code == 200
    assert connection.rollbacks == 1 and connection.commits == 0


def test_failed_compare_and_swap_rejects_a_concurrent_password_change():
    password = "correct horse battery staple"
    legacy = hashlib.sha256(password.encode()).hexdigest()
    current = gateway.hash_password("a new password")
    connection = AuthConnection(
        {"id": 20, "username": "migration-user", "password": legacy},
        update_rowcount=0,
        current_password=current,
    )
    response = _login(connection, password)
    assert response.status_code == 401
    assert "token" not in response.get_data(as_text=True)
    assert connection.rollbacks == 1


def test_wrong_legacy_password_never_updates_or_issues_token():
    legacy = hashlib.sha256(b"right password").hexdigest()
    connection = AuthConnection({"id": 21, "username": "migration-user", "password": legacy})
    response = _login(connection, "wrong password")
    assert response.status_code == 401
    assert connection.upgrade_value is None
    assert "token" not in response.get_data(as_text=True)


def test_registration_writes_only_modern_hash():
    connection = AuthConnection()
    with mock.patch.object(gateway, "get_db_connection", return_value=connection):
        response = gateway.app.test_client().post("/api/register", json={
            "username": "new-user",
            "email": "new-user@example.org",
            "password": "new-user-password",
            "confirmPassword": "new-user-password",
        })
    assert response.status_code == 200
    assert connection.inserted_password.startswith(gateway.PASSWORD_HASH_METHOD + "$")
    assert gateway.verify_password("new-user-password", connection.inserted_password) == (True, False)


@pytest.mark.parametrize("path,payload", [
    ("/api/login", {"loginId": "user", "password": "x" * (gateway.PASSWORD_MAX_LENGTH + 1)}),
    ("/api/register", {
        "username": "user", "email": "user@example.org",
        "password": "x" * (gateway.PASSWORD_MAX_LENGTH + 1),
        "confirmPassword": "x" * (gateway.PASSWORD_MAX_LENGTH + 1),
    }),
])
def test_oversized_password_is_rejected_before_database(path, payload):
    with mock.patch.object(gateway, "get_db_connection") as database:
        response = gateway.app.test_client().post(path, json=payload)
    assert response.status_code in (400, 401)
    database.assert_not_called()


def test_cloud_schema_can_hold_current_password_hash():
    schema = (gateway.BASE_DIR / "deploy" / "mysql-init" / "001_schema.sql").read_text(encoding="utf-8")
    width = int(re.search(r"`password`\s+varchar\((\d+)\)", schema, re.IGNORECASE).group(1))
    assert width >= len(gateway.hash_password("schema-check"))
