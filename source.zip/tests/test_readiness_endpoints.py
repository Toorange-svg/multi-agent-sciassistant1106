"""Regression coverage for public-safe liveness and readiness endpoints."""
from unittest import mock

import app as account_app
import web_app


def test_gateway_readyz_reports_database_ready_without_leaking_details():
    connection = mock.MagicMock()
    cursor = connection.cursor.return_value.__enter__.return_value
    with mock.patch.object(account_app, "get_db_connection", return_value=connection), \
            mock.patch.object(account_app, "has_minimum_free_space", return_value=True):
        response = account_app.app.test_client().get("/api/readyz")
    assert response.status_code == 200
    assert response.get_json() == {"status": "ready", "components": {
        "database": "ready", "runtime_storage": "ready"
    }}
    cursor.execute.assert_called_once_with("SELECT 1")
    connection.close.assert_called_once()


def test_gateway_readyz_fails_closed_when_database_is_unavailable():
    with mock.patch.object(account_app, "get_db_connection", side_effect=RuntimeError("canary")), \
            mock.patch.object(account_app, "has_minimum_free_space", return_value=True):
        response = account_app.app.test_client().get("/api/readyz")
    assert response.status_code == 503
    assert response.get_json() == {"status": "not_ready", "components": {
        "database": "unavailable", "runtime_storage": "ready"
    }}
    assert "canary" not in response.get_data(as_text=True)


def test_research_readyz_reports_all_dependencies_ready(monkeypatch, tmp_path):
    monkeypatch.setattr(web_app, "TASK_STATE_DIR", tmp_path)
    with mock.patch.object(web_app, "check_shared_mcp"), \
            mock.patch.object(web_app, "has_minimum_free_space", return_value=True):
        response = web_app.app.test_client().get("/api/readyz")
    assert response.status_code == 200
    assert response.get_json() == {
        "status": "ready",
        "components": {"task_state": "ready", "runtime_storage": "ready", "shared_mcp": "ready"},
    }


def test_research_readyz_fails_closed_for_shared_mcp(monkeypatch, tmp_path):
    monkeypatch.setattr(web_app, "TASK_STATE_DIR", tmp_path)
    with mock.patch.object(
        web_app, "check_shared_mcp", side_effect=web_app.ResearchDependencyError("internal")
    ), mock.patch.object(web_app, "has_minimum_free_space", return_value=True):
        response = web_app.app.test_client().get("/api/readyz")
    assert response.status_code == 503
    assert response.get_json() == {
        "status": "not_ready",
        "components": {"task_state": "ready", "runtime_storage": "ready", "shared_mcp": "unavailable"},
    }


def test_gateway_readyz_fails_closed_when_runtime_storage_is_unavailable():
    with mock.patch.object(account_app, "has_minimum_free_space", return_value=False), \
            mock.patch.object(account_app, "get_db_connection") as connect:
        response = account_app.app.test_client().get("/api/readyz")
    assert response.status_code == 503
    assert response.get_json() == {"status": "not_ready", "components": {
        "database": "not_checked", "runtime_storage": "unavailable"
    }}
    connect.assert_not_called()


def test_research_readyz_fails_closed_when_runtime_storage_is_unavailable(monkeypatch, tmp_path):
    monkeypatch.setattr(web_app, "TASK_STATE_DIR", tmp_path)
    with mock.patch.object(web_app, "has_minimum_free_space", return_value=False), \
            mock.patch.object(web_app, "check_shared_mcp"):
        response = web_app.app.test_client().get("/api/readyz")
    assert response.status_code == 503
    assert response.get_json() == {"status": "not_ready", "components": {
        "task_state": "ready", "runtime_storage": "unavailable", "shared_mcp": "ready"
    }}
