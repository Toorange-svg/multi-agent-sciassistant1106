"""MCP error-boundary and ordinary-log redaction regressions."""

import asyncio
import json
import os
from pathlib import Path
import socket
import subprocess
import sys

from starlette.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "deepdiver_v2"))
from src.tools import mcp_server_standard as server


CANARY = r"mcp-secret-canary token=plain-secret C:\Users\private\secret.txt /tmp/private/secret.txt"


def _configure_app(monkeypatch, tmp_path):
    monkeypatch.delenv("MCP_SHARED_SECRET", raising=False)
    monkeypatch.setattr(server, "config", server.ServerConfig(
        host="127.0.0.1",
        base_workspace_dir=str(tmp_path / "workspaces"),
    ))
    return server.create_app()


def test_invalid_json_and_internal_request_failure_do_not_echo_exception(monkeypatch, tmp_path):
    app = _configure_app(monkeypatch, tmp_path)
    with TestClient(app) as client:
        malformed = client.post("/mcp", content=b'{"jsonrpc":', headers={"Content-Type": "application/json"})
        assert malformed.status_code == 200
        assert "Invalid JSON" in malformed.text
        assert "line 1 column" not in malformed.text

        class FailingManager:
            async def get_or_create_session(self, _session_id):
                raise RuntimeError(CANARY)

        monkeypatch.setattr(server, "session_manager", FailingManager())
        failed = client.post("/mcp", json={"jsonrpc": "2.0", "id": 7, "method": "initialize"})
        assert failed.status_code == 200
        assert "Internal server error" in failed.text
        assert "mcp-secret-canary" not in failed.text
        assert "private" not in failed.text


def test_tool_exception_returns_fixed_contract_and_tracker_receives_no_secret(monkeypatch):
    monkeypatch.setattr(server, "config", server.ServerConfig())
    monkeypatch.setattr(server, "global_tool_rate_limiter", None)

    class Tracker:
        logged = None

        def log_tool_call(self, **kwargs):
            self.logged = kwargs

    class ExplodingTools:
        def explode(self):
            raise RuntimeError(CANARY)

    tracker = Tracker()

    class Session:
        id = "session-safe"
        request_count = 1
        workspace_path = Path("relative-workspace")

        def touch(self):
            return None

        def get_mcp_tools(self, prefer_async=True):
            return ExplodingTools()

        def get_tool_tracker(self):
            return tracker

    result = asyncio.run(server._call_session_tool_async(Session(), "explode", {}))
    assert result == {
        "success": False,
        "error": "Tool execution failed",
        "error_code": "TOOL_EXECUTION_FAILED",
        "data": None,
    }
    serialized = json.dumps(tracker.logged)
    assert "mcp-secret-canary" not in serialized
    assert tracker.logged["error_details"] == "TOOL_EXECUTION_FAILED"


def test_declared_tool_failure_redacts_credentials_and_common_absolute_paths(monkeypatch):
    monkeypatch.setattr(server, "config", server.ServerConfig())
    monkeypatch.setattr(server, "global_tool_rate_limiter", None)

    class Tools:
        def fail_safely(self):
            return {"success": False, "error": CANARY}

    class Session:
        id = "session-safe"
        request_count = 1

        def touch(self):
            return None

        def get_mcp_tools(self, prefer_async=True):
            return Tools()

        def get_tool_tracker(self):
            return None

    result = asyncio.run(server._call_session_tool_async(Session(), "fail_safely", {}))
    assert result["success"] is False
    assert "plain-secret" not in result["error"]
    assert "Users" not in result["error"]
    assert "/tmp/private" not in result["error"]
    assert "token=[REDACTED]" in result["error"]
    assert result["error"].count("[REDACTED_PATH]") == 2


def test_rate_limit_diagnostic_failure_is_fixed(monkeypatch, tmp_path):
    app = _configure_app(monkeypatch, tmp_path)

    class FailingLimiter:
        async def get_all_stats(self):
            raise RuntimeError(CANARY)

    monkeypatch.setattr(server, "global_tool_rate_limiter", FailingLimiter())
    with TestClient(app) as client:
        response = client.get("/rate-limits")
    assert response.status_code == 500
    assert response.json() == {"error": "RATE_LIMIT_STATS_UNAVAILABLE"}
    assert "mcp-secret-canary" not in response.text


def test_sse_serialization_failure_has_fixed_message():
    response = server.create_sse_response({"jsonrpc": "2.0", "id": 9, "result": object()})

    async def read_body():
        parts = []
        async for part in response.body_iterator:
            parts.append(part.decode() if isinstance(part, bytes) else part)
        return "".join(parts)

    body = asyncio.run(read_body())
    assert "Internal server error" in body
    assert "not JSON serializable" not in body
    assert "object at 0x" not in body


def test_real_startup_failure_is_fixed_and_has_no_traceback(tmp_path):
    with socket.socket() as occupied:
        occupied.bind(("127.0.0.1", 0))
        occupied.listen()
        port = occupied.getsockname()[1]
        private_workspace = tmp_path / "private-workspace-canary"
        environment = {
            **os.environ,
            "PYTHONUTF8": "1",
            "MCP_SERVER_LOG_PATH": str(tmp_path / "mcp.log"),
        }
        environment.pop("MCP_SHARED_SECRET", None)
        completed = subprocess.run(
            [
                sys.executable,
                str(ROOT / "deepdiver_v2/src/tools/mcp_server_standard.py"),
                "--host", "127.0.0.1",
                "--port", str(port),
                "--workspace-dir", str(private_workspace),
            ],
            cwd=ROOT,
            env=environment,
            capture_output=True,
            text=True,
            timeout=15,
        )
    output = completed.stdout + completed.stderr
    assert completed.returncode == 1
    assert "MCP_SERVER_STARTUP_FAILED" in output
    assert "Traceback" not in output
    assert str(private_workspace) not in output


def test_source_has_no_raw_exception_response_or_traceback_logging():
    source = (ROOT / "deepdiver_v2/src/tools/mcp_server_standard.py").read_text(encoding="utf-8")
    forbidden = (
        'content={"error": str(e)}',
        'f"Internal server error: {str(e)}"',
        'f"Internal error: {str(e)}"',
        "traceback.format_exc()",
        "traceback.print_exc()",
    )
    for fragment in forbidden:
        assert fragment not in source
