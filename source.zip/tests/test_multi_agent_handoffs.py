"""Typed role contracts, bounded routing and claim-isolated model input."""
from copy import deepcopy
import json
import pytest
from multi_agent_handoffs import (PLAN_SCHEMA, AUDIT_JOB_POLICY, plan_handoff_issues,
    evidence_need_contract, route_need_titles, need_flow_snapshot, project_audit_packet, compile_search_plan)
from multi_agent_quality import scope_plan_to_question, answer_requirements, citation_audit_input
from multi_agent_live import normalize_live_result
from multi_agent_agents import AgentContractError
from test_multi_agent_report_fields import draft, evidence

QUESTION = 'DETR、SAM、CLIP有什么帮助？请提出可证伪实验。'


def typed_plan():
    return {'schema_version': PLAN_SCHEMA, 'groups': [
        {'id': 'g1', 'kind': 'research', 'question_quote': 'DETR、SAM、CLIP有什么帮助？',
         'question': 'Definitions', 'core': ['DETR', 'SAM', 'CLIP'], 'support': [],
         'metrics': ['definition'], 'queries': ['DETR definition', 'SAM CLIP combined'],
         'evidence_needs': [{'entity': e, 'question_quote': e, 'aspect': 'definition', 'source_title': t}
            for e,t in [('DETR','End to End Object Detection'), ('SAM','Segment Anything'), ('CLIP','Learning Transferable Visual Models')]]},
        {'id': 'g2', 'kind': 'report', 'question_quote': '请提出可证伪实验。',
         'question': 'experimental design without magic keywords',
         'core': [], 'support': [], 'metrics': [], 'queries': [], 'evidence_needs': []}],
         'premise_checks': []}


def requests():
    return [{'request_id': f'r{i}', 'action': 'request_arxiv_search',
             'arguments': {'group_id': 'g1', 'query': q}}
            for i,q in enumerate(['DETR original', 'SAM CLIP combined'])]


def test_typed_plan_moves_report_by_kind_not_vocabulary_and_preserves_raw():
    raw = typed_plan(); before = deepcopy(raw)
    assert not plan_handoff_issues(raw, QUESTION)
    plan, diagnostics = scope_plan_to_question(raw, answer_requirements(QUESTION))
    assert [g['id'] for g in plan['groups']] == ['g1']
    assert plan['report_obligations'][0]['question'] == 'experimental design without magic keywords'
    assert diagnostics['delivery_group_changes'] and raw == before
    assert len(evidence_need_contract(plan)['needs']) == 3


@pytest.mark.parametrize('field,value', [('kind', 'other'), ('kind', []),
    ('question_quote', 'not in question'), ('evidence_needs', []), ('evidence_needs', None)])
def test_invalid_typed_handoff_is_rejected(field, value):
    raw = typed_plan(); raw['groups'][0][field] = value
    assert plan_handoff_issues(raw, QUESTION)


@pytest.mark.parametrize('field,value', [('question_quote','not in current question'), ('aspect','recommendation'),
    ('aspect', []), ('source_title','https://example.test'), ('source_title','x'*201)])
def test_entity_and_evidence_need_permissions(field, value):
    raw = typed_plan(); raw['groups'][0]['evidence_needs'][0][field] = value
    assert plan_handoff_issues(raw, QUESTION)


@pytest.mark.parametrize('field', ['queries','core','support','metrics','evidence_needs'])
def test_report_instruction_cannot_request_search(field):
    raw = typed_plan(); raw['groups'][1][field] = ['search']
    assert plan_handoff_issues(raw, QUESTION)


def test_cannot_expand_a_user_statement_with_an_invented_belief():
    raw = typed_plan(); raw['premise_checks'] = [{'origin': 'user_statement',
        'question_quote': 'DETR、SAM、CLIP有什么帮助？', 'assumption': 'User asserts no training needed'}]
    assert any(i['reason'] == 'USER_STATEMENT_MUST_BE_LITERAL_NOT_EXPANDED' for i in plan_handoff_issues(raw, QUESTION))
    raw['premise_checks'][0]['assumption'] = raw['premise_checks'][0]['question_quote']
    assert not plan_handoff_issues(raw, QUESTION)


def test_live_current_plan_does_not_downgrade_to_legacy():
    old = {'output': {'schema_version':'sciassistant.research-plan/v2','groups':[{'id':'g1'}]}}
    assert normalize_live_result('planner', old)['output']['groups']
    with pytest.raises(AgentContractError):
        normalize_live_result('planner', old, require_current=True)
    current = typed_plan()
    with pytest.raises(AgentContractError):
        normalize_live_result('planner', {'output':current}, require_current=True)
    from multi_agent_report_contracts import REPORT_PLAN_SCHEMA
    current.update(schema_version=REPORT_PLAN_SCHEMA,
        user_requirements=[{'id':'u1','question_quote':'DETR、SAM、CLIP有什么帮助？','answer_kind':'relation',
            'research_group_ids':['g1'],'report_obligation_ids':[]}],
        segment_dispositions={'s1':['u1'],'s2':'background'})
    assert normalize_live_result('planner', {'output':current}, require_current=True)['output']['groups'][0]['kind']=='research'
    legacy_current = deepcopy(current)
    legacy_current['schema_version'] = 'sciassistant.research-plan/v6'
    with pytest.raises(AgentContractError):
        normalize_live_result('planner', {'output': legacy_current}, require_current=True)


def test_three_original_source_clues_fit_two_existing_or_slots():
    raw = typed_plan(); actions = requests(); before = deepcopy(actions)
    routed, changes = route_need_titles(raw, actions)
    assert len(routed) == 2 and len(changes) == 2 and actions == before
    all_queries = ' '.join(a['arguments']['query'] for a in routed)
    assert all(n['source_title'] in all_queries for n in raw['groups'][0]['evidence_needs'])
    assert ' OR ' in all_queries and ' AND ' not in all_queries
    assert [a['request_id'] for a in routed] == [a['request_id'] for a in actions]


@pytest.mark.parametrize('action', ['request_document_search', 'request_research_search'])
def test_no_new_public_route_for_private_or_mixed_modes(action):
    actions = requests()
    for a in actions: a['action'] = action
    assert route_need_titles(typed_plan(), actions) == (actions, [])


def test_respect_explicit_exclusions_and_do_not_invent_semantic_coverage():
    actions = requests(); actions[0]['arguments']['query'] = 'SAM ANDNOT medical'
    assert route_need_titles(typed_plan(), actions) == (actions, [])
    flow = need_flow_snapshot(typed_plan(), requests(), {'evidence':[
        {'evidence_id':'ev1','text':'SAM is mentioned in related work.'}]}, {'allowed_evidence_ids':['ev1']})
    assert not flow['semantic_coverage_verified']
    assert next(n for n in flow['needs'] if n['entity']=='SAM')['approved_literal_mentions']==['ev1']


def make_audit_packet():
    data, sources = draft(), evidence()
    data['audit_job_policy'] = AUDIT_JOB_POLICY
    data['claims'].append({**deepcopy(data['claims'][0]), 'claim_id':'c2'})
    audit = citation_audit_input(data, sources)
    # Explicit menus make isolation independent of existing quote-policy fixtures.
    for job in audit['audit_jobs']:
        job['source_witness_options'] = [{'claim_id':job['claim_id'],'choice_label':job['claim_id']+'-i-1'}]
    return {'inputs':[{'artifact_id':'audit','payload':audit},
        {'artifact_id':'draft','payload':data}, {'artifact_id':'approved','payload':sources},
        {'artifact_id':'fix','payload':{'schema_version':'sciassistant.validation-report/v1',
          'issues':[{'claim_id':'c1','reason':'X'}, {'claim_id':'c2','reason':'Y'}]}}]}


def test_model_sees_disjoint_menus_and_claim_local_corrections_not_flat_pools():
    packet = make_audit_packet(); before=deepcopy(packet)
    projected = project_audit_packet(packet)
    content = projected['inputs'][0]['payload']
    assert 'claims' not in content and 'source_witness_options' not in content
    jobs = content['audit_jobs']
    assert jobs[0]['source_witness_options'][0]['choice_label']=='c1-i-1'
    assert 'c2-i-1' not in json.dumps(jobs[0])
    assert all(row['claim_id']=='c1' for row in jobs[0]['corrections'][0]['issues'])
    assert projected['inputs'][1]['payload']['schema_version']=='sciassistant.audit-input-reference/v1'
    assert not jobs[0]['processing_context']['manual_page_review_attested_by_workflow']
    assert packet == before


def test_legacy_audit_packet_is_not_rewritten():
    packet={'inputs':[{'payload':{'schema_version':'sciassistant.citation-audit-input/v1','claims':[]}}]}
    assert project_audit_packet(packet) is packet


def test_three_scientific_topics_and_advice_do_not_compete_for_group_slots():
    raw = typed_plan()
    group = raw['groups'][0]
    raw['groups'] = [{**deepcopy(group), 'id': f'g{i}'} for i in range(1,4)]
    raw['report_obligations'] = [{'id':'o1','kind':'report',
        'question_quote':'请提出可证伪实验。','question':'Experiment design'}]
    assert not plan_handoff_issues(raw, QUESTION)
    actual, _ = scope_plan_to_question(raw, answer_requirements(QUESTION))
    assert len(actual['groups']) == 3 and len(actual['report_obligations']) == 1
    raw['report_obligations'][0]['queries'] = ['forbidden']
    assert plan_handoff_issues(raw, QUESTION)


def test_translated_alias_has_explicit_question_anchor_not_literal_false_rejection():
    raw = typed_plan(); raw['groups'][0]['evidence_needs'][0]['entity'] = 'object detection transformer'
    assert not plan_handoff_issues(raw, QUESTION)
    assert not evidence_need_contract(raw)['semantic_auto_approval']


@pytest.mark.parametrize('scope', ['arxiv', 'uploaded_pdf', 'uploaded_pdf_and_arxiv'])
def test_proposals_are_preserved_but_only_two_queries_can_execute(scope):
    raw = typed_plan(); raw['groups'] = raw['groups'][:1]
    raw['groups'][0]['query_candidates'] = ['DETR', 'SAM', 'CLIP']
    before = deepcopy(raw)
    compiled, report = compile_search_plan(raw, scope)
    group = compiled['groups'][0]
    assert raw == before and group['query_candidates'] == ['DETR', 'SAM', 'CLIP']
    assert len(group['queries']) == 2 and report['groups'][0]['execution_limit'] == 2
    if scope == 'arxiv':
        assert all(n['source_title'] in ' '.join(group['queries']) for n in group['evidence_needs'])
        assert ' OR ' in ' '.join(group['queries'])
    else:
        assert group['queries'] == ['DETR', 'SAM']
    assert route_need_titles(compiled, requests())[1] == []


def test_compiler_does_not_truncate_titles_or_override_explicit_exclusions():
    raw = typed_plan(); raw['groups'] = raw['groups'][:1]
    raw['groups'][0]['query_candidates'] = ['DETR ANDNOT medical', 'SAM', 'CLIP']
    compiled, _ = compile_search_plan(raw, 'arxiv')
    assert compiled['groups'][0]['queries'] == ['DETR ANDNOT medical', 'SAM']
    legacy = {'schema_version': 'sciassistant.research-plan/v3', 'groups': []}
    assert compile_search_plan(legacy, 'arxiv')[0] == legacy
