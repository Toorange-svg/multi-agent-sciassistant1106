"""Source grade caps metadata before audit, never rewrites or approves a claim."""
from copy import deepcopy
import pytest

from multi_agent_handoffs import SOURCE_CONFIDENCE_POLICY, AUDIT_JOB_POLICY
from multi_agent_quality import attach_reviewed_source_scope, citation_audit_input, check_audit, publication_rejections
from multi_agent_pipeline_v2 import check_draft, PipelineExecutionError
from test_multi_agent_report_fields import draft, evidence, audit


@pytest.mark.parametrize('reported',['high','medium','low',None])
def test_only_weak_approved_sources_cap_confidence_without_touching_scientific_fields(reported):
    data,sources=draft(),evidence()
    data['claims'][0]['confidence']=reported
    sources['evidence'][0].update(coverage_scope='abstract',evidence_strength='fulltext_located')
    original=deepcopy((data,sources))
    data['source_confidence_policy']=SOURCE_CONFIDENCE_POLICY
    result,formatting=attach_reviewed_source_scope(data,sources)
    c=result['claims'][0]
    assert c['confidence']=='low' and c['source_confidence_ceiling']['reported_confidence']==reported
    assert not c['source_confidence_ceiling']['semantic_support_verified']
    for field in ('text','scope_note','qualification','evidence_ids'):
        assert c[field]==original[0]['claims'][0][field]
    assert data['claims']==original[0]['claims'] and sources==original[1]
    assert not any(i['reason']=='WEAK_EVIDENCE_CONFIDENCE' for i in check_draft(result,sources))
    assert formatting['semantic_auto_approval'] is False


def test_legacy_unapproved_or_mixed_sources_do_not_get_automatic_metadata_repair():
    data,sources=draft(),evidence(); data['claims'][0]['confidence']='high'
    sources['evidence'][0]['coverage_scope']='abstract'
    assert attach_reviewed_source_scope(data,sources)[0]['claims'][0]['confidence']=='high'
    data['source_confidence_policy']=SOURCE_CONFIDENCE_POLICY
    sources['evidence'][0]['review_status']='rejected'
    assert attach_reviewed_source_scope(data,sources)[0]['claims'][0]['confidence']=='high'
    sources['evidence'][0]['review_status']='approved'
    sources['evidence'].append({**sources['evidence'][0],'evidence_id':'e2','coverage_scope':'selected_chunks','locator':{'page':2}})
    data['claims'][0]['evidence_ids'].append('e2')
    assert attach_reviewed_source_scope(data,sources)[0]['claims'][0]['confidence']=='high'


def test_confidence_ceiling_is_visible_to_audit_and_cannot_override_rejection():
    data,sources=draft(),evidence(); data.update(source_confidence_policy=SOURCE_CONFIDENCE_POLICY,audit_job_policy=AUDIT_JOB_POLICY)
    data['claims'][0]['confidence']='medium'; sources['evidence'][0]['coverage_scope']='abstract'
    result,_=attach_reviewed_source_scope(data,sources)
    supplied=citation_audit_input(result,sources)
    assert supplied['audit_jobs'][0]['claim']['source_confidence_ceiling']['effective_confidence']=='low'
    value=audit(result); row=value['claim_results'][0]
    row.update(decision='rejected',reason_code='UNSUPPORTED_CLAIM')
    row['field_results']['text'].update(status='unsupported',detail='The source does not entail the assertion.')
    value.update(status='needs_revision',rejected_claim_ids=['c1'],issues=[{'claim_id':'c1','reason_code':'UNSUPPORTED_CLAIM','detail':'Wrong assertion.'}])
    checked=check_audit(value,result,sources)
    assert publication_rejections(checked,result)=={'c1'}


def test_index_timeout_has_specific_safe_failure_instead_of_generic_read_error(tmp_path):
    from multi_agent_local_pdf import LocalPdfRagExecutor
    pdf=tmp_path/'input.pdf'; pdf.write_bytes(b'%PDF-1.4\nfixture\n%%EOF')
    run=tmp_path/'run'; run.mkdir()
    executor=LocalPdfRagExecutor(run,pdf,rag_mode='lexical',parse=lambda _:{'layout_blocks':[{'page':1,'text':'Actual fixture content.'}]})
    def fail(*a,**k):
        raise TimeoutError('PDF_INDEX_DEADLINE')
    executor.indexer.index=fail
    request={'request_id':'r1','action':'request_document_search','arguments':{'query':'content','group_id':'g1'}}
    with pytest.raises(PipelineExecutionError) as exc:
        executor.execute([request],group_ids={'g1'})
    assert exc.value.code=='PDF_INDEX_DEADLINE'
