"""Offline release fixes, including actual independent-process storage leases."""
import json
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace as NS

import pytest

from rag_storage_lock import RagStorageBusy, StorageLease, writer_roots
from process_cleanup import terminate_process_tree
from tests.test_rag_cloud import model_configuration, Embedding
from tools import rag_startup

ROOT = Path(__file__).resolve().parents[1]


def test_two_leases_refuse_same_root_and_release(tmp_path):
    with StorageLease(tmp_path):
        with pytest.raises(RagStorageBusy):
            StorageLease(tmp_path).acquire()
    with StorageLease(tmp_path):
        assert (tmp_path / ".rag-writer.lock").is_file()


def test_partial_acquire_unwinds_other_roots(tmp_path):
    a, b = tmp_path / "a", tmp_path / "b"
    with StorageLease(b):
        with pytest.raises(RagStorageBusy):
            StorageLease(a, b).acquire()
        with StorageLease(a):
            pass


def test_real_process_termination_releases_lease(tmp_path):
    script = "from rag_storage_lock import StorageLease; import sys,time,os,json; lease=StorageLease(sys.argv[1]).acquire(); print(json.dumps({'ready':True,'worker_pid':os.getpid()}),flush=True); time.sleep(30)"
    child = subprocess.Popen([sys.executable, "-c", script, str(tmp_path)], cwd=ROOT,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                             start_new_session=os.name != "nt")
    if os.name != "nt":
        child._sciassistant_process_group = child.pid
    try:
        ready = json.loads(child.stdout.readline())
        assert ready["ready"] and ready["worker_pid"] > 0
        with pytest.raises(RagStorageBusy):
            StorageLease(tmp_path).acquire()
        # Windows venv python.exe may be a launcher: its PID is NOT the worker
        # holding the lease. Exercise the real production tree cleanup rather
        # than terminating only the redirector and leaving the worker running.
        cleanup = terminate_process_tree(child)
        assert cleanup["parent_stopped"] and cleanup["tree_stop_confirmed"]
        with StorageLease(tmp_path):
            pass
    finally:
        if child.poll() is None:
            terminate_process_tree(child)
        child.communicate(timeout=5)


def test_distinct_roots_can_run_simultaneously(tmp_path):
    with StorageLease(tmp_path / "a"), StorageLease(tmp_path / "b"):
        pass


def test_lease_cannot_reenter_or_release_an_active_owner(tmp_path):
    with StorageLease(tmp_path) as lease:
        with pytest.raises(RuntimeError, match="ALREADY_ACQUIRED"):
            lease.acquire()
        with pytest.raises(RagStorageBusy):
            StorageLease(tmp_path).acquire()


def test_unsafe_lock_link_refused(tmp_path):
    target = tmp_path / "real"
    target.write_bytes(b"0")
    try:
        (tmp_path / ".rag-writer.lock").symlink_to(target)
    except OSError:
        pytest.skip("host does not permit symlinks")
    with pytest.raises(ValueError, match="UNSAFE_STORAGE_LOCK"):
        StorageLease(tmp_path).acquire()


def test_writer_roots_cover_local_vector_and_remote_workspace(tmp_path, monkeypatch):
    monkeypatch.setenv("SCIASSISTANT_QDRANT_PATH", str(tmp_path / "vectors"))
    monkeypatch.delenv("SCIASSISTANT_QDRANT_URL", raising=False)
    assert len(writer_roots(tmp_path / "docs")) == 2
    monkeypatch.setenv("SCIASSISTANT_QDRANT_URL", "http://qdrant:6333")
    monkeypatch.setenv("SCIASSISTANT_MULTI_AGENT_VECTOR_LOCK_ROOT", str(tmp_path / "server-leases"))
    remote = writer_roots(tmp_path / "docs")
    assert len(remote) == 2 and remote[1].parent == tmp_path / "server-leases"
    assert writer_roots(tmp_path / "other")[1] == remote[1]


def test_busy_live_cli_is_terminal_without_model_call(tmp_path, monkeypatch, capsys):
    from tools import multi_agent_cli as cli
    storage = tmp_path / "storage"
    monkeypatch.setenv("SCIASSISTANT_QDRANT_PATH", str(tmp_path / "qdrant"))
    monkeypatch.setenv("SCIASSISTANT_MULTI_AGENT_VECTOR_LOCK_ROOT", str(tmp_path / "server-locks"))
    monkeypatch.setattr(cli, "configured_live_model", lambda: pytest.fail("busy run must not initialize model"))
    with StorageLease(storage):
        assert cli.main(["run", "--worker", "--mode", "live", "--query", "test",
                         "--run-id", "busy", "--storage-root", str(storage),
                         "--output-root", str(tmp_path / "runs")]) == 1
    assert "RAG_STORAGE_BUSY" in capsys.readouterr().out
    from multi_agent_workflow import WorkflowStore
    run = WorkflowStore(tmp_path / "runs/busy/workflow.sqlite3").get_run("busy")
    assert run["status"] == "failed" and run["model_calls_used"] == 0
    manifest = json.loads((tmp_path / "runs/busy/manifest.json").read_text())
    assert manifest["final_artifact_id"]


def test_posix_lease_uses_nonblocking_flock(tmp_path, monkeypatch):
    import rag_storage_lock as locks
    calls = []
    lease = StorageLease(tmp_path)
    monkeypatch.setitem(sys.modules, "fcntl", NS(LOCK_EX=2, LOCK_NB=4,
                                                 flock=lambda fd, flags: calls.append(flags)))
    with monkeypatch.context() as platform:
        platform.setattr(locks.os, "name", "posix")
        lease.acquire()
        lease.close()
    assert calls == [6]


@pytest.mark.parametrize("case", ["race", "wrong_dimension", "unavailable", "create_failure"])
def test_qdrant_startup_race_and_resource_cleanup(monkeypatch, case):
    from multi_agent_rag import QdrantVectorStore, RagError
    closed, created = [], []
    class Client:
        def collection_exists(self, _):
            if case == "unavailable":
                raise RuntimeError("private-service-canary")
            return bool(created) and case != "create_failure"
        def create_collection(self, **_):
            created.append(True)
            if case in {"race", "create_failure"}:
                raise RuntimeError("creation conflict")
        def get_collection(self, _):
            return NS(config=NS(params=NS(vectors=NS(size=2 if case == "wrong_dimension" else 384))))
        def close(self):
            closed.append(True)
    monkeypatch.setitem(sys.modules, "qdrant_client", NS(QdrantClient=lambda **_: Client()))
    monkeypatch.setitem(sys.modules, "qdrant_client.http", NS(models=NS(
        VectorParams=lambda **_: None, Distance=NS(COSINE="cosine"))))
    if case == "race":
        store = QdrantVectorStore(dimension=384, url="http://test")
        assert not closed
        store.close()
    else:
        with pytest.raises((RuntimeError, RagError)):
            QdrantVectorStore(dimension=384, url="http://test")
    assert len(closed) == 1


def test_startup_nonwritable_volume_refused_before_model(model_configuration, monkeypatch):
    monkeypatch.setattr(rag_startup.tempfile, "TemporaryFile", lambda **_: (_ for _ in ()).throw(PermissionError()))
    with pytest.raises(PermissionError):
        rag_startup.preflight(provider_factory=lambda _: pytest.fail("must not load model"))


@pytest.mark.parametrize("dimension", [384, 768])
def test_startup_existing_collection_dimension(model_configuration, dimension):
    closed, waits = [], []
    class Client:
        def get_collections(self): return NS(collections=[NS(name="sciassistant_evidence")])
        def get_collection(self, _): return NS(config=NS(params=NS(vectors=NS(size=dimension))))
        def close(self): closed.append(True)
    call = lambda: rag_startup.preflight(provider_factory=lambda _: Embedding(),
                                        client_factory=lambda **_: Client(), sleep=waits.append)
    if dimension == 384:
        assert call()["storage_writable"]
    else:
        with pytest.raises(ValueError, match="VECTOR_COLLECTION_DIMENSION_INVALID"):
            call()
    assert closed == [True] and not waits


def test_frontend_wide_grid_and_shrink_safe_controls():
    html = (ROOT / "chatAi/ai_chat.html").read_text(encoding="utf-8")
    css = (ROOT / "chatAi/multi_agent_rag.css").read_text(encoding="utf-8")
    js = (ROOT / "chatAi/multi_agent_rag.js").read_text(encoding="utf-8")
    assert ".rag-report-layout{display:block}" in css
    assert "max-width:1440px" in css and "100dvh - 16px" in css
    assert "analysisColumn.append(answer)" in js and "evidenceColumn.append(card)" in js
    assert "<span>发送</span>" in html and "max-width: 1100px" in html
    assert "#chat-form { display: flex; flex-wrap: wrap" in html


def test_new_runtime_module_in_both_images_and_fingerprint():
    from runtime_identity import IDENTITY_FILES
    from tools.cloud_release import REQUIRED
    assert "rag_storage_lock.py" in IDENTITY_FILES
    assert "rag_storage_lock.py" in REQUIRED
    for name in ("Dockerfile.account.cloud", "Dockerfile.cloud"):
        assert "COPY rag_storage_lock.py /app/" in (ROOT / name).read_text()
        assert "!rag_storage_lock.py" in (ROOT / (name + ".dockerignore")).read_text()
