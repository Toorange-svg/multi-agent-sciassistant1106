"""Presentation maps published records, not new scientific approvals."""
from copy import deepcopy
import json
from pathlib import Path
import re
import subprocess
import sys

import pytest

from multi_agent_presentation import (POLICY, LINKED_POLICY, build_presentation, render_answer,
    evidence_review, bibliography, report_content, coverage_report)
from multi_agent_web import exported_report

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture
def data():
    refs = [{'citation': n, 'evidence_id': 'e'+str(n), 'title': '论文 '+str(n),
        'paper_id': '2309.06180v1', 'source': 'arxiv', 'official_url': 'https://arxiv.org/abs/2309.06180v1',
        'locator': {'page': n, 'bbox': [1, 2, 3, 4]}, 'excerpt': 'source '+str(n),
        'review_status': 'approved', 'reviewed_group_ids': ['g1' if n < 3 else 'g2']}
        for n in (1, 2, 3)]
    claims = [{'claim_id': 'c1', 'group_id': 'g1', 'text': '检测方法可识别所选数据中的生成图像。',
        'scope_note': '只适用于所选评估设置。', 'qualification': '实验样本与指标定义需单独核对。', 'evidence_ids': ['e1','e2']},
        {'claim_id': 'c2', 'group_id': 'g2', 'text': 'ViT 特征可作为检测线索。',
         'scope_note': '', 'qualification': '未进行统一的跨路线比较。', 'evidence_ids': ['e3']}]
    coverage = [{'group_id': 'g1', 'metric': 'definition', 'status': 'partial', 'evidence_ids': ['e1'],
        'missing_conditions': ['仅描述真伪二分类范式，所选片段没有给出正式定义。'],
        'comparability': 'limited', 'recommended_action': 'qualified_answer'},
        {'group_id': 'g2', 'metric': 'relation', 'status': 'not_comparable',
         'missing_conditions': ['各论文的数据集和骨干不同，不能直接排名。']}]
    return {'status': 'partial', 'direct_answer': '### 直接回答\n\n'+claims[0]['text']+'[1][2]\n\n'+claims[1]['text']+'[3]',
            'claims': claims, 'coverage': coverage, 'references': refs,
            'plan': {'groups': [{'id':'g1','heading':'AI 生成图像检测'}, {'id':'g2','heading':'与 ViT 的关系'}]}}


def presentation(data):
    return build_presentation(data['claims'], data['coverage'], data['references'], data['plan'])


def test_labels_and_explicit_placement(data):
    p = presentation(data)
    assert p['policy'] == POLICY
    one, two = p['coverage_notes']
    assert (one['title'],one['metric_label'],one['status_label']) == ('AI 生成图像检测','概念与定义','部分覆盖')
    assert one['claim_ids'] == ['c1'] and one['evidence_ids'] == ['e1']
    assert two['claim_ids'] == ['c2'] and two['evidence_ids'] == ['e3']
    body = render_answer(data['direct_answer'],p,data['references'])
    assert '概念与定义' not in body and '技术关系' not in body
    text = coverage_report(p,data['references'])
    assert '概念与定义' in text and '技术关系' in text
    assert '缺少实验条件' not in text and 'qualified_answer' not in text
    assert '可比性有限' not in text and '不能直接排名' in text


def test_unlocated_gap_never_guesses_source_or_body(data):
    data['coverage'] = [{'metric':'role','status':'missing','evidence_ids':['rejected-source'],
                        'missing_conditions':['本项仍缺证据']}]
    p = presentation(data)
    assert p['coverage_notes'][0]['evidence_ids'] == p['coverage_notes'][0]['claim_ids'] == []
    text = coverage_report(p,data['references'])
    assert '本项仍缺证据' in text
    assert '本项仍缺证据' not in render_answer(data['direct_answer'],p,data['references'])
    assert 'rejected-source' not in text


def test_shared_source_does_not_place_topic_note_under_other_topic(data):
    data['claims'][0]['evidence_ids'].append('e3')
    assert presentation(data)['coverage_notes'][1]['claim_ids'] == ['c2']


def test_one_full_condition_record_and_other_evidence_links_to_it(data):
    p = presentation(data)
    one = evidence_review(p,'e1',data['references'])
    two = evidence_review(p,'e2',data['references'])
    assert '实验样本与指标定义需单独核对' in one
    assert '实验样本与指标定义需单独核对' not in two
    assert '完整说明见 [1]' in two
    assert p['claim_notes'][0]['details'][1]['text'] == data['claims'][0]['qualification']


def test_only_literal_duplicate_detail_is_hidden(data):
    c = data['claims'][0]
    c['qualification'] = c['scope_note']
    assert len(presentation(data)['claim_notes'][0]['details']) == 1
    c['qualification'] += ' 具体数据集仍须另行确认。'
    assert len(presentation(data)['claim_notes'][0]['details']) == 2


def test_long_details_retained_full_not_silently_truncated(data):
    value = '很长的实验条件。'*100
    data['coverage'][0]['missing_conditions'] = [value]
    p = presentation(data)
    assert len(p['coverage_notes'][0]['summary']) <= 161
    assert p['coverage_notes'][0]['details'][0]['text'] == value
    assert value in coverage_report(p,data['references'])
    assert value not in render_answer(data['direct_answer'],p,data['references'])


@pytest.mark.parametrize('fmt',['html','md','json'])
def test_export_retains_data_and_places_bibliography_last(data,fmt):
    original = deepcopy(data)
    content,_ = exported_report(data,fmt)
    text = content.decode('utf-8-sig')
    assert data == original
    assert '逐声明审查记录' not in text and '缺少实验条件' not in text
    if fmt == 'json':
        parsed = json.loads(text)
        assert parsed['claims'] == data['claims'] and parsed['coverage'] == data['coverage']
        assert parsed['presentation']['policy'] == POLICY
    else:
        assert text.rfind('参考文献') > text.rfind('适用范围与实验条件（完整记录）')
        assert text.count('实验样本与指标定义需单独核对。') == 1
        assert 'evidence-1' in text and 'evidence-3' in text


def test_html_escapes_all_new_surfaces_and_unknown_citations(data):
    payload = '<img src=x onerror=attack()>'
    data['coverage'][0]['missing_conditions'] = [payload]
    data['claims'][0]['qualification'] = payload
    data['references'][0]['title'] = payload
    data['direct_answer'] += payload+' [999]'
    text = exported_report(data,'html')[0].decode()
    assert payload not in text and '&lt;img' in text
    assert 'href="#evidence-999"' not in text and '引用未发布' in text


def test_markdown_note_heading_does_not_inject_raw_html(data):
    data['coverage'][0]['topic'] = '<img src=x onerror=attack()>'
    data['coverage'][0]['group_id'] = None
    text = exported_report(data,'md')[0].decode('utf-8-sig')
    assert '<img src=x onerror=attack()>' not in text and '&lt;img' in text


def test_empty_report_still_has_honest_reference_end():
    p,body,cards = report_content('本轮未形成可用结论。',[],[],[])
    assert not cards and '未形成可用结论' in body
    assert '没有可列出的已批准参考文献' in bibliography(p)


@pytest.mark.parametrize('fmt',['html','md'])
def test_source_tier_locator_and_attribution_not_lost(data,fmt):
    data['references'][0].update(evidence_strength_label='摘要级证据，不等于全文验证',
        source_attribution={'label':'二手转述，未核验原始方法'},excerpt_truncated=True)
    data['references'][0]['locator']['section'] = 'Method Table 2'
    text = exported_report(data,fmt)[0].decode('utf-8-sig')
    assert '摘要级证据，不等于全文验证' in text
    assert '二手转述，未核验原始方法' in text and 'Method Table 2' in text
    assert '长片段节选' in text


def test_new_cli_manifest_layout_and_read_only_replay(tmp_path):
    args = [sys.executable,str(ROOT/'tools/multi_agent_cli.py'),'run','--mode','mock',
        '--query','Define a method','--run-id','presentation-fixture','--output-root',str(tmp_path)]
    run = subprocess.run(args,cwd=ROOT,capture_output=True,text=True,timeout=45)
    assert run.returncode == 0,run.stderr
    folder = tmp_path/'presentation-fixture'
    assert json.loads((folder/'manifest.json').read_text())['report_presentation_policy'] == POLICY
    md = (folder/'final_answer.md').read_text(encoding='utf-8-sig')
    page = (folder/'final_answer.html').read_text(encoding='utf8')
    assert '逐声明审查记录' not in md
    assert md.rfind('## 参考文献') > md.rfind('## 原文证据')
    assert page.rfind('id="bibliography"') > page.rfind('id="evidence-1"')
    import hashlib
    def hashes():
        return {str(p.relative_to(folder)):hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.rglob('*') if p.is_file()}
    before = hashes()
    replay = subprocess.run([sys.executable,str(ROOT/'tools/multi_agent_cli.py'),'replay','--run-dir',str(folder)],
        cwd=ROOT,capture_output=True,text=True,timeout=45)
    assert replay.returncode == 0,replay.stderr
    assert hashes() == before


def test_grouped_gap_has_no_template_or_duplicate_summary(data):
    row = deepcopy(data['coverage'][0])
    row['metric'] = 'role'
    row['evidence_ids'] = ['e1','e2']
    data['coverage'].append(row)
    p = presentation(data)
    assert len(p['coverage_groups']) == 2
    assert p['coverage_groups'][0]['rows'][0]['metric_labels'] == ['概念与定义','作用与用途']
    text = coverage_report(p,data['references'])
    assert text.count(data['coverage'][0]['missing_conditions'][0]) == 1
    assert text.count('AI 生成图像检测') == 1
    assert text.count('href="#evidence-1"') == 1
    assert text.count('href="#evidence-2"') == 1
    for boilerplate in ['完整审查说明','与所列证据相关的审查说明','具体缺口：','比较边界：可比性有限','本轮处理','对应原文']:
        assert boilerplate not in text
    assert data['coverage'][0]['missing_conditions'][0] not in evidence_review(p,'e1',data['references'])


def test_meaningful_additional_boundary_is_not_dropped(data):
    boundary = '只能比较相同硬件、相同输入长度和相同批大小的测试。'
    data['coverage'][0]['comparability'] = boundary
    assert boundary in coverage_report(presentation(data),data['references'])


def test_same_wording_in_different_topics_is_not_merged(data):
    data['coverage'][1]['missing_conditions'] = data['coverage'][0]['missing_conditions']
    p = presentation(data)
    assert len(p['coverage_groups']) == 2
    assert len(p['coverage_groups'][0]['rows']) == len(p['coverage_groups'][1]['rows']) == 1


def test_old_linked_policy_keeps_original_placement_for_historical_replay(data):
    p = build_presentation(data['claims'],data['coverage'],data['references'],data['plan'],policy=LINKED_POLICY)
    assert 'coverage_groups' not in p
    assert '概念与定义' in render_answer(data['direct_answer'],p,data['references'])
    assert data['coverage'][0]['missing_conditions'][0] in evidence_review(p,'e1',data['references'])
