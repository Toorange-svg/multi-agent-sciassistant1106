"""Single-use, out-of-band password reset security boundaries."""

import hashlib
import json
from unittest import mock

import pytest

import app as gateway
import password_reset as reset_mail
from request_limits import SlidingWindowLimiter


TOKEN = "A" * 43


class ResetCursor:
    def __init__(self, connection):
        self.connection = connection
        self.result = None
        self.rowcount = 0

    def __enter__(self): return self
    def __exit__(self, *_args): return False

    def execute(self, sql, params=()):
        normalized = " ".join(sql.split()).lower()
        self.connection.statements.append((normalized, params))
        self.rowcount = 0
        if normalized.startswith("select id, email from users"):
            self.result = self.connection.user
        elif normalized.startswith("select id, user_id from password_reset_tokens"):
            self.result = self.connection.reset
        elif normalized.startswith("insert into password_reset_tokens"):
            self.connection.inserted_hash = params[1]
        elif normalized.startswith("update users set password"):
            self.connection.password_hash = params[0]
            self.rowcount = self.connection.user_update_count
        elif normalized.startswith("update password_reset_tokens"):
            self.rowcount = 1

    def fetchone(self): return self.result


class ResetConnection:
    def __init__(self, *, user=None, reset=None, user_update_count=1):
        self.user = user
        self.reset = reset
        self.user_update_count = user_update_count
        self.statements = []
        self.inserted_hash = None
        self.password_hash = None
        self.commits = 0
        self.rollbacks = 0
        self.closed = False

    def cursor(self): return ResetCursor(self)
    def commit(self): self.commits += 1
    def rollback(self): self.rollbacks += 1
    def close(self): self.closed = True


@pytest.fixture(autouse=True)
def reset_environment(monkeypatch):
    values = {
        "APP_ENV": "production",
        "PASSWORD_RESET_ENABLED": "true",
        "PASSWORD_RESET_BASE_URL": "https://science.example.org/forgot-password.html",
        "PASSWORD_RESET_TOKEN_TTL_SECONDS": "900",
        "SMTP_HOST": "smtp.example.org",
        "SMTP_PORT": "587",
        "SMTP_USERNAME": "mailer",
        "SMTP_PASSWORD": "private-mail-password",
        "SMTP_FROM": "noreply@example.org",
        "SMTP_USE_TLS": "true",
    }
    for key, value in values.items(): monkeypatch.setenv(key, value)
    with mock.patch.object(gateway, "_AUTH_RATE_LIMITER", SlidingWindowLimiter(max_keys=1000)):
        yield


def test_reset_config_is_disabled_by_default(monkeypatch):
    monkeypatch.setenv("PASSWORD_RESET_ENABLED", "false")
    assert not reset_mail.load_reset_mail_config().enabled


@pytest.mark.parametrize("key,value", [
    ("PASSWORD_RESET_BASE_URL", "http://science.example.org/reset"),
    ("PASSWORD_RESET_BASE_URL", "https://user:secret@science.example.org/reset"),
    ("PASSWORD_RESET_BASE_URL", "https://science.example.org/reset?token=x"),
    ("SMTP_USE_TLS", "false"),
    ("SMTP_PORT", "70000"),
    ("PASSWORD_RESET_TOKEN_TTL_SECONDS", "60"),
])
def test_production_reset_config_rejects_unsafe_values(monkeypatch, key, value):
    monkeypatch.setenv(key, value)
    with pytest.raises(reset_mail.ResetConfigurationError):
        reset_mail.load_reset_mail_config()


def test_reset_link_replaces_query_and_never_uses_fragment():
    link = reset_mail.build_reset_link("https://science.example.org/forgot-password.html", "safe_token")
    assert link == "https://science.example.org/forgot-password.html?token=safe_token"


def test_smtp_delivery_requires_tls_login_and_contains_single_link():
    config = reset_mail.load_reset_mail_config()
    client = mock.MagicMock()
    smtp = mock.MagicMock()
    smtp.return_value.__enter__.return_value = client
    with mock.patch.object(reset_mail.smtplib, "SMTP", smtp), \
         mock.patch.object(reset_mail.ssl, "create_default_context", return_value="tls-context"):
        reset_mail.send_reset_email(config, "person@example.org", TOKEN)
    smtp.assert_called_once_with("smtp.example.org", 587, timeout=10)
    client.starttls.assert_called_once_with(context="tls-context")
    client.login.assert_called_once_with("mailer", "private-mail-password")
    message = client.send_message.call_args.args[0]
    assert message["To"] == "person@example.org"
    assert TOKEN in message.get_content()


def test_disabled_request_never_opens_database(monkeypatch):
    monkeypatch.setenv("PASSWORD_RESET_ENABLED", "false")
    with mock.patch.object(gateway, "get_db_connection") as database:
        response = gateway.app.test_client().post(
            "/api/password-reset/request", json={"email": "person@example.org"})
    assert response.status_code == 503
    assert response.get_json()["error"] == "PASSWORD_RESET_DISABLED"
    database.assert_not_called()


def test_known_and_unknown_email_receive_identical_generic_response(monkeypatch):
    known = ResetConnection(user={"id": 7, "email": "person@example.org"})
    unknown = ResetConnection(user=None)
    sent = []
    monkeypatch.setattr(gateway.secrets, "token_urlsafe", lambda _size: TOKEN)
    with mock.patch.object(gateway, "send_reset_email", side_effect=lambda *_args: sent.append(True)), \
         mock.patch.object(gateway, "get_db_connection", side_effect=[known, unknown]):
        client = gateway.app.test_client()
        first = client.post("/api/password-reset/request", json={"email": "person@example.org"})
        second = client.post("/api/password-reset/request", json={"email": "unknown@example.org"})
    assert first.status_code == second.status_code == 202
    assert first.get_json() == second.get_json()
    assert sent == [True]
    assert known.inserted_hash == hashlib.sha256(TOKEN.encode("ascii")).hexdigest()
    assert TOKEN not in json.dumps(known.statements)


def test_smtp_failure_invalidates_issued_token_but_keeps_generic_response(monkeypatch):
    connection = ResetConnection(user={"id": 7, "email": "person@example.org"})
    monkeypatch.setattr(gateway.secrets, "token_urlsafe", lambda _size: TOKEN)
    with mock.patch.object(gateway, "get_db_connection", return_value=connection), \
         mock.patch.object(gateway, "send_reset_email", side_effect=RuntimeError("private smtp detail")):
        response = gateway.app.test_client().post(
            "/api/password-reset/request", json={"email": "person@example.org"})
    assert response.status_code == 202
    assert connection.commits == 2
    assert any("where token_hash = %s" in sql for sql, _ in connection.statements)
    assert "private smtp detail" not in response.get_data(as_text=True)


def test_confirm_consumes_token_updates_modern_hash_and_all_user_tokens():
    connection = ResetConnection(reset={"id": 3, "user_id": 7})
    with mock.patch.object(gateway, "get_db_connection", return_value=connection):
        response = gateway.app.test_client().post("/api/password-reset/confirm", json={
            "token": TOKEN, "password": "new secure password", "confirmPassword": "new secure password",
        })
    assert response.status_code == 200
    assert connection.commits == 1 and connection.rollbacks == 0
    assert connection.password_hash.startswith(gateway.PASSWORD_HASH_METHOD + "$")
    assert gateway.verify_password("new secure password", connection.password_hash) == (True, False)
    assert any("where user_id = %s and used_at is null" in sql for sql, _ in connection.statements)
    assert any("auth_version = auth_version + 1" in sql for sql, _ in connection.statements)


def test_used_expired_or_unknown_token_has_one_generic_error_and_no_password_write():
    connection = ResetConnection(reset=None)
    with mock.patch.object(gateway, "get_db_connection", return_value=connection):
        response = gateway.app.test_client().post("/api/password-reset/confirm", json={
            "token": TOKEN, "password": "new secure password", "confirmPassword": "new secure password",
        })
    assert response.status_code == 400
    assert response.get_json()["message"] == "重置链接无效或已过期"
    assert connection.password_hash is None and connection.rollbacks == 1


@pytest.mark.parametrize("payload", [
    {"token": "short", "password": "123456", "confirmPassword": "123456"},
    {"token": TOKEN, "password": "123", "confirmPassword": "123"},
    {"token": TOKEN, "password": "123456", "confirmPassword": "654321"},
    {"token": TOKEN, "password": [], "confirmPassword": "123456"},
])
def test_invalid_confirm_input_is_rejected_before_database(payload):
    with mock.patch.object(gateway, "get_db_connection") as database:
        response = gateway.app.test_client().post("/api/password-reset/confirm", json=payload)
    assert response.status_code == 400
    database.assert_not_called()


def test_reset_page_uses_only_new_token_endpoints_and_removes_token_after_success():
    page = (gateway.BASE_DIR / "chatAi" / "forgot-password.html").read_text(encoding="utf-8")
    login = (gateway.BASE_DIR / "chatAi" / "login.html").read_text(encoding="utf-8")
    assert "/5000/api/password-reset/request" in page
    assert "/5000/api/password-reset/confirm" in page
    assert "/api/verify-credentials" not in page and "/api/reset-password" not in page
    assert "userId" not in page
    assert "history.replaceState" in page
    assert 'href="forgot-password.html"' in login
