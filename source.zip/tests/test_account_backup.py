"""Offline backup bundle integrity, path safety and staged restore tests."""
import json
import os
from pathlib import Path
import subprocess
import sys

import pytest

from tools import account_backup as backup


ROOT = Path(__file__).resolve().parents[1]


def make_export(root: Path):
    source = root / "private-source-canary"
    for name in backup.DATA_ROOTS:
        (source / name).mkdir(parents=True)
    (source / "logs" / "task.json").write_text('{"status":"completed"}', encoding="utf-8")
    (source / "uploads" / "paper.pdf").write_bytes(b"%PDF-offline-canary")
    (source / "user_files" / "notes.txt").write_text("private user content", encoding="utf-8")
    (source / "web_uploads" / "context.bin").write_bytes(b"context-canary")
    database = root / "private-database-canary.sql"
    database.write_text(
        "-- MySQL dump offline fixture\nCREATE TABLE `user` (`id` int);\nINSERT INTO `user` VALUES (1);\n",
        encoding="utf-8",
    )
    return source, database


def build_bundle(tmp_path, revision="123abcd"):
    source, database = make_export(tmp_path)
    bundle = tmp_path / "bundle"
    report = backup.create_bundle(source, database, bundle, revision)
    assert report["passed"], report
    return source, database, bundle


def test_round_trip_bundle_is_verified_and_restored_to_new_staging_directory(tmp_path):
    source, database, bundle = build_bundle(tmp_path)
    verified = backup.verify_bundle(bundle)
    assert verified["passed"], verified
    manifest_text = (bundle / backup.MANIFEST_NAME).read_text(encoding="utf-8")
    manifest = json.loads(manifest_text)
    assert manifest["capture_consistency"] == "operator_quiesced_export"
    assert manifest["data_roots"] == list(backup.DATA_ROOTS)
    assert str(source) not in manifest_text and str(database) not in manifest_text
    assert all(set(entry) == {"path", "size", "sha256"} for entry in manifest["files"])

    restored = tmp_path / "restored"
    report = backup.restore_stage(bundle, restored)
    assert report["passed"], report
    assert backup.verify_bundle(restored)["passed"]
    assert (restored / "payload/data/user_files/notes.txt").read_text() == "private user content"
    assert (restored / "payload/data/arxiv").is_dir()  # Empty roots are retained.


@pytest.mark.parametrize("relative", [
    "payload/data/logs/task.json",
    "payload/database.sql",
    "manifest.json",
])
def test_tampering_or_manifest_corruption_is_detected(tmp_path, relative):
    _, _, bundle = build_bundle(tmp_path)
    target = bundle / relative
    target.write_bytes(target.read_bytes() + b"tampered")
    report = backup.verify_bundle(bundle)
    assert not report["passed"]
    assert "private-source-canary" not in json.dumps(report)


def test_unexpected_file_is_rejected(tmp_path):
    _, _, bundle = build_bundle(tmp_path)
    (bundle / "payload" / "unexpected.txt").write_text("unexpected")
    report = backup.verify_bundle(bundle)
    assert not report["passed"]
    assert report["checks"][0]["check"] == "bundle_file_set_invalid"


def test_missing_empty_root_and_extra_manifest_metadata_are_rejected(tmp_path):
    _, _, bundle = build_bundle(tmp_path)
    (bundle / "payload/data/arxiv").rmdir()
    report = backup.verify_bundle(bundle)
    assert not report["passed"] and report["checks"][0]["check"] == "bundle_layout_invalid"

    _, _, second_bundle = build_bundle(tmp_path / "second")
    manifest_path = second_bundle / backup.MANIFEST_NAME
    manifest = json.loads(manifest_path.read_text())
    manifest["source_path"] = "private-source-canary"
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    report = backup.verify_bundle(second_bundle)
    assert not report["passed"] and report["checks"][0]["check"] == "manifest_schema_invalid"
    assert "private-source-canary" not in json.dumps(report)


def test_manifest_path_traversal_is_rejected_before_file_access(tmp_path):
    _, _, bundle = build_bundle(tmp_path)
    manifest_path = bundle / backup.MANIFEST_NAME
    manifest = json.loads(manifest_path.read_text())
    manifest["files"][0]["path"] = "../private-database-canary.sql"
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    report = backup.verify_bundle(bundle)
    assert not report["passed"]
    assert report["checks"][0]["check"] == "manifest_path_invalid"


def test_restore_never_overwrites_existing_target(tmp_path):
    _, _, bundle = build_bundle(tmp_path)
    target = tmp_path / "existing"
    target.mkdir()
    sentinel = target / "keep.txt"
    sentinel.write_text("keep")
    with pytest.raises(backup.BackupError, match="restore_target_invalid"):
        backup.restore_stage(bundle, target)
    assert sentinel.read_text() == "keep"


def test_create_rejects_invalid_sql_overlap_and_limits_without_partial_output(tmp_path):
    source, database = make_export(tmp_path)
    database.write_text("not a mysql export", encoding="utf-8")
    with pytest.raises(backup.BackupError, match="database_dump_invalid"):
        backup.create_bundle(source, database, tmp_path / "invalid-bundle")
    database.write_text("CREATE TABLE `t` (`id` int);", encoding="utf-8")
    with pytest.raises(backup.BackupError, match="output_overlaps_source"):
        backup.create_bundle(source, database, source / "bundle")
    output = tmp_path / "limited-bundle"
    with pytest.raises(backup.BackupError, match="capture_byte_limit_exceeded"):
        backup.create_bundle(source, database, output, max_bytes=1)
    assert not output.exists()
    assert not list(tmp_path.glob(".limited-bundle.partial-*"))


def test_invalid_revision_is_not_copied_to_reports_or_manifest(tmp_path):
    source, database = make_export(tmp_path)
    secret = "Authorization-private-canary"
    with pytest.raises(backup.BackupError, match="revision_invalid"):
        backup.create_bundle(source, database, tmp_path / "bundle", secret)
    report = backup._run_safely("create", backup.create_bundle, source, database,
                                tmp_path / "bundle", secret)
    assert not report["passed"] and secret not in json.dumps(report)


def test_source_symlink_or_reparse_is_rejected(tmp_path, monkeypatch):
    source, database = make_export(tmp_path)
    external = tmp_path / "external-private.txt"
    external.write_text("private")
    link = source / "logs" / "linked.txt"
    try:
        link.symlink_to(external)
    except (OSError, NotImplementedError):
        link.write_text("reparse-fixture")
        original = backup._is_link_or_reparse
        monkeypatch.setattr(backup, "_is_link_or_reparse", lambda path: path == link or original(path))
    with pytest.raises(backup.BackupError, match="non_regular_file_rejected|link_or_reparse_rejected"):
        backup.create_bundle(source, database, tmp_path / "bundle")


def test_cli_failure_is_structured_redacted_and_nonzero(tmp_path):
    private_path = tmp_path / "private-source-canary"
    process = subprocess.run(
        [sys.executable, str(ROOT / "tools/account_backup.py"), "verify", "--bundle", str(private_path)],
        capture_output=True,
        text=True,
        timeout=10,
    )
    assert process.returncode == 2
    report = json.loads(process.stdout)
    assert not report["passed"] and report["operation"] == "verify"
    assert str(private_path) not in process.stdout + process.stderr


def test_cli_create_verify_and_restore_stage(tmp_path):
    source, database = make_export(tmp_path)
    bundle, restored = tmp_path / "bundle", tmp_path / "restored"
    commands = [
        ["create", "--source-root", str(source), "--database-dump", str(database),
         "--output", str(bundle), "--revision", "123abcd"],
        ["verify", "--bundle", str(bundle)],
        ["restore-stage", "--bundle", str(bundle), "--target", str(restored)],
    ]
    for arguments in commands:
        process = subprocess.run(
            [sys.executable, str(ROOT / "tools/account_backup.py"), *arguments],
            capture_output=True,
            text=True,
            timeout=15,
        )
        assert process.returncode == 0, process.stdout + process.stderr
        assert json.loads(process.stdout)["passed"]
        assert "private user content" not in process.stdout + process.stderr
    assert backup.verify_bundle(restored)["passed"]
