"""No CDN, no browser compiler, versioned resources and complete fonts."""
import hashlib
import json
from pathlib import Path
import shutil

import pytest
import app as gateway
from tools.check_frontend_assets import check, Resources

ROOT = Path(__file__).resolve().parents[1]


def test_static_assets_and_locked_build_inputs():
    result = check(ROOT)
    assert result['passed'], result
    assert result['external_runtime_assets'] == 0
    assert (ROOT/'chatAi/assets/tailwind.css').stat().st_size < 200_000
    assert 'darkMode' in (ROOT/'frontend/tailwind.config.cjs').read_text(encoding='utf8')
    manifest = json.loads((ROOT/'chatAi/assets/manifest.json').read_text(encoding='utf8'))
    assert manifest['dependencies']['tailwindcss'] == '3.4.17'
    assert len({row['path'] for row in manifest['files']}) == len(manifest['files'])


@pytest.mark.parametrize('page', ['login.html','register.html','forgot-password.html','ai_chat.html'])
def test_pages_reference_only_versioned_local_resources(page):
    client = gateway.app.test_client()
    response = client.get('/' + page)
    assert response.status_code == 200 and response.headers['Cache-Control'] == 'no-cache'
    resources = Resources(); resources.feed(response.text)
    assert resources.urls and not resources.runtime_compiler
    for url in resources.urls:
        assert url.startswith('/chatAi/') and '?v=' in url
        asset = client.get(url)
        assert asset.status_code == 200, url
        assert asset.headers['Cache-Control'] == 'no-cache'
        assert 'https://' not in asset.headers['Content-Security-Policy']
    # Never loosen API/account response caching to optimize public CSS.
    assert client.get('/api/health').headers['Cache-Control'] == 'no-store'


@pytest.mark.parametrize('font', ['vendor/font-awesome/fonts/fontawesome-webfont.woff2',
    'vendor/katex/fonts/KaTeX_Main-Regular.woff2'])
def test_real_font_files_are_served_not_html(font):
    response = gateway.app.test_client().get('/chatAi/'+font)
    assert response.status_code == 200 and response.data[:4] == b'wOF2'
    assert 'html' not in response.mimetype


@pytest.mark.parametrize('damage', ['missing_font','wrong_css','unversioned','remote_script','runtime_style'])
def test_invalid_bundles_are_refused(tmp_path, damage):
    manifest = json.loads((ROOT/'chatAi/assets/manifest.json').read_text(encoding='utf8'))
    published = [row['path'] for row in manifest['files']] + [
        'assets/manifest.json', 'ai_chat.html', 'login.html', 'register.html', 'forgot-password.html']
    for relative in published:
        target = tmp_path/'chatAi'/relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT/'chatAi'/relative, target)
    shutil.copytree(ROOT/'frontend', tmp_path/'frontend')
    for name in ['Dockerfile.account.cloud.dockerignore','Dockerfile.cloud.dockerignore']:
        shutil.copyfile(ROOT/name,tmp_path/name)
    if damage == 'missing_font': (tmp_path/'chatAi/vendor/katex/fonts/KaTeX_Main-Regular.woff2').unlink()
    elif damage == 'wrong_css': (tmp_path/'chatAi/assets/tailwind.css').write_text('broken',encoding='utf8')
    else:
        page = tmp_path/'chatAi/login.html'
        text = page.read_text(encoding='utf8')
        if damage == 'unversioned':
            import re
            text = re.sub(r'\?v=[a-f0-9]{12}', '', text)
        elif damage == 'remote_script': text = text.replace('</head>', '<script src="https://example.invalid/compiler.js"></script></head>')
        else: text = text.replace('</head>', '<style type="text/tailwindcss"></style></head>')
        page.write_text(text,encoding='utf8')
    assert not check(tmp_path)['passed']


def test_assets_manifest_is_in_runtime_fingerprint_and_both_images():
    from runtime_identity import IDENTITY_FILES
    assert 'chatAi/assets/manifest.json' in IDENTITY_FILES
    for name in ['Dockerfile.account.cloud','Dockerfile.cloud']:
        source = (ROOT/name).read_text(encoding='utf8')
        assert 'COPY chatAi /app/chatAi' in source
        assert 'COPY tools/check_frontend_assets.py /app/tools/' in source
    for license_file in ['tailwindcss/LICENSE','prism/LICENSE','katex/LICENSE','font-awesome/LICENSE-FONT','font-awesome/LICENSE-CSS']:
        assert (ROOT/'chatAi/vendor'/license_file).stat().st_size > 100
