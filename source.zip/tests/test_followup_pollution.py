"""Offline acceptance tests for the follow-up context pollution fix.

Covers two regressions observed in the real session
``sciassistant_conversation_77e84465-1b43-4946-aa60-a8df1d8a2e0e.md``:

A. A self-contained follow-up ("RAG 的检索器和生成器分别做什么？") must be
   planned from its own topic. The previous round's vocabulary
   (LoRA/QLoRA) must not leak into the new query plan or the subquestion
   split, and the follow-up evidence classifier fallback must default to
   fresh multi-source retrieval (``search_required``) instead of
   ``reuse_only`` (which used to disable the multi-source ladder and
   produced an arxiv-only refusal for a hot RAG topic).

B. Exact arXiv paper-ID routes ("id:2305.14314v1", from explicit paper
   references and inherited follow-up papers) must reach the arXiv adapter
   via ``id_list`` instead of being rejected by the ti:/abs: entity gate,
   and non-arXiv sources must skip them with one honest ``skipped`` event
   instead of burning a round on free-text noise.

All tests are offline: the retrieval integration test mocks the arxiv
adapter, the public-source adapter, rotation state, the cache writer and
the LLM config.
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

import requests

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "deepdiver_v2") not in sys.path:
    sys.path.insert(0, str(ROOT / "deepdiver_v2"))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from deepdiver_v2.cli import demo  # noqa: E402
from deepdiver_v2.src.tools.mcp_tools import MCPTools  # noqa: E402


FOLLOWUP_CONTEXT = {
    "status": "ready",
    "previous_query": "LoRA 与 QLoRA 的核心差异是什么？",
    "paper_ids": ["2305.14314v1"],
    "previous_intent": {"task_type": "comparison", "entities": ["lora", "qlora"]},
}


def _offline_config():
    """A config object whose model URL is empty so no LLM is ever called."""
    return SimpleNamespace(
        get_custom_llm_config=lambda: {"url": "", "token": "", "timeout": 20},
        model_name="offline-test",
    )


class FollowupMergeTests(unittest.TestCase):
    """Problem A1: only referential follow-ups merge the parent topic."""

    def test_self_contained_followup_keeps_own_topic(self):
        # The RAG round in the real session: no pronoun, no deictic word, so
        # the previous LoRA/QLoRA topic must NOT be merged into retrieval text.
        query = "RAG 的检索器和生成器分别做什么？"
        with mock.patch.dict(demo.CONVERSATION_CONTEXT, FOLLOWUP_CONTEXT, clear=False):
            merged = demo._merge_followup_query_for_retrieval(query)
        self.assertEqual(merged, query)
        self.assertNotIn("LoRA", merged)
        self.assertNotIn("QLoRA", merged)

    def test_referential_followup_merges_parent(self):
        with mock.patch.dict(demo.CONVERSATION_CONTEXT, FOLLOWUP_CONTEXT, clear=False):
            merged = demo._merge_followup_query_for_retrieval("它的局限性是什么？")
        self.assertIn("LoRA 与 QLoRA 的核心差异是什么？", merged)
        self.assertIn("它的局限性是什么？", merged)


class FollowupDecisionFallbackTests(unittest.TestCase):
    """Problem A2: the classifier fallback must not demote a new topic."""

    def _decide(self, query):
        with mock.patch.dict(demo.CONVERSATION_CONTEXT, FOLLOWUP_CONTEXT, clear=False), \
             mock.patch.dict(os.environ,
                             {"MODEL_REQUEST_URL": "", "MODEL_REQUEST_TOKEN": ""},
                             clear=False), \
             mock.patch.object(demo, "get_config", return_value=_offline_config()):
            return demo._decide_followup_evidence_need(query)

    def test_self_contained_topic_defaults_to_search_required(self):
        decision, diag = self._decide("RAG 的检索器和生成器分别做什么？")
        self.assertEqual(decision, "search_required")
        self.assertEqual(diag["status"], "fallback")

    def test_referential_followup_defaults_to_reuse_and_search(self):
        decision, diag = self._decide("它的局限性是什么？")
        self.assertEqual(decision, "reuse_and_search")
        self.assertEqual(diag["status"], "fallback")

    def test_no_followup_context_is_search_required(self):
        with mock.patch.dict(demo.CONVERSATION_CONTEXT, {"status": "none"}, clear=True), \
             mock.patch.object(demo, "get_config", return_value=_offline_config()):
            decision, diag = demo._decide_followup_evidence_need("任意问题")
        self.assertEqual(decision, "search_required")
        self.assertEqual(diag["status"], "not_followup")


class ArxivIdQueryTests(unittest.TestCase):
    """Problem B: "id:xxxx" reaches arXiv via id_list, not the entity gate."""

    ATOM_FEED = b"""<?xml version="1.0" encoding="UTF-8"?>
<feed xmlns="http://www.w3.org/2005/Atom">
  <entry>
    <id>https://arxiv.org/abs/2305.14314v1</id>
    <updated>2023-05-23T00:00:00Z</updated>
    <published>2023-05-23T00:00:00Z</published>
    <title>QLoRA: Efficient Finetuning of Quantized LLMs</title>
    <summary>We present QLoRA, an efficient finetuning approach.</summary>
    <author><name>Test Author</name></author>
    <link href="https://arxiv.org/pdf/2305.14314v1" type="application/pdf"/>
    <category term="cs.CL"/>
  </entry>
</feed>"""

    class _Response:
        def __init__(self, status_code, content=b""):
            self.status_code = status_code
            self.content = content
            self.headers = {}

        def raise_for_status(self):
            if self.status_code >= 400:
                raise requests.HTTPError(f"HTTP {self.status_code}", response=self)

    def _run(self, query):
        captured = {}

        class Session:
            def get(self, url, **kwargs):
                captured.update(kwargs)
                return ArxivIdQueryTests._Response(
                    200, ArxivIdQueryTests.ATOM_FEED
                )

        tools = MCPTools.__new__(MCPTools)
        tools.session = Session()
        with mock.patch.object(tools, "_reserve_arxiv_request", return_value=(True, 0.0)), \
             mock.patch.dict(os.environ, {"ARXIV_MAX_QUERY_VARIANTS": "1"}):
            result = tools.arxiv_search(query, max_results=5)
        return result, captured.get("params", {})

    def test_id_query_uses_id_list_and_succeeds(self):
        result, params = self._run("id:2305.14314v1")
        self.assertTrue(result.success)
        self.assertEqual(params.get("id_list"), "2305.14314v1")
        self.assertNotIn("search_query", params)
        self.assertEqual(len(result.data["papers"]), 1)
        self.assertEqual(result.data["papers"][0]["paper_id"], "2305.14314v1")

    def test_keyword_query_still_uses_search_query(self):
        result, params = self._run("world model")
        self.assertTrue(result.success)
        self.assertIn("search_query", params)
        self.assertNotIn("id_list", params)
        self.assertEqual(params["search_query"], '(ti:"world model" OR abs:"world model")')


class ContextIdQueryMultiSourceTests(unittest.TestCase):
    """Problem B integration: inherited-ID routes are arxiv-only in the ladder."""

    def test_inherited_id_round_skips_non_arxiv_sources(self):
        query = "它的局限性是什么？"  # referential -> reuse_and_search -> id route first

        def fake_paper(source, idx):
            return {
                "paper_id": f"{source}-{idx}", "id": f"{source}-{idx}",
                "title": f"Parameter-Efficient Fine-Tuning for HAR {idx}",
                "abstract": ("Parameter-efficient fine-tuning adapts large language "
                             "models with low-rank matrices and quantization."),
                "url": f"https://example.org/{source}/{idx}",
                "source": source, "published": "2024-01-01",
            }

        def fake_arxiv_search(search_query, max_results=5):
            return SimpleNamespace(
                success=True,
                data={"papers": [{
                    "paper_id": "2305.14314v1", "id": "2305.14314v1",
                    "title": "QLoRA: Efficient Finetuning of Quantized LLMs",
                    "abstract": ("We present QLoRA, an efficient finetuning approach "
                                 "that reduces memory usage enough to finetune a 65B "
                                 "parameter model on a single GPU."),
                    "url": "https://arxiv.org/abs/2305.14314v1",
                    "source": "arxiv", "published": "2023-05-23",
                }]},
                error=None, metadata={"warnings": []},
            )

        arxiv_calls = []

        def fake_arxiv_capture(search_query, max_results=5):
            arxiv_calls.append(search_query)
            return fake_arxiv_search(search_query, max_results)

        def fake_search_source(source, adapter_query, limit=3):
            return {"status": "ok",
                    "papers": [fake_paper(source, i) for i in range(limit)],
                    "error": None}

        tools = SimpleNamespace(
            arxiv_cooldown_remaining=None,
            arxiv_search=fake_arxiv_capture,
        )

        with tempfile.TemporaryDirectory() as tmp:
            diag_path = Path(tmp) / "diagnostics.jsonl"
            env = {
                "SCIASSISTANT_DIAGNOSTICS_PATH": str(diag_path),
                "MODEL_REQUEST_URL": "",
                "MODEL_REQUEST_TOKEN": "",
            }
            with mock.patch.dict(demo.CONVERSATION_CONTEXT, FOLLOWUP_CONTEXT, clear=False), \
                 mock.patch.dict(os.environ, env, clear=False), \
                 mock.patch.object(demo, "get_config", return_value=_offline_config()), \
                 mock.patch.object(demo, "search_source", side_effect=fake_search_source), \
                 mock.patch.object(demo, "source_skip_reason", return_value=""), \
                 mock.patch.object(demo, "put_literature_cache", return_value=None):
                _, diagnostics, _ = demo._search_relevant_literature(
                    query, "arxiv", tools, config=None
                )

        rounds = diagnostics.get("rounds") or []
        self.assertTrue(rounds)
        # Round 1 must run the inherited-ID route on arXiv only.
        first_round = [item for item in rounds if item["round"] == 1]
        arxiv_first = [item for item in first_round if item["source"] == "arxiv"]
        self.assertTrue(arxiv_first)
        self.assertEqual(arxiv_first[0]["query"], "id:2305.14314v1")
        self.assertEqual(arxiv_first[0]["source_status"], "ok")
        for item in first_round:
            if item["source"] in {"zenodo", "techrxiv", "hal"}:
                self.assertEqual(item["source_status"], "skipped")
                self.assertIn("exact paper-ID lookup", item.get("search_error") or "")
        # The id route never reached the non-arXiv adapters.
        self.assertTrue(arxiv_calls)
        self.assertTrue(any(str(call).startswith("id:") for call in arxiv_calls))
        # The refused-round aggregation stays honest: id route is not a source failure.
        self.assertFalse(diagnostics.get("search_failed"))
        self.assertEqual(diagnostics.get("sources_skipped", [])[-3:],
                         ["zenodo", "techrxiv", "hal"])
        self.assertEqual(diagnostics.get("followup_evidence_decision"),
                         "reuse_and_search")


if __name__ == "__main__":
    unittest.main(verbosity=2)
