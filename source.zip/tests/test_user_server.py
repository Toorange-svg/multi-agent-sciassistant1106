from pathlib import Path
import sys

import pytest

from tools import user_server as server


def values():
    return {'APP_ENV': 'production', 'SECRET_KEY': 'abcdefghijklmnopqrstuvwxyz0123456789',
        'USER_CREDENTIAL_ENCRYPTION_KEY': 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
        'MCP_SHARED_SECRET': '0123456789abcdefghijklmnopqrstuvwx',
        'MYSQL_USER': 'science', 'MYSQL_HOST': '127.0.0.1', 'MYSQL_DATABASE': 'science',
        'MYSQL_PASSWORD': 'database-private-0123456789', 'MODEL_REQUEST_URL': 'https://api.deepseek.com/chat/completions',
        'MODEL_NAME': 'configured-model', 'SCIASSISTANT_QDRANT_URL': 'https://vector.science.org',
        'SCIASSISTANT_QDRANT_API_KEY': 'vector-private-abcdefghijklmnopqrstuvwxyz',
        'SCIASSISTANT_EMBEDDING_MODEL': str(Path.cwd().anchor+'models/e5'),
        'MCP_SERVER_URL': 'http://127.0.0.1:6274/mcp', 'MCP_USE_STDIO': 'false',
        'PYMUPDF_LICENSE_MODE': 'agpl', 'PYMUPDF_AGPL_OBLIGATIONS_CONFIRMED': 'true',
        'PYMUPDF_CORRESPONDING_SOURCE_CONFIRMED': 'true',
        'PYMUPDF_SOURCE_URL': 'https://downloads.science.org/source.zip',
        'SCIASSISTANT_SOURCE_FINGERPRINT': 'a'*64, 'SCIASSISTANT_SOURCE_ARCHIVE_SHA256': 'b'*64}


def test_config_valid_only_without_private_release_dotenv(tmp_path, monkeypatch):
    monkeypatch.setattr(server, 'ROOT', tmp_path)
    assert all(server.config_checks(values(), 'a'*64).values())
    (tmp_path/'.env').write_text('PRIVATE=1')
    assert not server.config_checks(values(), 'a'*64)['no_dotenv_fallback']


@pytest.mark.parametrize('key,value,check', [
    ('ACCOUNT_BIND_ADDRESS', '0.0.0.0', 'loopback_nonprivileged_listener'),
    ('ACCOUNT_HOST_PORT', '80', 'loopback_nonprivileged_listener'),
    ('ACCOUNT_HOST_PORT', 'abc', 'loopback_nonprivileged_listener'),
    ('MYSQL_USER', 'root', 'mysql_not_root'), ('MODEL_REQUEST_TOKEN', 'shared-secret', 'shared_provider_keys_absent'),
    ('LLAMA_CLOUD_API_KEY', 'shared-secret', 'shared_provider_keys_absent'),
    ('OPENAI_API_KEY', 'shared-secret', 'shared_provider_keys_absent'),
    ('MODEL_REQUEST_URL', 'http://provider.org/v1', 'model_endpoint'),
    ('SCIASSISTANT_QDRANT_URL', 'http://vector.org', 'protected_vector_endpoint'),
    ('MCP_SERVER_URL', 'http://remote.org:6274/mcp', 'private_mcp_endpoint'),
    ('MCP_USE_STDIO', 'true', 'private_mcp_endpoint'),
    ('SECRET_KEY', 'REPLACE_WITH_PRIVATE_RANDOM_SIGNING_KEY', 'private_signing_key'),
    ('SCIASSISTANT_SOURCE_FINGERPRINT', 'c'*64, 'source_delivery_bound'),
])
def test_insecure_config_refused(tmp_path, monkeypatch, key, value, check):
    monkeypatch.setattr(server, 'ROOT', tmp_path)
    config = values(); config[key] = value
    assert not server.config_checks(config, 'a'*64)[check]


def test_private_config_bom_no_shell_expansion_no_parent_environment_leak(tmp_path, monkeypatch):
    root = tmp_path/'release'; root.mkdir(); monkeypatch.setattr(server, 'ROOT', root)
    config = tmp_path/'private.env'
    config.write_text('\ufeffAPP_ENV=production\nVALUE=${UNRELATED_SECRET}\nCOMMAND=$(do-not-execute)\n', encoding='utf8')
    config.chmod(0o600)
    monkeypatch.setenv('UNRELATED_SECRET', 'MUST_NOT_EXPAND')
    result = server.load_private_config(config)
    assert result['VALUE'] == '${UNRELATED_SECRET}' and result['COMMAND'] == '$(do-not-execute)'
    with pytest.raises(ValueError): server.load_private_config(root/'private.env')


def test_inherited_global_keys_cleared_and_all_state_inside_release(tmp_path, monkeypatch):
    monkeypatch.setattr(server, 'ROOT', tmp_path)
    for key in server.SHARED_KEYS: monkeypatch.setenv(key, 'ambient-secret')
    env = server.runtime_environment(values())
    assert all(env[key] == '' for key in server.SHARED_KEYS)
    assert all(Path(env[key]).is_relative_to(tmp_path/'logs') for key in server.STATE)
    assert env['SCIASSISTANT_EMBEDDING_ALLOW_DOWNLOAD'] == '0'
    assert env['SCIASSISTANT_WEB_BASE'] == ''


def test_launch_is_foreground_single_worker_no_shell_or_privilege_escalation():
    argv = server.launch_argv(values())
    assert argv[:3] == [sys.executable, '-m', 'gunicorn']
    assert argv[argv.index('--workers')+1] == '1'
    assert argv[argv.index('--bind')+1] == '127.0.0.1:5000'
    assert '--daemon' not in argv and not {'sudo', 'kill', 'sh'} & set(argv)


def test_dependency_failure_does_not_print_provider_or_database_output(tmp_path, monkeypatch, capsys):
    class Result:
        returncode = 1
        stdout = b'CANARY_PROVIDER_RESPONSE'
        stderr = b'CANARY_DATABASE_PASSWORD'
    monkeypatch.setattr(server.subprocess, 'run', lambda *a, **k: Result())
    assert not server.child_check(['check'], {}, 1)
    assert 'CANARY' not in capsys.readouterr().out


def test_windows_runtime_never_claimed_linux_deployment(monkeypatch):
    monkeypatch.setattr(server.sys, 'platform', 'win32')
    checks = server.preflight(values(), dependencies=False)
    assert not checks['passed'] and not checks['checks']['linux_x86_64_python311_venv']
    assert not checks['dependencies_checked'] and checks['answer_model_calls'] == 0
