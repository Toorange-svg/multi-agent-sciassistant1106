"""300s is a round admission cutoff, never an in-flight/publication deadline."""
import json
import time
from types import SimpleNamespace

import pytest

from multi_agent_pipeline_v2 import SOFT_TIME_POLICY, actionable_review_gaps
from multi_agent_workflow import WorkflowStore, WorkflowBudgetExceeded
from test_multi_agent_pipeline_v2 import agents, pipeline


def events(path):
    return [json.loads(line) for line in (path / "events.jsonl").read_text(encoding="utf-8").splitlines()]


def test_partial_qualified_answer_is_still_researchable():
    review = {"schema_version": "sciassistant.evidence-review/v5", "allowed_evidence_ids": ["e1"],
              "coverage": [{"group_id": "g1", "status": "partial", "recommended_action": "qualified_answer", "evidence_ids": ["e1"]},
                           {"group_id": "g1", "status": "not_reported"},
                           {"group_id": "g1", "status": "not_comparable"}]}
    assert actionable_review_gaps(review) == []
    assert actionable_review_gaps(review, include_qualified=True) == review["coverage"][:1]


@pytest.mark.parametrize("elapsed,expected", [(299.9, 1), (300, 1), (300.001, 0), (361, 0)])
def test_round_admission_cutoff_and_no_360_publication_kill(tmp_path, elapsed, expected):
    workers, calls = agents(recovery=True)
    flow, store = pipeline(tmp_path, workers)
    flow.time_policy = SOFT_TIME_POLICY
    flow._research_elapsed = lambda: elapsed
    # The estimate is already expired; it must not prevent writing/auditing.
    flow.time_budget_seconds = 1
    result = flow.run("soft", "owner", "Compare A")
    assert calls.count("gap_analyst") == expected
    if expected:
        assert result["run"]["status"] == "partial"
        assert calls[-2:] == ["writer", "citation_auditor"]
    else:
        assert result["run"]["failure_code"] == "INSUFFICIENT_EVIDENCE"
        assert any(e.get("reason_code") == "RESEARCH_START_CUTOFF" for e in events(tmp_path))


def test_started_round_finishes_after_300_then_writer_and_auditor_finish_after_360(tmp_path, monkeypatch):
    workers, calls = agents(recovery=True)
    flow, store = pipeline(tmp_path, workers)
    flow.time_policy = SOFT_TIME_POLICY
    elapsed = [299.0]
    flow._research_elapsed = lambda: elapsed[0]
    invoke = flow._invoke
    def slow_round(run_id, role, goal, inputs):
        if role == "gap_analyst":
            elapsed[0] = 390
            flow.deadline = time.monotonic() - 30
        return invoke(run_id, role, goal, inputs)
    monkeypatch.setattr(flow, "_invoke", slow_round)
    result = flow.run("soft", "owner", "Compare A")
    assert result["run"]["status"] == "partial"
    assert calls.count("gap_analyst") == 1
    assert calls[-2:] == ["writer", "citation_auditor"]
    assert result["run"]["model_calls_used"] == 8
    completed = [e for e in events(tmp_path) if e.get("event") == "gap_recovery_completed"]
    assert completed[0]["elapsed_seconds"] == 390


def test_soft_store_preserves_calls_and_cancellation_after_estimate(tmp_path):
    now = [1000.0]
    store = WorkflowStore(tmp_path / "state.sqlite3", clock=lambda: now[0])
    store.create_run("soft", "owner", time_budget_seconds=1, time_policy=SOFT_TIME_POLICY)
    now[0] += 500
    assert store.assert_active("soft")["status"] == "created"
    assert store.reserve_model_call("soft", "writer").deadline_at == now[0] + 120
    store.force_terminal("soft", "cancelled", failure_code="USER_CANCELLED")
    with pytest.raises(WorkflowBudgetExceeded):
        store.reserve_model_call("soft", "citation_auditor")


def test_soft_store_does_not_relax_ten_calls(tmp_path):
    store = WorkflowStore(tmp_path / "state.sqlite3")
    store.create_run("soft", "owner", time_policy=SOFT_TIME_POLICY)
    for _ in range(10):
        store.reserve_model_call("soft", "reviewer")
    with pytest.raises(WorkflowBudgetExceeded):
        store.reserve_model_call("soft", "writer")
    assert store.get_run("soft")["failure_code"] == "MODEL_CALL_BUDGET_EXCEEDED"


def test_legacy_store_deadline_unchanged(tmp_path):
    now = [1000.0]
    store = WorkflowStore(tmp_path / "state.sqlite3", clock=lambda: now[0])
    store.create_run("old", "owner", time_budget_seconds=1)
    now[0] += 2
    with pytest.raises(WorkflowBudgetExceeded):
        store.assert_active("old")


def test_initialization_counts_toward_300_seconds(tmp_path):
    workers, calls = agents(recovery=True)
    flow, _ = pipeline(tmp_path, workers)
    flow.time_policy = SOFT_TIME_POLICY
    flow.initialization_elapsed_seconds = 301
    flow.run("soft", "owner", "Compare A")
    assert "gap_analyst" not in calls


def test_cli_default_is_soft_and_legacy_explicit(monkeypatch):
    from tools import multi_agent_cli as cli
    seen = []
    monkeypatch.setattr(cli, "run_command", lambda args: seen.append(args.time_policy) or 0)
    assert cli.main(["run", "--query", "hello"]) == 0
    assert cli.main(["run", "--query", "hello", "--time-policy", "hard-deadline/v1"]) == 0
    assert seen == [SOFT_TIME_POLICY, "hard-deadline/v1"]


def test_soft_cli_supervisor_does_not_apply_whole_task_timeout(tmp_path, monkeypatch):
    from tools import multi_agent_cli as cli
    calls = []
    class Process:
        pid = 123
        returncode = 0
        def __init__(self, command, **_kwargs):
            assert command[-2:] == ["--query", "question"]
            assert SOFT_TIME_POLICY in command
        def communicate(self, timeout):
            calls.append(timeout)
            return "{}", ""
    monkeypatch.setattr(cli.subprocess, "Popen", Process)
    monkeypatch.setattr(cli, "finalize_worker_exit", lambda *_, **__: False)
    args = SimpleNamespace(output_root=str(tmp_path), storage_root=str(tmp_path / "store"),
        rag_mode="lexical", time_budget=1, time_policy=SOFT_TIME_POLICY,
        query_file=None, query="question", context_file=None)
    assert cli.supervise_live(args, "soft") == 0
    assert calls == [None]


def test_after_cutoff_partial_evidence_still_goes_to_writer(tmp_path):
    workers, calls = agents(partial=True)
    original = workers.reviewer.handler
    def review(packet):
        result = original(packet)
        result["output"]["coverage"] = [{"group_id": "g1", "status": "partial", "evidence_ids": ["arxiv-1"]}]
        return result
    workers.reviewer.handler = review
    flow, _ = pipeline(tmp_path, workers)
    flow.time_policy = SOFT_TIME_POLICY
    flow._research_elapsed = lambda: 301
    result = flow.run("soft", "owner", "Compare A")
    assert result["run"]["status"] == "partial"
    assert calls == ["planner", "retriever", "reviewer", "writer", "citation_auditor"]


def test_rejected_gap_does_not_loop_or_discard_approved_evidence(tmp_path):
    workers, calls = agents(partial=True)
    original = workers.reviewer.handler
    def review(packet):
        result = original(packet)
        result["output"]["coverage"] = [{"group_id": "g1", "status": "partial", "evidence_ids": ["arxiv-1"]}]
        return result
    workers.reviewer.handler = review
    def bad_gap(_):
        calls.append("gap_analyst")
        return {"output": {"gaps": [{"group_id": "not_allowed", "query": "outside scope"}]}}
    workers.gap_analyst.handler = bad_gap
    flow, _ = pipeline(tmp_path, workers)
    flow.time_policy = SOFT_TIME_POLICY
    result = flow.run("soft", "owner", "Compare A")
    assert result["run"]["status"] == "needs_review"
    assert calls.count("gap_analyst") == calls.count("retriever") == 1
    assert calls[-2:] == ["writer", "citation_auditor"]
    assert result["run"]["model_calls_used"] == 6
