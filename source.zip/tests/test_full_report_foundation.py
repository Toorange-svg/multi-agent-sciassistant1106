"""Offline acceptance fixtures are not a substitute for semantic report review."""
from copy import deepcopy
import json
import socket

import pytest

from tools import full_report_foundation as foundation


@pytest.fixture
def spec():
    return foundation.read_json(foundation.SPEC)


@pytest.fixture
def cases(spec):
    return foundation.build_cases(spec)


def test_six_families_and_all_scopes(cases):
    assert len(cases) == 24
    assert len({r["family"] for r in cases}) == 6
    assert {r["source_scope"] for r in cases} == {"uploaded_pdf", "public", "auto"}
    assert len({r["case_id"] for r in cases}) == 24
    assert all(len(r["requirements"]) > 4 for r in cases)


@pytest.mark.parametrize("variant", ["long_begin", "long_middle", "long_end"])
def test_long_length_and_critical_position(cases, variant):
    selected = [r for r in cases if r["variant"] == variant]
    assert len(selected) == 6
    for row in selected:
        assert 2_000 <= len(row["question"]) <= 5_000
        assert row["background_characters"] >= 2_000
        critical = next(r for r in row["requirements"] if r["requirement_id"] == row["critical_requirement_id"])
        fraction = critical["start"] / len(row["question"])
        low, high = {"long_begin": (0, .1), "long_middle": (.35, .65), "long_end": (.9, 1)}[variant]
        assert low <= fraction <= high


@pytest.mark.parametrize("family", ["methods_comparison", "table_metrics", "followup",
    "experiment_design", "wrong_premise", "multi_document_report"])
def test_position_variants_only_move_requirement_not_evidence_or_background(cases, family):
    group = [r for r in cases if r["family"] == family]
    assert len({r["background_sha256"] for r in group}) == 1
    expectations = [{r["requirement_id"]: (r["question_quote"], r["answer_kind"])
                     for r in c["requirements"]} for c in group]
    assert all(r == expectations[0] for r in expectations)
    backgrounds = []
    for case in group:
        assert [r["user_order"] for r in case["requirements"]] == list(range(1, len(case["requirements"]) + 1))
        question = case["question"]
        for req in case["requirements"]:
            assert question[req["start"]:req["end"]] == req["question_quote"]
            assert question.count(req["question_quote"]) == 1
        if case["variant"] != "short":
            for req in case["requirements"]:
                question = question.replace(req["question_quote"], "")
            backgrounds.append("".join(question.split()))
    assert len(set(backgrounds)) == 1


def test_no_model_network_or_live_permissions(spec, monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("offline benchmark attempted network")
    monkeypatch.setattr(socket.socket, "connect", forbidden)
    monkeypatch.setattr(foundation.subprocess, "run", forbidden)
    original = deepcopy(spec)
    first = foundation.build_cases(spec)
    assert spec == original
    assert first == foundation.build_cases(spec)
    summary = foundation.benchmark_summary(first)
    assert summary["model_calls"] == summary["network_requests"] == 0
    assert summary["live_quality_verified"] is False
    assert all(r["grants_live_permissions"] is False and r["semantic_auto_approval"] is False
               and r["background_is_evidence"] is False for r in first)


def test_followup_is_synthetic_not_inherited_approved_evidence(cases):
    contexts = [r["context_fixture"] for r in cases if r["family"] == "followup"]
    assert len(contexts) == 4 and all(r == contexts[0] for r in contexts)
    assert contexts[0]["synthetic"] and not contexts[0]["prior_answer_is_evidence"]
    assert all(r["context_fixture"] is None for r in cases if r["family"] != "followup")


@pytest.mark.parametrize("mutation", ["schema", "background_evidence", "family_id", "duplicate_family",
    "unknown_critical", "duplicate_requirement", "missing_kind", "scope", "context_evidence", "long_length"])
def test_bad_fixtures_rejected(spec, mutation):
    family = spec["families"][0]
    if mutation == "schema":
        spec["schema_version"] = "future/v999"
    elif mutation == "background_evidence":
        spec["background_is_evidence"] = True
    elif mutation == "family_id":
        family["id"] = "../private"
    elif mutation == "duplicate_family":
        spec["families"].append(deepcopy(family))
    elif mutation == "unknown_critical":
        family["critical_requirement_id"] = "r999"
    elif mutation == "duplicate_requirement":
        family["requirements"].append(deepcopy(family["requirements"][0]))
    elif mutation == "missing_kind":
        family["requirements"][0].pop("answer_kind")
    elif mutation == "scope":
        family["source_scope"] = "private_auto_grant"
    elif mutation == "context_evidence":
        spec["families"][2]["context"]["prior_answer_is_evidence"] = True
    elif mutation == "long_length":
        spec["common_background"] = ["短背景"]
    with pytest.raises(ValueError, match="BENCHMARK_"):
        foundation.build_cases(spec)


def test_bom_and_duplicate_json_keys(tmp_path):
    path = tmp_path / "fixture.json"
    path.write_text('{"中文":"输入"}', encoding="utf-8-sig")
    assert foundation.read_json(path) == {"中文": "输入"}
    path.write_text('{"schema":1,"schema":2}', encoding="utf-8")
    with pytest.raises(ValueError, match="DUPLICATE_JSON_KEY"):
        foundation.read_json(path)


def test_oversize_json_rejected(tmp_path):
    path = tmp_path / "oversize.json"
    path.write_bytes(b" " * 2_000_001)
    with pytest.raises(ValueError, match="TOO_LARGE"):
        foundation.read_json(path)


def test_cli_unknown_case_exit_2_and_valid_case_hash(capsys):
    assert foundation.main(["case", "--case-id", "unknown"]) == 2
    assert json.loads(capsys.readouterr().out)["error"] == "BENCHMARK_CASE_UNKNOWN"
    assert foundation.main(["case", "--case-id", "wrong_premise-long_end"]) == 0
    value = json.loads(capsys.readouterr().out)
    assert value["question_sha256"] == foundation.sha256(value["question"].encode())


def test_cli_question_only_does_not_send_gold_metadata(capsys):
    assert foundation.main(["case", "--case-id", "followup-long_end", "--question-only"]) == 0
    output = capsys.readouterr().out
    assert "question_sha256" not in output and "grants_live_permissions" not in output
    assert "原始LoRA" in output


def fake_checkout(tmp_path):
    checkout = tmp_path / "example"
    checkout.mkdir()
    for name in ("LICENSE", "source.py"):
        (checkout / name).write_text(name, encoding="utf-8")
    return {"repositories": [{"directory": "example", "url": "https://example.invalid/ref.git",
        "commit": "a" * 40, "license_file": "LICENSE", "license_spdx": "MIT",
        "license_sha256": foundation.sha256(b"LICENSE"),
        "reviewed_files": [{"path": "source.py", "sha256": foundation.sha256(b"source.py")}]}]}


@pytest.mark.parametrize("fault", [None, "commit", "origin", "dirty", "file", "license"])
def test_upstream_verification_fails_closed(tmp_path, monkeypatch, fault):
    pins = fake_checkout(tmp_path)
    def git(root, *args):
        if args == ("rev-parse", "HEAD"):
            return ("b" if fault == "commit" else "a") * 40
        if args == ("remote", "get-url", "origin"):
            return "wrong" if fault == "origin" else "https://example.invalid/ref.git"
        return " M source.py" if fault == "dirty" else ""
    monkeypatch.setattr(foundation, "_git", git)
    if fault in {"file", "license"}:
        (tmp_path / "example" / ("source.py" if fault == "file" else "LICENSE")).write_text("changed")
    result = foundation.check_upstreams(tmp_path, pins)
    assert result["passed"] is (fault is None)
    assert result["network_requests"] == result["model_calls"] == 0
    assert result["upstream_code_executed"] is False


@pytest.mark.parametrize("name", ["../private", "/etc/passwd", "missing.py"])
def test_source_paths_rejected(tmp_path, name):
    with pytest.raises(ValueError, match="REFERENCE_"):
        foundation._relative_file(tmp_path, name)


def test_source_link_rejected(tmp_path, monkeypatch):
    link = tmp_path / "link.py"
    # Deterministic even on Windows accounts without symlink privileges.
    actual = type(link).is_symlink
    monkeypatch.setattr(type(link), "is_symlink", lambda path: path == link or actual(path))
    with pytest.raises(ValueError, match="LINK_REJECTED"):
        foundation._relative_file(tmp_path, "link.py")


def test_reference_hash_tolerates_checkout_line_endings_not_content(tmp_path):
    first, second = tmp_path / "lf.txt", tmp_path / "crlf.txt"
    first.write_bytes("原文\nsource\n".encode())
    second.write_bytes("原文\r\nsource\r\n".encode())
    assert foundation.source_sha256(first) == foundation.source_sha256(second)
    second.write_bytes("改变原文\r\nsource\r\n".encode())
    assert foundation.source_sha256(first) != foundation.source_sha256(second)
