"""Small account/conversation binding store; PDFs remain in the upload store.

No credentials or document text. A generation prevents a late upload response
from undoing an explicit detach or replacing a more recently submitted PDF.
"""
from contextlib import closing
from pathlib import Path
import sqlite3


class PdfSessions:
    def __init__(self, path: Path):
        self.path = Path(path)

    def _connect(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(self.path, timeout=5)
        try:
            connection.execute("""CREATE TABLE IF NOT EXISTS pdf_sessions (
                user_id TEXT NOT NULL, conversation_id TEXT NOT NULL,
                generation INTEGER NOT NULL, source_task_id TEXT,
                PRIMARY KEY (user_id, conversation_id))""")
        except BaseException:
            connection.close()
            raise
        return connection

    def get(self, user_id, conversation_id):
        with closing(self._connect()) as connection:
            row = connection.execute(
                "SELECT source_task_id FROM pdf_sessions WHERE user_id=? AND conversation_id=?",
                (str(user_id), str(conversation_id)),
            ).fetchone()
            return row[0] if row else None

    def reserve(self, user_id, conversation_id, *, detach=False):
        with closing(self._connect()) as connection, connection:
            connection.execute("""INSERT INTO pdf_sessions VALUES (?, ?, 1, NULL)
                ON CONFLICT(user_id, conversation_id) DO UPDATE SET
                generation=generation+1,
                source_task_id=CASE WHEN ? THEN NULL ELSE source_task_id END""",
                (str(user_id), str(conversation_id), bool(detach)))
            return connection.execute(
                "SELECT generation FROM pdf_sessions WHERE user_id=? AND conversation_id=?",
                (str(user_id), str(conversation_id)),
            ).fetchone()[0]

    def bind(self, user_id, conversation_id, generation, source_task_id):
        with closing(self._connect()) as connection, connection:
            result = connection.execute("""UPDATE pdf_sessions SET source_task_id=?
                WHERE user_id=? AND conversation_id=? AND generation=?""",
                (source_task_id, str(user_id), str(conversation_id), generation))
            return result.rowcount == 1


def pdf_path(upload_dir, task_id, filename):
    """Resolve a server-recorded basename only; never follow a PDF symlink."""
    import re
    from werkzeug.utils import secure_filename
    if not re.fullmatch(r"[0-9a-f]{12}", str(task_id)):
        raise ValueError("INVALID_PDF_SOURCE")
    if not isinstance(filename, str) or not 0 < len(filename) <= 255:
        raise ValueError("INVALID_PDF_SOURCE")
    # Filename is display metadata, not a client-supplied path.
    if "/" in filename or "\\" in filename or any(ord(c) < 32 for c in filename):
        raise ValueError("INVALID_PDF_SOURCE")
    name = secure_filename(filename)
    if not filename.lower().endswith(".pdf") or not name:
        raise ValueError("INVALID_PDF_SOURCE")
    root = Path(upload_dir).resolve()
    path = root / f"{task_id}_{name}"
    if path.is_symlink() or path.resolve().parent != root or not path.is_file():
        raise ValueError("PDF_SOURCE_UNAVAILABLE")
    return path
