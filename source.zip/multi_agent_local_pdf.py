"""Uploaded-PDF tool boundary for the existing six-role workflow.

No public search, no shared document index, no model-owned storage. A private
run-local index and content-derived IDs keep user files outside the arXiv cache.
"""
from __future__ import annotations

import hashlib
import re
import shutil
import time
from pathlib import Path

from multi_agent_live import LiveArxivRagExecutor
from multi_agent_rag import (EvidenceStore, HybridRetriever, LexicalReranker,
    LocalSentenceTransformerEmbedding, QdrantVectorStore, RagError)
from multi_agent_workflow import WorkflowError
from multi_agent_agents import sanitize_artifact_text
from multi_agent_handoffs import PLAN_SCHEMA, TYPED_PLAN_SCHEMAS, compile_passage_needs


MAX_PDF_BYTES = 30 * 1024 * 1024
LOCAL_ROLE_PROSE_POLICY = "requested-freezing-propagation-source-facet/v1"
PDF_PARSER_POLICY = "uploaded-pdf-explicit-cloud-consent-page-provenance/v1"


def pdf_parser_options(has_pdf, mode="local", consent=False):
    if mode not in {"local", "llama_full", "hybrid"} or type(consent) is not bool:
        raise ValueError("PDF_PARSER_OPTIONS_INVALID")
    if mode != "local" and not has_pdf:
        raise ValueError("LLAMA_PDF_REQUIRED")
    if mode != "local" and consent is not True:
        raise ValueError("LLAMA_CLOUD_CONSENT_REQUIRED")
    return {"pdf_parse_mode": mode, "llama_cloud_consent": mode != "local" and consent,
            "pdf_parser_policy": PDF_PARSER_POLICY}


def validate_pdf_input(value) -> Path:
    path = Path(value)
    # secure_filename('论文.pdf') becomes 'pdf' in the existing upload store.
    # Accept only that precise server basename form, still check actual bytes.
    stored_pdf = re.fullmatch(r"[0-9a-f]{12}_pdf", path.name) is not None
    if path.is_symlink() or not path.is_file() or (path.suffix.lower() != ".pdf" and not stored_pdf):
        raise ValueError("LOCAL_PDF_INPUT_INVALID")
    if not 0 < path.stat().st_size <= MAX_PDF_BYTES:
        raise ValueError("LOCAL_PDF_SIZE_LIMIT")
    with path.open("rb") as source:
        if not source.read(1024).lstrip().startswith(b"%PDF-"):
            raise ValueError("LOCAL_PDF_INPUT_INVALID")
    return path.resolve()


class LocalPdfRagExecutor(LiveArxivRagExecutor):
    search_action = "request_document_search"

    def __init__(self, run_dir, pdf, *, rag_mode="hybrid", services=None, parse=None,
                 pdf_parse_mode="local", llama_cloud_consent=False, embedding_cloud_consent=False):
        import os
        self.parser_options = pdf_parser_options(True, pdf_parse_mode, llama_cloud_consent)
        if type(embedding_cloud_consent) is not bool:
            raise ValueError('EMBEDDING_CONSENT_INVALID')
        self.embedding_cloud_consent = embedding_cloud_consent
        self.pdf_parse_mode = pdf_parse_mode
        self.pdf_input = validate_pdf_input(pdf)
        digest = hashlib.sha256(self.pdf_input.read_bytes()).hexdigest()
        self.document_id = "uploaded-" + digest[:24]
        private_root = Path(run_dir) / "private_rag"
        store = EvidenceStore(private_root / "evidence.sqlite3")
        if services is None:
            if rag_mode == "hybrid":
                from multi_agent_rag import configured_embedding
                embedding = configured_embedding(store, private_document=True, cloud_consent=embedding_cloud_consent)
                # Deliberately ignore the PUBLIC index URL/path/collection.
                vectors = QdrantVectorStore(dimension=embedding.dimension, path=private_root / "qdrant")
                services = HybridRetriever(store, embedding, vectors, vector_required=True, reranker=LexicalReranker())
            else:
                services = HybridRetriever(store)
        super().__init__(Path(run_dir), private_root, rag_mode=rag_mode, services=services, parse=parse)
        self.source_context = {"schema_version": "sciassistant.research-source/v1",
            "source_scope": "uploaded_pdf", "title": sanitize_artifact_text(self.pdf_input.name),
            "content_hash": digest, "public_search_allowed": False,
            "embedding_cloud_consent": embedding_cloud_consent,
            "embedding_external": bool(getattr(self.services.embedding, 'external', False)),
            "parser": pdf_parse_mode, **self.parser_options,
            "evidence_policy": "selected_passages_require_review_and_citation_audit"}
        self.source_context["local_role_prose_policy"] = LOCAL_ROLE_PROSE_POLICY

    def _parse(self, pdf):
        if self.pdf_parse_mode == "local":
            return super()._parse(pdf)
        import json
        import os
        import subprocess
        import sys
        from multi_agent_live import parser_process_options
        from process_cleanup import terminate_process_tree
        from user_credentials import child_environment
        remaining = min(120.0, self.retrieval_deadline - time.monotonic() - 15.0)
        if remaining < 5:
            raise RagError("LLAMA_PARSE_DEADLINE")
        output = pdf.with_name("parsed.json")
        options = parser_process_options()
        process = subprocess.Popen([sys.executable,
            str(Path(__file__).parent / "tools/multi_agent_parse_pdf.py"), str(pdf), str(output),
            "--mode", self.pdf_parse_mode, "--cloud-consent", "--timeout", str(remaining)],
            env=child_environment(os.environ), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **options)
        if os.name != "nt" and options.get("start_new_session"):
            process._sciassistant_process_group = process.pid
        try:
            process.wait(timeout=remaining)
            if not output.is_file() or output.stat().st_size > 16 * 1024 * 1024:
                raise RagError("LLAMA_PARSE_FAILED")
            parsed = json.loads(output.read_text(encoding="utf-8"))
            if process.returncode or not parsed.get("success"):
                code = parsed.get("error_code")
                raise RagError(code if code in {"LLAMA_PAGE_MAPPING_INVALID", "LLAMA_USER_KEY_REQUIRED",
                    "LLAMA_PARSE_FAILED", "LLAMA_PARSE_DEADLINE"} else "LLAMA_PARSE_FAILED")
            return parsed
        except subprocess.TimeoutExpired:
            raise RagError("LLAMA_PARSE_DEADLINE") from None
        finally:
            if process.poll() is None:
                terminate_process_tree(process)

    def has_more_reading(self, focus_groups=None):
        # Recovery re-queries already indexed passages, not another PDF/network.
        return False

    def retrieval_configuration(self):
        # Do not describe this private run using inherited arXiv download quotas.
        return {"source_scope": "uploaded_pdf", "vector_scope": "private_run_local",
            **self.parser_options, "cloud_parse_max_seconds": 120 if self.pdf_parse_mode != "local" else 0,
            "pdf_download_hosts": 0, "pdf_download_total_budget_seconds": 0,
            "pdf_download_max_attempts": 0, "pdf_download_deadline_policy": "not-applicable-user-provided-document",
            "pdf_batch_size": 1, "pdf_paper_limit": 1, "pdf_batch_limit": 1,
            "per_document_packet_limit": 4, "per_query_packet_limit": 4,
            "per_query_context_budget": 4000, "maximum_evidence_packets": 12,
            "topic_selection": "planned_queries_within_uploaded_document",
            "representative_document_limit_per_topic": 1,
            "packet_selection": "hybrid_within_uploaded_document",
              "local_role_prose_policy": LOCAL_ROLE_PROSE_POLICY,
            "priority_evaluation_passages_per_query": 1,
            "public_search_allowed": False}

    def reading_summary(self):
        phase = next((row.get("phase") for row in reversed(self.observations)
                      if row.get("source") == "uploaded_pdf" and row.get("phase") in {"pdf_parse", "pdf_index"}), None)
        return {"schema_version": "sciassistant.reading-budget/v1", "batch_size": 1,
            "embedding_api_requests_total": getattr(getattr(self.services.embedding, 'provider', None), 'request_count', 0),
            "paper_limit": 1, "batch_limit": 1, "batches_used": self.read_batches,
            "papers_attempted": self.pdf_reads, "papers_indexed": len(self.ingested),
            "candidates_observed": 1, "remaining_candidates": 0,
            "uploaded_pdf_indexed": len(self.ingested), "uploaded_pdf_phase": phase,
            **({"parser_summary": self.parse_summary} if hasattr(self, "parse_summary") else {})}

    def reading_decisions(self, stop_reason):
        return [{"paper_id": self.document_id, "source": "uploaded_pdf", "selection": "selected",
            "reason_code": "USER_PROVIDED_DOCUMENT", "reading_status": "pdf_indexed" if self.ingested else "not_indexed"}]

    def _index_pdf(self, deadline, progress):
        if self.ingested:
            return
        self.pdf_reads = 1
        self.read_batches = 1
        folder = self.run_dir / "pdf" / self.document_id
        folder.mkdir(parents=True, exist_ok=True)
        target = folder / "source.pdf"
        shutil.copyfile(self.pdf_input, target)
        metadata = {"document_id": self.document_id, "paper_id": self.document_id,
            "title": self.source_context["title"], "official_url": "",
            "content_hash": self.source_context["content_hash"]}
        for phase in ("pdf_parse", "pdf_index"):
            if time.monotonic() >= deadline:
                raise TimeoutError("LOCAL_PDF_READ_DEADLINE")
            self.observations.append({"source_status": "reading_phase", "phase": phase, "source": "uploaded_pdf"})
            if progress:
                progress(self._snapshot())
            started = time.monotonic()
            if phase == "pdf_parse":
                parsed = (self.parse or self._parse)(target)
                if not parsed.get("success", True):
                    raise RagError("LOCAL_PDF_PARSE_FAILED")
                blocks = parsed.get("layout_blocks") or parsed.get("evidence_blocks") or [
                    {"text": page.get("text"), "page": page.get("page")} for page in parsed.get("pages") or []]
                if not any(str(block.get("text") or "").strip() for block in blocks):
                    raise RagError("LOCAL_PDF_TEXT_EMPTY")
                self.parse_summary = parsed.get("parser_summary") or {"requested": "local", "actual": "local"}
                self.observations.append({"source": "uploaded_pdf", "source_status": "parser_completed",
                                          "parser_summary": self.parse_summary})
            else:
                indexed = self.indexer.index(metadata, blocks, deadline_monotonic=deadline)
                self.documents.put(self.document_id, metadata)
                self.ingested.add(self.document_id)
            self.observations.append({"source_status": phase + "_completed", "source": "uploaded_pdf",
                "elapsed_ms": round((time.monotonic() - started) * 1000)})
        self.observations.append({"source_status": "pdf_indexed", "source": "uploaded_pdf",
            "index_phase_timings_ms": indexed.get('phase_timings_ms', {}),
            "embedding_cache": indexed.get('embedding_cache', {}),
            "embedding_api_requests": indexed.get('embedding_api_requests', 0),
            "document_id": self.document_id, "chunk_count": indexed["chunk_count"], "paper_id": self.document_id})

    def execute(self, requests, *, recovery=False, group_ids=None, deadline=None, progress=None):
        # Reuse the initial strict query/group/quota validator without making
        # its arXiv-specific executor callable from this private boundary.
        from multi_agent_pipeline_v2 import complete_initial_search_actions
        if len(requests) > (2 if recovery else 6):
            raise WorkflowError("too many document searches")
        if any(set(row.get("arguments") or {}) - {"query", "group_id", "gap_id"} for row in requests):
            raise WorkflowError("document search cannot choose a path, URL or another document")
        plan = {"groups": [{"id": key, "queries": ["unused"]} for key in sorted(group_ids or self.plan_groups)]}
        complete_initial_search_actions(plan, requests, action=self.search_action)
        self.retrieval_deadline = float(deadline or time.monotonic() + 180)
        try:
            self._index_pdf(self.retrieval_deadline, progress)
        except Exception as exc:
            from multi_agent_pipeline_v2 import PipelineExecutionError
            code = str(exc) if str(exc) in {"LOCAL_PDF_PARSE_FAILED", "LOCAL_PDF_TEXT_EMPTY",
                "LLAMA_PAGE_MAPPING_INVALID", "LLAMA_USER_KEY_REQUIRED", "LLAMA_PARSE_FAILED",
                "LLAMA_PARSE_DEADLINE", "PDF_INDEX_DEADLINE", "LOCAL_PDF_READ_DEADLINE"} else "LOCAL_PDF_READ_FAILED"
            self.observations.append({"source_status": "pdf_failed", "source": "uploaded_pdf", "reason_code": code})
            if progress:
                progress(self._snapshot(recovery=recovery))
            raise PipelineExecutionError(code) from None
        selected, seen = [], {}
        for request in requests:
            if time.monotonic() >= self.retrieval_deadline:
                raise TimeoutError("LOCAL_PDF_RETRIEVAL_DEADLINE")
            args = request["arguments"]
            topic = self.plan_groups.get(args["group_id"], {})
            facets = list(dict.fromkeys(topic.get("support", [])))[:2]
            priority = []
            if topic.get("core"):
                # Captions are separately indexed, not hidden in a page's body
                # chunk. Give requested evaluation information its own bounded
                # local facet; still at most four packets / 4000 tokens/query.
                evaluation = re.search(r"accuracy|evaluation|protocol|dataset|split|准确|实验|划分|测试", " ".join(topic.get("metrics", [])), re.I)
                facet = str(topic["core"][0]) + (" accuracy test samples" if evaluation else " " + " ".join(topic.get("metrics", [])[:2]))
                facet = facet[:500]
                facets = list(dict.fromkeys([facet, *facets])) if evaluation else [*facets, facet]
                priority = [facet] if evaluation else []
            # A prose-supported frozen/update distinction is often in the
            # abstract, while formula-heavy method chunks dominate the main
            # query. This local-only facet shares the existing three searches
            # and four-packet quota; it never promotes/approves that passage.
            if re.search(r"冻结|反向传播|反传|\bfrozen\b|\bbackprop\w*\b|\bbackward\b", args["query"], re.I):
                facets = list(dict.fromkeys(["frozen backpropagates gradients backward", *facets]))
            need_plan = (compile_passage_needs(topic, {self.document_id: {}}, uploaded_document_id=self.document_id)
                if getattr(self, 'plan_schema', None) in TYPED_PLAN_SCHEMAS else {})
            if need_plan:
                self.observations.append({'source_status': 'passage_needs_compiled', 'source': 'uploaded_pdf', **need_plan})
            scoped_needs = need_plan.get('needs', [])
            packets = self.services.search(args["query"], limit=4, per_document=4,
                document_ids={self.document_id}, context_budget=4000,
                representative_document_ids=[self.document_id], passage_queries=[] if scoped_needs else facets[:3],
                priority_passage_queries=[] if scoped_needs else priority,
                **({'evidence_needs': scoped_needs} if scoped_needs else {}),
                deadline_monotonic=self.retrieval_deadline)
            for packet in packets:
                key = packet["evidence_id"]
                if key in seen:
                    seen[key]["group_ids"] = list(dict.fromkeys([*seen[key]["group_ids"], args["group_id"]]))
                    continue
                item = {**packet, "source": "uploaded_pdf", "official_url": "",
                    "group_id": args["group_id"], "group_ids": [args["group_id"]],
                    "excerpt": str(packet.get("text") or "")[:8000], "coverage_scope": "selected_chunks"}
                from multi_agent_evidence import evidence_strength, excerpt_content_scope, source_attribution_hint
                item.update(content_scope=excerpt_content_scope(item), evidence_strength=evidence_strength(item),
                            source_attribution=source_attribution_hint(item))
                seen[key] = item
                selected.append(item)
            self.selected = selected[:12]
            self.observations.append({"request_id": request["request_id"], "group_id": args["group_id"],
                "query": args["query"], "source": "uploaded_pdf", "source_status": "ok" if packets else "no_results",
                "accepted_count": len(packets), "recovery": recovery,
                "priority_passage_selected": any(p.get("retrieval", {}).get("priority_passage_selected") for p in packets)})
            if progress:
                progress(self._snapshot(recovery=recovery))
        return self._snapshot(recovery=recovery)
