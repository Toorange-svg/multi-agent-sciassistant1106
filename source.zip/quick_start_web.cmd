@echo off
setlocal
cd /d "%~dp0"
echo SciAssistant quick web launcher
echo Starting MCP, DeepDiver, research web, and account web...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0bin\windows\quick_start_web.ps1"
set EXIT_CODE=%ERRORLEVEL%
if not "%EXIT_CODE%"=="0" (
  echo Startup failed. Exit code: %EXIT_CODE%
  pause
  endlocal & exit /b %EXIT_CODE%
)
echo.
echo Account web:  http://127.0.0.1:5000/chat
echo Research web: http://127.0.0.1:5050/
echo MCP health:   http://127.0.0.1:6274/health
echo Startup command finished. Services continue in background.
pause
endlocal
