﻿import requests, json, time
def probe(name, url, params, timeout=12):
    t=time.monotonic()
    try:
        r=requests.get(url, params=params, timeout=timeout)
        return name, r.status_code, len(r.text), round(time.monotonic()-t,2), (r.text[:200] if r.status_code!=200 else "")
    except Exception as e:
        return name, "ERR", str(e)[:120], round(time.monotonic()-t,2), ""
tests = [
    ("hal_and", "https://api.archives-ouvertes.fr/search/", {"q":"title_t:(LoRA QLoRA core differences) OR abstract_t:(LoRA QLoRA core differences)","wt":"json","rows":3}),
    ("hal_or", "https://api.archives-ouvertes.fr/search/", {"q":"title_t:(LoRA OR QLoRA) OR abstract_t:(LoRA OR QLoRA)","wt":"json","rows":3}),
    ("hal_rag_and", "https://api.archives-ouvertes.fr/search/", {"q":"title_t:(retrieval augmented generation retriever role) OR abstract_t:(retrieval augmented generation retriever role)","wt":"json","rows":3}),
    ("hal_rag_or", "https://api.archives-ouvertes.fr/search/", {"q":"title_t:(retrieval augmented generation) OR abstract_t:(retrieval augmented generation)","wt":"json","rows":3}),
    ("zenodo", "https://zenodo.org/api/records", {"q":"LoRA QLoRA core differences","size":3,"sort":"bestmatch"}),
]
for name,url,params in tests:
    print(probe(name,url,params))
