"""Bounded in-process sliding-window limiter with no raw subject storage."""
from collections import deque
import math
import threading
import time


class SlidingWindowLimiter:
    def __init__(self, *, clock=time.monotonic, max_keys=10_000):
        if max_keys < 1:
            raise ValueError("max_keys must be positive")
        self._clock = clock
        self._max_keys = max_keys
        self._events = {}
        self._lock = threading.Lock()

    def check_and_record(self, specifications):
        """Atomically check [(opaque_key, limit, window_seconds), ...]."""
        now = float(self._clock())
        specs = list(specifications)
        if not specs:
            return True, 0
        with self._lock:
            retry_after = 0
            prepared = []
            for key, limit, window in specs:
                if not isinstance(key, str) or not key or limit < 1 or window < 1:
                    raise ValueError("invalid rate-limit specification")
                events = self._events.get(key)
                if events is None:
                    if len(self._events) >= self._max_keys:
                        self._evict_oldest()
                    events = self._events.setdefault(key, deque())
                cutoff = now - window
                while events and events[0] <= cutoff:
                    events.popleft()
                prepared.append((events, limit, window))
                if len(events) >= limit:
                    retry_after = max(retry_after, math.ceil(events[0] + window - now))
            if retry_after:
                return False, max(1, retry_after)
            for events, _, _ in prepared:
                events.append(now)
            return True, 0

    def _evict_oldest(self):
        empty = [key for key, events in self._events.items() if not events]
        if empty:
            del self._events[empty[0]]
            return
        oldest = min(self._events, key=lambda key: self._events[key][-1])
        del self._events[oldest]

    def clear(self):
        with self._lock:
            self._events.clear()

    def safe_snapshot(self):
        """Test/diagnostic view: opaque keys and counts only."""
        with self._lock:
            return {key: len(events) for key, events in self._events.items()}
