@echo off
setlocal
call "%~dp0bin\windows\check_status.cmd" %*
endlocal
