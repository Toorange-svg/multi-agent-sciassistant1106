@echo off
setlocal
cd /d "%~dp0"
call "%~dp0start_chat_5000.cmd" %*
exit /b %ERRORLEVEL%
