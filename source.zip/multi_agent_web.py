"""Web adapter for the independently tested V2 CLI; no account/Agent database ownership.

The gateway authorizes the task before dispatching any report or asset request.
This adapter exposes only hash-checked final/approved artifacts, never run folders.
"""
from __future__ import annotations

import html
import importlib.util
import json
import os
import re
import sys
from pathlib import Path

from multi_agent_agents import ArtifactDirectory, sanitize_artifact_text
from multi_agent_workflow import WorkflowStore, TERMINAL_STATUSES
from user_credentials import scoped_storage
from multi_agent_report_contracts import report_budget, is_soft_time_policy

ROOT = Path(__file__).resolve().parent
MODE = "multi_agent_rag"
PDF_MODE = "multi_agent_pdf"
WORKFLOW = "controlled_multi_agent_rag_v2"
SUCCESS = frozenset({"completed", "partial", "needs_review"})
STAGES = {
    "created": "正在规划研究问题", "planned": "正在生成检索动作",
    "retrieving": "正在检索与选择原文片段", "reviewing": "正在审查证据与覆盖缺口",
    "writing": "正在基于批准证据撰写", "auditing": "正在核验声明与引用",
}


def run_root() -> Path:
    return Path(os.getenv("SCIASSISTANT_MULTI_AGENT_WEB_RUN_ROOT", str(ROOT / "logs/multi_agent_web_runs"))).resolve()


def run_directory(task_id: str) -> Path:
    if not re.fullmatch(r"[0-9a-f]{12}", task_id):
        raise ValueError("invalid task id")
    path = run_root() / task_id
    if path.is_symlink() or not path.resolve().is_relative_to(run_root()):
        raise ValueError("unsafe run directory")
    return path


def _file(directory: Path, name: str, limit: int = 2_000_000) -> Path:
    path = directory / name
    if path.is_symlink() or not path.resolve().is_relative_to(directory.resolve()) or not path.is_file():
        raise FileNotFoundError("report unavailable")
    if path.stat().st_size > limit:
        raise ValueError("oversized report")
    return path


def readiness() -> dict:
    """Cheap, no model load/download/network probe. Real vector readiness is a CLI selfcheck."""
    missing = [name for name in ("sentence_transformers", "qdrant_client") if importlib.util.find_spec(name) is None]
    enabled = os.getenv("SCIASSISTANT_MULTI_AGENT_RAG_ENABLED", "1").lower() in {"1", "true", "yes"}
    return {"schema_version": "sciassistant.multi-agent-readiness/v1", "enabled": enabled,
            "ready": enabled and not missing, "missing_dependencies": missing,
            "runtime_validation_required": True, "model_call_limit": 10, "time_budget_seconds": 360,
            "retrieval_mode": "hybrid", "mcp_required": False,
            "message": "运行依赖已安装；首次使用前须完成本地模型向量自检。" if enabled and not missing else "新版 RAG 未就绪，请安装可选依赖或检查启用配置。"}


def command(task_id: str, query_file: Path, *, mode: str = "live", budget: int | None = None, context_file: Path | None = None, pdf: Path | None = None,
            source_policy=None, allow_public_search=False, pdf_parse_mode="local", llama_cloud_consent=False,
            report_profile='standard', task_namespace: str | None = None) -> list[str]:
    run_directory(task_id)
    config = report_budget(report_profile, time_budget=budget)
    budget = config['time_budget_seconds']
    if mode not in {"mock", "live"}:
        raise ValueError("invalid runtime configuration")
    from multi_agent_sources import source_options
    from multi_agent_local_pdf import pdf_parser_options
    pdf_parser_options(bool(pdf), pdf_parse_mode, llama_cloud_consent)
    sources = source_options(has_pdf=bool(pdf), policy=source_policy, allow_public=allow_public_search)
    storage = scoped_storage(os.getenv("SCIASSISTANT_MULTI_AGENT_WEB_STORAGE_ROOT", str(ROOT / "logs/multi_agent_web_rag")))
    if task_namespace:
        if not re.fullmatch(r"[0-9a-f]{12}", str(task_namespace)):
            raise ValueError("invalid task namespace")
        storage = storage / "tasks" / str(task_namespace)
    result = [sys.executable, str(ROOT / "tools/multi_agent_cli.py"), "run", "--worker",
            "--mode", mode, "--rag-mode", "hybrid", "--run-id", task_id,
            "--output-root", str(run_root()), "--storage-root", str(storage),
            "--query-file", str(query_file), "--time-budget", str(budget)]
    if report_profile != 'standard':
        result.extend(['--report-profile', report_profile])
    if context_file:
        result.extend(["--context-file", str(context_file)])
    if pdf:
        from multi_agent_local_pdf import validate_pdf_input
        result.extend(["--pdf", str(validate_pdf_input(pdf))])
        if pdf_parse_mode != "local":
            result.extend(["--pdf-parse-mode", pdf_parse_mode, "--llama-cloud-consent"])
    if sources["source_policy"] == "auto":
        result.extend(["--source-policy", "auto", "--allow-public-search"])
    return result


def environment(task_namespace: str | None = None) -> dict[str, str]:
    result = os.environ.copy()
    storage = scoped_storage(os.getenv("SCIASSISTANT_MULTI_AGENT_WEB_STORAGE_ROOT", str(ROOT / "logs/multi_agent_web_rag")))
    if task_namespace:
        if not re.fullmatch(r"[0-9a-f]{12}", str(task_namespace)):
            raise ValueError("invalid task namespace")
        storage = storage / "tasks" / str(task_namespace)
    if not result.get("SCIASSISTANT_QDRANT_URL"):
        result["SCIASSISTANT_QDRANT_PATH"] = str(storage / "qdrant")
    # No surprise downloads or excessive native thread counts in a Web request.
    result["SCIASSISTANT_EMBEDDING_ALLOW_DOWNLOAD"] = "0"
    result["SCIASSISTANT_SUPERVISED_CLI"] = "1"
    result.setdefault("OMP_NUM_THREADS", "2")
    result.setdefault("TOKENIZERS_PARALLELISM", "false")
    return result


def progress(task_id: str) -> dict | None:
    directory = run_directory(task_id)
    if not (directory / "workflow.sqlite3").is_file():
        return None
    store = WorkflowStore(_file(directory, "workflow.sqlite3", 100_000_000))
    run = store.get_run(task_id)
    stages = store.list_stages(task_id)
    latest = next((r["details"]["public_progress"] for r in reversed(stages)
                   if isinstance(r.get("details", {}).get("public_progress"), dict)), {})
    safe = {k: max(0, min(limit, latest[k])) for k, limit in {
        "papers_attempted": 16, "papers_indexed": 16, "batches_used": 4, "queries_finished": 8, "candidates_observed": 40,
        "uploaded_pdf_indexed": 1}.items()
        if isinstance(latest.get(k), int) and not isinstance(latest[k], bool)}
    if latest.get("phase") in {"pdf_download", "pdf_parse", "pdf_index", "reading_selected", "reading_batch_completed", "rag_selection_completed"}:
        safe["phase"] = latest["phase"]
    if latest.get("uploaded_pdf_phase") in {"pdf_parse", "pdf_index"}:
        safe["uploaded_pdf_phase"] = latest["uploaded_pdf_phase"]
    # No arbitrary stage details, queries, prompts, owner refs or disk paths.
    return {"workflow": WORKFLOW, "workflow_status": run["status"],
            "model_calls": run["model_calls_used"], "model_call_limit": run['max_model_calls'],
            "time_budget_seconds": run.get('time_budget_seconds', 360), "failure_code": run.get("failure_code"),
            'report_profile': run.get('report_profile', 'standard'),
            'research_start_cutoff_seconds': report_budget(run.get('report_profile', 'standard'))['research_start_cutoff_seconds'],
            "time_policy": run["time_policy"],
            "time_budget_is_estimate": is_soft_time_policy(run["time_policy"]),
            "reading_progress": safe,
            "stages": [{"stage": row["stage"], "status": row["status"], "sequence": row["sequence"]}
                       for row in stages[-30:]]}


def sync_terminal(task_id: str, status: str, code: str) -> None:
    directory = run_directory(task_id)
    if not (directory / "workflow.sqlite3").is_file():
        return
    store = WorkflowStore(_file(directory, "workflow.sqlite3", 100_000_000))
    run = store.get_run(task_id)
    if run["status"] not in TERMINAL_STATUSES or run["status"] in SUCCESS:
        store.force_terminal(task_id, status, failure_code=code, interrupt_unpublished_result=True,
                             details={"source": "web_publication_boundary", "previous_status": run["status"]})


def report(task_id: str) -> dict:
    directory = run_directory(task_id)
    manifest = json.loads(_file(directory, "manifest.json").read_text(encoding="utf-8"))
    if manifest.get("run_id") != task_id or not manifest.get("final_artifact_id"):
        raise FileNotFoundError("report not ready")
    artifacts = ArtifactDirectory(directory / "artifacts")
    if artifacts.root.is_symlink() or not artifacts.root.resolve().is_relative_to(directory.resolve()):
        raise ValueError("unsafe artifact directory")
    final = artifacts.get(manifest["final_artifact_id"])
    if final.get("run_id") != task_id or final.get("status") not in TERMINAL_STATUSES:
        raise ValueError("invalid final report")
    refs = final.get("artifact_refs") or {}
    approved = artifacts.get(refs["approved"]) if refs.get("approved") else {"evidence": []}
    ledger = []
    for item in approved.get("evidence") or []:
        if item.get("review_status") != "approved":
            continue
        paper_id = str(item.get("paper_id") or "")
        official = "https://arxiv.org/abs/" + paper_id if re.fullmatch(r"(?:\d{4}\.\d{4,5}|[a-z-]+(?:\.[A-Z]{2})?/\d{7})(?:v[1-9]\d*)?", paper_id) else ""
        page_number = (item.get("locator") or {}).get("page")
        official_pdf = "https://arxiv.org/pdf/" + paper_id if official else ""
        if official_pdf and isinstance(page_number, int) and page_number >= 1:
            official_pdf += f"#page={page_number}"
        index = len(ledger) + 1
        doc_id = str(item.get("document_id") or "")
        pdf = f"pdf/{doc_id}/source.pdf" if re.fullmatch(r"[A-Za-z0-9_-]{1,100}", doc_id) else None
        try:
            _file(directory, pdf, 30 * 1024 * 1024) if pdf else None
        except (OSError, ValueError):
            pdf = None
        page_image = f"pages/evidence-{index}.png"
        try:
            _file(directory, page_image, 10 * 1024 * 1024)
        except (OSError, ValueError):
            page_image = None
        page_size = None
        preview_locator = None
        if pdf and page_image:
            try:
                import fitz
                with fitz.open(directory / pdf) as document:
                    page_number = (item.get("locator") or {}).get("page")
                    if isinstance(page_number, int) and not isinstance(page_number, bool) and 1 <= page_number <= document.page_count:
                        from multi_agent_report import source_preview_geometry
                        preview_locator = source_preview_geometry(document[page_number - 1], item.get("locator") or {})
                        page_size = preview_locator["page_size"]
            except Exception:
                pass
        from multi_agent_evidence import evidence_strength, evidence_label
        ledger.append({"citation": index, "evidence_id": item["evidence_id"],
                       "source": item.get("source", "arxiv"),
                       "title": str(item.get("title") or ""), "paper_id": paper_id,
                       "official_url": official, "official_pdf_url": official_pdf,
                       "excerpt": str(item.get("excerpt") or "")[:16_000],
                       "excerpt_truncated": len(str(item.get("excerpt") or "")) > 16_000,
                       "locator": item.get("locator") or {}, "review_status": "approved",
                       "coverage_scope": item.get("coverage_scope"), "content_scope": item.get("content_scope"),
                       "parser_provenance": item.get("parser_provenance"),
                       "source_attribution": item.get("source_attribution"),
                       "evidence_strength": evidence_strength(item),
                       "evidence_strength_label": evidence_label(item),
                       "task_relevance": item.get("task_relevance", "not_classified"),
                       "source_domain": item.get("source_domain", ""), "source_scope_policy": item.get("source_scope_policy"),
                       "reviewed_group_ids": item.get("reviewed_group_ids"), "topic_association_policy": item.get("topic_association_policy"),
                       "retrieval_group_ids": item.get("group_ids") or [item.get("group_id")],
                       "published_at": item.get("published_at"), "updated_at": item.get("updated_at"),
                       "pdf_asset": pdf, "page_image_asset": page_image, "page_size": page_size,
                       "preview_locator": preview_locator})
    audit = artifacts.get(refs["audit"]) if refs.get("audit") else {"status": "not_available"}
    draft = artifacts.get(refs["draft"]) if refs.get("draft") else {}
    ids = {item["evidence_id"] for item in ledger}
    from multi_agent_quality import check_audit, publication_rejections
    if draft.get("claims"):
        audit = check_audit(audit, draft, {"evidence": ledger})
    rejected = publication_rejections(audit, draft)
    claims = [row for row in draft.get("claims") or [] if row.get("claim_id") not in rejected
              and "draft" not in rejected and row.get("evidence_ids") and set(row["evidence_ids"]).issubset(ids)]
    review = artifacts.get(refs["review"]) if refs.get("review") else {}
    from multi_agent_status import describe_status, source_execution_lines
    plan = artifacts.get(refs["plan"]) if refs.get("plan") else None
    display = describe_status(final["status"], audit=audit, coverage=review.get("coverage"), workflow_notice=review.get("recovery_notice"), plan=plan,
                              failure_code=final.get("failure_code"))
    if refs.get("source_execution"):
        display["source_execution_lines"] = source_execution_lines(artifacts.get(refs["source_execution"]), final.get("run_id"))
    from multi_agent_presentation import build_presentation
    presentation = build_presentation(claims, review.get('coverage'), ledger, plan)
    return {"schema_version": "sciassistant.web-rag-report/v1", "task_id": task_id,
            "status": final["status"], "failure_code": final.get("failure_code"),
            "direct_answer": sanitize_artifact_text(str(final.get("direct_answer") or "")),
            "status_display": display, "presentation": presentation,
            "limitation": display["description"] if final["status"] in {"partial", "needs_review"} else "",
            "references": ledger, "claims": claims, "draft_schema_version": draft.get("schema_version"), "coverage": review.get("coverage") or [],
            "audit_status": audit.get("status", "not_available"),
            "audit_has_unresolved_issues": bool(audit.get("code_issues") or audit.get("rejected_claim_ids") or audit.get("contract_errors")), "execution": progress(task_id),
            "source_routing": artifacts.get(refs["source_routing"]) if refs.get("source_routing") else None,
            "pdf_parser_result": manifest.get("pdf_parser_result"),
            "budget_usage": artifacts.get(refs["budget"]) if refs.get("budget") else None}


def asset(task_id: str, name: str) -> Path:
    # A final approved reference is the authority; arbitrary PDFs/HTML/SQLite are never served.
    if "\\" in name or ".." in name.split("/") or not re.fullmatch(r"(?:pages/evidence-[1-9]\d*\.png|pdf/[A-Za-z0-9_-]{1,100}/source\.pdf)", name):
        raise FileNotFoundError("asset unavailable")
    allowed = {item[key] for item in report(task_id)["references"] for key in ("pdf_asset", "page_image_asset") if item[key]}
    if name not in allowed:
        raise FileNotFoundError("asset unavailable")
    return _file(run_directory(task_id), name, 30 * 1024 * 1024)


def cached_paper_path(task_id: str, document_id: str) -> Path:
    """Gateway must check task ownership first. Cached original is NOT an approval."""
    if not re.fullmatch(r'arxiv-[A-Za-z0-9_-]{1,94}', document_id):
        raise FileNotFoundError('cached paper unavailable')
    path = _file(run_directory(task_id), f'pdf/{document_id}/source.pdf', 30 * 1024 * 1024)
    with path.open('rb') as stream:
        if not stream.read(1024).lstrip().startswith(b'%PDF-'):
            raise FileNotFoundError('cached paper unavailable')
    return path


def cached_papers(task_id: str) -> list[dict]:
    directory = run_directory(task_id)
    folder = directory / 'pdf'
    if folder.is_symlink() or not folder.is_dir():
        return []
    metadata = {}
    try:
        rows = json.loads(_file(directory, 'evidence_ledger.json').read_text(encoding='utf-8-sig'))
        for row in rows if isinstance(rows, list) else []:
            if isinstance(row, dict) and isinstance(row.get('document_id'), str):
                metadata[row['document_id']] = row
    except (OSError, ValueError):
        pass
    papers = []
    for document in sorted(folder.iterdir()):
        try:
            path = cached_paper_path(task_id, document.name)
        except (OSError, ValueError):
            continue
        info = metadata.get(document.name, {})
        try:
            local = json.loads(_file(directory, f'pdf/{document.name}/metadata.json', 128_000).read_text(encoding='utf-8-sig'))
            if isinstance(local, dict) and local.get('document_id') == document.name:
                info = local
        except (OSError, ValueError):
            pass
        papers.append({'id': task_id + ':' + document.name, 'dir': document.name,
            'title': str(info.get('title') or document.name), 'paper_id': info.get('paper_id'),
            'document_id': document.name, 'task_id': task_id, 'cache_kind': 'task', 'source': 'arxiv',
            'pdf_count': 1, 'size_mb': round(path.stat().st_size / 1024 / 1024, 2),
            'mtime': path.stat().st_mtime, 'downloaded_only': True, 'can_delete': False})
    return papers


def exported_report(data: dict, format_name: str) -> tuple[bytes, str]:
    from multi_agent_status import describe_status, status_markdown, status_html, OUTCOME_CSS
    display = describe_status(data["status"], audit={"status": data.get("audit_status"),
        "code_issues": [True] if data.get("audit_has_unresolved_issues") else []},
        coverage=data.get("coverage"), workflow_notice=data.get("status_display", {}).get("workflow_notice"),
        failure_code=data.get("failure_code") or (data.get("execution") or {}).get("failure_code") or
        ((data.get("status_display") or {}).get("billing_notice") or {}).get("code"))
    # Preserve the server's validated topic labels and detailed audit findings.
    for key in ("topic_summaries", "audit_findings", "source_execution_lines"):
        if key in data.get("status_display", {}):
            display[key] = data["status_display"][key]
    from multi_agent_presentation import report_content, bibliography, coverage_report, compact_status, COMPACT_CSS
    references = data.get('references') or []
    plan = {'groups': [{'id': row['group_id'], 'heading': row['title']}
        for row in display.get('topic_summaries', []) if row.get('group_id') and row.get('title')]}
    presentation, answer, cards = report_content(data.get('direct_answer') or '未生成科研结论。',
        data.get('claims'), data.get('coverage'), references, plan, markdown=format_name == 'md')
    if format_name == "json":
        return json.dumps({**data, "status_display": display, "presentation": presentation}, ensure_ascii=False, indent=2).encode("utf-8"), "application/json"
    if format_name == 'md':
        text = '# 多智能体科研 RAG 报告\n\n' + status_markdown(compact_status(display)) + '## 回答正文\n\n' + answer
        text += '\n\n## 原文证据与对应说明\n\n' + coverage_report(presentation,references,markdown=True) + '\n\n' + '\n\n'.join(cards)
        text += '\n\n' + bibliography(presentation, markdown=True) + '\n'
        return text.encode('utf-8-sig'), 'text/markdown; charset=utf-8'
    if format_name == 'html':
        text = '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>科研 RAG 报告</title>'
        text += '<style>body{max-width:1100px;margin:2rem auto;padding:1rem;font:16px/1.8 sans-serif;overflow-wrap:anywhere}blockquote{white-space:pre-wrap;background:#f6f8fc;padding:12px}article{border-top:1px solid #ccd4de;padding:16px 0}</style>'
        text += f'<style>{OUTCOME_CSS}{COMPACT_CSS}</style><h1>多智能体科研 RAG 报告</h1>' + status_html(compact_status(display))
        text += '<nav><a href="#answer">回答正文</a> · <a href="#evidence">原文证据</a> · <a href="#bibliography">参考文献</a></nav>'
        text += '<section id="answer"><h2>回答正文</h2>'+answer+'</section>'
        text += '<section id="evidence"><h2>原文证据与对应说明</h2>'+coverage_report(presentation,references)+''.join(cards)+'</section>'
        return (text + bibliography(presentation) + '</html>').encode('utf-8'), 'text/html; charset=utf-8'
    raise ValueError('unsupported report format')
