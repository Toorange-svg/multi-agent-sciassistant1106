"""Owner-scoped file/task links, not an Agent memory or a second RAG engine.

MySQL remains authoritative for original files. Task-owned PDF copies and the
existing Workflow own analysis/indexes. This SQLite ledger only links outcomes.
"""
from contextlib import closing
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
import threading

_PREVIEW_SLOTS = threading.BoundedSemaphore(2)


class PreviewError(ValueError):
    pass


def render_preview(path, page):
    """Render one requested page in a time/pixel-bounded disposable process.

    Explicit preview is NOT parsing/indexing for RAG, and does not change the
    library processing state. No PDF plugin or relaxed browser CSP is needed.
    """
    if type(page) is not int or not 1 <= page <= 10000:
        raise PreviewError('PREVIEW_PAGE_INVALID')
    if not _PREVIEW_SLOTS.acquire(blocking=False):
        raise PreviewError('PREVIEW_BUSY')
    try:
        result = subprocess.run([sys.executable, str(Path(__file__).resolve())],
            input=json.dumps({'path': str(path), 'page': page}).encode(),
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=15,
            env={key: value for key, value in os.environ.items() if key.upper() in
                 {'PATH', 'SYSTEMROOT', 'WINDIR', 'TEMP', 'TMP', 'LANG', 'LC_ALL'}},
            **({'creationflags': subprocess.CREATE_NO_WINDOW} if sys.platform == 'win32' else {}))
        if result.returncode != 0 or not result.stdout or len(result.stdout) > 10_000_000:
            raise PreviewError('PREVIEW_UNAVAILABLE')
        header, png = result.stdout.split(b'\n', 1)
        meta = json.loads(header)
        if (not png.startswith(b'\x89PNG\r\n\x1a\n') or meta.get('page') != page
                or type(meta.get('page_count')) is not int or not page <= meta['page_count'] <= 10000):
            raise PreviewError('PREVIEW_UNAVAILABLE')
        return meta, png
    except subprocess.TimeoutExpired:
        raise PreviewError('PREVIEW_TIMEOUT') from None
    except (OSError, ValueError):
        raise PreviewError('PREVIEW_UNAVAILABLE') from None
    finally:
        _PREVIEW_SLOTS.release()


def _render_child():
    import math
    if sys.platform != 'win32':
        import resource
        resource.setrlimit(resource.RLIMIT_CPU, (10, 10))
        resource.setrlimit(resource.RLIMIT_AS, (512 * 1024 * 1024, 512 * 1024 * 1024))
    try:
        import pymupdf as fitz
    except ImportError:
        import fitz
    value = json.loads(sys.stdin.buffer.read(16384))
    page = value['page']
    path = Path(value['path'])
    if type(page) is not int or not 1 <= page <= 10000 or path.is_symlink() or not 0 < path.stat().st_size <= 30 * 1024 * 1024:
        return 1
    with fitz.open(path) as document:
        if document.needs_pass or not page <= document.page_count <= 10000:
            return 1
        source = document[page - 1]
        width, height = source.rect.width, source.rect.height
        if not all(math.isfinite(v) and v > 0 for v in (width, height)):
            return 1
        scale = min(1.5, math.sqrt(1_980_000 / (width * height)), 4095 / max(width, height))
        pixmap = source.get_pixmap(matrix=fitz.Matrix(scale, scale), colorspace=fitz.csRGB, alpha=False)
        if pixmap.width * pixmap.height > 2_000_000:
            return 1
        png = pixmap.tobytes('png')
        sys.stdout.buffer.write(json.dumps({'page': page, 'page_count': document.page_count}).encode() + b'\n' + png)
    return 0

TERMINAL = frozenset({'completed', 'partial', 'needs_review', 'failed', 'timed_out', 'cancelled'})
LABELS = {'uploaded': '已上传（暂无任务索引记录）', 'queued': '等待解析', 'parsing': '正在解析',
          'indexing': '正在索引', 'indexed': '已索引（任务内）', 'failed': '处理失败',
          'cancelled': '处理已取消', 'unavailable': '处理记录暂不可用'}


class LibraryLinks:
    def __init__(self, path):
        self.path = Path(path)

    def _connect(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(self.path, timeout=5)
        try:
            connection.execute('''CREATE TABLE IF NOT EXISTS library_tasks (
                user_id TEXT NOT NULL, file_id TEXT NOT NULL, task_id TEXT NOT NULL,
                conversation_id TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(user_id, file_id, task_id))''')
        except BaseException:
            connection.close()
            raise
        return connection

    def link(self, user_id, file_id, task_id, conversation_id=None):
        if not re.fullmatch(r'[0-9a-f]{12}', str(task_id)):
            raise ValueError('invalid task id')
        with closing(self._connect()) as connection, connection:
            connection.execute('INSERT OR IGNORE INTO library_tasks(user_id,file_id,task_id,conversation_id) VALUES(?,?,?,?)',
                               (str(user_id), str(file_id), task_id, conversation_id))

    def tasks(self, user_id, file_id, limit=20):
        # Merely viewing an untouched library does not create a database.
        if not self.path.exists():
            return []
        with closing(sqlite3.connect(f'{self.path.resolve().as_uri()}?mode=ro', uri=True, timeout=5)) as connection:
            rows = connection.execute('''SELECT task_id, conversation_id FROM library_tasks
                WHERE user_id=? AND file_id=? ORDER BY rowid DESC LIMIT ?''',
                (str(user_id), str(file_id), min(20, max(1, limit)))).fetchall()
        return [{'task_id': row[0], 'conversation_id': row[1]} for row in rows]


def original_path(root, owner, row, *, must_exist=True):
    """Never let a DB path or a symlink grant access outside this owner's folder."""
    root = Path(root).resolve()
    owner = str(owner)
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,128}', owner):
        raise ValueError('invalid owner')
    folder = root / owner
    path = Path(row['file_path'])
    if folder.is_symlink() or path.is_symlink() or path.resolve().parent != folder.resolve():
        raise ValueError('unsafe library file')
    if path.exists() and not path.is_file():
        raise ValueError('unsafe library file')
    if must_exist and not path.is_file():
        raise FileNotFoundError('file unavailable')
    return path.resolve()


def copy_pdf(source, destination):
    """Bounded private copy; future file removal cannot invalidate old reports."""
    from multi_agent_local_pdf import validate_pdf_input, MAX_PDF_BYTES
    source = validate_pdf_input(source)
    digest = hashlib.sha256()
    size = 0
    created = False
    try:
        with source.open('rb') as original, Path(destination).open('xb') as target:
            created = True
            while block := original.read(1024 * 1024):
                size += len(block)
                if size > MAX_PDF_BYTES:
                    raise ValueError('LOCAL_PDF_SIZE_LIMIT')
                target.write(block)
                digest.update(block)
        validate_pdf_input(destination)
    except BaseException:
        if created:
            Path(destination).unlink(missing_ok=True)
        raise
    return digest.hexdigest()


def snapshot(root, task_id):
    if not re.fullmatch(r'[0-9a-f]{12}', task_id):
        return None
    root = Path(root).resolve()
    path = root / (task_id + '.json')
    try:
        if path.is_symlink() or path.resolve().parent != root or not 0 < path.stat().st_size <= 5_000_000:
            return None
        value = json.loads(path.read_text(encoding='utf-8-sig'))
        return value if isinstance(value, dict) and value.get('id') == task_id else None
    except (OSError, ValueError):
        return None


def processing_state(task):
    if not task:
        return 'uploaded'
    progress = (task.get('execution') or {}).get('reading_progress') or {}
    # An unrelated public paper being indexed never proves this PDF was indexed.
    if type(progress.get('uploaded_pdf_indexed')) is int and progress['uploaded_pdf_indexed'] == 1:
        return 'indexed'
    status = task.get('status')
    if status in {'failed', 'timed_out'}:
        return 'failed'
    if status == 'cancelled':
        return 'cancelled'
    if status in TERMINAL:
        return 'unavailable'  # No recorded proof, not a fabricated index verdict.
    phase = progress.get('uploaded_pdf_phase')
    if phase == 'pdf_index':
        return 'indexing'
    if phase == 'pdf_parse':
        return 'parsing'
    return 'queued'


if __name__ == '__main__':
    try:
        raise SystemExit(_render_child())
    except Exception:
        raise SystemExit(1) from None
