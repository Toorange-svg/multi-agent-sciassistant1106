"""Small, dependency-free storage readiness guard for durable runtime paths."""

from __future__ import annotations

import os
from pathlib import Path
import shutil
from typing import Iterable


DEFAULT_MIN_FREE_BYTES = 1024 * 1024 * 1024


def configured_min_free_bytes(raw_value: str | None = None) -> int:
    """Return a conservative, non-negative free-space threshold.

    Invalid values fall back to one GiB rather than silently disabling the
    readiness gate. Operators may set zero only when they explicitly accept
    responsibility for external disk monitoring.
    """
    raw_value = os.getenv("SCIASSISTANT_MIN_FREE_DISK_BYTES") if raw_value is None else raw_value
    if raw_value is None or str(raw_value).strip() == "":
        return DEFAULT_MIN_FREE_BYTES
    try:
        value = int(str(raw_value).strip())
    except (TypeError, ValueError):
        return DEFAULT_MIN_FREE_BYTES
    return value if value >= 0 else DEFAULT_MIN_FREE_BYTES


def has_minimum_free_space(paths: Iterable[Path | str], minimum_bytes: int) -> bool:
    """Check writable runtime roots without returning host paths to clients."""
    if minimum_bytes < 0:
        return False
    for raw_path in paths:
        path = Path(raw_path)
        try:
            if not path.is_dir() or not os.access(path, os.W_OK):
                return False
            if shutil.disk_usage(path).free < minimum_bytes:
                return False
        except OSError:
            return False
    return True
