"""Bounded, task-owned subprocess-tree termination; never kill by image name."""
from __future__ import annotations

import os
import signal
import subprocess
import threading
from dataclasses import dataclass, field


@dataclass
class _CleanupState:
    lock: threading.Lock = field(default_factory=threading.Lock)
    result: dict | None = None


_STATE_LOCK = threading.Lock()


def terminate_process_tree(process) -> dict:
    # Endpoint and worker can request cleanup concurrently. Keep the first
    # confirmed result; do not reinterpret an exited parent as a second kill.
    with _STATE_LOCK:
        state = process.__dict__.get("_sciassistant_cleanup_state")
        if not isinstance(state, _CleanupState):
            state = _CleanupState()
            process._sciassistant_cleanup_state = state
    with state.lock:
        if state.result is not None:
            return dict(state.result)
        result = _terminate(process)
        if result["parent_stopped"]:
            state.result = dict(result)
        return result


def _terminate(process) -> dict:
    result = {"scope": "local_cli_process_tree", "method": "parent_only",
              "tree_stop_requested": False, "tree_stop_confirmed": False,
              "parent_stopped": False, "status": "failed",
              "remote_mcp_cancelled": False}
    pid = getattr(process, "pid", None)
    group = process.__dict__.get("_sciassistant_process_group")
    try:
        parent_exited = process.poll() is not None
    except Exception:
        parent_exited = False
    # Only a group created by our Popen(start_new_session=True) can be killed.
    owned_group = (os.name != "nt" and type(pid) is int and pid > 1
                   and type(group) is int and group == pid and group != os.getpgrp())
    if os.name == "nt" and type(pid) is int and pid > 0 and not parent_exited:
        result.update(method="windows_taskkill", tree_stop_requested=True)
        try:
            # Crucially: kill the tree BEFORE terminating the wrapper. Once
            # the parent has exited, taskkill /T cannot reliably find children.
            command = subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False,
                timeout=5, creationflags=subprocess.CREATE_NO_WINDOW)
            result["tree_stop_confirmed"] = command.returncode == 0
        except Exception as exc:
            result["error_type"] = type(exc).__name__
    elif owned_group:
        result.update(method="posix_process_group", tree_stop_requested=True)
        try:
            os.killpg(group, signal.SIGKILL)
            result["tree_stop_confirmed"] = True
        except ProcessLookupError:
            result["tree_stop_confirmed"] = True
        except Exception as exc:
            result["error_type"] = type(exc).__name__
    try:
        if process.poll() is None:
            # Fallback for missing/failed tree termination. Do not label this
            # as tree-confirmed merely because the parent exited.
            process.terminate()
        process.wait(timeout=2)
        result["parent_stopped"] = process.poll() is not None
    except subprocess.TimeoutExpired:
        try:
            process.kill()
            process.wait(timeout=2)
            result["parent_stopped"] = process.poll() is not None
        except Exception as exc:
            result["error_type"] = type(exc).__name__
    except Exception as exc:
        result["error_type"] = type(exc).__name__
    result["status"] = ("confirmed" if result["parent_stopped"] and result["tree_stop_confirmed"]
                        else "partial" if result["parent_stopped"] else "failed")
    return result
