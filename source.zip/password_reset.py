"""Configuration and SMTP delivery for single-use password reset links."""

from __future__ import annotations

from dataclasses import dataclass
from email.message import EmailMessage
import os
import smtplib
import ssl
from urllib.parse import urlencode, urlsplit, urlunsplit


class ResetConfigurationError(RuntimeError):
    pass


def _enabled(value: str | None) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class ResetMailConfig:
    enabled: bool
    base_url: str = ""
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_username: str = ""
    smtp_password: str = ""
    from_address: str = ""
    use_tls: bool = True
    token_ttl_seconds: int = 900


def load_reset_mail_config() -> ResetMailConfig:
    enabled = _enabled(os.getenv("PASSWORD_RESET_ENABLED"))
    if not enabled:
        return ResetMailConfig(enabled=False)
    environment = os.getenv("APP_ENV", "production").strip().lower()
    base_url = os.getenv("PASSWORD_RESET_BASE_URL", "").strip()
    host = os.getenv("SMTP_HOST", "").strip()
    username = os.getenv("SMTP_USERNAME", "").strip()
    password = os.getenv("SMTP_PASSWORD", "")
    from_address = os.getenv("SMTP_FROM", "").strip()
    use_tls = _enabled(os.getenv("SMTP_USE_TLS", "true"))
    try:
        port = int(os.getenv("SMTP_PORT", "587"))
        ttl = int(os.getenv("PASSWORD_RESET_TOKEN_TTL_SECONDS", "900"))
        parsed = urlsplit(base_url)
        parsed.port
    except (TypeError, ValueError) as exc:
        raise ResetConfigurationError("PASSWORD_RESET_CONFIGURATION_INVALID") from exc
    safe_url = (
        parsed.scheme in ({"http", "https"} if environment in {"dev", "development", "test", "testing"} else {"https"})
        and bool(parsed.hostname)
        and parsed.username is None
        and parsed.password is None
        and not parsed.query
        and not parsed.fragment
    )
    if (
        not safe_url or not host or not username or not password or "@" not in from_address
        or not 1 <= port <= 65535 or not 300 <= ttl <= 3600
        or (environment not in {"dev", "development", "test", "testing"} and not use_tls)
    ):
        raise ResetConfigurationError("PASSWORD_RESET_CONFIGURATION_INVALID")
    return ResetMailConfig(
        True, base_url, host, port, username, password, from_address, use_tls, ttl
    )


def build_reset_link(base_url: str, token: str) -> str:
    parsed = urlsplit(base_url)
    return urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urlencode({"token": token}), ""))


def send_reset_email(config: ResetMailConfig, recipient: str, token: str) -> None:
    link = build_reset_link(config.base_url, token)
    message = EmailMessage()
    message["Subject"] = "SciAssistant 密码重置"
    message["From"] = config.from_address
    message["To"] = recipient
    message.set_content(
        "有人为您的 SciAssistant 账号申请了密码重置。\n\n"
        f"请在 {config.token_ttl_seconds // 60} 分钟内打开以下链接：\n{link}\n\n"
        "如果不是您发起的请求，请忽略此邮件。该链接只能使用一次。"
    )
    with smtplib.SMTP(config.smtp_host, config.smtp_port, timeout=10) as client:
        client.ehlo()
        if config.use_tls:
            client.starttls(context=ssl.create_default_context())
            client.ehlo()
        client.login(config.smtp_username, config.smtp_password)
        client.send_message(message)
