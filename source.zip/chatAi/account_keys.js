/* Account-only provider settings. Never store secrets/JWTs in local browser state. */
(() => {
    'use strict';
    const endpoint = '/5000/api/account/provider-keys';
    const dialog = document.getElementById('account-keys-dialog');
    const status = document.getElementById('account-keys-status');
    const deepseek = document.getElementById('account-deepseek-key');
    const backups = document.getElementById('account-deepseek-backups');
    const llama = document.getElementById('account-llama-key');
    const save = document.getElementById('account-keys-save');
    const onboarding = document.getElementById('account-keys-onboarding');
    let generation = 0, busy = false, dialogOwner = null;
    const wipe = () => { for (const input of [deepseek, backups, llama]) if (input) input.value = ''; };
    const same = owner => owner && owner === window.userToken;
    async function refresh() {
        const owner = window.userToken, ticket = ++generation;
        if (!owner || !status) return;
        status.textContent = '正在读取当前账号配置…';
        try {
            const response = await fetch(endpoint);
            if (!response.ok) throw new Error('账号配置暂不可用，请重新登录或稍后重试。');
            const data = await response.json();
            if (!same(owner) || ticket !== generation) return;
            if (data.schema_version !== 'sciassistant.account-provider-status/v1' ||
                typeof data.deepseek?.configured !== 'boolean' || typeof data.llama?.configured !== 'boolean') {
                throw new Error('账号配置响应无效，请稍后重试。');
            }
            status.textContent = `DeepSeek：${data.deepseek.configured ? `已配置 ${data.deepseek.key_count} 个 Key` : '未配置'}；LlamaParse：${data.llama.configured ? '已配置' : '未配置'}。密钥仅供本账号，服务端不回显原值。`;
            if (onboarding) onboarding.hidden = data.deepseek.configured;
            for (const id of ['account-keys-btn', 'sidebar-keys-btn']) {
                const button = document.getElementById(id);
                if (button) button.title = data.deepseek.configured ? '我的 API Keys（仅本账号）' : '请先填写自己的 DeepSeek API Key';
            }
            return data;
        } catch (error) { if (same(owner) && ticket === generation) status.textContent = error.message; }
    }
    function open(skipRefresh = false) {
        if (!window.userToken || !dialog) return;
        wipe(); dialogOwner = window.userToken;
        for (const provider of ['deepseek', 'llama']) document.getElementById(`account-clear-${provider}`).checked = false;
        if (!dialog.open) dialog.showModal();
        if (!skipRefresh) refresh();
    }
    function close() { ++generation; dialogOwner = null; wipe(); dialog?.close(); }
    for (const id of ['account-keys-btn', 'sidebar-keys-btn']) document.getElementById(id)?.addEventListener('click', () => open());
    document.getElementById('account-keys-close')?.addEventListener('click', close);
    dialog?.addEventListener('close', wipe);
    save?.addEventListener('click', async () => {
        if (busy) return;
        if (!same(dialogOwner)) { close(); return; }
        const owner = window.userToken, payload = {}, clear = [];
        const keys = [deepseek.value, ...backups.value.split(/[,;\n]+/)].map(v => v.trim()).filter(Boolean);
        if (keys.length) payload.deepseek_keys = [...new Set(keys)];
        if (llama.value.trim()) payload.llama_key = llama.value.trim();
        for (const provider of ['deepseek', 'llama']) if (document.getElementById(`account-clear-${provider}`)?.checked) clear.push(provider);
        if (clear.length) payload.clear = clear;
        if (!Object.keys(payload).length) { status.textContent = '请输入新密钥，或勾选清除；留空会保留已保存配置。'; return; }
        busy = true; save.disabled = true; status.textContent = '正在保存当前账号配置…';
        try {
            const response = await fetch(endpoint, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload)});
            if (!same(owner)) { close(); return; }
            if (!response.ok) throw new Error('保存失败，请检查密钥格式和清除选项；未改其他账号配置。');
            wipe(); for (const provider of ['deepseek', 'llama']) document.getElementById(`account-clear-${provider}`).checked = false;
            await refresh();
        } catch (error) { if (same(owner)) status.textContent = error.message; }
        finally { busy = false; save.disabled = false; }
    });
    window.addEventListener('pagehide', close);
    window.addEventListener('storage', close);
    setInterval(() => { if (dialog?.open && !same(dialogOwner)) close(); }, 1000);
    // Read only the authenticated account's configuration flags, never key values.
    // A missing key prompts once on entry, without blocking browsing or registration.
    let initialized = false;
    async function initialize() {
        if (initialized || !window.userToken) return;
        initialized = true;
        const owner = window.userToken;
        const data = await refresh();
        if (same(owner) && data?.deepseek.configured === false && !dialog.open) open(true);
    }
    if (document.readyState === 'loading') window.addEventListener('DOMContentLoaded', initialize, {once: true});
    else initialize();
    window.AccountKeys = {open, close, refresh};
})();
