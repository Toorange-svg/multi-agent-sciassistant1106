/* A tab-local selection hint, never an ownership proof or a PDF/credential store. */
(() => {
    'use strict';
    const key = 'sciassistant.active-conversation/v1';
    let revision = 0;
    const owner = () => String(window.chatSessionOwnerId || '');
    const valid = id => typeof id === 'string' && /^[A-Za-z0-9_-]{1,128}$/.test(id);
    const checkpoint = () => ({revision, owner: owner(), credential: window.userToken});
    const isCurrent = ticket => !!ticket && ticket.revision === revision &&
        ticket.owner === owner() && ticket.credential === window.userToken;
    function forget() {
        ++revision;
        try { window.sessionStorage.removeItem(key); } catch (_error) { /* Storage may be disabled. */ }
    }
    function remember(session) {
        ++revision;
        try {
            if (!owner() || !window.userToken || !valid(session)) window.sessionStorage.removeItem(key);
            else window.sessionStorage.setItem(key, JSON.stringify({owner: owner(), session}));
        } catch (_error) { /* Chat remains usable without browser storage. */ }
    }
    function restore(nodes, ticket) {
        if (!isCurrent(ticket) || !owner() || !window.userToken || window.currentSessionId) return false;
        let saved;
        try { saved = JSON.parse(window.sessionStorage.getItem(key)); } catch (_error) { return false; }
        if (!saved || saved.owner !== owner() || !valid(saved.session)) return false;
        // Only a node from the authenticated server list can nominate a session.
        const node = Array.from(nodes).find(item => item.dataset.id === saved.session);
        if (!node) { forget(); return false; }
        node.click();
        return true;
    }
    window.ConversationSelection = {checkpoint, isCurrent, remember, forget, restore};
})();
