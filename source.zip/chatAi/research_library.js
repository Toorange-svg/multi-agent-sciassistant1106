/* Originals are server-owned. Selecting a PDF is not starting/charging a run. */
(() => {
    'use strict';
    let selected = null, pendingUpload = null, ticket = 0, dialog = null, previewUrl = null;
    const key = () => ({owner: window.userToken, session: window.currentSessionId});
    const same = value => value.owner === window.userToken && value.session === window.currentSessionId;
    const endpoint = id => `/5000/api/research-library/files/${encodeURIComponent(id)}`;
    const badge = () => document.getElementById('library-selected-pdf');
    const multi = () => ['multi_agent_rag', 'multi_agent_pdf'].includes(document.getElementById('research-processing-mode')?.value);
    function resetConsent() {
        const local = document.getElementById('library-local-only'); if (local) local.checked = true;
        const publicChoice = document.getElementById('library-public-consent'); if (publicChoice) publicChoice.checked = false;
    }
    function clear() {
        selected = null; pendingUpload = null; ++ticket;
        const host = badge(); if (host) { host.hidden = true; host.replaceChildren(); }
    }
    function button(text, action) {
        const node = document.createElement('button'); node.type = 'button'; node.textContent = text;
        node.addEventListener('click', action); return node;
    }
    function render(name, staged, uploaded = false) {
        const host = badge(); if (!host) return;
        const label = document.createElement('span');
        label.textContent = uploaded ? '本轮上传 PDF' : `${staged ? '本轮选用' : '会话复用'}：${name}`;
        const choices = document.createElement('fieldset'); choices.className = 'library-source-choices';
        const legend = document.createElement('legend'); legend.textContent = '本轮资料来源'; choices.append(legend);
        for (const [id, value, text] of [
            ['library-local-only', 'local', '默认只读本文（不检索公开文献）'],
            ['library-public-consent', 'auto', '仅本轮：允许按我的问题补查公开文献（不发送 PDF 原文）']]) {
            const option = document.createElement('label');
            const radio = document.createElement('input'); radio.type = 'radio'; radio.name = 'library-source-policy';
            radio.id = id; radio.value = value; radio.checked = value === 'local';
            option.append(radio, document.createTextNode(text)); choices.append(option);
        }
        host.replaceChildren(label, choices);
        if (staged) host.append(button('取消选用', () => { clear(); window.SciencePdfSession?.restore(); }));
        if (!staged && !uploaded) host.append(button('移除会话引用', async () => {
            const current = key();
            try {
                const response = await fetch(`/5000/api/science/conversations/${encodeURIComponent(current.session)}/pdf-attachment`, {method: 'DELETE'});
                if (!response.ok) throw new Error('会话 PDF 引用移除失败，历史报告没有删除。');
                if (same(current)) { clear(); window.SciencePdfSession?.clear(); }
            } catch (error) { if (same(current)) window.showToast?.(error.message, 'error'); }
        }));
        host.hidden = !multi();
    }
    async function detail(id) {
        const response = await fetch(endpoint(id));
        if (!response.ok) throw new Error(response.status === 404 ? '资料已删除或不属于当前账号。' : '资料暂不可用，请重新登录或稍后重试。');
        return (await response.json()).file;
    }
    async function prepare(id) {
        const current = key(), sequence = ++ticket;
        try {
            const file = await detail(id);
            if (!same(current) || sequence !== ticket) return;
            if (!file.can_analyze) throw new Error('目前仅支持选用 PDF 进入多智能体分析。');
            if (!window.currentSessionId) {
                const session = await createNewSessionAndGetId('分析科研资料');
                if (!same(current) || sequence !== ticket) return;
                window.currentSessionId = session;
                window.ConversationSelection?.remember(session);
            }
            selected = {id, name: file.name, staged: true, ...key()};
            window.sciencePendingFile = null; window.sciencePendingSessionId = null;
            window.attachedContexts = [];
            document.querySelectorAll('[data-science-pending], #attachments-bar > *').forEach(node => node.remove());
            window.updateAttachmentsBarVisibility?.();
            document.getElementById('back-to-chat-btn').click();
            document.getElementById('research-processing-mode').value = 'multi_agent_rag';
            document.getElementById('research-processing-mode').dispatchEvent(new Event('change'));
            render(file.name, true);
            document.getElementById('user-input')?.focus();
            window.showToast?.('已选用 PDF。输入问题后才会创建任务和调用模型。', 'info');
        } catch (error) { if (same(current)) window.showToast?.(error.message, 'error'); }
    }
    async function append(form, session, mode, uploadedFile) {
        if (!['multi_agent_rag', 'multi_agent_pdf'].includes(mode)) return false;
        if (selected && !same(selected)) clear();
        const staged = selected;
        if (uploadedFile) {
            if (pendingUpload?.file !== uploadedFile || pendingUpload.owner !== window.userToken || pendingUpload.session !== session) pending(uploadedFile);
            const consent = document.getElementById('library-public-consent')?.checked === true;
            form.append('source_policy', consent ? 'auto' : 'local');
            form.append('allow_public_search', consent ? 'true' : 'false');
            return false;
        }
        if (staged) {
            if (staged.session !== session) throw new DOMException('资料所选会话已变化', 'AbortError');
            if (staged.staged) await detail(staged.id);
            else if (window.SciencePdfSession?.readBinding) {
                const binding = await window.SciencePdfSession.readBinding(session, true);
                if (!binding || binding.source_task_id !== staged.sourceTaskId) throw new Error('会话 PDF 引用已变化，请重新选用资料。');
            }
            if (!same(staged) || selected !== staged) throw new DOMException('资料或账号已变化', 'AbortError');
            form.append(staged.staged ? 'library_file_id' : 'pdf_source_task_id', staged.staged ? staged.id : staged.sourceTaskId);
        }
        if (staged) {
            const consent = document.getElementById('library-public-consent')?.checked === true;
            form.append('source_policy', consent ? 'auto' : 'local');
            form.append('allow_public_search', consent ? 'true' : 'false');
        }
        return !!staged;
    }
    function submitted(task) {
        pendingUpload = null;
        resetConsent();
        if (task.pdf_attachment) {
            selected = {id: task.library_file_id, name: task.pdf_attachment.filename,
                        sourceTaskId: task.pdf_attachment.source_task_id, staged: false, ...key()};
            render(selected.name, false);
        }
    }
    function attachment(value, current) {
        current = {session: current.session, owner: current.owner || current.credential};
        if (selected && same(selected)) return true;
        if (value?.source_task_id && same(current) && multi()) {
            selected = {id: value.library_file_id, name: value.filename, sourceTaskId: value.source_task_id, staged: false, ...key()};
            render(value.filename, false);
            return true;
        }
        else if (!selected) { const node = badge(); if (node) node.hidden = true; }
    }
    function pending(file) {
        clear();
        pendingUpload = {file, ...key()};
        render('', false, true);
    }
    const outcomeLabel = status => ({completed: '已完成', partial: '有限回答（覆盖不完整）', needs_review: '需要复核（仍有审查疑点）',
        failed: '执行失败', timed_out: '已超时', cancelled: '已取消', queued: '等待执行', running: '执行中', unavailable: '记录暂不可用'}[status] || '处理中');
    function close() {
        ++ticket;
        if (previewUrl) URL.revokeObjectURL(previewUrl); previewUrl = null;
        if (dialog) { dialog.close(); dialog.remove(); dialog = null; }
    }
    async function show(id, preview = false) {
        close(); const current = key(), sequence = ++ticket;
        try {
            const file = await detail(id);
            if (!same(current) || ticket !== sequence) return;
            const node = document.createElement('dialog'); node.className = 'research-library-dialog';
            const header = document.createElement('header'), title = document.createElement('h2'); title.textContent = file.name;
            header.append(title, button('关闭', close)); node.append(header);
            const status = document.createElement('p'); status.textContent = `${file.status}。${file.index_note}`; node.append(status);
            if (file.can_analyze) node.append(button('选用此 PDF 开始分析', () => { close(); prepare(id); }));
            const heading = document.createElement('h3'); heading.textContent = '关联会话与研究报告'; node.append(heading);
            if (!file.outcomes?.length) { const empty = document.createElement('p'); empty.textContent = '尚未使用此文件创建多智能体任务。'; node.append(empty); }
            for (const outcome of file.outcomes || []) {
                const row = document.createElement('div'); row.className = 'library-outcome';
                const label = document.createElement('span'); label.textContent = `${outcome.query} · ${outcomeLabel(outcome.status)}`; row.append(label);
                if (outcome.conversation_id) row.append(button('打开会话', () => {
                    const session = Array.from(document.querySelectorAll('.chat-session')).find(item => item.dataset.id === outcome.conversation_id);
                    if (session) { close(); document.getElementById('back-to-chat-btn').click(); session.click(); }
                    else window.showToast?.('会话不在当前列表中，可打开报告查看历史成果。', 'info');
                }));
                if (outcome.report_available) row.append(button('报告与原文引用', () => { close(); window.MultiAgentRagUI?.open(outcome.task_id); }));
                node.append(row);
            }
            document.body.append(node); dialog = node; node.libraryOwner = current.owner;
            node.addEventListener('cancel', event => { event.preventDefault(); close(); }); node.showModal();
            if (preview && file.can_analyze) {
                const viewer = document.createElement('section'); viewer.className = 'library-page-viewer';
                const controls = document.createElement('div'); controls.className = 'library-page-controls';
                const info = document.createElement('span'), image = document.createElement('img');
                image.alt = '科研资料 PDF 原文页'; let page = 1, count = 1, loading = false;
                const previous = button('上一页', () => load(page - 1)), next = button('下一页', () => load(page + 1));
                controls.append(previous, info, next, button('下载 PDF 原件', async () => {
                    try { await downloadAuthenticatedFile(`${endpoint(id)}/pdf`, file.name); }
                    catch (_) { if (same(current)) window.showToast?.('下载失败，请稍后重试。', 'error'); }
                }));
                viewer.append(controls, image); node.append(viewer);
                async function load(target) {
                    if (loading || target < 1 || target > count) return;
                    loading = true; previous.disabled = next.disabled = true; info.textContent = '正在读取原文页…';
                    try {
                        const response = await fetch(`${endpoint(id)}/pages/${target}`);
                        if (!response.ok) throw new Error('原文页暂不可用，可下载 PDF 原件查看。');
                        const total = Number(response.headers.get('X-PDF-Page-Count'));
                        if (!Number.isInteger(total) || total < target || total > 10000) throw new Error('原文页信息无效。');
                        const blob = await response.blob();
                        if (!same(current) || ticket !== sequence || dialog !== node) return;
                        if (previewUrl) URL.revokeObjectURL(previewUrl);
                        previewUrl = URL.createObjectURL(new Blob([blob], {type: 'image/png'}));
                        image.src = previewUrl; page = target; count = total;
                        info.textContent = `第 ${page} / ${count} 页 · 仅查看，不会调用模型或创建索引`;
                    } catch (error) { if (dialog === node && same(current)) info.textContent = error.message; }
                    finally { loading = false; previous.disabled = page <= 1; next.disabled = page >= count; }
                }
                await load(1);
            }
        } catch (error) { if (same(current)) window.showToast?.(error.message, 'error'); }
    }
    function changed() {
        ++ticket;
        if (selected && !same(selected)) clear();
        if (pendingUpload && (pendingUpload.owner !== window.userToken || pendingUpload.session !== window.currentSessionId || pendingUpload.file !== window.sciencePendingFile)) clear();
        const host = badge(); if (host) host.hidden = !multi() || !host.childNodes.length;
        resetConsent();
        restoreRag();
    }
    async function restoreRag() {
        if (document.getElementById('research-processing-mode')?.value !== 'multi_agent_rag' || selected) return;
        const current = key(), sequence = ticket;
        if (!current.session || !current.owner) return;
        try {
            let value;
            if (window.SciencePdfSession?.readBinding) value = await window.SciencePdfSession.readBinding(current.session);
            else {
                const response = await fetch(`/5000/api/science/conversations/${encodeURIComponent(current.session)}/pdf-attachment`);
                if (!response.ok) return;
                value = (await response.json()).attachment;
            }
            if (same(current) && sequence === ticket && !selected) attachment(value, {credential: current.owner, session: current.session});
        } catch (_) { /* Never guess a private file from a failed response. */ }
    }
    document.getElementById('research-processing-mode')?.addEventListener('change', changed);
    setInterval(() => { if (selected && !same(selected)) clear();
        if (pendingUpload && (pendingUpload.owner !== window.userToken || pendingUpload.session !== window.currentSessionId || pendingUpload.file !== window.sciencePendingFile)) clear();
        if (dialog && dialog.libraryOwner !== window.userToken) close(); }, 500);
    window.addEventListener('pagehide', () => { clear(); close(); });
    window.ResearchLibrary = {prepare, append, submitted, attachment, pending, clear, changed, show};
    restoreRag();
})();
