/* Account-authenticated evidence viewer. Content is rendered as text, never model HTML. */
(() => {
    'use strict';
    const SUCCESS = new Set(['completed', 'partial', 'needs_review']);
    let active = null;
    let center = null;
    const inlineReports = new Map();
    const COLUMN_RATIO_KEY = 'sciassistant.rag-columns/v1';
    function bindColumnResize(workspace, handle) {
        // Evidence starts narrower so the answer remains the primary reading area.
        let preferred = 35, shown = 35, minimum = 25, maximum = 75, dragging = null;
        try {
            const saved = window.localStorage?.getItem(COLUMN_RATIO_KEY);
            const value = Number(saved);
            if (saved !== null && Number.isFinite(value) && value >= 25 && value <= 75) preferred = value;
        } catch (_) { /* Layout remains usable when browser storage is blocked. */ }
        function save() {
            try { window.localStorage?.setItem(COLUMN_RATIO_KEY, String(preferred)); } catch (_) {}
        }
        function render() {
            const width = workspace.getBoundingClientRect().width;
            // Matches the 14px separator + two 5px CSS gutters, not the sidebar.
            const available = width - 24;
            const stacked = window.innerWidth <= 700 || width < 600;
            workspace.classList.toggle('rag-workspace-stacked', stacked);
            handle.tabIndex = stacked ? -1 : 0;
            handle.setAttribute('aria-hidden', String(stacked));
            if (available <= 0) return;
            minimum = stacked ? 25 : Math.max(25, Math.ceil(220 / available * 100));
            maximum = Math.min(75, 100 - minimum);
            shown = stacked ? preferred : Math.max(minimum, Math.min(maximum, preferred));
            workspace.style.setProperty('--rag-source-share', `${shown}fr`);
            workspace.style.setProperty('--rag-answer-share', `${100 - shown}fr`);
            handle.setAttribute('aria-valuemin', String(minimum));
            handle.setAttribute('aria-valuemax', String(maximum));
            handle.setAttribute('aria-valuenow', String(shown));
            handle.setAttribute('aria-valuetext', `原文证据 ${shown}%，回答 ${100 - shown}%`);
        }
        function set(value, persist = false) {
            if (!Number.isFinite(value)) return;
            preferred = Math.round(Math.max(minimum, Math.min(maximum, value)));
            render();
            if (persist) save();
        }
        function finish(cancelled = false) {
            if (!dragging) return;
            const prior = dragging; dragging = null;
            document.body.classList.toggle('rag-columns-resizing', false);
            if (cancelled) { preferred = prior.preferred; render(); }
            else save();
            if (handle.hasPointerCapture(prior.id)) handle.releasePointerCapture(prior.id);
        }
        handle.setAttribute('role', 'separator');
        handle.setAttribute('aria-orientation', 'vertical');
        handle.setAttribute('aria-label', '调整原文证据与回答宽度');
        handle.title = '左右拖动调整宽度；双击恢复均分；也可使用左右方向键';
        handle.addEventListener('pointerdown', event => {
            if (event.button !== 0 || event.isPrimary === false || dragging || handle.tabIndex < 0) return;
            event.preventDefault();
            handle.setPointerCapture(event.pointerId);
            handle.focus({preventScroll:true});
            dragging = {id:event.pointerId, x:event.clientX, shown, preferred};
            document.body.classList.toggle('rag-columns-resizing', true);
        });
        handle.addEventListener('pointermove', event => {
            if (!dragging || dragging.id !== event.pointerId) return;
            const available = workspace.getBoundingClientRect().width - 24;
            if (available > 0) set(dragging.shown + (event.clientX - dragging.x) / available * 100);
        });
        handle.addEventListener('pointerup', event => { if (dragging?.id === event.pointerId) finish(); });
        handle.addEventListener('pointercancel', event => { if (dragging?.id === event.pointerId) finish(true); });
        handle.addEventListener('lostpointercapture', event => { if (dragging?.id === event.pointerId) finish(true); });
        handle.addEventListener('dblclick', () => { if (handle.tabIndex >= 0) set(50, true); });
        handle.addEventListener('keydown', event => {
            if (handle.tabIndex < 0) return;
            if (event.key === 'Escape' && dragging) { event.preventDefault(); finish(true); return; }
            const step = event.shiftKey ? 10 : 2;
            const values = {ArrowLeft:shown - step, ArrowRight:shown + step, Home:minimum, End:maximum};
            if (Object.prototype.hasOwnProperty.call(values, event.key)) {
                event.preventDefault(); set(values[event.key], true);
            }
        });
        function resized() { finish(true); render(); }
        const observer = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(render) : null;
        observer?.observe(workspace);
        window.addEventListener('resize', resized);
        render();
        return {dispose() { finish(true); observer?.disconnect(); window.removeEventListener('resize', resized); }};
    }
    const currentState = state => sameIdentity(state.identity) && (state.inline
        ? inlineReports.get(state.task)?.state === state && state.dialog.isConnected !== false
        : active === state || center === state);
    function releaseInline(mount) {
        mount.layout?.dispose();
        mount.state?.controller.abort();
        mount.state?.urls.forEach(url => URL.revokeObjectURL(url));
        mount.source.textContent = '原文证据已关闭；请回到所属会话查看。';
        inlineReports.delete(mount.task);
    }
    const LABELS = {queued:'排队中', running:'执行中', searching:'检索中', needs_clarification:'待澄清',
        completed:'已完成 · 主要问题已覆盖', partial:'有限回答 · 内容已审查，覆盖不完整', needs_review:'需要复核 · 仍有审查疑点', failed:'分析未完成', timed_out:'超时', cancelled:'已取消'};
    const COVERAGE = {direct:'已有直接证据', indirect:'只有间接证据', partial:'证据不完整',
        not_reported:'未报告该指标', not_comparable:'不可直接比较', conflicting:'存在冲突', missing:'缺少证据'};
    const DISPLAY_LABELS = {'research problem':'研究问题','research_problem':'研究问题',
        'problem':'问题','direct evidence':'已有直接证据','partial coverage':'证据不完整'};
    const displayLabel = value => DISPLAY_LABELS[String(value || '').trim().toLowerCase()] || value;
    const normalized = value => String(value || '').replace(/\s+/g, '');
    function presentationFor(data) {
        if (data.presentation?.schema_version === 'sciassistant.report-presentation/v1') return data.presentation;
        // Compatibility for older report APIs; only explicit evidence IDs link notes.
        return {coverage_notes:(data.coverage || []).map((row, n) => ({note_id:`legacy-${n}`,
            title:displayLabel(row.topic || row.topic_id || row.group_id || '本轮研究问题'),
            metric_label:({definition:'概念与定义',role:'作用与用途',relation:'技术关系',latency:'推理延迟'})[row.metric] || displayLabel(row.metric) || '问题覆盖',
            status_label:COVERAGE[row.status || row.evidence_status] || '覆盖状态待确认', tone:'warning',
            summary:(row.missing_conditions || [])[0] || row.reason || '请结合相关结论与原文核对本项边界。',
            details:(row.missing_conditions || []).map(text => ({label:'具体缺口',text})),
            evidence_ids:(row.evidence_ids || []).filter(id => data.references.some(r => r.evidence_id === id)),claim_ids:[]})),
            claim_notes:(data.claims || []).map(c => ({...c,details:[
                ...(c.scope_note ? [{label:'结论适用范围',text:c.scope_note}] : []),
                ...(c.qualification && normalized(c.qualification)!==normalized(c.scope_note) ? [{label:'实验条件与证据边界',text:c.qualification}] : [])],
                detail_evidence_id:c.evidence_ids?.[0]})),bibliography:data.references};
    }
    function compactGroups(presentation) {
        if (Array.isArray(presentation.coverage_groups)) return presentation.coverage_groups;
        const groups = new Map();
        const generic = new Set(['可比性有限','不能直接横向比较','可比性尚未确认',
            '可给出有限结论，不补造缺失指标','需要补充检索','需要针对本项补充检索','按已批准证据回答']);
        for (const note of presentation.coverage_notes || []) {
            const main = (note.details || []).filter(d => ['具体缺口','审查依据'].includes(d.label)).map(d => d.text);
            const extra = (note.details || []).filter(d => !['具体缺口','审查依据'].includes(d.label)&&!generic.has(d.text)).map(d => d.text);
            if (['有直接证据','直接证据'].includes(note.status_label)&&!main.length&&!extra.length) continue;
            const paragraphs = [...new Map([...(main.length?main:[note.summary]),...extra].filter(Boolean).map(t => [normalized(t),t])).values()];
            const key = note.group_id || note.title;
            if (!groups.has(key)) groups.set(key,{title:note.title,evidence_ids:[],rows:[]});
            const group = groups.get(key); group.evidence_ids=[...new Set([...group.evidence_ids,...note.evidence_ids])];
            const prior = group.rows.find(row => JSON.stringify(row.paragraphs.map(normalized))===JSON.stringify(paragraphs.map(normalized)));
            if (prior) {
                prior.metric_labels=[...new Set([...prior.metric_labels,note.metric_label])];
                prior.status_labels=[...new Set([...prior.status_labels,note.status_label])];
            } else group.rows.push({metric_labels:[note.metric_label],status_labels:[note.status_label],paragraphs});
        }
        return [...groups.values()];
    }
    function coveragePanel(presentation, task, references, display) {
        const section = element('section',undefined,'rag-coverage-summary');
        section.ariaLabel='证据覆盖与缺口';
        const details = element('details', undefined, 'rag-coverage-details');
        const summary = element('summary', '证据覆盖与缺口');
        const body = element('div', undefined, 'rag-coverage-body');
        details.append(summary, body);
        const groups = compactGroups(presentation);
        for (const group of groups) {
            const topic=element('div',undefined,'coverage-group'); topic.append(element('h4',group.title));
            for (const row of group.rows) {
                const item=element('div',undefined,'coverage-row');
                item.append(element('h5',`${row.metric_labels.join('、')} · ${row.status_labels.join('、')}`));
                for (const text of row.paragraphs) item.append(element('p',text));
                topic.append(item);
            }
            const related=references.filter(r=>group.evidence_ids.includes(r.evidence_id));
            if (related.length) {
                const links=element('p',undefined,'coverage-links');links.append(element('span','相关原文：'));
                for (const ref of related) {
                    const cite=element('button',`[${ref.citation}]`,'rag-citation');cite.type='button';
                    cite.addEventListener('click',()=>jump(task,ref.citation));links.append(cite);
                }
                topic.append(links);
            }
            body.append(topic);
        }
        if (!groups.length) body.append(element('p','本轮未单独记录待补强项；具体适用范围仍需结合结果状态和原文核对。'));
        if (display?.workflow_notice) body.append(element('p',display.workflow_notice));
        section.append(details);
        return section;
    }
    function bibliographyNode(presentation, task, references) {
        const section = element('section', undefined, 'research-bibliography');
        section.append(element('h3', '参考文献'));
        const list = element('ol');
        for (const ref of presentation.bibliography) {
            const row = element('li');
            const title = element('button', `[${ref.citation}] ${ref.title}`); title.type = 'button';
            title.addEventListener('click', () => jump(task, ref.citation)); row.append(title);
            const source = references.find(r => r.evidence_id === ref.evidence_id) || ref;
            row.append(element('p', `${ref.source_label || (source.source==='uploaded_pdf'?'用户上传 PDF':'arXiv')}${ref.paper_id?' · '+ref.paper_id:''} · ${source.locator?.page || ref.page ? '第 '+(source.locator?.page || ref.page)+' 页' : '摘要或页码未定位'}`));
            list.append(row);
        }
        if (!presentation.bibliography.length) list.append(element('li', '本轮没有可列出的已批准参考文献。'));
        section.append(list); return section;
    }
    const root = task => `/5000/api/science/tasks/${encodeURIComponent(task)}/report`;
    const element = (tag, text, className) => {
        const node = document.createElement(tag);
        if (text !== undefined) node.textContent = text;
        if (className) node.className = className;
        return node;
    };
    // Separate presentation region, never prepend these messages to the answer.
    const OUTCOMES = {
        completed: ['已完成：主要问题已覆盖，回答通过审查', 'success',
            '本轮主要问题已有获批证据支持，保留的回答声明通过了引用审查。这不代表结论在所有模型、硬件或实验条件下都成立。',
            '可阅读和使用正文；引用具体数字时，仍应核对原文位置、实验条件和适用范围。'],
        partial: ['有限回答：已审查内容可用，但证据覆盖不完整', 'partial',
            '已有可靠证据形成有限回答，保留的声明通过审查；部分子问题、指标或可比实验仍有缺口。缺少数据或实验不可比，不等于现有回答有错误。',
            '可使用正文中有引用且说明适用范围的结论；不要把缺项补成确定数字，也不要将吞吐、显存改善直接当作延迟降低。'],
        needs_review: ['需要复核：仍有审查疑点，不能当作已核验结论', 'review',
            '本轮资料或回答仍存在未解决的审查疑点，例如证据冲突、引用支持或原文定位问题。它与“有限回答”不同：不只是覆盖不完整，可靠性也需要进一步核对。',
            '正文仅供待核对的研究线索；请先查看疑点与原文证据，再决定是否采用。未经核对，不应直接作为定量结论或正式报告依据。'],
        failed: ['分析未完成：未能形成可安全使用的回答', 'error',
            '本轮未能完成分析或没有可用证据，不能视为科研结论。安全失败说明并不代表该领域没有研究。',
            '查看失败说明，确认检索、网络或模型服务状态后再决定是否重试；不要从失败状态推断科学结论。'],
        timed_out: ['分析超时：预算内未完成', 'error', '本轮达到时间预算，已停止后续处理；不能视为已审查完成的回答。', '可查看已保存证据，缩小问题范围后重试。'],
        cancelled: ['已取消：分析已停止', 'neutral', '用户已停止本轮分析，已保存的片段不等于最终审查结论。', '如需完整回答，请重新提交任务。']
    };
    function billingAlert(display) {
        if (display?.billing_notice?.code !== 'MODEL_HTTP_402' && display?.failure_code !== 'MODEL_HTTP_402') return null;
        const owner = window.userToken;
        const alert = element('section', undefined, 'rag-billing-alert');
        alert.setAttribute('role', 'alert'); alert.ariaLabel = '模型服务余额提醒';
        alert.append(element('h3', '⚠ 余额不足 / 额度不可用（HTTP 402）'),
            element('p', '当前账号的模型服务拒绝了后续调用。请检查供应商余额、可用额度及 API Key 所属账号。'),
            element('p', '充值或更换自己的有效 Key 后，请手动重新发送问题。系统不会因打开此提示自动重试；本轮此前已完成的调用仍可能计费。'));
        const settings = element('button', '打开我的 API Keys', 'rag-billing-settings'); settings.type = 'button';
        settings.addEventListener('click', () => {
            if (owner && owner === window.userToken) window.AccountKeys?.open();
        });
        alert.append(settings); return alert;
    }
    function outcomePanel(status, display = null) {
        const copy = OUTCOMES[status] || ['处理中：尚未形成最终结论', 'neutral', '工作流仍在处理或状态尚未确认。', '请等待终态，不要将中间结果当作已核验回答。'];
        const panel = element('section', undefined, `rag-outcome-panel rag-outcome-${copy[1]}`);
        panel.ariaLabel = '结果状态与使用建议'; panel.dataset.resultStatus = status;
        const billing = billingAlert(display);
        if (billing) panel.append(billing);
        const explanation = element('details', undefined, 'rag-outcome-details');
        const collapsed = {completed: '回答已完成', partial: '已审查内容可用', needs_review: '需要复核', failed: '分析未完成', timed_out: '分析超时', cancelled: '已取消'}[status] || '查看结果说明';
        explanation.append(element('summary', collapsed), element('h3', copy[0]), element('p', copy[2]), element('p', `使用建议：${copy[3]}`));
        explanation.open = false;
        panel.append(explanation);
        if (display?.audit_label) explanation.append(element('p', `引用审查：${display.audit_label}`));
        if (display?.audit_findings?.length) explanation.append(element('p', `需要核对：${display.audit_findings.join('；')}`));
        return panel;
    }
    const identity = (accountOnly = false) => ({session: window.currentSessionId, credential: window.userToken, accountOnly});
    const sameIdentity = id => (id.accountOnly || id.session === window.currentSessionId) && id.credential === window.userToken;
    function downloadControl(task, format, dialogState = null) {
        const origin = identity();
        const button = element('button', `下载 ${format.toUpperCase()} 报告`); button.type = 'button';
        button.addEventListener('click', async () => {
            const id = dialogState ? dialogState.identity : origin;
            const current = () => sameIdentity(id) && (!dialogState || currentState(dialogState));
            if (!current()) return;
            button.disabled = true;
            try {
                const response = await fetch(`${root(task)}/export?format=${format}`,
                    dialogState ? {signal: dialogState.controller.signal} : {});
                if (!current()) return;
                if (!response.ok) throw new Error('报告下载失败或登录已失效。');
                const blob = await response.blob(); if (!current()) return;
                const url = URL.createObjectURL(blob), link = element('a');
                link.href = url; link.download = `sciassistant_rag_${task}.${format}`;
                document.body.append(link); link.click(); link.remove();
                setTimeout(() => URL.revokeObjectURL(url), 1000);
            } catch (err) {
                if (err.name !== 'AbortError' && current() && window.showToast) window.showToast(err.message, 'error');
            } finally { button.disabled = false; }
        });
        return button;
    }
    function reportDownloads(task, state = null) {
        const menu = element('details', undefined, 'rag-download-menu');
        menu.append(element('summary', '下载报告'));
        for (const format of ['html', 'md', 'json']) menu.append(downloadControl(task, format, state));
        return menu;
    }
    function flattenChatAnswer(message) {
        // A confirmed RAG history row may have used the legacy fold renderer.
        // Move its already-sanitized DOM, preserving all old text and citations.
        const legacy = message?.querySelector?.('.science-report-sections');
        const panels = legacy?.querySelectorAll('details.science-report-section');
        if (panels?.length) {
            const flat = element('div', undefined, 'rag-chat-answer');
            for (const panel of panels) {
                const title = panel.querySelector('summary')?.textContent;
                if (title && title !== '科研分析报告') flat.append(element('h3', title));
                const body = panel.querySelector('.science-report-body');
                if (body) flat.append(...Array.from(body.childNodes));
            }
            legacy.replaceWith(flat);
        }
        message?.querySelectorAll?.('.download-container').forEach(node => node.remove());
    }
    function close() {
        if (!active) return;
        active.controller.abort();
        active.urls.forEach(url => URL.revokeObjectURL(url));
        active.dialog.remove();
        active.returnFocus?.focus?.();
        active = null;
    }
    function closeCenter() {
        if (!center) return;
        center.controller.abort(); center.dialog.remove(); center.returnFocus?.focus?.(); center = null;
    }
    function jump(task, citation) {
        const mounted = inlineReports.get(task);
        if (mounted && sameIdentity(mounted.identity)) {
            if (!mounted.state?.loaded) { open(task, citation); return; }
            const card = mounted.source.querySelector(`#rag-${task}-${Number(citation)}`);
            if (card) {
                // Scroll the evidence pane ONLY; do not yank the chat/body.
                const toolbar = mounted.source.querySelector('.rag-toolbar');
                mounted.source.scrollTop = Math.max(0, card.offsetTop - (toolbar?.offsetHeight || 0) - 18);
                card.focus({preventScroll:true});
                // A phone uses stacked columns, so its source may be above
                // the visible answer. Desktop citations never move the chat.
                if (window.innerWidth <= 700) mounted.source.closest?.('.rag-source-column')?.scrollIntoView({block:'start'});
            } else window.showToast?.('此引用不在批准证据中，请核对报告。', 'error');
            return;
        }
        if (active?.task === task) {
            const card = active.dialog.querySelector(`#rag-${task}-${Number(citation)}`);
            if (card) { card.scrollIntoView({block:'start'}); card.focus(); }
            else if (window.showToast) window.showToast('此引用不在批准证据中，请核对报告。', 'error');
        } else open(task, citation);
    }
    async function request(url, state, asBlob = false) {
        const response = await fetch(url, {signal: state.controller.signal});
        if (!currentState(state)) throw new DOMException('会话已切换', 'AbortError');
        if (!response.ok) throw new Error(response.status === 401 ? '登录已失效，请重新登录。' : '资料不可用或不属于当前账号。');
        return asBlob ? response.blob() : response.json();
    }
    async function open(task, citation = null, accountOnly = false) {
        if (!/^[0-9a-f]{12}$/.test(task)) return;
        const candidate = inlineReports.get(task);
        const mount = candidate && sameIdentity(candidate.identity) ? candidate : null;
        if (!accountOnly && candidate && !mount) return;
        if (mount && accountOnly) closeCenter();
        if (mount?.state) {
            if (mount.state.loaded) { if (citation) jump(task, citation); return; }
            mount.state.pendingCitation = citation;
            return;
        }
        if (!mount) { close(); closeCenter(); }
        const dialog = mount ? mount.source : element('dialog', undefined, 'multi-agent-rag-dialog');
        if (mount) dialog.textContent = '';
        dialog.ariaLabel = accountOnly ? '科研报告与批准原文依据' : '原文证据面板';
        const toolbar = element('header', undefined, 'rag-toolbar');
        const heading = element('h2', accountOnly ? '科研报告与原文依据' : '原文证据');
        const dismiss = element('button', '关闭');
        dismiss.type = 'button'; dismiss.addEventListener('click', close);
        toolbar.append(heading);
        if (!mount) toolbar.append(dismiss);
        dialog.append(toolbar);
        const status = element('p', '正在认证读取报告…', 'rag-status');
        dialog.append(status);
        if (!mount) document.body.append(dialog);
        const state = {dialog, task, inline: Boolean(mount), identity: mount?.identity || identity(accountOnly),
            controller: new AbortController(), urls: [], returnFocus: document.activeElement, pendingCitation:citation};
        if (mount) mount.state = state;
        else { active = state; dialog.addEventListener('cancel', close); dialog.showModal(); }
        try {
            const data = await request(root(task), state);
            // A late JSON body from a dismissed report must not close its successor.
            if (!currentState(state)) {
                if (!mount && active === state && !sameIdentity(state.identity)) close();
                return;
            }
            status.remove();
            const presentation = presentationFor(data);
            if (accountOnly) {
                dialog.append(outcomePanel(data.status, {...data.status_display, failure_code:data.failure_code || data.execution?.failure_code}), reportDownloads(task, state));
            } else {
                for (const finding of data.status_display?.audit_findings || []) dialog.append(element('p', finding, 'rag-limitation'));
            }
            if (mount) mount.outcome.replaceWith(mount.outcome = outcomePanel(data.status, {...data.status_display, failure_code:data.failure_code || data.execution?.failure_code}));
            if (mount?.content && typeof window.renderPublishedRagBody === 'function' && typeof data.direct_answer === 'string') {
                // Reuse the existing escaping renderer on the authoritative
                // published body, not model HTML or a stale folded-history DOM.
                window.renderPublishedRagBody(mount.content, data.direct_answer);
                delete mount.content.dataset.ragCitationTask;
                decorate(mount.content, task);
                window.highlightCodeBlocks?.(mount.content);
                window.renderMathFormulas?.(mount.content);
            }
            const nav = element('nav', undefined, 'rag-navigation'); nav.ariaLabel = '报告内导航';
            const navigate = (label, target) => {
                const button = element('button', label); button.type = 'button';
                button.addEventListener('click', () => {
                    if (mount) { jump(task, target.dataset.citation); return; }
                    if (target.tagName === 'DETAILS') target.open = true;
                    target.scrollIntoView({block:'start'}); target.focus();
                });
                nav.append(button);
            };
            dialog.append(nav);
            const layout = element('div', undefined, 'rag-report-layout');
            const analysisColumn = mount ? mount.review : element('div', undefined, 'rag-analysis-column');
            const evidenceColumn = element('div', undefined, 'rag-evidence-column');
            if (mount) dialog.append(evidenceColumn);
            else { layout.append(analysisColumn, evidenceColumn); dialog.append(layout); }
            let answerBody = mount?.content || null;
            if (!mount && data.direct_answer) {
                const answer = element('section', undefined, 'rag-linked-answer');
                // Code-owned headings only. Model text never becomes executable HTML.
                for (const block of data.direct_answer.split(/\n\n/)) {
                    const heading = block.match(/^(#{3,4}) ([^\n]+)$/);
                    answer.append(element(heading ? `h${heading[1].length}` : 'p', heading ? heading[2] : block));
                }
                answer.tabIndex = -1; navigate('回答正文', answer);
                analysisColumn.append(answer); decorate(answer, task);
                answerBody = answer;
            }
            evidenceColumn.append(coveragePanel(presentation,task,data.references,data.status_display));
            if (!data.references.length) dialog.append(element('p', '没有可展示的批准原文。'));
            for (const ref of data.references) {
                const card = element('article', undefined, 'rag-evidence');
                card.id = `rag-${task}-${ref.citation}`; card.tabIndex = -1;
                card.dataset.citation = ref.citation;
                navigate(`[${ref.citation}]`, card);
                card.append(element('h3', `[${ref.citation}] ${ref.title}`));
                const locator = ref.locator || {};
                card.append(element('p', `位置：${locator.page ? `第 ${locator.page} 页` : '摘要'} · ${locator.section || '未标注章节'}；审核：已批准`));
                card.append(element('p', `证据等级：${ref.evidence_strength_label || '历史证据 · 来源层级未记录'}`));
                if (ref.parser_provenance?.parser === 'llamaparse') {
                    card.append(element('p', 'LlamaCloud 转写片段：页码已关联；转写不等于原文核验，公式和数字请对照原页。', 'rag-audit-note'));
                }
                card.append(element('blockquote', ref.excerpt));
                const related = presentation.claim_notes.filter(claim => claim.evidence_ids?.includes(ref.evidence_id));
                if (related.length) {
                    const detail = element('details'); detail.append(element('summary', '支持的结论与适用条件'));
                    for (const claim of related) {
                        const row = element('article'); row.append(element('p', claim.text));
                        if (claim.detail_evidence_id === ref.evidence_id && claim.details?.length) {
                            const full = element('details'); full.append(element('summary', '适用范围与实验条件（完整记录）'));
                            for (const field of claim.details) full.append(element('p', `${field.label}：${field.text}`));
                            row.append(full);
                        } else if (claim.details?.length) {
                            const canonical = data.references.find(r => r.evidence_id === claim.detail_evidence_id);
                            if (canonical) {
                                const view = element('button', `完整说明见 [${canonical.citation}]`); view.type='button';
                                view.addEventListener('click', () => jump(task, canonical.citation)); row.append(view);
                            }
                        }
                        detail.append(row);
                    }
                    card.append(detail);
                }
                const locate = element('button', `[${ref.citation}] 原文位置`); locate.type='button';
                locate.addEventListener('click', () => jump(task, ref.citation)); card.append(locate);
                if (ref.excerpt_truncated) card.append(element('p', '此处为长片段节选，请打开原文页核对完整内容。'));
                if (locator.anchor_text) card.append(element('p', `原文锚点：${locator.anchor_text}`));
                if (ref.official_url && /^https:\/\/arxiv\.org\/abs\//.test(ref.official_url)) {
                    const link = element('a', '官方论文页面'); link.href = ref.official_url;
                    link.target = '_blank'; link.rel = 'noopener noreferrer'; card.append(link);
                }
                if (ref.official_pdf_url && /^https:\/\/arxiv\.org\/pdf\//.test(ref.official_pdf_url)) {
                    const link = element('a', '官方 PDF 原文页'); link.href = ref.official_pdf_url;
                    link.target = '_blank'; link.rel = 'noopener noreferrer'; card.append(link);
                }
                if (ref.page_image_asset) {
                    const preview = element('button', '查看原文页 / 引用高亮'); preview.type = 'button';
                    preview.addEventListener('click', async () => {
                        if (card.querySelector('.rag-page-preview')) return;
                        preview.disabled = true;
                        try {
                            const blob = await request(`${root(task)}/assets/${ref.page_image_asset}`, state, true);
                            if (!currentState(state)) return;
                            const url = URL.createObjectURL(blob); state.urls.push(url);
                            const container = element('div', undefined, 'rag-page-preview');
                            const image = element('img'); image.src = url; image.alt = `原文第 ${locator.page} 页`;
                            container.append(image);
                            // New reports supply display-space boxes without changing source/audit coordinates.
                            // Older APIs have no preview_locator field; retain their ordinary-page fallback.
                            const hasPreview = Object.prototype.hasOwnProperty.call(ref, 'preview_locator');
                            const box = hasPreview ? ref.preview_locator?.bbox : locator.bbox;
                            const size = hasPreview ? ref.preview_locator?.page_size : ref.page_size;
                            let highlighted = false;
                            if (Array.isArray(box) && box.length === 4 && box.every(Number.isFinite) &&
                                Array.isArray(size) && size.length === 2 && size.every(Number.isFinite) && size[0] > 0 && size[1] > 0 &&
                                box[0] >= 0 && box[1] >= 0 && box[2] > box[0] && box[3] > box[1] && box[2] <= size[0] && box[3] <= size[1]) {
                                const mark = element('span', undefined, 'rag-bbox');
                                mark.style.left = `${100 * box[0] / size[0]}%`; mark.style.top = `${100 * box[1] / size[1]}%`;
                                mark.style.width = `${100 * (box[2] - box[0]) / size[0]}%`; mark.style.height = `${100 * (box[3] - box[1]) / size[1]}%`;
                                container.append(mark);
                                highlighted = true;
                            }
                            if (ref.preview_locator?.notice) card.append(element('p', ref.preview_locator.notice));
                            else if (!highlighted) card.append(element('p', '原文页已定位；此片段没有可用坐标框，请用锚点核对。'));
                            card.append(container);
                        } catch (err) { if (err.name !== 'AbortError') status.textContent = err.message; }
                        finally { preview.disabled = false; }
                    });
                    card.append(preview);
                }
                if (ref.pdf_asset) {
                    const pdf = element('button', `打开认证 PDF${locator.page ? ` · 第 ${locator.page} 页` : ''}`); pdf.type = 'button';
                    pdf.addEventListener('click', async () => {
                        pdf.disabled = true;
                        try {
                            const blob = await request(`${root(task)}/assets/${ref.pdf_asset}`, state, true);
                            if (!currentState(state)) return;
                            const url = URL.createObjectURL(blob); state.urls.push(url);
                            const target = `${url}${locator.page ? `#page=${locator.page}` : ''}`;
                            const link = element('a', 'PDF 已就绪，点击在新标签页查看');
                            link.href = target; link.target = '_blank'; link.rel = 'noopener noreferrer';
                            card.append(link); link.click();
                        } catch (err) { if (err.name !== 'AbortError') status.textContent = err.message; }
                        finally { pdf.disabled = false; }
                    });
                    card.append(pdf);
                }
                evidenceColumn.append(card);
            }
            (mount ? answerBody || analysisColumn : dialog).append(bibliographyNode(presentation, task, data.references));
            state.loaded = true;
            if (state.pendingCitation) {
                if (mount) jump(task, state.pendingCitation);
                else dialog.querySelector(`#rag-${task}-${Number(state.pendingCitation)}`)?.scrollIntoView({block:'start'});
            }
        } catch (err) {
            if (!mount && active === state && !sameIdentity(state.identity)) { close(); return; }
            if (err.name !== 'AbortError' && currentState(state)) {
                status.textContent = err.message;
                if (mount) mount.state = null; // allow an explicit retry, no polling loop
            }
        }
    }
    function decorate(message, task) {
        if (!message || message.dataset.ragCitationTask === task) return;
        message.dataset.ragCitationTask = task;
        const walker = document.createTreeWalker(message, NodeFilter.SHOW_TEXT);
        const nodes = [];
        while (walker.nextNode()) {
            const node = walker.currentNode;
            if (!node.parentElement.closest('a,button,code,pre,script,style') && /\[\d+\]/.test(node.nodeValue)) nodes.push(node);
        }
        for (const node of nodes) {
            const fragment = document.createDocumentFragment(); let start = 0;
            for (const match of node.nodeValue.matchAll(/\[(\d+)\]/g)) {
                fragment.append(document.createTextNode(node.nodeValue.slice(start, match.index)));
                const button = element('button', match[0], 'rag-citation'); button.type = 'button';
                button.title = '查看已批准证据及原文位置';
                button.addEventListener('click', () => jump(task, match[1])); fragment.append(button);
                start = match.index + match[0].length;
            }
            fragment.append(document.createTextNode(node.nodeValue.slice(start))); node.replaceWith(fragment);
        }
    }
    function attach(task, session, message) {
        if (!task || !/^[0-9a-f]{12}$/.test(task.id) || !sameIdentity({session, credential: window.userToken})) return;
        const display = {...task.status_display, failure_code: task.failure_code || task.execution?.failure_code};
        if (task.processing_mode !== 'multi_agent_rag') {
            const alert = billingAlert(display);
            if (alert && message && !message.querySelector('.rag-billing-alert')) message.prepend(alert);
            return;
        }
        const container = document.getElementById('chat-messages'); if (!container) return;
        if (message) { flattenChatAnswer(message); decorate(message, task.id); }
        if (container.querySelector(`[data-rag-report-task="${task.id}"]`)) return;
        const card = element('section', undefined, message ? 'rag-report-card rag-response-column' : 'rag-report-card'); card.dataset.ragReportTask = task.id;
        const execution = task.execution || {};
        const attachedIdentity = identity();
        const outcome = outcomePanel(task.status, display);
        const review = element('div', undefined, 'rag-review-details');
        card.append(outcome, review);
        const tools = element('footer', undefined, 'rag-report-tools');
        const actions = element('div', undefined, 'rag-answer-actions');
        if (task.report_available) {
            const view = element('button', '查看原文证据'); view.type = 'button';
            view.textContent = '定位原文证据';
            view.addEventListener('click', () => {
                if (!sameIdentity(attachedIdentity)) return;
                const mount = inlineReports.get(task.id);
                if (mount?.state?.loaded) { mount.source.scrollTop = 0; mount.source.focus({preventScroll:true}); }
                else open(task.id);
            }); actions.append(view, reportDownloads(task.id));
        }
        tools.append(actions);
        if (message) {
            const host = message.querySelector?.('[data-chat-content-wrapper]') || message;
            const body = Array.from(host.childNodes || host.children || []);
            const answer = element('div', undefined, 'rag-answer-body'); answer.append(...body);
            card.append(answer, tools);
            const workspace = element('div', undefined, 'rag-chat-workspace');
            const evidence = element('aside', undefined, 'rag-source-column');
            evidence.id = `rag-${task.id}-source-pane`; card.id = `rag-${task.id}-response-pane`;
            evidence.ariaLabel = '原文证据';
            const scroll = element('div', '正在读取已批准原文证据…', 'rag-source-scroll');
            scroll.tabIndex = 0; scroll.ariaLabel = '原文证据，独立滚动';
            const divider = element('div', undefined, 'rag-column-resizer');
            divider.setAttribute('aria-controls', `${evidence.id} ${card.id}`);
            evidence.append(scroll); workspace.append(evidence, divider, card); host.append(workspace);
            const layout = bindColumnResize(workspace, divider);
            message.classList?.add?.('rag-message-wide');
            const bubble = message.querySelector?.('.message-container');
            if (bubble) bubble.style.width = '100%';
            const mount = {task:task.id, identity:attachedIdentity, source:scroll, review, outcome, state:null, layout,
                content: message.querySelector?.('[data-chat-answer-content]')};
            const previous = inlineReports.get(task.id);
            if (previous) releaseInline(previous); // revoke old assets even before the 300ms cleanup tick
            inlineReports.set(task.id, mount);
            if (task.report_available) open(task.id);
            else scroll.textContent = '此任务暂时没有可展示的批准原文，请查看结果说明。';
        } else { card.append(tools); container.append(card); }
    }
    function update(task, loading) {
        if (!loading || task.processing_mode !== 'multi_agent_rag') return false;
        let panel = loading.querySelector('.rag-progress-panel');
        if (!panel) {
            const legacy = loading.querySelector('.science-status-label');
            const host = legacy?.parentElement || loading;
            host.classList.add('rag-progress-host');
            // Preserve the existing cancel button (and its listener), not a clone.
            const stop = loading.querySelector('.science-stop-btn');
            for (const old of loading.querySelectorAll('.science-status-label,.science-elapsed,.rag-budget,.rag-reading-progress,.fa-spinner')) old.remove();
            panel = element('section', undefined, 'rag-progress-panel');
            panel.ariaLabel = '科研分析进度';
            const header = element('div', undefined, 'rag-progress-header');
            const stage = element('h3', undefined, 'rag-progress-stage');
            stage.setAttribute('role', 'status'); stage.setAttribute('aria-live', 'polite');
            header.append(stage); if (stop) header.append(stop);
            const details = element('details', undefined, 'rag-progress-details');
            details.append(element('summary', '查看进度详情'), element('p', undefined, 'rag-progress-reading'), element('p', undefined, 'rag-progress-limits'));
            panel.append(header, element('p', undefined, 'rag-progress-budget'), details);
            host.append(panel);
        }
        const execution = task.execution || {};
        const reading = execution.reading_progress;
        const phases = {pdf_download:'正在下载原文', pdf_parse:'正在解析原文', pdf_index:'正在建立检索索引',
            reading_selected:'正在选择文献', reading_batch_completed:'本批文献读取完成', rag_selection_completed:'正在选择证据片段'};
        const stages = {created:'正在规划', planned:'正在准备检索', retrieving:'正在检索文献', reviewing:'正在审查证据',
            writing:'正在撰写回答', auditing:'正在审计引用'};
        const workflow = execution.workflow_status;
        const waiting = task.status === 'queued' || task.status === 'submitting';
        panel.querySelector('.rag-progress-stage').textContent = task.status === 'submitting' ? '正在提交科研问题'
            : task.status === 'queued' ? '排队等待分析'
            : (workflow === 'retrieving' ? (phases[reading?.phase] || stages[workflow]) : (stages[workflow] || '正在初始化科研分析'));
        const count = Number.isInteger(execution.model_calls) && execution.model_calls >= 0 ? execution.model_calls : '—';
        const enhanced = (execution.report_profile || task.report_profile) === 'enhanced';
        const limit = Number.isInteger(execution.model_call_limit) && execution.model_call_limit > 0 ? execution.model_call_limit : (enhanced ? 20 : 10);
        const budget = Number.isFinite(execution.time_budget_seconds) && execution.time_budget_seconds > 0 ? execution.time_budget_seconds : (enhanced ? 720 : 360);
        const cutoff = Number.isFinite(execution.research_start_cutoff_seconds) && execution.research_start_cutoff_seconds > 0 ? execution.research_start_cutoff_seconds : (enhanced ? 600 : 300);
        const elapsed = Number.isFinite(task.elapsed_seconds) ? Math.max(0, Math.round(task.elapsed_seconds)) : null;
        panel.querySelector('.rag-progress-budget').textContent = waiting
            ? `模型调用 ${count}/${limit} · 正在排队`
            : `模型调用 ${count}/${limit} · 已用时 ${elapsed === null ? '待同步' : elapsed + ' 秒'}`;
        const details = panel.querySelector('.rag-progress-details');
        details.hidden = false;
        panel.querySelector('.rag-progress-limits').textContent = `预计大约 ${budget} 秒，实际耗时可能更长 · 超过${cutoff}秒不再启动补查，已开始的一轮完成后继续生成回答 · 原文最多3批、15篇（非必须读满）`;
        const known = value => Number.isInteger(value) && value >= 0 ? value : '待同步';
        panel.querySelector('.rag-progress-reading').textContent = reading
            ? `已索引 ${known(reading.papers_indexed)} 篇原文 · 已尝试读取 ${known(reading.papers_attempted)} 篇 · 已完成查询 ${known(reading.queries_finished)} 条` : '';
        return true;
    }
    // Detect same-tab session/account changes too; storage events alone miss them.
    setInterval(() => {
        if (active && !sameIdentity(active.identity)) close(); if (center && !sameIdentity(center.identity)) closeCenter();
        for (const mount of inlineReports.values()) if (!sameIdentity(mount.identity) || mount.source.isConnected === false) releaseInline(mount);
    }, 300);
    window.addEventListener('pagehide', () => { close(); closeCenter(); for (const mount of inlineReports.values()) releaseInline(mount); });
    window.addEventListener('keydown', event => { if (event.key === 'Escape' && active) close(); });
    // Read-only deep link for an owned CLI/Web task that has no chat-history row.
    window.addEventListener('DOMContentLoaded', () => {
        const task = new URLSearchParams(window.location.search).get('rag_task');
        if (task && /^[0-9a-f]{12}$/.test(task)) open(task, null, true);
    });
    window.MultiAgentRagUI = {attach, update, close, open, successful: status => SUCCESS.has(status)};
})();

