/* Server-owned conversation PDF references. No files/tokens in browser storage. */
(() => {
    'use strict';
    let sequence = 0;
    let cache = null, pending = null;
    const endpoint = session => `/5000/api/science/conversations/${encodeURIComponent(session)}/pdf-attachment`;
    const current = () => ({session: window.currentSessionId, credential: window.userToken});
    const same = key => key.session === window.currentSessionId && key.credential === window.userToken;
    const enabled = () => window.selectedTab === 'research' &&
        ['pdf_local', 'multi_agent_rag', 'multi_agent_pdf'].includes(document.getElementById('research-processing-mode')?.value);
    const host = () => document.getElementById('session-pdf-attachment');
    function clear() { const node = host(); if (node) { node.hidden = true; node.replaceChildren(); } }
    function invalidate() { cache = null; pending?.controller.abort(); pending = null; }
    async function read(session, fresh = false) {
        const key = {session, credential: window.userToken};
        if (!fresh && cache && same(cache.key) && cache.key.session === session && Date.now() - cache.at < 5000) return cache.value;
        if (!fresh && pending && same(pending.key) && pending.key.session === session) return pending.promise;
        pending?.controller.abort();
        const controller = new AbortController();
        const state = {key, controller};
        state.promise = (async () => {
            const response = await fetch(endpoint(session), {signal: controller.signal});
            if (!response.ok) throw new Error(response.status === 401 ? '登录已失效，请重新登录。' : '会话 PDF 不可用，请重新上传或移除附件绑定。');
            const value = (await response.json()).attachment;
            if (same(key) && pending === state) cache = {key, value, at: Date.now()};
            return value;
        })();
        pending = state;
        try { return await state.promise; }
        finally { if (pending === state) pending = null; }
    }
    function removeControl(key) {
        const remove = document.createElement('button'); remove.type = 'button'; remove.textContent = '移除';
        remove.setAttribute('aria-label', '移除本会话 PDF 绑定');
        remove.addEventListener('click', async () => {
            if (!same(key)) return;
            ++sequence; invalidate(); remove.disabled = true;
            try {
                const response = await fetch(endpoint(key.session), {method: 'DELETE'});
                if (!response.ok) throw new Error('PDF 绑定移除失败，请稍后重试。');
                if (same(key)) { clear(); window.ResearchLibrary?.clear(); window.showToast?.('已移除会话绑定，历史报告和原文件保留。', 'success'); }
            } catch (error) { if (same(key)) window.showToast?.(error.message, 'error'); }
            finally { remove.disabled = false; }
        });
        return remove;
    }
    async function restore() {
        const ticket = ++sequence, key = current(); clear();
        if (!enabled() || !key.session || !key.credential || window.sciencePendingFile) return;
        try {
            const attachment = await read(key.session);
            const handled = ticket === sequence && same(key) && window.ResearchLibrary?.attachment(attachment, key);
            if (ticket !== sequence || !same(key) || !enabled() || window.sciencePendingFile || !attachment) return;
            if (handled) return; // One source card, including consent/detach; no duplicate filename.
            const node = host(); if (!node) return;
            const label = document.createElement('span');
            label.textContent = ['multi_agent_rag', 'multi_agent_pdf'].includes(document.getElementById('research-processing-mode')?.value)
                ? `本会话 PDF：${attachment.filename}（六角色分析与追问可复用，仅研究此文件）`
                : `本会话 PDF：${attachment.filename}（后续 PDF 解析可复用）`;
            node.replaceChildren(label, removeControl(key)); node.hidden = false;
        } catch (error) {
            if (error.name === 'AbortError') return;
            if (ticket === sequence && same(key) && enabled()) {
                const node = host(); if (node) {
                    const label = document.createElement('span'); label.textContent = error.message;
                    node.replaceChildren(label, removeControl(key)); node.hidden = false;
                }
            }
        }
    }
    async function append(form, session, mode, file) {
        if (!['pdf_local', 'multi_agent_rag', 'multi_agent_pdf'].includes(mode) || file || !session) return;
        const key = current();
        const attachment = await read(session, true); // submission never trusts display cache
        if (!same(key) || key.session !== session) throw new DOMException('会话或登录状态已变化', 'AbortError');
        if (attachment) {
            form.append('pdf_source_task_id', attachment.source_task_id);
            if (mode === 'multi_agent_rag' || mode === 'multi_agent_pdf') {
                const consent = document.getElementById('library-public-consent')?.checked === true;
                form.append('source_policy', consent ? 'auto' : 'local');
                form.append('allow_public_search', consent ? 'true' : 'false');
            }
        } else if (mode !== 'multi_agent_rag') throw new Error('本会话尚未保存 PDF，请通过回形针上传后再选择解析方式。');
    }
    function changed() {
        ++sequence; invalidate(); clear();
        window.ResearchLibrary?.changed();
        const session = window.currentSessionId;
        window.ConversationSelection?.remember(session);
        if (window.sciencePendingSessionId && window.sciencePendingSessionId !== session) {
            window.sciencePendingFile = null; window.sciencePendingSessionId = null;
            window.attachedContexts = (window.attachedContexts || []).filter(ctx => !ctx.scienceLocal);
            document.querySelectorAll('[data-science-pending]').forEach(node => node.remove());
            window.updateAttachmentsBarVisibility?.();
        }
        return restore();
    }
    window.SciencePdfSession = {restore, append, changed, clear, readBinding: read};
    // The main chat script is already evaluated when this deferred helper loads.
    restore();
})();
