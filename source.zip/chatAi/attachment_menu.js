/* File selection is explicit; opening this menu never uploads or calls a model. */
(() => {
    'use strict';
    const trigger = document.getElementById('context-file-label');
    const menu = document.getElementById('attachment-action-menu');
    if (!trigger || !menu) return;
    const items = [...menu.querySelectorAll('[role="menuitem"]')];
    function close(focus = false) {
        menu.hidden = true; trigger.setAttribute('aria-expanded', 'false');
        if (focus) trigger.focus();
    }
    function open() {
        const rect = trigger.getBoundingClientRect();
        menu.hidden = false;
        menu.style.left = Math.max(12, Math.min(rect.right - menu.offsetWidth, innerWidth - menu.offsetWidth - 12)) + 'px';
        menu.style.top = Math.max(12, rect.top - menu.offsetHeight - 8) + 'px';
        trigger.setAttribute('aria-expanded', 'true'); items[0]?.focus();
    }
    trigger.addEventListener('click', event => {
        if (window.selectedTab === 'deepdiver') return;
        event.preventDefault(); if (menu.hidden) open(); else close(true);
    });
    menu.addEventListener('keydown', event => {
        const current = items.indexOf(document.activeElement);
        if (event.key === 'Escape') { event.preventDefault(); close(true); }
        else if (event.key === 'Tab') close();
        else if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) {
            event.preventDefault();
            const index = event.key === 'Home' ? 0 : event.key === 'End' ? items.length - 1
                : (current + (event.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length;
            items[index]?.focus();
        }
    });
    document.getElementById('attachment-upload-action').addEventListener('click', () => {
        close(); document.getElementById('context-file')?.click();
    });
    document.getElementById('attachment-library-action').addEventListener('click', () => {
        close(); document.getElementById('file-library-btn')?.click(); document.getElementById('tab-user-files')?.click();
    });
    document.addEventListener('click', event => { if (!menu.contains(event.target) && !trigger.contains(event.target)) close(); });
    window.addEventListener('resize', () => close());
    window.addEventListener('pagehide', () => close());
})();
