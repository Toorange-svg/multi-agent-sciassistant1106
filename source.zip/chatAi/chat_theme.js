/* Appearance only. No account, credential, document or answer storage. */
(() => {
    'use strict';
    const key = 'sciassistant.chat-theme';
    const valid = value => value === 'dark' ? 'dark' : 'light';
    function apply(value, persist = false) {
        const theme = valid(value);
        document.documentElement.dataset.chatTheme = theme;
        document.documentElement.style.colorScheme = theme;
        for (const name of ['light', 'dark']) {
            document.getElementById(`chat-theme-${name}`)?.setAttribute('aria-pressed', String(name === theme));
        }
        if (persist) { try { localStorage.setItem(key, theme); } catch (_) { /* unavailable storage is harmless */ } }
    }
    let saved;
    try { saved = localStorage.getItem(key); } catch (_) { saved = null; }
    apply(saved);
    function bind() {
        for (const name of ['light', 'dark']) document.getElementById(`chat-theme-${name}`)?.addEventListener('click', () => apply(name, true));
        document.getElementById('reset-chat-theme')?.addEventListener('click', () => apply('light', true));
        apply(document.documentElement.dataset.chatTheme);
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bind, {once:true});
    else bind();
    window.addEventListener('storage', event => { if (event.key === key) apply(event.newValue); });
})();
