@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo ===============================================
echo        SciAssistant 多智能体科研助手
echo ===============================================
echo.
echo 正在检查运行状态；旧版网页将在没有活动任务时自动更新。
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0bin\windows\start_chat_5000.ps1" -UpdateIfIdle %*
set EXIT_CODE=%ERRORLEVEL%
echo.
if not "%EXIT_CODE%"=="0" (
  echo 启动失败，退出码：%EXIT_CODE%
  pause
  endlocal & exit /b %EXIT_CODE%
)
echo 入口执行完成。
endlocal & exit /b 0
