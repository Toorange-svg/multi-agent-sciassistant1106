"""Code-owned role handoffs: typed plans, bounded search slots and audit jobs.

No model calls, database access, semantic approval or correction of old runs.
"""
from copy import deepcopy
from decimal import Decimal
import hashlib
import re
from multi_agent_evidence import evidence_strength
from multi_agent_report_contracts import REPORT_PLAN_SCHEMA, LEGACY_REPORT_PLAN_SCHEMA, REQUIREMENT_PLAN_SCHEMAS, MAX_REQUIREMENTS, requirement_plan_issues

PLAN_SCHEMA = 'sciassistant.research-plan/v4'
TYPED_PLAN_SCHEMAS = frozenset({PLAN_SCHEMA, *REQUIREMENT_PLAN_SCHEMAS})
HANDOFF_POLICY = 'typed-needs-with-bounded-query-compilation/v2'
AUDIT_JOB_POLICY = 'claim-scoped-audit-inputs-with-processing-context/v1'
COMPARISON_POLICY = 'printed-table-observations-and-cross-claim-context/v1'
SOURCE_CONFIDENCE_POLICY = 'weak-source-confidence-ceiling-before-independent-audit/v1'
NEED_PASSAGE_POLICY = 'entity-aspect-scoped-recall-within-existing-context/v1'


def compile_passage_needs(group, documents, *, uploaded_document_id=None):
    """Compile local-only retrieval hints, not public actions or support verdicts.

    documents is the executor's already indexed/authorized document catalogue.
    An original-title clue must match that catalogue; it cannot grant access to
    another paper or promote a title guessed by a model into a verified source.
    """
    phrases = {
        'definition': 'native task inputs outputs model overview predicts given',
        'mechanism': 'method architecture algorithm training objective computation',
        'result': 'results evaluation performance accuracy measurements',
        'protocol': 'experimental setup dataset training evaluation test protocol',
    }
    normalize = lambda value: ' '.join(str(value).casefold().split())
    rows, skipped = [], []
    for index, need in enumerate(group.get('evidence_needs', [])[:4]):
        need_id = f"{group['id']}-n{index+1}"
        aspect, entity, title = need.get('aspect'), need.get('entity'), need.get('source_title', '')
        if aspect not in phrases or not isinstance(entity, str) or not 1 <= len(entity.strip()) <= 100:
            skipped.append({'need_id': need_id, 'reason_code': 'INVALID_PASSAGE_NEED'})
            continue
        if uploaded_document_id is not None:
            ids, binding = [uploaded_document_id] if uploaded_document_id in documents else [], 'uploaded_scope'
        elif title:
            ids = [key for key, doc in documents.items() if normalize(doc.get('title', '')) == normalize(title)]
            binding = 'exact_title'
        else:
            # No unverified entity-to-paper inference: this is exploratory
            # retrieval over the caller's explicitly allowed current scope.
            ids, binding = list(documents), 'current_scope'
        if not ids:
            skipped.append({'need_id': need_id, 'entity': entity,
                'reason_code': 'SOURCE_TITLE_NOT_INDEXED' if title else 'NO_ALLOWED_DOCUMENT'})
            continue
        rows.append({'need_id': need_id, 'entity': entity, 'aspect': aspect,
            'query': entity.strip() + ' ' + phrases[aspect],
            'document_ids': sorted(ids), 'source_binding': binding})
    return {'schema_version': 'sciassistant.passage-needs/v1', 'policy': NEED_PASSAGE_POLICY,
        'group_id': group['id'], 'needs': rows, 'skipped': skipped,
        'semantic_support_verified': False, 'new_public_requests': 0}


def comparison_observations(evidence):
    """Read observed scalar cells, not metric semantics or a scientific verdict.

    Only approved page-located tables qualify. Exact offsets and printed cells
    remain available; min/max is arithmetic, never an inferred best method.
    Unsupported/ambiguous layouts produce diagnostics, not guessed tables.
    """
    records, skipped = [], []
    scalar = re.compile(r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d{1,3})?')
    for item in evidence.get('evidence', []):
        locator = item.get('locator') or {}
        if (item.get('review_status') != 'approved' or item.get('evidence_strength') != 'fulltext_located'
                or evidence_strength(item) != 'fulltext_located'
                or not locator.get('page') or not locator.get('table_id')):
            continue
        text = item.get('excerpt') or item.get('text') or ''
        if not isinstance(text, str):
            continue
        if len(text) > 16000:
            skipped.append({'evidence_id': item['evidence_id'], 'reason': 'TABLE_TEXT_INPUT_LIMIT'})
            continue
        lines, offset, blocks, block = text.splitlines(keepends=True), 0, [], []
        for line in lines:
            if not line.strip():
                offset += len(line)
                continue  # Page-local parsers may separate every table row with a blank line.
            cells = [c.strip() for c in line.strip().strip('|').split('|')]
            if '|' in line and 2 <= len(cells) <= 24:
                block.append((offset, offset+len(line), cells))
            else:
                if block:
                    blocks.append(block)
                block = []
            offset += len(line)
        if block:
            blocks.append(block)
        for block in blocks:
            header = block[0][2]
            rows = [r for r in block[1:] if not all(re.fullmatch(r'[:\- ]+', c or '-') for c in r[2])]
            if (not 2 <= len(rows) <= 128 or any(len(r[2]) != len(header) for r in rows)
                    or not any(re.search(r'[A-Za-z\u4e00-\u9fff]', c) for c in header)):
                skipped.append({'evidence_id': item['evidence_id'], 'reason': 'TABLE_LAYOUT_NOT_SUPPORTED'})
                continue
            columns = []
            for index, name in enumerate(header[1:], 1):
                values = [r[2][index] for r in rows]
                if not all(scalar.fullmatch(v) for v in values):
                    continue  # No partial-column extrema or error-bar normalization.
                numbers = [Decimal(v) for v in values]
                columns.append({'column_index': index, 'printed_header': name,
                    'minimum_printed_value': values[numbers.index(min(numbers))],
                    'minimum_row_indices': [i for i,v in enumerate(numbers) if v == min(numbers)],
                    'maximum_printed_value': values[numbers.index(max(numbers))],
                    'maximum_row_indices': [i for i,v in enumerate(numbers) if v == max(numbers)]})
            if not columns:
                skipped.append({'evidence_id': item['evidence_id'], 'reason': 'NO_COMPLETE_SCALAR_COLUMN'})
                continue
            if len(records) >= 12:
                skipped.append({'evidence_id': item['evidence_id'], 'reason': 'TABLE_RECORD_INPUT_LIMIT'})
                continue
            records.append({'evidence_id': item['evidence_id'], 'paper_id': item.get('paper_id'),
                'page': locator['page'], 'table_id': locator['table_id'],
                'source_field': 'excerpt' if item.get('excerpt') else 'text',
                'source_text_sha256': hashlib.sha256(text.encode('utf8')).hexdigest(),
                'start': block[0][0], 'end': block[-1][1], 'printed_headers': header,
                'rows': [{'row_index': i, 'printed_cells': r[2], 'start': r[0], 'end': r[1]} for i,r in enumerate(rows)],
                'scalar_columns': columns, 'column_semantics_verified': False,
                'manual_visual_verification': False, 'statistical_significance_verified': False})
    return {'schema_version': 'sciassistant.comparison-observations/v1', 'policy': COMPARISON_POLICY,
        'records': records, 'skipped': skipped, 'semantic_auto_approval': False,
        'instructions': 'These are printed-cell arithmetic observations, not optimality or statistical conclusions. '
            'Match metric headers, task/settings and direction against the cited original. Preserve all tied row indices; '
            'separate an author-named representative optimum from ties at printed precision. Do not state a unique best '
            'choice in the opening and a tied set later. Parser output is not independent visual verification.'}


def report_assertions(audit_input):
    """Peer text is report context only; no foreign quote handles or verdicts."""
    return [{'claim_id': c['claim_id'], 'group_id': c.get('group_id'),
             'report_fields': deepcopy(c['report_fields']), 'evidence_ids': list(c['evidence_ids'])}
            for c in audit_input['claims']]


def plan_handoff_issues(plan, question=None):
    if plan.get('schema_version') not in TYPED_PLAN_SCHEMAS:
        return []
    issues = []
    research = 0
    group_ids = set()
    if not isinstance(plan.get('groups'), list) or not 1 <= len(plan['groups']) <= 3:
        return [{'path': 'groups', 'reason': 'ONE_TO_THREE_TYPED_GROUPS_REQUIRED'}]
    for n, group in enumerate(plan.get('groups', [])):
        path = f'groups[{n}]'
        if not isinstance(group, dict):
            continue  # Existing envelope validator owns this error.
        key = group.get('id')
        if not isinstance(key, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,80}', key) or key in group_ids:
            issues.append({'path': path+'.id', 'reason': 'UNIQUE_GROUP_ID_REQUIRED'})
        else:
            group_ids.add(key)
        kind, quote = group.get('kind'), group.get('question_quote')
        if not isinstance(kind, str) or kind not in {'research', 'report'}:
            issues.append({'path': path+'.kind', 'reason': 'GROUP_KIND_REQUIRED'})
        if (not isinstance(quote, str) or not 1 <= len(quote) <= 600
                or question is not None and quote not in question):
            issues.append({'path': path+'.question_quote', 'reason': 'CURRENT_QUESTION_QUOTE_REQUIRED'})
        needs = group.get('evidence_needs')
        if kind == 'report':
            if (any(group.get(key) != [] for key in ('queries', 'core', 'support', 'metrics', 'evidence_needs'))
                    or group.get('query_candidates', []) != []):
                issues.append({'path': path, 'reason': 'REPORT_INSTRUCTION_MUST_NOT_REQUEST_RETRIEVAL'})
        if kind == 'research':
            research += 1
            queries = group.get('query_candidates', group.get('queries'))
            if (not isinstance(queries, list) or not 1 <= len(queries) <= 4
                    or any(not isinstance(q, str) or not 1 <= len(q.strip()) <= 500 for q in queries)):
                issues.append({'path': path+'.query_candidates', 'reason': 'ONE_TO_FOUR_QUERY_PROPOSALS_REQUIRED'})
            if not isinstance(needs, list) or not 1 <= len(needs) <= 4:
                issues.append({'path': path+'.evidence_needs', 'reason': 'EVIDENCE_NEEDS_REQUIRED'})
                continue
            for i, need in enumerate(needs):
                target = f'{path}.evidence_needs[{i}]'
                if not isinstance(need, dict) or set(need) != {'entity', 'question_quote', 'aspect', 'source_title'}:
                    issues.append({'path': target, 'reason': 'EVIDENCE_NEED_FIELDS_INVALID'})
                    continue
                entity, title = need['entity'], need['source_title']
                if not isinstance(entity, str) or not 1 <= len(entity.strip()) <= 100:
                    issues.append({'path': target+'.entity', 'reason': 'BOUNDED_ENTITY_ALIAS_REQUIRED'})
                quote = need['question_quote']
                if (not isinstance(quote, str) or not 1 <= len(quote) <= 600
                        or question is not None and quote not in question):
                    issues.append({'path': target+'.question_quote', 'reason': 'CURRENT_QUESTION_QUOTE_REQUIRED'})
                if not isinstance(need['aspect'], str) or need['aspect'] not in {'definition', 'mechanism', 'result', 'protocol'}:
                    issues.append({'path': target+'.aspect', 'reason': 'UNKNOWN_EVIDENCE_ASPECT'})
                if (not isinstance(title, str) or title and not 4 <= len(title) <= 200
                        or re.search(r'[\x00-\x1f\x7f"\\<>]|https?://', title, re.I)):
                    issues.append({'path': target+'.source_title', 'reason': 'SOURCE_CLUE_INVALID'})
    if not research:
        issues.append({'path': 'groups', 'reason': 'RESEARCH_GROUP_REQUIRED'})
    reports = plan.get('report_obligations', [])
    if not isinstance(reports, list) or len(reports) > (MAX_REQUIREMENTS if plan.get('schema_version') in REQUIREMENT_PLAN_SCHEMAS else 4):
        issues.append({'path': 'report_obligations', 'reason': 'REPORT_OBLIGATIONS_INVALID'})
    else:
        for i, report in enumerate(reports):
            path = f'report_obligations[{i}]'
            if not isinstance(report, dict) or set(report) != {'id', 'kind', 'question_quote', 'question'}:
                issues.append({'path': path, 'reason': 'REPORT_FIELDS_INVALID'})
                continue
            if (report['kind'] != 'report' or not isinstance(report['question_quote'], str)
                    or not 1 <= len(report['question_quote']) <= 600
                    or question is not None and report['question_quote'] not in question
                    or not isinstance(report['question'], str) or not 1 <= len(report['question']) <= 1200):
                issues.append({'path': path, 'reason': 'REPORT_QUESTION_INVALID'})
            if not isinstance(report['id'], str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,80}', report['id']) or report['id'] in group_ids:
                issues.append({'path': path+'.id', 'reason': 'UNIQUE_GROUP_ID_REQUIRED'})
            else:
                group_ids.add(report['id'])
    for i, row in enumerate(plan.get('premise_checks', [])):
        if (isinstance(row, dict) and row.get('origin') == 'user_statement'
                and row.get('assumption') != row.get('question_quote')):
            issues.append({'path': f'premise_checks[{i}]', 'reason': 'USER_STATEMENT_MUST_BE_LITERAL_NOT_EXPANDED'})
    issues.extend(requirement_plan_issues(plan, question))
    return issues[:20]


def compile_search_plan(plan, source_scope):
    """Compile proposals into existing tool slots; never grant source permission."""
    result = deepcopy(plan)
    report = {'schema_version': 'sciassistant.search-plan-compilation/v1',
              'policy': HANDOFF_POLICY, 'groups': [], 'semantic_auto_approval': False}
    if plan.get('schema_version') not in TYPED_PLAN_SCHEMAS:
        return result, report
    for group in result['groups']:
        candidates = group.get('query_candidates', group.get('queries', []))
        queries = list(dict.fromkeys(candidates))[:2]
        titles = list(dict.fromkeys(n['source_title'] for n in group.get('evidence_needs', [])
            if n['aspect'] in {'definition', 'mechanism'} and n['source_title']))
        # Private and mixed routes retain their existing question/consent boundary.
        if source_scope == 'arxiv' and titles and not any(re.search(r'\b(?:NOT|ANDNOT)\b', q, re.I) for q in candidates):
            slots = [[] for _ in range(min(2, len(titles)))]
            for index, title in enumerate(titles):
                slots[index % len(slots)].append(f'ti:"{title}"')
            for index, clauses in enumerate(slots):
                query = '('+' OR '.join(clauses)+')'
                if len(query) <= 500:
                    if index < len(queries):
                        queries[index] = query
                    else:
                        queries.append(query)
        group['query_candidates'] = deepcopy(candidates)
        group['queries'] = queries
        report['groups'].append({'group_id': group['id'], 'proposals': deepcopy(candidates),
            'queries': queries, 'execution_limit': 2, 'source_scope': source_scope})
    result['search_compilation_policy'] = HANDOFF_POLICY
    return result, report


def evidence_need_contract(plan):
    return {'schema_version': 'sciassistant.evidence-needs/v1', 'policy': HANDOFF_POLICY,
        'needs': [{'need_id': f"{g['id']}-n{i+1}", 'group_id': g['id'], **deepcopy(need)}
                  for g in plan.get('groups', []) for i, need in enumerate(g.get('evidence_needs', []))],
        'report_obligations': deepcopy(plan.get('report_obligations', [])),
        'instructions': 'Track definitions/results for each named component independently; report instructions are not search topics. Title clues are not verified papers or approved evidence.',
        'semantic_auto_approval': False}


def route_need_titles(plan, actions):
    """Use existing public slots for original-source clues; never join methods by AND."""
    result, changes = deepcopy(actions), []
    if plan.get('schema_version') not in TYPED_PLAN_SCHEMAS or plan.get('search_compilation_policy') == HANDOFF_POLICY:
        return result, changes
    for group in plan.get('groups', []):
        positions = [i for i, a in enumerate(result) if a.get('action') == 'request_arxiv_search'
                     and a.get('arguments', {}).get('group_id') == group['id']]
        titles = list(dict.fromkeys(n['source_title'] for n in group.get('evidence_needs', [])
                                   if n['aspect'] in {'definition', 'mechanism'} and n['source_title']))
        if not positions or not titles or any(re.search(r'\b(?:NOT|ANDNOT)\b',
                result[i]['arguments']['query'], re.I) for i in positions):
            continue
        slots = [[] for _ in positions]
        for i, title in enumerate(titles):
            slots[i % len(slots)].append(f'ti:"{title}"')
        for index, clauses in zip(positions, slots):
            query = '('+' OR '.join(clauses)+')'
            if not clauses or len(query) > 500:
                continue  # Never truncate titles, add requests or exceed a tool limit.
            before = result[index]['arguments']['query']
            result[index]['arguments']['query'] = query
            changes.append({'group_id': group['id'], 'request_id': result[index]['request_id'],
                'previous_query': before, 'query': query, 'policy': HANDOFF_POLICY})
    return result, changes


def need_flow_snapshot(plan, actions, evidence, review=None):
    """Literal observations for diagnosis, not an entity's semantic coverage verdict."""
    allowed = set((review or {}).get('allowed_evidence_ids', []))
    rows = []
    for need in evidence_need_contract(plan)['needs']:
        entity = need['entity'].casefold()
        sources = [e for e in evidence.get('evidence', [])
                   if entity in str(e.get('excerpt') or e.get('text') or '').casefold()]
        rows.append({**need, 'query_mentions': [a['request_id'] for a in actions
            if a.get('arguments', {}).get('group_id') == need['group_id']
            and (entity in a['arguments']['query'].casefold()
                 or need['source_title'] and need['source_title'].casefold() in a['arguments']['query'].casefold())],
            'presented_literal_mentions': [e['evidence_id'] for e in sources],
            'presented_title_matches': [e['evidence_id'] for e in evidence.get('evidence', [])
                if need['source_title'] and str(e.get('title', '')).casefold() == need['source_title'].casefold()],
            'approved_literal_mentions': [e['evidence_id'] for e in sources if e['evidence_id'] in allowed]})
        rows[-1]['selected_for_need'] = [e['evidence_id'] for e in evidence.get('evidence', [])
            if e.get('retrieval', {}).get('evidence_need_selection', {}).get('selected_for_need_id') == need['need_id']]
        rows[-1]['recall_candidate_for_need'] = [e['evidence_id'] for e in evidence.get('evidence', [])
            if need['need_id'] in e.get('retrieval', {}).get('evidence_need_selection', {}).get('candidate_need_ids', [])]
    return {'schema_version': 'sciassistant.need-flow/v1', 'needs': rows,
            'semantic_coverage_verified': False, 'policy': HANDOFF_POLICY}


def audit_jobs(audit_input, evidence):
    sources = {e['evidence_id']: e for e in evidence.get('evidence', []) if e.get('review_status') == 'approved'}
    jobs = []
    for claim in audit_input['claims']:
        key = claim['claim_id']
        cited = [sources[i] for i in claim['evidence_ids'] if i in sources]
        jobs.append({'claim_id': key, 'claim': deepcopy(claim), 'approved_cited_source_ids': [e['evidence_id'] for e in cited],
            'source_copy_brief': _for_claim(audit_input.get('source_copy_brief', {}), key),
            'source_witness_options': [deepcopy(o) for o in audit_input.get('source_witness_options', {}).get('options', []) if o.get('claim_id') == key],
            'absence_assertion_options': [deepcopy(o) for o in audit_input.get('absence_assertion_options', {}).get('options', []) if o.get('claim_id') == key],
            'processing_context': {'manual_page_review_attested_by_workflow': False,
                'locator_has_bbox': {e['evidence_id']: bool(e.get('locator', {}).get('bbox')) for e in cited},
                'instructions': 'Parser coordinates are not manual verification. Statements about this run\'s transcription/manual checking are processing metadata, not claims that a paper omitted an experiment. Do not infer paper absence from a processing limitation.'}})
        if audit_input.get('comparison_context_policy') == COMPARISON_POLICY:
            papers = {e.get('paper_id') for e in cited if e.get('paper_id')}
            jobs[-1]['related_report_claim_ids'] = [c['claim_id'] for c in audit_input['claims'] if c['claim_id'] != key and (
                set(c['evidence_ids']) & set(claim['evidence_ids']) or papers & {
                    sources[e].get('paper_id') for e in c['evidence_ids'] if e in sources})]
            jobs[-1]['consistency_instructions'] = (
                'Compare these peer assertions in report_assertions against the shared table observations. '
                'Peer text is not source evidence or permission to borrow quote handles. If the report mixes author wording '
                'with table readings, require explicit attribution and reconcile tied/unique statements in this field.')
    return jobs


def audit_source_catalog(evidence):
    """Read-only shared text, not an authorization to cite another job's source."""
    fields = ('evidence_id', 'paper_id', 'title', 'locator', 'coverage_scope', 'content_scope',
              'task_relevance', 'source_domain', 'reviewed_group_ids', 'source_identity',
              'evidence_strength', 'source_attribution', 'task_side_roles', 'parser_provenance')
    return [{**{k: deepcopy(e[k]) for k in fields if k in e},
             'excerpt': e.get('excerpt') or e.get('text') or ''}
            for e in evidence.get('evidence', []) if e.get('review_status') == 'approved']


def _for_claim(value, key):
    if isinstance(value, dict):
        if 'claim_id' in value and value['claim_id'] != key:
            return None
        return {k: v for k, item in value.items() if (v := _for_claim(item, key)) is not None}
    if isinstance(value, list):
        return [v for item in value if (v := _for_claim(item, key)) is not None]
    return deepcopy(value)


def project_audit_packet(packet):
    """Separate work orders without altering stored artifacts, verdicts or source checks."""
    inputs = packet.get('inputs') or []
    current = next((i['payload'] for i in inputs if i.get('payload', {}).get('audit_job_policy') == AUDIT_JOB_POLICY
                    and i['payload'].get('schema_version') == 'sciassistant.citation-audit-input/v1'), None)
    if current is None:
        return packet
    result = deepcopy(packet)
    jobs = deepcopy(current['audit_jobs'])
    corrections = [i for i in inputs if i.get('payload', {}).get('schema_version') == 'sciassistant.validation-report/v1']
    for job in jobs:
        job['corrections'] = [_for_claim(i['payload'], job['claim_id']) for i in corrections]
    for item in result['inputs']:
        payload = item.get('payload', {})
        if payload.get('schema_version') == 'sciassistant.citation-audit-input/v1':
            payload['audit_jobs'] = jobs
            for name in ('claims', 'source_witness_options', 'absence_assertion_options', 'source_copy_brief'):
                payload.pop(name, None)
        elif (payload.get('schema_version') in {'sciassistant.claim-draft/v2', 'sciassistant.claim-draft/v3', 'sciassistant.claim-draft/v4', 'sciassistant.validation-report/v1'}
              or 'evidence' in payload):
            item['payload'] = {'schema_version': 'sciassistant.audit-input-reference/v1',
                'original_schema': payload.get('schema_version'),
                'instruction': 'Read current claim-scoped audit_jobs; original artifact remains stored unchanged.'}
    result['role_input_projection_policy'] = AUDIT_JOB_POLICY
    return result
