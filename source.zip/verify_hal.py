﻿import sys
sys.path.insert(0, ".")
sys.path.insert(0, "deepdiver_v2")
from deepdiver_v2.src.literature_sources import _hal
for q in ("LoRA QLoRA core differences", "retrieval-augmented generation retriever role", "RAG retriever component architecture"):
    try:
        papers = _hal(q, 3)
        print(q, "->", len(papers), "papers", "| first:", (papers[0]["title"][:70] if papers else "-"))
    except Exception as e:
        print(q, "-> ERR", str(e)[:100])
