"""Read-only report presentation. Never approves, edits or invents evidence."""
from __future__ import annotations

import html
import json
import re

LINKED_POLICY = 'linked-coverage-single-review-end-references/v1'
POLICY = 'evidence-sidebar-compact-coverage/v2'
SCHEMA = 'sciassistant.report-presentation/v1'
METRICS = {'definition': '概念与定义', 'role': '作用与用途', 'relation': '技术关系',
    'mechanism': '工作机制', 'latency': '推理延迟', 'single_request_latency': '单请求延迟',
    'throughput': '吞吐量', 'quality': '生成质量', 'memory': '内存与显存',
    'accuracy': '准确率', 'generalization': '泛化能力', 'trainable parameters': '可训练参数',
    'trainable_parameters': '可训练参数', 'ttft': '首 Token 延迟（TTFT）', 'tpot': '逐 Token 延迟（TPOT）'}
DISPLAY_LABELS = {'research problem': '研究问题', 'research_problem': '研究问题',
    'problem': '问题', 'direct evidence': '已有直接证据', 'partial coverage': '证据不完整'}
STATUSES = {'direct': '有直接证据', 'indirect': '仅有间接证据', 'partial': '部分覆盖',
    'not_reported': '所选片段未报告此指标', 'not_comparable': '实验不可直接比较',
    'conflicting': '证据存在冲突', 'missing': '仍缺少证据'}
COMPARABILITY = {'limited': '可比性有限', 'comparable': '在已列条件下可比较',
    'not_comparable': '不能直接横向比较', 'unknown': '可比性尚未确认'}
ACTIONS = {'qualified_answer': '可给出有限结论，不补造缺失指标',
    'gap_search': '需要针对本项补充检索', 'search': '需要补充检索',
    'needs_review': '需进一步核对证据', 'answer': '按已批准证据回答'}
CSS = '''.research-note{margin:12px 0;padding:12px 14px;border:1px solid #d5dfec;border-left:4px solid #3978ba;border-radius:8px;background:var(--chat-subtle,#eef5ff);color:var(--chat-text,#24374d);font-size:14px;line-height:1.7;overflow-wrap:anywhere}
.research-note.warning{border-left-color:#b78300;background:var(--chat-partial,#fff8df)}.research-note.review{border-left-color:#bd5129;background:var(--chat-review,#fff0e6)}
.research-note h4{margin:0 0 6px;font-size:14px}.research-note p{margin:6px 0}.research-note details{margin-top:6px}.research-note summary{cursor:pointer}.research-bibliography{border-top:1px solid #ccd4de;margin-top:24px;padding-top:12px}.research-bibliography li{margin:10px 0}.research-note a{margin-right:8px}'''
COMPACT_CSS = CSS + '''.rag-coverage-summary{border:1px solid #e7d8ae;border-left:4px solid #b78300;border-radius:8px;background:var(--chat-partial,#fff8df);padding:12px;margin:12px 0}.rag-coverage-summary h3{margin:0 0 8px}.coverage-group{border-top:1px solid #e7d8ae;padding-top:8px;margin-top:8px}.coverage-group h4{font-size:14px;margin:0 0 4px}.coverage-row{margin:8px 0}.coverage-row h5{font-size:13px;margin:0 0 3px}.coverage-row p{margin:3px 0}.coverage-links{font-size:12px}.coverage-links a{margin-right:6px}'''


def _norm(value):
    return re.sub(r'\s+', '', str(value or ''))


def _text(value):
    return value.strip() if isinstance(value, str) else ''


def _unique(values):
    return list(dict.fromkeys(value for value in values if isinstance(value, str) and value))


def build_presentation(claims, coverage, references, plan=None, *, policy=POLICY):
    """Only explicit IDs/groups determine placement; no semantic fuzzy matching."""
    claims = [c for c in (claims or []) if isinstance(c, dict)]
    references = [r for r in (references or []) if isinstance(r, dict)]
    available = {r['evidence_id']: r for r in references if isinstance(r.get('evidence_id'), str)}
    labels = {g.get('id'): _text(g.get('heading')) or _text(g.get('question')) or ', '.join(g.get('core') or [])
              for g in (plan or {}).get('groups', []) if isinstance(g, dict)}
    notes = []
    for n, row in enumerate(coverage or [], 1):
        if not isinstance(row, dict):
            continue
        group = row.get('group_id') or row.get('topic_id')
        supplied = _unique(row.get('evidence_ids') or [])
        ids = [key for key in supplied if key in available]
        basis = 'evidence_ids' if ids else 'unlocated'
        if not supplied and group:
            ids = [key for key, ref in available.items() if group in (ref.get('reviewed_group_ids') or [])]
            if ids:
                basis = 'reviewed_topic'
        linked = [c for c in claims if (not group or not c.get('group_id') or c.get('group_id') == group)
                  and ((ids and set(c.get('evidence_ids') or []) & set(ids))
                       or (not supplied and group and c.get('group_id') == group))]
        status = row.get('evidence_status') or row.get('status')
        details = []
        for label, values in [('具体缺口', row.get('missing_conditions') or []),
                              ('审查依据', [row.get('reason')]),
                              ('比较边界', [COMPARABILITY.get(row.get('comparability'), row.get('comparability'))]),
                              ('本轮处理', [ACTIONS.get(row.get('recommended_action'), row.get('recommended_action'))])]:
            for value in values:
                if _text(value) and not any(_norm(d['text']) == _norm(value) for d in details):
                    details.append({'label': label, 'text': _text(value)})
        title = labels.get(group) or _text(row.get('topic')) or group or '本轮研究问题'
        title = DISPLAY_LABELS.get(str(title).strip().lower(), title)
        metric = _text(row.get('metric'))
        summary = next((d['text'] for d in details if d['label'] in {'具体缺口', '审查依据'}), '')
        if not summary:
            summary = ('本项结论有已取得的直接证据；仍应核对原文及适用范围。' if status == 'direct'
                       else '审查未提供具体原因，请结合相关结论和原文核对；不能据此推断全文缺失。')
        notes.append({'note_id': f'coverage-{n}', 'group_id': group,
            'title': str(title), 'metric_label': METRICS.get(metric.lower(), DISPLAY_LABELS.get(metric.lower(), metric or '问题覆盖')),
            'status_label': STATUSES.get(status, '覆盖状态待确认'),
            'tone': 'review' if status == 'conflicting' else 'info' if status == 'direct' else 'warning',
            'summary': summary[:160] + ('…' if len(summary) > 160 else ''),
            'scope_label': '本主题说明，非对某一句话的单独判定' if basis != 'evidence_ids' else '与所列证据相关的审查说明',
            'details': details, 'claim_ids': _unique(c.get('claim_id') for c in linked),
            'evidence_ids': ids, 'association_basis': basis})
    claim_notes = []
    for c in claims:
        ids = [key for key in c.get('evidence_ids') or [] if key in available]
        details, seen = [], {_norm(c.get('text'))}
        for field, label in [('scope_note', '结论适用范围'), ('qualification', '实验条件与证据边界')]:
            value = _text(c.get(field))
            # Suppress only a literally repeated complete field, never paraphrases.
            if value and _norm(value) not in seen:
                details.append({'field': field, 'label': label, 'text': value})
                seen.add(_norm(value))
        claim_notes.append({'claim_id': c.get('claim_id'), 'text': _text(c.get('text')),
            'evidence_ids': ids, 'detail_evidence_id': ids[0] if ids else None, 'details': details})
    bibliography = [{'citation': r.get('citation'), 'evidence_id': r.get('evidence_id'),
        'title': _text(r.get('title')), 'source_label': '用户上传 PDF' if r.get('source') == 'uploaded_pdf' else 'arXiv',
        'paper_id': r.get('paper_id'), 'page': (r.get('locator') or {}).get('page'),
        'official_url': r.get('official_url') or ''} for r in references]
    result = {'schema_version': SCHEMA, 'policy': policy, 'coverage_notes': notes,
              'claim_notes': claim_notes, 'bibliography': bibliography}
    if policy == POLICY:
        result['coverage_groups'] = compact_coverage_groups(notes)
    return result


def compact_coverage_groups(notes):
    """Deduplicate exact wording, not scientific meanings; retain raw records."""
    groups = {}
    generic = set(COMPARABILITY.values()) | set(ACTIONS.values()) | set(COMPARABILITY) | set(ACTIONS)
    for note in notes:
        primary = [row['text'] for row in note['details'] if row['label'] in {'具体缺口', '审查依据'}]
        other = [row['text'] for row in note['details'] if row['label'] not in {'具体缺口', '审查依据'} and row['text'] not in generic]
        if note['status_label'] == '有直接证据' and not primary and not other:
            continue
        paragraphs, seen = [], set()
        for text in [*(primary or [note['summary']]), *other]:
            if _norm(text) and _norm(text) not in seen:
                paragraphs.append(text); seen.add(_norm(text))
        key = note.get('group_id') or note['title']
        group = groups.setdefault(key, {'title': note['title'], 'evidence_ids': [], 'rows': []})
        group['evidence_ids'] = _unique([*group['evidence_ids'], *note['evidence_ids']])
        prior = next((row for row in group['rows'] if [_norm(p) for p in row['paragraphs']] == [_norm(p) for p in paragraphs]), None)
        if prior:
            prior['metric_labels'] = _unique([*prior['metric_labels'], note['metric_label']])
            prior['status_labels'] = _unique([*prior['status_labels'], note['status_label']])
            prior['note_ids'].append(note['note_id'])
        else:
            group['rows'].append({'metric_labels': [note['metric_label']], 'status_labels': [note['status_label']],
                                  'paragraphs': paragraphs, 'note_ids': [note['note_id']]})
    return list(groups.values())


def coverage_report(presentation, references, *, markdown=False):
    """One evidence-area summary, without boilerplate or repeated source buttons."""
    groups = presentation.get('coverage_groups') or []
    output = ['## 证据覆盖与缺口' if markdown else '<section class="rag-coverage-summary"><h3>证据覆盖与缺口</h3>']
    for group in groups:
        output.append('### '+html.escape(group['title']) if markdown else '<div class="coverage-group"><h4>'+html.escape(group['title'])+'</h4>')
        for row in group['rows']:
            title = html.escape('、'.join(row['metric_labels'])+' · '+'、'.join(row['status_labels']))
            if markdown:
                output.append('**'+title+'**\n\n'+'\n\n'.join(html.escape(p) for p in row['paragraphs']))
            else:
                output.append('<div class="coverage-row"><h5>'+title+'</h5>'+''.join('<p>'+html.escape(p)+'</p>' for p in row['paragraphs'])+'</div>')
        refs = [r for r in references if r['evidence_id'] in group['evidence_ids']]
        if refs:
            output.append('相关原文：'+' '.join(f'[{r["citation"]}](#evidence-{r["citation"]})' for r in refs) if markdown else
                '<p class="coverage-links">相关原文：'+''.join(f'<a href="#evidence-{r["citation"]}">[{r["citation"]}]</a>' for r in refs)+'</p>')
        if not markdown:
            output.append('</div>')
    if not groups:
        text = '本轮未单独记录待补强项；具体适用范围仍需结合结果状态和原文核对。'
        output.append(text if markdown else '<p>'+text+'</p>')
    if not markdown:
        output.append('</section>')
    return '\n\n'.join(output)


def compact_status(display):
    """Keep outcome/usage/audit warnings, not a second coverage summary."""
    return {**display, 'findings': [], 'topic_summaries': [], 'answer_scope': {}}


def _placements(answer, presentation):
    blocks = answer.split('\n\n')
    claims = {c['claim_id']: c for c in presentation['claim_notes']}
    placed, unplaced = {}, []
    for note in presentation['coverage_notes']:
        targets = [_norm(claims[key]['text']) for key in note['claim_ids'] if key in claims and claims[key]['text']]
        index = next((i for i, block in enumerate(blocks) if any(target in _norm(block) for target in targets)), None)
        if index is None:
            unplaced.append(note)
        else:
            placed.setdefault(index, []).append(note)
    return blocks, placed, unplaced


def note_html(note, references):
    e = html.escape
    links = ''.join(f'<a href="#evidence-{r["citation"]}">[{r["citation"]}] 对应原文</a>'
                    for r in references if r.get('evidence_id') in note['evidence_ids'])
    details = ''.join(f'<p>{e(d["label"])}：{e(d["text"])}</p>' for d in note['details'])
    return (f'<aside class="research-note {e(note["tone"])}"><h4>{e(note["title"])} · {e(note["metric_label"])} · {e(note["status_label"])}</h4>'
        f'<p>{e(note["summary"])}</p><p>{e(note["scope_label"])}</p>{links}'
        + (f'<details><summary>完整审查说明</summary>{details}</details>' if details else '') + '</aside>')


def _note_md(note, references):
    heading = html.escape(' · '.join([note['title'],note['metric_label'],note['status_label']]))
    text = f'> **{heading}**\n> {html.escape(note["summary"])}\n'
    text += '> ' + note['scope_label'] + '\n'
    markers = ' '.join(f'[{r["citation"]}](#evidence-{r["citation"]})' for r in references if r.get('evidence_id') in note['evidence_ids'])
    if markers:
        text += '> 对应原文：' + markers + '\n'
    if note['details']:
        text += '\n<details><summary>完整审查说明</summary>\n\n' + '\n\n'.join(html.escape(d['label']+ '：'+d['text']) for d in note['details']) + '\n\n</details>\n'
    return text


def render_answer(answer, presentation, references, *, markdown=False):
    """Retain every answer character; notes are separate, never model rewrites."""
    blocks, placed, unplaced = (answer.split('\n\n'), {}, []) if presentation.get('policy') == POLICY else _placements(answer, presentation)
    output = []
    numbers = {r['citation'] for r in references}
    for i, block in enumerate(blocks):
        if markdown:
            output.append(block)
        else:
            text = html.escape(block)
            text = re.sub(r'\[(\d+)\]', lambda m: f'<a href="#evidence-{m[1]}">[{m[1]}]</a>'
                if int(m[1]) in numbers else f'<span>{m[0]}（引用未发布）</span>', text)
            heading = re.fullmatch(r'(#{1,4}) ([^\n]+)', text)
            output.append(f'<h{len(heading[1])}>{heading[2]}</h{len(heading[1])}>' if heading
                          else '<p>'+text.replace('\n', '<br>')+'</p>')
        output.extend(_note_md(note, references) if markdown else note_html(note, references) for note in placed.get(i, []))
    if unplaced:
        output.append('### 本轮其他证据说明（未定位到具体段落）' if markdown else '<h3>本轮其他证据说明（未定位到具体段落）</h3>')
        output.extend(_note_md(note, references) if markdown else note_html(note, references) for note in unplaced)
    return ('\n\n' if markdown else '').join(output)


def evidence_review(presentation, evidence_id, references, *, markdown=False):
    output = []
    for note in presentation['coverage_notes'] if presentation.get('policy') != POLICY else []:
        if evidence_id in note['evidence_ids']:
            output.append(_note_md(note, references) if markdown else note_html(note, references))
    for claim in presentation['claim_notes']:
        if evidence_id not in claim['evidence_ids']:
            continue
        same = evidence_id == claim['detail_evidence_id']
        text = html.escape(claim['text'])
        if markdown:
            output.append('支持的结论：'+text)
            if same and claim['details']:
                output.append('<details><summary>适用范围与实验条件（完整记录）</summary>\n\n' + '\n\n'.join(
                    html.escape(d['label']+'：'+d['text']) for d in claim['details']) + '\n\n</details>')
        else:
            output.append('<p>支持的结论：'+text+'</p>')
            if same and claim['details']:
                output.append('<details><summary>适用范围与实验条件（完整记录）</summary>'+''.join(
                    '<p>'+html.escape(d['label']+'：'+d['text'])+'</p>' for d in claim['details'])+'</details>')
        if not same and claim['details']:
            number = next((r['citation'] for r in references if r['evidence_id'] == claim['detail_evidence_id']), None)
            if number:
                output.append(f'完整说明见 [{number}](#evidence-{number})。' if markdown else f'<a href="#evidence-{number}">完整说明见 [{number}]</a>')
    return ('\n\n' if markdown else '').join(output)


def bibliography(presentation, *, markdown=False):
    output = ['## 参考文献' if markdown else '<section class="research-bibliography" id="bibliography"><h2>参考文献</h2><ol>']
    for r in presentation['bibliography']:
        label = f'[{r["citation"]}] {r["title"]} · {r["source_label"]}'
        if r['paper_id']:
            label += ' · '+str(r['paper_id'])
        label += f' · 第 {r["page"]} 页' if r['page'] else ' · 摘要或原文页码未定位'
        if markdown:
            output.append(f'{html.escape(label)} · [原文证据](#evidence-{r["citation"]})')
        else:
            output.append(f'<li><a href="#evidence-{r["citation"]}">{html.escape(label)}</a></li>')
    if not presentation['bibliography']:
        output.append('本轮没有可列出的已批准参考文献。' if markdown else '<li>本轮没有可列出的已批准参考文献。</li>')
    if not markdown:
        output.append('</ol></section>')
    return '\n\n'.join(output)


def report_content(answer, claims, coverage, references, plan=None, *, markdown=False, policy=POLICY):
    presentation = build_presentation(claims, coverage, references, plan, policy=policy)
    body = render_answer(answer, presentation, references, markdown=markdown)
    cards = []
    for ref in references:
        n, locator = ref['citation'], ref.get('locator') or {}
        location = f'第 {locator["page"]} 页' if locator.get('page') else '摘要级或原文页码未定位'
        strength = html.escape(str(ref.get('evidence_strength_label') or '原文层级见元数据'))
        position = html.escape(json.dumps(locator,ensure_ascii=False,indent=2))
        attribution = html.escape(str((ref.get('source_attribution') or {}).get('label') or '来源用途未分类；原句存在不等于原句支持所有推断。'))
        extra = (f'\n\n证据等级：{strength}\n\n来源用途：{attribution}\n\n<details><summary>原文定位详情</summary><pre>{position}</pre></details>'
                 if markdown else f'<p>证据等级：{strength}</p><p>来源用途：{attribution}</p><details><summary>原文定位详情</summary><pre>{position}</pre></details>')
        if ref.get('excerpt_truncated'):
            extra += '\n\n此处为长片段节选，请打开原文页核对完整内容。' if markdown else '<p>此处为长片段节选，请打开原文页核对完整内容。</p>'
        if (ref.get('parser_provenance') or {}).get('parser') == 'llamaparse':
            warning = 'LlamaCloud 转写片段：页码已关联；转写不等于原文核验，公式和数字请对照原页。'
            extra += '\n\n' + warning if markdown else '<p>' + warning + '</p>'
        title = html.escape(str(ref.get('title') or ''))
        excerpt = html.escape(str(ref.get('excerpt') or ''))
        review = evidence_review(presentation, ref['evidence_id'], references, markdown=markdown)
        if markdown:
            cards.append(f'<a id="evidence-{n}"></a>\n\n### [{n}] {title}\n\n{location}{extra}\n\n> '+excerpt.replace('\n','\n> ')+'\n\n'+review)
        else:
            cards.append(f'<article id="evidence-{n}"><h3>[{n}] {title}</h3><p>{location}</p>{extra}<blockquote>{excerpt}</blockquote>{review}</article>')
        url = ref.get('official_pdf_url') or ref.get('official_url') or ''
        if re.fullmatch(r'https://arxiv\.org/(?:abs|pdf)/[A-Za-z0-9./_-]+(?:#page=[1-9]\d*)?', url):
            link = f'\n\n[官方原文]({url})' if markdown else f'<p><a href="{html.escape(url, quote=True)}" target="_blank" rel="noopener noreferrer">官方原文 / PDF 页</a></p>'
            cards[-1] = cards[-1] + link if markdown else cards[-1].removesuffix('</article>') + link + '</article>'
        elif ref.get('source') == 'uploaded_pdf':
            note = '用户上传原文；请从已认证的任务证据栏查看 PDF 和原文页。'
            cards[-1] = cards[-1]+'\n\n'+note if markdown else cards[-1].removesuffix('</article>')+'<p>'+note+'</p></article>'
    return presentation, body, cards
