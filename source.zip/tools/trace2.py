# -*- coding: utf-8 -*-
import sys, pathlib, logging
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
logging.disable(logging.WARNING)
from deepdiver_v2.src.query_router import build_literature_query_plan, score_literature_relevance
from deepdiver_v2.src.literature_sources import search_source
from deepdiver_v2.cli.demo import _semantic_filter_literature_candidates, get_config

QUERIES = [
    "滑动窗口注意力（sliding window attention）在 Longformer 等模型中是如何降低复杂度的？",
    "ACT 系列和 Diffusion Policy 在动作生成上有什么区别？",
]
config = get_config()
for QUERY in QUERIES:
    print("=" * 70); print("Q:", QUERY); print("=" * 70)
    plan = build_literature_query_plan(QUERY)
    queries = [p["query"] for p in plan if p.get("query")]
    print(f"plan: {len(queries)}")
    for q in queries[:6]: print("  Q:", q[:120])
    cands = []
    for q in queries[:4]:
        try:
            r = search_source("arxiv", q, limit=10)
            r = r.get("papers") if isinstance(r, dict) else r
            r = r or []
            for p in r:
                p["relevance"] = score_literature_relevance(QUERY, p)
                cands.append(p)
        except Exception as e:
            print("err", e)
    print(f"total cands: {len(cands)}")
    kept, diag = _semantic_filter_literature_candidates(QUERY, cands, config)
    print(f"semantic: {diag}")
    for k in kept[:10]:
        print("  KEPT", k["relevance"].get("semantic_label"), (k.get("title") or "")[:60])
    print()
