/* Actual production UI and HTTP APIs, fresh browser; secrets supplied via stdin only. */
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {chromium}=require('playwright');
let input='';process.stdin.setEncoding('utf8');process.stdin.on('data',part=>{input+=part;if(input.length>65536)process.exit(2);});
process.stdin.on('end',async()=>{
 const data=JSON.parse(input),url=new URL(data.base_url),directory=path.resolve(data.output_directory);
 if(url.protocol!=='http:'||url.hostname!=='127.0.0.1'||url.port==='5000')throw Error('Owned temporary instance required');
 const checks={},errors=[],traffic=[];let browser,submitPage,step='login';
 const mark=name=>{step=name;fs.writeFileSync(path.join(directory,'browser_step.json'),JSON.stringify({step:name}));};
 process.on('unhandledRejection',()=>{fs.writeFileSync(path.join(directory,'browser_unhandled.json'),JSON.stringify({step,error_type:'UnhandledPromiseRejection'}));process.exit(1);});
 try{
  const chrome='C:/Program Files/Google/Chrome/Application/chrome.exe';
  browser=await chromium.launch({headless:true,...(fs.existsSync(chrome)?{executablePath:chrome}:{})});
  const context=await browser.newContext({viewport:{width:1366,height:1000},acceptDownloads:true,ignoreHTTPSErrors:true});
  const page=await context.newPage();page.on('pageerror',e=>errors.push(e.name));
  page.on('request',req=>{const u=new URL(req.url());if(u.origin===url.origin)traffic.push({path:u.pathname,method:req.method()});});
  await page.goto(data.base_url+'/login.html',{waitUntil:'domcontentloaded'});
  const licensePagePromise=context.waitForEvent('page');
  await page.locator('#source-license-link').click();
  const licensePage=await licensePagePromise;await licensePage.waitForLoadState('domcontentloaded');
  checks.public_source_entry_click=licensePage.url()===data.base_url+'/open-source'
    &&(await licensePage.locator('h1').innerText())==='开源许可与对应源码';
  await licensePage.screenshot({path:path.join(directory,'public-source-entry.png')});
  await licensePage.close();
  await page.locator('#loginId').fill(data.username);await page.locator('#password').fill(data.password);
  await page.locator('#loginBtn').click();await page.waitForURL('**/ai_chat.html',{timeout:20000});
  checks.real_login_button=await page.evaluate(()=>!!sessionStorage.getItem('userToken'));
  await page.waitForFunction(()=>window.ResearchLibrary&&window.MultiAgentRagUI);
  // Production ships static CSS; no browser-side Tailwind compiler is expected.
  await page.waitForFunction(()=>{
   const probe=document.createElement('div');probe.className='flex';document.body.append(probe);
   const ready=getComputedStyle(probe).display==='flex';probe.remove();return ready;
  });
  checks.static_css_ready=true;
  await page.locator('#file-library-btn').click();await page.waitForSelector('.library-analyze-btn');
  checks.real_library_list=await page.locator('#file-library-list').innerText().then(text=>text.includes('科研验收原件.pdf'));
  await page.locator('.library-preview-btn').click();await page.waitForSelector('.library-page-viewer img[src]');
  await page.waitForFunction(()=>document.querySelector('.library-page-viewer img')?.naturalWidth>0);
  checks.authenticated_page_blob=(await page.locator('.library-page-viewer img').getAttribute('src')).startsWith('blob:');
  checks.original_page_visually_rendered=await page.locator('.library-page-viewer img').evaluate(node=>node.complete&&node.naturalHeight>0);
  checks.actual_pdf_response=await page.evaluate(async id=>{const r=await fetch('/5000/api/research-library/files/'+id+'/pdf');const b=new Uint8Array(await r.arrayBuffer());
    return r.ok&&new TextDecoder().decode(b.slice(0,5))==='%PDF-';},data.file_id);
  await page.screenshot({path:path.join(directory,'original-pdf-preview.png')});
  await page.locator('.library-page-controls button').filter({hasText:'下一页'}).click();
  await page.waitForFunction(()=>document.querySelector('.library-page-controls span')?.textContent.includes('第 2 /'));
  checks.original_page_navigation=true;
  await page.locator('.research-library-dialog button').filter({hasText:'关闭'}).click();
  await page.locator('.library-detail-btn').click();await page.waitForSelector('.library-outcome');
  const labels={completed:'已完成',partial:'有限回答',needs_review:'需要复核'};
  const outcomes=await page.locator('.library-outcome').allInnerTexts();
  checks.localized_outcome_status=(data.outcome_statuses||['partial']).every(status=>
    labels[status]&&outcomes.some(text=>text.includes(labels[status])));
  await page.locator('.research-library-dialog button').filter({hasText:'关闭'}).click();
  // Selecting is zero fee: no task POST. Existing task was produced via real Web API.
  const before=traffic.filter(r=>r.path.endsWith('/science/tasks')&&r.method==='POST').length;
  await page.locator('.library-analyze-btn').click();await page.waitForSelector('#library-selected-pdf:not([hidden])');
  checks.selection_no_task_post=traffic.filter(r=>r.path.endsWith('/science/tasks')&&r.method==='POST').length===before;
  checks.default_no_public_consent=!(await page.locator('#library-public-consent').isChecked());
  await page.evaluate(async()=>{await window.SciencePdfSession.restore();});
  checks.single_source_card=await page.locator('#session-pdf-attachment:visible').count()===0;
  // Mount the existing owned report through the same chat renderer, not a fake report payload.
  await page.evaluate(async({task,session})=>{window.currentSessionId=session;
   document.getElementById('back-to-chat-btn').click();document.getElementById('initial-prompt')?.remove();
   const message=addMessage('正在载入现有报告','ai',session,0,'',{multiAgentRag:true});
   const response=await fetch('/5000/api/science/tasks/'+task);const body=await response.json();
   window.MultiAgentRagUI.attach(body.task||body,session,message);
  },{task:data.task_id,session:data.conversation_id});
  await page.waitForSelector('.rag-evidence');
  checks.real_inline_report=await page.locator('.rag-answer-body').innerText().then(text=>text.length>10);
  const citation=page.locator('.rag-answer-body button.rag-citation').first();
  if(await citation.count()){await citation.click();checks.actual_citation_click=true;}else{
    const button=page.locator('.rag-navigation button').filter({hasText:'[1]'}).first();await button.click();checks.actual_citation_click=true;
  }
  await page.locator('.rag-evidence button').filter({hasText:'查看原文页 / 引用高亮'}).first().click();
  await page.waitForSelector('.rag-page-preview img');
  checks.real_source_page_image=await page.locator('.rag-page-preview img').first().evaluate(node=>node.complete&&node.naturalWidth>0);
  checks.real_bbox_overlay=await page.locator('.rag-page-preview .rag-bbox').count()>0;
  await page.locator('.rag-page-preview').first().evaluate(node=>{
    const scroll=node.closest('.rag-source-scroll');scroll.scrollTop=node.offsetTop-scroll.offsetTop;
  });
  await page.locator('.rag-page-preview').first().screenshot({path:path.join(directory,'source-page-highlight.png')});
  await page.locator('.rag-download-menu summary').first().click();
  const downloadPromise=page.waitForEvent('download');await page.locator('.rag-download-menu button').filter({hasText:'下载 MD 报告'}).first().click();
  const download=await downloadPromise;await download.saveAs(path.join(directory,'browser-downloaded-report.md'));
  checks.real_authenticated_report_download=fs.statSync(path.join(directory,'browser-downloaded-report.md')).size>100;
  const handle=page.locator('#sidebar-resize-handle'),position=await handle.boundingBox();
  await page.mouse.move(position.x+3,position.y+100);await page.mouse.down();await page.mouse.move(340,position.y+100);await page.mouse.up();
  checks.real_resize_handle=await page.evaluate(()=>document.getElementById('sidebar').style.width==='340px');
  await page.waitForTimeout(3500);await page.screenshot({path:path.join(directory,'report-wide.png')});
  await page.setViewportSize({width:877,height:1000});await page.waitForTimeout(500);
  checks.medium_no_overflow=await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth);
  await page.screenshot({path:path.join(directory,'report-medium.png')});
  await page.setViewportSize({width:462,height:900});await page.waitForTimeout(600);
  checks.narrow_no_overflow=await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth);
  await page.screenshot({path:path.join(directory,'report-narrow.png')});
  // Real UI, controlled network failure; the backend session is not deleted.
  await page.setViewportSize({width:1366,height:1000});await page.waitForTimeout(500);
  const row=page.locator(`.chat-session[data-id="${data.conversation_id}"]`),answer=await page.locator('.rag-answer-body').innerText();
  const deletion='**/api/chat/sessions/'+data.conversation_id;
  let deleteIntercepted=false;
  await page.route(deletion,async route=>{if(route.request().method()==='DELETE'){
    deleteIntercepted=true;await route.fulfill({status:500,contentType:'application/json',body:'{"success":false}'});
   }else await route.continue();});
  await row.hover();await row.locator('.session-menu-btn').click();await row.locator('.delete-btn').click();
  await page.locator('#session-delete-confirm-btn').click();
  await page.waitForFunction(()=>Array.from(document.querySelectorAll('.toast')).some(n=>n.textContent.includes('删除失败')));
  checks.delete_500_keeps_session=deleteIntercepted&&await row.count()===1;
  checks.delete_500_keeps_answer=(await page.locator('.rag-answer-body').innerText())===answer;
  await page.unroute(deletion);
  // Delay a real authenticated list. A newer user selection must win.
  let listIntercepted=false,releaseList;
  const listGate=new Promise(resolve=>{releaseList=resolve;});
  const listPath='**/api/chat/sessions/'+data.user_id;
  await page.route(listPath,async route=>{const response=await route.fetch();listIntercepted=true;await listGate;await route.fulfill({response});});
  await page.evaluate(({id,owner})=>{window.ConversationSelection.remember(id);window.currentSessionId=null;getList(owner);},
    {id:data.conversation_id,owner:data.user_id});
  for(let i=0;i<100&&!listIntercepted;i++)await page.waitForTimeout(20);
  if(!listIntercepted)throw Error('Authenticated delayed list not reached');
  await page.locator('#new-chat-btn').click();
  await page.waitForFunction(old=>window.currentSessionId&&window.currentSessionId!==old,data.conversation_id);
  const newlySelected=await page.evaluate(()=>window.currentSessionId);releaseList();
  await page.waitForSelector(`.chat-session[data-id="${data.conversation_id}"]`);await page.waitForTimeout(500);
  checks.late_list_keeps_new_selection=await page.evaluate(id=>window.currentSessionId===id,newlySelected);
  await page.unroute(listPath);
  checks.no_token_in_url=traffic.every(r=>!/token|authorization/i.test(r.path));
  checks.no_new_model_requests=traffic.filter(r=>r.path.endsWith('/science/tasks')&&r.method==='POST').length===0;
  // An additional real browser submit/upload/reuse journey. The backend CLI
  // models are fixed fixtures; this proves UI wiring, not scientific quality.
  const submissionTasks=[];
  if(data.model_mode==='mock'&&data.pdf_path){
   mark('ui_submit_login');
   submitPage=await context.newPage();
   submitPage.on('pageerror',e=>errors.push(e.name));
   submitPage.on('request',req=>{const u=new URL(req.url());if(u.origin===url.origin)traffic.push({path:u.pathname,method:req.method()});});
   await submitPage.goto(data.base_url+'/login.html',{waitUntil:'domcontentloaded'});
   await submitPage.locator('#loginId').fill(data.username);await submitPage.locator('#password').fill(data.password);
   await submitPage.locator('#loginBtn').click();await submitPage.waitForURL('**/ai_chat.html');
   await submitPage.waitForFunction(()=>window.ResearchLibrary&&window.MultiAgentRagUI);
   await submitPage.locator('#new-chat-btn').click();
   await submitPage.waitForFunction(()=>!!window.currentSessionId);
   const session=await submitPage.evaluate(()=>window.currentSessionId);
   mark('ui_submit_upload');
   checks.default_unified_research_mode=await submitPage.locator('#research-processing-mode').inputValue()==='multi_agent_rag';
   await submitPage.locator('#research-report-profile').selectOption('standard');
   await submitPage.locator('#context-file-label').click();
   const fileChoice=submitPage.waitForEvent('filechooser');
   await submitPage.locator('#attachment-upload-action').click();await(await fileChoice).setFiles(data.pdf_path);
   await submitPage.waitForSelector('#library-local-only');
   checks.ui_upload_defaults_local=await submitPage.locator('#library-local-only').isChecked();
   for(const question of ['解释本文方法与实验条件。','继续说明本文哪些参数更新。']){
    mark('ui_submit_send_'+submissionTasks.length);
    await submitPage.locator('#user-input').fill(question);
    checks.send_enabled_after_input=await submitPage.locator('#chat-send-btn').isEnabled();
    checks.attachment_button_not_overwritten=await submitPage.locator('#context-file-label .fa-paperclip').count()===1;
    const [response]=await Promise.all([
     submitPage.waitForResponse(r=>r.request().method()==='POST'&&new URL(r.url()).pathname.endsWith('/science/tasks'),{timeout:20000}),
     submitPage.locator('#chat-form button[type=submit]').click()]);
    assert.equal(response.status(),202);
    const body=await response.json(),task=body.task||body;submissionTasks.push(task.id);
    mark('ui_submit_poll_'+submissionTasks.length);
    await submitPage.waitForFunction(async id=>{
     const response=await fetch('/5000/api/science/tasks/'+id);if(!response.ok)return false;
     const body=await response.json(),task=body.task||body;
     if(['failed','timed_out','cancelled'].includes(task.status))throw Error('UI task did not produce answer');
     return ['completed','partial','needs_review'].includes(task.status);
    },task.id,{timeout:45000,polling:500});
    await submitPage.waitForFunction(id=>!window.scienceActiveTaskIds?.[id],session);
   }
   const reportTask=await submitPage.evaluate(async id=>{
    const response=await fetch('/5000/api/science/tasks/'+id);const body=await response.json();return body.task||body;
   },submissionTasks[1]);
   checks.ui_followup_reuses_upload=reportTask.source_scope==='uploaded_pdf'&&reportTask.pdf_attachment?.source_task_id===submissionTasks[0];
   await submitPage.reload({waitUntil:'domcontentloaded'});
   await submitPage.waitForFunction(id=>window.currentSessionId===id,session);
   await submitPage.waitForSelector('.rag-answer-body');
   checks.ui_refresh_restores_submitted_answer=await submitPage.locator('.rag-answer-body').last().innerText().then(s=>s.length>10);
   await submitPage.screenshot({path:path.join(directory,'ui-submitted-pdf-followup.png')});
   await submitPage.close();
  }
  const result={passed:Object.values(checks).every(Boolean)&&!errors.length,checks,page_errors:errors,
    actual_api:true,actual_mysql:true,model_responses_mocked:data.model_mode!=='live',native_pdf_plugin_required:false,
    deletion_failure_injected:true,session_list_delayed:true,
    source_pdf_bytes_verified:true,model_calls_added:0,mock_workflow_tasks_submitted_in_browser:submissionTasks};
  fs.writeFileSync(path.join(directory,'browser_checks.json'),JSON.stringify(result,null,2),{flag:'wx'});
  console.log(JSON.stringify(result));assert(result.passed);
 }catch(e){
  const state=await submitPage?.evaluate(()=>({selected_tab:window.selectedTab,mode:document.getElementById('research-processing-mode')?.value,
   has_session:!!window.currentSessionId,has_pending_file:!!window.sciencePendingFile,attachment_count:window.attachedContexts?.length,
   send_disabled:document.querySelector('#chat-form button[type=submit]')?.disabled})).catch(()=>null);
  fs.writeFileSync(path.join(directory,'browser_failure.json'),JSON.stringify({checks,error_type:e.name,step,page_errors:errors,state,
   local_request_paths:traffic.slice(-20)}),{flag:'wx'});
  await submitPage?.screenshot({path:path.join(directory,'browser-failure.png')}).catch(()=>{});
  process.stderr.write('BROWSER_CHECK_FAILED\n');process.exitCode=1;
 }finally{await browser?.close();}
});
