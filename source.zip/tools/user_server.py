"""No-sudo Linux gateway preflight/foreground launcher, never a process killer.

Uses a dedicated CPython 3.11 venv and externally provisioned MySQL/Qdrant/MCP.
Does not install packages, import SQL, alter permissions or accept inline secrets.
"""
from __future__ import annotations

import argparse
import ipaddress
import json
import os
from pathlib import Path
import platform
import socket
import stat
import subprocess
import sys
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
SHARED_KEYS = ('MODEL_REQUEST_TOKEN', 'MODEL_REQUEST_TOKENS', 'LLAMA_CLOUD_API_KEY',
               'EMBEDDING_API_KEY', 'OPENAI_API_KEY', 'DEEPSEEK_API_KEY', 'OPENROUTER_API_KEY')
STATE = {
    'SCIASSISTANT_TASK_STATE_DIR': 'logs/task_state',
    'SCIASSISTANT_TASK_OWNER_STATE_PATH': 'logs/science_task_owners.json',
    'SCIASSISTANT_CONTEXT_FILE_OWNER_STATE_PATH': 'logs/context_file_owners.json',
    'SCIASSISTANT_PDF_SESSION_STATE_PATH': 'logs/science_pdf_sessions.sqlite3',
    'SCIASSISTANT_RESEARCH_LIBRARY_STATE_PATH': 'logs/research_library.sqlite3',
    'SCIASSISTANT_USER_CREDENTIAL_DB': 'logs/user_credentials.sqlite3',
    'SCIASSISTANT_USER_RUNTIME_ROOT': 'logs/user_runtime',
    'SCIASSISTANT_MULTI_AGENT_WEB_RUN_ROOT': 'logs/multi_agent_web_runs',
    'SCIASSISTANT_MULTI_AGENT_WEB_STORAGE_ROOT': 'logs/multi_agent_web_rag',
    'SCIASSISTANT_MULTI_AGENT_VECTOR_LOCK_ROOT': 'logs/rag_vector_locks',
    'MODEL_KEY_POOL_STATE_PATH': 'logs/model_key_pool.sqlite3',
}


def load_private_config(path):
    path = Path(path).absolute()
    if path.is_symlink() or path.resolve() != path or not path.is_file():
        raise ValueError('PRIVATE_CONFIG_NOT_PLAIN_FILE')
    info = path.stat()
    if path.is_relative_to(ROOT) or info.st_size > 262144:
        raise ValueError('PRIVATE_CONFIG_MUST_BE_OUTSIDE_RELEASE')
    if os.name != 'nt' and (stat.S_IMODE(info.st_mode) & 0o077 or info.st_uid != os.getuid()):
        raise ValueError('PRIVATE_CONFIG_OWNER_ONLY_REQUIRED')
    from dotenv import dotenv_values
    with path.open(encoding='utf-8-sig') as stream:
        values = dotenv_values(stream=stream, interpolate=False)
    if not values or any(value is None for value in values.values()):
        raise ValueError('PRIVATE_CONFIG_INVALID')
    return dict(values)


def secure_value(value, minimum=32):
    return (isinstance(value, str) and len(value) >= minimum and len(set(value)) >= 8
            and not any(word in value.lower() for word in ('replace_with', 'change-me', 'placeholder')))


def safe_https(value):
    try:
        parsed = urlsplit(value)
        return (parsed.scheme == 'https' and bool(parsed.hostname) and not parsed.username
                and not parsed.password and not parsed.query and not parsed.fragment)
    except ValueError:
        return False


def config_checks(values, fingerprint):
    from source_delivery import source_status
    checks = {
        'production': values.get('APP_ENV') == 'production',
        'private_signing_key': secure_value(values.get('SECRET_KEY')),
        'stable_separate_vault_key': secure_value(values.get('USER_CREDENTIAL_ENCRYPTION_KEY')),
        'private_mcp_secret': secure_value(values.get('MCP_SHARED_SECRET')),
        'mysql_not_root': bool(values.get('MYSQL_USER')) and values['MYSQL_USER'].lower() != 'root',
        'mysql_configured': bool(values.get('MYSQL_HOST')) and bool(values.get('MYSQL_DATABASE'))
                            and secure_value(values.get('MYSQL_PASSWORD'), 12),
        'shared_provider_keys_absent': not any(values.get(key, '').strip() for key in SHARED_KEYS),
        'model_endpoint': safe_https(values.get('MODEL_REQUEST_URL', '')) and bool(values.get('MODEL_NAME')),
        'protected_vector_endpoint': safe_https(values.get('SCIASSISTANT_QDRANT_URL', ''))
                                     and secure_value(values.get('SCIASSISTANT_QDRANT_API_KEY')),
        'local_embedding': values.get('SCIASSISTANT_EMBEDDING_PROVIDER', 'local') == 'local'
                           and Path(values.get('SCIASSISTANT_EMBEDDING_MODEL', '')).is_absolute(),
        'source_delivery_bound': source_status(values, fingerprint)['ready'],
        'no_dotenv_fallback': not (ROOT/'.env').exists() and not (ROOT/'deepdiver_v2/config/.env').exists(),
    }
    try:
        host = values.get('ACCOUNT_BIND_ADDRESS', '127.0.0.1')
        port = int(values.get('ACCOUNT_HOST_PORT', '5000'))
        address = ipaddress.ip_address(host)
        checks['loopback_nonprivileged_listener'] = address.version == 4 and address.is_loopback and 1024 <= port <= 65535
    except (ValueError, TypeError):
        checks['loopback_nonprivileged_listener'] = False
    try:
        mcp = urlsplit(values.get('MCP_SERVER_URL', ''))
        private_http = mcp.scheme == 'http' and mcp.hostname == '127.0.0.1' and bool(mcp.port)
        checks['private_mcp_endpoint'] = ((private_http or safe_https(values.get('MCP_SERVER_URL', '')))
                                        and mcp.path == '/mcp' and not mcp.username and not mcp.password
                                        and not mcp.query and not mcp.fragment
                                        and values.get('MCP_USE_STDIO', '').lower() == 'false')
    except ValueError:
        checks['private_mcp_endpoint'] = False
    checks['release_state_directories_plain'] = all(not (ROOT/name).is_symlink() for name in (
        'logs', 'uploads', 'user_files', 'web_uploads', 'arxiv'))
    return checks


def runtime_environment(values):
    env = os.environ.copy()
    env.update(values)
    # Prevent ambient shared keys and private configs from becoming user fallback.
    for key in SHARED_KEYS: env[key] = ''
    env.update({key: str(ROOT/relative) for key, relative in STATE.items()})
    env.update(PYTHONDONTWRITEBYTECODE='1', PYTHONIOENCODING='utf-8',
               HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', SCIASSISTANT_EMBEDDING_ALLOW_DOWNLOAD='0',
               SCIASSISTANT_WEB_BASE='', OMP_NUM_THREADS='2', TOKENIZERS_PARALLELISM='false')
    return env


def child_check(args, env, timeout):
    try:
        child = subprocess.run([sys.executable, *args], cwd=ROOT, env=env,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
        # Deliberately do not propagate provider/DB output, paths or exceptions.
        return child.returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


def preflight(values, *, dependencies=True):
    from runtime_identity import source_fingerprint
    fingerprint, complete = source_fingerprint(ROOT)
    checks = config_checks(values, fingerprint)
    checks['linux_x86_64_python311_venv'] = (sys.platform == 'linux' and platform.machine() == 'x86_64'
                                            and sys.version_info[:2] == (3, 11) and sys.prefix != sys.base_prefix)
    checks['source_complete'] = complete
    if all(checks.values()) and dependencies:
        env = runtime_environment(values)
        checks['installed_locks_exact'] = child_check(['tools/rag_cloud.py', 'verify-installed',
                                                       '--output', '.rag-dependency-lock.json'], env, 45)
        checks['mysql_schema_read_only'] = child_check(['account_schema.py', 'check'], env, 70)
        checks['cpu_model_and_protected_vector'] = child_check(['tools/rag_startup.py'], env, 120)
        checks['mcp_health'] = child_check(['-c', 'import os; from research_runtime import check_shared_mcp; check_shared_mcp(dict(os.environ))'], env, 8)
        try:
            with socket.socket() as probe:
                probe.bind((values.get('ACCOUNT_BIND_ADDRESS', '127.0.0.1'), int(values.get('ACCOUNT_HOST_PORT', '5000'))))
            checks['listener_available'] = True
        except OSError:
            checks['listener_available'] = False
    return {'schema_version': 'sciassistant.user-server-check/v1', 'passed': all(checks.values()),
            'checks': checks, 'source_fingerprint': fingerprint, 'answer_model_calls': 0,
            'installs_or_migrations': 0, 'production_https_verified': False,
            'dependencies_checked': dependencies and 'installed_locks_exact' in checks}


def launch_argv(values):
    return [sys.executable, '-m', 'gunicorn', '--bind',
            values.get('ACCOUNT_BIND_ADDRESS', '127.0.0.1')+':'+values.get('ACCOUNT_HOST_PORT', '5000'),
            '--workers', '1', '--threads', '4', '--timeout', '900', '--graceful-timeout', '900',
            '--access-logfile', '-', '--error-logfile', '-', 'app:app']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('check', 'serve'))
    parser.add_argument('--env-file', type=Path, required=True)
    args = parser.parse_args()
    try:
        values = load_private_config(args.env_file)
        result = preflight(values)
        print(json.dumps(result), flush=True)
        if not result['passed']: return 2
        if args.command == 'serve':
            os.chdir(ROOT)
            os.execve(sys.executable, launch_argv(values), runtime_environment(values))
        return 0
    except Exception:
        print(json.dumps({'schema_version': 'sciassistant.user-server-check/v1',
                          'passed': False, 'error': 'USER_SERVER_PREFLIGHT_FAILED'}))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
