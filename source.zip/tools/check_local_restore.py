"""Isolated local MySQL + encrypted-key + file backup rehearsal.

Creates TWO new, uniquely named scratch databases with the shipped schema.
Never dumps, imports into, stops or alters the configured application database.
Only synthetic account/file data are used; no production provider key is read.
Scratch databases are retained, never silently dropped. Not Linux-volume DR.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import sqlite3
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-id', required=True)
    parser.add_argument('--mysql-bin', type=Path, required=True)
    args = parser.parse_args()
    if not re.fullmatch(r'[a-z0-9-]{1,60}', args.run_id):
        parser.error('invalid run id')
    directory = ROOT / 'backup_restore_staging' / args.run_id
    if directory.exists():
        parser.error('run id already exists')
    directory.mkdir(parents=True)
    checks = {}
    report = {'schema_version': 'sciassistant.local-restore-check/v1', 'checks': checks,
              'synthetic_accounts_only': True, 'production_database_exported': False,
              'production_service_touched': False, 'linux_volumes_verified': False,
              'scratch_databases_retained': True}
    client_config = directory / 'mysql-client.cnf'
    connection = None
    try:
        import pymysql
        from account_schema import _connection_settings, check_schema
        from user_credentials import CredentialStore
        from werkzeug.security import generate_password_hash, check_password_hash
        from tools.account_backup import DATA_ROOTS, create_bundle, verify_bundle, restore_stage
        from science_pdf_sessions import PdfSessions
        from research_library import LibraryLinks
        from multi_agent_workflow import WorkflowStore

        settings, configured_database = _connection_settings()
        # Refuse remote connections: formal server work is explicitly deferred.
        if settings['host'] not in {'localhost', '127.0.0.1', '::1'}:
            raise ValueError('LOCAL_MYSQL_REQUIRED')
        settings.pop('database', None)
        connection = pymysql.connect(**settings)
        suffix = secrets.token_hex(6)
        source_db, target_db = 'sci_dr_' + suffix + '_src', 'sci_dr_' + suffix + '_dst'
        if configured_database in {source_db, target_db}:
            raise ValueError('SCRATCH_DATABASE_COLLISION')
        with connection.cursor() as cursor:
            cursor.execute('CREATE DATABASE `' + source_db + '` CHARACTER SET utf8mb4')
            cursor.execute('CREATE DATABASE `' + target_db + '` CHARACTER SET utf8mb4')
        report['scratch_databases'] = [source_db, target_db]
        connection.select_db(source_db)
        schema = (ROOT / 'deploy/mysql-init/001_schema.sql').read_text(encoding='utf-8')
        schema = '\n'.join(line for line in schema.splitlines() if not line.lstrip().startswith('--'))
        with connection.cursor() as cursor:
            for statement in schema.split(';'):
                if statement.strip():
                    cursor.execute(statement)
        password = secrets.token_urlsafe(30)
        with connection.cursor() as cursor:
            cursor.execute('INSERT INTO users(id,username,email,password) VALUES(%s,%s,%s,%s)',
                           (1, 'restore_fixture', 'restore@example.invalid', generate_password_hash(password)))
            cursor.execute("INSERT INTO chat_list(user_id,session_id,title) VALUES(1,'restore-session','恢复预演')")
            cursor.execute("INSERT INTO conversation_detail(session_id,from_who,`round`,timestamp,content) "
                           "VALUES('restore-session','ai',1,NOW(),'fixture report')")
        connection.commit()
        checks['source_uses_current_schema'] = check_schema(connection, source_db)['status'] == 'ready'

        export = directory / 'export'
        for name in DATA_ROOTS:
            (export / name).mkdir(parents=True)
        (export / 'logs/task.json').write_text(json.dumps({'id': 'restore-task', 'user_id': '1',
             'conversation_id': 'restore-session', 'status': 'partial', 'model_calls': 5}), encoding='utf8')
        (export / 'logs/science_task_owners.json').write_text('{"restore-task":"1"}', encoding='utf8')
        for name in ('uploads/source.pdf', 'user_files/report.md', 'web_uploads/context.txt', 'arxiv/metadata.json'):
            (export / name).write_bytes(('isolated fixture: ' + name).encode())
        vault_secret = secrets.token_urlsafe(40)
        fake_key = 'restore-fixture-' + secrets.token_hex(24)
        CredentialStore(export / 'logs/user_credentials.sqlite3', vault_secret).update('1', {'deepseek_keys': [fake_key]})
        bindings = PdfSessions(export / 'logs/science_pdf_sessions.sqlite3')
        generation = bindings.reserve('1', 'restore-session')
        if not bindings.bind('1', 'restore-session', generation, 'abcdef123456'):
            raise ValueError('FIXTURE_PDF_BIND_FAILED')
        LibraryLinks(export / 'logs/research_library.sqlite3').link('1', 'fixture-file', 'abcdef123456', 'restore-session')
        workflow = WorkflowStore(export / 'logs/workflow.sqlite3')
        workflow.create_run('restore-task', '1')
        workflow.reserve_model_call('restore-task', 'planner')
        for stage in ('planned', 'retrieving', 'partial'):
            workflow.transition('restore-task', stage)
        # Closed SQLite connection and quiesced fixture: no WAL is silently lost.
        with sqlite3.connect(export / 'logs/user_credentials.sqlite3') as db:
            db.execute('PRAGMA wal_checkpoint(TRUNCATE)')

        def ini(value):
            return '"' + str(value).replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\r', '\\r') + '"'
        client_config.write_text('[client]\n' + '\n'.join(k + '=' + ini(settings[k])
                                 for k in ('host', 'user', 'password')) + '\n', encoding='utf8')
        os.chmod(client_config, 0o600)
        extension = '.exe' if os.name == 'nt' else ''
        dump_client, import_client = (args.mysql_bin / (name + extension) for name in ('mysqldump', 'mysql'))
        if not dump_client.is_file() or not import_client.is_file():
            raise ValueError('MYSQL_CLIENTS_REQUIRED')
        dump = directory / 'fixture.sql'
        result = subprocess.run([str(dump_client), '--defaults-extra-file=' + str(client_config),
            '--single-transaction', '--no-tablespaces', '--set-gtid-purged=OFF', '--skip-comments',
            '--default-character-set=utf8mb4', '--result-file=' + str(dump), source_db],
            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=60)
        if result.returncode:
            raise ValueError('SCRATCH_MYSQL_DUMP_FAILED')
        checks['actual_mysql_dump'] = dump.stat().st_size > 0
        bundle = directory / 'bundle.sciassistant-backup'
        checks['bundle_created'] = create_bundle(export, dump, bundle)['passed']
        checks['bundle_verified'] = verify_bundle(bundle)['passed']
        staged = directory / 'restored'
        checks['restore_staged'] = restore_stage(bundle, staged)['passed']
        with (staged / 'payload/database.sql').open('rb') as source:
            result = subprocess.run([str(import_client), '--defaults-extra-file=' + str(client_config),
                '--default-character-set=utf8mb4', target_db], stdin=source,
                stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=60)
        if result.returncode:
            raise ValueError('SCRATCH_MYSQL_IMPORT_FAILED')
        # A restored application reconnects; do not retain the export reader's
        # pre-import transaction/metadata snapshot across an external import.
        connection.close()
        connection = pymysql.connect(**settings, database=target_db)
        checks['restored_schema_ready'] = check_schema(connection, target_db)['status'] == 'ready'
        with connection.cursor() as cursor:
            cursor.execute('SELECT password FROM users WHERE id=1')
            checks['restored_account_password_verifies'] = check_password_hash(cursor.fetchone()['password'], password)
            cursor.execute("SELECT content FROM conversation_detail WHERE session_id='restore-session'")
            checks['restored_conversation'] = cursor.fetchone()['content'] == 'fixture report'
        data = staged / 'payload/data'
        checks['restored_all_file_hashes'] = all(hashlib.sha256(p.read_bytes()).digest() ==
            hashlib.sha256((data / p.relative_to(export)).read_bytes()).digest() for p in export.rglob('*') if p.is_file())
        vault = CredentialStore(data / 'logs/user_credentials.sqlite3', vault_secret)
        checks['restored_own_key'] = vault.capability('1').values['MODEL_REQUEST_TOKEN'] == fake_key
        checks['restored_other_user_has_no_key'] = not any(vault.capability('2').values.values())
        try:
            CredentialStore(data / 'logs/user_credentials.sqlite3', secrets.token_urlsafe(40)).capability('1')
        except ValueError:
            checks['wrong_encryption_key_fails_closed'] = True
        else:
            checks['wrong_encryption_key_fails_closed'] = False
        checks['restored_owner_and_terminal_state'] = (json.loads((data / 'logs/task.json').read_text())['status'] == 'partial'
              and json.loads((data / 'logs/science_task_owners.json').read_text())['restore-task'] == '1')
        restored_bindings = PdfSessions(data / 'logs/science_pdf_sessions.sqlite3')
        checks['restored_pdf_binding_owned'] = restored_bindings.get('1', 'restore-session') == 'abcdef123456'
        checks['restored_pdf_binding_cross_account_empty'] = restored_bindings.get('2', 'restore-session') is None
        restored_library = LibraryLinks(data / 'logs/research_library.sqlite3')
        checks['restored_library_links_owned'] = restored_library.tasks('1', 'fixture-file') == [
            {'task_id': 'abcdef123456', 'conversation_id': 'restore-session'}]
        checks['restored_library_links_cross_account_empty'] = restored_library.tasks('2', 'fixture-file') == []
        restored_workflow = WorkflowStore(data / 'logs/workflow.sqlite3').get_run('restore-task')
        checks['restored_workflow_terminal_and_budget'] = (restored_workflow['status'] == 'partial'
                                                           and restored_workflow['model_calls_used'] == 1)
        # Corrupt a COPY only. The valid bundle and restore stay available.
        damaged = directory / 'damaged.sciassistant-backup'
        shutil.copytree(bundle, damaged)
        with (damaged / 'payload/data/uploads/source.pdf').open('ab') as stream:
            stream.write(b'corrupted')
        checks['tampering_rejected'] = not verify_bundle(damaged)['passed']
        report['passed'] = all(checks.values())
    except Exception as exc:
        report['passed'] = False
        safe_code = getattr(exc, 'code', None)
        report['error'] = safe_code if isinstance(safe_code, str) and re.fullmatch('[A-Z_]+', safe_code) else (
            str(exc) if isinstance(exc, ValueError) and re.fullmatch('[A-Z_]+', str(exc)) else 'LOCAL_RESTORE_EXECUTION_FAILED')
        report['exception_type'] = type(exc).__name__
    finally:
        if connection:
            connection.close()
        client_config.unlink(missing_ok=True)
        (directory / 'result.json').write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf8')
    print(json.dumps(report, ensure_ascii=True))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
