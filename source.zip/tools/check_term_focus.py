"""Read-only terminology/absence-choice diagnostics; never repair an old audit."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))


def hashes(run):
    return {str(p.relative_to(run)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in run.rglob('*') if p.is_file()}


def inspect(run):
    from multi_agent_agents import ArtifactDirectory
    from multi_agent_quality import (TERM_BINDING_POLICY,ABSENCE_CHOICE_POLICY,
        source_term_definitions,check_term_family_aliases,absence_assertion_options,resolve_absence_choices)
    before=hashes(run)
    store=ArtifactDirectory(run/'artifacts')
    manifest=json.loads((run/'manifest.json').read_text(encoding='utf-8-sig'))
    final=store.get(manifest['final_artifact_id']); refs=final['artifact_refs']
    draft,approved,audit=(store.get(refs[k]) for k in ('draft','approved','audit'))
    proposed={**deepcopy(draft),'term_binding_policy':TERM_BINDING_POLICY,'absence_choice_policy':ABSENCE_CHOICE_POLICY}
    definitions=source_term_definitions(approved); menu=absence_assertion_options(proposed)
    preserved,resolution=resolve_absence_choices(audit,menu,proposed)
    clauses=[]
    fields={c['claim_id']:c for c in draft['claims']}
    for row in audit.get('claim_results',[]):
        for field,value in (row.get('field_results') or {}).items():
            for check in value.get('absence_checks',[]):
                actual=str(fields.get(row['claim_id'],{}).get(field) or '')
                assertion=check.get('assertion')
                if isinstance(assertion,str) and assertion not in actual:
                    clauses.append({'claim_id':row['claim_id'],'field':field,'original_assertion':assertion,
                        'actual_field':actual,'same_field_options':[r['assertion_id'] for r in menu['options']
                            if r['claim_id']==row['claim_id'] and r['field']==field]})
    return {'run_id':manifest['run_id'],'historical_status':final['status'],
        'original_policy_term_findings':check_term_family_aliases(draft,approved),
        'current_policy_diagnostic_term_findings':check_term_family_aliases(proposed,approved),
        'source_term_definitions':definitions,'assertion_options':menu,
        'historical_non_substring_assertions':clauses,'old_audit_preserved':preserved==audit,
        'automatic_choices_count':len(resolution['resolutions']),
        'source_files':len(before),'source_hashes_unchanged':before==hashes(run),
        'historical_publication_rewritten':False}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-dir',nargs='+',type=Path,required=True)
    parser.add_argument('--output-dir',type=Path,required=True)
    args=parser.parse_args(); runs=[p.resolve() for p in args.run_dir]; output=args.output_dir.resolve()
    if any(not p.is_dir() or output.is_relative_to(p) or p.is_relative_to(output) for p in runs):
        parser.error('missing run or output overlaps source')
    output.mkdir(parents=True,exist_ok=False)
    rows=[inspect(run) for run in runs]
    result={'schema_version':'sciassistant.term-focus-diagnosis/v1','runs':rows,
        'model_calls':0,'network_requests':0,'automatic_scientific_approval':False,
        'passed':all(r['source_hashes_unchanged'] and r['old_audit_preserved'] and r['automatic_choices_count']==0 for r in rows)}
    (output/'checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'passed':result['passed'],'runs':[{'run_id':r['run_id'],
        'term_findings':[(e['claim_id'],e['field'],e['reason']) for e in r['current_policy_diagnostic_term_findings']],
        'old_non_substring_fields':[(e['claim_id'],e['field']) for e in r['historical_non_substring_assertions']],
        'automatic_choices':r['automatic_choices_count']} for r in rows],'model_calls':0,'network_requests':0}))
    return 0 if result['passed'] else 1


if __name__=='__main__':
    raise SystemExit(main())
