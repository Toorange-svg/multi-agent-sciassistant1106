"""Zero-model-cost HTTP check using a copied terminal task, not the live 5000.

Requires local DB access to validate actual account auth_version. It does not
log in, change users/ownership, restart a service, or create a research task.
The complete report bundle and SQLite snapshot are copied before HTTP checks.
The source run is never opened by the temporary Web app. This is an HTTP/API
test, not a browser or a real login-flow test. Application import may append
ordinary startup logs; owner/task/run files are checked for changes.
"""
import argparse
from contextlib import closing
import hashlib
import html
import json
import logging
import os
from pathlib import Path
import re
import shutil
import sqlite3
import sys
import tempfile
import threading

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def copy_report_bundle(source, target):
    """Copy terminal report inputs only, not private vectors or other tasks."""
    source, target = Path(source), Path(target)
    if source.is_symlink() or not source.is_dir() or target.exists():
        raise ValueError("invalid report copy")
    source = source.resolve()
    if target.resolve().is_relative_to(source) or source.is_relative_to(target.resolve()):
        raise ValueError("report copy overlaps source")
    files = [source / "manifest.json", source / "workflow.sqlite3"]
    for folder in ("artifacts", "pdf", "pages"):
        root = source / folder
        if root.is_symlink() or root.exists() and not root.resolve().is_relative_to(source):
            raise ValueError("unsafe report folder")
        if not root.exists():
            continue
        for path in root.rglob("*"):
            if path.is_symlink() or not path.resolve().is_relative_to(source):
                raise ValueError("unsafe report asset")
            if path.is_file() and (folder == "artifacts" and path.suffix == ".json"
                    or folder == "pdf" and path.name == "source.pdf"
                    or folder == "pages" and re.fullmatch(r"evidence-[1-9]\d*\.png", path.name)):
                files.append(path)
    if len(files) > 2000:
        raise ValueError("oversized report bundle")
    limits = {"manifest.json": 2_000_000, "workflow.sqlite3": 100_000_000}
    original = {}
    for path in files:
        limit = limits.get(path.name, 30 * 1024 * 1024 if path.suffix == ".pdf" else 10 * 1024 * 1024)
        if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(source) or path.stat().st_size > limit:
            raise ValueError("invalid report input")
        original[path.relative_to(source).as_posix()] = digest(path)
    target.mkdir()
    for path in files:
        destination = target / path.relative_to(source)
        destination.parent.mkdir(parents=True, exist_ok=True)
        if path.name == "workflow.sqlite3":
            with closing(sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)) as read:
                with closing(sqlite3.connect(destination)) as write:
                    read.backup(write)
        else:
            shutil.copyfile(path, destination)
    return original


def bundle_unchanged(source, hashes):
    return all(digest(Path(source) / name) == value for name, value in hashes.items())


def check(task_id, other_user_id):
    if "app" in sys.modules or "web_app" in sys.modules:
        raise ValueError("run this checker in a fresh process")
    from dotenv import dotenv_values
    values = {**dotenv_values(ROOT / "deepdiver_v2/config/.env"), **dotenv_values(ROOT / ".env"), **os.environ}
    def configured(name, fallback):
        path = Path(values.get(name) or fallback)
        return path if path.is_absolute() else ROOT / path
    owner_path = configured("SCIASSISTANT_TASK_OWNER_STATE_PATH", ROOT / "logs/science_task_owners.json")
    state_root = configured("SCIASSISTANT_TASK_STATE_DIR", ROOT / "logs/task_state")
    snapshot = state_root / f"{task_id}.json"
    source_run = configured("SCIASSISTANT_MULTI_AGENT_WEB_RUN_ROOT", ROOT / "logs/multi_agent_web_runs") / task_id
    owners = json.loads(owner_path.read_text(encoding="utf-8-sig"))
    owner_id = str(owners.get(task_id) or "")
    if not owner_id or owner_id == other_user_id:
        raise ValueError("owner precondition")
    task = json.loads(snapshot.read_text(encoding="utf-8-sig"))
    if task.get("id") != task_id or task.get("processing_mode") not in {"multi_agent_rag", "multi_agent_pdf"} or task.get("status") not in {"completed", "partial", "needs_review"}:
        raise ValueError("terminal RAG task required")
    original = (digest(owner_path), digest(snapshot))
    with tempfile.TemporaryDirectory(prefix="sciassistant-web-readonly-") as temporary:
        directory = Path(temporary)
        (directory / "state").mkdir()
        (directory / "runs").mkdir()
        bundle_hashes = copy_report_bundle(source_run, directory / "runs" / task_id)
        shutil.copyfile(snapshot, directory / "state" / snapshot.name)
        shutil.copyfile(owner_path, directory / "owners.json")
        os.environ.update(SCIASSISTANT_TASK_STATE_DIR=str(directory / "state"),
                          SCIASSISTANT_TASK_OWNER_STATE_PATH=str(directory / "owners.json"),
                          SCIASSISTANT_CONTEXT_FILE_OWNER_STATE_PATH=str(directory / "context-owners.json"),
                          SCIASSISTANT_PDF_SESSION_STATE_PATH=str(directory / "pdf-sessions.sqlite3"),
                          SCIASSISTANT_MULTI_AGENT_WEB_RUN_ROOT=str(directory / "runs"),
                          SCIASSISTANT_MULTI_AGENT_WEB_STORAGE_ROOT=str(directory / "rag"),
                          MODEL_KEY_POOL_STATE_PATH=str(directory / "key-pool.sqlite3"),
                          SCIASSISTANT_WEB_BASE="")
        # First application import occurs only after temporary state isolation.
        import app as account
        # This process is only a local probe. Never print routine access logs
        # mixed into the machine-readable summary; normal warnings remain.
        logging.disable(logging.INFO)
        from werkzeug.serving import make_server
        import requests
        versions = {uid: account._current_auth_version(uid) for uid in (owner_id, other_user_id)}
        if any(version is None for version in versions.values()):
            raise ValueError("existing accounts required")
        credentials = {"owner": {"Authorization": "Bearer " + account.generate_token(owner_id, "local-check", versions[owner_id])},
                       "other": {"Authorization": "Bearer " + account.generate_token(other_user_id, "local-check", versions[other_user_id])},
                       "anonymous": {}}
        server = make_server("127.0.0.1", 0, account.app)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        session = requests.Session()
        session.trust_env = False
        base = f"http://127.0.0.1:{server.server_port}"
        def get(path, identity="owner"):
            return session.get(base + path, headers=credentials[identity], timeout=15, allow_redirects=False)
        try:
            listing = get("/5000/api/science/tasks?mode=" + task["processing_mode"]).json()
            checks = {"owned_api_only_task_discovered": task_id in {row["id"] for row in listing.get("tasks") or []},
                      "other_list_has_no_task": task_id not in {row["id"] for row in get("/5000/api/science/tasks", "other").json().get("tasks") or []},
                      "anonymous_list_401": get("/5000/api/science/tasks", "anonymous").status_code == 401}
            prefix = f"/5000/api/science/tasks/{task_id}"
            report_response = get(prefix + "/report")
            report = report_response.json() if report_response.status_code == 200 else {}
            refs = report.get("references") or []
            paths = [prefix, prefix + "/report"] + [prefix + f"/report/export?format={fmt}" for fmt in ("html", "md", "json")]
            paths += [prefix + f"/evidence?format={fmt}" for fmt in ("md", "json")]
            asset_checks = {}
            for field in ("pdf_asset", "page_image_asset"):
                assets = sorted({row[field] for row in refs if row.get(field)})
                checks[field + "_available"] = bool(assets)
                for item in assets:
                    path = prefix + "/report/assets/" + item
                    paths.append(path)
                    response = get(path)
                    expected = directory / "runs" / task_id / item
                    asset_checks[item] = response.status_code == 200 and hashlib.sha256(response.content).hexdigest() == digest(expected)
            matrix = {name: [get(path, name).status_code for path in paths] for name in credentials}
            exported = get(prefix + "/report/export?format=json").json()
            md = get(prefix + "/report/export?format=md").text
            html_report = html.unescape(get(prefix + "/report/export?format=html").text)
            approved = {row["evidence_id"] for row in refs}
            claims = report.get("claims") or []
            checks.update({"owner_resources_200": all(code == 200 for code in matrix["owner"]),
                           "other_resources_404": all(code == 404 for code in matrix["other"]),
                           "anonymous_resources_401": all(code == 401 for code in matrix["anonymous"]),
                           "internal_asset_404": get(prefix + "/report/assets/workflow.sqlite3").status_code == 404,
                           "assets_match_source_hashes": bool(asset_checks) and all(asset_checks.values()),
                           "published_claims_exist": bool(claims),
                           "claims_use_only_approved_references": all(row.get("evidence_ids") and set(row["evidence_ids"]).issubset(approved) for row in claims),
                           "exports_keep_claims_and_references": exported.get("claims") == claims and exported.get("references") == refs,
                           "md_html_keep_published_claim_text": all(row["text"] in md and row["text"] in html_report for row in claims),
                           "fresh_source_identity": get("/api/health").json().get("runtime", {}).get("code_on_disk_matches_startup") is True,
                           "model_call_count_unchanged": report.get("execution", {}).get("model_calls") == task.get("execution", {}).get("model_calls"),
                           "original_state_unchanged": original == (digest(owner_path), digest(snapshot)),
                           "original_run_unchanged": bundle_unchanged(source_run, bundle_hashes)})
            return {"schema": "sciassistant.web-readonly-check/v1", "passed": all(checks.values()),
                    "checks": checks, "resource_matrix": matrix, "reference_count": len(refs),
                    "resource_paths": paths, "asset_hash_checks": asset_checks, "published_claim_count": len(claims),
                    "model_calls_added": 0, "temporary_instance": True, "browser_test": False,
                    "auth_check": "server-issued-test-jwt-with-real-database-auth-version-not-login-ui"}
        finally:
            session.close(); server.shutdown(); thread.join(timeout=5); server.server_close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task-id", required=True)
    parser.add_argument("--other-user-id", required=True)
    args = parser.parse_args()
    if not re.fullmatch(r"[0-9a-f]{12}", args.task_id) or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", args.other_user_id):
        parser.error("invalid task/account identifier")
    try:
        result = check(args.task_id, args.other_user_id)
    except Exception as exc:
        result = {"schema": "sciassistant.web-readonly-check/v1", "passed": False,
                  "error": "READONLY_CHECK_FAILED", "exception_type": type(exc).__name__}
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
