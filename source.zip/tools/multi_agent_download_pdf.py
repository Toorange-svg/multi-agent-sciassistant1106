"""Internal arXiv-only download worker; bounded by its parent process.

Never prints exception text, credentials, provider replies or filesystem paths.
"""
from pathlib import Path
import json
import re
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    try:
        paper_id, destination, budget_text = argv
        budget = float(budget_text)
        if not re.fullmatch(r"(?:\d{4}\.\d{4,5}|[a-z-]+(?:\.[A-Z]{2})?/\d{7})(?:v[1-9]\d*)?", paper_id):
            raise ValueError("invalid paper id")
        if not 0 < budget <= 30:
            raise ValueError("invalid download budget")
    except (ValueError, TypeError):
        print(json.dumps({"status": "failed", "error_code": "PDF_DOWNLOAD_INPUT_INVALID"}))
        return 2
    import requests
    from deepdiver_v2.src.literature_sources import SourceDeadlineExceeded
    from multi_agent_live import LiveArxivRagExecutor
    from multi_agent_rag import RagError
    worker = object.__new__(LiveArxivRagExecutor)
    worker.retrieval_deadline = time.monotonic() + budget
    try:
        worker._download_http(paper_id, Path(destination))
        result = {"status": "completed"}
        exitcode = 0
    except SourceDeadlineExceeded:
        result = {"status": "failed", "error_code": "SOURCE_WAIT_BUDGET_EXCEEDED"}
        exitcode = 1
    except (TimeoutError, requests.Timeout):
        result = {"status": "failed", "error_code": "PDF_DOWNLOAD_DEADLINE"}
        exitcode = 1
    except requests.HTTPError as exc:
        result = {"status": "failed", "error_code": "SOURCE_HTTP_ERROR",
                  "http_status": getattr(exc.response, "status_code", None)}
        exitcode = 1
    except requests.ConnectionError:
        result = {"status": "failed", "error_code": "SOURCE_UNREACHABLE"}
        exitcode = 1
    except RagError as exc:
        code = str(exc)
        result = {"status": "failed", "error_code": code if code in {
            "PDF_INCOMPLETE", "PDF_SIZE_LIMIT"} else "PDF_DOWNLOAD_WORKER_FAILED"}
        exitcode = 1
    except Exception:
        result = {"status": "failed", "error_code": "PDF_DOWNLOAD_WORKER_FAILED"}
        exitcode = 1
    result["attempts"] = getattr(worker, "pdf_download_attempts", [])
    print(json.dumps(result))
    return exitcode


if __name__ == "__main__":
    raise SystemExit(main())
