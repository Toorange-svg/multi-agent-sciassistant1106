import pathlib
f = pathlib.Path(r"C:\Users\tomatoorange\Desktop\SciAssistant_v1.0.0\deepdiver_v2\src\arxiv_query.py")
lines = f.read_text(encoding="utf-8").splitlines()
# 第33行(0-idx 32)是 if re.search(...boolean...): 下一行是 return False
# 在 return False 后插入非 ASCII 检查
# 找 "boolean_expression_inside_quote" 行
for i, l in enumerate(lines):
    if "boolean_expression_inside_quote" in l:
        indent = "    "
        new_lines = [
            indent + "# Chinese full-width brackets/parens leaked into a quoted phrase make",
            indent + "# the arXiv match useless (e.g. ti:\"attention）\"). Reject so repair runs.",
            indent + "if re.search(r\"[^\\x00-\\x7F]\", quoted):",
            indent + "    return False, \"non_ascii_in_quoted_phrase\"",
        ]
        lines[i+1:i+1] = new_lines
        break
f.write_text("\n".join(lines) + "\n", encoding="utf-8")
print("OK")
