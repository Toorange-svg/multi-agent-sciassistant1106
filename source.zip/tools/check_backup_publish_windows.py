"""Check publication against real Windows locks in disposable fixture directories.

No account data, database connection, provider key or running service is read.
Outputs only check names/codes/timings, never temporary paths or exceptions.
"""
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
import time
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tools import account_backup as backup


def run():
    if os.name != 'nt':
        return {'passed': False, 'executed': False, 'reason': 'WINDOWS_REQUIRED'}
    import ctypes
    from ctypes import wintypes
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
        wintypes.LPVOID, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
    kernel.CreateFileW.restype = wintypes.HANDLE
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel.CloseHandle.restype = wintypes.BOOL
    invalid = ctypes.c_void_p(-1).value
    native_rename = os.rename
    checks, details = {}, {}
    # These are newly created canaries, not the application's backup storage.
    with tempfile.TemporaryDirectory(prefix='sciassistant-publish-lock-check-') as directory:
        root = Path(directory).resolve()
        for case in ('transient', 'persistent'):
            staged, target = root / (case + '-stage'), root / (case + '-target')
            staged.mkdir()
            (staged / 'canary.txt').write_text('disposable-check-only', encoding='utf8')
            # Open a directory without FILE_SHARE_DELETE. No ACL is modified.
            handle = kernel.CreateFileW(str(staged), 0x80000000, 0x1 | 0x2,
                None, 3, 0x02000000, None)
            if handle == invalid:
                return {'passed': False, 'executed': True, 'reason': 'LOCK_FIXTURE_UNAVAILABLE',
                    'winerror': ctypes.get_last_error()}
            held, mutex, attempts = [True], threading.Lock(), []
            def release():
                with mutex:
                    if held[0]:
                        kernel.CloseHandle(handle)
                        held[0] = False
            def rename(source, destination):
                try:
                    native_rename(source, destination)
                except OSError as exc:
                    attempts.append(getattr(exc, 'winerror', None))
                    raise
                attempts.append(0)
            timer = threading.Timer(0.075, release) if case == 'transient' else None
            started = time.monotonic()
            error_code = None
            try:
                if timer:
                    timer.start()
                with patch.object(backup.os, 'rename', rename):
                    backup._publish_staged_directory(staged, target, 'output_target_invalid')
            except backup.BackupError as exc:
                error_code = exc.code
            finally:
                if timer:
                    timer.join()
                release()
            details[case] = {'attempt_winerrors': attempts, 'error_code': error_code,
                'elapsed_seconds': round(time.monotonic()-started, 3)}
            if case == 'transient':
                checks[case] = (error_code is None and len(attempts) >= 2
                    and any(code in {5, 32, 33} for code in attempts[:-1])
                    and target.is_dir() and (target/'canary.txt').read_text(encoding='utf8') == 'disposable-check-only')
            else:
                checks[case] = (error_code == 'directory_publish_busy' and len(attempts) == 4
                    and not target.exists() and staged.is_dir())
        staged, target = root/'race-stage', root/'race-target'
        staged.mkdir()
        (staged/'source.txt').write_text('keep-source', encoding='utf8')
        def create_target_during_rename(source, destination):
            target.mkdir()
            return native_rename(source, destination)
        conflict = None
        try:
            with patch.object(backup.os, 'rename', create_target_during_rename):
                backup._publish_staged_directory(staged, target, 'output_target_invalid')
        except backup.BackupError as exc:
            conflict = exc.code
        checks['target_created_between_check_and_rename_not_overwritten'] = (
            conflict == 'output_target_invalid' and target.is_dir()
            and not (target/'source.txt').exists() and (staged/'source.txt').is_file())
    return {'schema_version': 'sciassistant.native-backup-publish-check/v1',
        'passed': all(checks.values()), 'executed': True, 'checks': checks, 'details': details,
        'provider_calls': 0, 'real_account_data_read': False, 'permissions_changed': False}


if __name__ == '__main__':
    try:
        report = run()
    except Exception as exc:
        report = {'passed': False, 'executed': True, 'reason': 'NATIVE_CHECK_FAILED',
            'exception_type': type(exc).__name__}
    print(json.dumps(report))
    raise SystemExit(0 if report['passed'] else 2)
