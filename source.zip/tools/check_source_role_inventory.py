"""Read-only literal source-role diagnosis; no model/network or republication."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def hashes(folder):
    return {str(p.relative_to(folder)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in folder.rglob('*') if p.is_file()}


def inspect(run):
    from multi_agent_agents import ArtifactDirectory
    from multi_agent_quality import (SOURCE_ROLE_INVENTORY_POLICY, source_role_inventory,
        check_printed_type_denials, citation_audit_input)
    before = hashes(run)
    manifest = json.loads((run/'manifest.json').read_text(encoding='utf-8-sig'))
    store = ArtifactDirectory(run/'artifacts')
    final = store.get(manifest['final_artifact_id'])
    refs = final['artifact_refs']
    original = store.get(refs['draft'])
    approved = store.get(refs['approved'])
    proposed = {**deepcopy(original), 'source_role_inventory_policy':SOURCE_ROLE_INVENTORY_POLICY}
    cards = source_role_inventory(approved)
    audit_input = citation_audit_input(proposed, approved)
    available = {r['evidence_id']:r for r in approved['evidence']}
    checks = {
        'exact_source_offsets':all(r['quote'] == available[r['evidence_id']][r['field']][r['start']:r['end']]
                                   for r in cards['records']),
        'no_automatic_approval':all(r['semantic_auto_approval'] is False for r in cards['records']),
        'bounded_input':len(cards['records']) <= 12,
        'claim_records_only_cited':all(r['evidence_id'] in c['evidence_ids']
            for c in audit_input['claims'] for r in c['source_role_records']),
        'source_hashes_unchanged':before == hashes(run),
    }
    return {'run_id':manifest['run_id'], 'historical_status':final['status'],
        'original_policy_findings':check_printed_type_denials(original, approved),
        'current_policy_diagnostic_findings':check_printed_type_denials(proposed, approved),
        'source_inventory':cards, 'checks':checks, 'source_files':len(before),
        'source_hashes_unchanged':checks['source_hashes_unchanged'],
        'historical_publication_rewritten':False,
        'scientific_quality_passed':False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-dir', type=Path, nargs='+', required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    runs, output = [p.resolve() for p in args.run_dir], args.output_dir.resolve()
    if any(not p.is_dir() or output.is_relative_to(p) or p.is_relative_to(output) for p in runs):
        parser.error('missing run or output overlaps source')
    output.mkdir(parents=True, exist_ok=False)
    rows = [inspect(run) for run in runs]
    result = {'schema_version':'sciassistant.source-role-diagnosis/v1','runs':rows,
        'model_calls':0,'network_requests':0,'automatic_scientific_approval':False,
        'passed':all(all(row['checks'].values()) for row in rows)}
    (output/'checks.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'passed':result['passed'],'runs':len(rows),
        'findings':[[{'claim_id':r['claim_id'],'field':r['field'],'reason':r['reason']}
                     for r in row['current_policy_diagnostic_findings']] for row in rows],
        'model_calls':0,'network_requests':0}))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
