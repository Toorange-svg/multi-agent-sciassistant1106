"""Real HTTP/MySQL tenant/key/UI check; loopback vendor fixture, zero fees."""
import argparse
import concurrent.futures
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import requests

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tools.check_research_web_flow import Server,request,register,wait_task
from tools.tenant_provider_fixture import FAKE_MODEL,FAKE_LLAMA


def run(args):
    root=ROOT/'logs/research_web_validation'/args.run_id
    root.mkdir(parents=True,exist_ok=False)
    server=Server(root,'mock');server.env['SCIASSISTANT_TENANT_PROBE']='1'
    result={'schema_version':'sciassistant.tenant-check/v1','checks':{},'actual_http':True,'actual_mysql':True,
            'vendor_responses_stubbed':True,'paid_model_calls':0,'production_5000_touched':False}
    checks=result['checks']
    def require(name,condition):
        checks[name]=bool(condition)
        if not condition:raise RuntimeError(name)
    try:
        server.start();accounts={label:register(server.base,'tenant_'+label) for label in ['a','b']}
        health=request(server.base,'GET','/api/health').json()['runtime']
        result['source_fingerprint']=health['source_fingerprint']
        require('source_complete',health.get('source_complete') is True)
        require('source_matches_startup',health.get('code_on_disk_matches_startup') is True)
        result['test_account_ids']={k:v['user_id'] for k,v in accounts.items()}
        require('anonymous_keys_401',request(server.base,'GET','/api/account/provider-keys').status_code==401)
        for label,account in accounts.items():
            status=request(server.base,'GET','/api/account/provider-keys',account['token'])
            require('new_'+label+'_no_shared_defaults',not status.json()['deepseek']['configured'] and not status.json()['llama']['configured'])
            denied=request(server.base,'POST','/api/science/tasks',account['token'],json={'query':'你好','processing_mode':'general_answer'})
            require('no_key_'+label+'_blocked_before_task',denied.status_code==400 and denied.json().get('error_code')=='USER_PROVIDER_KEY_REQUIRED')
            settings=request(server.base,'POST','/api/account/provider-keys',account['token'],json={'deepseek_keys':[FAKE_MODEL[label]],'llama_key':FAKE_LLAMA[label]})
            require('save_'+label+'_only_masked_status',settings.status_code==200 and FAKE_MODEL[label] not in settings.text and FAKE_LLAMA[label] not in settings.text)
        def model(label):
            account=accounts[label]
            response=request(server.base,'POST','/api/science/tasks',account['token'],json={'query':'你好','processing_mode':'general_answer'})
            if response.status_code!=202:raise RuntimeError('model task create')
            task=wait_task(server,account,response.json()['task']['id'],limit=30)
            return task
        with concurrent.futures.ThreadPoolExecutor(2) as pool:
            tasks=dict(zip(['a','b'],pool.map(model,['a','b'])))
        result['tasks']={k:{'id':v['id'],'status':v['status']} for k,v in tasks.items()}
        for label,task in tasks.items():
            require('actual_model_header_'+label,task['status']=='completed' and task['answer']=='TENANT_'+label)
            other=accounts['b' if label=='a' else 'a']
            require('private_task_'+label,request(server.base,'GET','/api/science/tasks/'+task['id'],other['token']).status_code==404)
            cloud=request(server.base,'POST','/_validation/llama-probe',accounts[label]['token'])
            require('actual_llama_header_'+label,cloud.status_code==200 and cloud.json().get('status')=='ok' and cloud.json().get('transcription')=='TENANT_'+label)
        # Real account-specific file upload/download; never delete user files.
        files={}
        for label,account in accounts.items():
            import pymupdf
            doc=pymupdf.open();page=doc.new_page();page.insert_text((50,50),'TENANT_'+label);data=doc.tobytes();doc.close()
            uploaded=request(server.base,'POST','/api/research-library/upload',account['token'],files={'files':('tenant-'+label+'.pdf',data,'application/pdf')})
            require('upload_'+label,uploaded.status_code==200);fid=uploaded.json()['files'][0]['file_id'];files[label]=fid
            own=request(server.base,'GET','/api/files/download/'+fid,account['token'])
            other=accounts['b' if label=='a' else 'a']
            require('file_'+label+'_private',own.status_code==200 and own.content==data and request(server.base,'GET','/api/files/download/'+fid,other['token']).status_code==404)
        for label,account in accounts.items():
            listed=request(server.base,'GET','/api/research-library/files',account['token']).json()['files']
            require('list_'+label+'_only_own',len(listed)==1 and listed[0]['id']==files[label])
        clear=request(server.base,'POST','/api/account/provider-keys',accounts['a']['token'],json={'clear':['deepseek','llama']})
        require('clear_a_only',clear.status_code==200 and not clear.json()['deepseek']['configured'] and request(server.base,'GET','/api/account/provider-keys',accounts['b']['token']).json()['deepseek']['configured'])
        require('clear_a_no_fallback',request(server.base,'POST','/api/science/tasks',accounts['a']['token'],json={'query':'你好','processing_mode':'general_answer'}).status_code==400)
        cloud=request(server.base,'POST','/_validation/llama-probe',accounts['a']['token']).json()
        require('clear_llama_no_fallback',cloud.get('status')=='skipped')
        if args.browser:
            payload={'base_url':server.base,'output_directory':str(root),'username':accounts['a']['username'],
                     'password':accounts['a']['password'],'other_token':accounts['b']['token'],
                     'model_key':FAKE_MODEL['a'],'llama_key':FAKE_LLAMA['a']}
            node_env = os.environ.copy()
            bundled_modules = Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules'
            if bundled_modules.is_dir():
                node_env.setdefault('NODE_PATH', str(bundled_modules))
            browser=subprocess.run(['node',str(ROOT/'tools/check_user_isolation_browser.cjs')],input=json.dumps(payload),
                text=True,encoding='utf8',capture_output=True,timeout=120,env=node_env)
            require('browser_exit',browser.returncode==0)
            result['browser']=json.loads((root/'tenant_browser_checks.json').read_text())
        with requests.Session() as probe_client:
            probe_client.trust_env=False
            probes=probe_client.get(server.base+'/_validation/tenant-probe',headers={'X-Validation-Capability':server.env['SCIASSISTANT_VALIDATION_SIGNING_KEY']},timeout=10,allow_redirects=False)
        result['provider_attempts']=probes.json()['attempts']
        require('no_unknown_or_shared_keys',all(x['owner'] in {'a','b'} for x in result['provider_attempts']))
        require('both_model_and_llama_scopes_observed',all(any(x['owner']==label and x['kind']==kind for x in result['provider_attempts']) for label in ['a','b'] for kind in ['model','llama']))
        # Fixture restart retains encrypted keys and owned files, not a shared default.
        server.stop();server.start()
        require('restart_b_keys_private',request(server.base,'GET','/api/account/provider-keys',accounts['b']['token']).json()['deepseek']['configured'])
        require('restart_private_files',request(server.base,'GET','/api/files/download/'+files['a'],accounts['b']['token']).status_code==404)
        current=request(server.base,'GET','/api/health').json()['runtime']
        require('same_frozen_source_after_restart',current['source_fingerprint']==result['source_fingerprint'] and current['code_on_disk_matches_startup'] is True)
        result['passed']=all(checks.values())
    except Exception as exc:
        result.update(passed=False,error_type=type(exc).__name__,failed_check=next((k for k,v in checks.items() if not v),None))
    finally:
        server.stop()
        (root/'tenant_result.json').write_text(json.dumps(result,indent=2),encoding='utf8')
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run-id',required=True);parser.add_argument('--browser',action='store_true');args=parser.parse_args()
    if not re.fullmatch('[a-z0-9-]{1,80}',args.run_id):parser.error('invalid run-id')
    result=run(args);print(json.dumps(result));raise SystemExit(0 if result['passed'] else 1)
