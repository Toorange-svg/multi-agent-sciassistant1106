"""Zero-model/network diagnostics on preserved source runs; never republish."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))


def tree_sha(path):
    return {str(p.relative_to(path)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in path.rglob('*') if p.is_file()}


def inspect(path):
    from multi_agent_agents import ArtifactDirectory
    from multi_agent_quality import PASSAGE_EXCLUSIVITY_POLICY, check_passage_exclusivity
    before = tree_sha(path)
    manifest = json.loads((path/'manifest.json').read_text(encoding='utf-8-sig'))
    store = ArtifactDirectory(path/'artifacts')
    final = store.get(manifest['final_artifact_id'])
    refs = final.get('artifact_refs',{})
    draft = store.get(refs['draft'])
    approved = store.get(refs['approved'])
    proposed = {**deepcopy(draft),'passage_exclusivity_policy':PASSAGE_EXCLUSIVITY_POLICY}
    return {'run_id':manifest['run_id'],'recorded_status':final['status'],
        'recorded_answer_sha256':hashlib.sha256((path/'final_answer.md').read_bytes()).hexdigest(),
        'historical_policy_findings':check_passage_exclusivity(draft,approved),
        'current_policy_diagnosis_only':check_passage_exclusivity(proposed,approved),
        'source_files':len(before),'source_hashes_unchanged':before==tree_sha(path),
        'automatic_rewrite':False,'automatic_publication':False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-dir',nargs='+',type=Path,required=True)
    parser.add_argument('--output-dir',type=Path,required=True)
    args = parser.parse_args()
    paths = [p.resolve() for p in args.run_dir]
    output = args.output_dir.resolve()
    if any(not p.is_dir() or output.is_relative_to(p) or p.is_relative_to(output) for p in paths):
        parser.error('missing source or output overlaps source')
    output.mkdir(parents=True,exist_ok=False)
    rows = [inspect(p) for p in paths]
    data = {'schema_version':'sciassistant.answer-relevance-diagnosis/v1','runs':rows,
        'model_calls':0,'network_calls':0,'semantic_auto_approval':False,
        'passed':all(row['source_hashes_unchanged'] for row in rows)}
    (output/'checks.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'passed':data['passed'],'findings':[
        {'run_id':r['run_id'],'fields':[(i['claim_id'],i['field'],i['reason'])
            for i in r['current_policy_diagnosis_only']]} for r in rows]},ensure_ascii=True))
    return 0 if data['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
