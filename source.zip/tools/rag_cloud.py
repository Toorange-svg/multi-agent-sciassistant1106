"""CPU-only Linux RAG extension lock: structural, wheel and installed gates.

No network, environment values, model/API credentials, or application state.
The generator hashes the already-downloaded Linux wheels; it never changes the
independently pinned base cloud dependency set.
"""
from __future__ import annotations

import argparse
from email.parser import BytesParser
import hashlib
from importlib import metadata
import json
from pathlib import Path
import platform
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tools.dependency_lock import parse_constraints, parse_hash_requirements, canonical_name, BASE_ALLOWLIST
from packaging.requirements import Requirement
from packaging.specifiers import SpecifierSet
from packaging.tags import compatible_tags, cpython_tags
from packaging.utils import parse_wheel_filename

SCHEMA = "sciassistant.rag-cloud-lock/v1"
INPUT = "deepdiver_v2/requirements.rag.cloud.txt"
PINS = "deepdiver_v2/constraints.rag.cloud.txt"
HASHES = "deepdiver_v2/requirements.rag.cloud.hashes.txt"
ARTIFACTS = "deepdiver_v2/rag.cloud.artifacts.json"
LINUX = ["manylinux_2_28_x86_64", "manylinux_2_27_x86_64", "manylinux2014_x86_64",
         "manylinux_2_17_x86_64", "linux_x86_64"]
TAGS = set(cpython_tags((3, 11), abis=["cp311"], platforms=LINUX)) | set(compatible_tags((3, 11), interpreter="cp311", platforms=LINUX))
ENVIRONMENT = {"python_version": "3.11", "python_full_version": "3.11.17", "sys_platform": "linux",
               "platform_system": "Linux", "platform_machine": "x86_64", "os_name": "posix",
               "implementation_name": "cpython", "platform_python_implementation": "CPython",
               "platform_release": "", "platform_version": "", "extra": ""}


def digest(path):
    hasher = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            hasher.update(block)
    return hasher.hexdigest()


def wheel_record(path):
    name, version, _, tags = parse_wheel_filename(path.name)
    if not tags.intersection(TAGS) or path.is_symlink():
        raise ValueError("wheel target rejected")
    with zipfile.ZipFile(path) as archive:
        entries = [item for item in archive.infolist() if item.filename.endswith(".dist-info/METADATA")
                   and len(Path(item.filename).parts) == 2]
        if len(entries) != 1 or entries[0].file_size > 2_000_000:
            raise ValueError("invalid wheel metadata")
        information = BytesParser().parsebytes(archive.read(entries[0]))
    if canonical_name(information["Name"]) != name or information["Version"] != str(version):
        raise ValueError("wheel name mismatch")
    required_python = information.get("Requires-Python") or ""
    if required_python and not SpecifierSet(required_python).contains("3.11.17"):
        raise ValueError("Python 3.11 not supported")
    return {"name": name, "version": str(version), "filename": path.name, "sha256": digest(path),
            "requires_python": required_python, "requires_dist": information.get_all("Requires-Dist") or [],
            "license": str(information.get("License-Expression") or information.get("License") or "See distribution license files")[:600]}


def generate(root, wheel_dir):
    root, wheel_dir = Path(root), Path(wheel_dir)
    pins, errors = parse_constraints(root / PINS)
    base, base_errors = parse_constraints(root / "deepdiver_v2/constraints.cloud.txt")
    if errors or base_errors or set(pins).intersection(base):
        raise ValueError("extension must not replace base pins")
    if (root / HASHES).exists() or (root / ARTIFACTS).exists():
        raise ValueError("generated lock already exists")
    records = {}
    for path in wheel_dir.glob("*.whl"):
        row = wheel_record(path)
        if row["name"] not in pins:
            continue
        if row["name"] in records or row["version"] != pins[row["name"]]:
            raise ValueError("ambiguous wheel selection")
        records[row["name"]] = row
    if set(records) != set(pins):
        raise ValueError("incomplete wheel set")
    lines = [f"{name}=={pins[name]} --hash=sha256:{records[name]['sha256']}" for name in sorted(records)]
    # Mechanical generated artifacts, not a manual rewrite of existing locks.
    (root / HASHES).write_text("# Linux/amd64 CPython 3.11; CPU only; one audited wheel per pin.\n" + "\n".join(lines) + "\n", encoding="utf-8")
    (root / ARTIFACTS).write_text(json.dumps({"schema": SCHEMA, "platform": "linux/amd64", "python": "3.11",
        "artifacts": [records[name] for name in sorted(records)]}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return check(root)


def check(root):
    root = Path(root)
    checks = []
    def record(name, passed):
        checks.append({"check": name, "passed": bool(passed)})
    pins, errors = parse_constraints(root / PINS)
    hashes, hash_errors = parse_hash_requirements(root / HASHES)
    base, base_errors = parse_constraints(root / "deepdiver_v2/constraints.cloud.txt")
    requested, input_errors = parse_constraints(root / INPUT)
    record("strict_sorted_pins", not errors and not input_errors and not base_errors)
    record("strict_one_hash_per_pin", not hash_errors and {key: value[0] for key, value in hashes.items()} == pins)
    record("base_versions_unchanged", not set(pins).intersection(base))
    record("required_roots_locked", set(requested) == {"qdrant-client", "sentence-transformers", "torch"}
           and all(pins.get(name) == version for name, version in requested.items()))
    record("cpu_torch_only", pins.get("torch", "").endswith("+cpu") and not any(name.startswith("nvidia-") or name == "triton" for name in pins))
    artifact = json.loads((root / ARTIFACTS).read_text(encoding="utf-8"))
    rows = artifact["artifacts"]
    record("target_platform", artifact.get("schema") == SCHEMA and artifact.get("platform") == "linux/amd64" and artifact.get("python") == "3.11")
    record("artifact_set_exact", len(rows) == len(pins) and {row["name"] for row in rows} == set(pins))
    versions = {**base, **pins}
    graph_valid = True
    for row in rows:
        name, version, _, tags = parse_wheel_filename(row["filename"])
        record("artifact:" + row["name"], name == row["name"] and str(version) == pins.get(name)
               and row["sha256"] == hashes.get(name, (None, None))[1] and bool(tags.intersection(TAGS))
               and (not row["requires_python"] or SpecifierSet(row["requires_python"]).contains("3.11.17")))
        for text in row["requires_dist"]:
            requirement = Requirement(text)
            if requirement.marker and not requirement.marker.evaluate(ENVIRONMENT):
                continue
            target = canonical_name(requirement.name)
            if requirement.url or target not in versions or not requirement.specifier.contains(versions[target]):
                graph_valid = False
    record("linux_dependency_edges", graph_valid)
    return {"schema": SCHEMA, "passed": all(item["passed"] for item in checks), "checks": checks,
            "base_package_count": len(base), "rag_package_count": len(pins), "total_package_count": len(versions),
            "sha256": digest(root / HASHES), "base_sha256": digest(root / "deepdiver_v2/requirements.cloud.hashes.txt")}


def verify_installed(root, output):
    result = check(root)
    base, _ = parse_constraints(Path(root) / "deepdiver_v2/constraints.cloud.txt")
    extra, _ = parse_constraints(Path(root) / PINS)
    expected = {**base, **extra}
    installed = {canonical_name(dist.metadata["Name"]): dist.version for dist in metadata.distributions() if dist.metadata["Name"]}
    result["checks"].append({"check": "linux_python311_runtime", "passed": sys.platform.startswith("linux") and sys.version_info[:2] == (3, 11) and platform.machine() in {"x86_64", "AMD64"}})
    result["checks"].append({"check": "all_versions_exact", "passed": all(installed.get(name) == version for name, version in expected.items())})
    result["checks"].append({"check": "no_unlocked_runtime_packages", "passed": not (set(installed) - set(expected) - BASE_ALLOWLIST)})
    result["passed"] = all(item["passed"] for item in result["checks"])
    if result["passed"]:
        Path(output).write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["generate", "check", "verify-installed"])
    parser.add_argument("--root", default=str(ROOT))
    parser.add_argument("--wheel-dir")
    parser.add_argument("--output", default=".rag-dependency-lock.json")
    args = parser.parse_args()
    try:
        result = generate(args.root, args.wheel_dir) if args.command == "generate" else (verify_installed(args.root, args.output) if args.command == "verify-installed" else check(args.root))
        print(json.dumps(result, ensure_ascii=False))
        return 0 if result["passed"] else 2
    except Exception:
        print(json.dumps({"schema": SCHEMA, "passed": False, "error": "RAG_DEPENDENCY_LOCK_INVALID"}))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
