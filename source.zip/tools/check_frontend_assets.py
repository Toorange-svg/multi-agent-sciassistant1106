"""Offline static release gate. Never imports Flask, opens a DB or calls a provider."""
from pathlib import Path
from html.parser import HTMLParser
import hashlib
import json
import re
from urllib.parse import urlsplit, unquote

ROOT = Path(__file__).resolve().parents[1]


class Resources(HTMLParser):
    def __init__(self):
        super().__init__(); self.urls = []; self.runtime_compiler = False

    def handle_starttag(self, tag, attrs):
        fields = dict(attrs)
        if tag == 'script' and fields.get('type') == 'text/tailwindcss':
            self.runtime_compiler = True
        if tag == 'style' and fields.get('type') == 'text/tailwindcss':
            self.runtime_compiler = True
        if tag == 'script' and fields.get('src'):
            self.urls.append(fields['src'])
        if tag == 'link' and fields.get('rel') == 'stylesheet':
            self.urls.append(fields.get('href', ''))


def check(root=ROOT, runtime_only=False):
    root = Path(root).resolve()
    checks = {}; issues = []
    manifest = json.loads((root / 'chatAi/assets/manifest.json').read_text(encoding='utf8'))
    checks['schema'] = manifest.get('schema_version') == 'sciassistant.frontend-assets/v1'
    if not runtime_only:
        checks['lock'] = hashlib.sha256((root/'frontend/package-lock.json').read_bytes()).hexdigest() == manifest['lock_sha256']
    for row in manifest['files']:
        path = root / 'chatAi' / row['path']
        if (not path.resolve().is_relative_to(root/'chatAi') or path.is_symlink()
                or not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != row['sha256']):
            issues.append('ASSET_HASH:' + row['path'])
    checks['asset_hashes'] = not issues
    for name in ['ai_chat.html', 'login.html', 'register.html', 'forgot-password.html']:
        source = (root / 'chatAi' / name).read_text(encoding='utf8')
        parser = Resources(); parser.feed(source)
        if parser.runtime_compiler or re.search(r'cdn\.tailwindcss\.com|tailwind\.config', source):
            issues.append('RUNTIME_COMPILER:' + name)
        for url in parser.urls:
            parsed = urlsplit(url)
            if parsed.scheme or parsed.netloc or not parsed.path.startswith('/chatAi/'):
                issues.append('REMOTE_ASSET:' + name)
                continue
            path = root / unquote(parsed.path).lstrip('/')
            if not path.resolve().is_relative_to(root/'chatAi') or not path.is_file():
                issues.append('MISSING_RESOURCE:' + name)
            elif parsed.query != 'v=' + hashlib.sha256(path.read_bytes()).hexdigest()[:12]:
                issues.append('STALE_VERSION:' + name + ':' + parsed.path)
    checks['all_four_pages_self_hosted_and_versioned'] = not any(i.startswith(('REMOTE','MISSING','STALE','RUNTIME')) for i in issues)
    for path in (root/'chatAi').rglob('*.css'):
        for raw in re.findall(r'url\(\s*[\'"]?([^\)\'"\s]+)', path.read_text(encoding='utf8')):
            url = urlsplit(raw)
            if url.scheme == 'data':
                continue
            if url.scheme or url.netloc:
                issues.append('EXTERNAL_CSS_RESOURCE:' + path.name)
            elif url.path and not (path.parent / unquote(url.path)).is_file():
                issues.append('MISSING_CSS_RESOURCE:' + path.name)
    checks['all_css_fonts_local_and_present'] = not any(i.startswith(('EXTERNAL_CSS','MISSING_CSS')) for i in issues)
    css = (root/'chatAi/assets/tailwind.css').read_text(encoding='utf8')
    checks['critical_utilities'] = all(selector in css for selector in
        ['.hidden{', '.flex{', '.grid{', '.bg-primary{', '.text-primary{', '.ring-indigo-500{', '.justify-end{'])
    checks['no_generated_dependency_tree'] = not (root/'frontend/node_modules').exists()
    if not runtime_only:
        checks['container_assets_allowed'] = all(all(rule in (root/name).read_text(encoding='utf8') for rule in
            ['!chatAi/assets/**', '!chatAi/vendor/**', '!chatAi/assets/manifest.json']) for name in
            ['Dockerfile.account.cloud.dockerignore', 'Dockerfile.cloud.dockerignore'])
    return {'passed': all(checks.values()) and not issues, 'checks': checks, 'issues': issues,
            'asset_files': len(manifest['files']), 'bytes': sum(row['bytes'] for row in manifest['files']),
            'external_runtime_assets': 0, 'paid_calls': 0}


if __name__ == '__main__':
    report = check(); print(json.dumps(report)); raise SystemExit(0 if report['passed'] else 1)
