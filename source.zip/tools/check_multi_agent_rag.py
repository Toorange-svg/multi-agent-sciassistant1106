"""Small offline check of real CPU embeddings and persistent local Qdrant.

Uses synthetic passages, not an answering model or public literature requests.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import uuid

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from multi_agent_rag import (DEFAULT_EMBEDDING_MODEL, EvidenceStore, HybridRetriever,
                             LexicalReranker, LocalSentenceTransformerEmbedding,
                             QdrantVectorStore, RagIndexer)


class CountingEmbedding:
    def __init__(self, provider):
        self.provider = provider
        self.model_name = provider.model_name
        self.dimension = provider.dimension
        self.revision = getattr(provider, "revision", "")
        self.document_calls = 0

    def embed(self, texts):
        self.document_calls += 1
        return self.provider.embed(texts)

    def embed_query(self, query):
        return self.provider.embed_query(query)


def check_retrieval(output: Path, provider, vector_factory, *, test_recovery=False) -> dict:
    """Fresh output directory; injection exists only for fast unit checks."""
    output.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    embedding = CountingEmbedding(provider)
    store = EvidenceStore(output / "evidence.sqlite3")
    summary = {"schema_version": "sciassistant.rag-self-check/v1", "status": "running",
               "fixture": "synthetic-not-scientific-evidence", "model": Path(provider.model_name).name,
               "dimension": provider.dimension, "answer_model_calls": 0, "public_literature_requests": 0,
               "checks": {}}
    vector = None

    def record(name, passed):
        summary["checks"][name] = bool(passed)
        (output / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
        if not passed:
            raise ValueError("RAG check did not meet its assertion")

    texts = {
        "memory": "The serving engine stores attention keys and values in fixed-size pages. Sharing cached blocks between requests and allocating pages on demand reduces GPU memory fragmentation and wasted storage.",
        "draft": "Speculative decoding proposes candidate tokens with a small draft language model. A larger model verifies the draft to accelerate text generation while preserving the target output distribution.",
        "garden": "A gardener waters orange trees and grows vegetables. Fruit ripens in sunny weather. Soil nutrition and seasonal rainfall affect the harvest.",
    }
    metadata = {key: {"document_id": key, "paper_id": f"fixture-{key}", "title": f"Synthetic {key}",
                      "content_hash": hashlib.sha256(text.encode()).hexdigest()} for key, text in texts.items()}
    blocks = {key: [{"text": text, "page": 1, "section": "Synthetic fixture", "bbox": [20, 40, 500, 100]}]
              for key, text in texts.items()}
    try:
        vector = vector_factory(output / "qdrant", embedding.dimension)
        indexer = RagIndexer(store, embedding, vector, vector_required=True)
        for key in texts:
            result = indexer.index(metadata[key], blocks[key])
            record(f"index_{key}", result["changed"] and result["vector_indexed"])
        count_before = embedding.document_calls
        cached = indexer.index(metadata["memory"], blocks["memory"])
        record("unchanged_document_skips_embedding", not cached["changed"] and embedding.document_calls == count_before)

        lexical = store.lexical_search("GPU memory fragmentation")
        record("fts_keyword_recall", bool(lexical) and lexical[0][0].startswith("memory-"))
        semantic_query = "如何减少显存碎片并让多个请求共享注意力的键值缓存？"
        record("semantic_query_has_no_fts_match", not store.lexical_search(semantic_query))
        ranking = vector.search(embedding.embed_query(semantic_query), limit=3)
        record("cross_language_vector_recall", bool(ranking) and ranking[0][0].startswith("memory-"))
        retriever = HybridRetriever(store, embedding, vector, vector_required=True, reranker=LexicalReranker())
        packets = retriever.search("GPU memory fragmentation", document_ids={"memory"}, limit=3)
        record("hybrid_scope_and_locator", bool(packets) and all(
            packet["document_id"] == "memory" and packet["retrieval"]["lexical_used"]
            and packet["retrieval"]["vector_used"] and packet["locator"]["page"] == 1
            and packet["locator"]["bbox"] == [20, 40, 500, 100] for packet in packets))

        vector.close()
        vector = None
        vector = vector_factory(output / "qdrant", embedding.dimension)
        reopened = vector.search(embedding.embed_query(semantic_query), limit=3)
        record("vector_persists_after_reopen", bool(reopened) and reopened[0][0] == ranking[0][0])
        indexer = RagIndexer(store, embedding, vector, vector_required=True)
        count_before = embedding.document_calls
        cached = indexer.index(metadata["memory"], blocks["memory"])
        record("reopened_cache_skips_embedding", not cached["changed"] and embedding.document_calls == count_before)
        if test_recovery:
            # Simulate losing only the vector records, not the FTS/document cache.
            vector.delete_document("memory")
            repaired = indexer.index(metadata["memory"], blocks["memory"])
            record("missing_vector_rebuilds_from_cached_document", repaired["changed"]
                   and repaired.get("repair_reason") == "VECTOR_INDEX_MISSING_OR_INCOMPLETE"
                   and embedding.document_calls == count_before + 1)
            recovered = vector.search(embedding.embed_query(semantic_query), limit=3, document_ids={"memory"})
            record("repaired_vector_recall", bool(recovered) and recovered[0][0].startswith("memory-"))
            count_before = embedding.document_calls
        before_hash = store.document_hash("memory")
        updated = [{**blocks["memory"][0], "text": texts["memory"] + " This is an updated synthetic passage."}]
        rebuilt = indexer.index({**metadata["memory"], "content_hash": "fixture-update"}, updated)
        record("content_change_rebuilds", rebuilt["changed"] and rebuilt["vector_indexed"]
               and embedding.document_calls == count_before + 1 and store.document_hash("memory") != before_hash)
        indexer.delete_document("garden")
        record("delete_clears_fts_and_vector", not store.lexical_search("gardener", document_ids={"garden"})
               and not vector.search(embedding.embed_query("garden"), limit=3, document_ids={"garden"}))
        summary["status"] = "passed"
    except Exception:
        summary["status"] = "failed"
        summary["error_code"] = "RAG_SELF_CHECK_FAILED"
    finally:
        if vector is not None:
            vector.close()
        summary["elapsed_seconds"] = round(time.monotonic() - started, 3)
        (output / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default=f"logs/rag_checks/check-{uuid.uuid4().hex[:12]}")
    parser.add_argument("--test-recovery", action="store_true", help="Also delete vector records and verify cached-document repair")
    args = parser.parse_args()
    # This check never downloads a model. Prepare its cache separately.
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    os.environ.pop("SCIASSISTANT_EMBEDDING_ALLOW_DOWNLOAD", None)
    output = Path(args.output)
    if output.exists():
        print(json.dumps({"status": "configuration_error", "error_code": "OUTPUT_ALREADY_EXISTS"}))
        return 2
    try:
        provider = LocalSentenceTransformerEmbedding(os.getenv("SCIASSISTANT_EMBEDDING_MODEL", DEFAULT_EMBEDDING_MODEL))
        result = check_retrieval(output, provider, lambda path, dimension: QdrantVectorStore(dimension=dimension, path=path),
                                 test_recovery=args.test_recovery)
    except Exception:
        print(json.dumps({"status": "configuration_error", "error_code": "LOCAL_RAG_NOT_READY"}))
        return 2
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
