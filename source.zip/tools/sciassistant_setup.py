"""Windows GUI installer for the local SciAssistant web application.

This program intentionally stores user-supplied credentials only in local .env files.
Those files are ignored by Git and are never sent to an external service by this setup
program. The model token is used only after the user starts SciAssistant.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import threading
from pathlib import Path
from queue import Empty, Queue
from tkinter import BooleanVar, StringVar, Tk, messagebox, ttk
from tkinter.scrolledtext import ScrolledText


MODEL_URL = "https://api.deepseek.com/v1/chat/completions"
MODEL_NAME = "deepseek-v4-flash"
MIN_PYTHON = (3, 10)


def project_root() -> Path:
    """Resolve the repository root for source and frozen executable layouts."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent.parent
    return Path(__file__).resolve().parent.parent


def find_python() -> list[str] | None:
    """Find a usable Python even when an old PATH/launcher entry is broken."""
    candidates: list[list[str]] = [["py", "-3"], ["python"]]
    local_programs = os.environ.get("LOCALAPPDATA", "")
    program_files = os.environ.get("ProgramFiles", r"C:\\Program Files")
    for base in (Path(local_programs) / "Programs" / "Python", Path(program_files) / "Python"):
        if base.exists():
            candidates.extend([[str(executable)] for executable in sorted(base.glob("Python*/python.exe"), reverse=True)])
    for command in candidates:
        try:
            completed = subprocess.run(
                [*command, "-c", "import sys; print(sys.version_info[:2])"],
                capture_output=True,
                text=True,
                timeout=10,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            if completed.returncode == 0:
                value = completed.stdout.strip().strip("()").replace(" ", "")
                major, minor = (int(part.rstrip(",")) for part in value.split(","))
                if (major, minor) >= MIN_PYTHON:
                    return list(command)
        except (OSError, subprocess.SubprocessError, ValueError):
            continue
    return None


def upsert_env(path: Path, values: dict[str, str]) -> None:
    """Replace named dotenv values while retaining unrelated user settings."""
    lines = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
    pending = dict(values)
    output: list[str] = []
    for line in lines:
        key, separator, _ = line.partition("=")
        if separator and key in pending:
            output.append(f"{key}={pending.pop(key)}")
        else:
            output.append(line)
    if pending and output:
        output.append("")
    output.extend(f"{key}={value}" for key, value in pending.items())
    path.write_text("\n".join(output) + "\n", encoding="utf-8")


class SetupWindow:
    def __init__(self) -> None:
        self.root = Tk()
        self.root.title("SciAssistant v0.3.0 - 安装与配置")
        self.root.geometry("770x670")
        self.root.minsize(680, 560)
        self.root.configure(bg="#121821")
        self.events: Queue[tuple[str, str]] = Queue()
        self.running = False
        self.install_tesseract = BooleanVar(value=True)
        self.model_url = StringVar(value=MODEL_URL)
        self.model_name = StringVar(value=MODEL_NAME)
        self.model_token = StringVar()
        self.llama_key = StringVar()
        self._build()
        self.root.after(150, self._drain_events)

    def _build(self) -> None:
        style = ttk.Style(self.root)
        style.theme_use("clam")
        style.configure("TFrame", background="#121821")
        style.configure("TLabel", background="#121821", foreground="#e6edf3", font=("Segoe UI", 10))
        style.configure("Title.TLabel", font=("Segoe UI", 18, "bold"), foreground="#f5f7fa")
        style.configure("Hint.TLabel", foreground="#a9b4c4")
        style.configure("TCheckbutton", background="#121821", foreground="#e6edf3")
        style.configure("TEntry", fieldbackground="#202938", foreground="#f5f7fa")
        style.configure("Accent.TButton", font=("Segoe UI", 10, "bold"), padding=8)

        outer = ttk.Frame(self.root, padding=22)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="SciAssistant 本地安装与配置", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            outer,
            text="安装 Python 依赖，创建本机配置，并保留所有 API Key 在项目目录的 .env 中。",
            style="Hint.TLabel",
        ).pack(anchor="w", pady=(4, 16))

        form = ttk.Frame(outer)
        form.pack(fill="x")
        self._field(form, "模型接口地址", self.model_url)
        self._field(form, "模型名称", self.model_name)
        self._field(form, "MODEL_REQUEST_TOKEN", self.model_token, secret=True)
        self._field(form, "LLAMA_CLOUD_API_KEY（可选）", self.llama_key, secret=True)
        ttk.Checkbutton(
            form,
            text="安装 Tesseract OCR（建议：扫描 PDF 兜底和表格 OCR 交叉核验）",
            variable=self.install_tesseract,
        ).pack(anchor="w", pady=(8, 8))
        ttk.Label(
            form,
            text="若电脑没有 Python 或 Tesseract，安装器会尝试通过 Windows winget 安装；失败时会给出明确说明。",
            style="Hint.TLabel",
            wraplength=700,
        ).pack(anchor="w", pady=(0, 14))

        self.action = ttk.Button(outer, text="安装依赖并保存配置", style="Accent.TButton", command=self.start)
        self.action.pack(anchor="w", pady=(0, 12))
        self.log = ScrolledText(
            outer, height=15, bg="#0b1119", fg="#d9e2ef", insertbackground="#ffffff",
            relief="flat", font=("Consolas", 9), wrap="word",
        )
        self.log.pack(fill="both", expand=True)
        self._write(f"项目目录: {project_root()}")
        self._write("填写回答模型 Token 后点击安装；Llama Key 仅在全 Llama/混合模式时需要。")

    @staticmethod
    def _field(parent: ttk.Frame, label: str, variable: StringVar, secret: bool = False) -> None:
        ttk.Label(parent, text=label).pack(anchor="w", pady=(6, 2))
        ttk.Entry(parent, textvariable=variable, show="*" if secret else "").pack(fill="x")

    def _write(self, message: str) -> None:
        self.log.insert("end", message + "\n")
        self.log.see("end")

    def _emit(self, kind: str, message: str) -> None:
        self.events.put((kind, message))

    def _drain_events(self) -> None:
        try:
            while True:
                kind, message = self.events.get_nowait()
                self._write(message)
                if kind == "done":
                    self.running = False
                    self.action.configure(state="normal")
                    messagebox.showinfo("SciAssistant", "安装和配置完成。可使用 start_web.cmd 启动网页端。")
                elif kind == "error":
                    self.running = False
                    self.action.configure(state="normal")
                    messagebox.showerror("SciAssistant", message)
        except Empty:
            pass
        self.root.after(150, self._drain_events)

    def start(self) -> None:
        if self.running:
            return
        if not self.model_token.get().strip():
            messagebox.showwarning("缺少 Token", "请填写 MODEL_REQUEST_TOKEN 后再继续。")
            return
        if not self.model_url.get().strip().lower().startswith(("https://", "http://")):
            messagebox.showwarning("接口地址无效", "模型接口地址必须以 http:// 或 https:// 开头。")
            return
        self.running = True
        self.action.configure(state="disabled")
        values = {
            "MODEL_REQUEST_URL": self.model_url.get().strip(),
            "MODEL_REQUEST_TOKEN": self.model_token.get().strip(),
            "MODEL_NAME": self.model_name.get().strip() or MODEL_NAME,
            "LLAMA_CLOUD_API_KEY": self.llama_key.get().strip(),
        }
        install_tesseract = bool(self.install_tesseract.get())
        threading.Thread(target=self._install, args=(values, install_tesseract), daemon=True).start()

    def _run(self, command: list[str], cwd: Path) -> None:
        self._emit("log", "> " + " ".join(command))
        process = subprocess.Popen(
            command, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, encoding="utf-8", errors="replace",
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        assert process.stdout is not None
        for line in process.stdout:
            self._emit("log", line.rstrip())
        if process.wait() != 0:
            raise RuntimeError(f"命令执行失败，退出码 {process.returncode}: {' '.join(command)}")

    def _try_winget(self, package_id: str, name: str, cwd: Path) -> bool:
        if not shutil.which("winget"):
            self._emit("log", f"未检测到 winget，无法自动安装 {name}。")
            return False
        try:
            self._run(["winget", "install", "--id", package_id, "-e", "--accept-package-agreements", "--accept-source-agreements"], cwd)
            return True
        except RuntimeError as exc:
            self._emit("log", f"自动安装 {name} 失败: {exc}")
            return False

    def _install(self, values: dict[str, str], install_tesseract: bool) -> None:
        root = project_root()
        try:
            if not (root / "deepdiver_v2" / "requirements.txt").exists():
                raise RuntimeError("未找到项目依赖文件。请将 SciAssistantSetup.exe 保留在 installer 文件夹中。")
            python = find_python()
            if python is None:
                self._emit("log", "未检测到可用 Python 3.10+，尝试通过 winget 安装 Python 3.12...")
                self._try_winget("Python.Python.3.12", "Python 3.12", root)
                python = find_python()
            if python is None:
                raise RuntimeError("未找到 Python 3.10+。请安装 Python 后重新运行安装器，并勾选 Add Python to PATH。")
            self._emit("log", "已检测到 Python: " + " ".join(python))

            venv_python = root / "venv" / "Scripts" / "python.exe"
            if not venv_python.exists():
                self._emit("log", "创建项目虚拟环境...")
                self._run([*python, "-m", "venv", "venv"], root)
            self._emit("log", "安装 Python 依赖...")
            self._run([str(venv_python), "-m", "pip", "install", "--upgrade", "pip"], root)
            self._run([str(venv_python), "-m", "pip", "install", "-r", "deepdiver_v2/requirements.txt"], root)

            if install_tesseract and not (shutil.which("tesseract") or Path(r"C:\Program Files\Tesseract-OCR\tesseract.exe").exists()):
                self._emit("log", "未检测到 Tesseract，尝试通过 winget 安装...")
                self._try_winget("UB-Mannheim.TesseractOCR", "Tesseract OCR", root)
            elif install_tesseract:
                self._emit("log", "已检测到 Tesseract OCR。")

            root_env = root / ".env"
            nested_env = root / "deepdiver_v2" / "config" / ".env"
            upsert_env(root_env, values)
            upsert_env(nested_env, values)
            self._emit("done", "完成：依赖已安装，本机 API 配置已保存到 .env。")
        except Exception as exc:  # Shown to the user, without exposing API keys.
            self._emit("error", f"安装未完成：{exc}")

    def run(self) -> None:
        self.root.mainloop()


if __name__ == "__main__":
    SetupWindow().run()
