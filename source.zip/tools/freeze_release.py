"""Freeze current source bytes without consuming the user's Git index.

No checkout, reset, network, environment capture, model, or production-data copy.
Optional --git-ref creates a local, parentless release snapshot with its own index.
The ZIP is source, not a container image or a production data backup.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = 'sciassistant.source-release/v1'
MANIFEST = 'RELEASE_MANIFEST.json'
PRIVATE_OPERATOR_TOOLS = frozenset({
    'tools/backfill_eval_messages.py', 'tools/continue5x10.py',
    'tools/quick_verify.py', 'tools/run_multidomain_eval.py',
    'tools/run_new3x10.py', 'tools/run_regression_and_new.py',
    'tools/rwkv3.py', 'tools/stress10.py', 'tools/stress_test.py',
})
ROOT_NAMES = {'LICENSE', 'NOTICE', 'README.md', '.gitignore', '.gitattributes', 'pytest.ini'}
DOC_NAMES = {'AGPL_DEPLOYMENT.md', 'ACCOUNT_BACKUP_RESTORE_RUNBOOK_20260929.md',
             'LOCAL_RELEASE_ACCEPTANCE_20261017.md', 'RELEASE_AND_RESTORE_20261017.md',
             'DEPLOYMENT_READINESS_ACCEPTANCE_20261023.md', 'INITIAL_DELIVERY_BUDGET_ACCEPTANCE_20261023.md',
             'DEPLOYMENT_NONQUALITY_ACCEPTANCE_20261023.md', 'USER_SERVER_DEPLOYMENT_20261023.md'}
FRONTEND_BUILD_NAMES = {'package.json', 'package-lock.json', 'tailwind.config.cjs',
                        'tailwind.css', 'THIRD_PARTY_NOTICES.md'}
VENDOR_NOTICE_NAMES = {'chatAi/vendor/font-awesome/LICENSE-CSS', 'chatAi/vendor/font-awesome/LICENSE-FONT',
    'chatAi/vendor/font-awesome/README.md', 'chatAi/vendor/katex/LICENSE',
    'chatAi/vendor/prism/LICENSE', 'chatAi/vendor/tailwindcss/LICENSE'}
FORBIDDEN_PARTS = {'.git', '__pycache__', 'venv', '.venv', 'logs', 'uploads', 'user_files',
                   'web_uploads', 'workspace', 'workspaces', 'arxiv', 'models', 'node_modules',
                   'dist', 'build', 'backup_bundles', 'backup_restore_staging'}


class ReleaseError(ValueError):
    pass


def digest(data):
    return hashlib.sha256(data).hexdigest()


def allowed(name):
    path = PurePosixPath(name)
    if name in PRIVATE_OPERATOR_TOOLS:
        return False  # Legacy operator scripts contain fixed account login data.
    if ('\\' in name or path.is_absolute() or '..' in path.parts
            or str(path) != name or any(p in FORBIDDEN_PARTS for p in path.parts)):
        return False
    if path.name.startswith('.env'):
        return len(path.parts) == 1 and path.name.endswith('.example')
    # Reviewed empty-volume schema, not an operator's SQL data dump.
    if name == 'deploy/mysql-init/001_schema.sql':
        return True
    if name in {'chatAi/assets/manifest.json', 'tests/fixtures/full_report_cases.json'} or name in VENDOR_NOTICE_NAMES:
        return True  # Reviewed public manifests/notices, not arbitrary user JSON.
    if path.name.endswith(('.sql', '.pdf', '.db', '.sqlite3', '.log', '.pyc', '.pem', '.key')):
        return False
    if len(path.parts) == 1:
        return (name in ROOT_NAMES or path.suffix in {'.py', '.cmd'} or name.startswith('Dockerfile')
                or bool(re.fullmatch(r'docker-compose[\w.-]*\.ya?ml', name)))
    category = path.parts[0]
    if category == '.github':
        return len(path.parts) == 3 and path.parts[1] == 'workflows' and path.suffix in {'.yml', '.yaml'}
    if category in {'tools', 'tests'}:
        # Local one-off diagnostics may embed operator credentials or data.
        # They are not runtime modules; never ship them with a source release.
        if category == 'tools' and (any(p.startswith('_') for p in path.parts[1:-1])
                or path.name.startswith('_') and path.name != '__init__.py'):
            return False
        return path.suffix in {'.py', '.cjs'}
    if category in {'bin', 'scripts'}:
        return path.suffix in {'.sh', '.ps1', '.cmd', '.py'}
    if category == 'deploy':
        return path.suffix in {'.conf', '.example', '.md'}
    if category == 'frontend':
        return len(path.parts) == 2 and path.name in FRONTEND_BUILD_NAMES
    if category in {'chatAi', 'web'}:
        return (path.suffix.lower() in {'.html', '.js', '.css', '.svg', '.png', '.jpg', '.ico', '.woff2'}
                or category == 'chatAi' and len(path.parts) > 3 and path.parts[1] == 'vendor'
                and path.suffix.lower() in {'.woff', '.ttf', '.otf', '.eot'})
    if category == 'deepdiver_v2':
        return (path.suffix in {'.py', '.yaml', '.yml'} or path.name == 'env.template'
                or bool(re.fullmatch(r'(requirements|constraints)[\w.-]*\.txt', path.name))
                or path.name == 'rag.cloud.artifacts.json')
    return category == 'docs' and len(path.parts) == 2 and path.name in DOC_NAMES


def git(root, *args, env=None, data=None):
    run = subprocess.run(['git', '-C', str(root), *args], input=data, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, env=env, check=False)
    if run.returncode:
        raise ReleaseError('RELEASE_GIT_OPERATION_FAILED')
    return run.stdout


def index_hash(root):
    name = git(root, 'rev-parse', '--git-path', 'index').decode().strip()
    path = Path(name)
    if not path.is_absolute():
        path = root / path
    return digest(path.read_bytes()) if path.exists() else None


def collect(root):
    names = git(root, 'ls-files', '-c', '-o', '--exclude-standard', '-z').decode('utf-8').split('\0')
    files = {}
    for name in sorted({name for name in names if name and allowed(name)}):
        path = root / name
        info = path.lstat()
        if (not stat.S_ISREG(info.st_mode) or path.is_symlink()
                or getattr(info, 'st_file_attributes', 0) & 0x400
                or not path.resolve().is_relative_to(root)):
            raise ReleaseError('RELEASE_NON_REGULAR_SOURCE')
        value = path.read_bytes()
        if path.suffix == '.sh' and b'\r\n' in value:
            raise ReleaseError('RELEASE_SHELL_CRLF')
        files[name] = value
    if not files:
        raise ReleaseError('RELEASE_SOURCE_EMPTY')
    return files


def freeze(root, output, git_ref=None):
    root, output = Path(root).resolve(), Path(output).resolve()
    if output.exists() or not output.parent.is_dir():
        raise ReleaseError('RELEASE_OUTPUT_MUST_BE_NEW')
    if git_ref and not re.fullmatch(r'refs/heads/release/[a-z0-9][a-z0-9._-]{0,79}', git_ref):
        raise ReleaseError('RELEASE_REF_INVALID')
    if git_ref and git(root, 'for-each-ref', '--format=%(refname)', git_ref).strip():
        raise ReleaseError('RELEASE_REF_ALREADY_EXISTS')
    before = index_hash(root)
    files = collect(root)
    from runtime_identity import source_fingerprint
    fingerprint, complete = source_fingerprint(root)
    if not complete:
        raise ReleaseError('RELEASE_IDENTITY_INCOMPLETE')
    # A release must contain every identity file, including new untracked modules.
    from runtime_identity import IDENTITY_FILES
    if not set(IDENTITY_FILES) <= files.keys():
        raise ReleaseError('RELEASE_IDENTITY_FILES_MISSING')
    manifest = {'schema_version': SCHEMA, 'source_head': git(root, 'rev-parse', 'HEAD').decode().strip(),
                'source_fingerprint': fingerprint, 'source_complete': complete,
                'private_data_included': False, 'models_included': False,
                'files': [{'path': n, 'sha256': digest(b), 'size': len(b)} for n, b in files.items()]}
    encoded = (json.dumps(manifest, indent=2, ensure_ascii=False) + '\n').encode()
    payload = {**files, MANIFEST: encoded}
    # Recheck all source bytes before publishing; don't combine a racing edit.
    if any((root / n).read_bytes() != b for n, b in files.items()):
        raise ReleaseError('RELEASE_SOURCE_CHANGED')
    output.mkdir()
    snapshot = output / 'source'
    snapshot.mkdir()
    for name, value in payload.items():
        target = snapshot / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream:
            stream.write(value)
        if name.endswith('.sh'):
            target.chmod(0o755)
    archive = output / 'source.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as bundle:
        for name, value in payload.items():
            info = zipfile.ZipInfo(name, date_time=(2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o100755 if name.endswith('.sh') else 0o100644) << 16
            bundle.writestr(info, value)
    commit = None
    if git_ref:
        with tempfile.TemporaryDirectory(prefix='sciassistant-release-index-') as directory:
            isolated = {**os.environ, 'GIT_INDEX_FILE': str(Path(directory) / 'index')}
            git(root, 'read-tree', '--empty', env=isolated)
            for name, value in payload.items():
                blob = git(root, 'hash-object', '-w', '--stdin', env=isolated, data=value).decode().strip()
                mode = '100755' if name.endswith('.sh') else '100644'
                git(root, 'update-index', '--add', '--cacheinfo', mode, blob, name, env=isolated)
            tree = git(root, 'write-tree', env=isolated).decode().strip()
            commit = git(root, '-c', 'user.name=SciAssistant Release', '-c', 'user.email=release@localhost',
                         'commit-tree', tree, '-m', 'Freeze verified working source for deployment', env=isolated).decode().strip()
            git(root, 'update-ref', git_ref, commit, '0' * 40)
    after = index_hash(root)
    if before != after:
        raise ReleaseError('USER_INDEX_CHANGED_DURING_FREEZE')
    report = {'schema_version': SCHEMA, 'source_fingerprint': fingerprint, 'release_commit': commit,
              'git_ref': git_ref, 'files': len(files), 'archive_sha256': digest(archive.read_bytes()),
              'original_index_unchanged': True, 'production_deployment_verified': False}
    (output / 'release.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    verify(archive)
    return report


def verify(archive):
    with zipfile.ZipFile(archive) as bundle:
        names = bundle.namelist()
        if len(names) != len(set(names)) or MANIFEST not in names:
            raise ReleaseError('RELEASE_MANIFEST_INVALID')
        manifest = json.loads(bundle.read(MANIFEST))
        if manifest.get('schema_version') != SCHEMA:
            raise ReleaseError('RELEASE_MANIFEST_INVALID')
        expected = {}
        for entry in manifest['files']:
            name = entry['path']
            if not allowed(name) or name in expected:
                raise ReleaseError('RELEASE_FILE_SET_INVALID')
            expected[name] = entry
        if set(names) != {*expected, MANIFEST}:
            raise ReleaseError('RELEASE_FILE_SET_INVALID')
        for name, entry in expected.items():
            value = bundle.read(name)
            if len(value) != entry['size'] or digest(value) != entry['sha256']:
                raise ReleaseError('RELEASE_HASH_MISMATCH')
        from runtime_identity import IDENTITY_FILES
        if not set(IDENTITY_FILES) <= expected.keys():
            raise ReleaseError('RELEASE_IDENTITY_FILES_MISSING')
        identity = hashlib.sha256()
        for name in IDENTITY_FILES:
            identity.update(name.encode() + b'\0' + hashlib.sha256(bundle.read(name)).digest())
        if manifest.get('source_fingerprint') != identity.hexdigest() or manifest.get('source_complete') is not True:
            raise ReleaseError('RELEASE_IDENTITY_MISMATCH')
    return {'passed': True, 'files': len(expected), 'archive_sha256': digest(Path(archive).read_bytes())}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    create = sub.add_parser('freeze')
    create.add_argument('--root', type=Path, default=ROOT)
    create.add_argument('--output', type=Path, required=True)
    create.add_argument('--git-ref')
    check = sub.add_parser('verify')
    check.add_argument('--archive', type=Path, required=True)
    args = parser.parse_args()
    try:
        report = freeze(args.root, args.output, args.git_ref) if args.command == 'freeze' else verify(args.archive)
        print(json.dumps(report))
        return 0
    except Exception as exc:
        code = str(exc) if isinstance(exc, ReleaseError) else 'RELEASE_OPERATION_FAILED'
        print(json.dumps({'passed': False, 'error': code}))
        return 2


if __name__ == '__main__':
    import sys
    sys.path.insert(0, str(ROOT))
    raise SystemExit(main())
