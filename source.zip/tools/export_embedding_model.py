"""Export an already cached CPU embedding model for a read-only Docker mount."""
import argparse
import json
import os
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    output = Path(args.output).resolve()
    if output.exists():
        print(json.dumps({"passed": False, "error": "OUTPUT_ALREADY_EXISTS"}))
        return 2
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    os.environ["SCIASSISTANT_EMBEDDING_ALLOW_DOWNLOAD"] = "0"
    try:
        from multi_agent_rag import LocalSentenceTransformerEmbedding, DEFAULT_EMBEDDING_MODEL
        provider = LocalSentenceTransformerEmbedding(os.getenv("SCIASSISTANT_EMBEDDING_MODEL", DEFAULT_EMBEDDING_MODEL))
        if provider.dimension != 384:
            raise ValueError("unsupported model")
        output.mkdir(parents=True, exist_ok=False)
        provider._model.save(str(output), safe_serialization=True)
        (output / "sciassistant-model.json").write_text(json.dumps({"schema": "sciassistant.embedding-export/v1",
            "dimension": 384, "device": "cpu", "answer_model_calls": 0}) + "\n", encoding="utf-8")
        print(json.dumps({"passed": True, "dimension": 384, "answer_model_calls": 0}))
        return 0
    except Exception:
        # Failed output is left for inspection; never delete a user's directory.
        print(json.dumps({"passed": False, "error": "LOCAL_MODEL_EXPORT_FAILED"}))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
