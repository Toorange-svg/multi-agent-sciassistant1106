"""Read-only source-description pointers; no semantic verdict or publication."""
import argparse
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from multi_agent_agents import ArtifactDirectory
from multi_agent_quality import source_boundary_brief
from tools.check_premise_artifacts import read, tree


def collect(run):
    before=tree(run)
    manifest=read(run/'manifest.json')
    store=ArtifactDirectory(run/'artifacts')
    final=store.get(manifest['final_artifact_id'])
    approved=store.get(final['artifact_refs']['approved'])
    draft=store.get(final['artifact_refs']['draft'])
    mentions=[]
    for claim in draft.get('claims',[]):
        for field in ('text','scope_note','qualification'):
            text=str(claim.get(field) or '')
            if re.search(r'综述|\b(?:survey|review)\s+(?:paper|article)\b',text,re.I):
                mentions.append({'claim_id':claim['claim_id'],'field':field,'text':text,
                    'evidence_ids':claim.get('evidence_ids',[]),'automatic_rejection':False})
    return {'schema_version':'sciassistant.document-description-check/v1',
        'run_id':manifest['run_id'],'recorded_status':final['status'],
        'records':source_boundary_brief(approved)['document_description_records'],
        'genre_mentions_for_review':mentions,'semantic_support_verified':False,
        'source_republished':False,'source_hashes_unchanged':before==tree(run),
        'model_calls_added':0,'network_calls_added':0}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-dir',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    run,output=args.run_dir.resolve(),args.output.resolve()
    if (not run.is_dir() or not run.is_relative_to(ROOT/'logs') or output.exists()
            or not output.is_relative_to(ROOT/'logs') or output.is_relative_to(run)):
        parser.error('source logs run and new logs output outside it required')
    result=collect(run)
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('x',encoding='utf-8') as stream:
        json.dump(result,stream,ensure_ascii=False,indent=2)
    print(json.dumps({'run_id':result['run_id'],'genre_mentions':len(result['genre_mentions_for_review']),
        'records':len(result['records']),'source_hashes_unchanged':result['source_hashes_unchanged']},ensure_ascii=False))
    return 0 if result['source_hashes_unchanged'] else 1


if __name__=='__main__':
    raise SystemExit(main())
