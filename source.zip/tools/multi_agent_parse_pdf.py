"""Isolated PDF tool. Cloud use requires explicit consent and an owner-scoped key.

Default remains local/offline. No provider response, job ID or key is logged.
"""
from pathlib import Path
import json
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


class DeadlineHttp:
    """Pinned TLS origin, bounded response and one shared deadline; no redirects."""
    def __init__(self, deadline):
        import requests
        self.deadline = deadline
        self.session = requests.Session()
        self.session.trust_env = False

    def request(self, method, url, **kwargs):
        from urllib.parse import urlsplit
        parsed = urlsplit(url)
        if (parsed.scheme != "https" or parsed.netloc != "api.cloud.llamaindex.ai"
                or parsed.username or parsed.password or parsed.fragment):
            raise ValueError("LLAMA_ENDPOINT_REJECTED")
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError("LLAMA_PARSE_DEADLINE")
        kwargs.update(timeout=max(.1, min(15.0, remaining)), allow_redirects=False, verify=True, stream=True)
        response = self.session.request(method, url, **kwargs)
        try:
            if 300 <= response.status_code < 400:
                raise ValueError("LLAMA_REDIRECT_REJECTED")
            payload = bytearray()
            for chunk in response.iter_content(64 * 1024):
                if time.monotonic() >= self.deadline:
                    raise TimeoutError("LLAMA_PARSE_DEADLINE")
                payload.extend(chunk)
                if len(payload) > 8 * 1024 * 1024:
                    raise ValueError("LLAMA_RESPONSE_LIMIT")
            response._content = bytes(payload)
            response._content_consumed = True
            return response
        finally:
            response.close()

    def close(self):
        self.session.close()

    # LlamaVisionClient accepts a requests-like client and invokes verb methods.
    # Route every verb through the same pinned-origin/deadline/body-size gate.
    def get(self, url, **kwargs):
        return self.request('get', url, **kwargs)

    def post(self, url, **kwargs):
        return self.request('post', url, **kwargs)

    def delete(self, url, **kwargs):
        return self.request('delete', url, **kwargs)


def cloud_blocks(result, page_count):
    """Only complete, ordered page output is eligible for page-level citations.

    Cloud text does not inherit local boxes, tables or section interpretations.
    Matching page count is a structural check, NOT proof of OCR correctness.
    """
    pages = result.get("page_markdown")
    if (not isinstance(pages, list) or len(pages) != page_count or not pages
            or any(not isinstance(text, str) or not text.strip() for text in pages)
            or sum(len(text) for text in pages) > 2_000_000):
        raise ValueError("LLAMA_PAGE_MAPPING_INVALID")
    return [{"page": number, "text": text, "bbox": None, "source_parser": "llamaparse",
             "type": "cloud_transcription", "section": "LlamaParse 云解析（需核对原页）"}
            for number, text in enumerate(pages, 1)]


def parse_document(path, mode="local", consent=False, timeout=120, *, local_parser=None, cloud_parser=None):
    from pdf_pipeline import parse_pdf
    from multi_agent_local_pdf import pdf_parser_options, validate_pdf_input
    from user_credentials import provider_value
    pdf_parser_options(True, mode, consent)
    path = validate_pdf_input(path)
    if mode != "local" and not provider_value("LLAMA_CLOUD_API_KEY").startswith("llx-"):
        return {"success": False, "error_code": "LLAMA_USER_KEY_REQUIRED"}
    deadline = time.monotonic() + max(.1, min(120., float(timeout)))
    local = (local_parser or parse_pdf)(path, enable_ocr=False)
    if mode == "local":
        return local
    # The real PDF determines page count; never number arbitrary Markdown chunks.
    import fitz
    with fitz.open(path) as document:
        page_count = len(document)
    http = None
    try:
        if time.monotonic() >= deadline:
            raise TimeoutError("LLAMA_PARSE_DEADLINE")
        if cloud_parser is None:
            from deepdiver_v2.src.tools.llama_vision_client import LlamaVisionClient, LlamaVisionConfig
            http = DeadlineHttp(deadline)
            client = LlamaVisionClient(LlamaVisionConfig(enabled=True,
                api_key=provider_value("LLAMA_CLOUD_API_KEY"), max_retries=0,
                timeout=max(1, int(deadline - time.monotonic())), poll_interval=1), http_client=http)
            cloud_parser = client.parse_full_pdf
        cloud = cloud_parser(str(path), timeout=max(1, int(deadline - time.monotonic())), max_retries=0)
        if time.monotonic() >= deadline:
            raise TimeoutError("LLAMA_PARSE_DEADLINE")
        if cloud.get("status") != "completed":
            raise ValueError("LLAMA_PARSE_FAILED")
        blocks = cloud_blocks(cloud, page_count)
        if mode == "hybrid":
            # Preserve native local geometry and add a separately tagged cloud
            # transcription. The RAG chunk boundary must keep these apart.
            blocks = list(local.get("layout_blocks") or local.get("evidence_blocks") or []) + blocks
        return {"success": True, "layout_blocks": blocks,
            "parser_summary": {"requested": mode, "actual": mode, "cloud_status": "completed",
                "cloud_pages": page_count, "cloud_locator": "page_only_no_invented_bbox",
                "cloud_text_requires_original_review": True}}
    except Exception as error:
        code = str(error) if str(error) in {"LLAMA_PAGE_MAPPING_INVALID", "LLAMA_PARSE_DEADLINE"} else "LLAMA_PARSE_FAILED"
        if mode == "hybrid" and local.get("success") and (local.get("layout_blocks") or local.get("evidence_blocks")):
            return {**local, "parser_summary": {"requested": mode, "actual": "local",
                "cloud_status": "failed", "warning_code": code, "fallback": "verified_local_extraction"}}
        return {"success": False, "error_code": code}
    finally:
        if http:
            http.close()


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("pdf"); parser.add_argument("output")
    parser.add_argument("--mode", choices=["local", "llama_full", "hybrid"], default="local")
    parser.add_argument("--cloud-consent", action="store_true")
    parser.add_argument("--timeout", type=float, default=120)
    args = parser.parse_args()
    parsed = parse_document(args.pdf, args.mode, args.cloud_consent, args.timeout)
    Path(args.output).write_text(json.dumps(parsed, ensure_ascii=False), encoding="utf-8")
    return 0 if parsed.get("success") else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception:
        raise SystemExit(1)
