# -*- coding: utf-8 -*-
"""端到端 trace：选一个问题，逐层打印 query_plan -> lexical -> semantic -> 最终。"""
import sys, pathlib, json, logging
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
logging.disable(logging.WARNING)

from deepdiver_v2.src.query_router import (
    build_literature_query_plan, score_literature_relevance, requested_concepts,
)

QUERIES = [
    "滑动窗口注意力（sliding window attention）在 Longformer 等模型中是如何降低复杂度的？",
    "高分辨率图像在输入视觉编码器时通常怎么切分？",
    "ACT 系列和 Diffusion Policy 在动作生成上有什么区别？",
]
for QUERY in QUERIES:
    print("=" * 70)
    print("QUERY:", QUERY)
    print("=" * 70)

# 1. query_plan
plan = build_literature_query_plan(QUERY)
print(f"\n[1] query_plan: {len(plan)} 条")
for i, p in enumerate(plan):
    print(f"  {i+1}. {p.get('query','')}")

# 2. requested concepts
print(f"\n[2] requested_concepts: {sorted(requested_concepts(QUERY))}")

# 3. 直接用 demo 的检索函数拿候选
from deepdiver_v2.cli.demo import _semantic_filter_literature_candidates, get_config
config = get_config()

# 用 perform_search_round 拿候选
import deepdiver_v2.cli.demo as demo_mod

# 直接调底层：用 arxiv adapter 查第一个 query
queries = [p["query"] for p in plan if p.get("query")] or [QUERY]
all_candidates = []
for q in queries[:3]:
    try:
        # 找 adapter
        tools = demo_mod._build_tools() if hasattr(demo_mod, "_build_tools") else None
    except Exception:
        tools = None
    print(f"\n[3] query: {q!r}")
    # 直接用 arxiv search
    try:
        from deepdiver_v2.src.literature_sources import search_source
        res = search_source("arxiv", q, limit=10)
        res = res.get("papers") if isinstance(res, dict) else res
        res = res or []
        print(f"    arxiv returned: {len(res)}")
        for r in res[:8]:
            title = (r.get("title") or "")[:60]
            rel = score_literature_relevance(QUERY, r)
            print(f"      [{rel['score']:.2f} lex={rel['accepted']}] {title}  why={rel.get('rejection_reason')}")
            r["relevance"] = rel
            all_candidates.append(r)
    except Exception as e:
        print(f"    arxiv error: {e}")

# 4. semantic filter
print(f"\n[4] semantic filter on {len(all_candidates)} candidates")
try:
    kept, diag = _semantic_filter_literature_candidates(QUERY, all_candidates, config)
    print(f"    diag: {diag}")
    for c in kept:
        print(f"    KEPT: [{c['relevance'].get('semantic_label')}] {(c.get('title') or '')[:60]}")
except Exception as e:
    import traceback; traceback.print_exc()
