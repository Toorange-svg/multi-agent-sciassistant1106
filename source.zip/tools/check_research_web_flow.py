"""Actual HTTP entry test with dedicated registered accounts and isolated files.

Runs an owned temporary gateway, never restarts 5000. Uses the real MySQL/API
authentication paths. Mock models are NOT scientific quality acceptance.
--model-mode live incurs model fees; stop immediately at HTTP402.
No passwords, JWTs or full provider responses in artifacts/stdout.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import secrets
import sqlite3
import subprocess
import sys
import time

import requests

ROOT = Path(__file__).resolve().parents[1]
SUCCESS = {'completed', 'partial', 'needs_review'}
TERMINAL = SUCCESS | {'failed', 'timed_out', 'cancelled'}


class CheckFailed(RuntimeError):
    pass


class Server:
    def __init__(self, state, mode):
        self.state, self.mode, self.process = state, mode, None
        self.env = os.environ.copy()
        self.env['SCIASSISTANT_VALIDATION_SIGNING_KEY'] = secrets.token_hex(32)

    def start(self):
        ready = self.state / 'ready.json'
        ready.unlink(missing_ok=True)  # exact validation-owned marker, not an archive
        self.process = subprocess.Popen([sys.executable, str(ROOT / 'tools/research_web_fixture.py'),
            '--state', str(self.state), '--model-mode', self.mode], cwd=ROOT, env=self.env,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            **({'creationflags': subprocess.CREATE_NO_WINDOW} if os.name == 'nt' else {'start_new_session': True}))
        deadline = time.monotonic() + 35
        while time.monotonic() < deadline:
            if self.process.poll() is not None: raise CheckFailed('ISOLATED_SERVER_EXITED')
            if ready.is_file():
                self.base = 'http://127.0.0.1:' + str(json.loads(ready.read_text(encoding='utf8'))['port'])
                return
            time.sleep(.15)
        raise CheckFailed('ISOLATED_SERVER_START_TIMEOUT')

    def stop(self):
        if self.process and self.process.poll() is None:
            self.process.terminate()
            try: self.process.wait(timeout=8)
            except subprocess.TimeoutExpired: self.process.kill(); self.process.wait(timeout=5)


def request(base, method, path, token=None, **kwargs):
    # Literal local base is owned by Server; no proxy/redirect credential forwarding.
    with requests.Session() as session:
        session.trust_env = False
        headers = {'Authorization': 'Bearer ' + token} if token else {}
        return session.request(method, base + path, headers=headers, allow_redirects=False,
                               timeout=(5, 30), **kwargs)


def register(base, label):
    username = 'webcheck_' + label + '_' + secrets.token_hex(4)
    password = secrets.token_urlsafe(24)
    response = request(base, 'POST', '/api/register', json={'username': username,
        'email': username + '@example.invalid', 'password': password, 'confirmPassword': password})
    if response.status_code != 200: raise CheckFailed('DEDICATED_ACCOUNT_REGISTER_' + str(response.status_code))
    response = request(base, 'POST', '/api/login', json={'loginId': username, 'password': password})
    if response.status_code != 200: raise CheckFailed('DEDICATED_ACCOUNT_LOGIN_' + str(response.status_code))
    values = response.json()['data']
    return {'token': values['token'], 'user_id': values['user_id'], 'username': username, 'password': password}


def session_id(server, account, title):
    response = request(server.base, 'POST', '/api/chat/sessions', account['token'], json={'title': title})
    if response.status_code not in {200, 201}: raise CheckFailed('CHAT_CREATE_' + str(response.status_code))
    return response.json()['session_id']


def wait_task(server, owner, task_id, *, limit=400):
    deadline = time.monotonic() + limit
    while time.monotonic() < deadline:
        response = request(server.base, 'GET', '/api/science/tasks/' + task_id, owner['token'])
        if response.status_code != 200: raise CheckFailed('TASK_READ_' + str(response.status_code))
        task = response.json().get('task', response.json())
        if task['status'] in TERMINAL: return task
        time.sleep(.5)
    # Cancel only the task created by this checker, don't leave orphan execution.
    request(server.base, 'POST', '/api/science/tasks/' + task_id + '/cancel', owner['token'])
    raise CheckFailed('VALIDATION_TASK_WAIT_TIMEOUT')


def task_summary(task):
    execution = task.get('execution') or {}
    return {'task_id': task['id'], 'status': task['status'], 'processing_mode': task.get('processing_mode'),
            'source_scope': task.get('source_scope'), 'model_calls': execution.get('model_calls'),
            'failure_code': execution.get('failure_code'), 'elapsed_seconds': task.get('elapsed_seconds'),
            'local_indexed': (execution.get('reading_progress') or {}).get('uploaded_pdf_indexed'),
            'library_file_id': task.get('library_file_id'), 'pdf_source_task_id': (task.get('pdf_attachment') or {}).get('source_task_id')}


def cancel_running_check(server, owner, other, pdf, root, created_tasks):
    """Cancel our new actual CLI process; never pick an existing user's task."""
    chat = session_id(server, owner, '取消边界验收')
    with pdf.open('rb') as source:
        response = request(server.base, 'POST', '/api/science/tasks', owner['token'],
            data={'query': '解释本文方法', 'conversation_id': chat, 'processing_mode': 'multi_agent_pdf'},
            files={'pdf': ('cancel-source.pdf', source, 'application/pdf')})
    if response.status_code != 202: raise CheckFailed('CANCEL_TASK_CREATE_FAILED')
    task_id = response.json()['task']['id']; created_tasks.append(task_id)
    directory = root / 'runs' / task_id
    deadline = time.monotonic() + 20
    while time.monotonic() < deadline:
        if (directory / 'workflow.sqlite3').exists() and (directory / 'manifest.json').exists(): break
        time.sleep(.03)
    else: raise CheckFailed('CANCEL_PROCESS_NOT_STARTED')
    forbidden = request(server.base, 'POST', '/api/science/tasks/' + task_id + '/cancel', other['token'])
    response = request(server.base, 'POST', '/api/science/tasks/' + task_id + '/cancel', owner['token'])
    if response.status_code != 200: raise CheckFailed('OWN_CANCEL_REJECTED')
    deadline = time.monotonic() + 15
    record = {}
    while time.monotonic() < deadline:
        record = request(server.base, 'GET', '/api/science/tasks/' + task_id, owner['token']).json()
        record = record.get('task', record)
        with sqlite3.connect(f'{(directory / "workflow.sqlite3").resolve().as_uri()}?mode=ro', uri=True) as database:
            row = database.execute('SELECT status FROM workflow_run WHERE run_id=?', (task_id,)).fetchone()
        if row and row[0] == 'cancelled': break
        time.sleep(.1)
    cancellation = record.get('cancellation') or {}
    return {'task_id': task_id, 'other_status': forbidden.status_code,
            'task_status': record.get('status'), 'workflow_status': row[0] if row else None,
            'process_registered_at_request': cancellation.get('process_registered_at_request'),
            'passed': forbidden.status_code == 404 and record.get('status') == 'cancelled'
                      and bool(row) and row[0] == 'cancelled' and cancellation.get('process_registered_at_request') is True}


def run(args):
    root = ROOT / 'logs/research_web_validation' / args.run_id
    if root.exists(): raise CheckFailed('RUN_ID_ALREADY_EXISTS')
    root.mkdir(parents=True)
    server = Server(root, args.model_mode)
    checks, tasks, matrix, browser = {}, [], {}, None
    owner = other = None; created_tasks = []; paid_stopped = False
    result = {'schema_version': 'sciassistant.web-flow-check/v1', 'mode': args.model_mode,
              'real_mysql': True, 'real_http': True, 'production_5000_touched': False,
              'model_responses_mocked': args.model_mode == 'mock', 'checks': checks,
              'tasks': tasks, 'resource_matrix': matrix, 'scientific_quality_verified': False}
    try:
        server.start()
        health = request(server.base, 'GET', '/api/health').json()
        result['source_fingerprint'] = health['runtime']['source_fingerprint']
        checks['fresh_instance'] = health['runtime']['code_on_disk_matches_startup'] is True
        owner, other = register(server.base, 'a'), register(server.base, 'b')
        result['test_account_ids'] = [owner['user_id'], other['user_id']]
        if args.model_mode == 'mock':
            # The real gateway still requires account-owned credentials. Only
            # this isolated fixture mocks execution; never copy an existing
            # user's provider keys or relax the production credential gate.
            for account in (owner, other):
                saved = request(server.base, 'POST', '/api/account/provider-keys', account['token'],
                    json={'deepseek_keys': ['fixture-only-' + secrets.token_hex(24)]})
                if saved.status_code != 200:
                    raise CheckFailed('FIXTURE_ACCOUNT_KEY_SETUP_FAILED')
            checks['mock_accounts_have_dedicated_fixture_keys'] = True
        chat = session_id(server, owner, '资料库闭环验收')
        other_chat = session_id(server, other, '隔离验收')
        with args.pdf.open('rb') as pdf:
            response = request(server.base, 'POST', '/api/research-library/upload', owner['token'],
                files={'files': ('科研验收原件.pdf', pdf, 'application/pdf')})
        if response.status_code != 200: raise CheckFailed('LIBRARY_UPLOAD_' + str(response.status_code))
        file_id = response.json()['files'][0]['file_id']; result['file_id'] = file_id
        source_hash = hashlib.sha256(args.pdf.read_bytes()).hexdigest()
        detail = '/api/research-library/files/' + file_id
        matrix['library'] = [request(server.base, 'GET', detail, who).status_code for who in (owner['token'], other['token'], None)]
        checks['upload_not_indexed'] = request(server.base, 'GET', detail, owner['token']).json()['file']['processing_state'] == 'uploaded'
        response = request(server.base, 'GET', detail + '/pdf', owner['token'])
        checks['original_pdf_hash'] = response.status_code == 200 and hashlib.sha256(response.content).hexdigest() == source_hash
        matrix['original_page'] = [request(server.base, 'GET', detail + '/pages/1', who).status_code for who in (owner['token'], other['token'], None)]
        checks['page_owner_boundary'] = matrix['original_page'] == [200, 404, 401]
        checks['preview_does_not_index'] = request(server.base, 'GET', detail, owner['token']).json()['file']['processing_state'] == 'uploaded'
        checks['library_boundary'] = matrix['library'] == [200, 404, 401]
        negative = request(server.base, 'POST', '/api/science/tasks', owner['token'], json={
            'query': '比较 QLoRA 与 LoRA', 'conversation_id': chat, 'processing_mode': 'multi_agent_rag',
            'library_file_id': file_id, 'source_policy': 'auto'})
        checks['auto_requires_consent'] = negative.status_code == 400
        forbidden = request(server.base, 'POST', '/api/science/tasks', other['token'], json={
            'query': '本文', 'conversation_id': other_chat, 'processing_mode': 'multi_agent_pdf',
            'library_file_id': file_id, 'user_id': owner['user_id']})
        checks['forged_owner_rejected'] = forbidden.status_code == 404
        questions = ['解释本文 NF4、双重量化和分页优化器的作用。',
                     '对比本文 QLoRA 与原始 LoRA，分别说明参数、显存与实验条件，不能跨实验换算统一百分比。'
                     if args.mixed_followup else '继续解释本文哪些参数更新，是否仍有反向传播。']
        result['questions'] = questions
        result['mixed_followup'] = args.mixed_followup
        for index, query in enumerate(questions):
            payload = {'query': query, 'conversation_id': chat, 'processing_mode': 'multi_agent_pdf', 'pdf_parse_mode': 'local'}
            if not index: payload['library_file_id'] = file_id
            else:
                payload['pdf_source_task_id'] = tasks[0]['pdf_source_task_id']
                payload['parent_task_id'] = tasks[0]['task_id']
                if args.mixed_followup:
                    payload.update(source_policy='auto', allow_public_search=True)
            response = request(server.base, 'POST', '/api/science/tasks', owner['token'], json=payload)
            if response.status_code != 202: raise CheckFailed('TASK_CREATE_' + str(response.status_code))
            task_id = response.json()['task']['id']; created_tasks.append(task_id)
            task = wait_task(server, owner, task_id); tasks.append(task_summary(task))
            if '402' in str(tasks[-1]['failure_code']):
                paid_stopped = True; raise CheckFailed('MODEL_HTTP_402_STOP')
            if task['status'] not in SUCCESS: raise CheckFailed('TASK_DID_NOT_PRODUCE_REPORT')
            report = request(server.base, 'GET', '/api/science/tasks/' + task_id + '/report', owner['token']).json()
            refs = {row['evidence_id'] for row in report['references']}
            checks['task_' + str(index) + '_approved_citations'] = bool(report['claims']) and all(
                row['evidence_ids'] and set(row['evidence_ids']) <= refs for row in report['claims'])
        first = tasks[0]['task_id']; prefix = '/api/science/tasks/' + first
        paths = [prefix, prefix + '/report', prefix + '/evidence?format=json'] + [prefix + '/report/export?format=' + kind for kind in ('html', 'md', 'json')]
        report = request(server.base, 'GET', prefix + '/report', owner['token']).json()
        for reference in report['references']:
            for field in ('pdf_asset', 'page_image_asset'):
                if reference.get(field): paths.append(prefix + '/report/assets/' + reference[field])
        paths = list(dict.fromkeys(paths))
        matrix['reports'] = {who: [request(server.base, 'GET', path, token).status_code for path in paths]
                             for who, token in [('owner', owner['token']), ('other', other['token']), ('anonymous', None)]}
        checks['all_report_resources_owned'] = all(code == 200 for code in matrix['reports']['owner'])
        checks['all_report_resources_private'] = all(code == 404 for code in matrix['reports']['other']) and all(code == 401 for code in matrix['reports']['anonymous'])
        before = request(server.base, 'GET', detail, owner['token']).json()['file']
        checks['indexed_from_real_workflow_progress'] = before['processing_state'] == 'indexed'
        checks['both_rounds_linked'] = len(before['outcomes']) == 2
        if args.model_mode == 'mock':
            result['cancellation'] = cancel_running_check(server, owner, other, args.pdf, root, created_tasks)
            checks['real_running_cancellation'] = result['cancellation']['passed']
        if args.browser:
            node_env = os.environ.copy()
            node_env['NODE_PATH'] = str(Path.home() / '.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules')
            context = {'base_url': server.base, 'username': owner['username'], 'password': owner['password'],
                       'task_id': first, 'file_id': file_id, 'conversation_id': chat, 'user_id': owner['user_id'],
                       'output_directory': str(root), 'model_mode': args.model_mode,
                       'pdf_path': str(args.pdf.resolve()),
                       'outcome_statuses': [task['status'] for task in tasks]}
            probe = subprocess.run(['node', str(ROOT / 'tools/check_research_web_browser.cjs')],
                input=json.dumps(context), text=True, encoding='utf8', stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                cwd=ROOT, env=node_env, timeout=180)
            if probe.returncode != 0: raise CheckFailed('BROWSER_CHECK_FAILED')
            browser = json.loads(probe.stdout); result['browser'] = browser
            checks['browser'] = browser['passed']
        server.stop(); server.start()
        after = request(server.base, 'GET', detail, owner['token'])
        checks['restart_keeps_links_and_index_state'] = after.status_code == 200 and after.json()['file']['processing_state'] == 'indexed' and len(after.json()['file']['outcomes']) == 2
        restored_body = request(server.base, 'GET', prefix, owner['token']).json()
        restored = restored_body.get('task', restored_body)
        checks['restart_keeps_terminal_without_rerun'] = restored['status'] == tasks[0]['status'] and task_summary(restored)['model_calls'] == tasks[0]['model_calls']
        # Only our just-uploaded original; deliberately keep task copies and accounts for inspection.
        deleted = request(server.base, 'DELETE', '/api/files/delete/' + file_id, owner['token'])
        checks['delete_original_only'] = deleted.status_code == 200 and request(server.base, 'GET', detail, owner['token']).status_code == 404
        checks['old_report_survives_original_delete'] = all(request(server.base, 'GET', path, owner['token']).status_code == 200 for path in paths)
        server.stop(); server.start()
        checks['second_restart_keeps_private_report'] = (
            request(server.base, 'GET', prefix + '/report', owner['token']).status_code == 200
            and request(server.base, 'GET', prefix + '/report', other['token']).status_code == 404
            and request(server.base, 'GET', prefix + '/report').status_code == 401)
        body = request(server.base, 'GET', prefix, owner['token']).json()
        second = body.get('task', body)
        checks['second_restart_no_rerun'] = second['status'] == tasks[0]['status'] and task_summary(second)['model_calls'] == tasks[0]['model_calls']
        result['test_account_ids'] = [owner['user_id'], other['user_id']]
        result['passed'] = all(checks.values())
    except Exception as exc:
        result['passed'] = False
        result['error'] = str(exc) if isinstance(exc, CheckFailed) else 'VALIDATION_EXECUTION_FAILED'
        result['exception_type'] = type(exc).__name__
    finally:
        if owner and server.process and server.process.poll() is None:
            for task_id in created_tasks:
                try:
                    body = request(server.base, 'GET', '/api/science/tasks/' + task_id, owner['token']).json()
                    current = body.get('task', body)
                    if current.get('status') not in TERMINAL:
                        request(server.base, 'POST', '/api/science/tasks/' + task_id + '/cancel', owner['token'])
                except Exception: pass
        server.stop()
        result['billing_stop'] = paid_stopped
        result['test_accounts_retained'] = bool(owner or other)
        (root / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf8')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-id', required=True)
    parser.add_argument('--pdf', type=Path, required=True)
    parser.add_argument('--model-mode', choices=('mock', 'live'), default='mock')
    parser.add_argument('--browser', action='store_true')
    parser.add_argument('--mixed-followup', action='store_true', help='Explicitly allow public literature search for the second question only')
    args = parser.parse_args()
    import re
    if not re.fullmatch(r'[a-z0-9-]{1,80}', args.run_id) or not args.pdf.is_file() or args.pdf.is_symlink():
        parser.error('invalid run id or PDF')
    try: result = run(args)
    except Exception as exc: result = {'passed': False, 'error': 'VALIDATION_SETUP_FAILED', 'exception_type': type(exc).__name__}
    print(json.dumps(result, ensure_ascii=True))  # Reliable through legacy Windows console encodings.
    return 0 if result['passed'] else 1


if __name__ == '__main__': raise SystemExit(main())
