"""Zero-fee report layout proof: CLI, replay, exports, production browser code."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from multi_agent_presentation import build_presentation
from multi_agent_web import exported_report


def fixture():
    claims = [{'claim_id':'c1','group_id':'g1','text':'AI 生成图像检测可利用图像特征判断真伪。',
        'scope_note':'该表述仅限本轮演示片段，不构成通用性能承诺。',
        'qualification':'完整条件记录：各数据集与生成器划分必须分别核对。','evidence_ids':['e1','e2']},
        {'claim_id':'c2','group_id':'g2','text':'ViT 特征可用作检测线索，但不是所有检测方法都必须使用 ViT。',
         'qualification':'模型家族和具体变体需要区分，所选片段不能推出统一排名。','evidence_ids':['e3']}]
    refs = [{'citation':n,'evidence_id':'e'+str(n),'source':'uploaded_pdf','title':'演示论文 '+str(n),
        'paper_id':'','locator':{'page':n,'bbox':[10,20,40,60]},'review_status':'approved',
        'reviewed_group_ids':['g1' if n<3 else 'g2'],
        'excerpt': ('This is a synthetic evidence excerpt for layout checks only. '*12),
        'evidence_strength_label':'演示全文片段（非科研质量验证）',
        'page_image_asset':f'pages/evidence-{n}.png','page_size':[100,200],
        'preview_locator':{'bbox':[10,20,40,60],'page_size':[100,200],'notice':'演示定位框'}} for n in (1,2,3)]
    coverage = [{'group_id':'g1','metric':'definition','status':'partial','evidence_ids':['e1'],
        'missing_conditions':['仅描述真伪二分类任务，所选片段未给出统一正式定义。'],
        'comparability':'limited','recommended_action':'qualified_answer'},
        {'group_id':'g2','metric':'relation','status':'not_comparable','evidence_ids':['e3'],
         'missing_conditions':['不同数据集和骨干下的结果不能直接合并排名。']},
        {'metric':'role','status':'missing','missing_conditions':['另一个研究目标没有明确的片段对应关系。']}]
    coverage.append({**coverage[0],'metric':'role','evidence_ids':['e1','e2']})
    plan = {'groups':[{'id':'g1','heading':'AI 生成图像检测'},{'id':'g2','heading':'与 ViT 的关系'}]}
    data = {'status':'partial','claims':claims,'coverage':coverage,'references':refs,
        'audit_status':'passed','direct_answer':'### 直接回答\n\n'+claims[0]['text']+'[1][2]\n\n'+claims[1]['text']+'[3]'}
    data['presentation'] = build_presentation(claims,coverage,refs,plan)
    return data


def tree_hashes(root):
    return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in root.rglob('*') if p.is_file()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--label',required=True)
    parser.add_argument('--historical-run',type=Path)
    args = parser.parse_args()
    if not re.fullmatch('[a-z0-9-]{1,60}',args.label):
        parser.error('invalid label')
    root = ROOT/'logs/report_presentation_20261015'/args.label
    root.mkdir(parents=True,exist_ok=False)
    data = fixture()
    html = exported_report(data,'html')[0].decode('utf8')
    (root/'fixture_export.html').write_text(html,encoding='utf8')
    (root/'fixture_export.md').write_bytes(exported_report(data,'md')[0])
    payload = {'report':data,'html':html,'output':str(root)}
    browser = subprocess.run(['node',str(ROOT/'tools/check_report_presentation_browser.cjs')],
        input=json.dumps(payload),capture_output=True,text=True,encoding='utf8',timeout=120,env=os.environ)
    result = {'browser_exit':browser.returncode,'paid_vendor_calls':0,'production_5000_touched':False}
    if (root/'browser_checks.json').is_file():
        result['browser'] = json.loads((root/'browser_checks.json').read_text(encoding='utf8'))
    command = [sys.executable,str(ROOT/'tools/multi_agent_cli.py'),'run','--mode','mock','--query',
        'Explain a method','--run-id','presentation-cli','--output-root',str(root/'runs')]
    cli = subprocess.run(command,cwd=ROOT,capture_output=True,text=True,timeout=45)
    run = root/'runs/presentation-cli'
    result['cli_mock_exit'] = cli.returncode
    if cli.returncode == 0:
        before = tree_hashes(run)
        for action in ('inspect','replay'):
            check = subprocess.run([sys.executable,str(ROOT/'tools/multi_agent_cli.py'),action,'--run-dir',str(run)],
                cwd=ROOT,capture_output=True,text=True,timeout=45)
            result[action+'_exit'] = check.returncode
        result['new_run_unchanged'] = tree_hashes(run) == before
    if args.historical_run:
        source = args.historical_run.resolve()
        before = tree_hashes(source)
        check = subprocess.run([sys.executable,str(ROOT/'tools/multi_agent_cli.py'),'replay','--run-dir',str(source)],
            cwd=ROOT,capture_output=True,text=True,timeout=45)
        result['historical_replay_exit'] = check.returncode
        result['historical_hashes_unchanged'] = tree_hashes(source) == before
    from runtime_identity import source_fingerprint
    result['source_fingerprint'],result['source_complete'] = source_fingerprint()
    result['passed'] = (browser.returncode == cli.returncode == result.get('replay_exit') == result.get('inspect_exit') == 0
        and result.get('new_run_unchanged') is True and result.get('browser',{}).get('passed') is True
        and result.get('historical_replay_exit',0) == 0 and result.get('historical_hashes_unchanged',True))
    (root/'result.json').write_text(json.dumps(result,indent=2),encoding='utf8')
    print(json.dumps(result))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
