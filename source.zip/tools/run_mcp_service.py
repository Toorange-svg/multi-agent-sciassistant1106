"""Foreground shared MCP service; supervise independently of research tasks."""

import os
from pathlib import Path
import runpy
import sys

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    # This process IS the service, not a detached task descendant/wrapper.
    os.chdir(ROOT)
    from dotenv import load_dotenv
    load_dotenv(ROOT / ".env")
    (ROOT / "logs").mkdir(exist_ok=True)
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")
    entry = ROOT / "deepdiver_v2" / "src" / "tools" / "mcp_server_standard.py"
    sys.argv = [str(entry), *sys.argv[1:]]
    runpy.run_path(str(entry), run_name="__main__")


if __name__ == "__main__":
    main()
