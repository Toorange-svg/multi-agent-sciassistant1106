"""Collect version-bound source materials. Does not publish or attest legal completeness."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import tarfile
import urllib.request
import zipfile

PYMUPDF_VERSION = '1.28.2'
SDIST_SHA = '5e0be7908a715aa20333caddd73f1d6f01e4cd0c26e869fa2dd0b7f344da2249'
PROJECT_SHA = '726e8a3f90f455ddca74b6298ed42fd612fdf079601a48a06f83f857b3fa2993'
FINGERPRINT = '229806223f8c3afec8b055f56c295b53ba780d22c0e33e2c4977b5eea997ad00'
MUPDF_SHA = '44075a84e329db55b9bef5f342a70fd26d69e48ad1d33cb89d9664581c641156'


def download(url, target, expected, limit):
    if target.exists():
        if sha(target) == expected:
            return
        raise ValueError('EXISTING_SOURCE_HASH_MISMATCH')
    with urllib.request.urlopen(url, timeout=60) as response, target.open('xb') as stream:
        size = 0
        while block := response.read(1024 * 1024):
            size += len(block)
            if size > limit:
                raise ValueError('SOURCE_DOWNLOAD_TOO_LARGE')
            stream.write(block)
    if sha(target) != expected:
        raise ValueError('SOURCE_DOWNLOAD_HASH_MISMATCH')


def complete(output):
    report = json.loads((output / 'source-materials.json').read_text('utf-8'))
    source = output / ('pymupdf-' + PYMUPDF_VERSION + '.tar.gz')
    if sha(source) != SDIST_SHA or sha(output / 'sciassistant-a3ce456-source.zip') != PROJECT_SHA:
        raise ValueError('SOURCE_INPUT_HASH_MISMATCH')
    with tarfile.open(source) as bundle:
        setup = bundle.extractfile('pymupdf-' + PYMUPDF_VERSION + '/setup.py').read().decode('utf-8')
    if re.search(r"^version_mupdf = '([^']+)'", setup, re.M).group(1) != PYMUPDF_VERSION:
        raise ValueError('UPSTREAM_MUPDF_VERSION_MISMATCH')
    api = 'https://api.github.com/repos/ArtifexSoftware/mupdf-downloads/releases/tags/' + PYMUPDF_VERSION
    with urllib.request.urlopen(api, timeout=30) as response:
        release = json.load(response)
    name = 'mupdf-' + PYMUPDF_VERSION + '-source.tar.gz'
    item = next(a for a in release['assets'] if a['name'] == name)
    if item.get('digest') != 'sha256:' + MUPDF_SHA:
        raise ValueError('MUPDF_OFFICIAL_DIGEST_MISMATCH')
    download('https://mupdf.com/downloads/archive/' + name, output / name, MUPDF_SHA, 100 * 1024 * 1024)
    with tarfile.open(output / name) as bundle:
        names = bundle.getnames()
        prefix = name.removesuffix('.tar.gz') + '/'
        required = ['COPYING', 'Makefile', 'include/mupdf/fitz/version.h']
        if not all(prefix + n in names for n in required):
            raise ValueError('MUPDF_SOURCE_INCOMPLETE')
        header = bundle.extractfile(prefix + required[-1]).read().decode('utf-8')
        if '1.28.2' not in header:
            raise ValueError('MUPDF_HEADER_VERSION_MISMATCH')
        (output / 'MuPDF-COPYING').write_bytes(bundle.extractfile(prefix + 'COPYING').read())
        report.update({'mupdf_version': PYMUPDF_VERSION, 'mupdf_source_sha256': MUPDF_SHA,
            'mupdf_source_members': len(names),
            'mupdf_thirdparty_source_members': sum('/thirdparty/' in n for n in names),
            'mupdf_official_release_digest_verified': True})
    for relative in ('deploy/offline/README.md',):
        shutil.copyfile(Path(__file__).parents[1] / relative, output / 'OFFLINE_DEPLOYMENT.md')
    readme = Path(__file__).parents[1] / 'deploy/agpl/SOURCE_README.md'
    shutil.copyfile(readme, output / 'README.md')
    report['files'] = [{'path': p.name, 'size': p.stat().st_size, 'sha256': sha(p)}
                       for p in sorted(output.iterdir()) if p.is_file() and p.name != 'source-materials.json']
    (output / 'source-materials.json').write_text(json.dumps(report, indent=2) + '\n', 'utf-8')
    archive = output.with_suffix('.zip')
    if archive.exists():
        raise ValueError('OUTPUT_ARCHIVE_ALREADY_EXISTS')
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as bundle:
        for path in sorted(output.iterdir()):
            bundle.write(path, output.name + '/' + path.name)
    return {'archive': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive),
            'published': False, 'legal_completeness_attested': False}


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def collect(project_zip, output):
    if output.exists():
        raise ValueError('OUTPUT_ALREADY_EXISTS')
    if sha(project_zip) != PROJECT_SHA:
        raise ValueError('PROJECT_ARCHIVE_MISMATCH')
    with zipfile.ZipFile(project_zip) as bundle:
        manifest = json.loads(bundle.read('RELEASE_MANIFEST.json'))
        if manifest['source_fingerprint'] != FINGERPRINT:
            raise ValueError('SOURCE_FINGERPRINT_MISMATCH')
    with urllib.request.urlopen('https://pypi.org/pypi/PyMuPDF/' + PYMUPDF_VERSION + '/json', timeout=30) as response:
        metadata = json.load(response)
    item = next(r for r in metadata['urls'] if r['packagetype'] == 'sdist')
    if item['digests']['sha256'] != SDIST_SHA or not item['url'].startswith('https://files.pythonhosted.org/'):
        raise ValueError('UPSTREAM_SOURCE_MISMATCH')
    output.mkdir(parents=True)
    source = output / ('pymupdf-' + PYMUPDF_VERSION + '.tar.gz')
    request = urllib.request.Request(item['url'], headers={'User-Agent': 'SciAssistant-SourceDelivery/1.0'})
    with urllib.request.urlopen(request, timeout=60) as response, source.open('xb') as stream:
        size = 0
        while block := response.read(1024 * 1024):
            size += len(block)
            if size > item['size'] or size > 150 * 1024 * 1024:
                raise ValueError('SOURCE_DOWNLOAD_TOO_LARGE')
            stream.write(block)
    if sha(source) != SDIST_SHA or source.stat().st_size != item['size']:
        raise ValueError('SOURCE_DOWNLOAD_HASH_MISMATCH')
    shutil.copyfile(project_zip, output / 'sciassistant-a3ce456-source.zip')
    # Inspect source archives without executing setup.py or extracting paths.
    with tarfile.open(source) as bundle:
        names = bundle.getnames()
        embedded = [n for n in names if 'mupdf' in PurePosixPath(n).name.lower()
                    and n.endswith(('.tar.gz', '.tar.xz', '.tgz'))]
        licenses = [n for n in names if PurePosixPath(n).name.upper() in {'COPYING', 'LICENSE', 'LICENSE.AGPL'}]
        setup = next(n for n in names if n.endswith('/setup.py') and n.count('/') == 1)
        setup_text = bundle.extractfile(setup).read().decode('utf-8')
        report = {'schema': 'sciassistant.source-materials/v1', 'source_fingerprint': FINGERPRINT,
            'source_revision': manifest['source_head'], 'pymupdf_version': PYMUPDF_VERSION,
            'pypi_source_sha256': SDIST_SHA, 'project_source_sha256': PROJECT_SHA,
            'embedded_mupdf_archives': embedded, 'license_members': licenses,
            'setup_mupdf_lines': [line.strip() for line in setup_text.splitlines()
                                 if 'mupdf-' in line and ('tar' in line or 'version' in line)],
            'published': False, 'legal_completeness_attested': False,
            'private_configuration_included': False}
        for name in licenses:
            if name.count('/') == 1:
                (output / ('PyMuPDF-' + PurePosixPath(name).name)).write_bytes(bundle.extractfile(name).read())
    (output / 'source-materials.json').write_text(json.dumps(report, indent=2) + '\n', 'utf-8')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project-zip', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--complete', action='store_true')
    args = parser.parse_args()
    print(json.dumps(complete(args.output) if args.complete else collect(args.project_zip, args.output)))
