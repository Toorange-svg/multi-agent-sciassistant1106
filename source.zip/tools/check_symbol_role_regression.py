"""One isolated Auditor call against a preserved old claim and reviewed new text.

No source task mutation, no automatic publication, and not a full Workflow retry.
The trusted local operator must explicitly select the credential owner.
"""
from copy import deepcopy
from pathlib import Path
import argparse
import hashlib
import json
import os
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--old-run', type=Path, required=True)
    parser.add_argument('--source-run', type=Path, required=True)
    parser.add_argument('--credential-user')
    parser.add_argument('--diagnose-only', action='store_true', help='No model or network; source-backed code guard only')
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    old, source, output = args.old_run.resolve(), args.source_run.resolve(), args.output_dir.resolve()
    if any(not p.is_dir() or output.is_relative_to(p) or p.is_relative_to(output) for p in (old, source)):
        raise ValueError('output overlaps source or run missing')
    output.mkdir(parents=True, exist_ok=False)
    def hashes(folder):
        return {str(p.relative_to(folder)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in folder.rglob('*') if p.is_file()}
    before = [hashes(p) for p in (old, source)]
    from multi_agent_agents import ArtifactDirectory
    def load_run(folder):
        store = ArtifactDirectory(folder / 'artifacts')
        manifest = json.loads((folder / 'manifest.json').read_text(encoding='utf-8'))
        final = store.get(manifest['final_artifact_id'])
        return store, final['artifact_refs']
    past, past_refs = load_run(old)
    current, current_refs = load_run(source)
    draft = deepcopy(past.get(past_refs['draft']))
    draft['claims'] = [row for row in draft['claims'] if row['claim_id'] == 'c3']
    if len(draft['claims']) != 1 or draft['claims'][0].get('depends_on_claim_ids'):
        raise ValueError('expected independent preserved c3 claim')
    approved = current.get(current_refs['approved'])
    from multi_agent_quality import citation_audit_input, check_audit, check_symbol_roles
    if args.diagnose_only:
        findings = check_symbol_roles(draft, approved)
        corrected_draft = current.get(current_refs['draft'])
        corrected_findings = check_symbol_roles(corrected_draft, approved)
        receipt = {'schema_version': 'sciassistant.symbol-role-code-diagnosis/v1',
            'code_findings': findings, 'current_draft_findings': corrected_findings,
            'model_calls': 0, 'network_requests': 0,
            'source_hashes_unchanged': before == [hashes(p) for p in (old, source)],
            'workflow_retry_verified': False, 'published_back_to_source': False,
            'automatic_scientific_approval': False}
        (output / 'result.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
        print(json.dumps(receipt, ensure_ascii=False))
        return 0 if findings and not corrected_findings and receipt['source_hashes_unchanged'] else 1
    if not args.credential_user:
        raise ValueError('live audit requires explicit credential owner')
    audit_input = citation_audit_input(draft, approved)
    payload = {'input_artifacts': [past.get(past_refs['question']), draft, approved, audit_input,
        {'schema_version': 'sciassistant.research-source/v1', 'source_scope': 'uploaded_pdf'}]}
    input_path = output / 'audit_input.json'
    input_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    from dotenv import dotenv_values
    from user_credentials import CredentialStore, provider_scope
    values = {**dotenv_values(ROOT / 'deepdiver_v2/config/.env'), **dotenv_values(ROOT / '.env'), **os.environ}
    credentials = CredentialStore(values.get('SCIASSISTANT_USER_CREDENTIAL_DB', ROOT / 'logs/user_credentials.sqlite3'),
        values.get('USER_CREDENTIAL_ENCRYPTION_KEY') or values.get('SECRET_KEY'))
    cap = credentials.capability(args.credential_user)
    if not credentials.status(cap)['deepseek']['configured']:
        raise ValueError('USER_PROVIDER_KEY_REQUIRED')
    os.environ['MODEL_KEY_POOL_STATE_PATH'] = str(output / 'keys.sqlite3')
    from tools.multi_agent_cli import agent_command
    with provider_scope(cap):
        code = agent_command(argparse.Namespace(role='citation_auditor', mode='live', from_run=None,
            call_number=None, input_json=str(input_path), output_dir=str(output / 'role'), run_id='symbol-role-regression'))
    result = json.loads((output / 'role/agent_result.json').read_text(encoding='utf-8'))
    audit = ArtifactDirectory(output / 'role/artifacts').get(result['output_artifact_ids'][-1]) if code == 0 else {}
    checked = check_audit(audit, draft, approved) if code == 0 else {}
    rows = checked.get('claim_results') or []
    verdict = next((row for row in rows if row.get('claim_id') == 'c3'), {})
    receipt = {'schema_version': 'sciassistant.symbol-role-regression/v1',
        'agent_exit': code, 'model_calls': result.get('usage', {}).get('model_calls'),
        'elapsed_ms': result.get('usage', {}).get('elapsed_ms'), 'status': result.get('status'),
        'audit_decision': verdict.get('decision'), 'reason_code': verdict.get('reason_code'),
        'contract_errors': checked.get('contract_errors', []),
        'scientific_counterexample_rejected': verdict.get('decision') == 'rejected' and not checked.get('contract_errors'),
        'source_hashes_unchanged': before == [hashes(p) for p in (old, source)],
        'workflow_retry_verified': False, 'published_back_to_source': False}
    (output / 'result.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(receipt, ensure_ascii=False))
    return 0 if receipt['scientific_counterexample_rejected'] and receipt['source_hashes_unchanged'] else 1


if __name__ == '__main__':
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    raise SystemExit(main())
