"""Validate the cloud dependency lock and record the installed environment.

The report contains package names and versions only. It never reads environment
variables, credentials, application data, or network resources.
"""
import argparse
import hashlib
from importlib import metadata
import json
from pathlib import Path
import re
import sys


SCHEMA = "sciassistant.dependency-lock/v2"
BASE_ALLOWLIST = {"pip", "setuptools", "wheel"}
PIN = re.compile(r"^([A-Za-z0-9][A-Za-z0-9._-]*)(?:\[[^]]+\])?==([^\s;]+)$")
HASH_PIN = re.compile(
    r"^([A-Za-z0-9][A-Za-z0-9._-]*)==([^\s;]+) --hash=sha256:([0-9a-f]{64})$")
NAME = re.compile(r"^([A-Za-z0-9][A-Za-z0-9._-]*)(?:\[[^]]+\])?")


def canonical_name(value):
    return re.sub(r"[-_.]+", "-", value).lower()


def lock_digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def parse_constraints(path):
    packages, errors = {}, []
    for number, raw in enumerate(Path(path).read_text(encoding="utf-8").splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        match = PIN.fullmatch(line)
        if not match:
            errors.append(f"invalid_constraint_line:{number}")
            continue
        name, version = canonical_name(match.group(1)), match.group(2)
        if name in packages:
            errors.append(f"duplicate_constraint:{name}")
        packages[name] = version
    if list(packages) != sorted(packages):
        errors.append("constraints_not_sorted")
    return packages, errors


def parse_hash_requirements(path):
    packages, errors = {}, []
    for number, raw in enumerate(Path(path).read_text(encoding="utf-8").splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        match = HASH_PIN.fullmatch(line)
        if not match:
            errors.append(f"invalid_hash_line:{number}")
            continue
        name = canonical_name(match.group(1))
        if name in packages:
            errors.append(f"duplicate_hash_pin:{name}")
        packages[name] = (match.group(2), match.group(3))
    if list(packages) != sorted(packages):
        errors.append("hash_requirements_not_sorted")
    return packages, errors


def direct_names(path, seen=None):
    path = Path(path).resolve()
    seen = set() if seen is None else seen
    if path in seen:
        raise ValueError("recursive_requirement_include")
    seen.add(path)
    names = set()
    for number, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith(("-r ", "--requirement ")):
            include = line.split(maxsplit=1)[1]
            names.update(direct_names(path.parent / include, seen))
            continue
        if line.startswith("-") or " @ " in line or "://" in line:
            raise ValueError(f"unsafe_requirement_line:{path.name}:{number}")
        match = NAME.match(line)
        if not match:
            raise ValueError(f"invalid_requirement_line:{path.name}:{number}")
        names.add(canonical_name(match.group(1)))
    return names


def report(passed, checks, digest="", constraints_digest="", package_count=0):
    return {"schema": SCHEMA, "passed": bool(passed), "sha256": digest,
            "constraints_sha256": constraints_digest,
            "package_count": package_count, "checks": checks}


def check_lock(requirements, cloud_requirements, constraints, hash_requirements):
    try:
        packages, errors = parse_constraints(constraints)
        hashes, hash_errors = parse_hash_requirements(hash_requirements)
        required = direct_names(requirements) | direct_names(cloud_requirements)
    except (OSError, UnicodeError, ValueError) as error:
        return report(False, [{"check": type(error).__name__, "passed": False}])
    checks = [
        {"check": "strict_exact_pins", "passed": not errors},
        {"check": "all_direct_dependencies_constrained", "passed": required <= set(packages)},
        {"check": "lock_has_packages", "passed": bool(packages)},
        {"check": "strict_sha256_pins", "passed": not hash_errors},
        {"check": "artifact_set_matches_constraints", "passed": set(hashes) == set(packages)},
        {"check": "artifact_versions_match_constraints", "passed": all(
            hashes.get(name, (None,))[0] == version for name, version in packages.items())},
    ]
    return report(all(item["passed"] for item in checks), checks,
                  lock_digest(hash_requirements), lock_digest(constraints), len(packages))


def installed_packages():
    packages = {}
    for distribution in metadata.distributions():
        name = distribution.metadata.get("Name")
        if name:
            packages[canonical_name(name)] = distribution.version
    return packages


def verify_installed(constraints, hash_requirements, output=None, base_image="", target_platform=""):
    try:
        locked, errors = parse_constraints(constraints)
        hashes, hash_errors = parse_hash_requirements(hash_requirements)
        installed = installed_packages()
    except (OSError, UnicodeError, ValueError) as error:
        return report(False, [{"check": type(error).__name__, "passed": False}])
    missing = sorted(set(locked) - set(installed))
    mismatched = sorted(name for name, version in locked.items()
                        if installed.get(name) not in {None, version})
    unexpected = sorted(set(installed) - set(locked) - BASE_ALLOWLIST)
    checks = [
        {"check": "lock_syntax", "passed": not errors},
        {"check": "artifact_hash_syntax", "passed": not hash_errors},
        {"check": "artifact_lock_matches_versions", "passed": (
            set(hashes) == set(locked) and all(
                hashes.get(name, (None,))[0] == version for name, version in locked.items()))},
        {"check": "locked_packages_installed", "passed": not missing},
        {"check": "installed_versions_match", "passed": not mismatched},
        {"check": "no_unlocked_runtime_packages", "passed": not unexpected},
    ]
    result = report(all(item["passed"] for item in checks), checks,
                    lock_digest(hash_requirements), lock_digest(constraints), len(locked))
    if result["passed"] and output:
        payload = {"schema": SCHEMA, "sha256": result["sha256"],
                   "constraints_sha256": result["constraints_sha256"],
                   "package_count": result["package_count"],
                   "python": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
                   "base_image": base_image, "platform": target_platform}
        Path(output).write_text(json.dumps(payload, sort_keys=True), encoding="utf-8")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    check_parser = commands.add_parser("check")
    check_parser.add_argument("--requirements", type=Path, required=True)
    check_parser.add_argument("--cloud-requirements", type=Path, required=True)
    check_parser.add_argument("--constraints", type=Path, required=True)
    check_parser.add_argument("--hash-requirements", type=Path, required=True)
    verify_parser = commands.add_parser("verify-installed")
    verify_parser.add_argument("--constraints", type=Path, required=True)
    verify_parser.add_argument("--hash-requirements", type=Path, required=True)
    verify_parser.add_argument("--output", type=Path)
    verify_parser.add_argument("--base-image", default="")
    verify_parser.add_argument("--target-platform", default="")
    args = parser.parse_args()
    if args.command == "check":
        result = check_lock(args.requirements, args.cloud_requirements, args.constraints,
                            args.hash_requirements)
    else:
        result = verify_installed(args.constraints, args.hash_requirements, args.output,
                                  args.base_image, args.target_platform)
    print(json.dumps(result, sort_keys=True))
    return 0 if result["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
