"""Standalone retrieval-chain inspection UI (port 5080).

This tool is intentionally separate from the 5000/5050 applications. It
visualizes planning and query construction, and only performs external search
when the user explicitly clicks the search button.
"""
from __future__ import annotations

import json
import ipaddress
import os
import re
import sys
import threading
import time
import uuid
from pathlib import Path
from urllib.parse import urlsplit

from flask import Flask, jsonify, request, render_template_string, Response

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from deepdiver_v2.cli.demo import _plan_literature_queries  # noqa: E402
from deepdiver_v2.config.config import get_config  # noqa: E402
from deepdiver_v2.src.literature_sources import (  # noqa: E402
    SOURCE_ORDER,
    disabled_source_notice,
    search_source,
)
from deepdiver_v2.cli.demo import _score_by_groups, CURRENT_QUERY_GROUPS  # noqa: E402
from deepdiver_v2.src.query_router import (  # noqa: E402
    DIRECT_LIMITATION_EVIDENCE_TERMS,
    GENERIC_QUERY_TERMS,
    RELEVANCE_THRESHOLD,
    _concept_matches,
    is_limitation_query,
    requested_concepts,
    score_literature_relevance,
)
from deepdiver_v2.src.tools.mcp_tools import MCPTools  # noqa: E402

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 256 * 1024
QUEUE_LOCK = threading.RLock()
QUEUES: dict[str, dict] = {}
MAX_QUERY_CHARS = 20_000


def _loopback_literal(value: str | None) -> bool:
    candidate = str(value or "").strip().strip("[]")
    if candidate.lower() == "localhost":
        return True
    try:
        return ipaddress.ip_address(candidate).is_loopback
    except ValueError:
        return False


def _configured_debug_host(raw_value: str | None = None) -> str:
    """Return a literal loopback bind or fail closed.

    The debug UI exposes provider envelopes and can launch paid retrieval, so
    it must never be made remotely reachable through an environment override.
    """
    host = str(
        os.getenv("RETRIEVAL_DEBUG_HOST", "127.0.0.1")
        if raw_value is None else raw_value
    ).strip()
    if not _loopback_literal(host):
        raise RuntimeError("RETRIEVAL_DEBUG_HOST 必须是本机回环地址")
    return host


def _request_host_is_loopback() -> bool:
    try:
        return _loopback_literal(urlsplit(f"//{request.host}").hostname)
    except ValueError:
        return False


@app.before_request
def _require_local_debug_request():
    # Never trust X-Forwarded-For here. The actual socket peer and Host must
    # both be loopback, which also blocks DNS-rebinding access to this UI.
    if not _loopback_literal(request.remote_addr) or not _request_host_is_loopback():
        return jsonify({"error": "LOCAL_ACCESS_REQUIRED"}), 403
    origin = request.headers.get("Origin")
    if origin and request.method not in {"GET", "HEAD", "OPTIONS"}:
        parsed = urlsplit(origin)
        expected = urlsplit(request.host_url)
        if (
            parsed.scheme not in {"http", "https"}
            or parsed.scheme != expected.scheme
            or parsed.netloc != expected.netloc
            or not _loopback_literal(parsed.hostname)
        ):
            return jsonify({"error": "SAME_ORIGIN_REQUIRED"}), 403
    return None


@app.after_request
def _secure_debug_response(response):
    response.headers["Cache-Control"] = "no-store"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Cross-Origin-Opener-Policy"] = "same-origin"
    response.headers["Cross-Origin-Resource-Policy"] = "same-origin"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; base-uri 'none'; frame-ancestors 'none'; "
        "form-action 'self'; img-src 'self' data:; connect-src 'self'; "
        "style-src 'unsafe-inline'; script-src 'unsafe-inline'"
    )
    return response


@app.errorhandler(413)
def _payload_too_large(_error):
    return jsonify({"error": "PAYLOAD_TOO_LARGE"}), 413


def _plain_terms(value: str) -> str:
    terms = []
    generic = {
        "all", "ti", "abs", "and", "or", "not", "andnot",
        "method", "methods", "analysis", "evaluation", "benchmark",
        "experiment", "experiments", "comparison", "compare",
    }
    for quoted, bare in re.findall(r'"([^"]+)"|([A-Za-z][A-Za-z0-9-]{2,})', value or ""):
        term = (quoted or bare).strip()
        if term.lower() in generic:
            continue
        if term and term.lower() not in {x.lower() for x in terms}:
            terms.append(term)
    return " ".join(terms[:10])


def _compact_query(value: str, limit: int = 600) -> str:
    """Reduce an arXiv boolean expression to comparable free-text terms."""
    terms = []
    generic = {
        "all", "ti", "abs", "and", "or", "not", "andnot",
        "method", "methods", "analysis", "evaluation", "benchmark",
        "experiment", "experiments", "comparison", "compare",
    }
    for quoted, bare in re.findall(r'"([^"]+)"|([A-Za-z][A-Za-z0-9-]{2,})', str(value or "")):
        term = (quoted or bare).strip()
        if not term or term.lower() in generic:
            continue
        if term.lower() not in {item.lower() for item in terms}:
            terms.append(term)
    return " ".join(terms)[:limit]


def _semantic_gate_label(score: float, accepted: bool) -> str:
    """Bucket the raw score so a report can be read at a glance."""
    if not accepted:
        return "rejected"
    if score >= 0.65:
        return "strong"
    if score >= 0.45:
        return "partial"
    return "weak"


def _semantic_gate_reason(query: str, paper: dict, verdict: dict) -> str:
    """Explain a gate decision in one line, in the gate's own vocabulary."""
    score = float(verdict.get("score") or 0.0)
    if verdict.get("accepted"):
        matched = [str(item) for item in (verdict.get("matched_concepts") or [])]
        if matched:
            return f"accepted: matched concept(s) {', '.join(matched[:4])}"
        title_hits = [str(item) for item in (verdict.get("title_matched") or [])]
        if title_hits:
            return f"accepted: title evidence {', '.join(title_hits[:4])}"
        abstract_hits = [str(item) for item in (verdict.get("abstract_matched") or [])]
        if abstract_hits:
            return f"accepted: abstract evidence {', '.join(abstract_hits[:4])}"
        return "accepted: threshold met"
    if score < RELEVANCE_THRESHOLD:
        return f"below-threshold: score {score:.2f} < {RELEVANCE_THRESHOLD}"
    text = " ".join(
        str(paper.get(key) or "") for key in ("title", "abstract", "venue")
    ).lower()
    # Nothing in the candidate matched the question's own vocabulary. This is
    # the shape a cross-domain hit takes when the query carried only a common
    # word (``world model``, ``Mamba``), which is what this report is for.
    question_terms = {
        token.lower()
        for token in re.findall(r"[A-Za-z][A-Za-z0-9-]{2,}", _compact_query(query))
        if token.lower() not in GENERIC_QUERY_TERMS
    }
    if question_terms and not any(term in text for term in question_terms):
        return "cross-domain: no-entity-match with the question"
    if not verdict.get("matched_concepts"):
        return "no-entity-match: no requested concept appears in title/abstract"
    hard_terms = [str(item) for item in (verdict.get("hard_explicit_terms") or [])]
    if hard_terms:
        return (
            "off-topic: named object missing ("
            + ", ".join(hard_terms[:3])
            + ")"
        )
    return "off-topic: score high enough but no accepted concept coverage"


def _ledger_rank_key(row: dict) -> tuple:
    """Order candidates the way the real chain prefers evidence."""
    return (
        not row["accepted"],
        -(row.get("score") or 0.0),
        -(row.get("explicit_hits") or 0),
    )


def _build_evidence_ledger(query: str, gate_rows: list[dict]) -> dict:
    """Reproduce the citation ledger the real chain builds for an answer.

    ``demo.py`` keeps accepted papers, de-duplicates versioned IDs per source,
    caps the set at fifteen and numbers them ``[1..n]`` in that order. This
    layer applies the same rules to the debug run's candidates so a reviewer
    can see which papers would actually be cited, and in which order.
    """
    accepted = [dict(row) for row in gate_rows if row.get("accepted")]
    accepted.sort(key=_ledger_rank_key)
    entries = []
    seen: set[str] = set()
    for rank, row in enumerate(accepted, 1):
        paper_id = str(row.get("paper_id") or "").strip()
        source = str(row.get("source") or "").strip().lower()
        identity = f"{source}:{paper_id.lower().split('v', 1)[0]}"
        if paper_id and identity in seen:
            continue
        if paper_id:
            seen.add(identity)
        entries.append({
            "citation": f"[{rank}]",
            "source": row.get("source", ""),
            "paper_id": paper_id,
            "title": row.get("title", ""),
            "score": row.get("score"),
            "label": row.get("label", ""),
            "matched_concepts": row.get("matched_concepts") or [],
            "core_concept_coverage": row.get("core_concept_coverage", 0),
        })
    capped = entries[:15]
    return {
        "accepted_total": len(entries),
        "entries": capped,
        "truncated": len(entries) > len(capped),
        "ranked_by": "accepted first, then score desc, then explicit hits desc",
        "fill_rate": round(len(capped) / len(gate_rows), 4) if gate_rows else 0.0,
        "weak_in_ledger": sum(1 for item in capped if item["label"] == "weak"),
    }


def _matched_anchor_field(paper: dict, term: str) -> str:
    """Report which field a concrete term was found in."""
    term = str(term or "").lower()
    if not term:
        return ""
    if term in str(paper.get("title") or "").lower():
        return "title"
    if term in str(paper.get("abstract") or "").lower():
        return "abstract"
    return ""


def _build_match_details(query: str, gate_rows: list[dict]) -> dict:
    """Rebuild the gate's scoring arithmetic for every candidate.

    The gate is a conservative lexical decision, so its arithmetic is the
    fastest way to see why a genuinely relevant paper scored low: whether the
    question matched any requested concept, which explicit term was missing,
    and how much of the score came from each contribution.

    ``score_breakdown`` is a local decomposition, not a value read back from
    the gate. It sums to the gate's own ``score`` for concept-based verdicts;
    limitation-query bonus terms are reported separately because they also
    raise the gate's score.
    """
    query_lower = str(query or "").lower()
    requested = sorted(requested_concepts(query))
    generic_relation_concepts = {"alignment", "video", "sequence", "memory"}
    specific_requested = [item for item in requested if item not in generic_relation_concepts]
    limitation_query = is_limitation_query(query)
    details = []
    for row in gate_rows:
        paper = row["paper"]
        title = str(paper.get("title") or "").lower()
        abstract = str(paper.get("abstract") or "").lower()
        matched = [str(item) for item in (row.get("matched_concepts") or [])]
        title_matched = [item for item in matched if _concept_matches(title, item)]
        abstract_matched = [item for item in matched if _concept_matches(abstract, item)]
        coverage = len(set(matched))
        breakdown = {
            "concept_title_component": round(0.45 * min(len(title_matched), 2) / 2, 4),
            "concept_abstract_component": round(0.25 * min(len(abstract_matched), 3) / 3, 4),
            "concept_coverage_component": round(0.30 * min(coverage, 3) / 3, 4),
        }
        if title_matched:
            breakdown["title_exact_floor"] = 0.40
        intent_groups = {
            "definition": ("definition", "architecture", "framework", "introduce", "propose"),
            "mechanism": ("mechanism", "method", "attention", "retrieval", "algorithm"),
            "comparison": ("comparison", "compare", "advantage", "limitation"),
            "experiment": ("experiment", "benchmark", "evaluation", "result"),
        }
        haystack = f"{title} {abstract}"
        intent_hits = [
            name for name, terms in intent_groups.items()
            if any(term in query_lower for term in terms)
            and any(term in haystack for term in terms)
        ]
        if intent_hits:
            breakdown["intent_component"] = round(0.08 * min(len(intent_hits), 2), 4)
        limitation_hits = [
            term for term in DIRECT_LIMITATION_EVIDENCE_TERMS
            if term.isascii() and term in haystack
        ]
        if limitation_query and limitation_hits:
            breakdown["limitation_component"] = 0.12
        explicit_terms = [str(item) for item in (row.get("explicit_terms") or [])]
        hard_terms = [str(item) for item in (row.get("hard_explicit_terms") or [])]
        details.append({
            "title": row.get("title", ""),
            "paper_id": row.get("paper_id", ""),
            "source": row.get("source", ""),
            "score": row.get("score"),
            "accepted": row["accepted"],
            "requested_concepts": requested,
            "matched_concepts": matched,
            "unmatched_requested_concepts": [item for item in requested if item not in matched],
            "title_matched": title_matched,
            "abstract_matched": abstract_matched,
            "concept_coverage": coverage,
            "core_concept_coverage": row.get("core_concept_coverage", 0),
            "specific_requested": specific_requested,
            "contains_specific_requested": bool(set(matched) & set(specific_requested)),
            "limitation_query": limitation_query,
            "limitation_hits": limitation_hits,
            "explicit_terms": explicit_terms,
            "explicit_anchors": [
                {"term": term, "field": _matched_anchor_field(paper, term)}
                for term in explicit_terms
            ],
            "hard_explicit_terms": hard_terms,
            "missing_hard_explicit_terms": [
                term for term in hard_terms
                if not _matched_anchor_field(paper, term)
            ],
            "intent_matches": intent_hits,
            # Deliberately NOT a reverse-engineered total. The gate is the
            # source of truth for ``score`` and ``accepted``; this breakdown
            # only names the individual contributions that are visible from
            # outside, so it is never summed into a competing score.
            "score_breakdown": breakdown,
        })
    return {"query": query, "requested_concepts": requested, "candidates": details}


def _scoring_query(original_query: str, keyword_query: str = "") -> str:
    """Build the text the real retrieval chain feeds to the relevance gate.

    ``demo.py`` scores each candidate against the question plus the generated
    route (``scoring_query = f"{score_query} {search_query}"``). The original
    question is always included, so this helper reproduces that pair rather
    than substituting one side for the other.

    Substituting the generated keywords for the original question would drop
    the question's own terminology; scoring the raw question alone is equally
    wrong, because a plain-language question can carry no matchable concept.
    """
    parts = [
        str(part).strip()
        for part in (original_query, keyword_query)
        if str(part or "").strip()
    ]
    # Preserve order while removing exact duplicates.
    return " ".join(dict.fromkeys(parts))


def _semantic_gate_rows(query: str, search: dict, keyword_query: str = "") -> list[dict]:
    """Score every raw candidate with the gate the real chain applies.

    This is a read-only view: the debug report keeps the raw recall untouched
    so a reviewer can compare what the source returned against what the real
    retrieval chain would have kept.
    """
    rows = []
    scoring_query = _scoring_query(query, keyword_query)
    for name, data in (search or {}).items():
        for paper in data.get("papers") or []:
            if not isinstance(paper, dict):
                continue
            verdict = score_literature_relevance(scoring_query, paper)
            # Group-based scoring override
            gv = _score_by_groups(paper)
            group_info = {}
            if gv:
                group_info = {
                    "group_score": gv["score"],
                    "group_accepted": gv["accepted"],
                    "group_scores": gv["group_scores"],
                    "passed_groups": gv["passed_groups"],
                    "total_groups": gv["total_groups"],
                }
                if gv["accepted"]:
                    verdict["accepted"] = True
                    verdict["score"] = gv["score"]
            rows.append({
                "title": paper.get("title", ""),
                "paper_id": paper.get("paper_id", "") or paper.get("id", ""),
                "source": paper.get("source") or name,
                "score": verdict.get("score"),
                "accepted": bool(verdict.get("accepted")),
                "label": _semantic_gate_label(
                    float(verdict.get("score") or 0.0), bool(verdict.get("accepted"))
                ),
                # ``degraded`` means no English terminology could be resolved
                # for the question, so a 0.0 score reflects an unmatchable
                # question rather than an absent relevant paper.
                "scoring_status": verdict.get("scoring_status"),
                "unresolved_terms": verdict.get("unresolved_terms") or [],
                "reason": _semantic_gate_reason(scoring_query, paper, verdict),
                "matched_concepts": verdict.get("matched_concepts") or [],
                "concept_coverage": verdict.get("concept_coverage", 0),
                "core_concept_coverage": verdict.get("core_concept_coverage", 0),
                "title_matched": verdict.get("title_matched") or [],
                "abstract_matched": verdict.get("abstract_matched") or [],
                "explicit_terms": verdict.get("explicit_terms") or [],
                "explicit_hits": len(verdict.get("explicit_hits") or []),
                "hard_explicit_terms": verdict.get("hard_explicit_terms") or [],
                "group_info": group_info,
                "paper": paper,
            })
    rows.sort(key=lambda item: (not item["accepted"], -(item["score"] or 0.0)))
    return rows


def inspect_query(query: str, do_search: bool = False) -> dict:
    config = get_config()
    trace: dict = {}
    plan, source = _plan_literature_queries(query, "arxiv", config, trace=trace)
    phrases = [str(item.get("query", "")).strip() for item in plan if item.get("query")]
    arxiv_queries = []
    try:
        formatter = MCPTools()
        for phrase in phrases:
            arxiv_queries.extend(formatter._normalize_arxiv_query(phrase))
    except Exception as exc:
        trace["arxiv_format_error"] = f"{type(exc).__name__}: {exc}"
    arxiv_queries = list(dict.fromkeys(arxiv_queries))[:30]
    source_queries = {name: [_plain_terms(p) or p for p in phrases[:10]] for name in ("arxiv", "zenodo", "techrxiv", "hal")}
    result = {
        "query": query,
        "planner_source": source,
        "trace": trace,
        "final_plan": plan,
        "final_keywords": phrases,
        "arxiv_queries": arxiv_queries,
        "source_queries": source_queries,
        "search": {},
        "semantic_gate": [],
        "evidence_ledger": {},
        "match_details": {},
    }
    if do_search:
        # One request per source and the first three routes keeps this audit
        # bounded and respects each adapter's independent throttle.
        for name in ("arxiv", "zenodo", "techrxiv", "hal"):
            query_value = arxiv_queries[0] if name == "arxiv" and arxiv_queries else (source_queries[name][0] if source_queries[name] else query)
            response = search_source(name, query_value, limit=3)
            result["search"][name] = {
                "request_query": query_value,
                "status": response.get("status"),
                "http_status": response.get("http_status"),
                "elapsed_ms": response.get("elapsed_ms"),
                # A per-source report needs to show why a source produced
                # nothing: how many transport retries were spent, and, when a
                # source is out of rotation, the recorded reason and the time
                # it left rotation.
                "retry_count": response.get("retry_count", 0),
                "retry_count_is_exact": response.get("retry_count_is_exact", True),
                "failure_status": response.get("failure_status"),
                "disabled_reason": response.get("disabled_reason", ""),
                "disabled_at": response.get("disabled_at", ""),
                "error": response.get("error"),
                "papers": response.get("papers", []),
            }
        # The real retrieval chain runs score_literature_relevance over every
        # candidate before anything can be cited. The raw recall above is kept
        # unchanged; this layer shows what that gate would have decided.
        # The gate input mirrors demo.py: the question plus the generated
        # route, never the arXiv boolean expression and never the model
        # keyword list on its own.
        gate_query = _scoring_query(
            query,
            result["source_queries"]["arxiv"][0] if result["source_queries"].get("arxiv") else "",
        )
        gate_rows = _semantic_gate_rows(query, result["search"], keyword_query=gate_query)
        result["gate_query"] = gate_query
        result["semantic_gate"] = gate_rows
        result["evidence_ledger"] = _build_evidence_ledger(gate_query, gate_rows)
        result["match_details"] = _build_match_details(gate_query, gate_rows)
    return result


def _queue_worker(queue_id: str) -> None:
    while True:
        with QUEUE_LOCK:
            queue = QUEUES.get(queue_id)
            if not queue:
                return
            next_item = next((item for item in queue["items"] if item["status"] == "queued"), None)
            if next_item is None:
                queue["status"] = "completed"
                queue["finished_at"] = time.time()
                return
            next_item["status"] = "running"
            next_item["started_at"] = time.time()
            query = next_item["query"]
        try:
            result = inspect_query(query, True)
            with QUEUE_LOCK:
                next_item["status"] = "completed"
                next_item["result"] = result
                next_item["finished_at"] = time.time()
        except Exception as exc:  # noqa: BLE001
            with QUEUE_LOCK:
                next_item["status"] = "failed"
                next_item["error"] = f"{type(exc).__name__}: {exc}"
                next_item["finished_at"] = time.time()


def _compact_queue(queue: dict) -> dict:
    """Reduce a queue to status, scores and decisions, dropping bulk payloads.

    The full report embeds every paper's ``raw`` provider envelope and the
    complete planner trace, which makes a 10-question run hundreds of
    kilobytes. Compact mode keeps everything needed to judge whether a source
    worked and whether a decision was right, and drops what is only needed for
    deep inspection.
    """
    compact_items = []
    for item in queue.get("items", []):
        result = item.get("result") or {}
        search = {}
        for source, data in (result.get("search") or {}).items():
            search[source] = {
                "status": data.get("status"),
                "http_status": data.get("http_status"),
                "elapsed_ms": data.get("elapsed_ms"),
                "retry_count": data.get("retry_count", 0),
                "retry_count_is_exact": data.get("retry_count_is_exact", True),
                "failure_status": data.get("failure_status"),
                "disabled_reason": data.get("disabled_reason", ""),
                "disabled_at": data.get("disabled_at", ""),
                "error": data.get("error"),
                "paper_count": len(data.get("papers") or []),
                "titles": [paper.get("title", "") for paper in (data.get("papers") or [])],
            }
        compact_items.append({
            "index": item.get("index"),
            "query": item.get("query"),
            "status": item.get("status"),
            "error": item.get("error"),
            "final_keywords": result.get("final_keywords", []),
            "planner_source": result.get("planner_source"),
            "search": search,
            "semantic_gate": [
                {key: row.get(key) for key in
                 ("title", "paper_id", "source", "score", "label", "scoring_status",
                  "accepted", "reason")}
                for row in (result.get("semantic_gate") or [])
            ],
            "evidence_ledger": result.get("evidence_ledger"),
        })
    return {
        "id": queue.get("id"),
        "status": queue.get("status"),
        "disabled_source_notices": queue.get("disabled_source_notices") or [],
        "items": compact_items,
    }


def _compact_markdown(queue: dict) -> str:
    """Render the compact view as Markdown for a human reading the report."""
    compact = _compact_queue(queue)
    lines = [
        "# SciAssistant 检索队列报告（精简）",
        "",
        f"- 队列 ID：`{compact['id']}`",
        f"- 状态：`{compact['status']}`",
        "- 说明：精简模式不内嵌各来源的原始响应与完整规划链路；需要排查细节时使用完整报告。",
        "",
    ]
    for notice in compact["disabled_source_notices"]:
        lines.extend([f"- 提示：{notice}", ""])
    for item in compact["items"]:
        lines.extend([f"## {item['index']}. {item['query']}", "", f"- 状态：`{item['status']}`", ""])
        if item.get("error"):
            lines.extend([f"- 错误：`{item['error']}`", ""])
            continue
        lines.extend(["| 来源 | 状态 | HTTP | 耗时(ms) | 重试 | 重试精确 | 论文数 |",
                      "|---|---|---|---|---|---|---|"])
        for source, data in item["search"].items():
            lines.append(
                f"| {source} | {data['status']} | {data['http_status']} | {data['elapsed_ms']} "
                f"| {data['retry_count']} | {str(data['retry_count_is_exact']).lower()} "
                f"| {data['paper_count']} |"
            )
        lines.append("")
        gate = item["semantic_gate"]
        if gate:
            lines.extend(["| 论文 | 来源 | 分数 | 标签 | 判定 |", "|---|---|---|---|---|"])
            for row in gate:
                lines.append(
                    f"| {row['title'][:60]} | {row['source']} | {row['score']} "
                    f"| {row['label']} | {'接受' if row['accepted'] else '拒绝'} |"
                )
            lines.append("")
    return "\n".join(lines)


def _queue_markdown(queue: dict) -> str:
    lines = ["# SciAssistant 检索队列报告", "", f"- 队列 ID：`{queue['id']}`", f"- 状态：`{queue['status']}`", ""]
    for notice in queue.get("disabled_source_notices") or []:
        lines.extend([f"- 提示：{notice}", ""])
    for index, item in enumerate(queue["items"], 1):
        lines.extend([f"## {index}. {item['query']}", "", f"- 状态：`{item['status']}`"])
        if item.get("error"):
            lines.extend([f"- 错误：`{item['error']}`", ""])
            continue
        result = item.get("result") or {}
        lines.extend(["", "### 最终关键词", "", *[f"- {x}" for x in result.get("final_keywords", [])]])
        lines.extend(["", "### arXiv 查询", "", *[f"- `{x}`" for x in result.get("arxiv_queries", [])]])
        lines.extend(["", "### 各来源查询", "", "```json", json.dumps(result.get("source_queries", {}), ensure_ascii=False, indent=2), "```", ""])
        lines.append("### 真实召回结果")
        for source, data in (result.get("search") or {}).items():
            status_text = data.get("status") or ""
            if data.get("failure_status"):
                status_text += f" / {data['failure_status']}"
            lines.extend(["", f"#### {source}", "", f"- 状态：`{status_text}`", f"- HTTP：`{data.get('http_status')}`", f"- 耗时：`{data.get('elapsed_ms')} ms`", f"- 重试次数：`{data.get('retry_count', 0)}`", f"- 请求词：`{data.get('request_query')}`"])
            if data.get("disabled_reason"):
                lines.append(f"- 停用原因：`{data['disabled_reason']}`")
            if data.get("disabled_at"):
                lines.append(f"- 停用于：`{data['disabled_at']}`")
            if data.get("error"):
                lines.append(f"- 错误：`{data['error']}`")
            for paper in data.get("papers") or []:
                lines.append(f"- {paper.get('title','')} ({paper.get('paper_id','')}) {paper.get('landing_url') or paper.get('url','')}")
        gate_rows = result.get("semantic_gate") or []
        lines.extend(["", "### 语义门控结果", ""])
        if not gate_rows:
            lines.append("本次没有可评分的原始召回候选（无召回、来源不可达或全部被拒于源侧）。")
        else:
            accepted = sum(1 for row in gate_rows if row["accepted"])
            lines.append(
                f"评分口径：`score_literature_relevance`（真实检索链路同款），"
                f"接受门槛 `score >= {RELEVANCE_THRESHOLD}`。"
                f"本轮原始召回 {len(gate_rows)} 篇，通过 {accepted} 篇，"
                f"拒绝 {len(gate_rows) - accepted} 篇。"
            )
            lines.append("")
            for row in gate_rows:
                score = row.get("score")
                score_text = "n/a" if score is None else f"{float(score):.2f}"
                lines.extend([
                    f"- {row.get('title','')} ({row.get('paper_id','')})",
                    f"    source: {row.get('source','')}",
                    f"    score: {score_text}",
                    f"    label: {row.get('label','')}",
                    f"    scoring_status: {row.get('scoring_status','')}",
                    f"    unresolved_terms: {', '.join(row.get('unresolved_terms') or []) or '-'}",
                    f"    reason: {row.get('reason','')}",
                ])
        ledger = result.get("evidence_ledger") or {}
        lines.extend(["", "### 最终证据账本", ""])
        if not ledger.get("entries"):
            lines.append("本轮没有通过语义门控的候选，因此没有论文会进入回答的证据账本。")
        else:
            lines.append(
                f"进入回答的论文 {len(ledger['entries'])} 篇"
                + (f"（另有 {ledger['accepted_total'] - len(ledger['entries'])} 篇因 15 篇上限被截断）"
                   if ledger.get("truncated") else "")
                + f"；占本轮原始召回 {ledger.get('fill_rate', 0.0) * 100:.0f}%。"
                + f"其中 `weak` 标签 {ledger.get('weak_in_ledger', 0)} 篇。"
            )
            lines.extend(["", f"排序口径：{ledger.get('ranked_by', '')}", ""])
            for item in ledger["entries"]:
                score = item.get("score")
                score_text = "n/a" if score is None else f"{float(score):.2f}"
                concepts = ", ".join(item.get("matched_concepts") or []) or "-"
                lines.extend([
                    f"- {item.get('citation','')} {item.get('title','')} ({item.get('paper_id','')})",
                    f"    source: {item.get('source','')}",
                    f"    score: {score_text}    label: {item.get('label','')}",
                    f"    matched_concepts: {concepts}",
                ])
        details = result.get("match_details") or {}
        lines.extend(["", "### 实体词匹配详情", ""])
        if not details.get("candidates"):
            lines.append("本轮没有可分析的候选。")
        else:
            lines.extend([
                f"问题识别到的概念：{', '.join(details.get('requested_concepts') or []) or '（无）'}",
                "",
            ])
            for item in details["candidates"]:
                score = item.get("score")
                score_text = "n/a" if score is None else f"{float(score):.2f}"
                breakdown = item.get("score_breakdown") or {}
                breakdown_text = ", ".join(f"{key}={value}" for key, value in breakdown.items()) or "-"
                lines.extend([
                    f"- {item.get('title','')} ({item.get('paper_id','')})",
                    f"    score: {score_text}    accepted: {str(item.get('accepted')).lower()}",
                    f"    requested_concepts: {', '.join(item.get('requested_concepts') or []) or '-'}",
                    f"    unmatched_requested_concepts: {', '.join(item.get('unmatched_requested_concepts') or []) or '-'}",
                    f"    matched_concepts: {', '.join(item.get('matched_concepts') or []) or '-'}",
                    f"    title_matched: {', '.join(item.get('title_matched') or []) or '-'}",
                    f"    abstract_matched: {', '.join(item.get('abstract_matched') or []) or '-'}",
                    f"    concept_coverage: {item.get('concept_coverage', 0)}    core_concept_coverage: {item.get('core_concept_coverage', 0)}",
                    f"    explicit_terms: {', '.join(item.get('explicit_terms') or []) or '-'}",
                    f"    hard_explicit_terms: {', '.join(item.get('hard_explicit_terms') or []) or '-'}",
                    f"    missing_hard_explicit_terms: {', '.join(item.get('missing_hard_explicit_terms') or []) or '-'}",
                    f"    limitation_query: {str(item.get('limitation_query')).lower()}    limitation_hits: {', '.join(item.get('limitation_hits') or []) or '-'}",
                    f"    intent_matches: {', '.join(item.get('intent_matches') or []) or '-'}",
                    f"    score_breakdown: {breakdown_text}",
                    "    （score_breakdown 为外部可见的各项贡献，仅供定位低分原因；",
                    "      它不是总分，`score` 与 `accepted` 一律以门控自身的判定为准。）",
                ])
        lines.extend(["", "### LLM 规划审计", "", "```json", json.dumps(result.get("trace", {}), ensure_ascii=False, indent=2), "```", ""])
    return "\n".join(lines)


PAGE = r'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SciAssistant 检索队列检查台</title>
<style>body{margin:0;background:#f4f7fa;color:#17202a;font:14px/1.55 system-ui,"Segoe UI",sans-serif}main{max-width:1200px;margin:auto;padding:24px 18px 60px}h1{margin:0 0 6px}textarea{width:100%;min-height:180px;box-sizing:border-box;border:1px solid #cbd5df;border-radius:6px;padding:10px;font:inherit;background:#fff}button{border:0;border-radius:6px;padding:9px 14px;background:#1264a3;color:#fff;font-weight:650;cursor:pointer;margin:10px 8px 10px 0}#status{color:#5c6b78}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(330px,1fr));gap:12px;margin-top:14px}details{background:#fff;border:1px solid #dce4eb;border-radius:7px;margin-top:12px;overflow:hidden}summary{cursor:pointer;padding:11px 13px;font-weight:700;background:#fff}pre{margin:0;padding:13px;white-space:pre-wrap;overflow:auto;background:#fbfcfd;border-top:1px solid #edf1f4;font:12px/1.5 ui-monospace,Consolas,monospace}.ok{color:#187548}.bad{color:#b33025}.item{background:#fff;border:1px solid #dce4eb;border-radius:7px;margin-top:12px;padding:12px}.muted{color:#63717e}</style></head><body><main><h1>检索链路真实召回队列</h1><p class="muted">每行一个问题，最多 10 个。系统严格按顺序逐题执行四来源真实召回，不再提供仅规划模式。</p><textarea id="q" placeholder="每行一个问题，最多 10 行"></textarea><br><button id="run">提交真实召回队列</button><button id="export" disabled>导出队列 Markdown</button><span id="status"></span><div id="out"></div></main><script>
const $=x=>document.querySelector(x); const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function block(title,data,open=false){return `<details${open?' open':''}><summary>${esc(title)}</summary><pre>${esc(typeof data==='string'?data:JSON.stringify(data,null,2))}</pre></details>`}
function renderItem(item){let r=item.result||{}, html=`<div class="item"><b>${esc(item.index)}. ${esc(item.query)}</b><span class="${item.status==='completed'?'ok':item.status==='failed'?'bad':''}">状态：${esc(item.status)}</span>`;if(item.error)return html+`<pre>${esc(item.error)}</pre></div>`;html+=block('最终关键词',r.final_keywords||[]);html+=block('arXiv 格式化查询',r.arxiv_queries||[]);html+=block('各来源查询',r.source_queries||{});for(const [s,x] of Object.entries(r.search||{})){const label=x.failure_status?`${x.status} / ${x.failure_status}`:x.status;html+=block(`${s} 真实召回：${label}`,x)}html+=block(`语义门控结果（${(r.semantic_gate||[]).length} 篇）`,(r.semantic_gate||[]).length?r.semantic_gate.map(g=>`- ${g.title} (${g.paper_id})\n    source: ${g.source}\n    score: ${g.score}\n    label: ${g.label}\n    reason: ${g.reason}`).join('\n'):'本次没有可评分的原始召回候选。',true);html+=block('LLM 规划链路完整追踪',r.trace||{});return html+'</div>'}
function renderQueue(q){$('#status').textContent=` ${q.status}（${q.items.filter(x=>x.status==='completed').length}/${q.items.length} 完成）`;$('#out').innerHTML=q.items.map(renderItem).join('');$('#export').disabled=q.status!=='completed';if(q.status!=='completed')setTimeout(()=>poll(q.id),1200)}
async function poll(id){let r=await fetch('/api/queue/'+id);let q=await r.json();if(r.ok)renderQueue(q)}
$('#run').onclick=async()=>{let queries=$('#q').value.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);if(!queries.length||queries.length>10){$('#status').textContent=' 请输入 1-10 个问题，每行一个';return}$('#run').disabled=true;$('#status').textContent=' 正在创建队列…';try{let r=await fetch('/api/queue',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({queries})});let q=await r.json();if(!r.ok)throw Error(q.error||'创建失败');window.queueId=q.id;renderQueue(q)}catch(e){$('#status').textContent=' '+e.message;$('#run').disabled=false}};
$('#export').onclick=()=>{if(window.queueId)location.href='/api/queue/'+window.queueId+'/export.md'};
</script></body></html>'''


@app.get("/")
def index():
    return render_template_string(PAGE)


@app.post("/api/queue")
def create_queue():
    body = request.get_json(silent=True) or {}
    queries = [str(x).strip() for x in (body.get("queries") or []) if str(x).strip()]
    if not queries:
        return jsonify({"error": "请至少输入一个问题"}), 400
    if len(queries) > 10:
        return jsonify({"error": "单个队列最多 10 个问题"}), 400
    if any(len(query) > MAX_QUERY_CHARS for query in queries):
        return jsonify({"error": "单个问题过长"}), 413
    queue_id = uuid.uuid4().hex[:12]
    queue = {"id": queue_id, "status": "running", "created_at": time.time(), "items": [{"index": i, "query": q, "status": "queued"} for i, q in enumerate(queries, 1)]}
    # Recovery of a disabled source stays a manual decision, so the run does
    # not re-enable anything. It records the situation and the command an
    # operator can run, so the condition is visible instead of silent.
    notices = [disabled_source_notice(name) for name in SOURCE_ORDER]
    queue["disabled_source_notices"] = [notice for notice in notices if notice]
    with QUEUE_LOCK:
        QUEUES[queue_id] = queue
    threading.Thread(target=_queue_worker, args=(queue_id,), daemon=True).start()
    return jsonify(queue), 202


@app.get("/api/queue/<queue_id>")
def queue_status(queue_id: str):
    with QUEUE_LOCK:
        queue = QUEUES.get(queue_id)
        if not queue:
            return jsonify({"error": "队列不存在或服务已重启"}), 404
        return jsonify(queue)


@app.get("/api/queue/<queue_id>/export.md")
def export_queue(queue_id: str):
    """Export the queue report.

    Default output is unchanged and complete. ``?compact=1`` returns the
    reduced Markdown view and ``?compact=json`` the same data as JSON, for
    runs where the full report (every raw provider envelope plus the planner
    trace) is too large to work with.
    """
    compact = str(request.args.get("compact", "")).strip().lower()
    with QUEUE_LOCK:
        queue = QUEUES.get(queue_id)
        if not queue:
            return jsonify({"error": "队列不存在"}), 404
        if compact == "json":
            return jsonify(_compact_queue(queue))
        markdown = _compact_markdown(queue) if compact else _queue_markdown(queue)
    filename = f"sciassistant_retrieval_queue_{queue_id}{'_compact' if compact else ''}.md"
    return Response(markdown, mimetype="text/markdown; charset=utf-8", headers={"Content-Disposition": f"attachment; filename={filename}"})


if __name__ == "__main__":
    app.run(host=_configured_debug_host(), port=int(os.getenv("RETRIEVAL_DEBUG_PORT", "5080")), debug=False)
