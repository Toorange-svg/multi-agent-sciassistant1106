"""Paid bounded Auditor-only check of copied approved public artifacts; never republishes history."""
import argparse
from copy import deepcopy
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from multi_agent_agents import ArtifactDirectory
from multi_agent_pipeline_v2 import LiteraturePipelineV2, DeterministicLiteratureExecutor
from multi_agent_quality import (ABSENCE_MENU_POLICY, ABSENCE_REASON_POLICY, ABSENCE_INVENTORY_POLICY, WITNESS_COPY_POLICY, WITNESS_CAPACITY_POLICY,
    publication_rejections)
from multi_agent_workflow import WorkflowStore
from tools.check_premise_artifacts import tree
from tools.multi_agent_cli import configured_live_model
from runtime_identity import source_fingerprint


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-run', type=Path, required=True)
    parser.add_argument('--output-root', type=Path, required=True)
    parser.add_argument('--credential-user', required=True)
    args = parser.parse_args()
    source, output = args.source_run.resolve(), args.output_root.resolve()
    if (not source.is_relative_to(ROOT/'logs') or not output.is_relative_to(ROOT/'logs')
            or output.exists() or output.is_relative_to(source)):
        parser.error('new logs output and explicit logs source required')
    from dotenv import dotenv_values
    from user_credentials import CredentialStore, provider_scope
    values = {**dotenv_values(ROOT/'deepdiver_v2/config/.env'), **dotenv_values(ROOT/'.env'), **os.environ}
    credentials = CredentialStore(values.get('SCIASSISTANT_USER_CREDENTIAL_DB', ROOT/'logs/user_credentials.sqlite3'),
                                  values.get('USER_CREDENTIAL_ENCRYPTION_KEY') or values.get('SECRET_KEY'))
    cap = credentials.capability(args.credential_user)
    if not credentials.status(cap)['deepseek']['configured']:
        parser.error('current user model key required')
    before = tree(source)
    source_store = ArtifactDirectory(source/'artifacts')
    manifest = json.loads((source/'manifest.json').read_text(encoding='utf-8-sig'))
    if manifest.get('source_scope') != 'arxiv':
        parser.error('this tool accepts recorded public arXiv runs only')
    final = source_store.get(manifest['final_artifact_id'])
    original = source_store.get(final['artifact_refs']['draft'])
    output.mkdir(parents=True)
    (output/'agents').mkdir()
    os.environ['MODEL_KEY_POOL_STATE_PATH'] = str(output/'key-pool.sqlite3')
    with provider_scope(cap):
        client = configured_live_model()
        artifacts = ArtifactDirectory(output/'artifacts')
        store = WorkflowStore(output/'workflow.sqlite3')
        def no_search(*_):
            raise RuntimeError('AUDIT_ONLY_NO_RETRIEVAL')
        flow = LiteraturePipelineV2(store, artifacts, client.agents(source_scope='arxiv'),
            DeterministicLiteratureExecutor(no_search), event_path=output/'events.jsonl',
            time_budget_seconds=120, configuration_fingerprint=client.fingerprint)
        run_id = 'copied-public-audit'
        store.create_run(run_id, 'local-operator', max_model_calls=2, time_budget_seconds=120)
        for state in ('planned','retrieving','reviewing','writing','auditing'):
            store.transition(run_id, state, details={'copied_inputs_only':True})
        flow.deadline = time.monotonic()+120
        refs = {}
        for name in ('question','requirements','plan','approved','review','source_boundaries','answer_focus_brief'):
            key = final['artifact_refs'].get(name)
            if key:
                refs[name] = artifacts.put(name.replace('_','-'), source_store.get(key))['artifact_id']
        draft = deepcopy(original)
        draft.update(absence_menu_policy=ABSENCE_MENU_POLICY, absence_reason_policy=ABSENCE_REASON_POLICY,
                     absence_inventory_policy=ABSENCE_INVENTORY_POLICY, witness_copy_policy=WITNESS_COPY_POLICY,
                     witness_capacity_policy=WITNESS_CAPACITY_POLICY)
        refs['draft'] = artifacts.put('draft-answer', draft)['artifact_id']
        approved = artifacts.get(refs['approved'])
        started = time.monotonic()
        error, error_type, blocked, audit_id = None, None, [], None
        try:
            _, checked = flow._audit(run_id, '独立复审复制的公开文献稿；核实原文与各字段，不能为凑通过而改判',
                [refs['draft'],refs['approved'],refs['review']], draft, refs)
            blocked = sorted(publication_rejections(checked, draft))
            audit_id = artifacts.put('checked-audit', checked)['artifact_id']
            store.transition(run_id, 'needs_review')  # Independent review is not publication.
        except Exception as exc:
            error = getattr(exc, 'code', 'INDEPENDENT_AUDIT_FAILED')
            error_type = type(exc).__name__
            store.force_terminal(run_id, 'failed', failure_code=error)
        receipt = {'schema_version':'sciassistant.copied-public-audit/v1',
            'role_invocation_path':'workflow_bounded_audit', 'full_workflow_test':False,
            'source_run':str(source.relative_to(ROOT)), 'source_status':final['status'],
            'source_hashes_unchanged':before==tree(source), 'source_claims_unchanged':draft['claims']==original['claims'],
            'source_fingerprint':source_fingerprint()[0], 'audit_artifact_id':audit_id,
            'model_calls':store.get_run(run_id)['model_calls_used'], 'elapsed_seconds':round(time.monotonic()-started,2),
            'blocked_claims':blocked, 'error':error, 'error_type':error_type, 'ledger_status':store.get_run(run_id)['status'],
            'retrieval_requests':0, 'source_republished':False, 'scientific_review_required':True}
        (output/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
        print(json.dumps(receipt,ensure_ascii=False))
        return 0 if not error and receipt['source_hashes_unchanged'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
