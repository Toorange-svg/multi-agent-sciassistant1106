"""Run a real Web UI literature-retrieval acceptance suite and render HTML."""

from __future__ import annotations

import argparse
import html
import json
import re
import time
from datetime import datetime
from pathlib import Path

import requests


CASES = [
    ("CNN advantages", "根据 arXiv 上的论文，CNN 架构的优势是什么？"),
    ("CNN limitations", "根据 arXiv 上的论文解释 CNN 架构的局限性。"),
    ("CNN comparison", "比较 CNN 和 Transformer 在视觉任务中的主要取舍，并给出论文依据。"),
    ("Transformer definition", "根据 arXiv 论文解释 Transformer 的基本架构和工作机制。"),
    ("Transformer advantages", "Transformer 相比 RNN 的优势是什么？请给出 arXiv 论文依据。"),
    ("Transformer limitations", "Transformer 在长序列建模中有哪些局限？基于 arXiv 论文回答。"),
    ("Transformer comparison", "比较 Transformer 和 RNN 的并行性、长程依赖与计算成本。"),
    ("RAG definition", "根据 arXiv 论文解释 RAG 的工作原理。"),
    ("RAG advantages", "RAG 相比只依赖参数记忆的语言模型有什么优势？"),
    ("RAG limitations", "RAG 系统常见的失败模式和局限是什么？引用 arXiv 论文。"),
    ("RAG comparison", "比较 RAG 和长上下文语言模型在知识访问上的取舍。"),
    ("CoT definition", "根据 arXiv 论文讲解 Chain-of-Thought 提示方法。"),
    ("CoT advantages", "CoT 在推理任务中为什么有效？请给出论文证据。"),
    ("CoT limitations", "Chain-of-Thought 的可靠性与忠实性有哪些问题？"),
    ("Diffusion definition", "解释扩散模型的基本生成机制，并给出 arXiv 论文依据。"),
    ("Diffusion advantages", "扩散模型相对 GAN 的主要优势是什么？"),
    ("Diffusion limitations", "扩散模型在采样速度和可控性方面有哪些局限？"),
    ("Diffusion progress", "扩散模型近年的研究进展主要集中在哪些方向？"),
    ("GNN definition", "根据 arXiv 论文解释图神经网络如何传播信息。"),
    ("GNN limitations", "图神经网络在深层训练时的局限性是什么？"),
    ("GNN comparison", "比较 GNN 与普通 MLP 在图结构数据上的归纳偏置。"),
    ("LLM mechanism", "大语言模型的预训练和指令微调分别解决什么问题？"),
    ("LLM limitations", "大语言模型的幻觉和事实可靠性问题有哪些论文依据？"),
    ("LLM comparison", "比较参数高效微调和全量微调的优势与代价。"),
    ("Image generation", "文本生成图像模型通常如何评估生成质量？"),
    ("Image generation limitations", "文本生成图像模型在文字渲染和组合性方面有什么局限？"),
    ("Video generation", "根据 arXiv 论文解释文本生成视频模型的主要技术挑战。"),
    ("Reinforcement learning", "强化学习中的探索与利用权衡如何影响算法设计？"),
    ("Reinforcement learning limitations", "深度强化学习的数据效率和稳定性问题有哪些？"),
    ("Survey request", "请概述生成式 AI 的近期研究方向，并以 arXiv 文献为依据。"),
]


def section(answer: str, name: str) -> str:
    pattern = rf"## {re.escape(name)}\s*(.*?)(?=\n## |\Z)"
    match = re.search(pattern, answer or "", re.S)
    return match.group(1).strip() if match else ""


def review(task: dict) -> dict:
    answer = str(task.get("answer") or "")
    diagnostics_raw = section(answer, "检索诊断")
    try:
        diagnostics = json.loads(diagnostics_raw) if diagnostics_raw else {}
    except json.JSONDecodeError:
        diagnostics = {}
    papers = re.findall(r"^\[\d+\]\s+(.+?)\. arxiv:([^\s.]+)", answer, re.M)
    structure = [name for name in ("结论", "依据", "文献来源", "检索诊断") if f"## {name}" in answer]
    issues = []
    if task.get("status") != "completed":
        issues.append("任务未完成")
    if "通用知识解释" in answer or "未找到达到相关性阈值" in answer:
        issues.append("降级为非文献回答")
    if not papers:
        issues.append("未提取到 arXiv 引用")
    if not diagnostics.get("query_plan"):
        issues.append("结果未记录查询计划")
    if len(structure) < 3:
        issues.append("回答结构不完整")
    return {
        "diagnostics": diagnostics,
        "papers": papers,
        "structure": structure,
        "issues": issues,
        "rating": "通过" if not issues else ("部分通过" if task.get("status") == "completed" else "不通过"),
        "summary": (section(answer, "结论") or answer)[:700],
    }


def run_case(base_url: str, label: str, query: str, timeout: int) -> dict:
    created = requests.post(
        f"{base_url}/api/tasks",
        json={"query": query, "processing_mode": "literature_answer", "pdf_parse_mode": "local"},
        timeout=20,
    )
    created.raise_for_status()
    task_id = created.json()["task"]["id"]
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        task = requests.get(f"{base_url}/api/tasks/{task_id}", timeout=20).json()
        if task.get("status") in {"completed", "failed"}:
            return {"label": label, "question": query, "task": task, "review": review(task)}
        time.sleep(1)
    return {"label": label, "question": query, "task": {"status": "timeout"},
            "review": {"papers": [], "structure": [], "issues": ["验收超时"], "rating": "不通过", "summary": ""}}


def render(results: list[dict], destination: Path) -> None:
    passed = sum(item["review"]["rating"] == "通过" for item in results)
    rows = []
    for index, item in enumerate(results, 1):
        task, review_data = item["task"], item["review"]
        diagnostics = review_data.get("diagnostics", {})
        papers = "<br>".join(
            f'<a href="https://arxiv.org/abs/{html.escape(paper_id)}" target="_blank">{html.escape(paper_id)}</a> {html.escape(title)}'
            for title, paper_id in review_data.get("papers", [])
        ) or "无"
        plan = "<br>".join(
            f"<b>{html.escape(str(step.get('dimension', '')))}</b>：{html.escape(str(step.get('query', '')))}"
            for step in diagnostics.get("query_plan", [])
        ) or "未记录"
        issues = "；".join(review_data.get("issues", [])) or "证据、结构和检索计划均已自动检查"
        rows.append(f"""
        <article class="case {review_data['rating']}">
          <header><span class="num">{index:02d}</span><div><h2>{html.escape(item['label'])}</h2><p>{html.escape(item['question'])}</p></div><span class="badge">{review_data['rating']}</span></header>
          <div class="grid"><section><h3>查询规划</h3><p>{plan}</p><h3>实际检索</h3><p>轮次：{diagnostics.get('search_rounds', '—')}；实际查询：{html.escape(' | '.join(diagnostics.get('queries_used', [])))}</p></section>
          <section><h3>命中文献</h3><p>{papers}</p><h3>回答结构</h3><p>{html.escape(' → '.join(review_data.get('structure', [])) or '未识别')}</p></section></div>
          <section><h3>回答结论摘要</h3><pre>{html.escape(review_data.get('summary', ''))}</pre></section>
          <section><h3>Codex 评价</h3><p>{html.escape(issues)}</p></section>
        </article>""")
    document = f"""<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>文献检索验收包</title>
    <style>body{{margin:0;background:#101418;color:#e7edf2;font:15px/1.6 Arial,sans-serif}}main{{max-width:1280px;margin:auto;padding:32px}}h1{{font-size:28px}}.meta{{color:#a9b8c5}}.case{{border:1px solid #34414c;background:#161d23;margin:20px 0;padding:20px;border-radius:6px}}.case.通过{{border-left:5px solid #40b984}}.case.部分通过{{border-left:5px solid #e3ab45}}.case.不通过{{border-left:5px solid #e26464}}header{{display:flex;gap:14px;align-items:flex-start}}h2,h3,p{{margin:0 0 8px}}h2{{font-size:18px}}h3{{font-size:13px;color:#8fc8e8;text-transform:uppercase;letter-spacing:.5px}}.num,.badge{{padding:3px 8px;background:#263541;border-radius:4px;white-space:nowrap}}.badge{{margin-left:auto}}.grid{{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin:16px 0}}pre{{white-space:pre-wrap;background:#0d1115;padding:12px;margin:0;border-radius:4px;color:#d3dde5}}a{{color:#7ec8f5}}@media(max-width:700px){{.grid{{grid-template-columns:1fr}}main{{padding:16px}}}}</style>
    <main><h1>通用文献检索链路验收包</h1><p class="meta">生成时间：{datetime.now().isoformat(timespec='seconds')}；真实网页端任务：{len(results)}；自动通过：{passed}/{len(results)}；PDF 模式：local；未使用 LlamaParse 或混合增强。</p>{''.join(rows)}</main>"""
    destination.mkdir(parents=True, exist_ok=True)
    (destination / "index.html").write_text(document, encoding="utf-8")
    (destination / "results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    md = [
        "# 通用文献检索链路网页验收报告（第二轮）",
        "",
        f"- 生成时间：{datetime.now().isoformat(timespec='seconds')}",
        f"- 实际网页端任务：{len(results)}；自动通过：{passed}/{len(results)}",
        "- 处理方式：文献依据科研回答；PDF 解析：本地；未使用 LlamaParse 或混合增强。",
        "- 自动判定说明：通过=完成、提取到 arXiv 引用、记录查询计划且结构完整；部分通过=任务完成但降级为通用回答；不通过=失败或超时。",
        "",
    ]
    for index, item in enumerate(results, 1):
        task, review_data = item.get("task", {}), item.get("review", {})
        diagnostics = review_data.get("diagnostics", {})
        papers = review_data.get("papers", [])
        md.extend([
            f"## {index:02d}. {item.get('label', '')}",
            "",
            f"**问题**：{item.get('question', '')}",
            f"**状态**：{task.get('status', '—')}；**自动判定**：{review_data.get('rating', '—')}",
            f"**问题规格**：实体={', '.join(diagnostics.get('problem_spec', {}).get('entities', [])) or '未识别'}；关系={diagnostics.get('problem_spec', {}).get('relation', '—')}；方面={'；'.join(diagnostics.get('problem_spec', {}).get('aspects', [])) or '—'}",
            f"**查询计划**：{'；'.join(step.get('query', '') for step in diagnostics.get('query_plan', [])) or '未记录'}",
            f"**检索轮次/停止原因**：{diagnostics.get('search_rounds', '—')} / {diagnostics.get('stop_reason', '—')}",
            f"**命中文献**：{'；'.join(f'{pid} {title}' for title, pid in papers) or '无'}",
            f"**回答结构**：{' → '.join(review_data.get('structure', [])) or '未识别'}",
            f"**回答摘要**：{review_data.get('summary', '').replace(chr(10), ' ')[:500]}",
            f"**Codex 评价**：{'；'.join(review_data.get('issues', [])) or '证据、结构和检索计划均已自动检查'}",
            "",
        ])
    (destination / "report.md").write_text("\n".join(md), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", default="http://127.0.0.1:5050")
    parser.add_argument("--output", required=True)
    parser.add_argument("--timeout", type=int, default=180)
    parser.add_argument("--resume", action="store_true", help="Reuse cases already stored in results.json.")
    parser.add_argument("--parallel", type=int, default=1, help="Maximum number of independent Web tasks in flight.")
    args = parser.parse_args()
    destination = Path(args.output)
    result_path = destination / "results.json"
    pending_path = destination / "pending.json"
    indexed_results: dict[int, dict] = {}
    case_indexes = {label: index for index, (label, _) in enumerate(CASES)}
    if args.resume and result_path.exists():
        try:
            previous = json.loads(result_path.read_text(encoding="utf-8"))
            if isinstance(previous, list):
                for fallback_index, item in enumerate(previous[:len(CASES)]):
                    if not isinstance(item, dict):
                        continue
                    index = case_indexes.get(str(item.get("label") or ""), fallback_index)
                    indexed_results[index] = item
        except (OSError, json.JSONDecodeError):
            pass
    pending: list[dict] = []
    if args.resume and pending_path.exists():
        try:
            loaded = json.loads(pending_path.read_text(encoding="utf-8"))
            if isinstance(loaded, list):
                pending = [item for item in loaded if isinstance(item, dict)]
        except (OSError, json.JSONDecodeError):
            pass

    def persist() -> None:
        results = []
        for index in sorted(indexed_results):
            item = dict(indexed_results[index])
            item["case_index"] = index
            results.append(item)
        destination.mkdir(parents=True, exist_ok=True)
        result_path.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
        pending_path.write_text(json.dumps(pending, ensure_ascii=False, indent=2), encoding="utf-8")
        render(results, destination)

    parallel = max(1, min(args.parallel, 3))
    def next_unstarted_index() -> int | None:
        occupied = set(indexed_results)
        occupied.update(int(item.get("index", -1)) for item in pending)
        return next((index for index in range(len(CASES)) if index not in occupied), None)

    while len(indexed_results) < len(CASES):
        while len(pending) < parallel:
            next_index = next_unstarted_index()
            if next_index is None:
                break
            label, query = CASES[next_index]
            print(f"[{next_index + 1}/{len(CASES)}] {label}", flush=True)
            try:
                created = requests.post(
                    f"{args.base_url.rstrip('/')}/api/tasks",
                    json={"query": query, "processing_mode": "literature_answer", "pdf_parse_mode": "local"},
                    timeout=20,
                )
                created.raise_for_status()
                pending.append({
                    "index": next_index, "label": label, "question": query,
                    "task_id": created.json()["task"]["id"], "started_at": time.time(),
                })
            except Exception as exc:
                indexed_results[next_index] = {
                    "label": label, "question": query, "task": {"status": "request_error"},
                    "review": {"papers": [], "structure": [], "issues": [str(exc)], "rating": "不通过", "summary": ""},
                }
            persist()

        completed = []
        for item in pending:
            try:
                task = requests.get(f"{args.base_url.rstrip('/')}/api/tasks/{item['task_id']}", timeout=20).json()
                if task.get("status") in {"completed", "failed"}:
                    indexed_results[int(item["index"])] = {
                        "label": item["label"], "question": item["question"], "task": task, "review": review(task),
                    }
                    completed.append(item)
                elif time.time() - float(item.get("started_at", time.time())) >= args.timeout:
                    indexed_results[int(item["index"])] = {
                        "label": item["label"], "question": item["question"], "task": {"status": "timeout"},
                        "review": {"papers": [], "structure": [], "issues": ["验收超时"], "rating": "不通过", "summary": ""},
                    }
                    completed.append(item)
            except Exception as exc:
                print(f"poll error: {exc}", flush=True)
        if completed:
            pending[:] = [item for item in pending if item not in completed]
            persist()
        if pending:
            time.sleep(1)
    persist()


if __name__ == "__main__":
    main()
