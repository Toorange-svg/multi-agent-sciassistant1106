"""Isolated paid Web-dispatch probe. No service restart, research, or shared keys."""
import argparse
import json
import os
from pathlib import Path
import sys
import time
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-root', type=Path, required=True)
    parser.add_argument('--credential-user', required=True)
    args = parser.parse_args()
    root = args.output_root.resolve()
    if root.exists() or not root.is_relative_to(ROOT / 'logs'):
        parser.error('new isolated logs-only output root required')
    from dotenv import dotenv_values
    from user_credentials import CredentialStore
    values = {**dotenv_values(ROOT / 'deepdiver_v2/config/.env'), **dotenv_values(ROOT / '.env'), **os.environ}
    store = CredentialStore(values.get('SCIASSISTANT_USER_CREDENTIAL_DB', ROOT / 'logs/user_credentials.sqlite3'),
        values.get('USER_CREDENTIAL_ENCRYPTION_KEY') or values.get('SECRET_KEY'))
    cap = store.capability(args.credential_user)
    if not store.status(cap)['deepseek']['configured']:
        parser.error('USER_PROVIDER_KEY_REQUIRED')
    root.mkdir(parents=True)
    os.environ['MODEL_KEY_POOL_STATE_PATH'] = str(root / 'keys.sqlite3')
    # web_app restores snapshots at import time, before patch.object can help.
    # Set this BEFORE importing it, never visit production task state.
    os.environ['SCIASSISTANT_TASK_STATE_DIR'] = str(root / 'state')
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    import web_app as web
    jobs, rows, requests = [], [], []
    real_post = web.post_model_request
    def model_post(*a, **kw):
        requests.append({'called': True})
        return real_post(*a, **kw)
    def forbidden(*a, **kw):
        raise AssertionError('unexpected retrieval or RAG readiness for a clear daily request')
    questions = ['你好', '帮我写一封简短的请假邮件', '今天广州天气怎么样？']
    with patch.object(web, 'TASKS', {}), patch.object(web, '_TASK_CREDENTIALS', {}), \
            patch.object(web, 'TASK_STATE_DIR', root / 'state'), patch.object(web, 'LOG_DIR', root), \
            patch.object(web, '_start_background_task', lambda *a, **kw: jobs.append((a, kw)) or True), \
            patch.object(web, '_enqueue_retrieval_task', forbidden), patch.object(web.rag_web, 'readiness', forbidden), \
            patch.object(web, 'post_model_request', model_post):
        for question in questions:
            before, started = len(requests), time.monotonic()
            response = web.app.test_client().post('/api/tasks',
                json={'query': question, 'processing_mode': 'multi_agent_rag'},
                environ_overrides={'sciassistant.provider_credentials': cap})
            task = response.get_json().get('task', {})
            if response.status_code == 202:
                a, kw = jobs.pop(0)
                web._execute_background_task(a[0], a[1], a[2:], kw['stage'])
                task = web.TASKS[task['id']]
            row = {'question': question, 'http_status': response.status_code,
                'processing_mode': task.get('processing_mode'), 'status': task.get('status'),
                'route': task.get('request_route'), 'answer': task.get('answer'),
                'model_transport_attempts': len(requests) - before,
                'elapsed_seconds': round(time.monotonic() - started, 2),
                'retrieval_calls': 0, 'uploaded_pdf': False, 'isolated_api_not_browser': True}
            rows.append(row)
            (root / 'result.json').write_text(json.dumps({'cases': rows}, ensure_ascii=False, indent=2), encoding='utf-8')
            print(json.dumps({k: row[k] for k in ('question', 'status', 'processing_mode', 'elapsed_seconds')}, ensure_ascii=False), flush=True)
            if row['status'] != 'completed':
                break  # Preserve first service/payment/dispatch failure; never loop to pick success.
    return 0 if len(rows) == len(questions) and all(r['status'] == 'completed' for r in rows) else 1


if __name__ == '__main__':
    raise SystemExit(main())
