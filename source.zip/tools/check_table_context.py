"""Read-only real-PDF -> parser -> local FTS/packets check, no LLM or network."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
import subprocess

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def verify_runs(paths, output):
    """Use the existing read-only CLI; record hashes and published mappings."""
    rows = []
    for value in paths:
        run = Path(value).resolve()
        if not run.is_dir() or output.is_relative_to(run) or run.is_relative_to(output):
            raise ValueError('verification output overlaps source or run is missing')
        def hashes():
            return {str(p.relative_to(run)): hashlib.sha256(p.read_bytes()).hexdigest()
                    for p in run.rglob('*') if p.is_file()}
        before = hashes()
        results = {}
        for action in ('inspect', 'replay'):
            result = subprocess.run([sys.executable, str(Path(__file__).with_name('multi_agent_cli.py')),
                action, '--run-dir', str(run)], capture_output=True, text=True, encoding='utf-8', timeout=60)
            results[action + '_exit'] = result.returncode
        refs = json.loads((run / 'references.json').read_text(encoding='utf-8'))
        claims = json.loads((run / 'claim_evidence_map.json').read_text(encoding='utf-8'))
        used = {key for c in claims for key in c['evidence_ids']}
        ref_ids = {r['evidence_id'] for r in refs}
        deliveries = [json.loads(p.read_text(encoding='utf-8'))
                      for p in (run / 'artifacts').glob('model-delivery-*.json')]
        row = {'run_id': run.name, **results, 'source_hashes_unchanged': before == hashes(),
            'source_files': len(before), 'published_claims': len(claims), 'references': len(refs),
            'references_equal_used_evidence': used == ref_ids,
            'references_approved_located': all(r.get('review_status') == 'approved'
                and r.get('locator', {}).get('page') and r.get('locator', {}).get('bbox') for r in refs),
            'delivery_count': len(deliveries), 'all_delivery_stop': all(d['finish_reason'] == 'stop' for d in deliveries),
            'answer_sha256': hashlib.sha256((run / 'final_answer.md').read_bytes()).hexdigest()}
        rows.append(row)
    payload = {'schema_version': 'sciassistant.table-context-run-check/v1', 'runs': rows,
        'model_calls_added': 0, 'network_calls_added': 0,
        'passed': all(r['inspect_exit'] == r['replay_exit'] == 0 and r['source_hashes_unchanged']
                      and r['references_equal_used_evidence'] and r['references_approved_located'] for r in rows)}
    (output / 'run_checks.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(payload, ensure_ascii=False))
    return 0 if payload['passed'] else 1


def main():
    parser = argparse.ArgumentParser()
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument('--pdf')
    action.add_argument('--verify-run', nargs='+')
    parser.add_argument('--include-symbol-checks', action='store_true',
                        help='Also verify the QLoRA p5 symbol-role paragraph, without assigning mathematical meaning')
    parser.add_argument('--output-dir', required=True)
    args = parser.parse_args()
    output = Path(args.output_dir).resolve()
    if args.verify_run:
        # Validate before creating output so a bad target cannot mutate a run.
        sources = [Path(v).resolve() for v in args.verify_run]
        if any(not p.is_dir() or output.is_relative_to(p) or p.is_relative_to(output) for p in sources):
            raise ValueError('verification output overlaps source or run is missing')
        output.mkdir(parents=True, exist_ok=False)
        return verify_runs(args.verify_run, output)
    source = Path(args.pdf).resolve()
    if output == source.parent or output.is_relative_to(source.parent):
        raise ValueError('output must be outside source directory')
    output.mkdir(parents=True, exist_ok=False)
    before = hashlib.sha256(source.read_bytes()).hexdigest()
    import pdf_pipeline
    pdf_pipeline.PDF_PARSE_CACHE_DIR = output / 'parser-cache'
    from multi_agent_local_pdf import LocalPdfRagExecutor
    from multi_agent_rag import TABLE_CONTEXT_POLICY
    executor = LocalPdfRagExecutor(output / 'run', source, rag_mode='lexical')
    result = executor.execute([{'request_id': 'table-context', 'action': 'request_document_search',
        'arguments': {'query': 'Table 3 GLUE RoBERTa T5 Super-NaturalInstructions RougeL 88.6 40.1', 'group_id': 'g1'}}],
        group_ids={'g1'}, deadline=time.monotonic() + 90)
    packets = result['evidence']
    tables = [row for row in packets if row.get('table_context')
              and row.get('locator', {}).get('page') == 7 and 'Table 3:' in row['text']]
    checks = {
        'source_hash_unchanged': hashlib.sha256(source.read_bytes()).hexdigest() == before,
        'complete_table_in_selected_packet': len(tables) >= 1,
        'dataset_headers_kept': any('GLUE (Acc.) | Super-NaturalInstructions (RougeL)' in row['text'] for row in tables),
        'model_headers_kept': any('RoBERTa-large | T5-80M | T5-250M' in row['text'] for row in tables),
        'baseline_row_kept': any('BF16 | 88.6 | 40.1 | 42.1 | 48.0 | 54.3 | 62.0' in row['text'] for row in tables),
        'nf4_row_kept': any('QLORA NF4 + DQ | - | 40.4 | 42.7 | 47.7 | 55.3 | 60.9' in row['text'] for row in tables),
        'page_and_bbox_kept': all(row['locator']['page'] == 7 and row['locator']['bbox'] for row in tables),
        'no_automatic_column_approval': all(row['table_context']['column_semantics_verified'] is False for row in tables),
        'packet_limit_unchanged': len(packets) <= 4,
        'no_public_actions': all(row.get('source') != 'arxiv' for row in result['observations']),
    }
    if args.include_symbol_checks:
        symbols = executor.execute([{'request_id': 'symbol-context', 'action': 'request_document_search',
            'arguments': {'query': 'Double Quantization constants first quantization second level FP32 FP8',
                          'group_id': 'g1'}}], group_ids={'g1'}, deadline=time.monotonic() + 30)
        paragraphs = [row['text'] for row in symbols['evidence'] if row.get('locator', {}).get('page') == 5]
        checks.update({
            'first_quantization_definition_not_split': any('cFP32 2 of the first quantization' in t for t in paragraphs),
            'second_stage_output_definition_kept': any('cFP8 2 and the second level of quantization constants cFP32 1' in t for t in paragraphs),
            'role_sentence_same_selected_packet': any('cFP32 2 of the first quantization' in t
                and 'cFP8 2 and the second level' in t for t in paragraphs),
            'symbol_packet_limit_unchanged': len(symbols['evidence']) <= 4,
        })
        (output / 'symbol_packets.json').write_text(json.dumps(symbols['evidence'], ensure_ascii=False, indent=2), encoding='utf-8')
    payload = {'schema_version': 'sciassistant.table-context-check/v1', 'policy': TABLE_CONTEXT_POLICY,
        'source_sha256': before, 'checks': checks, 'passed': all(checks.values()),
        'selected_evidence_ids': [row['evidence_id'] for row in packets], 'model_calls': 0, 'network_calls': 0}
    (output / 'checks.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    (output / 'selected_packets.json').write_text(json.dumps(packets, ensure_ascii=False, indent=2), encoding='utf-8')
    import pymupdf
    with pymupdf.open(source) as document:
        document[6].get_pixmap(matrix=pymupdf.Matrix(1.4, 1.4)).save(output / 'table3-page.png')
    print(json.dumps(payload, ensure_ascii=False))
    return 0 if payload['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
