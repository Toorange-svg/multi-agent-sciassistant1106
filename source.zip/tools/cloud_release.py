"""Safe, non-mutating deployment checks; stamp is an explicit build-only write.

No application imports, login, task creation, DB access or provider calls.
Reports contain check codes/booleans, never config values or response bodies.
"""
import argparse
import hashlib
import ipaddress
import io
import json
from pathlib import Path
import re
import sys
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from runtime_identity import source_fingerprint

REQUIRED = (
    "multi_agent_workflow.py", "multi_agent_literature.py", "multi_agent_literature_adapters.py", "multi_agent_literature_runtime.py", "multi_agent_demo_runner.py",
    "multi_agent_agents.py", "multi_agent_pipeline_v2.py", "multi_agent_rag.py", "multi_agent_live.py", "multi_agent_report.py", "multi_agent_web.py", "multi_agent_status.py", "multi_agent_evidence.py", "multi_agent_quality.py",
    "multi_agent_handoffs.py", "multi_agent_report_contracts.py", "multi_agent_sections.py", "multi_agent_skills.py", "multi_agent_publication.py", "multi_agent_audit_batches.py",
    "tools/multi_agent_cli.py", "tools/multi_agent_parse_pdf.py", "tools/multi_agent_download_pdf.py", "tools/check_multi_agent_rag.py", "rag_storage_lock.py",
    "tools/rag_cloud.py", "tools/rag_startup.py", "tools/export_embedding_model.py",
    "deepdiver_v2/requirements.rag.cloud.txt", "deepdiver_v2/constraints.rag.cloud.txt",
    "deepdiver_v2/requirements.rag.cloud.hashes.txt", "deepdiver_v2/rag.cloud.artifacts.json",
    "chatAi/multi_agent_rag.js", "chatAi/multi_agent_rag.css",
    "science_pdf_sessions.py", "multi_agent_local_pdf.py", "multi_agent_sources.py", "chatAi/pdf_session.js", "chatAi/conversation_selection.js",
    "research_library.py", "chatAi/research_library.js", "chatAi/research_library.css",
    "user_credentials.py", "chatAi/account_keys.js", "chatAi/attachment_menu.js", "multi_agent_presentation.py",
    "external_embedding.py", "source_delivery.py",
    "LICENSE", "NOTICE", "app.py", "account_schema.py", "password_reset.py", "web_app.py", "pdf_pipeline.py", "pdf_chunker.py", "process_cleanup.py",
    "research_runtime.py", "runtime_identity.py", "request_limits.py", "request_observability.py", "storage_guard.py", "deepdiver_v2/requirements.txt",
    "deepdiver_v2/requirements.cloud.txt", "deepdiver_v2/constraints.cloud.txt",
    "deepdiver_v2/requirements.cloud.hashes.txt",
    "deepdiver_v2/cli/demo.py", "deepdiver_v2/src/tools/server_config.yaml",
    "chatAi/login.html", "chatAi/register.html", "chatAi/forgot-password.html",
    "chatAi/ai_chat.html", "chatAi/images/logo.png", "chatAi/images/user.png",
    "tools/run_research.py", "tools/run_mcp_service.py", "tools/cloud_release.py", "tools/dependency_lock.py", "web/index.html",
    "tools/check_frontend_assets.py", "chatAi/assets/manifest.json",
)

BASE_IMAGE = "python:3.11-slim@sha256:9f6ef439f51f4b36dc5c6bb265c2d3dd810bde94c5bbec77ae86b6650c488cf9"


def result(checks, warnings=()):
    return {"schema": "sciassistant.release-check/v1", "passed": all(c["passed"] for c in checks),
            "checks": checks, "warnings": list(warnings)}


def check(checks, name, passed):
    checks.append({"check": name, "passed": bool(passed)})


def file_checks(root, image=False):
    root, checks = Path(root), []
    for name in REQUIRED:
        check(checks, "file:" + name, (root / name).is_file() and (root / name).stat().st_size > 0)
    for name, marker in (("chatAi/login.html", 'id="loginBtn"'), ("chatAi/ai_chat.html", 'id="chat-messages"')):
        try:
            text = (root / name).read_text(encoding="utf-8")
        except (OSError, UnicodeError):
            text = ""
        check(checks, "page_contract:" + name, marker in text)
    try:
        requirements = (root / "deepdiver_v2/requirements.txt").read_text(encoding="utf-8")
        notice = (root / "NOTICE").read_text(encoding="utf-8")
    except (OSError, UnicodeError):
        requirements = notice = ""
    pymupdf_required = any(
        re.match(r"\s*PyMuPDF(?:\s|[<>=!~])", line, re.I)
        for line in requirements.splitlines()
    )
    check(checks, "dependency_notice_consistent", (
        not pymupdf_required
        or ("PyMuPDF/fitz (GNU AGPL-3.0 OR commercial license)" in notice
            and "PyMuPDF/fitz (AGPL-3.0 License) - NOT INCLUDED" not in notice)
    ))
    try:
        from tools.check_frontend_assets import check as frontend_check
        frontend_valid = frontend_check(root, runtime_only=image)['passed']
    except (OSError, ValueError, KeyError, TypeError):
        frontend_valid = False
    check(checks, "self_hosted_frontend_complete", frontend_valid)
    if image:
        check(checks, "private_env_absent", not any(root.rglob(".env*")))
        check(checks, "database_dump_absent", not any(root.rglob("*.sql")))
        check(checks, "development_artifacts_absent", not any((root / name).exists() for name in (".git", "tests", "docs", "venv")))
        try:
            lock = json.loads((root / ".dependency-lock.json").read_text(encoding="utf-8"))
            constraint_digest = hashlib.sha256((root / "deepdiver_v2/constraints.cloud.txt").read_bytes()).hexdigest()
            artifact_digest = hashlib.sha256((root / "deepdiver_v2/requirements.cloud.hashes.txt").read_bytes()).hexdigest()
            lock_valid = (lock.get("schema") == "sciassistant.dependency-lock/v2"
                          and lock.get("sha256") == artifact_digest
                          and lock.get("constraints_sha256") == constraint_digest
                          and isinstance(lock.get("package_count"), int) and lock["package_count"] > 0
                          and lock.get("base_image") == BASE_IMAGE
                          and lock.get("platform") == "linux/amd64")
        except (OSError, UnicodeError, ValueError, TypeError, AttributeError):
            lock_valid = False
        check(checks, "dependency_lock_record", lock_valid)
    else:
        try:
            rules = (root / "Dockerfile.account.cloud.dockerignore").read_text(encoding="utf-8").splitlines()
            dockerfile = (root / "Dockerfile.account.cloud").read_text(encoding="utf-8")
        except (OSError, UnicodeError):
            rules, dockerfile = [], ""
        check(checks, "account_context_allowlist", "**" in rules and all(rule in rules for rule in (
            "!chatAi/*.html", "!chatAi/images/**", "!science_pdf_sessions.py", "!multi_agent_local_pdf.py", "!multi_agent_sources.py", "**/.env", "**/.env.*", "**/*.sql")))
        check(checks, "explicit_runtime_copy", "COPY . " not in dockerfile and "COPY chatAi /app/chatAi" in dockerfile)
        check(checks, "license_files_in_account_image", "COPY LICENSE NOTICE /app/" in dockerfile)
        check(checks, "image_build_gate", "cloud_release.py image-check" in dockerfile and "cloud_release.py stamp" in dockerfile)
        try:
            research_dockerfile = (root / "Dockerfile.cloud").read_text(encoding="utf-8")
            research_rules = (root / "Dockerfile.cloud.dockerignore").read_text(encoding="utf-8").splitlines()
            lock_script = (root / "tools/dependency_lock.py").read_text(encoding="utf-8")
        except (OSError, UnicodeError):
            research_dockerfile = lock_script = ""
            research_rules = []
        for label, content in (("account", dockerfile), ("research", research_dockerfile)):
            check(checks, label + "_base_image_digest_pinned", BASE_IMAGE in content)
            check(checks, label + "_cloud_constraints_install", (
                "requirements.cloud.txt" in content and "constraints.cloud.txt" in content
                and "requirements.cloud.hashes.txt" in content
                and "--require-hashes --no-deps" in content
                and 'test "$TARGETPLATFORM" = "linux/amd64"' in content
                and "dependency_lock.py verify-installed" in content and "pip check" in content))
        check(checks, "dependency_lock_tool_safe", "urllib" not in lock_script and "requests" not in lock_script)
        check(checks, "research_context_allowlist", "**" in research_rules and all(rule in research_rules for rule in (
            "!deepdiver_v2/constraints.cloud.txt", "!deepdiver_v2/requirements.cloud.hashes.txt",
            "!chatAi/*.html", "!science_pdf_sessions.py", "!multi_agent_local_pdf.py", "!multi_agent_sources.py", "**/.env", "**/*.sql")))
        check(checks, "research_explicit_runtime_copy", "COPY . " not in research_dockerfile
              and "COPY deepdiver_v2 /app/deepdiver_v2" in research_dockerfile)
    return result(checks)


def env_checks(path, allow_http_model=False):
    from dotenv.parser import parse_stream
    checks, warnings = [], []
    try:
        bindings = list(parse_stream(io.StringIO(Path(path).read_text(encoding="utf-8-sig"))))
        values = {item.key: item.value or "" for item in bindings if item.key}
        check(checks, "env_syntax", not any(item.error for item in bindings))
    except (OSError, UnicodeError):
        return result([{"check": "env_readable", "passed": False}])

    def private(value, minimum):
        value = value.strip()
        return len(value) >= minimum and not any(marker in value.lower() for marker in (
            "replace_", "change-me", "changeme", "your-secret", "your_secret", "${")) and value.lower() not in {"secret", "password"}

    def memory_limit_valid(name, default, minimum, maximum):
        raw = values.get(name, default).strip().lower()
        match = re.fullmatch(r"([1-9][0-9]*)(b|k|kb|m|mb|g|gb)?", raw)
        if not match:
            return False
        multiplier = {
            "": 1, "b": 1, "k": 1024, "kb": 1024,
            "m": 1024 ** 2, "mb": 1024 ** 2,
            "g": 1024 ** 3, "gb": 1024 ** 3,
        }[match.group(2) or ""]
        size = int(match.group(1)) * multiplier
        return minimum <= size <= maximum

    def cpu_limit_valid(name, default, minimum=0.25, maximum=8.0):
        try:
            value = float(values.get(name, default).strip())
        except (TypeError, ValueError):
            return False
        return minimum <= value <= maximum

    def integer_limit_valid(name, default, minimum, maximum):
        try:
            value = int(values.get(name, default).strip())
        except (TypeError, ValueError):
            return False
        return minimum <= value <= maximum

    check(checks, "production_environment", values.get("APP_ENV", "").strip().lower() == "production")
    license_mode = values.get("PYMUPDF_LICENSE_MODE", "review-required").strip().lower()
    commercial_confirmed = values.get("PYMUPDF_COMMERCIAL_LICENSE_CONFIRMED", "false").strip().lower()
    truthy = {"1", "true", "yes", "on"}
    check(checks, "pymupdf_license_mode_supported", license_mode in {"commercial", "agpl"})
    if license_mode == "commercial":
        check(checks, "pymupdf_commercial_license_confirmed", commercial_confirmed in truthy)
    elif license_mode == "agpl":
        # Operator attestations, NOT a legal determination or a network probe.
        for key in ("PYMUPDF_AGPL_OBLIGATIONS_CONFIRMED", "PYMUPDF_CORRESPONDING_SOURCE_CONFIRMED"):
            check(checks, key.lower(), values.get(key, "").strip().lower() in truthy)
        try:
            source = urlsplit(values.get("PYMUPDF_SOURCE_URL", "").strip())
            host = (source.hostname or "").lower()
            source_ok = (source.scheme == "https" and bool(host) and not source.username
                         and not source.password and not source.query and not source.fragment
                         and not host.endswith((".invalid", ".example", ".test"))
                         and host not in {"localhost", "example.com", "example.org", "example.net"}
                         and not host.endswith((".example.com", ".example.org", ".example.net")))
        except ValueError:
            source_ok = False
        check(checks, "pymupdf_source_url_configured", source_ok)
        warnings.append("agpl_operator_attestation_only_source_delivery_requires_manual_verification")
    check(checks, "stable_private_jwt_key", private(values.get("SECRET_KEY", ""), 32))
    check(checks, "stable_private_mcp_secret", private(values.get("MCP_SHARED_SECRET", ""), 32))
    app_user = values.get("MYSQL_APP_USER", "").strip()
    migration_user = values.get("MYSQL_MIGRATION_USER", "").strip()
    check(checks, "application_db_user_not_root", bool(app_user) and app_user.lower() != "root")
    check(checks, "migration_db_user_not_root", bool(migration_user) and migration_user.lower() != "root")
    check(checks, "database_users_separate", bool(app_user) and bool(migration_user) and app_user != migration_user)
    for key in ("MYSQL_APP_PASSWORD", "MYSQL_MIGRATION_PASSWORD", "MYSQL_ROOT_PASSWORD"):
        check(checks, key + "_configured", private(values.get(key, ""), 12))
    database_passwords = [values.get(key, "") for key in (
        "MYSQL_APP_PASSWORD", "MYSQL_MIGRATION_PASSWORD", "MYSQL_ROOT_PASSWORD")]
    check(checks, "separate_db_passwords", len(set(database_passwords)) == 3)
    check(checks, "account_shared_provider_keys_absent", all(not values.get(key, "").strip()
          for key in ("MODEL_REQUEST_TOKEN", "MODEL_REQUEST_TOKENS", "LLAMA_CLOUD_API_KEY", "EMBEDDING_API_KEY")))
    master = values.get("USER_CREDENTIAL_ENCRYPTION_KEY", "")
    check(checks, "account_vault_master_private_if_set", not master or private(master, 32))
    try:
        url = urlsplit(values.get("MODEL_REQUEST_URL", ""))
        good_url = bool(url.hostname) and not url.username and not url.password and not url.query and not url.fragment
        good_url = good_url and url.scheme in (("https", "http") if allow_http_model else ("https",))
        good_url = good_url and not (url.hostname == "example.com" or url.hostname.endswith(".example.com"))
    except ValueError:
        good_url = False
    check(checks, "provider_url_safe", good_url)
    if allow_http_model:
        warnings.append("http_model_endpoint_explicitly_allowed")
    cors_origins = []
    cors_valid = True
    for candidate in re.split(r"[,;\n]", values.get("CORS_ALLOWED_ORIGINS", "")):
        candidate = candidate.strip()
        if not candidate:
            continue
        try:
            cors = urlsplit(candidate)
            valid_origin = cors.scheme == "https" and bool(cors.hostname)
            valid_origin = valid_origin and cors.username is None and cors.password is None
            valid_origin = valid_origin and cors.path in {"", "/"} and not cors.query and not cors.fragment
            cors.port
        except ValueError:
            valid_origin = False
        normalized = f"{cors.scheme.lower()}://{cors.netloc.lower()}" if valid_origin else ""
        if not valid_origin or "*" in candidate or normalized in cors_origins:
            cors_valid = False
        else:
            cors_origins.append(normalized)
    check(checks, "cors_exact_https_origins", cors_valid)
    try:
        bind_address = ipaddress.ip_address(values.get("ACCOUNT_BIND_ADDRESS", "127.0.0.1").strip())
        bind_safe = isinstance(bind_address, ipaddress.IPv4Address) and bind_address.is_loopback
    except ValueError:
        bind_safe = False
    try:
        host_port_safe = 1 <= int(values.get("ACCOUNT_HOST_PORT", "5000")) <= 65535
    except ValueError:
        host_port_safe = False
    check(checks, "account_bind_ipv4_loopback", bind_safe)
    check(checks, "account_host_port_range", host_port_safe)
    for name, default, minimum, maximum in (
        ("ACCOUNT_MEMORY_LIMIT", "2g", 512 * 1024 ** 2, 8 * 1024 ** 3),
        ("MCP_MEMORY_LIMIT", "2g", 512 * 1024 ** 2, 8 * 1024 ** 3),
        ("MYSQL_MEMORY_LIMIT", "1g", 256 * 1024 ** 2, 8 * 1024 ** 3),
        ("SCHEMA_MEMORY_LIMIT", "256m", 128 * 1024 ** 2, 2 * 1024 ** 3),
    ):
        check(checks, name + "_range", memory_limit_valid(name, default, minimum, maximum))
    for name, default in (
        ("ACCOUNT_CPU_LIMIT", "2.0"), ("MCP_CPU_LIMIT", "2.0"),
        ("MYSQL_CPU_LIMIT", "1.0"), ("SCHEMA_CPU_LIMIT", "0.5"),
    ):
        check(checks, name + "_range", cpu_limit_valid(name, default))
    for name, default, minimum, maximum in (
        ("ACCOUNT_PIDS_LIMIT", "256", 64, 1024),
        ("MCP_PIDS_LIMIT", "256", 64, 1024),
        ("MYSQL_PIDS_LIMIT", "256", 64, 1024),
        ("SCHEMA_PIDS_LIMIT", "64", 16, 256),
    ):
        check(checks, name + "_range", integer_limit_valid(name, default, minimum, maximum))
    reset_enabled = values.get("PASSWORD_RESET_ENABLED", "false").strip().lower() in {"1", "true", "yes", "on"}
    check(checks, "password_reset_flag_valid", values.get("PASSWORD_RESET_ENABLED", "false").strip().lower() in {
        "0", "1", "false", "true", "no", "yes", "off", "on"})
    if reset_enabled:
        try:
            reset_url = urlsplit(values.get("PASSWORD_RESET_BASE_URL", ""))
            reset_url.port
            reset_url_safe = (reset_url.scheme == "https" and bool(reset_url.hostname)
                              and reset_url.username is None and reset_url.password is None
                              and not reset_url.query and not reset_url.fragment)
            smtp_port_valid = 1 <= int(values.get("SMTP_PORT", "587")) <= 65535
            reset_ttl_valid = 300 <= int(values.get("PASSWORD_RESET_TOKEN_TTL_SECONDS", "900")) <= 3600
        except (TypeError, ValueError):
            reset_url_safe = smtp_port_valid = reset_ttl_valid = False
        check(checks, "password_reset_https_url", reset_url_safe)
        check(checks, "password_reset_smtp_host", bool(values.get("SMTP_HOST", "").strip()))
        check(checks, "password_reset_smtp_port", smtp_port_valid)
        check(checks, "password_reset_smtp_username", bool(values.get("SMTP_USERNAME", "").strip()))
        check(checks, "password_reset_smtp_password", private(values.get("SMTP_PASSWORD", ""), 12))
        check(checks, "password_reset_smtp_from", "@" in values.get("SMTP_FROM", ""))
        check(checks, "password_reset_smtp_tls", values.get("SMTP_USE_TLS", "true").strip().lower() in {"1", "true", "yes", "on"})
        check(checks, "password_reset_ttl", reset_ttl_valid)
    else:
        warnings.append("password_reset_disabled")
    for name in ("SCIASSISTANT_TASK_WORKERS", "WEB_CONCURRENCY"):
        check(checks, name + "_single", values.get(name, "1").strip() == "1")
    for name, default, maximum in (("WEB_TASK_TIMEOUT", "900", 86400), ("ARXIV_PAPER_TASK_TIMEOUT", "240", 900),
                                  ("ARXIV_PAPER_CONTEXT_CHARS", "48000", 80000), ("WEB_RETRIEVAL_MAX_CONCURRENT", "8", 64)):
        try:
            number = int(values.get(name, default))
            minimum = {"ARXIV_PAPER_TASK_TIMEOUT": 30, "ARXIV_PAPER_CONTEXT_CHARS": 4000}.get(name, 1)
            valid = minimum <= number <= maximum
        except ValueError:
            valid = False
        check(checks, name + "_range", valid)
    for name, default, minimum, maximum in (
        ("AUTH_LOGIN_IDENTITY_LIMIT", "8", 1, 1000),
        ("AUTH_LOGIN_CLIENT_LIMIT", "30", 1, 5000),
        ("AUTH_LOGIN_WINDOW_SECONDS", "300", 10, 86400),
        ("AUTH_REGISTER_IDENTITY_LIMIT", "3", 1, 1000),
        ("AUTH_REGISTER_CLIENT_LIMIT", "15", 1, 5000),
        ("AUTH_REGISTER_WINDOW_SECONDS", "3600", 10, 86400),
        ("AUTH_RATE_LIMIT_MAX_KEYS", "10000", 100, 1000000),
        ("AUTH_RESET_REQUEST_IDENTITY_LIMIT", "3", 1, 100),
        ("AUTH_RESET_REQUEST_CLIENT_LIMIT", "10", 1, 500),
        ("AUTH_RESET_REQUEST_WINDOW_SECONDS", "900", 60, 86400),
        ("AUTH_RESET_CONFIRM_IDENTITY_LIMIT", "5", 1, 100),
        ("AUTH_RESET_CONFIRM_CLIENT_LIMIT", "20", 1, 500),
        ("AUTH_RESET_CONFIRM_WINDOW_SECONDS", "900", 60, 86400),
    ):
        try:
            valid = minimum <= int(values.get(name, default)) <= maximum
        except ValueError:
            valid = False
        check(checks, name + "_range", valid)
    revision = values.get("SCIASSISTANT_BUILD_REVISION", "unknown")
    check(checks, "build_revision_format", bool(re.fullmatch(r"[0-9a-f]{7,40}|unknown", revision)))
    if revision == "unknown":
        warnings.append("image_revision_unknown")
    return result(checks, warnings)


def stamp(root, revision):
    if not re.fullmatch(r"[0-9a-f]{7,40}|unknown", revision):
        return result([{"check": "build_revision_format", "passed": False}])
    report = file_checks(root, image=True)
    if report["passed"]:
        digest, complete = source_fingerprint(root)
        if not complete:
            return result([{"check": "source_identity_complete", "passed": False}])
        # Explicit stamp command only; other checks never write files.
        lock = json.loads((Path(root) / ".dependency-lock.json").read_text(encoding="utf-8"))
        dependency_lock = {key: lock[key] for key in (
            "sha256", "constraints_sha256", "package_count", "base_image", "platform")}
        (Path(root) / ".build-info.json").write_text(json.dumps({"schema": "sciassistant.build/v1",
            "revision": revision, "source_fingerprint": digest,
            "dependency_lock": dependency_lock}), encoding="utf-8")
    return report


def smoke(base_url, allow_remote=False):
    import requests
    checks = []
    try:
        url = urlsplit(base_url)
        valid = url.scheme in {"http", "https"} and bool(url.hostname) and not url.username and not url.password
        valid = valid and not url.query and not url.fragment and url.path in {"", "/"}
        valid = valid and (allow_remote or url.hostname in {"localhost", "127.0.0.1", "::1"})
    except ValueError:
        valid = False
    if not valid:
        return result([{"check": "smoke_target_safe", "passed": False}])
    endpoints = (
        ("/api/health", "health", 200), ("/login.html", "login", 200), ("/ai_chat.html", "chat", 200),
        ("/images/logo.png", "png", 200), ("/api/science/tasks/__release_smoke__", "unauth", 401),
        ("/8000/api/concurrency", "unauth", 401), ("/8088/v1/models", "unauth", 401),
    )
    with requests.Session() as session:
        session.trust_env = False  # no netrc, ambient proxy or account JWT
        for path, kind, status in endpoints:
            session.cookies.clear()
            try:
                with session.get(base_url.rstrip("/") + path, timeout=(3, 5), allow_redirects=False, stream=True) as response:
                    body = bytearray()
                    for chunk in response.iter_content(16384):
                        body.extend(chunk)
                        if len(body) > 524288:
                            break
                    passed = response.status_code == status and len(body) <= 524288
                    if kind == "health":
                        payload = json.loads(body.decode("utf-8"))
                        runtime = payload.get("runtime") or {}
                        passed = passed and payload.get("status") == "healthy" and runtime.get("component") == "account_gateway"
                        passed = passed and runtime.get("source_complete") is True and runtime.get("code_on_disk_matches_startup") is True
                        passed = passed and runtime.get("image_source_matches_startup") is not False
                        passed = passed and bool(re.fullmatch(r"[0-9a-f]{64}", str(runtime.get("source_fingerprint", ""))))
                    elif kind in {"login", "chat"}:
                        marker = b'id="loginBtn"' if kind == "login" else b'id="chat-messages"'
                        passed = passed and "text/html" in response.headers.get("Content-Type", "") and marker in body
                    elif kind == "png":
                        passed = passed and body.startswith(b"\x89PNG\r\n\x1a\n")
                    elif kind == "unauth":
                        passed = passed and isinstance(json.loads(body.decode("utf-8")), dict)
                    check(checks, "GET:" + path, passed)
            except Exception:
                check(checks, "GET:" + path, False)
    return result(checks)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("repo-check", "image-check", "stamp"):
        sub = commands.add_parser(name)
        sub.add_argument("--root", type=Path, default=ROOT)
        if name == "stamp":
            sub.add_argument("--revision", required=True)
    sub = commands.add_parser("env-check")
    sub.add_argument("--env-file", type=Path, required=True)
    sub.add_argument("--allow-http-model", action="store_true")
    sub = commands.add_parser("smoke")
    sub.add_argument("--base-url", required=True)
    sub.add_argument("--allow-remote", action="store_true")
    args = parser.parse_args()
    try:
        if args.command == "env-check":
            report = env_checks(args.env_file, args.allow_http_model)
        elif args.command == "smoke":
            report = smoke(args.base_url, args.allow_remote)
        elif args.command == "stamp":
            report = stamp(args.root, args.revision)
        else:
            report = file_checks(args.root, image=args.command == "image-check")
    except Exception:
        report = result([{"check": "release_check_execution", "passed": False}])
    print(json.dumps(report, ensure_ascii=False))
    return 0 if report["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
