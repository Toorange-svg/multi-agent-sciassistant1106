"""Real parser-only acceptance; cloud mode incurs LlamaParse fees, not LLM calls.

Reads only the explicitly selected account vault. Saves extraction artifacts in
a fresh private validation directory; prints counts, never text/keys/job IDs.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def worker(pdf, output, mode):
    # Same production parser/client, with transport-only instrumentation in this
    # disposable validation process. Never persist provider error bodies.
    import tools.multi_agent_parse_pdf as product
    import requests
    transport = []
    original = product.DeadlineHttp
    class DiagnosticHttp(original):
        def request(self, method, url, **kwargs):
            stage = 'upload' if '/beta/files' in url else 'parse'
            try:
                response = super().request(method, url, **kwargs)
                transport.append({'stage': stage, 'http_status': response.status_code})
                return response
            except Exception as exc:
                category = ('TLS_ERROR' if isinstance(exc, requests.exceptions.SSLError) else
                            'NETWORK_TIMEOUT' if isinstance(exc, (requests.exceptions.Timeout, TimeoutError)) else
                            'NETWORK_CONNECTION_ERROR' if isinstance(exc, requests.exceptions.ConnectionError) else
                            'BOUNDED_TRANSPORT_REJECTED')
                transport.append({'stage': stage, 'error_code': category})
                raise
    product.DeadlineHttp = DiagnosticHttp
    try:
        parsed = product.parse_document(pdf, mode, mode != 'local', 120)
    finally:
        product.DeadlineHttp = original
    parsed['validation_transport_summary'] = transport
    Path(output).write_text(json.dumps(parsed, ensure_ascii=False), encoding='utf8')
    return 0 if parsed.get('success') else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-id', required=True)
    parser.add_argument('--pdf', type=Path, required=True)
    parser.add_argument('--credential-user', required=True)
    parser.add_argument('--modes', nargs='+', choices=('local', 'llama_full', 'hybrid'), default=['local'])
    parser.add_argument('--allow-cloud', action='store_true')
    args = parser.parse_args()
    if not re.fullmatch('[a-z0-9-]{1,80}', args.run_id) or len(set(args.modes)) != len(args.modes):
        parser.error('invalid unique run id or duplicate modes')
    if any(mode != 'local' for mode in args.modes) and not args.allow_cloud:
        parser.error('cloud transmission requires --allow-cloud')
    from multi_agent_local_pdf import validate_pdf_input
    pdf = validate_pdf_input(args.pdf)
    out = ROOT/'logs/parser_delivery_validation'/args.run_id
    if out.exists(): parser.error('run id already exists')
    out.mkdir(parents=True)
    result = {'schema_version': 'sciassistant.parser-delivery-check/v1', 'passed': False,
              'source_sha256': hashlib.sha256(pdf.read_bytes()).hexdigest(),
              'llm_calls': 0, 'scientific_quality_verified': False, 'modes': []}
    try:
        from dotenv import dotenv_values
        from user_credentials import CredentialStore, provider_scope, child_environment
        values = {**dotenv_values(ROOT/'deepdiver_v2/config/.env', interpolate=False),
                  **dotenv_values(ROOT/'.env', interpolate=False), **os.environ}
        store = CredentialStore(values.get('SCIASSISTANT_USER_CREDENTIAL_DB', ROOT/'logs/user_credentials.sqlite3'),
                                values.get('USER_CREDENTIAL_ENCRYPTION_KEY') or values.get('SECRET_KEY'))
        cap = store.capability(args.credential_user)
        if any(mode != 'local' for mode in args.modes) and not cap.values.get('LLAMA_CLOUD_API_KEY', '').startswith('llx-'):
            raise ValueError('ACCOUNT_LLAMA_KEY_REQUIRED')
        with provider_scope(cap):
            env = child_environment({**os.environ, 'SCIASSISTANT_USER_RUNTIME_ROOT': str(out/'private-runtime')})
        env.update(PYTHONDONTWRITEBYTECODE='1', PYTHONIOENCODING='utf-8')
        for mode in args.modes:
            target = out/(mode+'.json')
            argv = [sys.executable, str(Path(__file__).resolve()), '_worker', str(pdf.resolve()), str(target), mode]
            if mode != 'local': argv.append('--cloud-consent')
            started = time.monotonic()
            call = subprocess.run(argv, cwd=ROOT, env=env, stdout=subprocess.DEVNULL,
                                  stderr=subprocess.DEVNULL, timeout=150)
            parsed = json.loads(target.read_text(encoding='utf-8-sig')) if target.is_file() else {}
            summary = parsed.get('parser_summary') or {}
            blocks = parsed.get('layout_blocks') or parsed.get('evidence_blocks') or []
            cloud = [block for block in blocks if block.get('source_parser') == 'llamaparse']
            actual = summary.get('actual', 'local' if mode == 'local' else None)
            row = {'requested': mode, 'actual': actual, 'success': parsed.get('success') is True and call.returncode == 0,
                   'elapsed_seconds': round(time.monotonic()-started, 2), 'block_count': len(blocks),
                   'cloud_page_count': len(cloud), 'cloud_status': summary.get('cloud_status'),
                   'cloud_boxes_not_invented': all(block.get('bbox') is None for block in cloud),
                   'cloud_pages_ordered': [block.get('page') for block in cloud] == list(range(1, len(cloud)+1)),
                   'fallback': summary.get('fallback'), 'error_code': parsed.get('error_code') or summary.get('warning_code')}
            row['transport'] = parsed.get('validation_transport_summary') or []
            row['passed'] = bool(row['success'] and blocks and actual == mode and row['cloud_boxes_not_invented']
                                 and (mode == 'local' or cloud and row['cloud_status'] == 'completed' and row['cloud_pages_ordered']))
            result['modes'].append(row)
            if not row['passed']: break  # preserve first failure; no repeated paid draws
        result['passed'] = len(result['modes']) == len(args.modes) and all(row['passed'] for row in result['modes'])
    except Exception as exc:
        result['error'] = 'PARSER_DELIVERY_VALIDATION_FAILED'
        result['exception_type'] = type(exc).__name__
    finally:
        (out/'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf8')
    print(json.dumps(result, ensure_ascii=True))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    if len(sys.argv) >= 2 and sys.argv[1] == '_worker':
        if len(sys.argv) not in {5, 6} or sys.argv[4] not in {'local', 'llama_full', 'hybrid'}:
            raise SystemExit(2)
        if sys.argv[4] != 'local' and (len(sys.argv) != 6 or sys.argv[5] != '--cloud-consent'):
            raise SystemExit(2)
        raise SystemExit(worker(sys.argv[2], sys.argv[3], sys.argv[4]))
    raise SystemExit(main())
