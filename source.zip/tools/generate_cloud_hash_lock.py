"""Generate the Linux/amd64 cloud artifact hash lock from a wheelhouse.

This maintenance command is intentionally offline. Download artifacts in the
pinned cloud base image first, then point this tool at that isolated directory.
"""
import argparse
import hashlib
import json
from pathlib import Path

from packaging.utils import canonicalize_name, parse_sdist_filename, parse_wheel_filename

try:
    from .dependency_lock import parse_constraints
except ImportError:  # Direct script execution adds tools/ rather than repo root.
    from dependency_lock import parse_constraints


def artifact_identity(path):
    if path.name.endswith(".whl"):
        name, version, _build, _tags = parse_wheel_filename(path.name)
    elif path.name.endswith((".tar.gz", ".zip")):
        name, version = parse_sdist_filename(path.name)
    else:
        raise ValueError("unsupported_artifact")
    return canonicalize_name(name), str(version)


def generate(constraints_path, wheelhouse, output, platform):
    constraints, errors = parse_constraints(constraints_path)
    if errors:
        raise ValueError("invalid_constraints")
    artifacts = {}
    for path in sorted(Path(wheelhouse).iterdir()):
        if not path.is_file():
            continue
        name, version = artifact_identity(path)
        if name in artifacts:
            raise ValueError("duplicate_artifact:" + name)
        artifacts[name] = (version, hashlib.sha256(path.read_bytes()).hexdigest(), path.name)
    if set(artifacts) != set(constraints):
        raise ValueError("artifact_set_mismatch")
    if any(artifacts[name][0] != version for name, version in constraints.items()):
        raise ValueError("artifact_version_mismatch")
    lines = [
        "# Generated from downloaded artifacts; do not edit individual hashes.",
        f"# Target: {platform}, CPython 3.11, {len(constraints)} locked distributions.",
    ]
    for name, version in constraints.items():
        lines.append(f"{name}=={version} --hash=sha256:{artifacts[name][1]}")
    content = "\n".join(lines) + "\n"
    Path(output).write_text(content, encoding="utf-8", newline="\n")
    return {"schema": "sciassistant.hash-lock-generation/v1", "platform": platform,
            "package_count": len(constraints), "artifact_count": len(artifacts),
            "sha256": hashlib.sha256(content.encode("utf-8")).hexdigest()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--constraints", type=Path, required=True)
    parser.add_argument("--wheelhouse", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--platform", default="linux/amd64")
    args = parser.parse_args()
    try:
        report = generate(args.constraints, args.wheelhouse, args.output, args.platform)
        exit_code = 0
    except (OSError, UnicodeError, ValueError) as error:
        report = {"schema": "sciassistant.hash-lock-generation/v1", "passed": False,
                  "error": str(error).split(":", 1)[0]}
        exit_code = 2
    else:
        report["passed"] = True
    print(json.dumps(report, sort_keys=True))
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
