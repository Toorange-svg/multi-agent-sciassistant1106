"""Independent public literature-source checker.

Does not start SciAssistant, MCP, or any web server. It probes the selected
source, optionally downloads public PDFs, and optionally runs local parsing.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "deepdiver_v2"))
sys.path.insert(0, str(ROOT))
from src.literature_sources import SOURCE_ORDER, deduplicate, download_pdf, search_source


def parse_pdf(path: str):
    from pdf_pipeline import build_parse_metadata, parse_pdf as parse
    parsed = parse(path)
    return parsed, build_parse_metadata(parsed, preview_chars=300) if parsed.get("success") else {}


def main() -> int:
    parser = argparse.ArgumentParser(description="独立检查 arXiv/Zenodo/TechRxiv/HAL 文献来源")
    parser.add_argument("--query", required=True)
    parser.add_argument("--source", choices=("all", *SOURCE_ORDER), default="all")
    parser.add_argument("--limit", type=int, default=3)
    parser.add_argument("--download", action="store_true")
    parser.add_argument("--parse", action="store_true")
    args = parser.parse_args()
    sources = SOURCE_ORDER if args.source == "all" else (args.source,)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out = ROOT / "logs" / "literature_source_checks" / stamp
    (out / "raw").mkdir(parents=True, exist_ok=True)
    (out / "papers").mkdir(parents=True, exist_ok=True)
    report = {"checked_at": datetime.now().isoformat(), "query": args.query, "sources_attempted": list(sources), "sources_succeeded": [], "sources_failed": [], "failure_types": [], "queries_by_source": {s: args.query for s in sources}, "papers_by_source": {}, "fulltext_by_source": {}, "results": []}
    all_papers = []
    for source in sources:
        result = search_source(source, args.query, max(1, min(args.limit, 10)))
        (out / "raw" / f"{source}.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        papers = result.get("papers") or []
        report["papers_by_source"][source] = len(papers)
        if result.get("status") == "ok":
            report["sources_succeeded"].append(source)
        else:
            report["sources_failed"].append(source)
            report["failure_types"].append({"source": source, "type": result.get("status"), "error": result.get("error")})
        for paper in papers:
            item = dict(paper)
            if args.download:
                item = download_pdf(item, out / "papers")
                if args.parse and item.get("pdf_path"):
                    try:
                        parsed, metadata = parse_pdf(item["pdf_path"])
                        target_dir = Path(item["pdf_path"]).parent
                        (target_dir / "paper.txt").write_text(parsed.get("text", ""), encoding="utf-8")
                        (target_dir / "parse_metadata.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
                        item["parse_status"] = "parsed" if parsed.get("success") else "failed"
                        if not parsed.get("success"): item["parse_error"] = parsed.get("error")
                    except Exception as exc:
                        item["parse_status"] = "failed"
                        item["parse_error"] = str(exc)
            all_papers.append(item)
        processed = [p for p in all_papers if p.get("source") == source]
        result["papers"] = processed
        report["fulltext_by_source"][source] = {"available": sum(1 for p in processed if p.get("download_status") == "downloaded"), "parsed": sum(1 for p in processed if p.get("parse_status") == "parsed")}
        report["results"].append(result)
        print(f"\n来源：{source}\n状态：{result.get('status')}\nHTTP：{result.get('http_status', 'n/a')}\n耗时：{result.get('elapsed_ms', 'n/a')} ms\n返回论文数：{len(processed)}")
        if processed:
            # Display the post-download/post-parse record, not the raw search
            # object; otherwise a successful PDF operation is incorrectly
            # shown as ``not_attempted`` in the terminal.
            first = processed[0]
            print(f"第一篇论文：{first.get('title', '')}\n全文 URL：{', '.join(first.get('fulltext_urls') or []) or '无'}")
            if args.download:
                print(f"PDF：{first.get('download_status')}，大小：{first.get('pdf_bytes', 'n/a')}，解析：{first.get('parse_status')}")
        if result.get("error"): print(f"失败原因：{result['error']}")
    report["deduplicated_papers"] = len(deduplicate(all_papers))
    report["fallback_reason"] = "all_sources_failed" if not report["sources_succeeded"] else None
    (out / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    md = [
        "# SciAssistant 文献来源验证报告", "",
        f"- 查询：`{args.query}`",
        f"- 检查时间：`{report['checked_at']}`",
        f"- 请求来源：{', '.join(sources)}",
        f"- 成功来源：{', '.join(report['sources_succeeded']) or '无'}",
        f"- 失败来源：{', '.join(report['sources_failed']) or '无'}", "",
        "## 来源结果", "",
        "| 来源 | 状态 | HTTP | 耗时(ms) | 返回数 | 下载数 | 解析数 | 错误 |",
        "|---|---|---:|---:|---:|---:|---:|---|",
    ]
    for result in report["results"]:
        source = result.get("source", "")
        processed = result.get("papers") or []
        error = str(result.get("error") or "").replace("|", "\\|").replace("\n", " ")
        md.append(
            f"| {source} | {result.get('status', '')} | {result.get('http_status', 'n/a')} | "
            f"{result.get('elapsed_ms', 'n/a')} | {len(processed)} | "
            f"{sum(1 for p in processed if p.get('download_status') == 'downloaded')} | "
            f"{sum(1 for p in processed if p.get('parse_status') == 'parsed')} | {error or '-'} |"
        )
    md.extend(["", "## 论文明细", ""])
    for result in report["results"]:
        papers = result.get("papers") or []
        if not papers:
            continue
        md.extend([f"### {result.get('source', '')}", ""])
        for index, paper in enumerate(papers, 1):
            md.extend([
                f"#### {index}. {paper.get('title') or '(无标题试记录)' }", "",
                f"- ID：`{paper.get('paper_id', '')}`",
                f"- 作者：{', '.join(paper.get('authors') or []) or '未提供'}",
                f"- 年份：{paper.get('year') or '未提供'}",
                f"- DOI：{paper.get('doi') or '未提供'}",
                f"- 论文页面：{paper.get('landing_url') or '未提供'}",
                f"- 全文 URL：{', '.join(paper.get('fulltext_urls') or []) or '无公开 PDF'}",
                f"- 全文状态：`{paper.get('fulltext_status', '')}`",
                f"- PDF 下载：`{paper.get('download_status', '')}`",
                f"- PDF 大小：`{paper.get('pdf_bytes', 'n/a')}`",
                f"- SHA-256：`{paper.get('sha256', 'n/a')}`",
                f"- 本地解析：`{paper.get('parse_status', '')}`",
            ])
            if paper.get("pdf_path"):
                md.append(f"- 本地文件：`{paper['pdf_path']}`")
            if paper.get("download_error") or paper.get("parse_error"):
                md.append(f"- 失败原因：{paper.get('download_error') or paper.get('parse_error')}")
            abstract = " ".join(str(paper.get("abstract") or "").split())
            if abstract:
                md.extend(["", "摘要：", "", abstract[:1200]])
            md.append("")
    md.extend(["## 输出文件", "", "- `report.json`：机器可读完整报告", "- `report.md`：本文件", "- `summary.txt`：简要摘要", "- `raw/`：各来源原始响应", "- `papers/`：下载的公开 PDF、解析文本和元数据"])
    (out / "report.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    summary = "\n".join([f"SciAssistant 文献来源验证", f"查询：{args.query}", f"JSON报告：{out / 'report.json'}", f"Markdown报告：{out / 'report.md'}", f"成功来源：{', '.join(report['sources_succeeded']) or '无'}", f"失败来源：{', '.join(report['sources_failed']) or '无'}"])
    (out / "summary.txt").write_text(summary, encoding="utf-8")
    print(f"\n{summary}")
    return 0 if report["sources_succeeded"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
