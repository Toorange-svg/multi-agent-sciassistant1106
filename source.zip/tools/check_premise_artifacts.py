"""Read-only premise/provenance/replay checks. Never calls a model or republishes history."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from multi_agent_agents import ArtifactDirectory
from multi_agent_quality import checked_premise_assessments, PREMISE_CHECK_POLICY


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def tree(root):
    if any(p.is_symlink() for p in root.rglob("*")):
        raise ValueError("SOURCE_LINK_REJECTED")
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(root.rglob("*")) if p.is_file()}


def reference_provenance(references, approved):
    """Separate source identity/text from optional abstract page localization."""
    available = {r['evidence_id']: r for r in approved.get('evidence', [])
                 if r.get('review_status') == 'approved'}
    rows = []
    for ref in references:
        source = available.get(ref.get('evidence_id'))
        text = str(source.get('excerpt') or '') if source else ''
        expected = text[:16000]
        # Report exports have a documented exact prefix limit, not arbitrary
        # excerpt substitution or a permission to truncate source witnesses.
        text_match = bool(source and ref.get('excerpt') == expected
            and ref.get('excerpt_truncated') == (len(text) > 16000))
        approved_match = bool(source and ref.get('review_status') == 'approved')
        locator_match = bool(source and ref.get('locator') == source.get('locator'))
        strength_match = bool(source and ref.get('evidence_strength') == source.get('evidence_strength'))
        rows.append({'evidence_id': ref.get('evidence_id'), 'approved_source': approved_match,
            'exported_excerpt_matches_source': text_match, 'locator_matches_source': locator_match,
            'evidence_strength_matches_source': strength_match,
            'evidence_strength': ref.get('evidence_strength'),
            'has_page_and_bbox': bool((ref.get('locator') or {}).get('page') and (ref.get('locator') or {}).get('bbox')),
            'fulltext_located': bool(source and source.get('evidence_strength') == 'fulltext_located'
                and ref.get('evidence_strength') == 'fulltext_located'
                and (ref.get('locator') or {}).get('page') and (ref.get('locator') or {}).get('bbox')
                and locator_match),
            'provenance_valid': approved_match and text_match and locator_match and strength_match})
    ids = [r.get('evidence_id') for r in references]
    return {'schema_version': 'sciassistant.reference-provenance/v1', 'records': rows,
        'all_provenance_valid': len(ids) == len(set(ids)) and all(r['provenance_valid'] for r in rows),
        'all_fulltext_located': bool(rows) and all(r['fulltext_located'] for r in rows),
        'fulltext_located_count': sum(r['fulltext_located'] for r in rows),
        'page_located_count': sum(r['has_page_and_bbox'] for r in rows),
        'semantic_support_verified': False}


def collect(run, *, replay=True):
    before = tree(run)
    manifest = read(run / "manifest.json")
    store = ArtifactDirectory(run / "artifacts")
    final = store.get(manifest["final_artifact_id"])
    refs = final.get("artifact_refs", {})
    plan = store.get(refs["plan"]) if refs.get("plan") else {"groups": []}
    review = store.get(refs["review"]) if refs.get("review") else {}
    approved = store.get(refs["approved"]) if refs.get("approved") else {}
    events = [json.loads(line) for line in (run / "events.jsonl").read_text(encoding="utf8").splitlines()]
    budget = read(run / "budget_usage.json")
    claims, references = read(run / "claim_evidence_map.json"), read(run / "references.json")
    available = {r["evidence_id"] for r in approved.get("evidence", [])}
    used = {key for c in claims for key in c.get("evidence_ids", [])}
    delivery = [read(p) for p in (run / "artifacts").glob("model-delivery-*.json")]
    commands = {}
    if replay:
        for name in ("inspect", "replay"):
            result = subprocess.run([sys.executable, str(ROOT / "tools/multi_agent_cli.py"), name,
                "--run-dir", str(run)], cwd=ROOT, capture_output=True)
            commands[name] = {"exit_code": result.returncode}
            if name == "replay" and not result.returncode:
                commands[name]["recorded_exports_match"] = json.loads(result.stdout)["recorded_exports_match"]
    recorded = store.get(refs["premise_assessment"]) if refs.get("premise_assessment") else None
    draft_data = store.get(refs["draft"]) if refs.get("draft") else {}
    audit_data = store.get(refs["audit"]) if refs.get("audit") else {}
    claim_lookup = {r["claim_id"]: r for r in draft_data.get("claims", [])}
    empty_omissions = [{"claim_id": row["claim_id"], "field": field}
        for row in audit_data.get("claim_results", []) if row.get("claim_id") in claim_lookup
        for field, value in row.get("field_results", {}).items()
        if field in {"text", "scope_note", "qualification"} and isinstance(value, dict)
        and value.get("status") == "not_applicable" and "absence_checks" not in value
        and not str(claim_lookup[row["claim_id"]].get(field) or "").strip()]
    result = {"run_id": manifest["run_id"], "run_dir": str(run.relative_to(ROOT)),
        "source_fingerprint": manifest.get("source_fingerprint"), "source_complete": manifest.get("source_complete"),
        "prompts": {k: r.get("version") for k, r in manifest.get("prompts", {}).items()},
        "recorded_premise_policy": manifest.get("question_premise_policy"),
        "question": store.get(refs["question"]).get("question") if refs.get("question") else None,
        "source_scope": manifest.get("source_scope"), "source_policy": manifest.get("source_policy"),
        "pdf_parse_mode": manifest.get("pdf_parse_mode"), "status": final.get("status"),
        "failure_code": final.get("failure_code"), "model_calls_used": budget.get("model_calls_used"),
        "workflow_seconds": budget.get("elapsed_seconds"),
        "initialization_seconds": manifest.get("initialization_elapsed_seconds"),
        "effective_workflow_budget": manifest.get("effective_workflow_budget_seconds"),
        "roles": dict(Counter(r["agent_role"] for r in delivery)),
        "delivery_count": len(delivery), "all_deliveries_stop": all(r.get("finish_reason") == "stop" for r in delivery),
        "draft_claim_count": len(draft_data.get("claims", [])),
        "empty_field_absence_policy": draft_data.get("empty_field_absence_policy"),
        "empty_not_applicable_omissions": empty_omissions,
        "published_claims": len(claims), "references": len(references),
        "reference_ids_match_published": used == {r["evidence_id"] for r in references},
        "published_evidence_approved": used.issubset(available),
        "reference_provenance": reference_provenance(references, approved),
        "references_with_page": all(r.get("locator", {}).get("page") for r in references),
        "planned_checks": plan.get("premise_checks", []), "recorded_assessment": recorded,
        "current_policy_diagnostic_not_historical_verdict": checked_premise_assessments(review, plan, approved),
        "current_policy": PREMISE_CHECK_POLICY, "historical_status_not_changed": True,
        "public_query_events_not_http_count": sum(1 for event in events if event.get("event") == "retrieval_query"
            and (event.get("source") == "arxiv" or not event.get("source") and manifest.get("source_scope") == "arxiv")),
        "local_query_events": sum(1 for event in events if event.get("event") == "retrieval_query" and event.get("source") == "uploaded_pdf"),
        "audit_protocol_retries": sum(1 for event in events if event.get("event") == "audit_protocol_retry"),
        "rework_tickets": len(list((run / "rework_tickets").glob("*.json"))),
        "replay": commands, "final_answer_sha256": before.get("final_answer.md"),
        "source_file_count": len(before), "source_hashes_unchanged": before == tree(run),
        "scientific_quality_requires_manual_review": True, "model_calls_in_this_check": 0, "network_in_this_check": 0}
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, action="append", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    paths = [p.resolve() for p in args.run_dir]
    target = args.output.resolve()
    if (target.exists() or not target.is_relative_to(ROOT) or any(not p.is_relative_to(ROOT / "logs") for p in paths)
            or any(target.is_relative_to(p) for p in paths)):
        parser.error("new output outside source runs and explicit logs runs required")
    rows = [collect(p) for p in paths]
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("x", encoding="utf8") as stream:
        json.dump({"schema_version": "sciassistant.premise-run-checks/v1", "runs": rows}, stream, ensure_ascii=False, indent=2)
    print(json.dumps({"runs": [{k: row[k] for k in ("run_id", "status", "published_claims", "model_calls_used", "source_hashes_unchanged")} for row in rows]}, ensure_ascii=False))
    return 0 if all(row["source_hashes_unchanged"] and all(r["exit_code"] == 0 for r in row["replay"].values()) for row in rows) else 1


if __name__ == "__main__":
    raise SystemExit(main())
