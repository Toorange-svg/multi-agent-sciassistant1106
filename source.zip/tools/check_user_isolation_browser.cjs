/* Fresh authenticated UI; credentials only through stdin, never output. */
const fs=require('node:fs'),path=require('node:path'),{chromium}=require('playwright');
let input='';process.stdin.setEncoding('utf8');process.stdin.on('data',part=>{input+=part;if(input.length>65536)process.exit(2);});
process.stdin.on('end',async()=>{
 const data=JSON.parse(input),url=new URL(data.base_url),root=path.resolve(data.output_directory);
 if(url.hostname!=='127.0.0.1'||url.port==='5000')throw Error('Owned test server required');
 const checks={},errors=[],traffic=[];let browser;
 try{
  const chrome='C:/Program Files/Google/Chrome/Application/chrome.exe';
  browser=await chromium.launch({headless:true,...(fs.existsSync(chrome)?{executablePath:chrome}:{})});
  const context=await browser.newContext({viewport:{width:1366,height:900},ignoreHTTPSErrors:true});
  const page=await context.newPage();page.on('pageerror',e=>errors.push(e.name));
  page.on('request',r=>{const u=new URL(r.url());if(u.origin===url.origin)traffic.push({path:u.pathname,method:r.method()});});
  await page.goto(data.base_url+'/login.html',{waitUntil:'domcontentloaded'});
  await page.locator('#loginId').fill(data.username);await page.locator('#password').fill(data.password);
  await page.locator('#loginBtn').click();await page.waitForURL('**/ai_chat.html');
  await page.waitForFunction(()=>window.AccountKeys&&window.SciencePdfSession);
  await page.waitForFunction(()=>document.getElementById('account-keys-dialog').open);
  await page.waitForFunction(()=>document.getElementById('account-keys-status').textContent.includes('未配置'));
  checks.current_account_unconfigured_visible=true;
  const secretFields=['account-deepseek-key','account-deepseek-backups','account-llama-key'];
  checks.password_fields=await page.evaluate(ids=>ids.every(id=>document.getElementById(id)?.type==='password'),secretFields);
  await page.locator('#account-deepseek-key').fill(data.model_key);await page.locator('#account-llama-key').fill(data.llama_key);
  await page.locator('#account-keys-save').click();await page.waitForFunction(()=>document.getElementById('account-keys-status').textContent.includes('已配置 1'));
  checks.saved_fields_cleared=await page.evaluate(ids=>ids.every(id=>!document.getElementById(id).value),secretFields);
  checks.no_plaintext_status=!(await page.locator('#account-keys-status').innerText()).includes(data.model_key);
  checks.no_secret_in_browser_storage=await page.evaluate(keys=>[sessionStorage,localStorage].every(storage=>Object.values(storage).every(value=>keys.every(key=>!String(value).includes(key)))),[data.model_key,data.llama_key]);
  await page.screenshot({path:path.join(root,'tenant-keys-wide.png')});
  await page.setViewportSize({width:462,height:900});await page.waitForTimeout(200);
  checks.narrow_dialog_fits=await page.evaluate(()=>{const r=document.getElementById('account-keys-dialog').getBoundingClientRect();return r.left>=0&&r.right<=innerWidth;});
  await page.screenshot({path:path.join(root,'tenant-keys-narrow.png')});
  await page.setViewportSize({width:1366,height:900});
  // Simulate same-tab account change while sensitive input exists: no POST.
  await page.locator('#account-deepseek-key').fill(data.model_key);
  const before=traffic.filter(x=>x.path.endsWith('/account/provider-keys')&&x.method==='POST').length;
  await page.evaluate(async other=>{const old=window.userToken;window.userToken=other;document.getElementById('account-keys-save').click();await Promise.resolve();window.userToken=old;},data.other_token);
  checks.account_change_blocks_save=traffic.filter(x=>x.path.endsWith('/account/provider-keys')&&x.method==='POST').length===before;
  checks.account_change_wipes=await page.evaluate(()=>!document.getElementById('account-keys-dialog').open&&!document.getElementById('account-deepseek-key').value);
  // Genuine backend session with injected delayed response; UI must not wait to show feedback.
  let posts=0;
  await page.route('**/api/chat/sessions',async route=>{if(route.request().method()!=='POST')return route.continue();posts++;
   const response=await route.fetch();await new Promise(resolve=>setTimeout(resolve,1600));await route.fulfill({response});});
  const immediate=await page.evaluate(()=>{const start=performance.now(),button=document.getElementById('new-chat-btn');button.click();button.click();
   return {milliseconds:performance.now()-start,disabled:button.disabled,busy:button.getAttribute('aria-busy')==='true',spinner:!!button.querySelector('.fa-spinner')};});
  checks.immediate_new_session_feedback=immediate.milliseconds<200&&immediate.disabled&&immediate.busy&&immediate.spinner;
  await page.locator('#research-report-profile').selectOption('enhanced');
  await page.locator('#pdf-parse-mode').selectOption('local');
  checks.profile_switch_during_pending_create=await page.locator('#research-report-profile').inputValue()==='enhanced';
  checks.default_mode_is_not_a_selector=await page.evaluate(()=>{const mode=document.getElementById('research-processing-mode');return mode.type==='hidden'&&mode.value==='multi_agent_rag';});
  await page.waitForFunction(()=>window.currentSessionId&&!document.getElementById('new-chat-btn').disabled,{timeout:15000});
  checks.one_create_for_double_click=posts===1;
  const pdfBefore=traffic.filter(x=>x.path.endsWith('/pdf-attachment')&&x.method==='GET').length;
  const modeTime=await page.evaluate(async()=>{const start=performance.now(),profile=document.getElementById('research-report-profile'),parser=document.getElementById('pdf-parse-mode');
   for(let i=0;i<10;i++){profile.value=i%2?'enhanced':'standard';profile.dispatchEvent(new Event('change',{bubbles:true}));parser.value=i%2?'hybrid':'local';parser.dispatchEvent(new Event('change',{bubbles:true}));}
   await new Promise(requestAnimationFrame);return performance.now()-start;});
  await page.waitForTimeout(500);
  const pdfAfter=traffic.filter(x=>x.path.endsWith('/pdf-attachment')&&x.method==='GET').length;
  checks.profile_parser_events_do_not_block_ui=modeTime<250;
  checks.binding_reads_coalesced=pdfAfter-pdfBefore<=1;
  checks.no_model_tasks_from_controls_or_new_session=traffic.filter(x=>x.path.endsWith('/science/tasks')&&x.method==='POST').length===0;
  // Reproduce the missing-CDN condition without relying on a network failure.
  // Only the production dialog markup/rules are copied, with no Tailwind reset.
  const dialogFixture=await page.evaluate(()=>({html:document.getElementById('account-keys-dialog').outerHTML,
   css:[...document.querySelectorAll('style')].flatMap(s=>[...(s.sheet?.cssRules||[])]).filter(r=>r.selectorText?.includes('#account-keys-dialog')).map(r=>r.cssText).join('\n')}));
  const noCdn=await context.newPage();await noCdn.setViewportSize({width:462,height:900});
  await noCdn.setContent('<!doctype html><style>'+dialogFixture.css+'</style>'+dialogFixture.html);
  checks.narrow_without_tailwind=await noCdn.evaluate(()=>{const dialog=document.getElementById('account-keys-dialog');dialog.removeAttribute('open');dialog.showModal();
   const r=dialog.getBoundingClientRect();return r.left>=0&&r.right<=innerWidth&&[...dialog.querySelectorAll('input[type=password]')].every(i=>i.getBoundingClientRect().right<=r.right);});
  await noCdn.close();
  const result={passed:Object.values(checks).every(Boolean)&&!errors.length,checks,page_errors:errors,
   new_session_feedback_ms:immediate.milliseconds,ten_profile_parser_changes_paint_ms:modeTime,
   create_response_delay_injected_ms:1600,pdf_gets_for_ten_control_changes:pdfAfter-pdfBefore,
   real_login_and_api:true,paid_calls:0,stress_limit:'Idle isolated server, not saturated CPU production load'};
  fs.writeFileSync(path.join(root,'tenant_browser_checks.json'),JSON.stringify(result,null,2),{flag:'wx'});console.log(JSON.stringify(result));
  if(!result.passed)process.exitCode=1;
 }catch(e){fs.writeFileSync(path.join(root,'tenant_browser_failure.json'),JSON.stringify({error_type:e.name,checks,page_errors:errors}),{flag:'wx'});process.exitCode=1;}
 finally{await browser?.close();}
});
