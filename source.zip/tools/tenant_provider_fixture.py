"""Validation-only loopback vendor: real HTTP auth hops, synthetic responses.

Never used by production; its known fake keys are not usable vendor secrets.
"""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import hmac
import json
import threading

FAKE_MODEL = {'a':'tenant-a-model-key-for-validation', 'b':'tenant-b-model-key-for-validation'}
FAKE_LLAMA = {'a':'llx-tenant-a-cloud-key-for-validation', 'b':'llx-tenant-b-cloud-key-for-validation'}


def install(gateway, web, signing_key):
    from flask import request, jsonify, g
    from user_credentials import provider_scope
    seen=[];lock=threading.Lock()
    lookup={value:(kind,owner) for kind,mapping in [('model',FAKE_MODEL),('llama',FAKE_LLAMA)] for owner,value in mapping.items()}
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*_args): pass
        def handle_request(self):
            auth=self.headers.get('Authorization','').removeprefix('Bearer ')
            kind,owner=lookup.get(auth,('unknown','unknown'))
            size=min(int(self.headers.get('Content-Length','0')),100_000)
            self.rfile.read(size)
            with lock:seen.append({'kind':kind,'owner':owner,'method':self.command})
            code=200 if owner!='unknown' else 401
            if kind=='model':body={'choices':[{'message':{'content':'TENANT_'+owner},'finish_reason':'stop'}]}
            elif self.command=='POST' and self.path.endswith('/files'):body={'id':'tenant-file'}
            elif self.command=='POST':body={'id':'tenant-job'}
            elif self.command=='GET':body={'status':'COMPLETED','markdown':'TENANT_'+owner}
            else:body={}
            data=json.dumps(body).encode();self.send_response(code);self.send_header('Content-Type','application/json')
            self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
        do_POST=handle_request;do_GET=handle_request;do_DELETE=handle_request
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    threading.Thread(target=server.serve_forever,daemon=True).start()
    url='http://127.0.0.1:'+str(server.server_port)
    import os
    os.environ['MODEL_REQUEST_URL']=url+'/v1/chat/completions'
    os.environ['MODEL_NAME']='tenant-validation-model'
    os.environ['LLAMA_PARSE_ENDPOINT']=url
    @gateway.app.get('/_validation/tenant-probe')
    def probe():
        if not hmac.compare_digest(request.headers.get('X-Validation-Capability',''),signing_key):
            return jsonify(error='not_found'),404
        with lock:return jsonify(attempts=list(seen))
    @gateway.app.post('/_validation/llama-probe')
    @gateway.require_auth
    def llama_probe():
        from deepdiver_v2.src.tools.llama_vision_client import LlamaVisionClient
        with provider_scope(gateway._provider_store().capability(g.current_user_id)):
            client=LlamaVisionClient();client.config.enabled=True;client.config.timeout=10;client.config.max_retries=0
            result=client.review(b'synthetic-validation-region','text')
        return jsonify(status=result.get('status'),transcription=(result.get('review') or {}).get('transcription'))
    return server
