"""Read-only old-public-run audit input comparison. No model, source fetch or republication."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from multi_agent_agents import ArtifactDirectory
from multi_agent_quality import (ABSENCE_MENU_POLICY, ABSENCE_REASON_POLICY, WITNESS_COPY_POLICY, WITNESS_CAPACITY_POLICY,
    absence_assertion_options, citation_audit_input, check_audit, publication_rejections)
from tools.check_premise_artifacts import tree, collect


def probe(run):
    before = tree(run)
    manifest = json.loads((run / 'manifest.json').read_text(encoding='utf-8-sig'))
    store = ArtifactDirectory(run / 'artifacts')
    final = store.get(manifest['final_artifact_id'])
    draft = store.get(final['artifact_refs']['draft'])
    approved = store.get(final['artifact_refs']['approved'])
    audit = store.get(final['artifact_refs']['audit'])
    proposed = deepcopy(draft)
    proposed.update(absence_menu_policy=ABSENCE_MENU_POLICY, absence_reason_policy=ABSENCE_REASON_POLICY,
                    witness_copy_policy=WITNESS_COPY_POLICY, witness_capacity_policy=WITNESS_CAPACITY_POLICY)
    legacy_menu, current_menu = absence_assertion_options(draft), absence_assertion_options(proposed)
    current = check_audit(audit, proposed, approved)
    replay = collect(run)
    audit_input = citation_audit_input(proposed, approved)
    brief = audit_input['assertion_classification_brief']
    return {'schema_version':'sciassistant.audit-classification-probe/v1',
        'run_dir':str(run.relative_to(ROOT)), 'recorded_status':final['status'],
        'legacy_menu':legacy_menu, 'proposed_menu_diagnosis_only':current_menu,
        'classification_brief':brief,
        'source_copy_brief_diagnosis_only':audit_input['source_copy_brief'],
        'source_witness_issues_diagnosis_only':current.get('witness_issues', []),
        'witness_limits_diagnosis_only':audit_input['witness_limits'],
        'proposed_protocol_issues_diagnosis_only':current.get('protocol_issues', []),
        'proposed_blocked_claims_diagnosis_only':sorted(publication_rejections(current, proposed)),
        'recorded_model_rejections_retained':audit.get('rejected_claim_ids', []),
        'source_hashes_unchanged':before == tree(run), 'replay':replay['replay'],
        'answer_sha256':before['final_answer.md'], 'automatic_historical_publication':False,
        'scientific_quality_requires_manual_review':True, 'model_calls':0, 'network_calls':0}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-run', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    run, output = args.source_run.resolve(), args.output.resolve()
    if (not run.is_relative_to(ROOT/'logs') or not output.is_relative_to(ROOT/'logs')
            or output.is_relative_to(run) or output.exists()):
        parser.error('explicit logs source and new logs output outside source required')
    data = probe(run)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('x', encoding='utf-8') as stream:
        json.dump(data, stream, ensure_ascii=False, indent=2)
    print(json.dumps({'source_hashes_unchanged':data['source_hashes_unchanged'],
        'legacy_candidates':len(data['legacy_menu']['options']),
        'current_candidates':len(data['proposed_menu_diagnosis_only']['options']),
        'new_approvals':0, 'model_calls':0, 'network_calls':0}))
    return 0 if data['source_hashes_unchanged'] and all(
        row['exit_code'] == 0 for row in data['replay'].values()) else 1


if __name__ == '__main__':
    raise SystemExit(main())
