"""Cross-platform CLI entry point; intentionally never starts MCP."""

import os
from pathlib import Path
import runpy
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

_FAST_HELP = """usage: run_research.py [-h] [--query QUERY] [--query-file PATH] [options]

SciAssistant research CLI. Normal task execution requires the separately
supervised MCP service when the selected query mode uses research tools.

options:
  -h, --help            show this help and exit
  -q, --query QUERY     execute one question
  --query-file PATH     read a UTF-8 question from a file
  --query-mode MODE     auto, paper_evidence, science_literature, multi_agent_literature, or direct_llm
  --pdf-parse-mode MODE local, llama_full, or hybrid
  --diagnostics-file PATH
                        write sanitized stage diagnostics
  --conversation-context-file PATH
                        load a request-local follow-up context packet
  --workflow-run-id ID  persist one bounded multi-agent workflow under this task ID
  -c, --config-only     show configuration and exit
  -e, --create-env      create a sample environment file
  --quiet [true]        suppress non-essential output
  --export MODE         none, md, pdf, or both
"""


def main() -> int:
    # The dependency check can fail before importing demo.py. Its safe
    # Chinese error must also be UTF-8 under a Windows legacy code page.
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")
    arguments = sys.argv[1:]
    # ``--help`` is an operational diagnostic and must stay available even on
    # a low-memory machine or while optional networking libraries are unable
    # to initialize.  Do not import the research runtime or demo module for a
    # request that can be answered entirely from this stable CLI contract.
    if any(flag in arguments for flag in ("--help", "-h")):
        print(_FAST_HELP, end="")
        return 0
    from research_runtime import (
        ResearchDependencyError, check_shared_mcp, research_command,
        research_environment, requires_shared_mcp,
    )
    # Load local fallbacks just like web_app; non-empty process values win.
    from dotenv import load_dotenv, dotenv_values
    load_dotenv(ROOT / ".env")
    for name, value in dotenv_values(ROOT / "deepdiver_v2" / "config" / ".env").items():
        if value and not os.getenv(name):
            os.environ[name] = value
    environment = research_environment()
    try:
        if requires_shared_mcp(arguments):
            check_shared_mcp(environment)
    except ResearchDependencyError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2
    os.environ.update(environment)
    os.chdir(ROOT)
    sys.argv = research_command(arguments)[2:]
    runpy.run_path(sys.argv[0], run_name="__main__")
    return 0


if __name__ == "__main__":
    sys.exit(main())
