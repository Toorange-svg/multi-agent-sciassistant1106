"""Read-only guard comparison, not publication or scientific approval."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from multi_agent_agents import ArtifactDirectory
from multi_agent_quality import ABSENCE_SCOPE_POLICY, check_absence_basis
from tools.check_premise_artifacts import read, tree


def compare(run):
    before = tree(run)
    manifest = read(run / 'manifest.json')
    store = ArtifactDirectory(run / 'artifacts')
    final = store.get(manifest['final_artifact_id'])
    refs = final['artifact_refs']
    draft, audit = store.get(refs['draft']), store.get(refs['audit'])
    candidate = deepcopy(draft)
    candidate['absence_scope_policy'] = ABSENCE_SCOPE_POLICY
    return {'run_id': manifest['run_id'], 'recorded_policy': draft.get('absence_scope_policy'),
        'candidate_policy': ABSENCE_SCOPE_POLICY,
        'recorded_status': final['status'],
        'recorded_policy_guard_findings': check_absence_basis(audit, draft),
        'candidate_policy_guard_findings': check_absence_basis(audit, candidate),
        'recorded_publication_unchanged': True,
        'semantic_support_verified': False, 'automatic_publication': False,
        'source_hashes_unchanged': before == tree(run), 'model_calls_added': 0, 'network_calls_added': 0}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-dir', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    run, output = args.run_dir.resolve(), args.output.resolve()
    if (not run.is_dir() or not run.is_relative_to(ROOT / 'logs') or output.exists()
            or not output.is_relative_to(ROOT / 'logs') or output.is_relative_to(run)):
        parser.error('explicit source logs run and new logs output outside it required')
    result = compare(run)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('x', encoding='utf-8') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result['source_hashes_unchanged'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
