import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from deepdiver_v2.src.literature_sources import search_source
qs = [
    '(ti:"attention" OR abs:"attention") AND (ti:"sliding" OR abs:"sliding")',
    '(ti:"attention" OR abs:"attention") AND (ti:"window" OR abs:"window")',
    '(ti:"Longformer" OR abs:"Longformer")',
]
for q in qs:
    try:
        r = search_source("arxiv", q, limit=5)
        r = r.get("papers") if isinstance(r, dict) else r
        print(q[:70], "->", len(r or []))
    except Exception as e:
        print(q[:70], "ERR", repr(e))
