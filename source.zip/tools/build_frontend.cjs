// Reproducible offline-at-runtime assets. npm scripts are never executed.
// Build dependencies stay in a dedicated OS temp directory, not the release.
'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const child = require('node:child_process');
const ROOT = path.resolve(__dirname, '..');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const out = name => path.join(ROOT, 'chatAi', name);
const workspace = fs.mkdtempSync(path.join(os.tmpdir(), 'sciassistant-frontend-build-'));
for (const name of ['package.json','package-lock.json']) fs.copyFileSync(path.join(ROOT,'frontend',name),path.join(workspace,name));
const npmCli = [process.env.SCIASSISTANT_NPM_CLI,process.env.npm_execpath,
    path.join(path.dirname(process.execPath),'node_modules/npm/bin/npm-cli.js'),
    path.resolve(path.dirname(process.execPath),'../lib/node_modules/npm/bin/npm-cli.js'),
    '/usr/share/nodejs/npm/bin/npm-cli.js'].find(file=>file && fs.existsSync(file));
const npmArgs = ['ci','--ignore-scripts','--no-audit','--no-fund',
    '--registry=https://registry.npmjs.org','--cache',path.join(workspace,'npm-cache')];
child.execFileSync(npmCli ? process.execPath : 'npm',npmCli ? [npmCli,...npmArgs] : npmArgs,{cwd:workspace,stdio:'inherit'});
const modules = path.join(workspace,'node_modules');
function copy(source, destination) {
    fs.mkdirSync(path.dirname(destination),{recursive:true}); fs.copyFileSync(source,destination);
}
function vendor(pkg, file, target) { copy(path.join(modules,pkg,file),out(target)); }
fs.mkdirSync(out('assets'),{recursive:true});
child.execFileSync(process.execPath,[path.join(modules,'tailwindcss/lib/cli.js'),
    '-c',path.join(ROOT,'frontend/tailwind.config.cjs'),'-i',path.join(ROOT,'frontend/tailwind.css'),
    '-o',out('assets/tailwind.css'),'--minify'],{cwd:ROOT,stdio:'inherit'});
vendor('tailwindcss','LICENSE','vendor/tailwindcss/LICENSE');
vendor('font-awesome','css/font-awesome.min.css','vendor/font-awesome/css/font-awesome.min.css');
for (const name of fs.readdirSync(path.join(modules,'font-awesome/fonts'))) vendor('font-awesome','fonts/'+name,'vendor/font-awesome/fonts/'+name);
vendor('font-awesome','README.md','vendor/font-awesome/README.md');
for (const file of ['katex.min.css','katex.min.js']) vendor('katex','dist/'+file,'vendor/katex/'+file);
for (const name of fs.readdirSync(path.join(modules,'katex/dist/fonts'))) vendor('katex','dist/fonts/'+name,'vendor/katex/fonts/'+name);
vendor('katex','LICENSE','vendor/katex/LICENSE');
const components = ['core','markup','css','clike','javascript','python','typescript','java','c','cpp',
    'csharp','go','rust','bash','sql','json','yaml','markdown'];
const prism = '/*! PrismJS 1.29.0 MIT; see vendor/prism/LICENSE. */\n' + components.map(name =>
    fs.readFileSync(path.join(modules,'prismjs/components/prism-'+name+'.min.js'),'utf8')).join('\n;\n');
fs.mkdirSync(out('vendor/prism'),{recursive:true}); fs.writeFileSync(out('vendor/prism/prism.bundle.js'),prism);
vendor('prismjs','themes/prism.min.css','vendor/prism/prism.min.css');
vendor('prismjs','LICENSE','vendor/prism/LICENSE');
// Content version every same-origin script/stylesheet. HTML is never long cached.
for (const name of ['ai_chat.html','login.html','register.html','forgot-password.html']) {
    const file = out(name);
    const html = fs.readFileSync(file,'utf8').replace(/\b(src|href)="(\/chatAi\/[^"?#]+\.(?:js|css))(?:\?v=[a-f0-9]{12})?"/g,
        (all, attr, url) => `${attr}="${url}?v=${sha(fs.readFileSync(path.join(ROOT,url.slice(1)))).slice(0,12)}"`);
    fs.writeFileSync(file,html);
}
const rows = [];
function inventory(folder) {
    for (const item of fs.readdirSync(folder,{withFileTypes:true})) {
        const file = path.join(folder,item.name);
        if (item.isDirectory()) inventory(file);
        else if (file !== out('assets/manifest.json') && !file.endsWith('.html')) {
            const bytes = fs.readFileSync(file);
            rows.push({path:path.relative(path.join(ROOT,'chatAi'),file).replaceAll('\\','/'),sha256:sha(bytes),bytes:bytes.length});
        }
    }
}
inventory(out('assets')); inventory(out('vendor'));
for (const name of fs.readdirSync(path.join(ROOT,'chatAi')).filter(n=>/\.(?:js|css)$/.test(n))) {
    const bytes=fs.readFileSync(out(name)); rows.push({path:name,sha256:sha(bytes),bytes:bytes.length});
}
rows.sort((a,b)=>a.path.localeCompare(b.path,'en'));
const manifest = {schema_version:'sciassistant.frontend-assets/v1',
    dependencies:JSON.parse(fs.readFileSync(path.join(ROOT,'frontend/package.json'))).devDependencies,
    lock_sha256:sha(fs.readFileSync(path.join(ROOT,'frontend/package-lock.json'))),
    runtime_external_assets:false, files:rows};
fs.writeFileSync(out('assets/manifest.json'),JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({passed:true,files:rows.length,bytes:rows.reduce((n,r)=>n+r.bytes,0),
    external_runtime_requests:0,build_workspace:workspace}));
