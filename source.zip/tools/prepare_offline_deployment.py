"""Prepare an additive offline Docker kit from a frozen delivery, not live source.

Does not load/start services, copy private configuration, or alter the delivery.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

import yaml

IMAGES = ('sciassistant-account:base-rag', 'sciassistant-account:rag-release',
          'sciassistant-qdrant:release', 'mysql:8.4')


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def compose_document(source):
    base = yaml.safe_load((source / 'docker-compose.account.cloud.yml').read_text('utf-8'))
    rag = yaml.safe_load((source / 'docker-compose.account.rag.yml').read_text('utf-8'))
    app = base['services']['sciassistant-account']
    extension = rag['services']['sciassistant-account']
    for key, value in extension.items():
        if key == 'build':
            continue
        if isinstance(value, dict):
            app[key] = {**app.get(key, {}), **value}
        elif key == 'volumes':
            app[key] = app.get(key, []) + value
        else:
            app[key] = value
    base['services']['qdrant'] = rag['services']['qdrant']
    base['volumes'].update(rag['volumes'])
    mapping = {'sciassistant-account': IMAGES[1], 'qdrant': IMAGES[2], 'database': IMAGES[3]}
    for name, service in base['services'].items():
        service.pop('build', None)
        service['image'] = mapping.get(name, IMAGES[0])
        service['pull_policy'] = 'never'
        service['platform'] = 'linux/amd64'
    # Fixed loopback even if an operator accidentally changes a template value.
    app['ports'] = ['127.0.0.1:${ACCOUNT_HOST_PORT:-5000}:5000']
    db = base['services']['database']
    db['volumes'] = [v for v in db['volumes'] if not isinstance(v, str) or 'mysql-init' not in v]
    db['volumes'].append({'type': 'bind', 'source': '${SOURCE_DIRECTORY:?set SOURCE_DIRECTORY}/deploy/mysql-init',
                          'target': '/docker-entrypoint-initdb.d', 'read_only': True,
                          'bind': {'create_host_path': False}})
    # Drop extension anchors: all effective hardening has already been expanded.
    return {key: value for key, value in base.items() if not key.startswith('x-')}


def prepare(source, archive, output):
    source, archive, output = source.resolve(), archive.resolve(), output.resolve()
    if output.exists():
        raise ValueError('OUTPUT_ALREADY_EXISTS')
    if source == output or source in output.parents:
        raise ValueError('OUTPUT_MUST_BE_OUTSIDE_DELIVERY')
    manifest = json.loads((source / 'RELEASE_MANIFEST.json').read_text('utf-8-sig'))
    delivery = json.loads((source / 'DELIVERY_MANIFEST.json').read_text('utf-8-sig'))
    for row in delivery['files']:
        name = Path(row['path'])
        if name.is_absolute() or '..' in name.parts or '\\' in row['path']:
            raise ValueError('UNSAFE_DELIVERY_PATH')
        if sha(source / name) != row['sha256']:
            raise ValueError('DELIVERY_HASH_MISMATCH')
    images = json.loads(subprocess.check_output(['docker', 'image', 'inspect', *IMAGES], text=True))
    for image in images:
        if (image['Os'], image['Architecture']) != ('linux', 'amd64'):
            raise ValueError('IMAGE_PLATFORM_MISMATCH')
    probe = "import json; from runtime_identity import source_fingerprint; print(json.dumps({'build':json.load(open('.build-info.json')), 'runtime':source_fingerprint()}))"
    for tag in IMAGES[:2]:
        result = json.loads(subprocess.check_output(['docker', 'run', '--rm', '--pull=never', '--network',
            'none', '--read-only', '--entrypoint', 'python', tag, '-c', probe], text=True))
        if (result['runtime'] != [manifest['source_fingerprint'], True]
                or result['build']['revision'] != manifest['source_head']
                or result['build']['source_fingerprint'] != manifest['source_fingerprint']):
            raise ValueError('IMAGE_SOURCE_IDENTITY_MISMATCH')
    # Read archive members without extracting to prove it contains these image IDs.
    import tarfile
    with tarfile.open(archive) as bundle:
        members = set(bundle.getnames())
        if not all('blobs/sha256/' + image['Id'].split(':')[1] in members for image in images):
            raise ValueError('ARCHIVE_IMAGE_IDS_MISMATCH')
    output.mkdir(parents=True)
    (output / 'compose.offline.yml').write_text(yaml.safe_dump(compose_document(source), sort_keys=False), 'utf-8')
    shutil.copyfile(source / '.env.account.cloud.example', output / 'account.env.example')
    shutil.copyfile(Path(__file__).parents[1] / 'deploy/offline/server.py', output / 'server.py')
    shutil.copyfile(Path(__file__).parents[1] / 'deploy/offline/README.md', output / 'README.md')
    record = {'schema': 'sciassistant.offline-kit/v1', 'source_directory_name': source.name,
        'source_revision': manifest['source_head'], 'source_fingerprint': manifest['source_fingerprint'],
        'archive': archive.name, 'archive_bytes': archive.stat().st_size, 'archive_sha256': sha(archive),
        'images': {tag: {'id': image['Id'], 'platform': 'linux/amd64'} for tag, image in zip(IMAGES, images)},
        'delivery_files': delivery['files'], 'server_verified': False, 'private_configuration_included': False}
    (output / 'offline-manifest.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', 'utf-8')
    return {key: record[key] for key in ('source_revision', 'source_fingerprint', 'archive_sha256', 'server_verified')}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(prepare(args.source, args.archive, args.output)))
