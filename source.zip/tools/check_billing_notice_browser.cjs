/* Isolated browser fixture: real UI/CSS, synthetic 402, no login/provider calls. */
'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {chromium}=require('playwright');
const root=path.resolve(__dirname,'..');
async function main(){
 const output=path.resolve(process.argv[2]||'');
 const relative=path.relative(path.join(root,'logs'),output);
 if(!process.argv[2]||relative.startsWith('..')||path.isAbsolute(relative)||!relative||fs.existsSync(output))
   throw Error('NEW_ISOLATED_LOG_DIRECTORY_REQUIRED');
 fs.mkdirSync(output,{recursive:true});
 const css=fs.readFileSync(path.join(root,'chatAi/chat_theme.css'),'utf8')+'\n'+
   fs.readFileSync(path.join(root,'chatAi/multi_agent_rag.css'),'utf8');
 const source=fs.readFileSync(path.join(root,'chatAi/multi_agent_rag.js'),'utf8');
 const chrome='C:/Program Files/Google/Chrome/Application/chrome.exe';
 const browser=await chromium.launch({headless:true,...(fs.existsSync(chrome)?{executablePath:chrome}:{})});
 const checks={},shots=[];let network=0;
 try{
  const context=await browser.newContext();
  await context.route('**/*',route=>{network++;return route.abort();});
  const page=await context.newPage();
  for(const width of [1366,462])for(const theme of ['light','dark']){
   await page.setViewportSize({width,height:950});
   await page.setContent('<!doctype html><html lang="zh-CN" data-chat-theme="'+theme+'"><head><meta charset="utf-8"><style>'+
     'body{margin:0;padding:20px;font:16px/1.7 sans-serif;background:'+(theme==='dark'?'#0c1423':'#f7f9fc')+'}'+
     '#chat-messages{max-width:1100px;margin:auto}.rag-report-card{max-width:100%;box-sizing:border-box}'+css+
     '</style></head><body><main id="chat-messages"></main></body></html>');
   await page.evaluate(()=>{
     window.currentSessionId='fixture-session';window.userToken='fixture-owner';
     window.settingsOpened=0;window.AccountKeys={open(){window.settingsOpened++;}};
   });
   await page.addScriptTag({content:source});
   await page.evaluate(()=>window.MultiAgentRagUI.attach({id:'abcdef012345',status:'failed',
     processing_mode:'multi_agent_rag',execution:{failure_code:'MODEL_HTTP_402'}},'fixture-session'));
   const alert=page.locator('.rag-billing-alert');
   assert.equal(await alert.count(),1);
   assert.equal(await alert.getAttribute('role'),'alert');
   assert.match(await alert.innerText(),/余额不足/);
   const box=await alert.boundingBox();assert(box&&box.width>200&&box.x>=0&&box.x+box.width<=width);
   assert(await alert.locator('h3').evaluate(n=>parseFloat(getComputedStyle(n).fontSize)>=20));
   const styles=await alert.evaluate(n=>({background:getComputedStyle(n).backgroundColor,color:getComputedStyle(n).color}));
   assert.equal(styles.background,theme==='dark'?'rgb(61, 23, 23)':'rgb(255, 241, 240)');
   await alert.getByRole('button',{name:'打开我的 API Keys'}).click();
   assert.equal(await page.evaluate(()=>window.settingsOpened),1);
   await page.evaluate(()=>{window.userToken='other-owner';document.querySelector('.rag-billing-settings').click();});
   assert.equal(await page.evaluate(()=>window.settingsOpened),1);
   const filename=`billing-${width}-${theme}.png`;
   await page.screenshot({path:path.join(output,filename),fullPage:true});shots.push(filename);
   checks[`${width}_${theme}`]={visible:true,within_viewport:true,large_heading:true,theme:true,
     settings_click:true,stale_account_click_blocked:true};
  }
  await page.evaluate(()=>{window.currentSessionId='s2';window.userToken='same-owner';
    const m=document.createElement('article');m.id='general-fixture';m.textContent='原有失败说明';
    document.body.append(m);window.MultiAgentRagUI.attach({id:'123456abcdef',status:'failed',
      processing_mode:'general_answer',failure_code:'MODEL_HTTP_402'},'s2',m);});
  assert.equal(await page.locator('#general-fixture .rag-billing-alert').count(),1);
  checks.general_chat_notice=true;
  await page.evaluate(()=>{const m=document.createElement('article');m.id='unrelated-fixture';document.body.append(m);
    window.MultiAgentRagUI.attach({id:'abcdefabcdef',status:'failed',processing_mode:'general_answer',
      message:'论文第402页',failure_code:'MODEL_HTTP_429'},'s2',m);});
  assert.equal(await page.locator('#unrelated-fixture .rag-billing-alert').count(),0);
  checks.non402_not_mislabeled=true;
  assert.equal(network,0);
  const result={passed:true,checks,screenshots:shots,network_requests:network,paid_calls:0,
    fixture_only:true,authenticated_website_not_verified:true,services_restarted:false};
  fs.writeFileSync(path.join(output,'result.json'),JSON.stringify(result,null,2));
  console.log(JSON.stringify(result));
 }finally{await browser.close();}
}
main().catch(error=>{console.error(error.name+': '+error.message);process.exitCode=1;});
