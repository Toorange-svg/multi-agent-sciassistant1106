import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from deepdiver_v2.src.arxiv_query import validate_arxiv_query, repair_arxiv_query
q = '(ti:"attention" OR abs:"attention") AND (ti:"attention）" OR abs:"attention）")'
print("valid:", validate_arxiv_query(q))
print("repair:", repair_arxiv_query(q))
