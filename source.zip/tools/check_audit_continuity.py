"""Read-only old audit diagnosis and copied-index passage retrieval; no LLM/network."""
from copy import deepcopy
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))


def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def tree(path): return {str(p.relative_to(path)):sha(p) for p in path.rglob('*') if p.is_file()}


def audit_probe(run):
    from multi_agent_agents import ArtifactDirectory
    from multi_agent_quality import (resolve_witness_choices,resolve_absence_choices,check_audit,
        publication_rejections,AUDIT_ROW_RETENTION_POLICY,retain_valid_audit_rows)
    before=tree(run)
    store=ArtifactDirectory(run/'artifacts')
    final=store.get(read(run/'manifest.json')['final_artifact_id'])
    draft=store.get(final['artifact_refs']['draft'])
    evidence=store.get(final['artifact_refs']['approved'])
    checks=[]
    for path in sorted((run/'agents').glob('*citation_auditor.json')):
        agent=read(path)
        payloads=[store.get(k) for k in agent['input']['input_artifact_ids']]
        inputs=next(p for p in payloads if p.get('schema_version')=='sciassistant.citation-audit-input/v1')
        options=[*inputs['source_witness_options']['options'], *[o for p in payloads
            if p.get('stage')=='citation_auditor' for o in p['source_witness_options']['options']]]
        raw=store.get(store.get(agent['result_artifact_id'])['output_artifact_ids'][0])
        resolved,_=resolve_witness_choices(raw,{'options':options},draft,evidence)
        resolved,_=resolve_absence_choices(resolved,inputs['absence_assertion_options'],draft)
        checks.append(check_audit(resolved,draft,evidence))
    proposed=deepcopy(draft)
    proposed['audit_row_retention_policy']=AUDIT_ROW_RETENTION_POLICY
    merged,receipt=retain_valid_audit_rows(checks[0],checks[1],proposed,evidence,
        prior_context=deepcopy({'draft':proposed,'evidence':evidence}))
    return {'source_run':str(run.relative_to(ROOT)),'recorded_status':final['status'],
        'old_blocked_by_first_audit':sorted(publication_rejections(checks[0],draft)),
        'old_blocked_by_correction':sorted(publication_rejections(checks[1],draft)),
        'proposed_policy_blocked_diagnosis_only':sorted(publication_rejections(merged,proposed)),
        'retention':receipt,'source_hashes_unchanged':before==tree(run),
        'answer_sha256':sha(run/'final_answer.md'),'automatic_historical_publication':False}


def passage_probe(run,index,output):
    from multi_agent_agents import ArtifactDirectory
    from multi_agent_live import LiveArxivRagExecutor,read_candidate_priority
    from multi_agent_rag import EvidenceStore,HybridRetriever
    before=tree(run)
    index_sha=sha(index)
    target=output/'index-copy.sqlite3'
    shutil.copy2(index,target)
    store=ArtifactDirectory(run/'artifacts')
    final=store.get(read(run/'manifest.json')['final_artifact_id'])
    plan=store.get(final['artifact_refs']['plan'])
    budget=read(run/'budget_usage.json')
    evidence=EvidenceStore(target)
    services=HybridRetriever(evidence)
    executor=LiveArxivRagExecutor(output/'run',output/'storage',rag_mode='lexical',
        evidence_store=evidence,services=services)
    groups=plan['groups']
    executor.configure_plan(plan)
    executor.group_queries={g['id']:g['queries'] for g in groups}
    for row in budget['candidate_reading_decisions']:
        if row.get('reading_status')!='pdf_indexed': continue
        document='arxiv-'+row['paper_id'].replace('.','-').replace('/','-')
        metadata=read(index.parent/'documents'/document/'metadata.json')
        paper={**metadata,'group_ids':row['group_ids'],'evidence_id':document,'abstract':''}
        executor.candidates[executor._paper_key(row['paper_id'])]=paper
        executor.ingested.add(document)
    control=deepcopy(plan)
    for g in control['groups']:
        own=[p for p in executor.candidates.values() if g['id'] in p['group_ids']]
        if not any(read_candidate_priority(p,g['queries'],source_hints=g.get('source_hints',()))['exact_title_hint'] for p in own):
            g['source_hints']=[]
    executor.configure_plan(control)
    old=executor._select_packets()
    executor.configure_plan(plan)
    new=executor._select_packets()
    def packets(values):
        return [{'evidence_id':p['evidence_id'],'paper_id':p['paper_id'],'group_ids':p['group_ids'],
            'page':p.get('locator',{}).get('page'),'text':p.get('excerpt'),
            'retrieval':p.get('retrieval')} for p in values]
    return {'source_run':str(run.relative_to(ROOT)),
        'control':'same copied lexical index and source metadata; ignore only cross-group title hints',
        'not_original_full_workflow_replay':True,'hybrid_not_proved_by_lexical_probe':True,
        'control_packets':packets(old),'current_packets':packets(new),
        'source_run_hashes_unchanged':before==tree(run),'source_index_sha256':index_sha,
        'source_index_unchanged':index_sha==sha(index),'new_network_requests':0,
        'automatic_evidence_approval':False}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--audit-run',type=Path,required=True)
    parser.add_argument('--public-run',type=Path,required=True)
    parser.add_argument('--source-index',type=Path,required=True)
    parser.add_argument('--output-dir',type=Path,required=True)
    args=parser.parse_args()
    output=args.output_dir.resolve()
    sources=[p.resolve() for p in (args.audit_run,args.public_run,args.source_index)]
    if output.exists() or any(output.is_relative_to(p if p.is_dir() else p.parent)
            or (p if p.is_dir() else p.parent).is_relative_to(output) for p in sources):
        parser.error('new non-overlapping output directory required')
    output.mkdir(parents=True)
    data={'schema_version':'sciassistant.audit-continuity-probe/v1',
        'audit':audit_probe(sources[0]),'passages':passage_probe(sources[1],sources[2],output),
        'model_calls':0,'network_calls':0,'semantic_auto_approval':False}
    (output/'checks.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps({'audit_retained':data['audit']['retention']['retained_claim_ids'],
        'remaining_blocked':data['audit']['proposed_policy_blocked_diagnosis_only'],
        'current_original_pages':[(p['page'],p['group_ids']) for p in data['passages']['current_packets'] if p['paper_id']=='1706.03762v7']},ensure_ascii=True))


if __name__=='__main__': main()
