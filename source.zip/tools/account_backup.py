"""Create and verify offline account-data backup bundles, then stage safe restores.

The tool never connects to MySQL, Docker, the application, or a provider. Operators
must supply a quiesced export tree and a completed MySQL SQL dump. Restore only
writes to a new staging directory; importing SQL or replacing live volumes remains
an explicit, separately authorized operation.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import tempfile
import time


SCHEMA = "sciassistant.backup/v1"
REPORT_SCHEMA = "sciassistant.backup-check/v1"
MANIFEST_NAME = "manifest.json"
DATABASE_PATH = "payload/database.sql"
DATA_ROOTS = ("logs", "uploads", "user_files", "web_uploads", "arxiv")
REVISION_RE = re.compile(r"[0-9a-f]{7,40}|unknown")
SHA256_RE = re.compile(r"[0-9a-f]{64}")
CREATED_AT_RE = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z")
MAX_MANIFEST_BYTES = 4 * 1024 * 1024
DEFAULT_MAX_FILES = 200_000
DEFAULT_MAX_BYTES = 50 * 1024 * 1024 * 1024
_WINDOWS = os.name == 'nt'
_PUBLISH_RETRY_DELAYS = (0.05, 0.1, 0.2)


class BackupError(RuntimeError):
    """Expected validation failure carrying only a public error code."""

    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


def _report(operation, passed, code, *, files=0, total_bytes=0, revision="unknown"):
    safe_revision = revision if REVISION_RE.fullmatch(str(revision)) else "unknown"
    return {
        "schema": REPORT_SCHEMA,
        "operation": operation,
        "passed": bool(passed),
        "checks": [{"check": code, "passed": bool(passed)}],
        "summary": {"files": int(files), "bytes": int(total_bytes), "revision": safe_revision},
    }


def _is_link_or_reparse(path: Path) -> bool:
    try:
        info = path.lstat()
    except OSError as exc:
        raise BackupError("path_unreadable") from exc
    attributes = getattr(info, "st_file_attributes", 0)
    reparse_flag = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    return stat.S_ISLNK(info.st_mode) or bool(attributes & reparse_flag)


def _require_plain_directory(path: Path, code: str):
    if not path.exists() or _is_link_or_reparse(path) or not path.is_dir():
        raise BackupError(code)


def _safe_relative_path(value: object) -> str:
    if not isinstance(value, str) or not value or "\\" in value or value.startswith("/"):
        raise BackupError("manifest_path_invalid")
    parsed = PurePosixPath(value)
    if any(part in {"", ".", ".."} for part in parsed.parts) or str(parsed) != value:
        raise BackupError("manifest_path_invalid")
    return value


def _is_within(path: Path, parent: Path) -> bool:
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def _iter_plain_files(root: Path):
    _require_plain_directory(root, "source_root_invalid")
    found = []
    for current, directories, files in os.walk(root, topdown=True, followlinks=False):
        current_path = Path(current)
        for name in directories:
            child = current_path / name
            if _is_link_or_reparse(child):
                raise BackupError("link_or_reparse_rejected")
        for name in files:
            child = current_path / name
            info = child.lstat()
            if _is_link_or_reparse(child) or not stat.S_ISREG(info.st_mode):
                raise BackupError("non_regular_file_rejected")
            found.append(child)
    return sorted(found, key=lambda item: item.relative_to(root).as_posix())


def _hash_file(path: Path):
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
            size += len(chunk)
    return digest.hexdigest(), size


def _copy_and_hash(source: Path, destination: Path):
    before = source.stat()
    destination.parent.mkdir(parents=True, exist_ok=True)
    digest = hashlib.sha256()
    size = 0
    with source.open("rb") as reader, destination.open("xb") as writer:
        while True:
            chunk = reader.read(1024 * 1024)
            if not chunk:
                break
            writer.write(chunk)
            digest.update(chunk)
            size += len(chunk)
        writer.flush()
        os.fsync(writer.fileno())
    after = source.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns) or size != before.st_size:
        raise BackupError("source_changed_during_capture")
    return digest.hexdigest(), size


def _valid_mysql_dump(path: Path) -> bool:
    try:
        if _is_link_or_reparse(path) or not path.is_file() or path.stat().st_size == 0:
            return False
        with path.open("rb") as handle:
            sample = handle.read(1024 * 1024)
    except OSError:
        return False
    upper = sample.upper()
    return b"\x00" not in sample and b"CREATE TABLE" in upper


def _write_manifest(path: Path, manifest: dict):
    encoded = (json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")
    if len(encoded) > MAX_MANIFEST_BYTES:
        raise BackupError("manifest_too_large")
    with path.open("xb") as handle:
        handle.write(encoded)
        handle.flush()
        os.fsync(handle.fileno())


def _publish_staged_directory(staged: Path, target: Path, conflict_code: str):
    """Retry only short Windows sharing/access blocks, never remove a target.

    Windows rename refuses an existing destination (unlike replace). Every
    retry rechecks conflicts; persistent access errors stay a safe failure.
    This is not a cross-process lock against arbitrary POSIX directory writers.
    """
    if staged.parent != target.parent:
        raise BackupError('publish_layout_invalid')
    for attempt in range(len(_PUBLISH_RETRY_DELAYS) + 1):
        if os.path.lexists(target):
            raise BackupError(conflict_code)
        try:
            os.rename(staged, target)
            return
        except OSError as exc:
            if os.path.lexists(target):
                raise BackupError(conflict_code) from exc
            transient = _WINDOWS and getattr(exc, 'winerror', None) in {5, 32, 33}
            if not transient:
                raise
            if attempt == len(_PUBLISH_RETRY_DELAYS):
                raise BackupError('directory_publish_busy') from exc
            time.sleep(_PUBLISH_RETRY_DELAYS[attempt])


def create_bundle(source_root, database_dump, output, revision="unknown", *,
                  max_files=DEFAULT_MAX_FILES, max_bytes=DEFAULT_MAX_BYTES):
    source_root = Path(source_root).resolve()
    database_dump = Path(database_dump).resolve()
    output = Path(output).resolve()
    revision = str(revision)
    if not REVISION_RE.fullmatch(revision):
        raise BackupError("revision_invalid")
    _require_plain_directory(source_root, "source_root_invalid")
    if not _valid_mysql_dump(database_dump):
        raise BackupError("database_dump_invalid")
    if output.exists() or not output.parent.exists() or _is_link_or_reparse(output.parent):
        raise BackupError("output_target_invalid")
    if _is_within(output, source_root) or _is_within(source_root, output):
        raise BackupError("output_overlaps_source")
    if max_files < 1 or max_bytes < 1:
        raise BackupError("capture_limit_invalid")

    sources = [(database_dump, DATABASE_PATH)]
    for root_name in DATA_ROOTS:
        root = source_root / root_name
        _require_plain_directory(root, "required_data_root_missing")
        for source in _iter_plain_files(root):
            relative = source.relative_to(root).as_posix()
            sources.append((source, f"payload/data/{root_name}/{relative}"))
    if len(sources) > max_files:
        raise BackupError("capture_file_limit_exceeded")
    estimated = sum(item.stat().st_size for item, _ in sources)
    if estimated > max_bytes:
        raise BackupError("capture_byte_limit_exceeded")

    temporary = Path(tempfile.mkdtemp(prefix=f".{output.name}.partial-", dir=output.parent))
    entries = []
    try:
        (temporary / "payload" / "data").mkdir(parents=True)
        for root_name in DATA_ROOTS:
            (temporary / "payload" / "data" / root_name).mkdir()
        total_bytes = 0
        for source, relative in sources:
            digest, size = _copy_and_hash(source, temporary / Path(*PurePosixPath(relative).parts))
            total_bytes += size
            if total_bytes > max_bytes:
                raise BackupError("capture_byte_limit_exceeded")
            entries.append({"path": relative, "size": size, "sha256": digest})
        entries.sort(key=lambda item: item["path"])
        manifest = {
            "schema": SCHEMA,
            "created_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "source_revision": revision,
            "capture_consistency": "operator_quiesced_export",
            "database_format": "mysql-sql",
            "data_roots": list(DATA_ROOTS),
            "files": entries,
        }
        _write_manifest(temporary / MANIFEST_NAME, manifest)
        _publish_staged_directory(temporary, output, 'output_target_invalid')
        return _report("create", True, "bundle_created", files=len(entries),
                       total_bytes=total_bytes, revision=revision)
    except Exception:
        if temporary.exists():
            shutil.rmtree(temporary)
        raise


def _inspect_bundle(bundle, *, max_files=DEFAULT_MAX_FILES, max_bytes=DEFAULT_MAX_BYTES):
    bundle = Path(bundle).resolve()
    _require_plain_directory(bundle, "bundle_invalid")
    manifest_path = bundle / MANIFEST_NAME
    if (not manifest_path.is_file() or _is_link_or_reparse(manifest_path)
            or manifest_path.stat().st_size > MAX_MANIFEST_BYTES):
        raise BackupError("manifest_invalid")
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise BackupError("manifest_invalid") from exc
    if not isinstance(manifest, dict) or manifest.get("schema") != SCHEMA:
        raise BackupError("manifest_schema_invalid")
    if set(manifest) != {"schema", "created_at", "source_revision", "capture_consistency",
                         "database_format", "data_roots", "files"}:
        raise BackupError("manifest_schema_invalid")
    if not isinstance(manifest.get("created_at"), str) or not CREATED_AT_RE.fullmatch(manifest["created_at"]):
        raise BackupError("manifest_created_at_invalid")
    revision = manifest.get("source_revision")
    if not isinstance(revision, str) or not REVISION_RE.fullmatch(revision):
        raise BackupError("manifest_revision_invalid")
    if manifest.get("capture_consistency") != "operator_quiesced_export":
        raise BackupError("manifest_consistency_invalid")
    if manifest.get("database_format") != "mysql-sql" or manifest.get("data_roots") != list(DATA_ROOTS):
        raise BackupError("manifest_layout_invalid")
    entries = manifest.get("files")
    if not isinstance(entries, list) or not entries or len(entries) > max_files:
        raise BackupError("manifest_entries_invalid")

    expected = {}
    total_bytes = 0
    allowed_prefixes = tuple(f"payload/data/{name}/" for name in DATA_ROOTS)
    for entry in entries:
        if not isinstance(entry, dict) or set(entry) != {"path", "size", "sha256"}:
            raise BackupError("manifest_entry_invalid")
        relative = _safe_relative_path(entry["path"])
        size, digest = entry["size"], entry["sha256"]
        if relative in expected or not isinstance(size, int) or isinstance(size, bool) or size < 0:
            raise BackupError("manifest_entry_invalid")
        if not isinstance(digest, str) or not SHA256_RE.fullmatch(digest):
            raise BackupError("manifest_entry_invalid")
        if relative != DATABASE_PATH and not relative.startswith(allowed_prefixes):
            raise BackupError("manifest_path_invalid")
        expected[relative] = (size, digest)
        total_bytes += size
        if total_bytes > max_bytes:
            raise BackupError("manifest_byte_limit_exceeded")
    if DATABASE_PATH not in expected or list(expected) != sorted(expected):
        raise BackupError("manifest_entries_invalid")

    actual = {}
    payload = bundle / "payload"
    _require_plain_directory(payload / "data", "bundle_layout_invalid")
    for root_name in DATA_ROOTS:
        _require_plain_directory(payload / "data" / root_name, "bundle_layout_invalid")
    for path in _iter_plain_files(payload):
        relative = path.relative_to(bundle).as_posix()
        actual[relative] = path
    top_level = {item.name for item in bundle.iterdir()}
    if top_level != {MANIFEST_NAME, "payload"} or set(actual) != set(expected):
        raise BackupError("bundle_file_set_invalid")
    for relative, (size, digest) in expected.items():
        actual_digest, actual_size = _hash_file(actual[relative])
        if (actual_size, actual_digest) != (size, digest):
            raise BackupError("bundle_integrity_failed")
    if not _valid_mysql_dump(bundle / Path(*PurePosixPath(DATABASE_PATH).parts)):
        raise BackupError("database_dump_invalid")
    return bundle, manifest, expected, total_bytes


def verify_bundle(bundle, *, max_files=DEFAULT_MAX_FILES, max_bytes=DEFAULT_MAX_BYTES):
    try:
        _, manifest, entries, total_bytes = _inspect_bundle(
            bundle, max_files=max_files, max_bytes=max_bytes)
        return _report("verify", True, "bundle_verified", files=len(entries),
                       total_bytes=total_bytes, revision=manifest["source_revision"])
    except BackupError as exc:
        return _report("verify", False, exc.code)
    except Exception:
        return _report("verify", False, "verification_failed")


def restore_stage(bundle, target, *, max_files=DEFAULT_MAX_FILES, max_bytes=DEFAULT_MAX_BYTES):
    bundle, manifest, entries, total_bytes = _inspect_bundle(
        bundle, max_files=max_files, max_bytes=max_bytes)
    target = Path(target).resolve()
    if target.exists() or not target.parent.exists() or _is_link_or_reparse(target.parent):
        raise BackupError("restore_target_invalid")
    if _is_within(target, bundle) or _is_within(bundle, target):
        raise BackupError("restore_overlaps_bundle")
    temporary = Path(tempfile.mkdtemp(prefix=f".{target.name}.partial-", dir=target.parent))
    try:
        for root_name in DATA_ROOTS:
            (temporary / "payload" / "data" / root_name).mkdir(parents=True, exist_ok=True)
        for relative, (size, digest) in entries.items():
            source = bundle / Path(*PurePosixPath(relative).parts)
            copied_digest, copied_size = _copy_and_hash(
                source, temporary / Path(*PurePosixPath(relative).parts))
            if (copied_size, copied_digest) != (size, digest):
                raise BackupError("restore_copy_integrity_failed")
        _copy_and_hash(bundle / MANIFEST_NAME, temporary / MANIFEST_NAME)
        # Close the verify/copy race before publishing the staged restore.
        _inspect_bundle(temporary, max_files=max_files, max_bytes=max_bytes)
        _publish_staged_directory(temporary, target, 'restore_target_invalid')
        return _report("restore-stage", True, "restore_staged", files=len(entries),
                       total_bytes=total_bytes, revision=manifest["source_revision"])
    except Exception:
        if temporary.exists():
            shutil.rmtree(temporary)
        raise


def _run_safely(operation, function, *args, **kwargs):
    try:
        return function(*args, **kwargs)
    except BackupError as exc:
        return _report(operation, False, exc.code)
    except Exception:
        return _report(operation, False, operation.replace("-", "_") + "_failed")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    create = commands.add_parser("create")
    create.add_argument("--source-root", type=Path, required=True)
    create.add_argument("--database-dump", type=Path, required=True)
    create.add_argument("--output", type=Path, required=True)
    create.add_argument("--revision", default="unknown")
    verify = commands.add_parser("verify")
    verify.add_argument("--bundle", type=Path, required=True)
    restore = commands.add_parser("restore-stage")
    restore.add_argument("--bundle", type=Path, required=True)
    restore.add_argument("--target", type=Path, required=True)
    for command in (create, verify, restore):
        command.add_argument("--max-files", type=int, default=DEFAULT_MAX_FILES)
        command.add_argument("--max-bytes", type=int, default=DEFAULT_MAX_BYTES)
    args = parser.parse_args(argv)
    if args.command == "create":
        report = _run_safely("create", create_bundle, args.source_root, args.database_dump,
                             args.output, args.revision, max_files=args.max_files,
                             max_bytes=args.max_bytes)
    elif args.command == "verify":
        report = verify_bundle(args.bundle, max_files=args.max_files, max_bytes=args.max_bytes)
    else:
        report = _run_safely("restore-stage", restore_stage, args.bundle, args.target,
                             max_files=args.max_files, max_bytes=args.max_bytes)
    print(json.dumps(report, ensure_ascii=False, sort_keys=True))
    return 0 if report["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
