from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
from contextlib import contextmanager
from urllib.parse import unquote, urlsplit
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from multi_agent_agents import AgentContractError, AgentWorker, ArtifactDirectory, ROLE_ALLOWED_ACTIONS, make_agent_input
from multi_agent_skills import SKILL_POLICY, ASSERTION_POLICY, PRECISE_REVISION_POLICY
from multi_agent_publication import PUBLICATION_POLICY, AUDIT_MATERIAL_POLICY
from multi_agent_sections import REVISION_DELIVERY_POLICY, MAX_REVISION_JOBS, INITIAL_DELIVERY_BUDGET_POLICY
from multi_agent_audit_batches import AUDIT_BATCH_POLICY, AUDIT_BATCH_RECOVERY_POLICY, MAX_AUDIT_CLAIMS, GLOBAL_REVIEW_SCHEMA
from multi_agent_pipeline_v2 import DeterministicLiteratureExecutor, LiteraturePipelineV2, PipelineAgents, SOFT_TIME_POLICY
from multi_agent_rag import EvidenceStore, RagIndexer, RagDependencyError, RagError, configured_vector_services
from multi_agent_report import export_run_report, read_run_manifest
from multi_agent_workflow import TERMINAL_STATUSES, WorkflowError, WorkflowStore
from multi_agent_quality import SEMANTIC_BOUNDARY_POLICY, READING_SCOPE_POLICY, QUANTITY_FEEDBACK_POLICY, CLAIM_REVISION_POLICY, WRITER_REVISION_BRIEF_POLICY, SOURCE_REASONING_POLICY, REPORT_FIELD_POLICY, ABSENCE_AUDIT_POLICY, AUDIT_PROTOCOL_POLICY, ABSENCE_SCOPE_POLICY, REPORT_REFERENCE_POLICY
from multi_agent_quality import WITNESS_CHOICE_POLICY
from multi_agent_quality import PREMISE_CHECK_POLICY, PREMISE_ORIGIN_POLICY
from multi_agent_quality import EMPTY_FIELD_ABSENCE_POLICY
from multi_agent_quality import ABSENCE_MENU_POLICY, ABSENCE_REASON_POLICY, ABSENCE_INVENTORY_POLICY, WITNESS_COPY_POLICY, WITNESS_CAPACITY_POLICY
from multi_agent_quality import SYMBOL_ROLE_POLICY
from multi_agent_quality import CONDITION_DENIAL_POLICY
from multi_agent_quality import AUDIT_CONTEXT_POLICY, AUDIT_QUOTE_MENU_POLICY, SOURCE_ROLE_INVENTORY_POLICY
from multi_agent_quality import TERM_BINDING_POLICY, ABSENCE_CHOICE_POLICY, SHORT_CHOICE_POLICY, PASSAGE_EXCLUSIVITY_POLICY, AUDIT_ROW_RETENTION_POLICY
from rag_storage_lock import RagStorageBusy, StorageLease, writer_roots
from multi_agent_report_contracts import (report_budget, default_time_policy, is_soft_time_policy,
    PROFILE_SOFT_POLICY, PROFILE_POLICY, REPORT_PLAN_SCHEMA, REQUIREMENTS_POLICY, question_inventory)
from multi_agent_sections import SECTION_DRAFT_SCHEMA, SECTION_POLICY, JOB_SCHEMA, BODY_DELIVERY_POLICY
from multi_agent_quality import METRIC_DIRECTION_POLICY


def _credential_owner():
    from user_credentials import current_capability
    cap = current_capability()
    return cap.owner if cap else 'cli-user'


def write_run_json(path: Path, payload: dict) -> None:
    """Readers see the previous complete snapshot or the next complete one."""
    temporary = path.with_name(f".{path.name}-{uuid.uuid4().hex}.tmp")
    try:
        with temporary.open("x", encoding="utf-8") as output:
            json.dump(payload, output, ensure_ascii=False, indent=2)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _mock_agents(*, source_scope="arxiv") -> PipelineAgents:
    auto = source_scope == "uploaded_pdf_and_arxiv"
    local = source_scope in {"uploaded_pdf", "uploaded_pdf_and_arxiv"}
    search_action = "request_research_search" if auto else "request_document_search" if local else "request_arxiv_search"
    def planner(_packet):
        question = next(i['payload']['question'] for i in _packet['inputs'] if 'question' in i['payload'])
        inventory = question_inventory(question)
        reqs = [{'id': f'u{i+1}', 'question_quote': s['text'], 'answer_kind': 'definition',
            'research_group_ids': ['group-1'], 'report_obligation_ids': []}
            for i,s in enumerate(inventory['segments'])]
        return {"output": {"schema_version": REPORT_PLAN_SCHEMA, "groups": [{"id": "group-1", "kind": "research",
            "question_quote": question[:600], "question": "Demo evidence", 'core': ['Demo'], 'support': [],
            'metrics': ['definition'], 'evidence_needs': [{'entity': 'Demo', 'question_quote': question[:600],
                'aspect': 'definition', 'source_title': ''}],
            "queries": ["bounded scientific evidence", "targeted evidence"] if auto else ["bounded scientific evidence"]}],
            'report_obligations': [], 'user_requirements': reqs,
            'segment_dispositions': {s['segment_id']: [f'u{i+1}'] for i,s in enumerate(inventory['segments'])}}}
    def retriever(_packet):
        gap = next((item["payload"] for item in _packet["inputs"] if "gaps" in item["payload"]), None)
        if local and gap:
            return {"output": {"actions": len(gap["gaps"])}, "tool_requests": [
                {"request_id": f"gap-{index}", "action": search_action, "arguments": dict(row)}
                for index, row in enumerate(gap["gaps"])]}
        if auto:
            question = next(item["payload"]["question"] for item in _packet["inputs"] if "question" in item["payload"])
            actions = [{"request_id": "request-1", "action": search_action,
                "arguments": {"query": "bounded scientific evidence", "group_id": "group-1", "source": "uploaded_pdf"}}]
            if any(term in question.lower() for term in ("外部", "最新", "比较", "对比", "compare", "latest")):
                actions.append({"request_id": "request-2", "action": search_action,
                    "arguments": {"query": "targeted evidence", "group_id": "group-1", "source": "arxiv"}})
            return {"output": {"actions": len(actions)}, "tool_requests": actions}
        return {"output": {"actions": 1}, "tool_requests": [{"request_id": "request-1",
                "action": "request_document_search" if local else "request_arxiv_search", "arguments": {"query": "bounded scientific evidence",
                                                                    "group_id": "group-1"}}]}
    def reviewer(packet):
        evidence = next(item["payload"] for item in packet["inputs"] if "evidence" in item["payload"])
        ids = [item["evidence_id"] for item in evidence["evidence"]]
        return {"output": {"coverage_status": "partial", "allowed_evidence_ids": ids,
                            "coverage": [{"group_id": "group-1", "status": "not_reported",
                                          "metric": "definition", "evidence_ids": ids}], "conflicts": []}}
    def gap(_packet):
        return {"output": {"gaps": [{"group_id": "group-1", "query": "targeted evidence"}]}}
    def writer(_packet):
        evidence_id = "arxiv-0000-00000"
        if local:
            evidence = next(item["payload"]["evidence"] for item in _packet["inputs"] if "evidence" in item["payload"])
            evidence_id = evidence[0]["evidence_id"]
        job = next((i['payload'] for i in _packet['inputs'] if i['payload'].get('schema_version') == JOB_SCHEMA), None)
        if job:
            claims = [{'claim_id': f'c{i+1}', 'text': '这是仅用于验证分节流水线的有限回答。',
                'claim_type': 'technical', 'assertion_mode': 'reported_fact', 'section': s['role'], 'report_section_id': s['section_id'],
                'group_id': job['planned_group_ids'][0], 'requirement_ids': s['requirement_ids'],
                'scope_note': '这是离线模拟材料，不是科研结论。', 'qualification': '', 'confidence': 'low',
                'evidence_ids': [evidence_id], 'depends_on_claim_ids': []} for i,s in enumerate(job['sections']) if s['requirement_ids']]
            return {'output': {'schema_version': SECTION_DRAFT_SCHEMA, 'direct_answer': '模拟分节草稿',
                'claims': claims, 'requirement_results': [{'requirement_id': rid, 'status': 'answered',
                    'claim_ids': [c['claim_id'] for c in claims if rid in c['requirement_ids']], 'reason': '玩具映射'}
                    for rid in job['requirement_ids']]}}
        return {"output": {"schema_version": "sciassistant.claim-draft/v2", "direct_answer": "这是仅用于验证流水线的有限回答。[1]",
                            "claims": [{"claim_id": "claim-1", "text": "这是仅用于验证流水线的有限回答。",
                                        "claim_type": "technical", "section": "direct_conclusion", "confidence": "low",
                                        "scope_note": "这是离线模拟材料，不是科研结论。", "qualification": "固定的玩具论文与模型回复，仅验证流程与引用映射。",
                                        "evidence_ids": [evidence_id]}]}}
    def auditor(_packet):
        evidence_id = "arxiv-0000-00000"
        draft = next(item['payload'] for item in _packet['inputs'] if 'claims' in item['payload'])
        ledger = next((i['payload'] for i in _packet['inputs'] if i['payload'].get('schema_version')=='sciassistant.user-requirements/v1'),{})
        from multi_agent_publication import review_request
        requirements=review_request(ledger,draft)['requirements']
        report_review={'schema_version':'sciassistant.report-review/v1',
            'requirements':[{'requirement_id':r['requirement_id'],
                'claim_ids':[c['claim_id'] for c in draft['claims'] if r['requirement_id'] in c.get('requirement_ids',[])],
                'status':'answered' if any(r['requirement_id'] in c.get('requirement_ids',[]) for c in draft['claims']) else 'unanswered',
                'reason':'仅验证结构化需求核算的模拟判断，不代表科研语义通过。'} for r in requirements],
            'consistency':{'reviewed_claim_ids':[c['claim_id'] for c in draft['claims']], 'conflicts':[]}}
        if draft.get('schema_version') == GLOBAL_REVIEW_SCHEMA:
            return {'output':{'schema_version':'sciassistant.citation-audit/v7','status':'passed',
                'rejected_claim_ids':[],'issues':[],'claim_results':[],'report_review':report_review}}
        return {"output": {"schema_version": "sciassistant.citation-audit/v2", "status": "passed",
                            "report_review":report_review,
                            "rejected_claim_ids": [], "issues": [], "claim_results": [{"claim_id": c['claim_id'],
                                "decision": "approved", "reason_code": "SUPPORTED", "detail": "离线玩具声明，仅用于映射校验。",
                                "evidence_ids": c['evidence_ids']} for c in draft['claims']]}}
    return PipelineAgents(
        AgentWorker("planner", planner, ["create_research_plan"]),
        AgentWorker("retriever", retriever, [search_action]),
        AgentWorker("reviewer", reviewer, ["review_evidence"]),
        AgentWorker("gap_analyst", gap, ["create_gap_search_plan"]),
        AgentWorker("writer", writer, ["write_approved_claims"]),
        AgentWorker("citation_auditor", auditor, ["audit_citations"]),
    )


def _mock_search(_query, _limit):
    return {"status": "ok", "papers": [{"paper_id": "0000.00000", "title": "Mock Evidence Paper",
            "abstract": "Deterministic evidence used only for offline workflow verification.",
            "landing_url": "https://arxiv.org/abs/0000.00000"}]}


def run_command(args):
    selected_profile = getattr(args, 'report_profile', 'standard')
    report_config = report_budget(selected_profile, time_budget=getattr(args, 'time_budget', None))
    args.report_profile, args.time_budget = selected_profile, report_config['time_budget_seconds']
    initialized_at = time.monotonic()
    local_pdf = None
    if getattr(args, "pdf", None):
        from multi_agent_local_pdf import validate_pdf_input
        local_pdf = validate_pdf_input(args.pdf)
    if getattr(args, 'embedding_cloud_consent', False) and not local_pdf:
        raise ValueError('EMBEDDING_CONSENT_REQUIRES_PDF')
    from multi_agent_local_pdf import pdf_parser_options
    parser_options = pdf_parser_options(bool(local_pdf), getattr(args, "pdf_parse_mode", "local"),
                                        getattr(args, "llama_cloud_consent", False))
    if args.mode == "mock" and parser_options["pdf_parse_mode"] != "local":
        raise ValueError("MOCK_CLOUD_PARSE_FORBIDDEN")
    from multi_agent_sources import source_options
    if args.query_file:
        path = Path(args.query_file)
        if path.stat().st_size > 80_000:
            raise ValueError("query file too large")
        args.query = path.read_text(encoding="utf-8-sig")
    sources = source_options(has_pdf=bool(local_pdf), policy=getattr(args, "source_policy", None),
                             allow_public=getattr(args, "allow_public_search", False), question=args.query)
    run_id = args.run_id or f"run-{uuid.uuid4().hex[:12]}"
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", run_id) or not 1 <= len(args.query.strip()) <= 20_000:
        raise ValueError("invalid run input")
    if args.mode == "live" and not args.worker:
        return supervise_live(args, run_id)
    run_dir = Path(args.output_root) / run_id
    run_dir.mkdir(parents=True, exist_ok=False)
    for folder in ("agents", "tools", "rework_tickets"):
        (run_dir / folder).mkdir()
    (run_dir / "console.log").write_text("structured CLI run started\n", encoding="utf-8")
    from runtime_identity import source_fingerprint
    startup_fingerprint, source_complete = source_fingerprint()
    manifest = {"schema_version": "sciassistant.run-manifest/v1", "run_id": run_id, "mode": args.mode,
                "report_presentation_policy": "evidence-sidebar-compact-coverage/v2",
                "created_at": time.time(), "model_call_limit": report_config['model_call_limit'], "time_budget_seconds": args.time_budget,
                'report_profile': selected_profile, 'report_budget_policy': PROFILE_POLICY,
                'initial_delivery_budget_policy': INITIAL_DELIVERY_BUDGET_POLICY,
                'report_composition_policy': SECTION_POLICY, 'live_writer_schema': SECTION_DRAFT_SCHEMA,
                'business_skill_policy': SKILL_POLICY, 'assertion_policy': ASSERTION_POLICY,
                'precise_revision_policy': PRECISE_REVISION_POLICY,
                'publication_review_policy':PUBLICATION_POLICY,'audit_material_policy':AUDIT_MATERIAL_POLICY,
                'audit_delivery_policy':AUDIT_BATCH_POLICY,'maximum_source_audit_claims':MAX_AUDIT_CLAIMS,
                'audit_batch_recovery_policy':AUDIT_BATCH_RECOVERY_POLICY,
                'revision_delivery_policy':REVISION_DELIVERY_POLICY,'maximum_revision_jobs':MAX_REVISION_JOBS,
                'report_budget': report_config, 'user_requirements_policy': REQUIREMENTS_POLICY,
                "time_policy": getattr(args, "time_policy", "hard-deadline/v1"),
                "time_budget_is_estimate": is_soft_time_policy(getattr(args, "time_policy", None)),
                "research_start_cutoff_seconds": report_config['research_start_cutoff_seconds'] if is_soft_time_policy(getattr(args, 'time_policy', None)) else None,
                "source_fingerprint": startup_fingerprint, "source_complete": source_complete,
                **sources,
                **parser_options,
                "local_pdf_policy": "private-run-index-question-query-allowlist/v1" if sources["source_policy"] == "auto" else "private-run-index-explicit-parser-no-public-search/v2" if local_pdf else None,
                "rag_mode": args.rag_mode if args.mode == "live" else "mock",
                "recovery_policy": "reviewer-subset-recovery/v1",
                "audit_policy": "v7-detail4000-report-fields-explicit-absence-basis-verbatim-source-witnesses"
                    if args.mode == "live" else "v3-detail4000-complete-no-subset-publication",
                "task_relevance_policy": "reviewer-v5-direct-adjacent-unrelated-visible-source-domain",
                "topic_association_policy": "planned-topics-semantic-review/v1",
                "source_scope_format_policy": "copy-approved-label-before-audit/v1",
                "source_attribution_policy": "quotation-match-not-primary-method-verification/v1",
                "document_description_policy": "passage-attribution-not-document-genre/v1",
                "source_failure_policy": "all-blocked-search-no-empty-model-review/v1",
                "primary_source_policy": "question-only-original-title-slot-with-consent/v2",
                "answer_scope_policy": "published-core-claims-by-planned-topic/v1",
                "local_passage_policy": "one-priority-evaluation-passage-within-existing-quota/v2",
                "source_cache_fallback_policy": "verified-local-arxiv-cache-after-transport-failure/v1",
                "audit_input_policy": "current-question-visible-claims-and-cited-approved-source-context/v2",
                "semantic_boundary_policy": "opening-assertion-and-same-paper-counter-context/v1",
                "source_boundary_brief_policy": "literal-approved-source-cues-not-facts-or-auto-verdicts/v1",
                "reported_conditions_policy": "approved-paragraph-context-no-inferred-experiment-facts/v1",
                "source_reasoning_policy": SOURCE_REASONING_POLICY,
                "report_field_policy": REPORT_FIELD_POLICY,
                "absence_audit_policy": ABSENCE_AUDIT_POLICY,
                "audit_protocol_policy": AUDIT_PROTOCOL_POLICY,
                "absence_scope_policy": ABSENCE_SCOPE_POLICY,
                "witness_choice_policy": WITNESS_CHOICE_POLICY,
                "report_reference_policy": REPORT_REFERENCE_POLICY,
                "detail_citation_policy": "report-field-evidence-mentions-within-claim-citations/v1",
                "field_quantity_policy": "printed-item-counts-all-claim-fields/v2",
                "answer_style_policy": "necessary-conditions-without-repeated-disclaimers/v1",
                "scientific_review_frame_policy": "actual-assertion-versus-unasked-proof-and-format/v1",
                'live_plan_schema': REPORT_PLAN_SCHEMA,
                'planning_handoff_policy': 'typed-needs-with-bounded-query-compilation/v2',
                'audit_job_policy': 'claim-scoped-audit-inputs-with-processing-context/v1',
                'comparison_context_policy': 'printed-table-observations-and-cross-claim-context/v1',
                'source_confidence_policy': 'weak-source-confidence-ceiling-before-independent-audit/v1',
                'public_cache_match_policy': 'verified-public-cache-title-or-plain-text-no-field-widening/v3',
                'need_passage_policy': 'entity-aspect-scoped-recall-within-existing-context/v1',
                "metric_interpretation_policy": "source-metric-direction-ties-and-tested-conditions/v1",
                "metric_direction_policy": METRIC_DIRECTION_POLICY,
                "body_delivery_policy": BODY_DELIVERY_POLICY,
                "source_execution_policy": "recorded-source-execution-outside-scientific-claims/v1",
                "evaluation_role_policy": "own-output-self-versus-human-ratings/v1",
                "memory_component_policy": "cited-quantization-constant-overhead-not-total-storage/v1",
                "symbol_role_policy": SYMBOL_ROLE_POLICY,
                "condition_denial_policy": CONDITION_DENIAL_POLICY,
                "audit_context_policy": AUDIT_CONTEXT_POLICY,
                "audit_quote_menu_policy": AUDIT_QUOTE_MENU_POLICY,
                "source_role_inventory_policy": SOURCE_ROLE_INVENTORY_POLICY,
                "term_binding_policy": TERM_BINDING_POLICY,
                "absence_choice_policy": ABSENCE_CHOICE_POLICY,
                "absence_menu_policy": ABSENCE_MENU_POLICY,
                "absence_reason_policy": ABSENCE_REASON_POLICY,
                "absence_inventory_policy": ABSENCE_INVENTORY_POLICY,
                "witness_copy_policy": WITNESS_COPY_POLICY,
                "witness_capacity_policy": WITNESS_CAPACITY_POLICY,
                "short_choice_policy": SHORT_CHOICE_POLICY,
                "passage_exclusivity_policy": PASSAGE_EXCLUSIVITY_POLICY,
                "audit_row_retention_policy": AUDIT_ROW_RETENTION_POLICY,
                "answer_focus_delivery_policy": "before-first-review-and-bounded-rework/v1",
                "question_premise_policy": PREMISE_CHECK_POLICY,
                "premise_origin_policy": PREMISE_ORIGIN_POLICY,
                "empty_field_absence_policy": EMPTY_FIELD_ABSENCE_POLICY,
                "report_length_policy": "question-driven-no-target-claim-or-sentence-count/v1",
                "model_delivery_policy": "whitelisted-finish-and-usage-separate-from-role-output/v1",
                "semantic_regression_guard": SEMANTIC_BOUNDARY_POLICY,
                "reading_scope_policy": READING_SCOPE_POLICY,
                "quantity_feedback_policy": QUANTITY_FEEDBACK_POLICY,
                "source_title_policy": "question-only-original-title-slot-with-consent/v2"
                    if sources["source_scope"] != "uploaded_pdf" else "not-applicable-local-document",
                "chunk_query_policy": "planned-support-local-facets-complementary-representatives/v3",
                "formula_continuation_policy": "adjacent-introducer-formula-separate-evidence-within-quota/v1",
                "mechanism_passage_policy": "planned-mechanism-body-before-introduction-within-quota/v1",
                "witness_selection_feedback_policy": "exact-claim-source-option-error-feedback-no-rebinding/v1",
                "gap_routing_policy": "v5-actionable-gaps-with-reading-capacity/v1",
                "gap_target_policy": "ticket-bounded-exact-group-metric-gap/v1",
                "gap_selection_policy": "uncovered-topics-first-one-target-per-topic/v1"
                    if is_soft_time_policy(getattr(args, 'time_policy', None)) else 'legacy-first-two',
                "recovery_rejection_policy": "plan-or-action-rejected-keep-valid-review-write-and-audit/v1",
                "plan_scope_policy": "qualitative-question-explicit-measurement-families/v2",
                "review_input_policy": "current-evidence-id-checklist-no-approval-inheritance/v1",
                "claim_revision_policy": CLAIM_REVISION_POLICY,
                "writer_revision_brief_policy": WRITER_REVISION_BRIEF_POLICY,
                "publication_window_policy": "explicit-year-range-metadata-only",
                "index_policy": "embedding-batch8-shared-reading-deadline/v1",
                "source_scope_policy": "tool-classified-abstract-or-mixed/v2",
                "planner_format_retry": {"limit": 1, "minimum_remaining_seconds": 210,
                                         "minimum_remaining_calls": 5,
                                         "errors": ["MODEL_JSON_INVALID", "MODEL_SCHEMA_REJECTED"]},
                "writer_format_retry": {"limit": 1, "minimum_remaining_seconds": 90, "minimum_remaining_calls": 2},
                "reviewer_format_retry": {"limit": 1, "scope": "initial_review_only_per_run", "minimum_remaining_seconds": 130,
                                          "minimum_remaining_calls": 3,
                                          "errors": ["MODEL_JSON_INVALID", "MODEL_SCHEMA_REJECTED"]},
                "audit_protocol_retry": {"limit": 1, "minimum_remaining_seconds": 45}}
    write_run_json(run_dir / "manifest.json", manifest)
    write_run_json(run_dir / "worker_execution.json", {
        "schema_version": "sciassistant.cli-worker-execution/v1", "run_id": run_id,
        "worker_pid": os.getpid(), "parent_pid": os.getppid(), "started_at": time.time(),
        "supervised": os.getenv("SCIASSISTANT_SUPERVISED_CLI") == "1",
        "time_budget_seconds": args.time_budget,
    })
    artifacts = ArtifactDirectory(run_dir / "artifacts")
    store = WorkflowStore(run_dir / "workflow.sqlite3")
    executor = None
    lease = None
    general_fallback = None
    try:
        if args.mode == "live":
            from multi_agent_live import LiveArxivRagExecutor, READING_PRIORITY_POLICY, INDEXED_SOURCE_REUSE_POLICY
            # Resolve the same deployment environment before choosing lock roots
            # and before constructing any model/vector client.
            from dotenv import load_dotenv
            load_dotenv(ROOT / ".env", override=False)
            if parser_options["pdf_parse_mode"] != "local":
                from user_credentials import provider_value
                if not provider_value("LLAMA_CLOUD_API_KEY").startswith("llx-"):
                    raise ValueError("LLAMA_USER_KEY_REQUIRED")
            lease = StorageLease(run_dir / "private_rag") if local_pdf else StorageLease(*writer_roots(args.storage_root, vector_enabled=args.rag_mode == "hybrid"))
            lease.acquire()
            client = configured_live_model()
            general_fallback = client.general_fallback
            manifest["configuration_fingerprint"] = client.fingerprint
            manifest["prompts"] = client.prompt_metadata(source_scope=sources["source_scope"])
            workers = client.agents(source_scope=sources["source_scope"])
            if local_pdf:
                from multi_agent_local_pdf import LocalPdfRagExecutor
                if sources["source_policy"] == "auto":
                    from multi_agent_sources import AutoSourceExecutor
                    executor = AutoSourceExecutor(run_dir, local_pdf, allow_public=True, rag_mode=args.rag_mode,
                        embedding_cloud_consent=getattr(args, 'embedding_cloud_consent', False),
                        pdf_parse_mode=parser_options["pdf_parse_mode"], llama_cloud_consent=parser_options["llama_cloud_consent"])
                else:
                    executor = LocalPdfRagExecutor(run_dir, local_pdf, rag_mode=args.rag_mode,
                        embedding_cloud_consent=getattr(args, 'embedding_cloud_consent', False),
                        pdf_parse_mode=parser_options["pdf_parse_mode"], llama_cloud_consent=parser_options["llama_cloud_consent"])
                manifest["research_source"] = executor.source_context
            else:
                executor = LiveArxivRagExecutor(run_dir, Path(args.storage_root), rag_mode=args.rag_mode)
            embedding = executor.services.embedding
            manifest["retrieval_configuration"] = {
                "schema_version": "sciassistant.rag-config/v1", "mode": args.rag_mode,
                "embedding_model": Path(embedding.model_name).name if embedding and Path(embedding.model_name).is_dir() else getattr(embedding, "model_name", None),
                "embedding_revision": getattr(embedding, "revision", None),
                "embedding_dimension": getattr(embedding, "dimension", None),
                "embedding_external": bool(getattr(embedding, 'external', False)),
                "embedding_cloud_consent": bool(local_pdf and getattr(args, 'embedding_cloud_consent', False)),
                "vector_scope": "private_run_local" if local_pdf else ("qdrant_server" if os.getenv("SCIASSISTANT_QDRANT_URL") else "qdrant_local"),
                "chunk_target": 1000, "chunk_overlap": 150, "maximum_evidence_packets": 12,
                "chunk_pipeline": "rag-v4-boundary-safe-overlap", "pdf_download_hosts": 2,
                "pdf_download_total_budget_seconds": 30, "pdf_download_max_attempts": 2,
                "pdf_download_deadline_policy": "isolated-process-shared-deadline/v1",
                "pdf_host_budget_policy": "two-official-hosts-first-half-reserved-fallback/v1",
                "pdf_batch_size": 5, "pdf_paper_limit": 15, "pdf_batch_limit": 3,
                "per_document_packet_limit": 2, "topic_selection": "core_support_fair_batches",
                "representative_document_limit_per_topic": 2,
                "packet_selection": "core_support_representatives_complementary_facets_then_mmr",
                "maximum_local_passage_queries_per_topic": 3,
                "initial_topic_coverage": "missing_actions_use_planned_query_round_robin",
                "evidence_strength_policy": "scope_derived_weak_confidence_low",
                "report_structure_policy": "audited_top_conclusion_or_explicit_limited_fallback",
                "answer_presentation_policy": "claim-draft-v2-visible-scope-retained-review-detail",
            }
            if local_pdf:
                manifest["retrieval_configuration"].update(executor.retrieval_configuration())
            if sources["source_scope"] in {"arxiv", "uploaded_pdf_and_arxiv"}:
                manifest["retrieval_configuration"]["public_reading_priority_policy"] = READING_PRIORITY_POLICY
                manifest["retrieval_configuration"]["indexed_source_reuse_policy"] = INDEXED_SOURCE_REUSE_POLICY
            manifest["configuration_fingerprint"] = hashlib.sha256(json.dumps({
                "model": client.fingerprint, "retrieval": manifest["retrieval_configuration"]}, sort_keys=True).encode()).hexdigest()
        else:
            if local_pdf:
                from multi_agent_local_pdf import LocalPdfRagExecutor
                workers = _mock_agents(source_scope=sources["source_scope"])
                if sources["source_policy"] == "auto":
                    from multi_agent_sources import AutoSourceExecutor
                    executor = AutoSourceExecutor(run_dir, local_pdf, allow_public=True, rag_mode="lexical",
                        public_factory=lambda: DeterministicLiteratureExecutor(_mock_search))
                else:
                    executor = LocalPdfRagExecutor(run_dir, local_pdf, rag_mode="lexical")
                manifest["research_source"] = executor.source_context
                manifest["retrieval_configuration"] = {"schema_version": "sciassistant.rag-config/v1",
                    "mode": "lexical", **executor.retrieval_configuration()}
            else:
                workers, executor = _mock_agents(), DeterministicLiteratureExecutor(_mock_search)
        write_run_json(run_dir / "manifest.json", manifest)
        context = None
        if args.context_file:
            context_path = Path(args.context_file)
            if context_path.stat().st_size > 40_000:
                raise ValueError("context file too large")
            context = json.loads(context_path.read_text(encoding="utf-8-sig"))
        manifest["initialization_elapsed_seconds"] = round(time.monotonic() - initialized_at, 2)
        manifest["effective_workflow_budget_seconds"] = max(1, args.time_budget - int(time.monotonic() - initialized_at))
        write_run_json(run_dir / "manifest.json", manifest)
        pipeline = LiteraturePipelineV2(store, artifacts, workers, executor, event_path=run_dir / "events.jsonl",
                                        time_budget_seconds=max(1, args.time_budget - int(time.monotonic() - initialized_at)),
                                        time_policy=getattr(args, "time_policy", "hard-deadline/v1"),
                                        initialization_elapsed_seconds=time.monotonic() - initialized_at,
                                        report_profile=selected_profile,
                                        configuration_fingerprint=manifest.get("configuration_fingerprint", "mock-v2"),
                                        general_fallback=general_fallback)
        result = pipeline.run(run_id, _credential_owner(), args.query, conversation_context=context)
        if hasattr(executor, "routing_summary"):
            manifest["source_routing"] = executor.routing_summary()
        if local_pdf:
            manifest["pdf_parser_result"] = executor.reading_summary().get("parser_summary")
        manifest["final_artifact_id"] = result["final_artifact_id"]
        current_fingerprint, current_complete = source_fingerprint()
        manifest["code_on_disk_matches_startup"] = (source_complete and current_complete
                                                    and current_fingerprint == startup_fingerprint)
        write_run_json(run_dir / "manifest.json", manifest)
    except RagStorageBusy:
        store.create_run(run_id, _credential_owner(), time_budget_seconds=args.time_budget, report_profile=selected_profile)
        store.force_terminal(run_id, "failed", failure_code="RAG_STORAGE_BUSY")
        manifest["final_artifact_id"] = artifacts.put("final-result", {
            "schema_version": "sciassistant.final-result/v1", "run_id": run_id,
            "status": "failed", "failure_code": "RAG_STORAGE_BUSY",
            "direct_answer": "共享科研索引正在被另一任务使用，请稍后重试。本次未调用模型。"})["artifact_id"]
        write_run_json(run_dir / "manifest.json", manifest)
        export_run_report(run_dir)
        print(json.dumps({"run_id": run_id, "status": "failed", "error_code": "RAG_STORAGE_BUSY"}))
        return 1
    except (ValueError, ImportError, RagDependencyError) as exc:
        try:
            store.get_run(run_id)
        except WorkflowError:
            store.create_run(run_id, _credential_owner(), time_budget_seconds=args.time_budget, report_profile=selected_profile)
        store.force_terminal(run_id, "failed", failure_code="LIVE_CONFIGURATION_INVALID")
        manifest["final_artifact_id"] = artifacts.put("final-result", {"schema_version": "sciassistant.final-result/v1", "run_id": run_id,
                                      "status": "failed", "failure_code": "LIVE_CONFIGURATION_INVALID",
                                      "direct_answer": "CLI配置未就绪，请检查模型设置和本地Embedding/Qdrant依赖；尚未发起研究调用。"})["artifact_id"]
        write_run_json(run_dir / "manifest.json", manifest)
        export_run_report(run_dir)
        print(json.dumps({"run_id": run_id, "status": "configuration_error", "error_code": "LIVE_CONFIGURATION_INVALID"}))
        return 2
    except Exception as exc:
        # Raw tracebacks/provider errors may contain credentials or local paths.
        # Keep a structured cause category before the supervisor loses the worker.
        write_run_json(run_dir / "worker_failure.json", {
            "schema_version": "sciassistant.worker-failure/v1", "run_id": run_id,
            "error_code": "CLI_WORKER_EXCEPTION",
            "error_category": "storage" if isinstance(exc, OSError) else "runtime",
            "at": time.time(),
        })
        finalize_worker_exit(run_dir, run_id, 1, args.time_budget, report_profile=selected_profile)
        print(json.dumps({"run_id": run_id, "status": "failed", "error_code": "CLI_WORKER_EXCEPTION"}))
        return 1
    finally:
        try:
            if executor is not None and hasattr(executor, "services") and executor.services.vector_store is not None:
                executor.services.vector_store.close()
        finally:
            if lease is not None:
                lease.close()
    export_run_report(run_dir)
    budget_file = run_dir / "budget_usage.json"
    budget = json.loads(budget_file.read_text(encoding="utf-8")) if budget_file.exists() else {}
    (run_dir / "run_report.md").write_text(
        f"# Run {run_id}\n\n- status: {result['run']['status']}\n- model_calls: {result['run']['model_calls_used']}/{report_config['model_call_limit']}\n"
        f"- report_profile: {selected_profile}\n"
        f"- requested_time_budget_seconds: {args.time_budget}\n"
        f"- effective_workflow_budget_seconds: {manifest.get('effective_workflow_budget_seconds')}\n"
        f"- reading_stop_reason: {budget.get('reading_stop_reason', 'not_available')}\n"
        f"- reading: {json.dumps(budget.get('reading'), ensure_ascii=False)}\n"
        f"\n完整分段记录见 budget_usage.json；预计大约{report_config['duration_target_seconds']}秒，超过{report_config['research_start_cutoff_seconds']}秒不再启动研究/补查，已开始阶段与最终审计不按总时长目标截断。\n",
        encoding="utf-8",
    )
    print(json.dumps({"run_id": run_id, "run_dir": str(run_dir), "status": result["run"]["status"]}, ensure_ascii=False))
    return 0 if result["run"]["status"] in {"completed", "partial", "needs_review"} else 1


def configured_live_model():
    from dotenv import load_dotenv
    load_dotenv(ROOT / ".env", override=False)
    from deepdiver_v2.config.config import APIConfig
    from multi_agent_live import LiveModelClient
    return LiveModelClient(APIConfig())


def supervise_live(args, run_id):
    """Bound the entire CLI process tree, including network/parser/native work."""
    from process_cleanup import terminate_process_tree
    run_dir = Path(args.output_root) / run_id
    selected_profile = getattr(args, 'report_profile', 'standard')
    report_budget(selected_profile, time_budget=args.time_budget)
    if run_dir.exists():
        raise ValueError("run output already exists")
    command = [sys.executable, str(Path(__file__).resolve()), "run", "--worker", "--mode", "live",
               "--run-id", run_id, "--output-root", args.output_root,
               "--storage-root", args.storage_root, "--rag-mode", args.rag_mode,
               "--time-budget", str(args.time_budget)]
    command.extend(["--time-policy", getattr(args, "time_policy", "hard-deadline/v1")])
    command.extend(['--report-profile', selected_profile])
    command.extend(["--query-file", args.query_file] if args.query_file else ["--query", args.query])
    if args.context_file:
        command.extend(["--context-file", args.context_file])
    if getattr(args, "pdf", None):
        command.extend(["--pdf", args.pdf])
        command.extend(["--pdf-parse-mode", getattr(args, "pdf_parse_mode", "local")])
        if getattr(args, "llama_cloud_consent", False):
            command.append("--llama-cloud-consent")
        if getattr(args, 'embedding_cloud_consent', False):
            command.append('--embedding-cloud-consent')
    if getattr(args, "source_policy", None):
        command.extend(["--source-policy", args.source_policy])
    if getattr(args, "allow_public_search", False):
        command.append("--allow-public-search")
    kwargs = {"start_new_session": True} if os.name != "nt" else {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW}
    environment = os.environ.copy()
    environment["SCIASSISTANT_SUPERVISED_CLI"] = "1"
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, encoding="utf-8", errors="replace", env=environment, **kwargs)
    if os.name != "nt":
        process._sciassistant_process_group = process.pid
    # This belongs to the wrapper, not to model Agents; no argv/env is saved.
    supervision = {"schema_version": "sciassistant.cli-supervision/v1", "run_id": run_id,
                   "supervisor_pid": os.getpid(), "worker_pid": process.pid,
                   "started_at": time.time(), "time_budget_seconds": args.time_budget,
                   "status": "running"}
    try:
        # Worker owns directory creation; write the wrapper record after exit
        # (or timeout) so it cannot race run_dir.mkdir(exist_ok=False).
        output, _ = process.communicate(timeout=None if is_soft_time_policy(getattr(args, "time_policy", None)) else args.time_budget)
        run_dir.mkdir(parents=True, exist_ok=True)
        supervision.update(status="worker_exited", ended_at=time.time(), worker_exit_code=process.returncode)
        write_run_json(run_dir / "supervision.json", supervision)
        print(output.strip())
        if finalize_worker_exit(run_dir, run_id, process.returncode, args.time_budget, report_profile=selected_profile):
            return 1
        return process.returncode
    except (Exception, KeyboardInterrupt) as exc:
        cancelled = isinstance(exc, KeyboardInterrupt)
        expired = isinstance(exc, subprocess.TimeoutExpired)
        cleanup = terminate_process_tree(process)
        run_dir.mkdir(parents=True, exist_ok=True)
        store = WorkflowStore(run_dir / "workflow.sqlite3")
        try:
            run = store.get_run(run_id)
        except WorkflowError:
            run = store.create_run(run_id, _credential_owner(), time_budget_seconds=args.time_budget, report_profile=selected_profile)
        status = "cancelled" if cancelled else "timed_out" if expired else "failed"
        code = "USER_CANCELLED" if cancelled else "OUTER_CLI_TIMEOUT" if expired else "CLI_SUPERVISOR_EXCEPTION"
        if run["status"] not in TERMINAL_STATUSES:
            store.force_terminal(run_id, status, failure_code=code)
        else:
            status = run["status"]
        artifacts = ArtifactDirectory(run_dir / "artifacts")
        manifest_path = run_dir / "manifest.json"
        manifest = read_run_manifest(run_dir, fallback_run_id=run_id)
        # A worker may have committed a terminal result just before the timeout
        # was observed. Preserve that result rather than replace audited claims.
        if not (status in {"completed", "partial", "needs_review"} and manifest.get("final_artifact_id")):
            final = artifacts.put("final-result", {"schema_version": "sciassistant.final-result/v1", "run_id": run_id,
                "status": status, "failure_code": code,
                "direct_answer": ("任务已取消或达到时间预算；已完成的查询和工件保留供检查。" if cancelled or expired
                                  else "任务执行监督发生异常；已完成的查询和工件保留供检查，未自动重跑。")})
            manifest["final_artifact_id"] = final["artifact_id"]
            write_run_json(manifest_path, manifest)
        write_run_json(run_dir / "process_cleanup.json", cleanup)
        supervision.update(status=status, ended_at=time.time(), failure_code=code)
        write_run_json(run_dir / "supervision.json", supervision)
        export_run_report(run_dir)
        print(json.dumps({"run_id": run_id, "status": status, "process_cleanup": cleanup}, ensure_ascii=False))
        return 1


def finalize_worker_exit(run_dir, run_id, returncode, time_budget, *, report_profile=None):
    """A prematurely exited worker must not leave a permanently active run.

    Record a safe boundary failure, never guess the hidden exception or silently
    restart paid work. Completed configuration failures retain their exit code.
    """
    manifest_path = run_dir / "manifest.json"
    manifest = read_run_manifest(run_dir, fallback_run_id=run_id)
    store = WorkflowStore(run_dir / "workflow.sqlite3")
    try:
        run = store.get_run(run_id)
    except WorkflowError:
        run = store.create_run(run_id, _credential_owner(), time_budget_seconds=time_budget,
            report_profile=manifest.get('report_profile', report_profile or 'standard'))
    if run["status"] in TERMINAL_STATUSES and manifest.get("final_artifact_id"):
        return False
    code = "CLI_WORKER_EXCEPTION" if (run_dir / "worker_failure.json").is_file() else "CLI_WORKER_EXITED"
    state = store.force_terminal(run_id, "failed", failure_code=code,
                                interrupt_unpublished_result=True, details={"worker_exit_code": int(returncode)})
    artifact = ArtifactDirectory(run_dir / "artifacts").put("final-result", {
        "schema_version": "sciassistant.final-result/v1", "run_id": run_id,
        "status": state["status"], "failure_code": state["failure_code"],
        "direct_answer": "执行进程在发布结果前结束；已保存工件可检查，未自动重跑。不能据此推断文献不存在。",
    })
    manifest["final_artifact_id"] = artifact["artifact_id"]
    write_run_json(manifest_path, manifest)
    with (run_dir / "events.jsonl").open("a", encoding="utf-8") as stream:
        stream.write(json.dumps({"at": time.time(), "event": "worker_exited_before_publication",
                                 "worker_exit_code": int(returncode), "status": state["status"],
                                 "failure_code": state["failure_code"]}) + "\n")
    export_run_report(run_dir)
    return True


def agent_command(args):
    output_dir = Path(args.output_dir)
    artifacts = ArtifactDirectory(output_dir / "artifacts")
    if args.from_run:
        source = Path(args.from_run)
        matches = sorted((source / "agents").glob(f"*-{args.role}.json"))
        if args.call_number:
            matches = [path for path in matches if path.name.startswith(f"{args.call_number:02d}-")]
        if not matches:
            raise ValueError("no recorded Agent input")
        recorded = json.loads(matches[-1].read_text(encoding="utf-8"))["input"]
        source_artifacts = ArtifactDirectory(source / "artifacts")
        values = [source_artifacts.get(key) for key in recorded["input_artifact_ids"]]
    else:
        payload = json.loads(Path(args.input_json).read_text(encoding="utf-8-sig"))
        if not isinstance(payload, dict):
            raise ValueError("agent input must be an object")
        values = payload.get("input_artifacts") if "input_artifacts" in payload else [payload]
    if not isinstance(values, list) or len(values) > 20 or not all(isinstance(item, dict) for item in values):
        raise ValueError("invalid standalone input artifacts")
    input_ids = [artifacts.put("agent-input-data", value)["artifact_id"] for value in values]
    action = sorted(ROLE_ALLOWED_ACTIONS[args.role])[0]
    if args.mode == "live":
        client = configured_live_model()
        scope = "uploaded_pdf_and_arxiv" if any(value.get("source_scope") == "uploaded_pdf_and_arxiv" for value in values) else "uploaded_pdf" if any(value.get("source_scope") == "uploaded_pdf" for value in values) else "arxiv"
        worker = client.agents(source_scope=scope).by_role(args.role)
    else:
        client = None
        worker = AgentWorker(args.role, lambda packet: {"output": {
            "role": args.role, "input_artifact_count": len(packet["inputs"]), "mode": "mock",
        }}, [action], uses_model=False)
    result = worker.run(make_agent_input(
        run_id=args.run_id, role=args.role, goal="独立角色合同测试",
        input_artifact_ids=input_ids, remaining_model_calls=10,
        deadline_at=time.time() + 40, configuration_fingerprint=client.fingerprint if client else "mock-v2",
    ), artifacts)
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "agent_result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result["status"] == "completed" else 1


@contextmanager
def inspection_store(run_dir):
    """Read a stable DB+WAL copy: even SQLite mode=ro changes WAL SHM bytes.

    Never checkpoint a historical source, or ignore an uncheckpointed WAL.
    A moving database is refused rather than presented as a consistent snapshot.
    """
    source = Path(run_dir) / "workflow.sqlite3"
    paths = (source, source.with_name(source.name + "-wal"))
    def signature():
        result = []
        for path in paths:
            if path.is_symlink():
                raise ValueError("INSPECTION_STORAGE_INVALID")
            stat = path.stat() if path.exists() else None
            result.append((stat.st_size, stat.st_mtime_ns) if stat else None)
        if result[0] is None:
            raise ValueError("INSPECTION_STORAGE_MISSING")
        return result
    with tempfile.TemporaryDirectory(prefix="sci-inspect-") as temporary:
        target = Path(temporary)
        for _ in range(3):
            before = signature()
            try:
                for path, stamp in zip(paths, before):
                    if stamp is not None:
                        shutil.copyfile(path, target / path.name)
                    else:
                        (target / path.name).unlink(missing_ok=True)
            except FileNotFoundError:
                continue
            if before == signature():
                yield WorkflowStore(target / source.name)
                return
        raise ValueError("INSPECTION_STORAGE_BUSY")


def inspect_command(args):
    run_dir = Path(args.run_dir)
    manifest = read_run_manifest(run_dir)
    events = [json.loads(line) for line in (run_dir / "events.jsonl").read_text(encoding="utf-8").splitlines()] if (run_dir / "events.jsonl").is_file() else []
    with inspection_store(run_dir) as store:
        run = store.get_run(manifest["run_id"])
        stages = store.list_stages(manifest["run_id"])
    overdue = run["time_policy"] == "hard-deadline/v1" and time.time() > run["deadline_at"]
    print(json.dumps({"manifest": manifest, "run": run,
                      "lifecycle_check": {"deadline_exceeded": overdue,
                          "terminal_record_missing": overdue and run["status"] not in TERMINAL_STATUSES,
                          "inspection_is_not_process_liveness": True},
                      "stages": stages, "events": events,
                      "rework_count": len(list((run_dir / "rework_tickets").glob("*.json")))}, ensure_ascii=False, indent=2))
    return 0


def replay_command(args):
    source = Path(args.run_dir).resolve()
    read_run_manifest(source)
    # Report generation writes previews and exports; perform it only on a copy.
    # Reject links rather than following them out of the selected run directory.
    if Path(args.run_dir).is_symlink() or any(p.is_symlink() for p in source.rglob("*")):
        raise ValueError("REPLAY_SOURCE_LINK_INVALID")
    destination = getattr(args, "output_dir", None)
    if destination:
        target = Path(destination).resolve()
        if target == source or target.is_relative_to(source) or source.is_relative_to(target) or target.exists():
            raise ValueError("REPLAY_OUTPUT_INVALID")
        shutil.copytree(source, target)
        paths = export_run_report(target)
        matches = _replay_matches(source, target)
    else:
        if any(not (source / name).is_file() for name in ("final_answer.md", "final_answer.html")):
            raise ValueError("REPLAY_REPORT_MISSING_USE_OUTPUT_DIR")
        with tempfile.TemporaryDirectory(prefix="sci-replay-") as temporary:
            target = Path(temporary) / "run"
            shutil.copytree(source, target)
            export_run_report(target)
            matches = _replay_matches(source, target)
        paths = {"markdown": str(source / "final_answer.md"), "html": str(source / "final_answer.html")}
    print(json.dumps({"status": "replayed", "source_run_modified": False,
                      "recorded_exports_match": matches, **paths}, ensure_ascii=False))
    return 0


def _replay_matches(source, target):
    names = ("final_answer.md", "final_answer.html", "references.json", "claim_evidence_map.json", "citation_audit.json")
    manifest = read_run_manifest(source)
    if manifest.get('final_artifact_id'):
        refs = ArtifactDirectory(source / 'artifacts').get(manifest['final_artifact_id']).get('artifact_refs', {})
        names += tuple(name + '.json' for name in ('report_outline', 'section_evidence', 'writer_jobs',
            'section_writing', 'report_composition', 'skill_loads', 'assertion_modes', 'publication_coverage', 'publication_recovery', 'report_review', 'audit_batches') if refs.get(name))
    return {name: (source / name).is_file() and (target / name).is_file()
            and (source / name).read_bytes() == (target / name).read_bytes() for name in names}


def context_command(args):
    """Export only published text as bounded background; never copy approval."""
    from multi_agent_pipeline_v2 import render_claims
    from multi_agent_quality import check_audit, publication_rejections
    directory = Path(args.run_dir).resolve()
    destination = Path(args.output).resolve()
    if destination.is_relative_to(directory):
        raise ValueError("context export cannot modify the source run")
    manifest_path = directory / "manifest.json"
    if manifest_path.stat().st_size > 256_000:
        raise ValueError("run manifest too large")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    if not isinstance(manifest, dict) or not isinstance(manifest.get("final_artifact_id"), str):
        raise ValueError("source run has no final artifact")
    artifacts = ArtifactDirectory(directory / "artifacts")
    final = artifacts.get(manifest["final_artifact_id"])
    if final.get("status") not in {"completed", "partial", "needs_review"}:
        raise ValueError("source run has no usable answer")
    refs = final.get("artifact_refs")
    if not isinstance(refs, dict) or any(not isinstance(refs.get(key), str) for key in ("draft", "approved", "audit", "question", "plan")):
        raise ValueError("source run lacks reviewed answer artifacts")
    draft, approved = artifacts.get(refs["draft"]), artifacts.get(refs["approved"])
    rejected = publication_rejections(check_audit(artifacts.get(refs["audit"]), draft, approved), draft)
    claims = [c for c in draft.get("claims", []) if c["claim_id"] not in rejected and "draft" not in rejected]
    if not claims:
        raise ValueError("source run has no published claims")
    answer = render_claims(draft, approved, rejected=rejected, plan=artifacts.get(refs["plan"]))
    ids = {key for claim in claims for key in claim.get("evidence_ids", [])}
    paper_ids = list(dict.fromkeys(item["paper_id"] for item in approved["evidence"] if item["evidence_id"] in ids))[:10]
    previous_question = artifacts.get(refs["question"]).get("question")
    if not isinstance(previous_question, str):
        raise ValueError("source question unavailable")
    context = {"schema_version": "sciassistant.followup-context/v1",
               "previous_question": previous_question[:1200],
               "previous_answer": answer[:6000], "paper_ids": paper_ids,
               "evidence_policy": "context_only_retrieve_again"}
    # Exclusive creation: neither historical artifacts nor prior Context files
    # are overwritten. This CLI-only export does not touch account state.
    with destination.open("x", encoding="utf-8") as output:
        json.dump(context, output, ensure_ascii=False, indent=2)
    print(json.dumps({"status": "context_exported", "paper_count": len(paper_ids),
        "context_sha256": hashlib.sha256(json.dumps(context, ensure_ascii=False, sort_keys=True).encode()).hexdigest(),
        "question_truncated": len(previous_question) > 1200,
        "answer_truncated": len(answer) > 6000}))
    return 0


def index_command(args):
    with StorageLease(*writer_roots(Path(args.evidence_db).parent)):
        return _index_command_locked(args)


def _index_command_locked(args):
    parsed = json.loads(Path(args.parsed_json).read_text(encoding="utf-8"))
    blocks = parsed.get("evidence_blocks") or parsed.get("layout_blocks") or []
    store = EvidenceStore(args.evidence_db)
    services = configured_vector_services(store, private_document=True,
        cloud_consent=getattr(args, 'embedding_cloud_consent', False))
    indexer = RagIndexer(store, services.embedding, services.vector_store, vector_required=True)
    content_hash = __import__("hashlib").sha256(json.dumps(parsed, sort_keys=True).encode()).hexdigest()
    try:
        result = indexer.index({"document_id": args.document_id, "paper_id": args.paper_id, "title": args.title,
                                "official_url": args.official_url, "content_hash": content_hash}, blocks)
    finally:
        services.vector_store.close()
    print(json.dumps(result, ensure_ascii=False))
    return 0


def serve_command(args):
    directory = Path(args.run_dir).resolve()
    server = ThreadingHTTPServer(("127.0.0.1", args.port), report_handler(directory))
    print(f"http://127.0.0.1:{args.port}/final_answer.html")
    server.serve_forever()


def report_handler(directory):
    directory = Path(directory).resolve()
    public = {"final_answer.html", "final_answer.md", "references.json", "claim_evidence_map.json",
              "evidence_ledger.json", "citation_audit.json"}

    class ReadOnlyReportHandler(SimpleHTTPRequestHandler):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, directory=str(directory), **kwargs)

        def send_head(self):
            valid_hosts = {f"127.0.0.1:{self.server.server_port}", f"localhost:{self.server.server_port}"}
            origin = self.headers.get("Origin")
            if self.headers.get("Host", "").lower() not in valid_hosts or (origin and origin not in {"http://" + host for host in valid_hosts}):
                self.send_error(403, "Local report access only")
                return None
            name = unquote(urlsplit(self.path).path).lstrip("/")
            path = directory / name
            allowed = name in public or bool(__import__("re").fullmatch(
                r"(?:source-[0-9]+\.html|pages/evidence-[0-9]+\.png|pdf/[A-Za-z0-9_-]{1,100}/source\.pdf)", name))
            if not allowed or path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(directory):
                self.send_error(404, "Report resource not found")
                return None
            return super().send_head()

        def end_headers(self):
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Security-Policy", "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; frame-ancestors 'none'")
            super().end_headers()

        def log_message(self, *_args):
            pass

    return ReadOnlyReportHandler


def main(argv=None):
    parser = argparse.ArgumentParser(description="SciAssistant structured multi-agent CLI demo")
    sub = parser.add_subparsers(dest="command", required=True)
    run = sub.add_parser("run"); run.add_argument("--mode", choices=["mock", "live"], default="mock"); run.add_argument("--run-id"); run.add_argument("--output-root", default="logs/multi_agent_runs"); run.set_defaults(func=run_command)
    question = run.add_mutually_exclusive_group(required=True)
    question.add_argument("--query")
    question.add_argument("--query-file", help="UTF-8 question file; keeps question text out of process arguments")
    run.add_argument("--context-file", help="Bounded structured follow-up context; not approved evidence")
    run.add_argument('--credential-user', help='Local trusted CLI only: explicitly use one account encrypted credential; never a Web request field')
    run.add_argument("--pdf", help="Local PDF: private document retrieval, no public literature search")
    run.add_argument("--pdf-parse-mode", choices=["local", "llama_full", "hybrid"], default="local")
    run.add_argument("--llama-cloud-consent", action="store_true", help="Authorize sending this PDF to LlamaCloud for this run (separate from public search)")
    run.add_argument("--source-policy", choices=["local", "auto", "public"], help="Default: local with PDF, public without PDF; auto lets Retriever select sources")
    run.add_argument("--allow-public-search", action="store_true", help="Explicitly authorize question-derived public queries for PDF auto mode; never upload PDF text")
    run.add_argument('--embedding-cloud-consent', action='store_true', help='This run only: permit uploading private PDF text chunks to the configured embedding service; separate from public search/LlamaParse consent')
    run.add_argument("--rag-mode", choices=["hybrid", "lexical"], default="hybrid")
    run.add_argument("--storage-root", default="logs/multi_agent_rag_v2")
    run.add_argument('--report-profile', choices=['standard', 'enhanced'], default='standard', help='Explicit only: standard=10/~360s, enhanced=20/~720s')
    run.add_argument("--time-budget", type=int, choices=range(1, 721), default=None, metavar="profile-bounded-seconds")
    run.add_argument("--time-policy", choices=[SOFT_TIME_POLICY, PROFILE_SOFT_POLICY, "hard-deadline/v1"], default=None,
                     help="New runs: 300s research-start cutoff, approximate total duration; legacy hard timeout is explicit.")
    run.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    agent = sub.add_parser("agent"); agent.add_argument("--role", required=True, choices=sorted(ROLE_ALLOWED_ACTIONS)); agent.add_argument("--output-dir", required=True); agent.add_argument("--run-id", default="agent-test"); agent.add_argument("--mode", choices=["mock", "live"], default="mock"); agent.set_defaults(func=agent_command)
    agent_input = agent.add_mutually_exclusive_group(required=True)
    agent_input.add_argument("--input-json")
    agent_input.add_argument("--from-run")
    agent.add_argument("--call-number", type=int)
    inspect = sub.add_parser("inspect"); inspect.add_argument("--run-dir", required=True); inspect.set_defaults(func=inspect_command)
    replay = sub.add_parser("replay"); replay.add_argument("--run-dir", required=True); replay.add_argument("--output-dir"); replay.set_defaults(func=replay_command)
    context = sub.add_parser("context"); context.add_argument("--run-dir", required=True); context.add_argument("--output", required=True); context.set_defaults(func=context_command)
    serve = sub.add_parser("serve-report"); serve.add_argument("--run-dir", required=True); serve.add_argument("--port", type=int, default=8765); serve.set_defaults(func=serve_command)
    index = sub.add_parser("index"); index.add_argument("--parsed-json", required=True); index.add_argument("--document-id", required=True); index.add_argument("--paper-id", required=True); index.add_argument("--title", required=True); index.add_argument("--official-url", default=""); index.add_argument("--evidence-db", default="logs/evidence.sqlite3"); index.set_defaults(func=index_command)
    index.add_argument('--embedding-cloud-consent', action='store_true', help='Permit sending parsed document text to the configured external embedding service; default local')
    args = parser.parse_args(argv)
    if args.command == 'run':
        try:
            selected = report_budget(args.report_profile, time_budget=args.time_budget)
            args.time_budget = selected['time_budget_seconds']
            args.time_policy = args.time_policy or default_time_policy(args.report_profile)
            if args.report_profile == 'enhanced' and args.time_policy == SOFT_TIME_POLICY:
                parser.error('enhanced profile requires profile-based soft policy or explicit hard-deadline')
        except ValueError:
            parser.error('time budget exceeds the explicitly selected report profile')
    if getattr(args, 'credential_user', None):
        from dotenv import dotenv_values
        from user_credentials import CredentialStore, provider_scope, child_environment, scoped_storage
        values = {**dotenv_values(ROOT / 'deepdiver_v2/config/.env'), **dotenv_values(ROOT / '.env'), **os.environ}
        store = CredentialStore(values.get('SCIASSISTANT_USER_CREDENTIAL_DB', ROOT / 'logs/user_credentials.sqlite3'),
                                values.get('USER_CREDENTIAL_ENCRYPTION_KEY') or values.get('SECRET_KEY'))
        cap = store.capability(args.credential_user)
        if not store.status(cap)['deepseek']['configured']:
            raise ValueError('USER_PROVIDER_KEY_REQUIRED')
        # This local process explicitly opts in; its owned subprocess inherits
        # the same capability. The HTTP gateway never accepts this selector.
        with provider_scope(cap):
            args.storage_root = str(scoped_storage(args.storage_root))
            os.environ.update(child_environment(os.environ))
            return int(args.func(args) or 0)
    return int(args.func(args) or 0)


if __name__ == "__main__":
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")
    try:
        raise SystemExit(main())
    except RagStorageBusy:
        print(json.dumps({"status": "failed", "error_code": "RAG_STORAGE_BUSY"}))
        raise SystemExit(1)
    except (ValueError, OSError, ImportError, RagDependencyError, AgentContractError):
        print(json.dumps({"status": "configuration_error", "error_code": "CLI_INPUT_OR_CONFIGURATION_INVALID"}))
        raise SystemExit(2)
