"""Isolated synthetic-vector benchmark; no papers, answer model, or live service."""
from __future__ import annotations
import argparse
from contextlib import nullcontext
import hashlib
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def benchmark(output):
    from multi_agent_rag import EvidenceStore, RagIndexer, QdrantVectorStore, configured_embedding
    from runtime_identity import source_fingerprint
    output.mkdir(parents=True, exist_ok=False)
    report = {'schema_version': 'sciassistant.embedding-performance/v1', 'status': 'running',
              'fixture': 'synthetic-not-scientific-evidence', 'answer_model_calls': 0,
              'paper_network_requests': 0, 'scientific_quality_verified': False}
    before = source_fingerprint()
    report['source_fingerprint'] = before[0]
    report['source_complete'] = before[1]
    vectors = None
    try:
        started = time.monotonic()
        store = EvidenceStore(output / 'evidence.sqlite3')
        embedding = configured_embedding(store)
        report.update(provider='external' if embedding.external else 'local', dimension=embedding.dimension,
                      initialization_ms=round((time.monotonic() - started) * 1000, 3))
        vectors = QdrantVectorStore(dimension=embedding.dimension, path=output / 'vectors')
        indexer = RagIndexer(store, embedding, vectors, vector_required=True)
        blocks = [{'page': i + 1, 'text': f'Synthetic experiment {i}. ' + (
            'An inference engine stores keys and values in pages. A draft model proposes tokens and a target '
            'model verifies candidates. Measurements of memory, throughput and latency require separate '
            'metrics and matched hardware. This is a synthetic performance fixture, not a research result. ') * 12}
            for i in range(8)]
        metadata = {'document_id': 'benchmark', 'paper_id': 'synthetic', 'title': 'Synthetic benchmark',
                    'content_hash': hashlib.sha256(json.dumps(blocks).encode()).hexdigest()}
        cold = indexer.index(metadata, blocks)
        # Changed source identity, identical chunks: prove chunk-cache reuse.
        changed = {**metadata, 'content_hash': 'same-chunks-new-source-revision'}
        warm = indexer.index(changed, blocks)
        ready = indexer.index(changed, blocks)
        report.update(status='passed', cold=cold, warm_chunks=warm, ready_document=ready,
                      checks={'cold_embedded': cold['embedding_cache']['misses'] > 0,
                              'warm_no_embedding_misses': warm['embedding_cache']['misses'] == 0,
                              'warm_cache_hits': warm['embedding_cache']['hits'] == warm['chunk_count'],
                              'ready_document_reused': not ready['changed']})
        if not all(report['checks'].values()):
            report['status'] = 'failed'
    except Exception:
        report.update(status='failed', error_code='EMBEDDING_BENCHMARK_FAILED')
    finally:
        if vectors is not None:
            vectors.close()
        report['source_unchanged'] = source_fingerprint() == before
        (output / 'summary.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--provider', choices=['local', 'external'], default='local')
    parser.add_argument('--allow-external-fixture', action='store_true')
    parser.add_argument('--credential-user', help='Use this account encrypted embedding key, never its chat key')
    args = parser.parse_args()
    if args.output.exists() or (args.provider == 'external' and not args.allow_external_fixture):
        parser.error('new output directory and explicit external-fixture permission required')
    os.environ['SCIASSISTANT_EMBEDDING_PROVIDER'] = args.provider
    os.environ['SCIASSISTANT_EMBEDDING_ALLOW_DOWNLOAD'] = '0'
    os.environ['HF_HUB_OFFLINE'] = os.environ['TRANSFORMERS_OFFLINE'] = '1'
    scope = nullcontext()
    if args.credential_user:
        from dotenv import dotenv_values
        from user_credentials import CredentialStore, provider_scope
        settings = {**dotenv_values(ROOT / '.env'), **os.environ}
        store = CredentialStore(settings.get('SCIASSISTANT_USER_CREDENTIAL_DB', ROOT / 'logs/user_credentials.sqlite3'),
                                settings.get('USER_CREDENTIAL_ENCRYPTION_KEY') or settings.get('SECRET_KEY'))
        scope = provider_scope(store.capability(args.credential_user))
    with scope:
        report = benchmark(args.output)
    print(json.dumps(report, ensure_ascii=False))
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
