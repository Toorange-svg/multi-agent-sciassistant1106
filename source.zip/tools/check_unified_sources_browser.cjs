/* Product UI with owned loopback API fixtures. No real user keys or model calls. */
const fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('playwright');
const root=path.resolve(__dirname,'..'),label=process.argv[2]||'01';
if(!/^[a-z0-9-]+$/.test(label))throw Error('invalid label');
const out=path.join(root,'logs/unified_sources_20261015/browser-'+label);
if(fs.existsSync(out))throw Error('preserve prior result');fs.mkdirSync(out,{recursive:true});
const calls=[],checks={},errors=[];let browser,binding=null;
const file={id:'fixture-pdf',name:'可复用论文.pdf',can_analyze:true,type:'pdf',size:1024,status:'已上传，尚未索引',processing_state:'uploaded',outcomes:[]};
const server=http.createServer((req,res)=>{
 const u=new URL(req.url,'http://fixture');calls.push({method:req.method,path:u.pathname});
 if(u.pathname.startsWith('/5000/api/')){
  res.setHeader('Content-Type','application/json');
  let body={status:'healthy'};
  if(u.pathname==='/5000/api/account/provider-keys')body={schema_version:'sciassistant.account-provider-status/v1',deepseek:{configured:!String(req.headers.authorization).includes('new-owner-fixture'),key_count:1},llama:{configured:false}};
  else if(u.pathname.endsWith('/pdf-attachment'))body={attachment:binding};
  else if(u.pathname==='/5000/api/research-library/files')body={success:true,files:[file]};
  else if(u.pathname.startsWith('/5000/api/research-library/files/'))body={success:true,file};
  else if(u.pathname==='/5000/api/literature/papers')body={papers:[{id:'cached-one',cache_kind:'task',task_id:'abcdef012345',document_id:'arxiv-2309-06180v1',title:'已下载的历史论文',source:'arxiv',size_mb:1,pdf_count:1}],next_offset:null};
  else if(u.pathname.endsWith('/save'))body={success:true,files:[{file_id:file.id}]};
  else if(u.pathname==='/5000/api/chat/sessions')body=[];
  else if(u.pathname.includes('/chat/sessions/'))body=[];
  return res.end(JSON.stringify(body));
 }
 const target=u.pathname==='/ai_chat.html'?path.join(root,'chatAi/ai_chat.html'):u.pathname.startsWith('/images/')?path.resolve(root,'chatAi','.'+u.pathname):path.resolve(root,'.'+u.pathname);
 const allowed=path.join(root,'chatAi')+path.sep;
 if(!target.startsWith(allowed)||!fs.existsSync(target)||!fs.statSync(target).isFile()||!fs.realpathSync(target).startsWith(allowed)){res.statusCode=404;return res.end();}
 res.setHeader('Content-Type',target.endsWith('.js')?'text/javascript':target.endsWith('.css')?'text/css':target.endsWith('.html')?'text/html':'application/octet-stream');res.end(fs.readFileSync(target));
});
(async()=>{
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 try{
  browser=await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe'});
  const context=await browser.newContext({viewport:{width:1366,height:980},ignoreHTTPSErrors:true});
  await context.addInitScript(()=>{sessionStorage.setItem('userToken','unified-fixture-not-real');sessionStorage.setItem('userId','fixture');sessionStorage.setItem('username','来源选择验收');});
  const page=await context.newPage();page.on('pageerror',e=>errors.push(e.name));
  await page.goto('http://127.0.0.1:'+server.address().port+'/ai_chat.html',{waitUntil:'domcontentloaded'});
  await page.waitForFunction(()=>window.ResearchLibrary&&window.SciencePdfSession);
  await page.waitForFunction(()=>document.getElementById('account-keys-status').textContent.includes('已配置'));
  checks.keys_at_sidebar_bottom=await page.locator('#sidebar #account-keys-btn').count()===1;
  checks.task_entry_removed=await page.locator('#research-task-center-btn').count()===0;
  checks.configured_user_no_prompt=!(await page.locator('#account-keys-dialog').isVisible());
  await page.locator('#account-keys-btn').click();
  checks.existing_keys_status_only=await page.locator('#account-keys-status').innerText().then(s=>s.includes('已配置 1'))&&await page.locator('#account-deepseek-key').inputValue()==='';
  await page.locator('#account-keys-close').click();
  await page.evaluate(()=>{window.currentSessionId='fixture-session';});
  checks.one_multi_agent_option=await page.locator('#research-processing-mode option[value^="multi_agent_"]').count()===1;
  await page.locator('#context-file-label').click();
  checks.menu_opens_first=await page.locator('#attachment-action-menu').isVisible();
  await page.screenshot({path:path.join(out,'attachment-menu-wide.png')});
  await page.keyboard.press('Escape');
  checks.escape_returns_focus=await page.evaluate(()=>document.getElementById('attachment-action-menu').hidden&&document.activeElement.id==='context-file-label');
  await page.locator('#context-file-label').click();
  const choosing=page.waitForEvent('filechooser');await page.locator('#attachment-upload-action').click();
  const chooser=await choosing;await chooser.setFiles({name:'uploaded.pdf',mimeType:'application/pdf',buffer:Buffer.from('%PDF-1.4\nfixture')});
  await page.waitForSelector('#library-local-only');
  checks.explicit_upload_chooser=true;
  checks.default_local_radio=await page.locator('#library-local-only').isChecked()&&!(await page.locator('#library-public-consent').isChecked());
  const payload=()=>page.evaluate(async()=>{const f=new FormData();await window.ResearchLibrary.append(f,window.currentSessionId,'multi_agent_rag',window.sciencePendingFile);return Object.fromEntries(f);});
  let data=await payload();checks.default_local_payload=data.source_policy==='local'&&data.allow_public_search==='false';
  await page.locator('#library-public-consent').check();data=await payload();
  checks.manual_public_radio=!(await page.locator('#library-local-only').isChecked())&&data.source_policy==='auto'&&data.allow_public_search==='true';
  await page.locator('#library-local-only').check();data=await payload();
  checks.return_to_local=!(await page.locator('#library-public-consent').isChecked())&&data.source_policy==='local';
  await page.locator('#library-public-consent').check();
  binding={filename:'uploaded.pdf',source_task_id:'abcdef012345'};
  await page.evaluate(task=>{window.sciencePendingFile=null;window.ResearchLibrary.submitted({pdf_attachment:task});},binding);
  checks.next_round_resets_local=await page.locator('#library-local-only').isChecked()&&!(await page.locator('#library-public-consent').isChecked());
  await page.locator('#context-file-label').click();await page.locator('#attachment-library-action').click();
  await page.waitForSelector('.library-analyze-btn');checks.library_menu_action=await page.locator('#file-library-view').isVisible();
  await page.locator('#tab-lit-cache').click();await page.getByText('已下载的历史论文',{exact:true}).waitFor();
  checks.cached_papers_visible=await page.getByRole('button',{name:'下载原文',exact:true}).count()===1;
  await page.getByRole('button',{name:'保存并选用',exact:true}).click();await page.waitForSelector('#library-selected-pdf:not([hidden])');
  checks.cache_save_select=await page.locator('#library-selected-pdf').innerText().then(s=>s.includes(file.name))&&calls.some(c=>c.method==='POST'&&c.path.endsWith('/save'));
  checks.selection_uses_unified_mode=await page.locator('#research-processing-mode').inputValue()==='multi_agent_rag';
  checks.saved_selection_defaults_local=await page.locator('#library-local-only').isChecked();
  await page.setViewportSize({width:462,height:900});await page.locator('#context-file-label').click();
  checks.narrow_menu_fits=await page.locator('#attachment-action-menu').evaluate(el=>{const r=el.getBoundingClientRect();return r.left>=0&&r.right<=innerWidth;});
  await page.screenshot({path:path.join(out,'attachment-menu-narrow.png')});
  const newcomer=await browser.newContext({viewport:{width:462,height:900},ignoreHTTPSErrors:true});
  await newcomer.addInitScript(()=>{sessionStorage.setItem('userToken','new-owner-fixture');sessionStorage.setItem('userId','new-fixture');sessionStorage.setItem('username','新用户引导');});
  const welcome=await newcomer.newPage();welcome.on('pageerror',e=>errors.push(e.name));
  await welcome.goto('http://127.0.0.1:'+server.address().port+'/ai_chat.html',{waitUntil:'domcontentloaded'});
  await welcome.locator('#account-keys-dialog').waitFor({state:'visible'});
  checks.new_user_guidance=await welcome.locator('#account-keys-onboarding').isVisible()&&await welcome.locator('#account-keys-status').innerText().then(s=>s.includes('未配置'));
  checks.new_user_no_inherited_keys=await welcome.locator('#account-keys-dialog input[type=password]').evaluateAll(fields=>fields.every(i=>i.value===''));
  checks.guidance_narrow_fits=await welcome.locator('#account-keys-dialog').evaluate(el=>{const r=el.getBoundingClientRect();return r.left>=0&&r.right<=innerWidth;});
  await welcome.screenshot({path:path.join(out,'new-user-keys-narrow.png')});
  await welcome.locator('#account-keys-close').click();
  checks.guidance_can_defer=!(await welcome.locator('#account-keys-dialog').isVisible());
  await newcomer.close();
  const dialogFixture=await page.evaluate(()=>({html:document.getElementById('account-keys-dialog').outerHTML,
   css:[...document.querySelectorAll('style')].flatMap(s=>[...(s.sheet?.cssRules||[])]).filter(r=>r.selectorText?.includes('#account-keys-dialog')).map(r=>r.cssText).join('\n')}));
  const noCdn=await context.newPage();await noCdn.setViewportSize({width:462,height:900});
  await noCdn.setContent('<!doctype html><style>'+dialogFixture.css+'</style>'+dialogFixture.html);
  checks.keys_fit_without_tailwind=await noCdn.evaluate(()=>{const dialog=document.getElementById('account-keys-dialog');dialog.removeAttribute('open');dialog.showModal();
   const r=dialog.getBoundingClientRect();return r.left>=0&&r.right<=innerWidth&&[...dialog.querySelectorAll('input[type=password]')].every(i=>i.getBoundingClientRect().right<=r.right);});
  await noCdn.close();
  checks.no_model_tasks=calls.every(c=>!c.path.endsWith('/science/tasks'));
  checks.no_page_errors=errors.length===0;
  checks.styles_loaded=await page.evaluate(()=>typeof tailwind!=='undefined');
 }catch(e){checks.execution=false;errors.push(e.name);console.log(String(e.message).slice(0,500));}
 finally{
  const result={passed:Object.values(checks).every(Boolean),checks,page_errors:errors,account_apis_stubbed:true,paid_model_calls:0};
  fs.writeFileSync(path.join(out,'result.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));
  await browser?.close();server.close();if(!result.passed)process.exitCode=1;
 }
})();
