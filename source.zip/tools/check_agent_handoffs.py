"""Read-only middle-stage diagnosis; no model/network calls or historical edits."""
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from multi_agent_agents import ArtifactDirectory
from multi_agent_handoffs import PLAN_SCHEMA, TYPED_PLAN_SCHEMAS, project_audit_packet, AUDIT_JOB_POLICY, comparison_observations
from multi_agent_report_contracts import REPORT_PLAN_SCHEMA
from tools.check_premise_artifacts import tree, read


def diagnose(run):
    before = tree(run)
    store = ArtifactDirectory(run/'artifacts')
    manifest = read(run/'manifest.json')
    final = store.get(manifest['final_artifact_id']) if manifest.get('final_artifact_id') else {}
    refs = final.get('artifact_refs', {})
    def artifact(key):
        return store.get(refs[key]) if refs.get(key) else {}
    plan, draft, review = artifact('plan'), artifact('draft'), artifact('review')
    events = [json.loads(x) for x in (run/'events.jsonl').read_text(encoding='utf8').splitlines()]
    publications = read(run/'publication_decisions.json') if (run/'publication_decisions.json').exists() else {}
    audits = []
    for event in events:
        if event.get('event') != 'agent_started' or event.get('role') != 'citation_auditor':
            continue
        ids = event['input_artifact_ids']
        packet = {'inputs': [{'artifact_id': key, 'payload': store.get(key)} for key in ids]}
        projected = project_audit_packet(packet)
        audit_input = next((r['payload'] for r in projected['inputs']
            if r['payload'].get('schema_version') == 'sciassistant.citation-audit-input/v1'), {})
        jobs = audit_input.get('audit_jobs', [])
        audits.append({'call_number': event.get('call_number'),
            'input_artifact_ids': ids, 'projection_reconstructed_not_a_new_call': True,
            'job_policy': audit_input.get('audit_job_policy'), 'job_count': len(jobs),
            'comparison_observations': audit_input.get('comparison_observations'),
            'report_assertions': audit_input.get('report_assertions'),
            'jobs': [{'claim_id': j['claim_id'], 'cited_sources': j['approved_cited_source_ids'],
                      'choice_labels': [o.get('choice_label') for o in j['source_witness_options']],
                      'all_choices_belong_to_job': all(o.get('claim_id') == j['claim_id'] for o in j['source_witness_options']),
                      'related_report_claim_ids': j.get('related_report_claim_ids', []),
                      'processing_context': j['processing_context']} for j in jobs]})
    result = {'schema_version': 'sciassistant.agent-handoff-diagnosis/v1',
        'run_dir': str(run.relative_to(ROOT)), 'status': final.get('status'),
        'planning': {'schema': plan.get('schema_version'),
            'typed': plan.get('schema_version') in {'sciassistant.research-plan/v3', *TYPED_PLAN_SCHEMAS},
            'current_schema': plan.get('schema_version') == REPORT_PLAN_SCHEMA,
            'research_groups': [{'id': g.get('id'), 'kind': g.get('kind'), 'question': g.get('question'),
                'evidence_needs': g.get('evidence_needs', [])} for g in plan.get('groups', [])],
            'report_obligations': plan.get('report_obligations', []),
            'premise_checks': plan.get('premise_checks', []),
            'literal_user_statement_comparison': [{'check_id': r.get('check_id'),
                'assumption_equals_quote': r.get('assumption') == r.get('question_quote'),
                'semantic_entailment_verified': False} for r in plan.get('premise_checks', []) if r.get('origin') == 'user_statement']},
        'search_actions': artifact('initial_search_actions'),
        'query_compilation': artifact('search_plan_compilation'),
        'comparison_observations': artifact('comparison_observations'),
        'current_table_observations_not_historical_verdict': comparison_observations(artifact('approved')),
        'retrieval_events': [e for e in events if e.get('event') in {
            'retrieval_query', 'retrieval_query_result', 'literature_reading', 'reading_batch_completed'}],
        'role_format_errors': [{'artifact_id': p.stem, 'diagnostic': read(p)}
            for p in (run/'artifacts').glob('*.json')
            if read(p).get('schema_version') == 'sciassistant.model-format-diagnostic/v1'],
        'control_events': [e for e in events if e.get('event') in {
            'agent_format_retry', 'planner_format_feedback_prepared', 'workflow_finished',
            'gap_recovery_started', 'gap_recovery_completed', 'audit_protocol_retry'}],
        'retrieved_need_flow': artifact('need_flow_retrieved'),
        'reviewed_need_flow': artifact('need_flow_reviewed'),
        'selected_passage_handoffs': [{'evidence_id': e.get('evidence_id'), 'paper_id': e.get('paper_id'),
            'page': e.get('locator', {}).get('page'), 'selection': e.get('retrieval', {}).get('evidence_need_selection'),
            'reviewer_approved': e.get('evidence_id') in review.get('allowed_evidence_ids', []),
            'semantic_support_verified_by_diagnostic': False}
            for e in artifact('evidence').get('evidence', [])],
        'review': {'allowed_evidence_ids': review.get('allowed_evidence_ids', []),
            'coverage': review.get('coverage', []), 'decisions': review.get('decisions', [])},
        'writing': {'claims': [{'claim_id': c.get('claim_id'), 'section': c.get('section'),
            'text': c.get('text'), 'scope_note': c.get('scope_note'),
            'evidence_ids': c.get('evidence_ids'), 'depends_on_claim_ids': c.get('depends_on_claim_ids', [])}
            for c in draft.get('claims', [])]},
        'audit_handoffs': audits, 'publication': publications,
        'source_hashes_unchanged': before == tree(run),
        'source_file_count': len(before), 'model_calls': 0, 'network_requests': 0,
        'semantic_auto_approval': False, 'historical_verdict_changed': False}
    if not result['source_hashes_unchanged']:
        raise ValueError('SOURCE_RUN_CHANGED')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-dir', type=Path, action='append', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    runs, output = [r.resolve() for r in args.run_dir], args.output.resolve()
    if (any(output.is_relative_to(r) for r in runs) or not output.is_relative_to(ROOT/'logs')
            or output.suffix.lower() != '.json' or output.exists()):
        parser.error('new logs-only JSON outside source runs required')
    results = [diagnose(r) for r in runs]
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps({'runs':results},ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps([{'run_dir':r['run_dir'],'typed':r['planning']['typed'],
        'audit_calls':len(r['audit_handoffs']),'source_unchanged':r['source_hashes_unchanged']} for r in results],ensure_ascii=False))
