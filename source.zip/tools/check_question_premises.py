"""Explicit paid CLI cases; new logs-only roots, per-case storage, no automatic reruns."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from multi_agent_agents import ArtifactDirectory
from runtime_identity import source_fingerprint

CASES = {
    "detr": ("public_arxiv", "DETR 对 AI 生成图片的检测有什么帮助？"),
    "vit": ("public_arxiv", "ViT 对 AI 生成图片的检测有什么帮助？"),
    "detr_negative": ("uploaded_pdf", "DETR 对任何 AI 生成图片鉴别任务都不可能有用，对吗？"),
    "ambiguous": ("uploaded_pdf", "DETR 是那个用于识别 AI 图片的 DETER 吗？它们是不是同一个方法？"),
    "freeze": ("uploaded_pdf", "QLoRA 冻结了底座，所以训练时就完全不需要反向传播了，对吗？"),
    "followup": ("uploaded_pdf", "所以底座冻结之后，就完全不需要反向传播，对吗？"),
    "metric": ("uploaded_pdf", "论文的95%和85%是否意味着泛化性能下降10%？直接说明能不能这么解读，并交代两个结果各自的设置。"),
    "hypothetical": ("uploaded_pdf", "假设在QLoRA中也更新底座权重，显存和训练过程会如何变化？请把条件推断与本文实测分开。"),
    "constraints": ("uploaded_pdf", "只依据这篇QLoRA PDF且不要联网：请提供截至今天所有新方法的完整排名；如果条件冲突请先指出，再给本文确实能支持的信息。"),
}


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def isolated_environment(folder):
    env = dict(os.environ)
    env.update(SCIASSISTANT_EMBEDDING_ALLOW_DOWNLOAD="0",
        MODEL_KEY_POOL_STATE_PATH=str(folder / "keys.sqlite3"),
        LITERATURE_CACHE_PATH=str(folder / "literature.sqlite3"),
        SCIASSISTANT_LITERATURE_STATE_PATH=str(folder / "source-state.sqlite3"),
        SCIASSISTANT_LITERATURE_CACHE_DIR=str(folder / "source-cache"),
        PDF_PARSE_CACHE_DIR=str(folder / "parser-cache"),
        SCIASSISTANT_QDRANT_URL="", SCIASSISTANT_QDRANT_PATH=str(folder / "vectors"),
        PYTHONIOENCODING="utf-8", PYTHONDONTWRITEBYTECODE="1", OMP_NUM_THREADS="2")
    return env


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--credential-user", required=True)
    parser.add_argument("--case", action="append", choices=CASES, required=True)
    parser.add_argument("--qlora-pdf", type=Path)
    parser.add_argument("--metric-pdf", type=Path)
    parser.add_argument("--detr-pdf", type=Path, help="Explicit local official-paper case, not public-search recovery")
    parser.add_argument("--vit-pdf", type=Path, help="Explicit local official-paper case, not public-search recovery")
    parser.add_argument("--context-file", type=Path, help="Structured background for the explicit followup case only")
    args = parser.parse_args()
    root = args.output_root.resolve()
    if root.exists() or not root.is_relative_to(ROOT / "logs"):
        parser.error("new logs-only root required")
    if len(args.case) != len(set(args.case)):
        parser.error("duplicate cases are not reruns")
    if "followup" in args.case and (not args.context_file or not args.context_file.is_file()):
        parser.error("followup requires an explicit context file")
    for case in args.case:
        pdf = args.detr_pdf if case in {"detr", "detr_negative", "ambiguous"} else args.vit_pdf if case == "vit" else args.metric_pdf if case == "metric" else args.qlora_pdf
        if CASES[case][0] == "uploaded_pdf" and (not pdf or not pdf.is_file()):
            parser.error("local case requires its PDF")
        if case in {"detr", "vit"} and pdf and not pdf.is_file():
            parser.error("explicit official PDF input does not exist")
    root.mkdir(parents=True)
    receipts = []
    for case in args.case:
        scope, question = CASES[case]
        public_case_pdf = args.detr_pdf if case in {"detr", "detr_negative", "ambiguous"} else args.vit_pdf if case == "vit" else None
        if public_case_pdf:
            scope = "uploaded_pdf"
        folder = root / case
        folder.mkdir()
        query = folder / "question.txt"
        query.write_text(question, encoding="utf8")
        env = isolated_environment(folder)
        run_id = "premises-" + case + "-" + root.name
        command = [sys.executable, str(ROOT / "tools/multi_agent_cli.py"), "run", "--mode", "live",
            "--credential-user", args.credential_user, "--run-id", run_id,
            "--query-file", str(query), "--rag-mode", "hybrid", "--time-budget", "360",
            "--source-policy", "public" if scope == "public_arxiv" else "local",
            "--output-root", str(folder / "runs"), "--storage-root", str(folder / "storage")]
        pdf = None if scope == "public_arxiv" else (public_case_pdf or (args.metric_pdf if case == "metric" else args.qlora_pdf)).resolve()
        pdf_hash = hashlib.sha256(pdf.read_bytes()).hexdigest() if pdf else None
        if pdf:
            command.extend(["--pdf", str(pdf)])
        context_hash = None
        if case == "followup":
            command.extend(["--context-file", str(args.context_file.resolve())])
            context_hash = hashlib.sha256(args.context_file.read_bytes()).hexdigest()
        started = time.monotonic()
        before = source_fingerprint()
        with (folder / "stdout.log").open("w", encoding="utf8") as output:
            process = subprocess.run(command, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT)
        run = folder / "runs" / run_id
        manifest = read(run / "manifest.json") if (run / "manifest.json").exists() else {}
        artifacts = ArtifactDirectory(run / "artifacts")
        final = artifacts.get(manifest["final_artifact_id"]) if manifest.get("final_artifact_id") else {}
        refs = final.get("artifact_refs", {})
        premise = artifacts.get(refs["premise_assessment"]) if refs.get("premise_assessment") else {}
        usage = read(run / "budget_usage.json") if (run / "budget_usage.json").exists() else {}
        receipt = {"case": case, "question": question, "input_mode": scope,
            "pdf_parse_mode": "local", "pdf_sha256": pdf_hash,
            "pdf_unchanged": hashlib.sha256(pdf.read_bytes()).hexdigest() == pdf_hash if pdf else None,
            "context_sha256": context_hash, "warm_public_cache": False,
            "explicit_local_substitute_for_public_case": bool(public_case_pdf) and CASES[case][0] == "public_arxiv",
            "run_dir": str(run.relative_to(ROOT)), "exit_code": process.returncode,
            "wall_seconds": round(time.monotonic() - started, 2), "status": final.get("status"),
            "failure_code": final.get("failure_code"), "budget": usage,
            "fingerprint_before": before, "fingerprint_after": source_fingerprint(),
            "premise_assessment": premise,
            "claims": len(read(run / "claim_evidence_map.json")) if (run / "claim_evidence_map.json").exists() else 0,
            "references": len(read(run / "references.json")) if (run / "references.json").exists() else 0}
        receipts.append(receipt)
        (root / "receipt.json").write_text(json.dumps({"runs": receipts}, ensure_ascii=False, indent=2), encoding="utf8")
        print(json.dumps({k: receipt[k] for k in ("case", "input_mode", "status", "failure_code", "claims", "references", "wall_seconds")}, ensure_ascii=False), flush=True)
        # Preserve first outcomes. Unrelated retrieval failure does not hide later
        # local cases; unavailable model service stops further paid attempts.
        if receipt["failure_code"] in {"MODEL_SERVICE_UNAVAILABLE", "MODEL_PAYMENT_REQUIRED"}:
            break


if __name__ == "__main__":
    main()
