# -*- coding: utf-8 -*-
import json, pathlib, re
ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / "logs" / "multidomain_eval_20260920_192106.jsonl"
LOGS = ROOT / "logs"
OUT = ROOT / "logs" / "multidomain_first3_preview.md"

def clean(ans):
    # 降级文案：保留友好结论，去掉技术诊断行
    if ans.startswith("已完成检索"):
        m = re.match(r"已完成检索：共检索到 (\d+) 篇候选文献，其中 (\d+) 篇通过相关性门控，但在证据账本构建后可用 (\d+) 篇", ans)
        if m:
            cand, gate, avail = m.groups()
            return (f"（证据不足）共检索到 {cand} 篇候选，{gate} 篇通过相关性筛选，"
                    f"但完整核验后可用 {avail} 篇，未找到足够支撑回答的相关文献。")
    # 删去 zenodo/techrxiv 技术行
    ans = re.sub(r"\n?- (arxiv|zenodo|techrxiv)：[^\n]*", "", ans)
    ans = re.sub(r"被拒候选的主要类型：[^\n]*", "", ans)
    return ans.strip()

lines = SRC.read_text(encoding="utf-8").splitlines()
parts = ["# 多领域实测 · 前三个会话预览\n"]
dom_map = {"A_LLM架构与注意力": "领域 A：LLM 架构与注意力"}
labels = {1: "主问题", 2: "追问一", 3: "追问二"}
for li in range(3):
    o = json.loads(lines[li])
    parts.append(f"\n---\n\n## {dom_map.get(o['domain'], o['domain'])} · 第 {o['q_index']} 题\n")
    for ri, r in enumerate(o["rounds"]):
        ans = r.get("answer_head", "")
        fp = LOGS / f"web_task_{r['task_id']}.followup.json"
        if fp.exists():
            try:
                ans = json.loads(fp.read_text(encoding="utf-8")).get("answer", ans)
            except Exception:
                pass
        parts.append(f"\n### Q{ri+1} · {labels[ri+1]}\n\n**问：** {r['query']}\n\n**答：**\n\n{clean(ans)}\n")
OUT.write_text("\n".join(parts), encoding="utf-8")
print("OK", OUT, "chars", OUT.stat().st_size)
