"""Offline report benchmark and pinned-source checks; never invokes an Agent.

The gold requirements are test expectations, not evidence or live user consent.
No upstream Python module, install script, model, or tool executor is imported.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
SPEC = ROOT / "tests/fixtures/full_report_cases.json"
PINS = ROOT / "docs/references/full_report_upstreams_20261021.json"
SCHEMA = "sciassistant.full-report-benchmark/v1"


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def source_sha256(path):
    """Reviewed UTF-8 text: tolerate Git's CRLF checkout, not content changes."""
    return sha256(Path(path).read_bytes().replace(b"\r\n", b"\n"))


def _unique_object(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError("DUPLICATE_JSON_KEY")
        obj[key] = value
    return obj


def read_json(path):
    path = Path(path)
    if path.stat().st_size > 2_000_000:
        raise ValueError("BENCHMARK_INPUT_TOO_LARGE")
    return json.loads(path.read_text(encoding="utf-8-sig"), object_pairs_hook=_unique_object)


def _text(value):
    return isinstance(value, str) and bool(value.strip())


def validate_spec(spec):
    if (not isinstance(spec, dict)
            or spec.get("schema_version") != "sciassistant.full-report-benchmark-spec/v1"
            or spec.get("background_is_evidence") is not False):
        raise ValueError("BENCHMARK_SCHEMA_INVALID")
    common = spec.get("common_background")
    families = spec.get("families")
    if (not isinstance(common, list) or not common or not all(map(_text, common))
            or not isinstance(families, list) or not families):
        raise ValueError("BENCHMARK_CONTENT_INVALID")
    family_ids = set()
    for family in families:
        if not isinstance(family, dict):
            raise ValueError("BENCHMARK_FAMILY_INVALID")
        key = family.get("id")
        if not isinstance(key, str) or not re.fullmatch(r"[a-z][a-z_]{1,59}", key) or key in family_ids:
            raise ValueError("BENCHMARK_FAMILY_ID_INVALID")
        family_ids.add(key)
        if family.get("source_scope") not in {"public", "uploaded_pdf", "auto"}:
            raise ValueError("BENCHMARK_SCOPE_INVALID")
        paragraphs = family.get("background")
        if not isinstance(paragraphs, list) or not paragraphs or not all(map(_text, paragraphs)):
            raise ValueError("BENCHMARK_BACKGROUND_INVALID")
        reqs = family.get("requirements")
        if not isinstance(reqs, list) or not reqs:
            raise ValueError("BENCHMARK_REQUIREMENTS_INVALID")
        ids, quotes = set(), set()
        for req in reqs:
            if not isinstance(req, dict):
                raise ValueError("BENCHMARK_REQUIREMENT_INVALID")
            rid, quote = req.get("id"), req.get("quote")
            if (not isinstance(rid, str) or not re.fullmatch(r"r[1-9][0-9]*", rid) or rid in ids
                    or not _text(quote) or quote in quotes or not _text(req.get("answer_kind"))):
                raise ValueError("BENCHMARK_REQUIREMENT_INVALID")
            ids.add(rid)
            quotes.add(quote)
        if family.get("critical_requirement_id") not in ids:
            raise ValueError("BENCHMARK_CRITICAL_REQUIREMENT_UNKNOWN")
        context = family.get("context")
        if context is not None and (not isinstance(context, dict)
                or context.get("schema_version") != "sciassistant.benchmark-context/v1"
                or context.get("synthetic") is not True
                or context.get("prior_answer_is_evidence") is not False
                or not _text(context.get("prior_question")) or not _text(context.get("prior_answer"))):
            raise ValueError("BENCHMARK_CONTEXT_INVALID")
    return spec


def build_cases(spec):
    """Position triplets share exactly the same background and requirements."""
    validate_spec(spec)
    cases = []
    for family in spec["families"]:
        reqs = family["requirements"]
        critical = next(r for r in reqs if r["id"] == family["critical_requirement_id"])
        others = [r["quote"] for r in reqs if r is not critical]
        paragraphs = [*spec["common_background"], *family["background"]]
        background = "\n\n".join(paragraphs)
        cut = len(paragraphs) // 2
        parts = {
            "short": [r["quote"] for r in reqs],
            "long_begin": [critical["quote"], background, *others],
            "long_middle": ["\n\n".join(paragraphs[:cut]), critical["quote"],
                            "\n\n".join(paragraphs[cut:]), *others],
            "long_end": [background, *others, critical["quote"]],
        }
        for variant, content in parts.items():
            question = "\n\n".join(content)
            requirements = []
            for req in reqs:
                quote = req["quote"]
                if question.count(quote) != 1:
                    raise ValueError("BENCHMARK_QUOTE_NOT_UNIQUE")
                start = question.index(quote)
                requirements.append({"requirement_id": req["id"], "question_quote": quote,
                    "start": start, "end": start + len(quote), "answer_kind": req["answer_kind"]})
            requirements.sort(key=lambda r: r["start"])
            for index, row in enumerate(requirements, 1):
                row["user_order"] = index
            if variant != "short" and not 2_000 <= len(question) <= 5_000:
                raise ValueError(f"BENCHMARK_LONG_LENGTH_INVALID:{family['id']}:{len(question)}")
            cases.append({"schema_version": SCHEMA, "case_id": f"{family['id']}-{variant}",
                "family": family["id"], "variant": variant,
                "question": question, "question_sha256": sha256(question.encode("utf-8")),
                "question_characters": len(question), "background_characters": len(background),
                "background_sha256": sha256(background.encode("utf-8")),
                "background_is_evidence": False, "source_scope": family["source_scope"],
                "document_fixture": family.get("document_fixture"),
                "public_search_permission_required": family["source_scope"] == "auto",
                "grants_live_permissions": False, "context_fixture": family.get("context"),
                "requirements": requirements, "critical_requirement_id": critical["id"],
                "semantic_auto_approval": False})
    return cases


def benchmark_summary(cases):
    lengths = [r["question_characters"] for r in cases if r["variant"] != "short"]
    return {"schema_version": "sciassistant.full-report-benchmark-summary/v1",
        "case_count": len(cases), "families": sorted({r["family"] for r in cases}),
        "variants": dict(Counter(r["variant"] for r in cases)),
        "long_question_min_characters": min(lengths), "long_question_max_characters": max(lengths),
        "source_scopes": dict(Counter(r["source_scope"] for r in cases)),
        "cases": [{k: r[k] for k in ("case_id", "question_sha256", "question_characters",
            "background_sha256", "critical_requirement_id")}
            | {"requirement_count": len(r["requirements"]), "context_present": r["context_fixture"] is not None}
            for r in cases],
        "model_calls": 0, "network_requests": 0, "live_quality_verified": False}


def _relative_file(root, name):
    # Do not follow a replaced checkout/file to secrets or another repository.
    relative = Path(name)
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError("REFERENCE_PATH_INVALID")
    current = Path(root)
    if current.is_symlink():
        raise ValueError("REFERENCE_LINK_REJECTED")
    for part in relative.parts:
        current /= part
        if current.is_symlink():
            raise ValueError("REFERENCE_LINK_REJECTED")
    if not current.is_file():
        raise ValueError("REFERENCE_FILE_MISSING")
    return current


def _git(checkout, *args):
    result = subprocess.run(["git", "--no-optional-locks", "-c", "core.fsmonitor=false",
        "-C", str(checkout), *args], capture_output=True, text=True, encoding="utf-8",
        timeout=30, check=True)
    return result.stdout.strip()


def check_upstreams(root, pins):
    """Verify existing pinned checkouts, with zero fetch/install/import steps."""
    root = Path(root)
    rows = []
    for pin in pins["repositories"]:
        checkout = root / pin["directory"]
        if checkout.is_symlink() or not checkout.is_dir():
            raise ValueError("REFERENCE_CHECKOUT_INVALID")
        _relative_file(checkout, pin["license_file"])
        actual_sha = _git(checkout, "rev-parse", "HEAD")
        files = []
        for item in [{"path": pin["license_file"], "sha256": pin["license_sha256"]}, *pin["reviewed_files"]]:
            digest = source_sha256(_relative_file(checkout, item["path"]))
            files.append({"path": item["path"], "sha256": digest, "matches": digest == item["sha256"]})
        origin = _git(checkout, "remote", "get-url", "origin")
        clean = not _git(checkout, "status", "--porcelain", "--untracked-files=normal")
        rows.append({"repository": pin["directory"], "commit": actual_sha,
            "commit_matches": actual_sha == pin["commit"], "origin_matches": origin == pin["url"],
            "clean": clean, "files": files, "license": pin["license_spdx"]})
    return {"schema_version": "sciassistant.upstream-verification/v1", "repositories": rows,
        "passed": all(r["commit_matches"] and r["origin_matches"] and r["clean"]
                      and all(f["matches"] for f in r["files"]) for r in rows),
        "network_requests": 0, "model_calls": 0, "upstream_code_executed": False}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("validate", help="check all offline question fixtures")
    case = commands.add_parser("case", help="show one question and its separate gold expectations")
    case.add_argument("--case-id", required=True)
    case.add_argument("--question-only", action="store_true")
    refs = commands.add_parser("upstreams", help="verify already-downloaded pinned repositories")
    refs.add_argument("--root", required=True, type=Path)
    args = parser.parse_args(argv)
    try:
        if args.command == "upstreams":
            output = check_upstreams(args.root, read_json(PINS))
            code = 0 if output["passed"] else 1
        else:
            cases = build_cases(read_json(SPEC))
            if args.command == "validate":
                output, code = benchmark_summary(cases), 0
            else:
                output = next((r for r in cases if r["case_id"] == args.case_id), None)
                if output is None:
                    raise ValueError("BENCHMARK_CASE_UNKNOWN")
                if args.question_only:
                    print(output["question"])
                    return 0
                code = 0
        print(json.dumps(output, ensure_ascii=False, indent=2))
        return code
    except (ValueError, OSError, subprocess.SubprocessError) as exc:
        # No raw supplier response, command environment, or arbitrary file content.
        print(json.dumps({"status": "error", "error_type": type(exc).__name__,
            "error": str(exc) if isinstance(exc, ValueError) else "FOUNDATION_CHECK_FAILED"}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    sys.exit(main())
