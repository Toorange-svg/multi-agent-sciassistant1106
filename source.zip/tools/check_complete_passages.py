"""Zero-call copied-index checks; not a hybrid/live workflow or historical repair."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from multi_agent_agents import ArtifactDirectory
from multi_agent_live import LiveArxivRagExecutor
from multi_agent_quality import ABSENCE_SCOPE_POLICY, check_absence_basis, check_audit, publication_rejections
from multi_agent_rag import EvidenceStore, HybridRetriever


def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def tree(p): return {str(f.relative_to(p)): sha(f) for f in sorted(p.rglob('*')) if f.is_file()}


def artifacts(run):
    store = ArtifactDirectory(run / 'artifacts')
    final = store.get(read(run / 'manifest.json')['final_artifact_id'])
    return store, final


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--local-run', type=Path, required=True)
    parser.add_argument('--public-run', type=Path, required=True)
    parser.add_argument('--public-index', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    local, public, index, output = [p.resolve() for p in (args.local_run, args.public_run, args.public_index, args.output_dir)]
    if output.exists() or any(output.is_relative_to(p) or p.is_relative_to(output) for p in (local, public, index.parent)):
        parser.error('new non-overlapping output required')
    originals = {str(p): tree(p) for p in (local, public)}
    original_index_sha = sha(index)
    output.mkdir(parents=True)
    local_index = local / 'private_rag/evidence.sqlite3'
    local_sha = sha(local_index)
    shutil.copy2(local_index, output / 'local.sqlite3')
    store = EvidenceStore(output / 'local.sqlite3')
    _, final = artifacts(local)
    refs = read(local / 'references.json')
    doc = refs[0]['document_id']
    packets = HybridRetriever(store).search('For h W0x modified forward pass yields frozen LoRA low-rank matrices',
        limit=4, per_document=4, context_budget=4000, document_ids={doc}, representative_document_ids=[doc])
    local_packets = [{'evidence_id': p['evidence_id'], 'page': p['locator']['page'],
                     'text': p['text'], 'retrieval': p['retrieval']} for p in packets]
    shutil.copy2(index, output / 'public.sqlite3')
    public_store, public_final = artifacts(public)
    sources = public_store.get(public_final['artifact_refs']['approved'])
    plan = public_store.get(public_final['artifact_refs']['plan'])
    executor = LiveArxivRagExecutor(output / 'run', output / 'storage', rag_mode='lexical',
        services=HybridRetriever(EvidenceStore(output / 'public.sqlite3')))
    executor.configure_plan(plan)
    executor.group_queries = {g['id']: g['queries'] for g in plan['groups']}
    for row in read(public / 'budget_usage.json')['candidate_reading_decisions']:
        if row.get('reading_status') != 'pdf_indexed': continue
        doc_id = 'arxiv-' + row['paper_id'].replace('.', '-').replace('/', '-')
        metadata = read(index.parent / 'documents' / doc_id / 'metadata.json')
        executor.candidates[executor._paper_key(row['paper_id'])] = {
            **metadata, 'group_ids': row['group_ids'], 'evidence_id': doc_id, 'abstract': ''}
        executor.ingested.add(doc_id)
    public_packets = executor._select_packets()
    draft = public_store.get(public_final['artifact_refs']['draft'])
    audit = public_store.get(public_final['artifact_refs']['audit'])
    prior_blocked = sorted(publication_rejections(audit, draft))
    proposed = deepcopy(draft)
    proposed['absence_scope_policy'] = ABSENCE_SCOPE_POLICY
    # Workflow had copied absence findings into code_issues. For this NEW-policy
    # in-memory diagnosis recompute only those exact findings, preserving all
    # unrelated code faults and the original artifact without writing it back.
    diagnostic_audit = deepcopy(audit)
    old_absence = check_absence_basis(audit, draft)
    diagnostic_audit['code_issues'] = [r for r in audit.get('code_issues', []) if r not in old_absence]
    checked = check_audit(diagnostic_audit, proposed, sources)
    data = {'schema_version': 'sciassistant.complete-passages-probe/v1', 'model_calls': 0, 'network_calls': 0,
        'local': {'source_run': str(local), 'original_reference_ids': [r['evidence_id'] for r in refs], 'packets': local_packets},
        'public': {'source_run': str(public), 'not_full_workflow_replay': True, 'hybrid_not_proved': True,
            'packets': [{'evidence_id': p['evidence_id'], 'paper_id': p['paper_id'], 'group_ids': p['group_ids'],
                        'page': p.get('locator', {}).get('page'), 'text': p.get('excerpt'),
                        'retrieval': p.get('retrieval')} for p in public_packets],
            'old_blocked': prior_blocked, 'current_policy_blocked_diagnosis_only': sorted(publication_rejections(checked, proposed)),
            'recomputed_old_absence_findings': old_absence,
            'current_absence_issues': checked.get('absence_issues'), 'historical_final_not_modified': True},
        'source_run_hashes_unchanged': all(tree(Path(p)) == before for p, before in originals.items()),
        'source_indices_unchanged': sha(index) == original_index_sha and sha(local_index) == local_sha,
        'automatic_evidence_or_scientific_approval': False}
    (output / 'checks.json').write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf8')
    print(json.dumps({'local_formula_pairs': [p['evidence_id'] for p in packets if p['retrieval'].get('continuation')],
        'original_mechanism_pages': [p.get('locator', {}).get('page') for p in public_packets if p['paper_id'] == '1706.03762v7'],
        'old_blocked': prior_blocked, 'current_blocked': data['public']['current_policy_blocked_diagnosis_only'],
        'source_run_hashes_unchanged': data['source_run_hashes_unchanged'],
        'source_indices_unchanged': data['source_indices_unchanged']}, ensure_ascii=True))


if __name__ == '__main__': main()
