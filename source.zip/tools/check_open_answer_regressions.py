"""Read-only diagnostics of the three saved first attempts, never republishes."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from multi_agent_agents import ArtifactDirectory
from multi_agent_pipeline_v2 import check_draft, actionable_review_gaps, select_recovery_targets
from multi_agent_quality import ABSENCE_SCOPE_POLICY, FIELD_QUANTITY_POLICY, check_absence_basis
from tools.check_premise_artifacts import read, tree


def probe(run):
    before = tree(run)
    store = ArtifactDirectory(run / 'artifacts')
    final = store.get(read(run / 'manifest.json')['final_artifact_id'])
    refs = final['artifact_refs']
    draft, audit, approved = (store.get(refs[key]) for key in ('draft', 'audit', 'approved'))
    plan, review = (store.get(refs[key]) for key in ('plan', 'review'))
    candidate = {**deepcopy(draft), 'absence_scope_policy': ABSENCE_SCOPE_POLICY,
                 'field_quantity_policy': FIELD_QUANTITY_POLICY}
    selected = select_recovery_targets(actionable_review_gaps(review, include_qualified=True), review, plan)
    def issues(value):
        return {'numbers': [{'claim_id': r['claim_id'], 'reason': r['reason'], 'field_errors': r.get('field_errors', [])}
                            for r in check_draft(value, approved) if r['reason'] == 'UNSUPPORTED_NUMBER'],
                'scope': [{'claim_id': r['claim_id'], 'field': r['field']}
                          for r in check_absence_basis(audit, value)]}
    return {'run_id': read(run / 'manifest.json')['run_id'], 'recorded_status': final['status'],
            'recorded_policy': issues(draft), 'candidate_policy': issues(candidate),
            'recorded_gap_targets': store.get(refs['gap_targets'])['targets'],
            'candidate_next_targets': [{k: r[k] for k in ('gap_id', 'group_id', 'metric') if k in r} for r in selected],
            'next_targets_based_on_final_review_not_initial_ticket': True,
            'source_hashes_unchanged': before == tree(run), 'automatic_publication': False,
            'semantic_support_verified': False, 'model_calls_added': 0, 'network_calls_added': 0}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-dir', type=Path, action='append', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    roots = [p.resolve() for p in args.run_dir]
    if (output.exists() or not output.is_relative_to(ROOT / 'logs')
            or any(not p.is_dir() or not p.is_relative_to(ROOT / 'logs') or output.is_relative_to(p) for p in roots)):
        parser.error('existing logs sources and new logs output outside them required')
    result = {'runs': [probe(root) for root in roots]}
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('x', encoding='utf8') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
    print(json.dumps(result, ensure_ascii=False))
    return 0 if all(r['source_hashes_unchanged'] for r in result['runs']) else 1


if __name__ == '__main__':
    raise SystemExit(main())
