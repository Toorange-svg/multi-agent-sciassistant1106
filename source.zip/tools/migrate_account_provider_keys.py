"""Move existing shared provider keys to one verified username, never print keys.

Local maintenance only. Saves encrypted credentials before retiring exact shared
dotenv fields. No account password/JWT is read, no other user row is updated.
"""
import argparse
import json
import os
from pathlib import Path
import re
import sys
import uuid

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dotenv import dotenv_values
import pymysql
from user_credentials import CredentialStore, FIELDS, split_keys


def retire_file(path):
    if not path.is_file():
        return 0
    if path.is_symlink() or path.stat().st_size > 1_000_000:
        raise ValueError('SHARED_CONFIG_INVALID')
    text = path.read_text(encoding='utf-8-sig')
    pattern = re.compile(r'^\s*(?:export\s+)?(' + '|'.join(FIELDS) + r')\s*=')
    lines = text.splitlines(keepends=True)
    kept = [line for line in lines if not pattern.match(line)]
    removed = len(lines) - len(kept)
    if removed:
        temporary = path.with_name('.' + path.name + '-' + uuid.uuid4().hex + '.tmp')
        try:
            with temporary.open('x', encoding='utf-8') as output:
                output.write(''.join(kept)); output.flush(); os.fsync(output.fileno())
            os.chmod(temporary, 0o600)
            os.replace(temporary, path)
        finally:
            temporary.unlink(missing_ok=True)
    return removed


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--username', required=True)
    parser.add_argument('--apply', action='store_true')
    parser.add_argument('--retire-shared', action='store_true')
    args = parser.parse_args(argv)
    files = [ROOT / 'deepdiver_v2/config/.env', ROOT / '.env']
    values = {**dotenv_values(files[0]), **dotenv_values(files[1]), **os.environ}
    conn = pymysql.connect(host=values.get('MYSQL_HOST', 'localhost'), user=values.get('MYSQL_USER', 'root'),
        password=values.get('MYSQL_PASSWORD', ''), database=values.get('MYSQL_DATABASE', 'chatai'),
        cursorclass=pymysql.cursors.DictCursor)
    try:
        with conn.cursor() as cursor:
            cursor.execute('SELECT id,username FROM users WHERE username=%s', (args.username,))
            owners = cursor.fetchall()
        if len(owners) != 1 or owners[0]['username'] != args.username:
            raise ValueError('EXACT_USERNAME_REQUIRED')
        owner = str(owners[0]['id'])
    finally:
        conn.close()
    keys = list(dict.fromkeys(split_keys(values.get('MODEL_REQUEST_TOKEN', '')) + split_keys(values.get('MODEL_REQUEST_TOKENS', ''))))
    llama = str(values.get('LLAMA_CLOUD_API_KEY') or '')
    embedding = str(values.get('EMBEDDING_API_KEY') or '')
    body = {}
    if keys: body['deepseek_keys'] = keys
    if llama: body['llama_key'] = llama
    if embedding: body['embedding_key'] = embedding
    store = CredentialStore(values.get('SCIASSISTANT_USER_CREDENTIAL_DB', ROOT / 'logs/user_credentials.sqlite3'),
                            values.get('USER_CREDENTIAL_ENCRYPTION_KEY') or values.get('SECRET_KEY'))
    before = store.status(store.capability(owner))
    result = {'schema_version': 'sciassistant.credential-migration/v1', 'owner_id': owner,
              'username': args.username, 'apply': args.apply, 'source_deepseek_count': len(keys),
              'source_llama_present': bool(llama), 'source_embedding_present': bool(embedding),
              'before': before, 'shared_fields_removed': 0}
    if args.apply and body:
        result['after'] = store.update(owner, body, only_if_empty=True)
        verified = store.capability(owner)
        if (keys and set(split_keys(verified.values['MODEL_REQUEST_TOKENS']) + split_keys(verified.values['MODEL_REQUEST_TOKEN'])) != set(keys)) or (llama and verified.values['LLAMA_CLOUD_API_KEY'] != llama):
            raise ValueError('MIGRATION_VERIFICATION_FAILED')
        if embedding and verified.values['EMBEDDING_API_KEY'] != embedding:
            raise ValueError('MIGRATION_VERIFICATION_FAILED')
        if args.retire_shared:
            result['shared_fields_removed'] = sum(retire_file(path) for path in files)
    elif args.apply:
        result['after'] = before
        result['no_shared_keys_to_migrate'] = True
    print(json.dumps(result))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(json.dumps({'error': 'CREDENTIAL_MIGRATION_FAILED', 'category': type(exc).__name__}))
        raise SystemExit(1)
