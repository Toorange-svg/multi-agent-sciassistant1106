"""Fail-closed CPU model and protected Qdrant preflight. Never calls answer models."""
from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path
import sys
import time
import tempfile
from urllib.parse import urlsplit

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def configuration():
    model = Path(os.getenv("SCIASSISTANT_EMBEDDING_MODEL", ""))
    if not model.is_absolute() or not model.is_dir() or not (model / "modules.json").is_file():
        raise ValueError("LOCAL_MODEL_NOT_READY")
    url = os.getenv("SCIASSISTANT_QDRANT_URL", "")
    parsed = urlsplit(url)
    key = os.getenv("SCIASSISTANT_QDRANT_API_KEY", "")
    if (len(key) < 32 or len(set(key)) < 8 or key.lower().startswith(("change-me", "example", "placeholder"))
            or parsed.username or parsed.password or parsed.query or parsed.fragment
            or parsed.path not in {"", "/"}
            or not (parsed.scheme == "https" and parsed.hostname
                    or parsed.scheme == "http" and parsed.hostname == "qdrant" and parsed.port == 6333)):
        raise ValueError("PROTECTED_VECTOR_CONFIGURATION_REQUIRED")
    return model, url, key


def preflight(*, provider_factory=None, client_factory=None, sleep=time.sleep):
    model, url, key = configuration()
    # Test the effective non-root volume permissions, not os.access or mere
    # directory existence. Temporary probes contain no document or credential.
    for variable, default in (
        ("SCIASSISTANT_MULTI_AGENT_WEB_RUN_ROOT", "logs/multi_agent_web_runs"),
        ("SCIASSISTANT_MULTI_AGENT_WEB_STORAGE_ROOT", "logs/multi_agent_web_rag"),
        ("SCIASSISTANT_MULTI_AGENT_VECTOR_LOCK_ROOT", "logs/rag_vector_locks"),
    ):
        root = Path(os.getenv(variable, str(Path(__file__).resolve().parents[1] / default)))
        root.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryFile(dir=root) as probe:
            probe.write(b"storage preflight")
            probe.flush()
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    os.environ["SCIASSISTANT_EMBEDDING_ALLOW_DOWNLOAD"] = "0"
    if provider_factory is None:
        from multi_agent_rag import LocalSentenceTransformerEmbedding
        provider_factory = LocalSentenceTransformerEmbedding
    if client_factory is None:
        from qdrant_client import QdrantClient
        client_factory = QdrantClient
    embedding = provider_factory(str(model))
    vectors = embedding.embed(["CPU embedding preflight"])
    if embedding.dimension != 384 or len(vectors) != 1 or len(vectors[0]) != 384 or not all(math.isfinite(value) for value in vectors[0]):
        raise ValueError("MODEL_DIMENSION_OR_VECTOR_INVALID")
    # Bounded startup-only wait. Runtime requests retain their separate deadline.
    for attempt in range(8):
        client = None
        try:
            client = client_factory(url=url, api_key=key, timeout=3, check_compatibility=False)
            collections = client.get_collections()
            collection = os.getenv("SCIASSISTANT_QDRANT_COLLECTION", "sciassistant_evidence")
            if any(item.name == collection for item in getattr(collections, "collections", [])):
                info = client.get_collection(collection)
                if getattr(info.config.params.vectors, "size", None) != embedding.dimension:
                    raise ValueError("VECTOR_COLLECTION_DIMENSION_INVALID")
            return {"schema": "sciassistant.rag-startup/v1", "passed": True,
                    "dimension": 384, "qdrant_authenticated": True, "answer_model_calls": 0,
                    "network_attempts": attempt + 1, "storage_writable": True}
        except ValueError:
            raise
        except Exception:
            if attempt == 7:
                raise RuntimeError("VECTOR_SERVICE_UNAVAILABLE") from None
            sleep(2)
        finally:
            if client is not None:
                try:
                    client.close()
                except Exception:
                    pass


def main():
    argparse.ArgumentParser(description=__doc__).parse_args()
    try:
        result = preflight()
        print(json.dumps(result))
        return 0
    except Exception:
        # No provider body, API key, model path, endpoint or traceback.
        print(json.dumps({"schema": "sciassistant.rag-startup/v1", "passed": False,
                          "error": "RAG_STARTUP_NOT_READY"}))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
