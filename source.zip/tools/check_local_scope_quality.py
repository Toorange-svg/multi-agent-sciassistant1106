"""Zero-model, zero-network diagnosis; never publish or rewrite historical runs."""
from copy import deepcopy
from pathlib import Path
import argparse
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from multi_agent_agents import ArtifactDirectory
from multi_agent_quality import (ABSENCE_SCOPE_POLICY, PREVIOUS_ABSENCE_SCOPE_POLICY, check_absence_basis,
                                 check_condition_denials)


def hashes(root):
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in root.rglob('*') if p.is_file()}


def inspect(run):
    before = hashes(run)
    manifest = json.loads((run / 'manifest.json').read_text(encoding='utf8'))
    store = ArtifactDirectory(run / 'artifacts')
    final = store.get(manifest['final_artifact_id'])
    refs = final['artifact_refs']
    approved = store.get(refs['approved'])
    pairs = [(refs['draft'], store.get(refs['audit']), 'final')]
    events = [json.loads(line) for line in (run / 'events.jsonl').read_text(encoding='utf8').splitlines()]
    if refs.get('citation_feedback'):
        feedback = store.get(refs['citation_feedback'])
        event = next(row for row in events if row.get('event') == 'agent_started'
                     and row.get('role') == 'citation_auditor')
        draft_id = next(key for key in event['input_artifact_ids'] if key.startswith('draft-answer-'))
        pairs.append((draft_id, feedback['model_audit'], 'before_writer_revision'))
    # Normalized publication audits can have invalid local records isolated.
    # Inspect the immutable raw role output too; otherwise an original false
    # rejection such as "these passages" disappears from this diagnosis.
    pending = None
    unavailable_raw_outputs = []
    for event in events:
        if event.get('role') != 'citation_auditor':
            continue
        if event.get('event') == 'agent_started':
            pending = event
        elif event.get('event') == 'agent_finished' and pending:
            draft_id = next((key for key in pending['input_artifact_ids']
                             if key.startswith('draft-answer-')), None)
            for key in event.get('output_artifact_ids', []):
                if not key.startswith('citation_auditor-output-') or not draft_id:
                    continue
                if not (run / 'artifacts' / (key + '.json')).is_file():
                    unavailable_raw_outputs.append(key)
                    continue
                pairs.append((draft_id, store.get(key),
                              'raw_auditor_call_' + str(pending['call_number'])))
            pending = None
    rows = []
    drafts = {p.stem: store.get(p.stem) for p in (run / 'artifacts').glob('draft-answer-*.json')}
    for draft_id, audit, phase in pairs:
        draft = store.get(draft_id)
        proposed = {**deepcopy(draft), 'absence_scope_policy': ABSENCE_SCOPE_POLICY}
        fields = {claim['claim_id']: claim for claim in draft.get('claims', [])}
        stale = []
        for claim in audit.get('claim_results') or []:
            for field, verdict in (claim.get('field_results') or {}).items():
                for check in verdict.get('absence_checks') or []:
                    assertion = check.get('assertion')
                    current = fields.get(claim['claim_id'], {}).get(field) or ''
                    if not isinstance(assertion, str) or assertion in current:
                        continue
                    old_ids = [key for key, old in drafts.items() if key != draft_id and any(
                        item['claim_id'] == claim['claim_id'] and assertion in (item.get(field) or '')
                        for item in old.get('claims', []))]
                    stale.append({'claim_id':claim['claim_id'], 'field':field, 'assertion':assertion,
                        'not_in_current_field':True, 'matching_prior_draft_ids':old_ids})
        rows.append({'phase': phase, 'draft_id': draft_id,
            'historical_absence_scope_policy': draft.get('absence_scope_policy'),
            'original_policy_absence_issues': check_absence_basis(audit, draft),
            'v3_diagnostic_absence_issues': check_absence_basis(audit, {**proposed, 'absence_scope_policy':PREVIOUS_ABSENCE_SCOPE_POLICY}),
            'current_diagnostic_absence_scope_policy': ABSENCE_SCOPE_POLICY,
            'current_diagnostic_absence_issues': check_absence_basis(audit, proposed),
            'explicit_condition_diagnosis': check_condition_denials(draft, approved),
            'out_of_current_field_assertions': stale})
    return {'run_id': manifest['run_id'], 'historical_status': final['status'],
        'source_fingerprint': manifest.get('source_fingerprint'), 'checks': rows,
        'unavailable_raw_outputs': unavailable_raw_outputs,
        'source_files': len(before), 'source_hashes_unchanged': before == hashes(run),
        'historical_publication_rewritten': False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run-dir', type=Path, nargs='+', required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    runs, output = [p.resolve() for p in args.run_dir], args.output_dir.resolve()
    if any(not p.is_dir() or output.is_relative_to(p) or p.is_relative_to(output) for p in runs):
        parser.error('output overlaps source or run missing')
    output.mkdir(parents=True, exist_ok=False)
    value = {'schema_version':'sciassistant.local-scope-diagnosis/v1', 'runs':[inspect(p) for p in runs],
        'model_calls':0, 'network_requests':0, 'automatic_scientific_approval':False}
    (output / 'checks.json').write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf8')
    print(json.dumps({'runs':len(runs), 'source_hashes_unchanged':all(r['source_hashes_unchanged'] for r in value['runs']),
        'output':'checks.json', 'model_calls':0, 'network_requests':0}))
    return 0 if all(r['source_hashes_unchanged'] for r in value['runs']) else 1


if __name__ == '__main__':
    raise SystemExit(main())
