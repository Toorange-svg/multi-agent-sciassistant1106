"""Read-only current input/format-feedback probe; never rejudge old science."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from multi_agent_agents import ArtifactDirectory
from multi_agent_quality import (SCIENTIFIC_REVIEW_FRAME_POLICY, citation_audit_input,
                                audit_correction_brief, check_audit, check_absence_basis, ABSENCE_SCOPE_POLICY)
from tools.check_open_answer_regressions import tree, read


def probe(run):
    before = tree(run)
    store = ArtifactDirectory(run/'artifacts')
    manifest = read(run/'manifest.json')
    final = store.get(manifest['final_artifact_id'])
    refs = final['artifact_refs']
    draft, evidence = (store.get(refs[k]) for k in ('draft', 'approved'))
    candidate = {**deepcopy(draft), 'scientific_review_frame_policy': SCIENTIFIC_REVIEW_FRAME_POLICY}
    validation = store.get(refs['audit_validation']) if refs.get('audit_validation') else {'reason_codes': []}
    first_raw = store.get(validation['input_audit_artifact_id']) if validation.get('input_audit_artifact_id') else store.get(refs['audit'])
    checked = check_audit(first_raw, candidate, evidence)
    packet = citation_audit_input(candidate, evidence)
    brief = audit_correction_brief(candidate, checked)
    final_audit = store.get(refs['audit'])
    scope_candidate = {**candidate, 'absence_scope_policy': ABSENCE_SCOPE_POLICY}
    return {'run_id': manifest['run_id'], 'recorded_status': final['status'],
        'frames': [{'claim_id': r['claim_id'], 'claim_type': r.get('claim_type'),
                    'frame': r['scientific_review_frame']} for r in packet['claims']],
        'first_error_codes': validation['reason_codes'], 'current_field_correction_brief': brief,
        'recorded_scope_issues': check_absence_basis(final_audit, draft),
        'candidate_scope_issues': check_absence_basis(final_audit, scope_candidate),
        'source_hashes_unchanged': before == tree(run), 'model_calls_added': 0,
        'network_calls_added': 0, 'automatic_publication': False, 'semantic_support_verified': False}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-dir', type=Path, action='append', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    roots, output = [p.resolve() for p in args.run_dir], args.output.resolve()
    if (output.exists() or not output.is_relative_to(ROOT/'logs')
            or any(not p.is_dir() or not p.is_relative_to(ROOT/'logs') or output.is_relative_to(p) for p in roots)):
        parser.error('existing logs sources and new output outside source runs required')
    result = {'runs': [probe(p) for p in roots]}
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('x', encoding='utf8') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
    print(json.dumps({'runs': [{'run_id': r['run_id'], 'frames': len(r['frames']),
        'correction_rows': len(r['current_field_correction_brief']['claims']),
        'source_hashes_unchanged': r['source_hashes_unchanged']} for r in result['runs']]}, ensure_ascii=False))
    raise SystemExit(0 if all(r['source_hashes_unchanged'] for r in result['runs']) else 1)
