# -*- coding: utf-8 -*-
import json, pathlib, re, collections
ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / "logs" / "multidomain_eval_20260920_192106.jsonl"
LOGS = ROOT / "logs"

lines = SRC.read_text(encoding="utf-8").splitlines()
reasons = collections.Counter()
src_ret = collections.Counter()  # 各源是否有返回
gate_zero = 0
gate_pos = 0
total = 0
arxiv_no = 0
hal_only = 0
cand_buckets = collections.Counter()

def final_answer(fp):
    t = fp.read_text(encoding="utf-8", errors="ignore")
    m = re.search(r"Final Answer:\n(.*?)(?:\n\n|\Z)", t, re.S)
    return m.group(1).strip() if m else ""

for line in lines:
    o = json.loads(line)
    for r in o["rounds"]:
        if not (r["degraded"] and r["answer_chars"] < 600):
            continue
        total += 1
        fp = LOGS / f"web_task_{r['task_id']}.txt"
        if not fp.exists():
            continue
        ans = final_answer(fp)
        m = re.search(r"被拒候选的主要类型：([^\n]+)", ans)
        if m:
            for part in m.group(1).split("、"):
                reasons[re.sub(r"（.*?）", "", part).strip()] += 1
        g = re.search(r"(\d+) 篇候选文献，其中 (\d+) 篇通过相关性门控.*可用 (\d+) 篇", ans)
        if g:
            cand, gate, avail = map(int, g.groups())
            cand_buckets[f"{cand}候选/{gate}过门/{avail}可用"] += 1
            if avail == 0 and gate > 0: gate_zero += 1
            if avail > 0: gate_pos += 1
        # 各源
        for src in ["arxiv", "zenodo", "hal", "techrxiv"]:
            mm = re.search(rf"{src}：([^\n]+)", ans)
            if mm:
                line_s = mm.group(1)
                if "返回" in line_s and "篇候选" in line_s:
                    src_ret[f"{src}_有返回"] += 1
                elif "未返回" in line_s and "不可用" in line_s or "DNS" in line_s:
                    src_ret[f"{src}_DNS禁用"] += 1
                elif "已停用" in line_s:
                    src_ret[f"{src}_停用"] += 1
                else:
                    src_ret[f"{src}_未返回"] += 1

print(f"总降级轮: {total}")
print(f"\n门控过但账本0篇: {gate_zero}   账本有可用: {gate_pos}")
print("\n-- 拒绝原因分布 --")
for k,v in reasons.most_common(): print(f"  {v:3d}  {k}")
print("\n-- 各源状态(跨降级轮) --")
for k,v in src_ret.most_common(): print(f"  {v:3d}  {k}")
print("\n-- 候选/门控/可用 漏斗 --")
for k,v in sorted(cand_buckets.items(), key=lambda x:-x[1]): print(f"  {v:3d}  {k}")
