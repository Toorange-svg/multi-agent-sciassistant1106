"""Fresh isolated gateway; real MySQL and HTTP, mock models by default.

Only validation-scoped account rows are created via normal registration. All
files, owners, bindings, Workflow runs and key-pool state live under --state.
Never bind 5000, restart production, or expose mock execution on production API.
"""
import argparse
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def configure_state(state, model_mode):
    state = Path(state).resolve()
    allowed = (ROOT / 'logs' / 'research_web_validation').resolve()
    if state.is_symlink() or not state.is_relative_to(allowed) or state == allowed:
        raise ValueError('validation state must be a specific child of the validation root')
    state.mkdir(parents=True, exist_ok=True)
    for name, child in {
        'SCIASSISTANT_TASK_STATE_DIR': 'tasks', 'SCIASSISTANT_TASK_OWNER_STATE_PATH': 'owners.json',
        'SCIASSISTANT_CONTEXT_FILE_OWNER_STATE_PATH': 'context-owners.json',
        'SCIASSISTANT_PDF_SESSION_STATE_PATH': 'bindings.sqlite3',
        'SCIASSISTANT_RESEARCH_LIBRARY_STATE_PATH': 'library.sqlite3',
        'SCIASSISTANT_MULTI_AGENT_WEB_RUN_ROOT': 'runs',
        'SCIASSISTANT_MULTI_AGENT_WEB_STORAGE_ROOT': 'rag',
        'MODEL_KEY_POOL_STATE_PATH': 'keys.sqlite3',
        'SCIASSISTANT_USER_CREDENTIAL_DB': 'provider-keys.sqlite3',
        'SCIASSISTANT_USER_RUNTIME_ROOT': 'user-runtime',
    }.items():
        os.environ[name] = str(state / child)
    os.environ['SCIASSISTANT_WEB_BASE'] = ''
    os.environ['SCIASSISTANT_EMBEDDING_ALLOW_DOWNLOAD'] = '0'
    os.environ['OMP_NUM_THREADS'] = '1'
    os.environ['TOKENIZERS_PARALLELISM'] = 'false'
    key = os.environ.get('SCIASSISTANT_VALIDATION_SIGNING_KEY', '')
    if len(key) < 40:
        raise ValueError('parent must provide an in-memory validation signing key')
    os.environ['SECRET_KEY'] = key
    # Do not let pytest/test exemptions weaken a real validation instance.
    os.environ['APP_ENV'] = 'production'
    import app as gateway
    import web_app as web
    gateway.UPLOAD_BASE_DIR = state / 'originals'; gateway.UPLOAD_BASE_DIR.mkdir(exist_ok=True)
    web.UPLOAD_DIR = state / 'uploads'; web.UPLOAD_DIR.mkdir(exist_ok=True)
    web.LOG_DIR = state / 'worker-logs'; web.LOG_DIR.mkdir(exist_ok=True)
    gateway._LOCAL_SCIENCE_APP = web.app
    original_missing = web._missing_task_configuration
    if model_mode == 'mock':
        original_worker = web._run_multi_agent_rag_task
        def worker(task_id, query, **kwargs):
            kwargs['mode'] = 'mock'
            return original_worker(task_id, query, **kwargs)
        web._run_multi_agent_rag_task = worker
        # Mock models don't require provider credentials; other readiness and
        # actual parser/index/schema checks remain the production paths.
        web._missing_task_configuration = lambda _mode: []
    if os.getenv('SCIASSISTANT_TENANT_PROBE') == '1':
        from tools.tenant_provider_fixture import install
        web._missing_task_configuration = original_missing
        gateway._tenant_probe_server = install(gateway, web, key)
    return gateway.app, state


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--state', type=Path, required=True)
    parser.add_argument('--model-mode', choices=('mock', 'live'), default='mock')
    parser.add_argument('--port', type=int, default=0)
    args = parser.parse_args()
    if args.port == 5000 or not 0 <= args.port <= 65535:
        parser.error('never bind the production port')
    try:
        app, state = configure_state(args.state, args.model_mode)
        from werkzeug.serving import make_server
        from runtime_identity import source_fingerprint
        server = make_server('127.0.0.1', args.port, app, threaded=True)
        (state / 'ready.json').write_text(json.dumps({'port': server.server_port,
            'model_mode': args.model_mode, 'source_fingerprint': source_fingerprint()[0],
            'scope': 'fresh isolated gateway; real MySQL; separate storage'}), encoding='utf8')
        server.serve_forever()
    except Exception as exc:
        print(json.dumps({'error': 'VALIDATION_SERVER_FAILED', 'type': type(exc).__name__}))
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
