"""Read-only quality funnel and per-paper evidence notes; no model/network calls.

This reports observable quantities, not an automatic scientific quality score.
Historical snapshots were context-capped, so their candidate counts are explicitly
lower bounds unless a complete pre-cap search catalog is available.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import re
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from multi_agent_agents import ArtifactDirectory, AgentContractError, sanitize_artifact_text
from multi_agent_pipeline_v2 import check_draft
from multi_agent_quality import claim_scope, publication_rejections, check_memory_component_scope, check_metric_direction
from multi_agent_report import read_run_manifest
from multi_agent_report import _official_link
from multi_agent_workflow import WorkflowError
from tools.multi_agent_cli import inspection_store


def read_json(path: Path):
    if path.is_symlink() or not path.is_file() or path.stat().st_size > 1_000_000:
        raise ValueError("quality input unavailable")
    return json.loads(path.read_text(encoding="utf-8-sig"))


def paper_key(paper_id: str) -> str:
    """Count a revised paper once, without merging its actual evidence records."""
    return re.sub(r"v[1-9]\d*$", "", paper_id)


def reviewed_groups(row):
    """Approved semantic associations win; retrieval groups remain provenance."""
    value = row.get("reviewed_group_ids") if "reviewed_group_ids" in row else row.get("group_ids") or [row.get("group_id")]
    return [key for key in (value or []) if isinstance(key, str) and key]


def pdf_problem(row):
    status = str(row.get("source_status") or "")
    return status.startswith("pdf_") and (status.endswith("_failed") or status.endswith("_skipped"))


def evidence_preview(text: str, limit: int) -> str:
    """Prefer a reported quantity or paragraph over repeated PDF page headers."""
    if limit <= 2:
        return ""
    compact = " ".join(text.split())
    number = re.search(r"\d+(?:\.\d+)?\s*(?:%|×|[xX](?![a-z]))", compact)
    if number:
        start = max(0, number.start() - 20)
    else:
        paragraph = next((p for p in re.split(r"\n\s*\n", text) if len(p.strip()) > 180), text)
        compact, start = " ".join(paragraph.split()), 0
    return ("…" if start else "") + compact[start:start + limit - 2] + "…"


def inspect_run(run_dir: str | Path) -> dict:
    run_dir = Path(run_dir).resolve()
    manifest = read_json(run_dir / "manifest.json")
    if not (run_dir / "artifacts").is_dir() or (run_dir / "artifacts").is_symlink():
        raise ValueError("quality artifacts unavailable")
    artifacts = ArtifactDirectory(run_dir / "artifacts")
    final = artifacts.get(manifest["final_artifact_id"])
    refs = final.get("artifact_refs") or {}
    plan = artifacts.get(refs["plan"]) if refs.get("plan") else {}
    approved_set = artifacts.get(refs["approved"]) if refs.get("approved") else {}
    approved = [row for row in approved_set.get("evidence") or [] if row.get("review_status") == "approved"]
    review = artifacts.get(refs["review"]) if refs.get("review") else {}
    draft = artifacts.get(refs["draft"]) if refs.get("draft") else {}
    audit = artifacts.get(refs["audit"]) if refs.get("audit") else {}
    rejected = publication_rejections(audit, draft)
    allowed = {row["evidence_id"] for row in approved}
    claims = [row for row in draft.get("claims") or [] if row.get("claim_id") not in rejected
              and "draft" not in rejected and row.get("evidence_ids")
              and set(row["evidence_ids"]).issubset(allowed)]
    if audit.get("status") not in {"passed", "completed"} and not rejected:
        claims = []
    # Count references that appear in the actual answer, not the entire ledger.
    markers = {int(n) for n in re.findall(r"\[(\d+)\]", final.get("direct_answer") or "")}
    cited = [row for index, row in enumerate(approved, 1) if index in markers]
    candidates, query_rows, pdf_rows = {}, {}, {}

    def add_candidate(row, groups=()):
        key = row.get("paper_id")
        if not key:
            return
        item = candidates.setdefault(key, {"paper_id": key, "title": row.get("title", ""),
                                          "abstract": "", "group_ids": []})
        if row.get("abstract"):
            item["abstract"] = row["abstract"]
        elif not row.get("coverage_scope") or row.get("coverage_scope") == "abstract":
            item["abstract"] = row.get("excerpt", "")
        item["group_ids"] = sorted(set(item["group_ids"]) | set(groups))

    # Snapshots are cumulative. Deduplicate events; never sum cumulative lengths.
    for path in sorted((run_dir / "artifacts").glob("evidence-set-*.json")):
        packet = artifacts.get(path.stem)
        recovery = bool(packet.get("recovery"))
        for row in packet.get("evidence") or []:
            add_candidate(row, row.get("group_ids") or [row.get("group_id")])
        for row in packet.get("observations") or []:
            if row.get("request_id"):
                query_rows[(recovery, row["request_id"], row.get("query"))] = row
            elif str(row.get("source_status", "")).startswith("pdf_"):
                key = (row.get("source", "arxiv"), row.get("group_id"), row.get("document_id"), row.get("source_status"))
                pdf_rows[key] = row
    # Merged snapshots may no longer carry recovery flags. Use unique action IDs
    # + query rather than counting an initial event again inside a recovery set.
    queries = {(row["request_id"], row.get("query")): row for row in query_rows.values()}
    queries = list(queries.values())
    event_path = run_dir / "events.jsonl"
    events = []
    if event_path.exists():
        if event_path.is_symlink() or event_path.stat().st_size > 1_000_000:
            raise ValueError("invalid quality events")
        events = [json.loads(line) for line in event_path.read_text(encoding="utf-8").splitlines()]
        # Final RAG progress can emit the last query again. Deduplicate within
        # a Retriever invocation, but preserve real repeats in its recovery call.
        invocation, event_queries = 0, {}
        for row in events:
            if row.get("event") == "agent_started" and row.get("role") == "retriever":
                invocation += 1
            if row.get("event") == "retrieval_query" and row.get("request_id"):
                event_queries.setdefault((invocation, row["request_id"], row.get("query")), row)
        queries = list(event_queries.values())
    catalog_path = run_dir / "tools" / "search_catalog.jsonl"
    catalog = []
    if catalog_path.exists():
        if catalog_path.is_symlink() or catalog_path.stat().st_size > 1_000_000:
            raise ValueError("invalid search catalog")
        for line in catalog_path.read_text(encoding="utf-8").splitlines():
            row = json.loads(line)
            if row.get("schema_version") != "sciassistant.search-catalog/v1":
                raise ValueError("unknown search catalog version")
            catalog.append(row)
    public_queries = [row for row in queries if row.get("source", "arxiv") == "arxiv"]
    expected = Counter((row.get("query"), row.get("source_status")) for row in public_queries
                       if row.get("source_status") != "deadline_skipped")
    observed = Counter((row.get("query"), row.get("source_status")) for row in catalog)
    complete_catalog = catalog_path.exists() and bool(public_queries) and expected == observed
    for row in catalog:
        groups = {q["group_id"] for q in public_queries if q.get("query") == row.get("query")}
        for paper in row.get("papers") or []:
            add_candidate(paper, groups)
    for row in approved:
        add_candidate(row, row.get("group_ids") or [row.get("group_id")])
    groups = []
    for group in plan.get("groups") or []:
        group_id = group["id"]
        in_group = lambda row: group_id in reviewed_groups(row)
        evidence = [row for row in approved if in_group(row)]
        group_cited = [row for row in cited if in_group(row)]
        groups.append({"group_id": group_id, "question": group.get("question"),
                       "candidate_papers_observed": len({paper_key(row["paper_id"]) for row in candidates.values()
                           if group_id in (row.get("group_ids") or [row.get("group_id")])}),
                       "approved_packets": len(evidence),
                       "approved_papers": len({paper_key(row["paper_id"]) for row in evidence}),
                       "cited_papers": len({paper_key(row["paper_id"]) for row in group_cited}),
                       "coverage": [row for row in review.get("coverage") or [] if row.get("group_id") == group_id]})
    db = run_dir / "workflow.sqlite3"
    if db.is_symlink() or not db.is_file():
        raise ValueError("workflow state unavailable")
    with inspection_store(run_dir) as store:
        runtime = store.get_run(manifest["run_id"])
    notes = []
    from multi_agent_evidence import evidence_strength
    for key in sorted({paper_key(row["paper_id"]) for row in approved}):
        evidence = [row for row in approved if paper_key(row["paper_id"]) == key]
        ids = {row["evidence_id"] for row in evidence}
        excerpt_budget = 240
        previews = []
        for r in evidence:
            preview = evidence_preview(str(r.get("excerpt") or ""), min(60, excerpt_budget))
            excerpt_budget -= len(preview)
            previews.append({"evidence_id": r["evidence_id"], "page": (r.get("locator") or {}).get("page"),
                             "evidence_strength": evidence_strength(r),
                             "section": (r.get("locator") or {}).get("section"),
                             "table_id": (r.get("locator") or {}).get("table_id"),
                             "figure_id": (r.get("locator") or {}).get("figure_id"),
                             "bbox_available": bool((r.get("locator") or {}).get("bbox")),
                             "excerpt": preview})
        source = evidence[0].get("source", "arxiv")
        notes.append({"paper_id": key, "versions": sorted({row["paper_id"] for row in evidence}),
                      "title": evidence[0]["title"], "source": source,
                      "official_url": "" if source == "uploaded_pdf" else _official_link(evidence[0]),
                      "reading_scope": "abstract_only" if all(evidence_strength(r) == "abstract_only" for r in evidence)
                          else "selected_chunks" if any(r.get("coverage_scope") == "selected_chunks" for r in evidence) else "legacy_unclassified",
                      "group_ids": sorted({g for r in evidence for g in reviewed_groups(r)}),
                      "retrieval_group_ids": sorted({g for r in evidence for g in
                          (r.get("group_ids") or [r.get("group_id")]) if isinstance(g, str) and g}),
                      "evidence": previews,
                      "research_questions": [g.get("question") for g in plan.get("groups", [])
                                             if any(g.get("id") in reviewed_groups(r) for r in evidence)],
                      "metric_findings": [{"metric": r.get("metric"), "status": r.get("status")}
                                          for r in review.get("coverage", []) if ids.intersection(r.get("evidence_ids", []))],
                      "linked_claims": [{**r, "visible_scope": claim_scope(draft, r)} for r in claims if ids.intersection(r["evidence_ids"])]})
    processing = list(pdf_rows.values())
    processing_ms = {key: sum(r.get(key, 0) for r in processing) for key in ("download_ms", "parse_ms", "index_ms")}
    for row in processing:
        if row.get("source") == "uploaded_pdf" and row.get("source_status") in {"pdf_parse_completed", "pdf_index_completed"}:
            key = "parse_ms" if row["source_status"] == "pdf_parse_completed" else "index_ms"
            processing_ms[key] += row.get("elapsed_ms", 0)
    recovery_events = [{key: row[key] for key in ("event", "stage", "reason_code", "retained_approved_evidence_count", "validation_artifact_id")
                       if key in row} for row in events if row.get("event") in {"gap_plan_rejected", "source_recovery_rejected", "followup_review_execution_rejected"}]
    return sanitize_artifact_text({
        "schema_version": "sciassistant.research-quality-inspection/v1", "run_id": manifest["run_id"],
        "status": final.get("status"), "failure_code": final.get("failure_code"),
        "source_fingerprint": manifest.get("source_fingerprint"), "source_scope": manifest.get("source_scope"),
        "prompt_versions": sorted({value.get("version") for value in manifest.get("prompts", {}).values()
                                   if isinstance(value, dict) and isinstance(value.get("version"), str)}),
        "model_calls": runtime.get("model_calls_used"),
        "workflow_elapsed_seconds": round(runtime["updated_at"] - runtime["created_at"], 2) if runtime else None,
        "recorded_run_elapsed_seconds": round(next(row["at"] for row in reversed(events) if row.get("event") == "workflow_finished")
                                               - manifest["created_at"], 2)
            if manifest.get("created_at") and any(row.get("event") == "workflow_finished" for row in events) else None,
        "funnel": {"queries": len(queries), "query_statuses": dict(Counter(q.get("source_status") for q in queries)),
                   "candidate_count_basis": "complete_search_catalog" if complete_catalog else "persisted_lower_bound",
                   "candidate_papers_observed": len({paper_key(key) for key in candidates}),
                   "indexed_documents": len({r["document_id"] for r in pdf_rows.values() if r.get("source_status") == "pdf_indexed"}),
                   "pdf_failures": [r for r in processing if pdf_problem(r)],
                   "pdf_unclassified_events": [r for r in processing if not pdf_problem(r)
                        and r.get("source_status") not in {"pdf_indexed", "pdf_parse_completed", "pdf_index_completed"}],
                   "approved_packets": len(approved), "approved_papers": len(notes),
                   "candidate_to_approved_paper_fraction": round(len(notes) / max(1, len({paper_key(k) for k in candidates})), 4) if complete_catalog else None,
                   "cited_packets": len(cited), "cited_papers": len({paper_key(r["paper_id"]) for r in cited}),
                   "claims": len(claims), "quantitative_claims": sum(r.get("claim_type") == "quantitative" for r in claims),
                   "paper_count_basis": "distinct_recorded_document_identities_not_independent_studies"},
        "groups": groups, "papers": notes,
        "budget_usage": artifacts.get(refs["budget"]) if refs.get("budget") else None,
        "paper_processing": processing,
        "processing_ms": processing_ms,
        "recovery_summary": {"rejections": recovery_events, "new_model_calls": 0,
                             "scope": "recorded_events_only_not_network_failure_or_new_approval"},
        "review_decisions": review.get("decisions", []),
        "evidence_flow": artifacts.get(refs["evidence_flow"]) if refs.get("evidence_flow") else None,
        "diagnostic_limits": ["批准片段数不能除以候选论文数作为批准率", "下载、解析、索引失败分别计数，不能全称网络故障",
                              "旧工件未记录拒绝原因时保持未知，不倒填模型理由"],
        "reading_selections": [row for row in events if row.get("event") == "literature_reading" and row.get("source_status") == "reading_selected"],
        "quantity_reaudit": {"recorded_code_issues": audit.get("code_issues") or [],
                             "current_code_issues": check_draft(draft, approved_set) if draft else [],
                             "scope": "read_only_not_a_new_model_audit_or_task_result"},
        "relevance_review": [{**row, "abstract": row["abstract"][:240], "label": None, "reason": ""} for row in candidates.values()],
        "manual_review_required": ["论文与问题的相关性", "数字及实验条件是否被原文支持", "原始研究与转述的区别", "结论是否易读且直接回答问题"],
    })


def render_notes(summary: dict) -> str:
    from multi_agent_status import describe_status
    display = describe_status(summary["status"])
    lines = ["# 按论文组织的证据笔记", "", f"运行：`{summary['run_id']}`", "",
             display["title"], "", display["guidance"], "",
             "> 这是批准片段和通过审计声明的索引，不是全文精读总结。这里只保留短原文预览；请回到报告证据卡查看完整片段和页框。未人工复核的实验条件不能补猜。", ""]
    for row in summary.get("recovery_summary", {}).get("rejections", []):
        lines += ["返工说明：" + str(row.get("reason_code") or "未记录") + "；保留已批准片段 "
                  + str(row.get("retained_approved_evidence_count", "未记录")) + " 条。不是文献不存在或网络故障的结论。", ""]
    for index, paper in enumerate(summary["papers"], 1):
        local = paper.get("source") == "uploaded_pdf"
        identity = ("本地上传文档：" if local else "文献标识：") + f"`{paper['paper_id']}`"
        original = "原文：本次报告中的本地 PDF 与证据卡；未生成外部链接。" if local else (
            f"原文：{paper['official_url']}" if paper.get("official_url") else "原文：没有经过校验的官方链接，请使用报告证据卡。")
        scope = {"selected_chunks": "仅所选原文片段，不代表全文读完", "abstract_only": "仅摘要级证据，不能冒称核验全文", "legacy_unclassified": "历史工件未记录阅读范围"}.get(paper["reading_scope"], paper["reading_scope"])
        lines += [f"## {index}. {paper['title']}", "", identity + "；版本：" + ', '.join(paper['versions']), "",
                  original, "", f"阅读范围：{scope}；已审查关联主题：{', '.join(paper['group_ids'])}", "",
                  "### 已批准摘录", ""]
        lines += ["关联研究问题：" + "；".join(q for q in paper.get("research_questions", []) if q), "",
                  "指标覆盖（仅所选证据）：" + "；".join(str(r.get("metric") or "未指定") + "=" + str(r.get("status"))
                                                    for r in paper.get("metric_findings", [])), ""]
        for evidence in paper["evidence"]:
            lines += [f"- `{evidence['evidence_id']}`，页码：{evidence['page'] or '摘要/未知'}", "",
                      "  位置：" + " / ".join(str(evidence.get(k) or "未提供") for k in ("section", "table_id", "figure_id"))
                      + ("；有页框" if evidence.get("bbox_available") else "；无页框"), "",
                      *["> " + line for line in evidence["excerpt"].splitlines()], ""]
        lines += ["### 回答中使用的声明与限制", ""]
        if not paper["linked_claims"]:
            lines += ["该论文已批准，但没有进入通过审计的最终声明。", ""]
        for claim in paper["linked_claims"]:
            kind = {"technical": "方法/机制线索", "quantitative": "定量结果", "comparative": "比较结论", "limitation": "证据边界"}.get(claim.get("claim_type"), "获批声明")
            lines += [f"- {kind} · `{claim['claim_id']}`：{claim.get('text', '')}", ""]
            if claim.get("visible_scope"):
                lines += ["  结论适用范围：" + claim["visible_scope"], ""]
            if claim.get("qualification") and claim.get("qualification") != claim.get("visible_scope"):
                lines += ["  详细实验条件与证据局限：" + claim["qualification"], ""]
        lines += ["### 人工复核栏", "", "- 研究问题/方法：待复核", "- 数字→指标→模型/硬件/batch/长度/基线：待逐项核验",
                  "- 与当前问题的相关性、贡献与局限：待复核", ""]
    if not summary["papers"]:
        lines += ["本轮无批准论文，不能生成科研读书笔记。", ""]
    return "\n".join(lines)


def _json(path, limit=2_000_000):
    if path.is_symlink() or not 0 < path.stat().st_size <= limit:
        raise ValueError('invalid dossier input')
    return json.loads(path.read_text(encoding='utf-8-sig'))


def dossier(directory):
    directory = Path(directory)
    if directory.is_symlink() or not directory.is_dir():
        raise ValueError('invalid run directory')
    directory = directory.resolve()
    manifest = read_run_manifest(directory)
    if not manifest.get('final_artifact_id'):
        raise ValueError('terminal artifact unavailable')
    root = directory / 'artifacts'
    if root.is_symlink(): raise ValueError('unsafe artifacts')
    artifacts = ArtifactDirectory(root)
    final = artifacts.get(manifest['final_artifact_id'])
    if final.get('run_id') != manifest.get('run_id'):
        raise ValueError('final identity mismatch')
    refs = final.get('artifact_refs') or {}
    payload = lambda name, default: artifacts.get(refs[name]) if refs.get(name) else default
    question, plan = payload('question', {}), payload('plan', {})
    approved, draft, audit = payload('approved', {'evidence': []}), payload('draft', {}), payload('audit', {})
    publication = payload('publication', {})
    evidence = {row['evidence_id']: row for row in approved.get('evidence', [])
                if row.get('review_status') == 'approved'}
    publication_rows = {row['claim_id']: row for row in publication.get('claims', [])}
    audit_rows = {row['claim_id']: row for row in audit.get('claim_results', [])}
    # The exported map is checked too, not silently substituted for decisions.
    map_path = directory / 'claim_evidence_map.json'
    mapped = {row['claim_id'] for row in _json(map_path)} if map_path.exists() else None
    claims = []
    for row in draft.get('claims', []):
        claim_id, decision = row['claim_id'], publication_rows.get(row['claim_id'], {})
        checked = audit_rows.get(claim_id, {})
        sources = []
        for key in row.get('evidence_ids', []):
            source = evidence.get(key)
            if not source:
                sources.append({'evidence_id': key, 'approved': False}); continue
            text = str(source.get('excerpt') or source.get('text') or '')
            sources.append({'evidence_id': key, 'approved': True, 'paper_id': source.get('paper_id'),
                'source': source.get('source'), 'locator': source.get('locator'),
                'coverage_scope': source.get('coverage_scope'), 'content_scope': source.get('content_scope'),
                'excerpt': sanitize_artifact_text(text[:16000]), 'excerpt_truncated': len(text) > 16000})
        claims.append({'claim_id': claim_id, 'fields': {field: sanitize_artifact_text(str(row.get(field) or ''))
                        for field in ('text', 'scope_note', 'qualification')},
            'published': decision.get('published'), 'in_exported_map': claim_id in mapped if mapped is not None else None,
            'audit_decision': checked.get('decision'), 'field_results': checked.get('field_results'),
            'source_witnesses': checked.get('source_witnesses', []),
            'code_issues': decision.get('code_issues', []), 'protocol_issues': decision.get('protocol_issues', []),
            'evidence': sources, 'independent_scientific_review': 'not_performed'})
    events_path = directory / 'events.jsonl'
    if events_path.exists() and (events_path.is_symlink() or events_path.stat().st_size > 10_000_000):
        raise ValueError('invalid event log')
    events = [json.loads(line) for line in events_path.read_text(encoding='utf8').splitlines()] if events_path.exists() else []
    role_calls = [{key: event.get(key) for key in ('event', 'role', 'call_number', 'status', 'usage',
                                                  'input_artifact_ids', 'output_artifact_ids') if key in event}
                  for event in events if event.get('event') in {'agent_started', 'agent_finished', 'agent_failed'}]
    for event in role_calls:
        if isinstance(event.get('usage'), dict):
            event['usage'] = {key: event['usage'][key] for key in ('model_calls', 'elapsed_ms') if key in event['usage']}
    published = {key for key, row in publication_rows.items() if row.get('published') is True}
    prompt_versions = sorted({value.get('version') for value in manifest.get('prompts', {}).values()
                              if isinstance(value, dict) and isinstance(value.get('version'), str)})
    return {'schema_version': 'sciassistant.quality-dossier/v1', 'run_id': final['run_id'],
        'source_fingerprint': manifest.get('source_fingerprint'), 'source_scope': manifest.get('source_scope'),
        'prompt_version': prompt_versions[0] if len(prompt_versions) == 1 else None,
        'prompt_versions': prompt_versions, 'status': final['status'],
        'failure_code': final.get('failure_code'), 'question': sanitize_artifact_text(str(question.get('question') or '')),
        'planned_groups': [{'group_id': group['id'], 'question': group.get('question'), 'metrics': group.get('metrics')}
                           for group in plan.get('groups', [])],
        'role_calls': role_calls, 'published_claims': len(published), 'draft_claims': len(claims),
        'publication_matches_export': published == mapped if mapped is not None and publication_rows else None,
        'claims': claims, 'read_only_regression_findings': [*check_memory_component_scope(draft, approved),
                                                          *check_metric_direction(draft, approved)],
        'public_source_routing': payload('source_routing', None),
        'automatic_scientific_approval': False, 'model_calls_added': 0, 'network_requests_added': 0,
        'interpretation': 'Model/source/protocol facts only. Audit approval and verbatim quotes are not scientific grading.'}



def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--output-dir", help="New directory only; does not modify source run")
    parser.add_argument("--dossier-output", "--output", type=Path, help="New claim-field/source JSON outside source run; no automatic grading")
    args = parser.parse_args(argv)
    try:
        if args.dossier_output:
            value = dossier(args.run_dir)
            path = args.dossier_output
            if path.exists() or path.is_symlink() or path.resolve().is_relative_to(Path(args.run_dir).resolve()):
                raise ValueError("output must be new and outside source run")
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("x", encoding="utf8") as stream:
                json.dump(value, stream, ensure_ascii=False, indent=2)
            print(json.dumps({k: value[k] for k in ("run_id", "status", "published_claims", "publication_matches_export", "model_calls_added")}, ensure_ascii=True))
            return 0
        summary = inspect_run(args.run_dir)
        if args.output_dir:
            output = Path(args.output_dir).resolve()
            run = Path(args.run_dir).resolve()
            if output == run or output.is_relative_to(run) or run.is_relative_to(output):
                raise ValueError("quality output overlaps source")
            output.mkdir(parents=True, exist_ok=False)
            (output / "quality_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
            (output / "paper_notes.md").write_text(render_notes(summary), encoding="utf-8-sig")
        print(json.dumps({k: summary[k] for k in ("run_id", "status", "model_calls", "workflow_elapsed_seconds", "recorded_run_elapsed_seconds", "funnel")}, ensure_ascii=False))
        return 0
    except (OSError, ValueError, KeyError, TypeError, sqlite3.Error, AgentContractError, WorkflowError):
        print(json.dumps({"status": "error", "error_code": "QUALITY_DOSSIER_INPUT_INVALID" if args.dossier_output else "QUALITY_INPUT_INVALID"}))
        return 2


if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    raise SystemExit(main())
