/* Production DOM/JS/CSS, synthetic evidence and owned loopback API; no fees. */
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),{chromium}=require('playwright');
let input='';process.stdin.setEncoding('utf8');process.stdin.on('data',part=>{input+=part;});
process.stdin.on('end',async()=>{
 const fixture=JSON.parse(input),root=path.resolve(__dirname,'..'),out=fixture.output,checks={},errors=[],calls=[];
 const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Y9Zl1sAAAAASUVORK5CYII=','base64');
 const server=http.createServer((req,res)=>{
  const u=new URL(req.url,'http://fixture');calls.push({path:u.pathname,method:req.method});
  if(u.pathname==='/export-fixture'){res.setHeader('Content-Type','text/html');return res.end(fixture.html);}
  if(u.pathname.startsWith('/5000/api/')){
   res.setHeader('Content-Type','application/json');let data={};
   if(u.pathname.endsWith('/report'))data=fixture.report;
   else if(u.pathname.includes('/assets/')){res.setHeader('Content-Type','image/png');return res.end(png);}
   else if(u.pathname.endsWith('/provider-keys'))data={schema_version:'sciassistant.account-provider-status/v1',deepseek:{configured:true,key_count:1},llama:{configured:false}};
   else if(u.pathname==='/5000/api/chat/sessions'||u.pathname.includes('/chat/sessions/'))data=[];
   return res.end(JSON.stringify(data));
  }
  const target=u.pathname==='/ai_chat.html'?path.join(root,'chatAi/ai_chat.html'):
   u.pathname.startsWith('/images/')?path.resolve(root,'chatAi','.'+u.pathname):path.resolve(root,'.'+u.pathname);
  const allowed=path.join(root,'chatAi')+path.sep;
  if(!target.startsWith(allowed)||!fs.existsSync(target)||!fs.statSync(target).isFile()||!fs.realpathSync(target).startsWith(allowed)){res.statusCode=404;return res.end();}
  res.setHeader('Content-Type',target.endsWith('.js')?'text/javascript':target.endsWith('.css')?'text/css':target.endsWith('.html')?'text/html':'application/octet-stream');res.end(fs.readFileSync(target));
 });
 let browser;
 try{
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const base='http://127.0.0.1:'+server.address().port;
  browser=await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe'});
  const context=await browser.newContext({viewport:{width:1366,height:980},ignoreHTTPSErrors:true});
  await context.addInitScript(()=>{sessionStorage.setItem('userToken','report-fixture-not-real');sessionStorage.setItem('username','排版验收');sessionStorage.setItem('userId','fixture');});
  const page=await context.newPage();page.on('pageerror',e=>errors.push(e.name));
  await page.goto(base+'/ai_chat.html',{waitUntil:'domcontentloaded'});
  await page.waitForFunction(()=>window.MultiAgentRagUI);
  const mountReport=async()=>{await page.evaluate(()=>{
   window.currentSessionId='fixture-session';
   document.getElementById('initial-prompt')?.remove();
   const message=document.createElement('div'),host=document.createElement('div'),content=document.createElement('div');
   message.className='message';host.setAttribute('data-chat-content-wrapper','');content.setAttribute('data-chat-answer-content','');
   content.textContent='正在读取报告';host.append(content);message.append(host);document.getElementById('chat-messages').append(message);
   window.MultiAgentRagUI.attach({id:'abcdef012345',status:'partial',processing_mode:'multi_agent_rag',report_available:true,execution:{model_calls:5}},'fixture-session',message);
  });await page.waitForSelector('.research-bibliography');};
  await mountReport();
  checks.no_duplicate_review_section=await page.locator('.rag-claims,.rag-coverage').count()===0;
  checks.no_right_column_gaps=await page.locator('.rag-response-column .research-note,.rag-response-column .rag-coverage-summary').count()===0;
  checks.one_left_gap_summary=await page.locator('.rag-source-column .rag-coverage-summary').count()===1;
  checks.no_per_evidence_gap_repetition=await page.locator('.rag-evidence .research-note,.rag-evidence .rag-coverage-summary').count()===0;
  checks.concrete_chinese_copy=await page.locator('.rag-source-column .rag-coverage-summary').innerText().then(s=>s.includes('概念与定义')&&s.includes('仅描述真伪二分类')&&!s.includes('qualified_answer')&&!s.includes('缺少实验条件：'));
  checks.repeated_gap_merged=await page.locator('.rag-source-column .rag-coverage-summary').textContent().then(s=>s.split('仅描述真伪二分类任务，所选片段未给出统一正式定义。').length-1===1);
  checks.no_gap_boilerplate=await page.locator('.rag-coverage-summary').textContent().then(s=>!['完整审查说明','与所列证据相关的审查说明','具体缺口：','本轮处理','可给出有限结论，不补造缺失指标'].some(t=>s.includes(t)));
  checks.right_body_not_polluted=await page.locator('.rag-answer-body').textContent().then(s=>!s.includes('仅描述真伪二分类任务'));
  checks.one_full_record=await page.locator('.rag-source-column').textContent().then(s=>s.split('完整条件记录：各数据集与生成器划分必须分别核对。').length-1===1);
  checks.cross_evidence_review_link=await page.getByRole('button',{name:'完整说明见 [1]',exact:true,includeHidden:true}).count()===1;
  checks.references_end_body=await page.locator('[data-chat-answer-content]').evaluate(el=>el.lastElementChild?.classList.contains('research-bibliography'));
  checks.colored_box=await page.locator('.rag-source-column .rag-coverage-summary').evaluate(el=>getComputedStyle(el).borderLeftWidth==='4px'&&getComputedStyle(el).backgroundColor!=='rgba(0, 0, 0, 0)');
  checks.equal_columns=await page.locator('.rag-chat-workspace').evaluate(el=>{
   const left=el.querySelector('.rag-source-column').getBoundingClientRect().width;
   const right=el.querySelector('.rag-response-column').getBoundingClientRect().width;return Math.abs(left-right)<2;
  });
  await page.locator('#chat-messages').evaluate(el=>el.scrollTop=0);
  await page.screenshot({path:path.join(out,'report-wide.png')});
  const divider=page.getByRole('separator',{name:'调整原文证据与回答宽度'});
  const widths=()=>page.locator('.rag-chat-workspace').evaluate(el=>({
   left:el.querySelector('.rag-source-column').getBoundingClientRect().width,
   right:el.querySelector('.rag-response-column').getBoundingClientRect().width,
   total:el.getBoundingClientRect().width
  }));
  checks.splitter_accessible=await divider.getAttribute('aria-orientation')==='vertical'&&await divider.getAttribute('tabindex')==='0';
  const initialWidths=await widths(),grip=await divider.boundingBox();
  await page.mouse.move(grip.x+grip.width/2,grip.y+40);await page.mouse.down();
  await page.mouse.move(grip.x+grip.width/2+120,grip.y+40,{steps:12});await page.mouse.up();
  const moved=await widths();
  checks.real_pointer_resizes_both_columns=moved.left>initialWidths.left+80&&moved.right<initialWidths.right-80&&Math.abs(moved.total-initialWidths.total)<2;
  checks.drag_cleanup=await page.locator('body').evaluate(el=>!el.classList.contains('rag-columns-resizing'));
  const stored=await page.evaluate(()=>localStorage.getItem('sciassistant.rag-columns/v1'));
  checks.preference_only_numeric_ratio=Number.isFinite(Number(stored))&&Number(stored)>=25&&Number(stored)<=75;
  await page.screenshot({path:path.join(out,'report-resized.png')});
  await divider.focus();const value=Number(await divider.getAttribute('aria-valuenow'));
  await page.keyboard.press('ArrowLeft');checks.keyboard_resize=Number(await divider.getAttribute('aria-valuenow'))===value-2;
  await page.keyboard.press('Home');const small=await widths();
  checks.minimum_pane_widths=small.left>=219&&small.right>=219;
  await page.keyboard.press('End');const large=await widths();
  checks.maximum_pane_widths=large.left>=219&&large.right>=219;
  await divider.dblclick();checks.double_click_resets=Number(await divider.getAttribute('aria-valuenow'))===50;
  await divider.focus();await page.keyboard.press('ArrowRight');await page.keyboard.press('ArrowRight');
  const saved=await divider.getAttribute('aria-valuenow');
  await page.reload({waitUntil:'domcontentloaded'});await page.waitForFunction(()=>window.MultiAgentRagUI);await mountReport();
  checks.ratio_restored_after_reload=await divider.getAttribute('aria-valuenow')===saved;
  await page.setViewportSize({width:877,height:980});await page.waitForTimeout(350);
  checks.container_narrow_stacked=await page.locator('.rag-chat-workspace').evaluate(el=>el.classList.contains('rag-workspace-stacked'));
  await page.setViewportSize({width:1366,height:980});await page.waitForTimeout(350);
  checks.ratio_restored_after_resizing_window=await divider.getAttribute('aria-valuenow')===saved;
  const before=await page.locator('#chat-messages').evaluate(el=>el.scrollTop);
  await page.locator('.research-bibliography button').last().evaluate(el=>el.click());
  checks.citation_scrolls_source_only=await page.locator('#chat-messages').evaluate((el,expected)=>el.scrollTop===expected,before)&&await page.locator('.rag-source-scroll').evaluate(el=>el.scrollTop>0);
  await page.locator('#rag-abcdef012345-3').getByRole('button',{name:'查看原文页 / 引用高亮',exact:true}).click();
  await page.waitForSelector('.rag-bbox');checks.preview_highlight_still_available=true;
  await page.setViewportSize({width:462,height:900});
  await page.waitForTimeout(350); // let the production resize handler/transition finish
  if(await page.locator('#sidebar').evaluate(el=>!el.classList.contains('sidebar-collapsed'))) {
   await page.locator('#sidebar-toggle-btn').click();
  }
  await page.waitForFunction(()=>document.getElementById('sidebar').getBoundingClientRect().right<=1);
  checks.narrow_stacked=await page.locator('.rag-chat-workspace').evaluate(el=>getComputedStyle(el).gridTemplateColumns.split(' ').length===1);
  checks.narrow_splitter_hidden=await page.locator('.rag-column-resizer').isHidden()&&await page.locator('.rag-column-resizer').getAttribute('tabindex')==='-1';
  checks.narrow_no_page_overflow=await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1);
  checks.mobile_sidebar_closed=await page.locator('#sidebar').evaluate(el=>el.getBoundingClientRect().right<=1);
  await page.locator('#chat-messages').evaluate(el=>el.scrollTop=0);await page.screenshot({path:path.join(out,'report-narrow.png')});
  const exported=await context.newPage();await exported.goto(base+'/export-fixture');
  checks.html_references_last=await exported.locator('body').evaluate(el=>el.lastElementChild.id==='bibliography');
  await exported.locator('a[href="#evidence-1"]').first().click();checks.export_citation_anchor=new URL(exported.url()).hash==='#evidence-1';
  checks.no_model_or_write_requests=calls.every(c=>c.method==='GET');checks.no_page_errors=errors.length===0;
 }catch(error){checks.execution=false;errors.push(error.name);}
 finally{
  const result={passed:Object.values(checks).every(Boolean)&&!errors.length,checks,page_errors:errors,synthetic_evidence:true,paid_vendor_calls:0};
  fs.writeFileSync(path.join(out,'browser_checks.json'),JSON.stringify(result,null,2),{flag:'wx'});
  await browser?.close();server.close();if(!result.passed)process.exitCode=1;
 }
});
