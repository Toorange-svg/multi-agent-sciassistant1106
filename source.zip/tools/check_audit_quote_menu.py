"""Read-only source menu / requested frozen-role recall probe; never publish."""
from copy import deepcopy
from pathlib import Path
import argparse
import hashlib
import json
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from multi_agent_agents import ArtifactDirectory
from multi_agent_quality import (AUDIT_QUOTE_MENU_POLICY, WITNESS_CHOICE_POLICY,
                                 initial_audit_witness_options, check_audit)


def hashes(root):
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in root.rglob('*') if p.is_file()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run-dir', type=Path, required=True)
    parser.add_argument('--pdf', type=Path)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    run, output = args.run_dir.resolve(), args.output_dir.resolve()
    if not run.is_dir() or output.is_relative_to(run) or run.is_relative_to(output):
        parser.error('missing run or output overlaps source run')
    source = args.pdf.resolve() if args.pdf else None
    if source and (not source.is_file() or output.is_relative_to(source.parent)):
        parser.error('missing PDF or output overlaps PDF source')
    before = hashes(run)
    source_sha = hashlib.sha256(source.read_bytes()).hexdigest() if source else None
    manifest = json.loads((run/'manifest.json').read_text(encoding='utf-8-sig'))
    store = ArtifactDirectory(run/'artifacts')
    final = store.get(manifest['final_artifact_id'])
    refs = final['artifact_refs']
    original = store.get(refs['draft'])
    proposed = {**deepcopy(original), 'audit_quote_menu_policy':AUDIT_QUOTE_MENU_POLICY,
                'witness_choice_policy':WITNESS_CHOICE_POLICY}
    approved = store.get(refs['approved'])
    menu = initial_audit_witness_options(proposed, approved)
    sources = {row['evidence_id']:row for row in approved['evidence']}
    claims = {row['claim_id']:row for row in original['claims']}
    checks = {
        'nonempty_bounded_choices':0 < len(menu['options']) <= 24,
        'exact_source_spans':all(o['quote'] == (sources[o['evidence_id']].get('excerpt') or
            sources[o['evidence_id']]['text'])[o['start_char']:o['end_char']] for o in menu['options']),
        'legal_quote_lengths':all(20 <= len(o['quote'].strip()) <= 300 for o in menu['options']),
        'only_cited_approved_sources':all(sources[o['evidence_id']]['review_status'] == 'approved'
            and o['evidence_id'] in claims[o['claim_id']]['evidence_ids'] for o in menu['options']),
        'no_automatic_approval':menu['semantic_auto_approval'] is False,
    }
    output.mkdir(parents=True, exist_ok=False)
    audit = check_audit(store.get(refs['audit']), original, approved)
    diagnosis = {'historical_status':final['status'], 'historical_claim_issues':audit.get('witness_issues', []),
                 'options':menu, 'publication_rewritten':False}
    if source:
        import pdf_pipeline
        from multi_agent_local_pdf import LocalPdfRagExecutor
        pdf_pipeline.PDF_PARSE_CACHE_DIR = output/'parser-cache'
        executor = LocalPdfRagExecutor(output/'private-probe', source, rag_mode='lexical')
        result = executor.execute([{'request_id':'frozen-role', 'action':'request_document_search',
            'arguments':{'query':'frozen base backward propagation', 'group_id':'g1'}}],
            group_ids={'g1'}, deadline=time.monotonic()+90)
        packets = result['evidence']
        witnesses = [row for row in packets if 'frozen' in row['excerpt'].lower()
                     and ('backpropagat' in row['excerpt'].lower() or 'backward' in row['excerpt'].lower())]
        checks.update({'frozen_propagation_prose_recalled':bool(witnesses),
            'same_packet_context_quota':len(packets) <= 4,
            'private_source_only':all(row['source'] == 'uploaded_pdf' for row in packets),
            'source_pdf_hash_unchanged':source_sha == hashlib.sha256(source.read_bytes()).hexdigest()})
        diagnosis['role_prose_evidence'] = [{key:row.get(key) for key in
            ('evidence_id','locator','excerpt','retrieval')} for row in witnesses]
        diagnosis['source_pdf_sha256'] = source_sha
    checks['historical_run_hashes_unchanged'] = before == hashes(run)
    value = {'schema_version':'sciassistant.audit-quote-menu-check/v1','checks':checks,
             'passed':all(checks.values()), 'diagnosis':diagnosis, 'model_calls':0,
             'network_requests':0, 'automatic_scientific_approval':False}
    (output/'checks.json').write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'passed':value['passed'],'checks':checks,'options':len(menu['options']),
                      'model_calls':0,'network_requests':0}))
    return 0 if value['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
