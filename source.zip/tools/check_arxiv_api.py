#!/usr/bin/env python3
"""独立检查 arXiv 官方 API 与论文网页连通性。

This script intentionally does not import app.py, web_app.py, MCP, or any
model client. arXiv's public Atom API does not require an API key. It uses the
normal process/network proxy environment, but never prints environment values.
"""

from __future__ import annotations

import argparse
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import requests
from dotenv import load_dotenv


ROOT = Path(__file__).resolve().parents[1]
# arxiv.org/api/query redirects to export.arxiv.org/api/query. Checking both
# in one run sends duplicate traffic to the same legacy API and can itself
# turn a diagnostic into another 429. The production client uses this one
# canonical endpoint as well.
ENDPOINTS = ("https://export.arxiv.org/api/query",)
ABS_URL = "https://arxiv.org/abs/1706.03762"
USER_AGENT = "SciAssistant/arxiv-api-check (contact: local deployment)"


def _load_project_environment() -> None:
    """Load project settings without displaying any secret values."""
    load_dotenv(ROOT / ".env", override=False)
    load_dotenv(ROOT / "deepdiver_v2" / "config" / ".env", override=False)


def _result(endpoint: str, status: str, **details: Any) -> dict[str, Any]:
    return {"endpoint": endpoint, "status": status, **details}


def _check_api_endpoint(session: requests.Session, endpoint: str, query: str, timeout: float) -> dict[str, Any]:
    params = {"search_query": f"all:{query}", "start": 0, "max_results": 1, "sortBy": "relevance", "sortOrder": "descending"}
    started = time.monotonic()
    try:
        response = session.get(endpoint, params=params, timeout=timeout)
        elapsed_ms = round((time.monotonic() - started) * 1000)
        if response.status_code == 429:
            return _result(endpoint, "rate_limited", http_status=429, elapsed_ms=elapsed_ms,
                           retry_after=response.headers.get("Retry-After") or None,
                           message="arXiv API returned HTTP 429 (rate limited)")
        if response.status_code != 200:
            return _result(endpoint, "http_error", http_status=response.status_code, elapsed_ms=elapsed_ms,
                           message=f"HTTP {response.status_code}: {response.text[:200].strip()}")
        body = response.content
        atom_ok = b"<feed" in body and b"<entry" in body
        return _result(endpoint, "ok" if atom_ok else "invalid_response", http_status=200,
                       elapsed_ms=elapsed_ms, bytes=len(body), content_type=response.headers.get("Content-Type", ""),
                       atom_feed=atom_ok, message="valid Atom feed received" if atom_ok else "HTTP 200 but no Atom entry was found")
    except requests.exceptions.Timeout as exc:
        return _result(endpoint, "timeout", elapsed_ms=round((time.monotonic() - started) * 1000), message=str(exc))
    except requests.exceptions.RequestException as exc:
        return _result(endpoint, "network_error", elapsed_ms=round((time.monotonic() - started) * 1000), message=str(exc))
    except Exception as exc:  # pragma: no cover - defensive diagnostic path
        return _result(endpoint, "unexpected_error", elapsed_ms=round((time.monotonic() - started) * 1000), message=str(exc))


def _check_abs_page(session: requests.Session, timeout: float) -> dict[str, Any]:
    started = time.monotonic()
    try:
        response = session.get(ABS_URL, timeout=timeout)
        elapsed_ms = round((time.monotonic() - started) * 1000)
        title_marker = b"citation_title" in response.content
        ok = response.status_code == 200 and title_marker
        return _result(ABS_URL, "ok" if ok else "http_error", http_status=response.status_code,
                       elapsed_ms=elapsed_ms, bytes=len(response.content), page_metadata=title_marker,
                       message="arXiv abstract page reachable" if ok else "abstract page did not return expected metadata")
    except requests.exceptions.Timeout as exc:
        return _result(ABS_URL, "timeout", elapsed_ms=round((time.monotonic() - started) * 1000), message=str(exc))
    except requests.exceptions.RequestException as exc:
        return _result(ABS_URL, "network_error", elapsed_ms=round((time.monotonic() - started) * 1000), message=str(exc))


def classify(api_results: list[dict[str, Any]], abs_result: dict[str, Any]) -> tuple[str, str]:
    api_statuses = {item["status"] for item in api_results}
    if "ok" in api_statuses:
        return "PASS", "至少一个 arXiv 官方 API 返回了有效 Atom 检索结果。"
    if api_statuses <= {"rate_limited"}:
        return "RATE_LIMITED", "arXiv 官方 API 返回限流；这不是无论文，而是当前出口暂时不能检索。"
    if "rate_limited" in api_statuses and abs_result["status"] == "ok":
        return "API_LIMITED", "论文网页可访问，但 API 入口被限流；问题集中在 API 入口或当前出口。"
    if abs_result["status"] == "ok":
        return "API_UNAVAILABLE", "论文网页可访问，但两个 API 端点均不可用。"
    return "NETWORK_UNAVAILABLE", "API 和论文网页都不可访问，优先检查网络、VPN、代理或 DNS。"


def main() -> int:
    parser = argparse.ArgumentParser(description="独立检查 arXiv 官方 API 是否可用")
    parser.add_argument("--query", default="transformer", help="用于最小检索的英文词，默认 transformer")
    parser.add_argument("--timeout", type=float, default=15.0, help="每个请求超时秒数，默认 15")
    parser.add_argument("--interval", type=float, default=3.0, help="两个 API 请求之间的间隔秒数，默认 3")
    parser.add_argument("--json", action="store_true", help="只输出 JSON，不输出中文摘要")
    args = parser.parse_args()
    _load_project_environment()

    session = requests.Session()
    session.headers.update({"User-Agent": USER_AGENT, "Accept": "application/atom+xml, application/xml"})
    api_results: list[dict[str, Any]] = []
    for index, endpoint in enumerate(ENDPOINTS):
        if index:
            time.sleep(max(0.0, args.interval))
        api_results.append(_check_api_endpoint(session, endpoint, args.query, args.timeout))
    abs_result = _check_abs_page(session, args.timeout)
    verdict, explanation = classify(api_results, abs_result)
    report = {"checked_at": datetime.now(timezone.utc).isoformat(), "query": args.query, "verdict": verdict,
              "explanation": explanation, "api_results": api_results, "abstract_page": abs_result,
              "uses_project_web_app": False, "uses_api_key": False}
    report_dir = ROOT / "logs" / "arxiv_api_checks"
    report_dir.mkdir(parents=True, exist_ok=True)
    report_path = report_dir / f"check_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print("SciAssistant 独立 arXiv API 检查")
        print(f"查询词：{args.query}")
        for item in api_results:
            print(f"- {item['endpoint']}: {item['status']} ({item.get('elapsed_ms', '?')} ms)")
        print(f"- {ABS_URL}: {abs_result['status']} ({abs_result.get('elapsed_ms', '?')} ms)")
        print(f"\n结论：{verdict} - {explanation}")
        print(f"详细报告：{report_path}")
    return 0 if verdict == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
