import sys
from pathlib import Path

from run_literature_retrieval_acceptance import main
import run_literature_retrieval_acceptance as suite

suite.CASES = [
    ("SSM Transformer fusion", "状态空间模型与 Transformer 融合架构下，如何解决长序列建模中非线性时序拟合不足与推理延迟过高的双重问题？"),
    ("Tool calling memory", "大规模预训练模型在工具调用迭代过程中，如何缓解多轮函数调用产生的参数遗忘与调用逻辑错乱问题？"),
    ("3D multimodal alignment", "三维视觉大模型在点云、图像多输入融合场景中，如何解决空间特征错位与几何语义解耦困难的问题？"),
    ("Online alignment", "对比传统离线对齐技术，在线动态对齐范式如何解决大模型领域适配后的对齐失效与能力回撤问题？"),
    ("Sparse expert routing", "稀疏大模型推理过程中，如何优化专家路由策略，降低低活跃专家带来的算力浪费与推理抖动问题？"),
    ("Long video generation", "超长视频生成模型中，如何解决帧间逻辑断裂、时序一致性差以及长片段语义漂移的核心难题？"),
    ("Private RAG chunking", "本地私有化 RAG 架构中，如何规避切片粒度固化导致的跨章节逻辑割裂与关键信息碎片化问题？"),
    ("Agent memory", "自主智能体长期记忆迭代更新中，如何设计记忆筛选与遗忘机制，避免冗余记忆堆积干扰决策精度？"),
    ("Quantized reasoning", "量化压缩后的大模型，在复杂数学推理与逻辑规划任务中精度暴跌，有哪些轻量化修复优化方案？"),
    ("World model sim2real", "世界模型在真实物理场景仿真落地时，如何弥补虚拟环境与现实世界的物理规则偏差与域 gap 问题？"),
    ("Causal multimodal hallucination", "多模态大模型普遍存在跨模态幻觉，如何通过因果干预机制抑制图文、视频匹配中的虚假关联生成？"),
    ("Continual pretraining", "大模型增量预训练过程中，如何平衡新领域知识学习与通用基座能力保留，彻底缓解灾难性遗忘？"),
    ("Edge agent planning", "端侧智能体受限算力与内存条件下，如何精简规划链路，实现低功耗下的实时任务自主决策？"),
    ("DPO limitations", "直接偏好优化相较于传统基于奖励的对齐方案，在复杂多维度偏好学习中存在哪些固有缺陷？"),
    ("Graph RAG errors", "图谱增强 RAG 在复杂行业知识推理中，如何解决知识图谱缺失、实体歧义导致的推理错误传导问题？"),
    ("Speculative long context", "speculative 加速解码技术在超长文本生成场景中，如何降低推测 token 误判带来的整体生成延迟损耗？"),
    ("Embodied correction", "具身智能机器人在动态未知环境中，如何实时修正视觉感知偏差，提升动作执行的精准度与泛化性？"),
    ("Self improvement", "大模型自我迭代微调过程中，如何规避自我数据污染引发的能力内卷、创造力衰减的迭代陷阱？"),
    ("Multi-agent coordination", "多智能体组队协作任务中，如何解决局部最优决策、信息不对称导致的整体协作效率低下问题？"),
    ("Synthetic data bias", "基于合成数据训练的大模型，如何构建偏差检测机制，甄别结构化伪数据带来的认知偏差与逻辑缺陷？"),
]

if __name__ == "__main__":
    main()
