"""Owned cache HTTP/MySQL flow with a synthetic PDF, zero vendor calls.

Never touches production 5000 or historical runs. The original is a controlled
fixture, not proof of arXiv availability or research-answer scientific quality.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tools.check_research_web_flow import Server, register, request, wait_task


def run(label):
    root = ROOT/'logs/research_web_validation'/label
    root.mkdir(parents=True, exist_ok=False)
    server = Server(root, 'mock')
    checks = {}
    result = {'synthetic_pdf': True, 'real_http': True, 'real_mysql': True,
              'paid_model_calls': 0, 'production_touched': False, 'checks': checks}

    def require(name, condition):
        checks[name] = bool(condition)
        if not condition:
            raise RuntimeError(name)

    try:
        server.start()
        a, b = register(server.base, 'cache_a'), register(server.base, 'cache_b')
        # The ordinary gateway creates the owner mapping; no owner-file edits.
        created = request(server.base, 'POST', '/api/science/tasks', a['token'],
            json={'query': 'Compare controlled fixture methods', 'processing_mode': 'multi_agent_rag'})
        require('task_created', created.status_code == 202)
        task = wait_task(server, a, created.json()['task']['id'], limit=40)
        require('mock_workflow_finished', task['status'] in {'completed', 'partial', 'needs_review'})
        task_id = task['id']
        document_id = 'arxiv-2309-06180v1'
        directory = root/'runs'/task_id/'pdf'/document_id
        directory.mkdir(parents=True, exist_ok=False)
        import pymupdf
        doc = pymupdf.open()
        doc.new_page().insert_text((50, 50), 'Owned synthetic original, not a research source')
        pdf = doc.tobytes()
        doc.close()
        original = directory/'source.pdf'
        original.write_bytes(pdf)
        (directory/'metadata.json').write_text(json.dumps({'document_id': document_id,
            'title': 'Controlled cached PDF', 'paper_id': '2309.06180v1'}), encoding='utf8')
        source_hash = hashlib.sha256(pdf).hexdigest()
        prefix = '/api/literature/tasks/'+task_id+'/papers/'+document_id
        own = request(server.base, 'GET', '/api/literature/papers', a['token'])
        require('own_cache_listed', own.status_code == 200 and any(row.get('task_id') == task_id for row in own.json()['papers']))
        other = request(server.base, 'GET', '/api/literature/papers', b['token'])
        require('other_cache_not_listed', all(row.get('task_id') != task_id for row in other.json()['papers']))
        downloaded = request(server.base, 'GET', prefix+'/pdf', a['token'])
        require('owner_original_matches', downloaded.status_code == 200 and downloaded.content == pdf)
        require('download_no_store', downloaded.headers.get('Cache-Control') == 'no-store')
        for suffix, method in [('/pdf', 'GET'), ('/save', 'POST')]:
            require(suffix[1:]+'_other_404', request(server.base, method, prefix+suffix, b['token']).status_code == 404)
            require(suffix[1:]+'_anonymous_401', request(server.base, method, prefix+suffix).status_code == 401)
        saved = request(server.base, 'POST', prefix+'/save', a['token'], json={'user_id': b['user_id']})
        require('saved_into_own_library', saved.status_code == 200 and len(saved.json()['files']) == 1)
        file_id = saved.json()['files'][0]['file_id']
        file_url = '/api/files/download/'+file_id
        require('saved_bytes_match', request(server.base, 'GET', file_url, a['token']).content == pdf)
        require('saved_other_404', request(server.base, 'GET', file_url, b['token']).status_code == 404)
        server.stop()
        server.start()
        require('cache_survives_restart', request(server.base, 'GET', prefix+'/pdf', a['token']).content == pdf)
        require('saved_survives_restart', request(server.base, 'GET', file_url, a['token']).content == pdf)
        require('original_unchanged', hashlib.sha256(original.read_bytes()).hexdigest() == source_hash)
        result['source_fingerprint'] = request(server.base, 'GET', '/api/health').json()['runtime']['source_fingerprint']
        result['passed'] = True
    except Exception as error:
        result.update(passed=False, error_type=type(error).__name__,
                      failed_check=next((key for key, value in checks.items() if not value), None))
    finally:
        server.stop()
        (root/'cache_flow_result.json').write_text(json.dumps(result, indent=2), encoding='utf8')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-id', required=True)
    args = parser.parse_args()
    if not re.fullmatch('[a-z0-9-]{1,80}', args.run_id):
        parser.error('invalid run-id')
    outcome = run(args.run_id)
    print(json.dumps(outcome))
    raise SystemExit(0 if outcome['passed'] else 1)
