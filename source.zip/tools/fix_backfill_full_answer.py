# -*- coding: utf-8 -*-
"""把数据库里补写的 ai 消息更新为 followup.json 中的完整答案。"""
import json, pathlib, sys
ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from app import DB_CONFIG
import pymysql

SRC = ROOT / "logs" / "multidomain_eval_20260920_192106.jsonl"
LOGS = ROOT / "logs"

def clean(ans):
    import re
    if ans.startswith("已完成检索"):
        m = re.match(r"已完成检索：共检索到 (\d+) 篇候选文献，其中 (\d+) 篇通过相关性门控，但在证据账本构建后可用 (\d+) 篇", ans)
        if m:
            c, g, a = m.groups()
            return f"（证据不足）共检索到 {c} 篇候选，{g} 篇通过相关性筛选，但完整核验后可用 {a} 篇，未找到足够支撑回答的相关文献。"
    ans = re.sub(r"\n?- (arxiv|zenodo|techrxiv)：[^\n]*", "", ans)
    ans = re.sub(r"被拒候选的主要类型：[^\n]*", "", ans)
    return ans.strip()

lines = SRC.read_text(encoding="utf-8").splitlines()
conn = pymysql.connect(**DB_CONFIG)
updated = 0
with conn.cursor() as cur:
    for line in lines:
        o = json.loads(line)
        conv = o["conv_id"]
        for ri, r in enumerate(o["rounds"]):
            ans = r.get("answer_head", "")
            fp = LOGS / f"web_task_{r['task_id']}.followup.json"
            if fp.exists():
                try:
                    ans = json.loads(fp.read_text(encoding="utf-8")).get("answer", ans)
                except Exception:
                    pass
            ans = clean(ans)
            cur.execute(
                "UPDATE conversation_detail SET content=%s WHERE session_id=%s AND from_who='ai' AND round=%s",
                (ans, conv, ri+1))
            updated += cur.rowcount
conn.commit()
print("UPDATED rows:", updated)
