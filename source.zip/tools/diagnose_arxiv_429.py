#!/usr/bin/env python3
"""Diagnose arXiv 429s without starting SciAssistant or MCP.

The tool performs one API request and one abstract-page request, then combines
those results with local process/port/throttle/log evidence. It never retries
the API and never prints proxy values or secrets.
"""

from __future__ import annotations

import argparse
import json
import os
import socket
import sqlite3
import subprocess
import time
import ipaddress
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import requests
from dotenv import load_dotenv


ROOT = Path(__file__).resolve().parents[1]
API_URL = "https://export.arxiv.org/api/query"
ABS_URL = "https://arxiv.org/abs/1706.03762"
USER_AGENT = "SciAssistant/arxiv-429-diagnostic (contact: local deployment)"
PROJECT_MARKER = "SciAssistant_v1.0.0"
PROJECT_PORTS = (5000, 5050, 6274, 8000)
CHECK_HOSTS = ("export.arxiv.org", "arxiv.org")


def _load_environment() -> None:
    load_dotenv(ROOT / ".env", override=False)
    load_dotenv(ROOT / "deepdiver_v2" / "config" / ".env", override=False)


def _request(session: requests.Session, url: str, timeout: float, api: bool) -> dict[str, Any]:
    started = time.monotonic()
    try:
        if api:
            response = session.get(
                url,
                params={"search_query": "all:transformer", "start": 0, "max_results": 1,
                        "sortBy": "relevance", "sortOrder": "descending"},
                timeout=timeout,
            )
        else:
            response = session.get(url, timeout=timeout)
        elapsed = round((time.monotonic() - started) * 1000)
        result: dict[str, Any] = {"url": url, "elapsed_ms": elapsed, "http_status": response.status_code}
        if response.status_code == 429:
            result.update({"status": "rate_limited", "retry_after": response.headers.get("Retry-After") or None})
        elif response.status_code != 200:
            result.update({"status": "http_error", "message": response.text[:200].strip()})
        elif api:
            result.update({"status": "ok" if b"<feed" in response.content and b"<entry" in response.content else "invalid_response"})
        else:
            result.update({"status": "ok" if b"citation_title" in response.content else "invalid_response"})
        return result
    except requests.exceptions.Timeout as exc:
        return {"url": url, "status": "timeout", "elapsed_ms": round((time.monotonic() - started) * 1000), "message": str(exc)}
    except requests.exceptions.RequestException as exc:
        return {"url": url, "status": "network_error", "elapsed_ms": round((time.monotonic() - started) * 1000), "message": str(exc)}


def _local_processes() -> dict[str, Any]:
    """Collect project process evidence using built-in Windows PowerShell."""
    if os.name != "nt":
        return {"status": "unsupported", "project_python_processes": [], "ports": {}}
    command = (
        "Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | "
        "Where-Object { $_.CommandLine -match 'SciAssistant_v1\\.0\\.0' } | "
        "Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress"
    )
    try:
        raw = subprocess.check_output(["powershell.exe", "-NoProfile", "-Command", command], text=True, stderr=subprocess.DEVNULL).strip()
        processes = json.loads(raw) if raw else []
        if isinstance(processes, dict):
            processes = [processes]
        # Do not count this diagnostic process as a running application.
        processes = [item for item in processes if "diagnose_arxiv_429.py" not in str(item.get("CommandLine", ""))]
    except Exception as exc:
        return {"status": "unavailable", "error": type(exc).__name__, "project_python_processes": [], "ports": {}}
    ports: dict[str, list[int]] = {}
    port_owners: list[dict[str, Any]] = []
    for port in PROJECT_PORTS:
        try:
            net_command = f"Get-NetTCPConnection -State Listen -LocalPort {port} -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess"
            raw_ports = subprocess.check_output(["powershell.exe", "-NoProfile", "-Command", net_command], text=True, stderr=subprocess.DEVNULL)
            pids = sorted({int(item.strip()) for item in raw_ports.splitlines() if item.strip().isdigit()})
            ports[str(port)] = pids
            for pid in pids:
                owner_command = ""
                owner_path = ""
                try:
                    owner_raw = subprocess.check_output(
                        ["powershell.exe", "-NoProfile", "-Command",
                         f"Get-CimInstance Win32_Process -Filter 'ProcessId={pid}' | Select-Object ProcessId,ExecutablePath,CommandLine | ConvertTo-Json -Compress"],
                        text=True, stderr=subprocess.DEVNULL,
                    ).strip()
                    owner = json.loads(owner_raw) if owner_raw else {}
                    owner_command = str(owner.get("CommandLine", ""))
                    owner_path = str(owner.get("ExecutablePath", ""))
                except Exception:
                    pass
                port_owners.append({"port": port, "pid": pid, "executable": owner_path, "command": owner_command})
        except Exception:
            ports[str(port)] = []
    return {"status": "ok", "project_python_processes": processes, "python_process_count": len(processes),
            "ports": ports, "port_owners": port_owners}


def _throttle_state() -> dict[str, Any]:
    path = ROOT / "logs" / "arxiv_request_state.sqlite3"
    if not path.exists():
        return {"status": "missing", "path": str(path)}
    try:
        connection = sqlite3.connect(str(path), timeout=2)
        row = connection.execute("SELECT next_request_at, cooldown_until FROM arxiv_state WHERE id=1").fetchone()
        connection.close()
        now = time.time()
        return {"status": "ok", "cooldown_remaining_seconds": max(0, round(float(row[1]) - now, 1)) if row else 0,
                "next_request_wait_seconds": max(0, round(float(row[0]) - now, 1)) if row else 0}
    except Exception as exc:
        return {"status": "unavailable", "error": type(exc).__name__}


def _log_evidence() -> dict[str, Any]:
    files = sorted((ROOT / "logs").glob("web_task_*.txt"), key=lambda p: p.stat().st_mtime, reverse=True)[:20]
    rate_limited = 0
    old_endpoint = 0
    for path in files:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        rate_limited += text.count("429")
        old_endpoint += text.count("https://arxiv.org/api/query")
    return {"recent_task_logs_checked": len(files), "recent_429_mentions": rate_limited,
            "old_redirect_endpoint_mentions": old_endpoint}


def _proxy_evidence() -> dict[str, Any]:
    names = ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY", "http_proxy", "https_proxy", "all_proxy", "no_proxy")
    present = sorted({name.upper() for name in names if os.getenv(name)})
    return {"proxy_variables_present": present, "note": "值已隐藏；代理变量存在会影响 VPN 路由判断。"}


def _dns_evidence() -> dict[str, Any]:
    """Record DNS answers and flag Clash Fake-IP answers."""
    answers: dict[str, list[str]] = {}
    fake_ip_hosts: list[str] = []
    for host in CHECK_HOSTS:
        values: set[str] = set()
        try:
            for item in socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM):
                address = item[4][0]
                try:
                    parsed = ipaddress.ip_address(address)
                except ValueError:
                    continue
                values.add(address)
                if parsed in ipaddress.ip_network("198.18.0.0/15"):
                    if host not in fake_ip_hosts:
                        fake_ip_hosts.append(host)
        except OSError:
            pass
        answers[host] = sorted(values)
    return {"answers": answers, "fake_ip_hosts": fake_ip_hosts,
            "fake_ip_range": "198.18.0.0/15"}


def _classify(api: dict[str, Any], abstract: dict[str, Any], local: dict[str, Any], throttle: dict[str, Any], logs: dict[str, Any], dns: dict[str, Any]) -> tuple[str, list[str]]:
    reasons: list[str] = []
    process_count = int(local.get("python_process_count", 0) or 0)
    occupied = [port for port, pids in local.get("ports", {}).items() if pids]
    # A Windows venv launcher can leave a parent Python process while the
    # base interpreter child owns the listening socket. Count only socket
    # owners here; counting every command line falsely reports that pair as
    # duplicate service instances.
    duplicate_services: dict[str, int] = {}
    for item in local.get("port_owners", []):
        command = str(item.get("command", ""))
        for name in ("app.py", "web_app.py", "a.py", "mcp_server_standard.py"):
            if name in command:
                duplicate_services[name] = duplicate_services.get(name, 0) + 1
    duplicate_services = {name: count for name, count in duplicate_services.items() if count > 1}
    duplicate_ports = {port: pids for port, pids in local.get("ports", {}).items() if len(pids) > 1}
    cooldown = float(throttle.get("cooldown_remaining_seconds", 0) or 0)
    if api.get("status") == "ok":
        verdict = "API_OK"
        reasons.append("当前单次 API 请求返回 200，当前出口此刻没有被 API 限流。")
    elif api.get("status") == "rate_limited":
        if abstract.get("status") == "ok":
            if not duplicate_services and not duplicate_ports:
                verdict = "API_RATE_LIMITED"
                reasons.append("论文网页可访问但 API 返回 429，且本机没有同端口重复服务；可排除本机并发，优先判断为 arXiv API 对当前出口或近期请求行为的限流。")
            else:
                verdict = "API_RATE_LIMITED_WITH_LOCAL_DUPLICATES"
                reasons.append("论文网页可访问但 API 返回 429；本机存在重复监听服务，需先清理本地并发，再判断出口是否仍被限流。")
        else:
            verdict = "API_LIMIT_AND_NETWORK_UNCERTAIN"
            reasons.append("API 返回 429 且论文页不可用，限流与 VPN/代理网络问题可能同时存在。")
    elif api.get("status") == "timeout" and abstract.get("status") == "ok":
        verdict = "API_PATH_TIMEOUT"
        reasons.append("论文网页可访问但 API 请求超时；当前更像 VPN/代理对 export.arxiv.org API 路径丢包、阻断或延迟过高，不是 API 429，也不是整个网络断开。")
    elif api.get("status") == "network_error" and abstract.get("status") == "ok":
        verdict = "API_PATH_NETWORK_ERROR"
        reasons.append("论文网页可访问但 API 连接失败；当前更像 VPN/代理对 export.arxiv.org API 路径的路由或 TLS 问题。")
    else:
        verdict = "NETWORK_OR_PROXY"
        reasons.append("API 没有返回有效结果，优先检查 VPN、代理、DNS、防火墙和 TLS 路径。")
    owners = local.get("port_owners") or []
    expected_python = str(ROOT / "venv" / "Scripts" / "python.exe").lower()
    stale_owners = [item for item in owners if str(item.get("executable", "")).lower() != expected_python]
    if duplicate_services or duplicate_ports:
        reasons.append(f"检测到重复服务：脚本 {duplicate_services or '无'}，端口多进程 {duplicate_ports or '无'}；这才可能造成并发访问。")
    elif occupied:
        reasons.append(f"检测到 {process_count} 个项目服务进程，分别占用端口 {', '.join(occupied)}；这是正常服务拓扑，不能据此判断存在并发重复请求。")
    if cooldown > 0:
        reasons.append(f"共享节流状态仍有约 {cooldown} 秒冷却，项目会主动暂停后续 API 请求。")
    if logs.get("old_redirect_endpoint_mentions", 0):
        reasons.append("最近日志仍出现旧 arxiv.org/api/query，说明曾有旧进程未重启；重启全部项目进程后再判断。")
    fake_ip_hosts = dns.get("fake_ip_hosts") or []
    if fake_ip_hosts:
        reasons.append(
            "DNS 将 " + ", ".join(fake_ip_hosts)
            + " 解析到 198.18.0.0/15 Fake-IP 保留网段；这通常表示 Clash Fake-IP/规则接管，"
            + "应检查 export.arxiv.org 是否走代理、TUN 和 DNS 映射。"
        )
        if verdict in {"API_PATH_TIMEOUT", "NETWORK_OR_PROXY"}:
            verdict = "API_PATH_TIMEOUT_FAKE_IP"
    return verdict, reasons


def main() -> int:
    parser = argparse.ArgumentParser(description="独立诊断 SciAssistant 当前 arXiv 429 原因")
    parser.add_argument("--timeout", type=float, default=15.0)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    _load_environment()
    session = requests.Session()
    session.headers.update({"User-Agent": os.getenv("ARXIV_USER_AGENT", USER_AGENT), "Accept": "application/atom+xml, application/xml"})
    api = _request(session, API_URL, args.timeout, True)
    time.sleep(3)
    abstract = _request(session, ABS_URL, args.timeout, False)
    local = _local_processes()
    throttle = _throttle_state()
    logs = _log_evidence()
    proxy = _proxy_evidence()
    dns = _dns_evidence()
    verdict, reasons = _classify(api, abstract, local, throttle, logs, dns)
    report = {"checked_at": datetime.now(timezone.utc).isoformat(), "verdict": verdict, "reasons": reasons,
              "api": api, "abstract_page": abstract, "local_processes": local, "throttle": throttle,
              "logs": logs, "proxy": proxy, "dns": dns, "uses_project_web_app": False, "uses_mcp": False}
    report_dir = ROOT / "logs" / "arxiv_api_checks"
    report_dir.mkdir(parents=True, exist_ok=True)
    report_path = report_dir / f"diagnosis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print("SciAssistant 独立 arXiv 429 诊断")
        print(f"结论：{verdict}")
        for reason in reasons:
            print(f"- {reason}")
        print(f"API：{api.get('status')}；论文页：{abstract.get('status')}")
        print(f"详细报告：{report_path}")
    return 0 if verdict == "API_OK" else 2


if __name__ == "__main__":
    raise SystemExit(main())
