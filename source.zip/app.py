# Copyright (c) 2026 South China Sea Institute of Oceanology, Chinese Academy of Sciences (SCSIO, CAS). All rights reserved.
import pathlib
import pymysql
import hashlib
import hmac
import ipaddress
import re
import os
import json
import jwt
import datetime
import secrets
import sqlite3
import threading
from flask import Flask, request, jsonify, app, abort, send_from_directory, g
from flask_cors import CORS
from dotenv import load_dotenv
from functools import wraps
from werkzeug.exceptions import HTTPException
from werkzeug.security import check_password_hash, generate_password_hash
import uuid
from flask import send_file, jsonify
from pathlib import Path
from typing import Optional, Dict, Any, List
import shutil
import sys
import requests as http_requests
from urllib.parse import urlsplit
from pdf_pipeline import build_parse_metadata, build_risk_summary, confidence_adjusted_score, page_confidence as pdf_page_confidence, parse_pdf as parse_pdf_with_layout
from deepdiver_v2.src.report_export import export_report_files
from runtime_identity import RuntimeIdentity
from request_limits import SlidingWindowLimiter
from password_reset import ResetConfigurationError, load_reset_mail_config, send_reset_email
from request_observability import install_request_observability
from storage_guard import configured_min_free_bytes, has_minimum_free_space
from user_credentials import CredentialStore, ProviderCapability

_GATEWAY_RUNTIME = RuntimeIdentity("account_gateway")

# 添加项目根目录到跾
sys.path.insert(0, str(Path(__file__).parent))

# 导入日志配置
from deepdiver_v2.config.logging_config import quick_setup, get_logger

# Shared log location used by task diagnostics and conversation exports.
BASE_DIR = Path(__file__).parent.resolve()
LOG_DIR = BASE_DIR / "logs"
RUNTIME_STORAGE_MIN_FREE_BYTES = configured_min_free_bytes()

# 加载变量
load_dotenv()
load_dotenv(Path(__file__).parent / "deepdiver_v2" / "config" / ".env", override=False)
# 数据库配?
MYSQL_HOST="localhost"
MYSQL_USER="root"
MYSQL_PASSWORD=""
MYSQL_DATABASE="chatai"
MYSQL_HOST = os.getenv("MYSQL_HOST", "localhost")
MYSQL_USER = os.getenv("MYSQL_USER", MYSQL_USER)
MYSQL_PASSWORD = os.getenv("MYSQL_PASSWORD", MYSQL_PASSWORD)
MYSQL_DATABASE = os.getenv("MYSQL_DATABASE", MYSQL_DATABASE)
quick_setup(
    environment=os.getenv('APP_ENV', 'production'),
    log_dir='logs',
    enable_file_logging=True
)

logger = get_logger(__name__)

def safe_filename_unicode(filename: str) -> str:
    """
    安全的文件名处理函数，支持中文和特殊字
    叧indows系统不允许的字和路径分隔
    
    Args:
        filename: 原文件?        
    Returns:
        处理后的安全文件?    """
    if not filename:
        return 'untitled'
    
    # Windows保留字和路径分隔
    forbidden_chars = r'<>:"/\|?*'
    # Control characters are invalid in Windows filenames.
    forbidden_chars += ''.join(chr(i) for i in range(32))
    
    # 移除禁字
    safe_name = ''.join(c for c in filename if c not in forbidden_chars)
    
    # Normalize Windows-incompatible trailing whitespace and periods.
    safe_name = safe_name.strip(' .')
    
    # 如果处理后的文件名为空或双吂号，使用默名称
    if not safe_name or safe_name == '.':
        safe_name = 'untitled'
    
    # Keep names below the practical Windows filename limit.
    if len(safe_name) > 200:
        # Preserve the extension when truncating.
        if '.' in safe_name:
            name_part, ext_part = safe_name.rsplit('.', 1)
            safe_name = name_part[:200-len(ext_part)-1] + '.' + ext_part
        else:
            safe_name = safe_name[:200]
    
    # Windows保留名称?查（虽然?舸会遇到，但为了安兼
    reserved_names = {'CON', 'PRN', 'AUX', 'NUL', 
                      'COM1', 'COM2', 'COM3', 'COM4', 'COM5', 'COM6', 'COM7', 'COM8', 'COM9',
                      'LPT1', 'LPT2', 'LPT3', 'LPT4', 'LPT5', 'LPT6', 'LPT7', 'LPT8', 'LPT9'}
    if safe_name.upper().split('.')[0] in reserved_names:
        safe_name = 'file_' + safe_name
    
    return safe_name

def _configured_cors_origins(raw_value: Optional[str] = None) -> list[str]:
    """Return an explicit origin allowlist; wildcard/URL components fail closed."""
    raw = os.getenv("CORS_ALLOWED_ORIGINS", "") if raw_value is None else raw_value
    production = os.getenv("APP_ENV", "production").strip().lower() not in {
        "development", "dev", "test", "testing"
    }
    origins = []
    for candidate in re.split(r"[,;\n]", raw or ""):
        candidate = candidate.strip()
        if not candidate:
            continue
        try:
            parsed = urlsplit(candidate)
            valid = parsed.scheme in {"http", "https"} and bool(parsed.hostname)
            valid = valid and parsed.username is None and parsed.password is None
            valid = valid and parsed.path in {"", "/"} and not parsed.query and not parsed.fragment
            parsed.port  # Force invalid ports to raise ValueError.
        except ValueError as exc:
            raise RuntimeError("CORS_ALLOWED_ORIGINS 包含无效来源；必须使用完整 http(s) origin。") from exc
        if not valid or "*" in candidate or (production and parsed.scheme.lower() != "https"):
            raise RuntimeError("CORS_ALLOWED_ORIGINS 包含无效来源；禁止通配符、路径、凭据和查询参数。")
        normalized = f"{parsed.scheme.lower()}://{parsed.netloc.lower()}"
        if normalized not in origins:
            origins.append(normalized)
    return origins


def _configured_account_listener(
    host_value: Optional[str] = None,
    port_value: Optional[str] = None,
) -> tuple[str, int]:
    """Keep the direct Flask launcher on an IPv4 loopback interface.

    Public production traffic belongs behind the HTTPS reverse proxy. The
    direct launcher is for local development/recovery and must not become an
    accidental plaintext LAN service through an environment override.
    """
    host = (
        os.getenv("ACCOUNT_BIND_ADDRESS", "127.0.0.1")
        if host_value is None else str(host_value)
    ).strip()
    raw_port = (
        os.getenv("ACCOUNT_HOST_PORT", "5000")
        if port_value is None else str(port_value)
    ).strip()
    try:
        address = ipaddress.ip_address(host)
        port = int(raw_port)
    except (ValueError, TypeError) as exc:
        raise RuntimeError("账户服务监听配置无效") from exc
    if not isinstance(address, ipaddress.IPv4Address) or not address.is_loopback:
        raise RuntimeError("ACCOUNT_BIND_ADDRESS 必须是 IPv4 本机回环地址")
    if not 1 <= port <= 65535:
        raise RuntimeError("ACCOUNT_HOST_PORT 必须在 1 到 65535 之间")
    return str(address), port


app = Flask(__name__)
from source_delivery import install as install_source_delivery
install_source_delivery(app, _GATEWAY_RUNTIME, BASE_DIR)
# Reject oversized multipart bodies while Werkzeug is still reading the
# request stream. Route-level limits remain lower and provide product-specific
# messages; this ceiling prevents them from being bypassed through chunked or
# misleading multipart metadata.
ACCOUNT_MAX_REQUEST_SIZE = 64 * 1024 * 1024
app.config["MAX_CONTENT_LENGTH"] = ACCOUNT_MAX_REQUEST_SIZE
app.config["MAX_FORM_MEMORY_SIZE"] = 1024 * 1024
app.config["MAX_FORM_PARTS"] = 32
install_request_observability(app, logger, "account_gateway")


@app.errorhandler(413)
def account_request_too_large(_error):
    return jsonify({
        "success": False,
        "error": "REQUEST_TOO_LARGE",
        "message": "请求内容超过 64 MB 限制，请减少文件数量或大小后重试。",
    }), 413

class PrefixStripMiddleware:
    """Allow the frontend's historical /5000 prefix to hit this Flask app."""

    def __init__(self, wrapped_app, prefix: str):
        self.wrapped_app = wrapped_app
        self.prefix = prefix.rstrip("/")

    def __call__(self, environ, start_response):
        path = environ.get("PATH_INFO", "")
        if path == self.prefix:
            environ["PATH_INFO"] = "/"
        elif path.startswith(self.prefix + "/"):
            environ["PATH_INFO"] = path[len(self.prefix):] or "/"
        return self.wrapped_app(environ, start_response)


app.wsgi_app = PrefixStripMiddleware(app.wsgi_app, "/5000")

# Browser clients are same-origin by default. Cross-origin API access must be
# explicitly enumerated; account JWTs are never accepted through a wildcard.
_CORS_ALLOWED_ORIGINS = _configured_cors_origins()
if _CORS_ALLOWED_ORIGINS:
    CORS(
        app,
        origins=_CORS_ALLOWED_ORIGINS,
        methods=("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"),
        allow_headers=("Authorization", "Content-Type"),
        supports_credentials=False,
        send_wildcard=False,
        vary_header=True,
        max_age=600,
    )


_BROWSER_CSP = "; ".join((
    "default-src 'self'",
    "base-uri 'self'",
    "object-src 'none'",
    "frame-ancestors 'none'",
    "form-action 'self'",
    "script-src 'self' 'unsafe-inline'",
    "style-src 'self' 'unsafe-inline'",
    "font-src 'self' data:",
    "img-src 'self' data: blob:",
    "connect-src 'self'",
    "media-src 'self' blob:",
    "worker-src 'self' blob:",
    "manifest-src 'self'",
))


@app.after_request
def _apply_browser_security_headers(response):
    """Apply one gateway policy to pages, APIs, downloads and proxy responses."""
    response.headers["Content-Security-Policy"] = _BROWSER_CSP
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Cross-Origin-Opener-Policy"] = "same-origin"
    response.headers["Cross-Origin-Resource-Policy"] = "same-origin"
    path = request.path
    if path.startswith(("/api/", "/8000/", "/8088/")):
        response.headers["Cache-Control"] = "no-store"
    elif request.endpoint in {"index_page", "chat_page", "frontend_asset", "frontend_legacy_page"}:
        # Revalidate locally; content-versioned links also separate releases.
        # Never let a cached old HTML silently request an incompatible asset set.
        response.headers["Cache-Control"] = "no-cache"
    if os.getenv("APP_ENV", "production").strip().lower() not in _NON_PRODUCTION_APP_ENVS:
        # Browsers ignore HSTS received over plain HTTP; a TLS terminator forwards
        # this header without requiring untrusted X-Forwarded-* interpretation.
        response.headers["Strict-Transport-Security"] = "max-age=31536000"
    return response

# The 5000 account UI must also work as a standalone deployment.  The
# validated research Flask app is loaded lazily and dispatched in-process,
# avoiding a hard dependency on a separately running 5050 listener.  Set
# SCIASSISTANT_WEB_BASE to an http(s) URL only when an external research
# service is intentionally desired.
_LOCAL_SCIENCE_APP = None
_LOCAL_SCIENCE_APP_LOCK = __import__("threading").Lock()
_SCIENCE_TASK_OWNERS: dict[str, str] = {}
_CONTEXT_FILE_OWNERS: dict[str, str] = {}
_RESOURCE_OWNER_LOCK = threading.Lock()
SCIENCE_TASK_OWNER_STATE_PATH = Path(
    os.getenv("SCIASSISTANT_TASK_OWNER_STATE_PATH", str(LOG_DIR / "science_task_owners.json"))
)
SCIENCE_TASK_STATE_DIR = Path(
    os.getenv("SCIASSISTANT_TASK_STATE_DIR", str(LOG_DIR / "task_state"))
)
CONTEXT_FILE_OWNER_STATE_PATH = Path(
    os.getenv("SCIASSISTANT_CONTEXT_FILE_OWNER_STATE_PATH", str(LOG_DIR / "context_file_owners.json"))
)
PDF_SESSION_STATE_PATH = Path(os.getenv(
    "SCIASSISTANT_PDF_SESSION_STATE_PATH", str(LOG_DIR / "pdf_sessions.sqlite3")
))
RESEARCH_LIBRARY_STATE_PATH = Path(os.getenv(
    "SCIASSISTANT_RESEARCH_LIBRARY_STATE_PATH", str(LOG_DIR / "research_library.sqlite3")
))


def _persist_science_task_owners_locked() -> None:
    """Atomically retain task ownership across a 5000 restart, without JWTs."""
    try:
        SCIENCE_TASK_OWNER_STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
        temporary = SCIENCE_TASK_OWNER_STATE_PATH.with_suffix(".tmp")
        temporary.write_text(
            json.dumps(_SCIENCE_TASK_OWNERS, ensure_ascii=False, sort_keys=True),
            encoding="utf-8",
        )
        os.replace(temporary, SCIENCE_TASK_OWNER_STATE_PATH)
    except OSError:
        # Retain fail-closed in-memory behavior when local storage is unhealthy.
        return


def _restore_science_task_owners() -> int:
    """Load valid persisted ownership bindings; corrupted data grants nothing."""
    try:
        # Windows editors/PowerShell can add a UTF-8 BOM during an authorized
        # restore. Accept that encoding marker, not malformed JSON or claims.
        payload = json.loads(SCIENCE_TASK_OWNER_STATE_PATH.read_text(encoding="utf-8-sig"))
    except FileNotFoundError:
        return 0
    except (OSError, TypeError, ValueError, json.JSONDecodeError) as exc:
        logger.warning("恢复科研任务归属失败: %s", type(exc).__name__)
        return 0
    if not isinstance(payload, dict):
        return 0
    restored = {
        str(task_id): str(owner)
        for task_id, owner in payload.items()
        if re.fullmatch(r"[A-Za-z0-9_-]{1,128}", str(task_id or ""))
        and str(owner or "").strip()
    }
    with _RESOURCE_OWNER_LOCK:
        _SCIENCE_TASK_OWNERS.update(restored)
    return len(restored)


def _recover_science_task_owner_from_snapshot(task_id: str, user_id: str) -> bool:
    """Recover a missing binding from server state plus authoritative chat ownership.

    A conversation message UUID is client-writable and is therefore not enough
    to claim a task.  The server-created task snapshot must name a conversation,
    and ``chat_list`` must assign that conversation to the authenticated user.
    Existing (including conflicting) owner bindings are never overwritten.
    """
    task_id = str(task_id or "")
    user_id = str(user_id or "")
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", task_id) or not user_id.strip():
        return False
    path = SCIENCE_TASK_STATE_DIR / f"{task_id}.json"
    try:
        if not path.is_file() or not 0 < path.stat().st_size <= 5_000_000:
            return False
        task = json.loads(path.read_text(encoding="utf-8"))
        conversation_id = str(task.get("conversation_id") or "") if isinstance(task, dict) else ""
        if task.get("id") != task_id or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", conversation_id):
            return False
    except (OSError, TypeError, ValueError, json.JSONDecodeError):
        return False

    connection = None
    try:
        connection = get_db_connection()
        if not connection:
            return False
        with connection.cursor() as cursor:
            owned = _session_owned(cursor, conversation_id, user_id)
    except Exception as exc:
        logger.warning("恢复科研任务归属失败: %s", type(exc).__name__)
        return False
    finally:
        if connection:
            connection.close()
    if not owned:
        return False

    with _RESOURCE_OWNER_LOCK:
        existing = _SCIENCE_TASK_OWNERS.get(task_id)
        if existing is not None:
            return existing == user_id
        _SCIENCE_TASK_OWNERS[task_id] = user_id
        _persist_science_task_owners_locked()
    return True


def _persist_context_file_owners_locked() -> None:
    """Atomically retain temporary-context ownership across a 5000 restart."""
    try:
        CONTEXT_FILE_OWNER_STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
        temporary = CONTEXT_FILE_OWNER_STATE_PATH.with_suffix(".tmp")
        temporary.write_text(
            json.dumps(_CONTEXT_FILE_OWNERS, ensure_ascii=False, sort_keys=True),
            encoding="utf-8",
        )
        os.replace(temporary, CONTEXT_FILE_OWNER_STATE_PATH)
    except OSError:
        # Fail closed after a restart if the owner store cannot be written.
        return


def _restore_context_file_owners() -> int:
    """Load valid temporary-context owner bindings; malformed data grants nothing."""
    try:
        payload = json.loads(CONTEXT_FILE_OWNER_STATE_PATH.read_text(encoding="utf-8-sig"))
    except FileNotFoundError:
        return 0
    except (OSError, TypeError, ValueError, json.JSONDecodeError) as exc:
        logger.warning("恢复临时文件归属失败: %s", type(exc).__name__)
        return 0
    if not isinstance(payload, dict):
        return 0
    restored = {
        str(file_id): str(owner)
        for file_id, owner in payload.items()
        if re.fullmatch(r"[A-Za-z0-9_-]{1,128}", str(file_id or ""))
        and str(owner or "").strip()
    }
    with _RESOURCE_OWNER_LOCK:
        _CONTEXT_FILE_OWNERS.update(restored)
    return len(restored)


_restore_science_task_owners()
_restore_context_file_owners()


def _local_science_app():
    global _LOCAL_SCIENCE_APP
    if _LOCAL_SCIENCE_APP is None:
        with _LOCAL_SCIENCE_APP_LOCK:
            if _LOCAL_SCIENCE_APP is None:
                from web_app import app as science_app
                _LOCAL_SCIENCE_APP = science_app
    return _LOCAL_SCIENCE_APP


def _dispatch_local_science(target_path: str):
    """Dispatch a research request directly to web_app in this process."""
    client = _local_science_app().test_client()
    headers = {
        key: value for key, value in request.headers
        if key.lower() not in HOP_BY_HOP_HEADERS
        and key.lower() not in {"host", "x-request-id"}
    }
    # The in-process science service receives the same opaque trace ID as the
    # gateway so one browser/API request can be followed without logging its
    # query string, token, cookie, or raw request body.
    request_id = str(getattr(g, "request_id", "") or "")
    if request_id:
        headers["X-Request-ID"] = request_id
    response = client.open(
        path="/" + target_path.lstrip("/"),
        method=request.method,
        query_string=request.args,
        data=request.get_data(),
        headers=headers,
        # Only the gateway can create this in-process capability. An HTTP
        # header/body field is never treated as permission to reuse a PDF.
        environ_overrides={"sciassistant.pdf_source": getattr(g, "science_pdf_source", None),
                          "sciassistant.library_source": getattr(g, "science_library_source", None),
                          "sciassistant.provider_credentials": getattr(g, "science_provider_credentials", None)},
    )
    response_headers = [
        (key, value) for key, value in response.headers.items()
        if key.lower() not in HOP_BY_HOP_HEADERS
    ]
    return response.get_data(), response.status_code, response_headers

# JWT configuration.
# A process-local random fallback makes every restart invalidate all existing
# JWTs and makes multi-process deployments unable to verify one another.  A
# deployment must therefore configure one stable, private value explicitly.
_INSECURE_SECRET_KEY_VALUES = frozenset({
    "change-me",
    "changeme",
    "secret",
    "your-secret-key",
    "your_secret_key",
})
_NON_PRODUCTION_APP_ENVS = frozenset({"development", "dev", "test", "testing"})


def _configured_secret_key() -> str:
    """Read one stable JWT signing key and reject unsafe production defaults."""
    environment = os.getenv("APP_ENV", "production").strip().lower()
    secret_key = (os.getenv("SECRET_KEY") or "").strip()
    insecure_value = not secret_key or secret_key.lower() in _INSECURE_SECRET_KEY_VALUES
    if insecure_value and environment not in _NON_PRODUCTION_APP_ENVS:
        raise RuntimeError(
            "生产环境必须设置一个非示例值的 SECRET_KEY；"
            "拒绝使用缺失、随机或 change-me 密钥启动。"
        )
    if insecure_value:
        logger.warning(
            "APP_ENV=%s 正在使用开发/测试 SECRET_KEY 示例值；"
            "不得将此配置部署到生产环境。",
            environment,
        )
    return secret_key


app.config['SECRET_KEY'] = _configured_secret_key()


def _bounded_positive_env(name: str, default: int, minimum: int, maximum: int) -> int:
    try:
        value = int(os.getenv(name, str(default)))
    except (TypeError, ValueError) as exc:
        raise RuntimeError(f"{name} 必须是整数。") from exc
    if not minimum <= value <= maximum:
        raise RuntimeError(f"{name} 超出允许范围。")
    return value


_AUTH_LIMITS = {
    "login": {
        "identity": _bounded_positive_env("AUTH_LOGIN_IDENTITY_LIMIT", 8, 1, 1000),
        "client": _bounded_positive_env("AUTH_LOGIN_CLIENT_LIMIT", 30, 1, 5000),
        "window": _bounded_positive_env("AUTH_LOGIN_WINDOW_SECONDS", 300, 10, 86400),
    },
    "register": {
        "identity": _bounded_positive_env("AUTH_REGISTER_IDENTITY_LIMIT", 3, 1, 1000),
        "client": _bounded_positive_env("AUTH_REGISTER_CLIENT_LIMIT", 15, 1, 5000),
        "window": _bounded_positive_env("AUTH_REGISTER_WINDOW_SECONDS", 3600, 10, 86400),
    },
    "password_reset_request": {
        "identity": _bounded_positive_env("AUTH_RESET_REQUEST_IDENTITY_LIMIT", 3, 1, 100),
        "client": _bounded_positive_env("AUTH_RESET_REQUEST_CLIENT_LIMIT", 10, 1, 500),
        "window": _bounded_positive_env("AUTH_RESET_REQUEST_WINDOW_SECONDS", 900, 60, 86400),
    },
    "password_reset_confirm": {
        "identity": _bounded_positive_env("AUTH_RESET_CONFIRM_IDENTITY_LIMIT", 5, 1, 100),
        "client": _bounded_positive_env("AUTH_RESET_CONFIRM_CLIENT_LIMIT", 20, 1, 500),
        "window": _bounded_positive_env("AUTH_RESET_CONFIRM_WINDOW_SECONDS", 900, 60, 86400),
    },
}
_AUTH_RATE_LIMITER = SlidingWindowLimiter(
    max_keys=_bounded_positive_env("AUTH_RATE_LIMIT_MAX_KEYS", 10_000, 100, 1_000_000)
)


def _opaque_auth_limit_key(scope: str, dimension: str, value: object) -> str:
    normalized = str(value or "unknown").strip().lower()[:512]
    digest = hmac.new(
        app.config["SECRET_KEY"].encode("utf-8"),
        f"{scope}:{dimension}:{normalized}".encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    return f"{scope}:{dimension}:{digest}"


def _enforce_auth_rate_limit(scope: str, identity: object):
    policy = _AUTH_LIMITS[scope]
    specifications = (
        (_opaque_auth_limit_key(scope, "identity", identity), policy["identity"], policy["window"]),
        (_opaque_auth_limit_key(scope, "client", request.remote_addr), policy["client"], policy["window"]),
    )
    allowed, retry_after = _AUTH_RATE_LIMITER.check_and_record(specifications)
    if allowed:
        return None
    response = jsonify({
        "success": False,
        "error": "RATE_LIMITED",
        "message": "请求过于频繁，请稍后重试。",
    })
    response.status_code = 429
    response.headers["Retry-After"] = str(retry_after)
    return response

# Database configuration.
DB_CONFIG = {
    'host': MYSQL_HOST,
    'user': MYSQL_USER,#标，需现场俔适配数据库用户名密码
    'password': MYSQL_PASSWORD,
    'db': MYSQL_DATABASE,
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

# Database connection factory.
def get_db_connection():
    """Create a database connection."""
    connection = pymysql.connect(**DB_CONFIG)
    return connection


FRONTEND_DIR = Path(__file__).parent / "chatAi"
HOP_BY_HOP_HEADERS = {
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailers",
    "transfer-encoding",
    "upgrade",
}


@app.route("/")
def index_page():
    return send_from_directory(FRONTEND_DIR, "login.html")


@app.route("/chat")
def chat_page():
    return send_from_directory(FRONTEND_DIR, "ai_chat.html")


@app.route("/chatAi/<path:filename>")
def frontend_asset(filename):
    return send_from_directory(FRONTEND_DIR, filename)


@app.route("/<path:filename>")
def frontend_legacy_page(filename):
    if filename in {"login.html", "register.html", "forgot-password.html", "ai_chat.html"}:
        return send_from_directory(FRONTEND_DIR, filename)
    if filename.startswith("images/"):
        return send_from_directory(FRONTEND_DIR, filename)
    abort(404)


def _proxy_request(
    target_base: str,
    target_path: str,
    extra_headers: Optional[dict] = None,
    body_override: Optional[bytes] = None,
    excluded_request_headers: Optional[set[str]] = None,
):
    if (
        not target_path
        or "\\" in target_path
        or any(segment in {"", ".", ".."} for segment in target_path.split("/"))
        or any(ord(character) < 32 for character in target_path)
        or "://" in target_path
    ):
        return jsonify({
            "success": False,
            "error": "INVALID_UPSTREAM_PATH",
            "message": "请求路径无效。",
        }), 400
    excluded_headers = {header.lower() for header in (excluded_request_headers or set())}
    target_url = f"{target_base.rstrip('/')}/{target_path.lstrip('/')}"
    headers = {
        key: value
        for key, value in request.headers
        if key.lower() not in HOP_BY_HOP_HEADERS
        and key.lower() != "host"
        and key.lower() != "x-request-id"
        and key.lower() not in excluded_headers
    }
    # Upstreams receive the gateway-generated ID, never an invalid client
    # header.  This keeps a remote research deployment correlated with its
    # gateway request without forwarding credentials or request contents.
    request_id = str(getattr(g, "request_id", "") or "")
    if request_id:
        headers["X-Request-ID"] = request_id
    if extra_headers:
        headers.update(extra_headers)
    try:
        upstream = http_requests.request(
            method=request.method,
            url=target_url,
            params=request.args,
            data=body_override if body_override is not None else request.get_data(),
            headers=headers,
            timeout=int(os.getenv("PROXY_TIMEOUT", "600")),
            stream=False,
            allow_redirects=False,
        )
    except http_requests.RequestException as exc:
        # ``target_base`` and a requests exception can contain private DNS
        # names, ports, paths, or credentials. Keep both the client response
        # and routine log metadata-free; operators can correlate the time,
        # method and exception class with protected infrastructure logs.
        logger.warning("Proxy upstream unavailable: method=%s error_type=%s", request.method, type(exc).__name__)
        return jsonify({
            "success": False,
            "error": "UPSTREAM_UNAVAILABLE",
            "message": "所需服务暂时不可用，请稍后重试。",
        }), 503

    if 300 <= upstream.status_code < 400:
        logger.warning("Proxy upstream redirect rejected: method=%s", request.method)
        return jsonify({
            "success": False,
            "error": "UPSTREAM_REDIRECT_REJECTED",
            "message": "上游服务返回了不允许的重定向。",
        }), 502

    response_headers = [
        (key, value)
        for key, value in upstream.headers.items()
        if key.lower() not in HOP_BY_HOP_HEADERS
    ]
    return upstream.content, upstream.status_code, response_headers


def _validated_upstream_base(raw_value: str, *, local_only: bool) -> str:
    """Validate configured proxy bases without DNS resolution or value echo."""
    value = str(raw_value or "").strip().rstrip("/")
    try:
        parsed = urlsplit(value)
        parsed.port
    except ValueError as exc:
        raise RuntimeError("UPSTREAM_CONFIGURATION_INVALID") from exc
    valid = (
        parsed.scheme in {"http", "https"}
        and bool(parsed.hostname)
        and parsed.username is None
        and parsed.password is None
        and not parsed.query
        and not parsed.fragment
    )
    try:
        address = ipaddress.ip_address(parsed.hostname or "")
    except ValueError:
        address = None
    if local_only:
        valid = (
            valid
            and parsed.scheme == "http"
            and isinstance(address, ipaddress.IPv4Address)
            and address.is_loopback
            and parsed.path in {"", "/"}
        )
    else:
        secure_remote = parsed.scheme == "https" and (
            address is None or (address.is_global and not address.is_reserved)
        )
        local_http = (
            parsed.scheme == "http"
            and isinstance(address, ipaddress.IPv4Address)
            and address.is_loopback
        )
        valid = valid and (secure_remote or local_http)
    if not valid:
        raise RuntimeError("UPSTREAM_CONFIGURATION_INVALID")
    return value


def _proxy_configuration_failure():
    return jsonify({
        "success": False,
        "error": "UPSTREAM_CONFIGURATION_INVALID",
        "message": "上游服务配置无效。",
    }), 503


@app.route("/8000/<path:target_path>", methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"])
def proxy_deepdiver(target_path):
    """Retain an explicit retirement response, not a shared-account backdoor."""
    auth_failure = _authenticate_current_request()
    if auth_failure is not None:
        return auth_failure
    # This independent legacy process cannot receive a trusted tenant scope.
    # It must not expose shared files or spend another account's provider keys.
    return jsonify(error="LEGACY_SERVICE_NOT_USER_ISOLATED",
                   message="旧独立服务不支持用户隔离，请使用科研任务和我的科研资料库。"), 410


@app.route("/8088/<path:target_path>", methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"])
def proxy_model(target_path):
    """Proxy the legacy Chat/Reasoner model endpoint.

    Chat and Reasoner are no longer front-end modes, but their endpoint is
    retained for historical conversation replay, compatibility with older
    clients, and a controlled rollback while the unified research modes are
    being adopted. New code should call the research task API instead of
    depending on this route. Do not remove it until old clients and stored
    integrations have been explicitly retired.
    """
    auth_failure = _authenticate_current_request()
    if auth_failure is not None:
        return auth_failure
    model_base = os.getenv("CHAT_API_BASE")
    model_url = os.getenv("MODEL_REQUEST_URL")
    if not model_base and model_url:
        suffix = "/v1/chat/completions"
        model_base = model_url[:-len(suffix)] if model_url.endswith(suffix) else model_url
    if not model_base:
        return jsonify({
            "error": {
                "message": "未配置 CHAT_API_BASE 或 MODEL_REQUEST_URL，无法转发 Chat/Reasoner 模型请求。"
            }
        }), 503
    try:
        model_base = _validated_upstream_base(model_base, local_only=False)
    except RuntimeError:
        return _proxy_configuration_failure()
    extra_headers = {}
    try:
        model_token = _provider_store().capability(g.current_user_id).values['MODEL_REQUEST_TOKEN']
    except (OSError, ValueError, sqlite3.Error):
        return jsonify(error="USER_CREDENTIALS_UNAVAILABLE", message="账号密钥暂不可用。"), 503
    if not model_token:
        return jsonify(error="USER_PROVIDER_KEY_REQUIRED", message="请先在“我的 API Keys”填写自己的 DeepSeek 密钥。"), 428
    # The incoming Authorization header is the account JWT.  It must not be
    # forwarded or mistaken for the model provider credential.
    if model_token:
        extra_headers["Authorization"] = f"Bearer {model_token}"
    body_override = None
    model_name = os.getenv("MODEL_NAME")
    if model_name and target_path.strip("/") == "v1/chat/completions" and request.is_json:
        payload = request.get_json(silent=True) or {}
        if isinstance(payload, dict):
            payload["model"] = model_name
            body_override = jsonify(payload).get_data()
    return _proxy_request(
        model_base,
        target_path,
        extra_headers=extra_headers,
        body_override=body_override,
        excluded_request_headers={
            "authorization", "origin", "referer", "cookie",
            "x-forwarded-for", "x-real-ip",
        },
    )


# The account/chat prototype can host the research UI without duplicating the
# validated SciAssistant task implementation. These routes are deliberately
# namespaced so the existing Chat/Reasoner and DeepDiver APIs keep their old
# behavior. The target service owns task state and evidence diagnostics.
def _science_web_base() -> str:
    return os.getenv("SCIASSISTANT_WEB_BASE", "").rstrip("/")


def _science_dispatch(target_path: str):
    """Use the local research app by default; support an explicit remote URL."""
    base = _science_web_base()
    if base:
        return _proxy_request(base, target_path)
    return _dispatch_local_science(target_path)


def _auth_error(message: str, status: int):
    return jsonify({'success': False, 'error': message}), status


def _current_auth_version(user_id: str) -> int | None:
    """Return the authoritative login generation for one existing user."""
    connection = None
    try:
        connection = get_db_connection()
        with connection.cursor() as cursor:
            cursor.execute(
                "SELECT auth_version FROM users WHERE id = %s LIMIT 1",
                (user_id,),
            )
            row = cursor.fetchone()
        if not row:
            return None
        value = row.get('auth_version') if isinstance(row, dict) else row[0]
        if isinstance(value, bool):
            return None
        try:
            version = int(value)
        except (TypeError, ValueError, OverflowError):
            return None
        return version if version >= 0 else None
    finally:
        if connection:
            connection.close()


def _authenticate_current_request():
    """Populate ``g`` from the Bearer JWT or return a JSON 401 response."""
    header = request.headers.get('Authorization', '')
    scheme, _, token = header.partition(' ')
    if scheme.lower() != 'bearer' or not token.strip():
        return _auth_error('需要登录后访问此资源', 401)
    try:
        claims = jwt.decode(token.strip(), app.config['SECRET_KEY'], algorithms=['HS256'])
        user_id = claims.get('user_id')
        if user_id is None or str(user_id).strip() == '':
            raise jwt.InvalidTokenError('missing user_id')
        token_auth_version = claims.get('auth_version', 0)
        if isinstance(token_auth_version, bool):
            raise jwt.InvalidTokenError('invalid auth_version')
        token_auth_version = int(token_auth_version)
        if token_auth_version < 0:
            raise jwt.InvalidTokenError('invalid auth_version')
    except jwt.ExpiredSignatureError:
        return _auth_error('登录已过期，请重新登录', 401)
    except (jwt.InvalidTokenError, TypeError, ValueError, OverflowError):
        return _auth_error('登录凭证无效，请重新登录', 401)
    try:
        current_auth_version = _current_auth_version(str(user_id))
    except pymysql.MySQLError as exc:
        logger.warning("JWT 版本校验数据库操作失败: %s", type(exc).__name__)
        return _auth_error('认证服务暂时不可用，请稍后重试', 503)
    if current_auth_version is None or token_auth_version != current_auth_version:
        return _auth_error('登录凭证已失效，请重新登录', 401)
    g.current_user_id = str(user_id)
    g.current_username = str(claims.get('username') or '')
    g.current_auth_version = token_auth_version
    return None


def require_auth(func):
    """Require a valid Bearer JWT and expose its identity through ``g``."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        auth_failure = _authenticate_current_request()
        if auth_failure is not None:
            return auth_failure
        return func(*args, **kwargs)
    return wrapper


def _provider_store():
    return CredentialStore(os.getenv('SCIASSISTANT_USER_CREDENTIAL_DB', str(LOG_DIR / 'user_credentials.sqlite3')),
                           os.getenv('USER_CREDENTIAL_ENCRYPTION_KEY') or app.config['SECRET_KEY'])


@app.route('/api/account/provider-keys', methods=['GET', 'POST'])
@require_auth
def account_provider_keys():
    try:
        store = _provider_store()
        if request.method == 'GET':
            return jsonify(store.status(store.capability(g.current_user_id)))
        if request.content_length and request.content_length > 16_384:
            return jsonify(error='PROVIDER_SETTINGS_TOO_LARGE'), 413
        result = store.update(g.current_user_id, request.get_json(silent=True))
        return jsonify(result)
    except ValueError as exc:
        code = str(exc) if str(exc) in {'INVALID_PROVIDER_KEY', 'INVALID_PROVIDER_SETTINGS'} else 'USER_CREDENTIALS_UNAVAILABLE'
        return jsonify(error=code, message='密钥格式无效。' if code.startswith('INVALID_') else '账号密钥存储暂不可用。'), 400 if code.startswith('INVALID_') else 503
    except (OSError, sqlite3.Error):
        return jsonify(error='USER_CREDENTIALS_UNAVAILABLE', message='账号密钥存储暂不可用。'), 503


def _remember_science_task_owner(response, user_id: str) -> None:
    """Bind a newly created in-memory research task to its JWT owner."""
    try:
        body = response[0] if isinstance(response, tuple) else response.get_data()
        payload = json.loads(body.decode('utf-8') if isinstance(body, bytes) else body)
        task = payload.get('task') if isinstance(payload, dict) else None
        task_id = (task or {}).get('id') if isinstance(task, dict) else None
        if task_id:
            with _RESOURCE_OWNER_LOCK:
                _SCIENCE_TASK_OWNERS[str(task_id)] = str(user_id)
                _persist_science_task_owners_locked()
    except (AttributeError, TypeError, ValueError, json.JSONDecodeError):
        # Creation failures and non-JSON upstream responses cannot expose a
        # task ID; leave them unbound rather than granting access implicitly.
        return


def _require_science_task_owner(task_id: str) -> None:
    with _RESOURCE_OWNER_LOCK:
        owner = _SCIENCE_TASK_OWNERS.get(str(task_id))
    current_user = str(g.current_user_id)
    if owner == current_user:
        return
    if owner is None and _recover_science_task_owner_from_snapshot(task_id, current_user):
        return
    if owner != current_user:
        abort(404)


def _request_science_conversation_id() -> str:
    payload = request.get_json(silent=True)
    if isinstance(payload, dict):
        return str(payload.get("conversation_id") or "").strip()
    return str(request.form.get("conversation_id") or "").strip()


def _require_science_conversation_owner(conversation_id: str) -> None:
    """Prevent new task snapshots from naming another account's chat."""
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", conversation_id):
        abort(404)
    connection = None
    try:
        connection = get_db_connection()
        with connection.cursor() as cursor:
            owned = _session_owned(cursor, conversation_id, g.current_user_id)
    except Exception as exc:
        logger.warning("检查科研任务会话归属失败: %s", type(exc).__name__)
        abort(404)
    finally:
        if connection:
            connection.close()
    if not owned:
        abort(404)


def _pdf_sessions():
    from science_pdf_sessions import PdfSessions
    return PdfSessions(PDF_SESSION_STATE_PATH)


def _owned_pdf_source(task_id: str, conversation_id: str):
    """Require both authoritative task ownership and the exact conversation."""
    from science_pdf_sessions import pdf_path
    if not re.fullmatch(r"[0-9a-f]{12}", task_id):
        abort(404)
    _require_science_task_owner(task_id)
    root = SCIENCE_TASK_STATE_DIR.resolve()
    path = root / f"{task_id}.json"
    try:
        if path.is_symlink() or path.resolve().parent != root or not 0 < path.stat().st_size <= 5_000_000:
            raise ValueError
        snapshot = json.loads(path.read_text(encoding="utf-8-sig"))
        if snapshot.get("id") != task_id or snapshot.get("conversation_id") != conversation_id:
            raise ValueError
        attachment = snapshot.get("pdf_attachment")
        if not isinstance(attachment, dict) or attachment.get("source_task_id") != task_id:
            raise ValueError
        # Original PDF tasks own the file. A reused task points back to this
        # original task, not an arbitrary path or unbounded reference chain.
        if snapshot.get("processing_mode") not in {"pdf_local", "multi_agent_rag"}:
            raise ValueError
        import web_app as science
        pdf_path(science.UPLOAD_DIR, task_id, attachment.get("filename"))
        result = {"source_task_id": task_id, "filename": attachment["filename"]}
        if snapshot.get("library_file_id"):
            result["library_file_id"] = snapshot["library_file_id"]
        return result
    except (OSError, ValueError, TypeError, AttributeError):
        abort(404)


@app.route('/api/science/conversations/<conversation_id>/pdf-attachment', methods=['GET', 'DELETE'])
@require_auth
def science_pdf_attachment(conversation_id):
    _require_science_conversation_owner(conversation_id)
    if _science_web_base():
        return jsonify(error="PDF_REUSE_UNAVAILABLE", message="当前独立科研服务暂不支持会话 PDF 复用。"), 503
    try:
        store = _pdf_sessions()
        if request.method == "DELETE":
            store.reserve(g.current_user_id, conversation_id, detach=True)
            return jsonify(attachment=None)
        source = store.get(g.current_user_id, conversation_id)
        return jsonify(attachment=_owned_pdf_source(source, conversation_id) if source else None)
    except (OSError, sqlite3.Error):
        return jsonify(error="PDF_SESSION_UNAVAILABLE", message="会话 PDF 状态暂不可用，请稍后重试。"), 503


@app.route('/api/science/tasks', methods=['POST'])
@require_auth
def proxy_science_task_create():
    """Create a research task without requiring a separate 5050 process."""
    # Cache the raw request before inspecting ``request.form`` below.  Flask
    # consumes a multipart stream while parsing the form; the in-process
    # dispatch must receive the same bytes, including the query and PDF.
    request.get_data(cache=True)
    conversation_id = _request_science_conversation_id()
    if conversation_id:
        _require_science_conversation_owner(conversation_id)
    payload = request.get_json(silent=True)
    parent_task_id = str((payload.get("parent_task_id") if isinstance(payload, dict)
                          else request.form.get("parent_task_id")) or "").strip()
    if parent_task_id:
        _require_science_task_owner(parent_task_id)
    source_id = str((payload.get("pdf_source_task_id") if isinstance(payload, dict)
                     else request.form.get("pdf_source_task_id")) or "").strip()
    processing_mode = (payload.get("processing_mode") if isinstance(payload, dict)
                       else request.form.get("processing_mode"))
    if processing_mode in {'literature_answer', 'multi_agent_literature', 'arxiv_paper'}:
        return jsonify(error='LEGACY_MODE_NOT_USER_ISOLATED',
                       message='旧共享科研链路暂不接受新任务；请使用新版多智能体 RAG。历史报告仍可查看。'), 410
    library_id = (payload.get("library_file_id") if isinstance(payload, dict)
                  else request.form.get("library_file_id"))
    if library_id is not None:
        if (not isinstance(library_id, str) or not library_id or source_id
                or request.files.get("pdf") or processing_mode not in {"multi_agent_rag", "multi_agent_pdf"}):
            return jsonify(error="INVALID_LIBRARY_SELECTION", message="请选择一篇资料库 PDF，不能同时复用或上传其他文件。"), 400
        if _science_web_base():
            return jsonify(error="LIBRARY_SOURCE_UNAVAILABLE", message="独立科研服务尚不支持资料库选用。"), 503
        row = _library_owned_file(library_id)
        try:
            from research_library import original_path
            from multi_agent_local_pdf import validate_pdf_input
            if str(row.get("original_filename") or "").rsplit('.', 1)[-1].lower() != "pdf":
                raise ValueError
            path = validate_pdf_input(original_path(UPLOAD_BASE_DIR, g.current_user_id, row))
        except FileNotFoundError:
            abort(404)
        except (OSError, ValueError):
            return jsonify(error="INVALID_LIBRARY_PDF", message="PDF 无效或超过 30MiB，尚未创建分析任务。"), 400
        g.science_library_source = {"file_id": library_id, "path": path,
                                   "filename": safe_filename_unicode(row["original_filename"])}
    if source_id:
        if not conversation_id or processing_mode not in {"pdf_local", "multi_agent_rag", "multi_agent_pdf"} or request.files.get("pdf"):
            return jsonify(error="INVALID_PDF_REUSE", message="复用 PDF 需要同一会话和 PDF 模式，不能同时上传新文件。"), 400
        if _science_web_base():
            return jsonify(error="PDF_REUSE_UNAVAILABLE", message="当前独立科研服务暂不支持会话 PDF 复用。"), 503
        g.science_pdf_source = _owned_pdf_source(source_id, conversation_id)
    generation = None
    if conversation_id and (request.files.get("pdf") or library_id) and not _science_web_base():
        try:
            generation = _pdf_sessions().reserve(g.current_user_id, conversation_id)
        except (OSError, sqlite3.Error):
            return jsonify(error="PDF_SESSION_UNAVAILABLE", message="会话 PDF 状态暂不可用，请稍后重试。"), 503
    if _science_web_base():
        return jsonify(error='TENANT_DISPATCH_UNAVAILABLE', message='独立远端科研服务尚不支持本批账号密钥隔离。'), 503
    try:
        g.science_provider_credentials = _provider_store().capability(g.current_user_id)
    except (OSError, ValueError, sqlite3.Error):
        return jsonify(error='USER_CREDENTIALS_UNAVAILABLE', message='账号密钥暂不可用，未创建任务。'), 503
    response = _science_dispatch("/api/tasks")
    _remember_science_task_owner(response, g.current_user_id)
    # A link is metadata, never authority to access the task or its PDF.
    try:
        raw = response[0] if isinstance(response, tuple) else response.get_data()
        created_task = json.loads(raw).get("task", {})
        linked_file = created_task.get("library_file_id")
        if linked_file and created_task.get("id"):
            _library_links().link(g.current_user_id, linked_file, created_task["id"], conversation_id or None)
    except (OSError, sqlite3.Error, ValueError, AttributeError, TypeError):
        logger.warning("科研资料库成果关联未完成")
    if generation is not None:
        try:
            raw = response[0] if isinstance(response, tuple) else response.get_data()
            task = json.loads(raw).get("task", {})
            attachment = task.get("pdf_attachment") or {}
            if (re.fullmatch(r"[0-9a-f]{12}", str(task.get("id") or ""))
                    and attachment.get("source_task_id") == task.get("id")):
                _pdf_sessions().bind(g.current_user_id, conversation_id, generation, task["id"])
        except (OSError, sqlite3.Error, ValueError, AttributeError, TypeError):
            # The task still exists and is owner-bound. Never claim that a
            # failed binding persisted; the UI will refresh this endpoint.
            logger.warning("会话 PDF 绑定未完成")
    return response


_TASK_LIST_STATUSES = frozenset({
    "queued", "running", "searching", "needs_clarification", "completed",
    "partial", "needs_review", "failed", "timed_out", "cancelled",
})


@app.route('/api/science/tasks', methods=['GET'])
@require_auth
def science_task_list():
    """Read-only, owner-first summaries; never discover tasks from a chat UUID.

    Files are selected only from authenticated bindings, not a global glob.
    The default in-process deployment shares snapshots with the gateway. An
    intentionally remote research service needs a shared snapshot mount.
    """
    from multi_agent_agents import sanitize_artifact_text
    if _science_web_base():
        return jsonify(error="TASK_LIST_UNAVAILABLE", message="独立科研服务暂不支持任务列表。"), 503
    try:
        limit = int(request.args.get("limit", "20"))
        offset = int(request.args.get("offset", "0"))
        if not 1 <= limit <= 25 or not 0 <= offset <= 100_000:
            raise ValueError
        status = request.args.get("status", "")
        mode = request.args.get("mode", "")
        if status and status not in _TASK_LIST_STATUSES:
            raise ValueError
        if mode and mode not in {"multi_agent_rag", "literature_answer", "multi_agent_literature",
                                 "arxiv_paper", "general_answer", "pdf_local", "pdf_cloud"}:
            raise ValueError
    except (TypeError, ValueError):
        return jsonify(error="INVALID_TASK_LIST_QUERY", message="任务列表参数无效。"), 400
    user_id = str(g.current_user_id)
    with _RESOURCE_OWNER_LOCK:
        ids = [key for key, owner in _SCIENCE_TASK_OWNERS.items()
               if owner == user_id and re.fullmatch(r"[0-9a-f]{12}", key)]
    # A small local deployment does not need a second database index. Bound
    # work explicitly rather than accidentally reading an unbounded archive.
    if len(ids) > 2000:
        return jsonify(error="TASK_LIST_LIMIT", message="任务归档过大，请通过任务链接访问。"), 503
    module = sys.modules.get("web_app")
    live = {}
    if module is not None:
        with module.TASK_LOCK:
            live = {key: dict(module.TASKS[key]) for key in ids if key in module.TASKS}
    records, unavailable = [], 0
    root = SCIENCE_TASK_STATE_DIR.resolve()
    for task_id in ids:
        path = root / f"{task_id}.json"
        try:
            if path.is_symlink() or path.resolve().parent != root:
                raise ValueError
            stamp = path.stat().st_mtime_ns if path.is_file() else 0
            if task_id not in live and not stamp:
                continue
            records.append((stamp, task_id, path))
        except (OSError, ValueError):
            unavailable += 1
    records.sort(reverse=True)
    # Scan a bounded window, returning a cursor even for corrupt/filtered rows.
    # This avoids reading every full task report just to render a list page.
    selected, read_bytes, scanned = [], 0, 0
    for _, task_id, path in records[offset:offset + 100]:
        if len(selected) == limit:
            break
        scanned += 1
        try:
            if task_id in live:
                task = live[task_id]
            else:
                size = path.stat().st_size
                if not 0 < size <= 5_000_000 or read_bytes + size > 25_000_000:
                    unavailable += 1
                    continue
                read_bytes += size
                task = json.loads(path.read_text(encoding="utf-8-sig"))
            if not isinstance(task, dict) or task.get("id") != task_id or task.get("status") not in _TASK_LIST_STATUSES:
                raise ValueError
            if status and task["status"] != status or mode and task.get("processing_mode") != mode:
                continue
            with _RESOURCE_OWNER_LOCK:
                if _SCIENCE_TASK_OWNERS.get(task_id) != user_id:
                    continue
            execution = task.get("execution") if isinstance(task.get("execution"), dict) else {}
            calls = execution.get("model_calls", 0)
            selected.append(sanitize_artifact_text({
                "id": task_id, "status": task["status"],
                "query": sanitize_artifact_text(str(task.get("query") or ""))[:500],
                "processing_mode": str(task.get("processing_mode") or "")[:50],
                "created_at": str(task.get("created_at") or "")[:40],
                "updated_at": str(task.get("updated_at") or "")[:40],
                "model_calls": calls if isinstance(calls, int) and not isinstance(calls, bool) and 0 <= calls <= 10 else 0,
                "report_available": task.get("report_available") is True,
                "evidence_available": True,
            }))
        except (OSError, TypeError, ValueError, json.JSONDecodeError):
            unavailable += 1
    following = offset + scanned
    return jsonify(schema_version="sciassistant.task-list/v1", tasks=selected,
                   total_owned=len(records), next_offset=following if following < len(records) else None,
                   unavailable_count=unavailable, read_only=True)


@app.route('/api/science/tasks/<task_id>', methods=['GET'])
@require_auth
def proxy_science_task_status(task_id):
    _require_science_task_owner(task_id)
    return _science_dispatch(f"/api/tasks/{task_id}")


@app.route('/api/science/tasks/<task_id>/clarify', methods=['POST'])
@require_auth
def proxy_science_task_clarify(task_id):
    _require_science_task_owner(task_id)
    # Only the retired shared-MCP chain has resumable clarification tasks.
    # Historical owner access is read-only; resuming would bypass create gates.
    return jsonify(error='LEGACY_MODE_NOT_USER_ISOLATED',
                   message='旧共享任务不再恢复执行；请在新版科研模式重新提交。历史报告仍可查看。'), 410

@app.route('/api/science/tasks/<task_id>/cancel', methods=['POST'])
@require_auth
def proxy_science_task_cancel(task_id):
    _require_science_task_owner(task_id)
    return _science_dispatch(f"/api/tasks/{task_id}/cancel")


@app.route('/api/science/tasks/<task_id>/export', methods=['GET'])
@require_auth
def proxy_science_task_export(task_id):
    """Proxy a completed research task's Markdown or PDF download."""
    _require_science_task_owner(task_id)
    return _science_dispatch(f"/api/tasks/{task_id}/export")


@app.route('/api/science/multi-agent/readyz', methods=['GET'])
@require_auth
def science_multi_agent_readiness():
    return _science_dispatch('/api/multi-agent/readyz')


@app.route('/api/science/tasks/<task_id>/report', methods=['GET'])
@require_auth
def science_multi_agent_report(task_id):
    _require_science_task_owner(task_id)
    return _science_dispatch(f'/api/tasks/{task_id}/report')


@app.route('/api/science/tasks/<task_id>/report/export', methods=['GET'])
@require_auth
def science_multi_agent_report_export(task_id):
    _require_science_task_owner(task_id)
    return _science_dispatch(f'/api/tasks/{task_id}/report/export')


@app.route('/api/science/tasks/<task_id>/report/assets/<path:name>', methods=['GET'])
@require_auth
def science_multi_agent_asset(task_id, name):
    _require_science_task_owner(task_id)
    return _science_dispatch(f'/api/tasks/{task_id}/report/assets/{name}')


@app.route('/api/science/tasks/<task_id>/evidence', methods=['GET'])
@require_auth
def proxy_science_task_evidence(task_id):
    """Proxy a secret-redacted acceptance evidence bundle for any task state."""
    _require_science_task_owner(task_id)
    return _science_dispatch(f"/api/tasks/{task_id}/evidence")


@app.route('/api/science/health', methods=['GET'])
def proxy_science_health():
    return _science_dispatch("/api/health")


@app.route('/api/science/readyz', methods=['GET'])
def proxy_science_readiness():
    """Expose research dependency readiness through the authenticated gateway host."""
    return _science_dispatch("/api/readyz")

#数据库理连接和异常
def _safe_internal_failure(operation: str, exc: Exception):
    """Return a stable error envelope without exposing exception details."""
    database_failure = isinstance(exc, pymysql.MySQLError)
    logger.error(
        "Gateway operation failed: operation=%s error_type=%s",
        operation,
        type(exc).__name__,
    )
    return jsonify({
        'success': False,
        'error': 'DATABASE_UNAVAILABLE' if database_failure else 'INTERNAL_ERROR',
        'message': ('数据库服务暂时不可用，请稍后重试。' if database_failure
                    else '服务器内部错误，请稍后重试。'),
    }), 503 if database_failure else 500


def db_operation(func):
    """Wrap database operations and close connections reliably."""

    @wraps(func)
    def wrapper(*args, **kwargs):
        connection = None
        try:
            connection = get_db_connection()
            result = func(connection, *args, **kwargs)
            return result
        except HTTPException:
            raise
        except Exception as exc:
            if connection:
                connection.rollback()
            return _safe_internal_failure(func.__name__, exc)
        finally:
            if connection:
                connection.close()

    return wrapper

# Password hashes created before the scrypt migration were unsalted SHA-256
# hex digests. Keep verification only so a successful login can upgrade the
# row; new or changed passwords must never be written in that legacy format.
PASSWORD_HASH_METHOD = "scrypt:32768:8:1"
PASSWORD_MAX_LENGTH = 1024
_LEGACY_PASSWORD_RE = re.compile(r"^[0-9a-f]{64}$")
_DUMMY_PASSWORD_HASH = generate_password_hash(
    "sciassistant-login-timing-placeholder",
    method=PASSWORD_HASH_METHOD,
)


def hash_password(password: str) -> str:
    """Create a salted, memory-hard password hash for database storage."""
    return generate_password_hash(password, method=PASSWORD_HASH_METHOD)


def _check_modern_password(password: str, stored_hash: str) -> bool:
    """Verify a supported modern hash, failing closed on malformed data."""
    if not stored_hash.startswith("scrypt:"):
        return False
    try:
        return check_password_hash(stored_hash, password)
    except (TypeError, ValueError):
        return False


def verify_password(password: str, stored_hash: object) -> tuple[bool, bool]:
    """Return ``(valid, needs_upgrade)`` without accepting unknown formats."""
    if not isinstance(stored_hash, str):
        check_password_hash(_DUMMY_PASSWORD_HASH, password)
        return False, False

    if stored_hash.startswith("scrypt:"):
        valid = _check_modern_password(password, stored_hash)
        method = stored_hash.split("$", 1)[0]
        return valid, valid and method != PASSWORD_HASH_METHOD

    if _LEGACY_PASSWORD_RE.fullmatch(stored_hash):
        legacy = hashlib.sha256(password.encode("utf-8")).hexdigest()
        valid = hmac.compare_digest(stored_hash, legacy)
        if not valid:
            # Keep legacy-account failures near the cost of a modern check.
            check_password_hash(_DUMMY_PASSWORD_HASH, password)
        return valid, valid

    check_password_hash(_DUMMY_PASSWORD_HASH, password)
    return False, False

#验证格式
def is_valid_email(email):
    """验证邮箱格式。"""
    pattern = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
    return re.match(pattern, email) is not None

#生成JWT令牌
def generate_token(user_id, username, auth_version=0, expire_hours=24):
    """Create a signed JWT with the configured expiration period."""

    expiration = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(hours=expire_hours)

    # 创建令牌
    token = jwt.encode({
        'user_id': user_id,
        'username': username,
        'auth_version': int(auth_version),
        'exp': expiration
    }, app.config['SECRET_KEY'], algorithm='HS256')

    return token


@app.route('/api/logout', methods=['POST'])
@require_auth
def logout_all_sessions():
    """Atomically revoke every JWT currently issued for this account."""
    connection = None
    try:
        connection = get_db_connection()
        with connection.cursor() as cursor:
            cursor.execute(
                "UPDATE users SET auth_version = auth_version + 1, updatetime = NOW() "
                "WHERE id = %s AND auth_version = %s",
                (g.current_user_id, g.current_auth_version),
            )
            if cursor.rowcount != 1:
                connection.rollback()
                return _auth_error('登录凭证已失效，请重新登录', 401)
        connection.commit()
        return jsonify({
            'success': True,
            'message': '已安全退出，所有已登录设备的凭证均已失效。',
        }), 200
    except pymysql.MySQLError as exc:
        if connection:
            connection.rollback()
        logger.warning("服务端退出数据库操作失败: %s", type(exc).__name__)
        return _auth_error('认证服务暂时不可用，请稍后重试', 503)
    finally:
        if connection:
            connection.close()


def convert_datetime_to_string(value):
    if isinstance(value, datetime.datetime):
        return value.strftime('%Y-%m-%d %H:%M:%S')
    return value


def _session_owned(cursor, session_id: str, user_id: str) -> bool:
    """Check the authoritative chat-list owner, not client supplied IDs."""
    cursor.execute(
        "SELECT 1 FROM chat_list WHERE session_id = %s AND user_id = %s LIMIT 1",
        (session_id, user_id),
    )
    return cursor.fetchone() is not None


def _require_session_owner(cursor, session_id: str) -> None:
    # Deliberately use 404 for another user's opaque ID so the API does not
    # become a session-existence oracle.
    if not _session_owned(cursor, session_id, g.current_user_id):
        abort(404)


def _require_requested_user_is_current(requested_user_id: str) -> None:
    if str(requested_user_id) != str(g.current_user_id):
        abort(404)


def _legacy_report_owned_by_current_user(report_id: str) -> bool:
    """Authorize legacy report exports through their persisted chat message."""
    connection = None
    try:
        connection = get_db_connection()
        with connection.cursor() as cursor:
            cursor.execute(
                """SELECT 1
                   FROM conversation_detail cd
                   JOIN chat_list cl ON cl.session_id = cd.session_id
                   WHERE cl.user_id = %s AND (cd.session_id = %s OR cd.uuid = %s)
                   LIMIT 1""",
                (g.current_user_id, report_id, report_id),
            )
            return cursor.fetchone() is not None
    except Exception as exc:
        logger.error("检查报告归属失败: %s", type(exc).__name__)
        return False
    finally:
        if connection:
            connection.close()


def _require_legacy_report_owner(report_id: str) -> None:
    if not _legacy_report_owned_by_current_user(report_id):
        abort(404)


# ------------------- 密码重置相关接口 -------------------
@app.route('/api/verify-credentials', methods=['POST'])
def verify_credentials():
    """Fail closed until an out-of-band, single-use reset channel exists."""
    return jsonify({
        'success': False,
        'error': 'PASSWORD_RESET_DISABLED',
        'message': '自助密码重置暂未启用，请联系管理员处理。',
    }), 503


@app.route('/api/reset-password', methods=['POST'])
def reset_password():
    """Never accept a client-supplied user ID as password-reset authority."""
    return jsonify({
        'success': False,
        'error': 'PASSWORD_RESET_DISABLED',
        'message': '自助密码重置暂未启用，请联系管理员处理。',
    }), 503


def _password_reset_config_or_response():
    try:
        config = load_reset_mail_config()
    except ResetConfigurationError:
        config = None
    if config is None or not config.enabled:
        return None, (jsonify({
            'success': False,
            'error': 'PASSWORD_RESET_DISABLED',
            'message': '自助密码重置暂未启用，请联系管理员处理。',
        }), 503)
    return config, None


@app.route('/api/password-reset/request', methods=['POST'])
def request_password_reset():
    """Send a generic response and deliver a single-use token out of band."""
    config, unavailable = _password_reset_config_or_response()
    if unavailable is not None:
        return unavailable
    data = request.get_json(silent=True) or {}
    email = data.get('email')
    if not isinstance(email, str) or not is_valid_email(email.strip()):
        return jsonify({'success': False, 'message': '邮箱格式不正确'}), 400
    email = email.strip().lower()
    limited = _enforce_auth_rate_limit("password_reset_request", email)
    if limited is not None:
        return limited

    generic = ({
        'success': True,
        'message': '如果该邮箱已注册，您将收到一封密码重置邮件。',
    }, 202)
    connection = None
    token_hash = None
    try:
        connection = get_db_connection()
        with connection.cursor() as cursor:
            cursor.execute("SELECT id, email FROM users WHERE email = %s LIMIT 1", (email,))
            user = cursor.fetchone()
            if not user:
                return jsonify(generic[0]), generic[1]
            token = secrets.token_urlsafe(32)
            token_hash = hashlib.sha256(token.encode('ascii')).hexdigest()
            cursor.execute(
                "UPDATE password_reset_tokens SET used_at = UTC_TIMESTAMP() "
                "WHERE user_id = %s AND used_at IS NULL",
                (user['id'],),
            )
            cursor.execute(
                "INSERT INTO password_reset_tokens "
                "(user_id, token_hash, expires_at, created_at) "
                "VALUES (%s, %s, DATE_ADD(UTC_TIMESTAMP(), INTERVAL %s SECOND), UTC_TIMESTAMP())",
                (user['id'], token_hash, config.token_ttl_seconds),
            )
            connection.commit()
        try:
            send_reset_email(config, user['email'], token)
        except Exception as exc:
            logger.warning("密码重置邮件发送失败: %s", type(exc).__name__)
            with connection.cursor() as cursor:
                cursor.execute(
                    "UPDATE password_reset_tokens SET used_at = UTC_TIMESTAMP() "
                    "WHERE token_hash = %s AND used_at IS NULL",
                    (token_hash,),
                )
                connection.commit()
    except pymysql.MySQLError as exc:
        if connection:
            connection.rollback()
        logger.warning("密码重置请求数据库操作失败: %s", type(exc).__name__)
    finally:
        if connection:
            connection.close()
    return jsonify(generic[0]), generic[1]


@app.route('/api/password-reset/confirm', methods=['POST'])
def confirm_password_reset():
    """Consume one valid token transactionally and store a modern hash."""
    _config, unavailable = _password_reset_config_or_response()
    if unavailable is not None:
        return unavailable
    data = request.get_json(silent=True) or {}
    token = data.get('token')
    password = data.get('password')
    confirmation = data.get('confirmPassword')
    if not isinstance(token, str) or not re.fullmatch(r'[A-Za-z0-9_-]{43}', token):
        return jsonify({'success': False, 'message': '重置链接无效或已过期'}), 400
    if not isinstance(password, str) or not isinstance(confirmation, str):
        return jsonify({'success': False, 'message': '密码格式不正确'}), 400
    if password != confirmation:
        return jsonify({'success': False, 'message': '密码和确认密码不匹配'}), 400
    if not 6 <= len(password) <= PASSWORD_MAX_LENGTH:
        return jsonify({'success': False, 'message': '密码长度必须为 6 至 1024 位'}), 400
    token_hash = hashlib.sha256(token.encode('ascii')).hexdigest()
    limited = _enforce_auth_rate_limit("password_reset_confirm", token_hash)
    if limited is not None:
        return limited

    connection = None
    try:
        connection = get_db_connection()
        with connection.cursor() as cursor:
            cursor.execute(
                "SELECT id, user_id FROM password_reset_tokens "
                "WHERE token_hash = %s AND used_at IS NULL "
                "AND expires_at > UTC_TIMESTAMP() FOR UPDATE",
                (token_hash,),
            )
            reset = cursor.fetchone()
            if not reset:
                connection.rollback()
                return jsonify({'success': False, 'message': '重置链接无效或已过期'}), 400
            cursor.execute(
                "UPDATE users SET password = %s, auth_version = auth_version + 1, "
                "updatetime = NOW() WHERE id = %s",
                (hash_password(password), reset['user_id']),
            )
            if cursor.rowcount != 1:
                connection.rollback()
                return jsonify({'success': False, 'message': '重置链接无效或已过期'}), 400
            cursor.execute(
                "UPDATE password_reset_tokens SET used_at = UTC_TIMESTAMP() "
                "WHERE user_id = %s AND used_at IS NULL",
                (reset['user_id'],),
            )
            connection.commit()
        return jsonify({'success': True, 'message': '密码重置成功，请重新登录。'}), 200
    except pymysql.MySQLError as exc:
        if connection:
            connection.rollback()
        logger.warning("密码重置确认数据库操作失败: %s", type(exc).__name__)
        return jsonify({'success': False, 'message': '重置链接无效或已过期'}), 400
    finally:
        if connection:
            connection.close()


# ------------------- 用户注册与登录接?-------------------
@app.route('/api/register', methods=['POST'])
def register():
    """用户注册接口（保持不变）"""
    data = request.get_json(silent=True) or {}

    # 验证请求数据
    required_fields = ['username', 'email', 'password', 'confirmPassword']
    for field in required_fields:
        if field not in data:
            return jsonify({'success': False, 'message': f'缺少必填字段: {field}'}), 400

    if not all(isinstance(data[field], str) for field in required_fields):
        return jsonify({'success': False, 'message': '注册字段格式不正确'}), 400
    username = data['username'].strip()
    email = data['email'].strip()
    password = data['password']
    confirm_password = data['confirmPassword']

    # 验证数据格式
    if not username:
        return jsonify({'success': False, 'message': '用户名不能为空'}), 400

    if not is_valid_email(email):
        return jsonify({'success': False, 'message': '邮箱格式不正确'}), 400

    if len(password) < 6:
        return jsonify({'success': False, 'message': '密码长度不能少于 6 位'}), 400

    if len(password) > PASSWORD_MAX_LENGTH:
        return jsonify({'success': False, 'message': f'密码长度不能超过 {PASSWORD_MAX_LENGTH} 位'}), 400

    if password != confirm_password:
        return jsonify({'success': False, 'message': '密码和确认密码不匹配'}), 400

    limited = _enforce_auth_rate_limit("register", f"{username}\n{email}")
    if limited is not None:
        return limited

    # Open the database only after request validation has succeeded.
    connection = None
    try:
        connection = get_db_connection()
        with connection.cursor() as cursor:
            # 检查用户名是否已经存在。
            cursor.execute("SELECT id FROM users WHERE username = %s", (username,))
            if cursor.fetchone():
                return jsonify({'success': False, 'message': '用户名已存在'}), 400

            # 检查邮箱是否已经注册。
            cursor.execute("SELECT id FROM users WHERE email = %s", (email,))
            if cursor.fetchone():
                return jsonify({'success': False, 'message': '邮箱已被注册'}), 400

            # 插入新用户。
            hashed_pwd = hash_password(password)
            cursor.execute(
                "INSERT INTO users (username, email, password, createtime, updatetime) VALUES (%s, %s, %s, NOW(), NOW())",
                (username, email, hashed_pwd)
            )
            connection.commit()

            return jsonify({'success': True, 'message': '注册成功'})

    except pymysql.MySQLError as e:
        if connection:
            connection.rollback()
        return _safe_internal_failure("register", e)

    finally:
        if connection:
            connection.close()


@app.route('/api/login', methods=['POST'])
def login():
    """用户登录接口，支持账号或邮箱登录。"""
    data = request.get_json(silent=True) or {}

    # 验证请求数据，loginId 支持用户名或邮箱。
    required_fields = ['loginId', 'password']
    for field in required_fields:
        if field not in data:
            return jsonify({'success': False, 'message': f'缺少必填字段: {field}'}), 400

    # 获取参数
    if not isinstance(data['loginId'], str) or not isinstance(data['password'], str):
        return jsonify({'success': False, 'message': '账号或密码格式不正确'}), 400
    login_id = data['loginId'].strip()  # 改为loginId，可接收用户名或
    password = data['password']
    remember_me = data.get('remember_me', False)

    # 基本验证
    if not login_id or not password:
        return jsonify({'success': False, 'message': '账号或邮箱和密码不能为空'}), 400

    if len(password) > PASSWORD_MAX_LENGTH:
        return jsonify({'success': False, 'message': '账号、邮箱或密码错误'}), 401

    limited = _enforce_auth_rate_limit("login", login_id)
    if limited is not None:
        return limited

    # 数据库操作。
    connection = None
    try:
        connection = get_db_connection()
        with connection.cursor() as cursor:
            # 支持按用户名或邮箱查询。
            cursor.execute(
                "SELECT id, username, password, auth_version FROM users "
                "WHERE username = %s OR email = %s",
                (login_id, login_id)
            )
            user = cursor.fetchone()

            # 验证用户存在性和密码
            if not user:
                check_password_hash(_DUMMY_PASSWORD_HASH, password)
                return jsonify({'success': False, 'message': '账号、邮箱或密码错误'}), 401

            # 验证密码
            password_valid, needs_upgrade = verify_password(password, user.get('password'))
            if not password_valid:
                return jsonify({'success': False, 'message': '账号、邮箱或密码错误'}), 401

            if needs_upgrade:
                upgraded_hash = hash_password(password)
                cursor.execute(
                    "UPDATE users SET password = %s, updatetime = NOW() "
                    "WHERE id = %s AND password = %s",
                    (upgraded_hash, user['id'], user['password']),
                )
                if cursor.rowcount != 1:
                    # A concurrent login or password change won the compare-
                    # and-swap. Start a fresh transaction and authenticate the
                    # value that is now authoritative before issuing a token.
                    connection.rollback()
                    cursor.execute("SELECT password FROM users WHERE id = %s", (user['id'],))
                    current = cursor.fetchone()
                    current_valid, _ = verify_password(
                        password,
                        current.get('password') if current else None,
                    )
                    if not current_valid:
                        return jsonify({'success': False, 'message': '账号、邮箱或密码错误'}), 401
                else:
                    connection.commit()

            # 根据“记住我”状态设置令牌有效期。
            if remember_me:
                token = generate_token(
                    user['id'], user['username'], user.get('auth_version', 0), expire_hours=168)
            else:
                token = generate_token(
                    user['id'], user['username'], user.get('auth_version', 0))

            # 返回结果
            return jsonify({
                'success': True,
                'message': '登录成功',
                'data': {
                    'token': token,
                    'user_id': user['id'],
                    'username': user['username'],
                    'remember_me': remember_me
                }
            })

    except pymysql.MySQLError as e:
        return _safe_internal_failure("login", e)

    finally:
        if connection:
            connection.close()


# ------------------- 会话列表接口-------------------
@app.route('/api/chat/sessions', methods=['POST'])
@require_auth
@db_operation
def create_chat_session(connection):
    """创建新的聊天列表"""
    data = request.get_json(silent=True) or {}
    user_id = g.current_user_id
    # session_id = data.get('session_id')
    session_id = str(uuid.uuid4())
    title = data.get('title', '新会话')

    with connection.cursor() as cursor:
        sql = """
        INSERT INTO chat_list (user_id, session_id, title, create_time, update_time)
        VALUES (%s, %s, %s, NOW(), NOW())
        """
        cursor.execute(sql, (user_id, session_id, title))
        connection.commit()
        return jsonify({
            'id': cursor.lastrowid,
            'message': 'Chat session created successfully',
            'session_id': session_id
        }), 201


@app.route('/api/chat/sessions/<user_id>', methods=['GET'])
@require_auth
@db_operation
def get_chat_sessions_by_userid(connection, user_id):
    """根据用户ID获取聊天会话"""
    _require_requested_user_is_current(user_id)
    with connection.cursor() as cursor:
        # Attach the first/last *user question* time from the message table so
        # the sidebar can show when a conversation was actually started and
        # when it was last used (update_time only changes on create/rename).
        sql = (
            "SELECT cl.*, "
            "(SELECT MIN(cd.create_time) FROM conversation_detail cd "
            " WHERE cd.session_id = cl.session_id AND cd.from_who = 'user') AS first_question_time, "
            "(SELECT MAX(cd.create_time) FROM conversation_detail cd "
            " WHERE cd.session_id = cl.session_id AND cd.from_who = 'user') AS last_question_time "
            "FROM chat_list cl WHERE cl.user_id = %s ORDER BY cl.update_time DESC"
        )
        cursor.execute(sql, (user_id,))
        session = cursor.fetchall()
        if session:
            # MySQL stores naive local datetimes; serialize them as local
            # strings (same as the messages API) instead of letting jsonify
            # emit them as GMT, which shifts the displayed time by the offset.
            for row in session:
                for key in ("create_time", "update_time",
                            "first_question_time", "last_question_time"):
                    if key in row:
                        row[key] = convert_datetime_to_string(row[key])
            return jsonify(session)
        else:
            return jsonify({'error': 'User not found'}), 404


@app.route('/api/chat/sessions/<session_id>', methods=['PUT'])
@require_auth
@db_operation
def update_chat_session_title(connection, session_id):
    """更新聊天会话标"""
    data = request.get_json()
    new_title = data.get('title')

    if not new_title:
        return jsonify({'error': 'title is required'}), 400

    with connection.cursor() as cursor:
        _require_session_owner(cursor, session_id)
        sql = "UPDATE chat_list SET title = %s, update_time = NOW() WHERE session_id = %s"
        cursor.execute(sql, (new_title, session_id))
        connection.commit()

        if cursor.rowcount == 0:
            return jsonify({'error': 'Session not found'}), 404

        return jsonify({'message': 'Title updated successfully'})


@app.route('/api/chat/sessions/<session_id>/touch', methods=['PUT'])
@require_auth
@db_operation
def update_chat_session_time(connection, session_id):
    """更新聊天会话的最后更新时间。"""
    with connection.cursor() as cursor:
        _require_session_owner(cursor, session_id)
        sql = "UPDATE chat_list SET update_time = NOW() WHERE session_id = %s"
        cursor.execute(sql, (session_id,))
        connection.commit()

        if cursor.rowcount == 0:
            return jsonify({'error': 'Session not found'}), 404

        return jsonify({'message': 'Update time refreshed successfully'})


@app.route('/api/chat/sessions/<session_id>', methods=['DELETE'])
@require_auth
@db_operation
def delete_chat_session(connection, session_id):
    """删除 single chat session and its details"""
    with connection.cursor() as cursor:
        try:
            _require_session_owner(cursor, session_id)
            # First delete from conversation_detail
            sql_detail = "DELETE FROM conversation_detail WHERE session_id = %s"
            cursor.execute(sql_detail, (session_id,))

            # Then delete from chat_history
            sql_history = "DELETE FROM chat_list WHERE session_id = %s"
            cursor.execute(sql_history, (session_id,))

            # Check if any records were affected
            if cursor.rowcount == 0:
                connection.rollback()  # Rollback if no records were deleted
                return jsonify({'error': 'Session not found'}), 404

            connection.commit()  # Commit both deletions if successful
            return jsonify({'message': 'Session deleted successfully'})

        except HTTPException:
            raise
        except Exception as e:
            connection.rollback()  # Rollback on any error
            return _safe_internal_failure("delete_chat_session", e)

#-----------------会话详情相关接口------------------
@app.route('/api/chat/messages', methods=['POST'])
@require_auth
def add_chat_message():
    """添加聊天消息"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': '没有提供JSON数据'}), 400

        # 验证必需字
        required_fields = ['session_id', 'from_who', 'content']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'缺少必需字段: {field}'}), 400

        # 设置字段。
        session_id = data['session_id']
        from_who = data['from_who']
        content = data['content']
        round_num = data.get('round',1)
        think_msg = data.get('think_msg', '')
        timestamp = data.get('timestamp', datetime.datetime.now())
        message_uuid = data.get('uuid', data.get('backend_session_id'))
        has_report = data.get('has_report',0)
        report_title = data.get('report_title', '')  # 新：获取报告标?

        # 验证 from_who。
        if from_who not in ['user', 'ai']:
            return jsonify({'error': 'from_who必须是user或ai'}), 400

        connection = get_db_connection()
        if not connection:
            return jsonify({'error': '数据库连接失败'}), 500

        try:
            with connection.cursor() as cursor:
                _require_session_owner(cursor, session_id)
                sql = """
                    INSERT INTO conversation_detail 
                    (session_id, from_who, round, timestamp, uuid, content, think_msg, create_time, has_report, report_title)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, NOW(), %s, %s)
                """
                cursor.execute(sql, (
                    session_id, from_who, round_num, timestamp,
                    message_uuid, content, think_msg, has_report, report_title
                ))
            connection.commit()

            logger.info(f"成功插入消息: session_id={session_id}, from={from_who}, report_title={report_title}")
            return jsonify({
                'success': True,
                'message': '消息添加成功',
                'uuid': message_uuid
            }), 201

        except HTTPException:
            raise
        except Exception as e:
            connection.rollback()
            return _safe_internal_failure("add_chat_message", e)
        finally:
            connection.close()

    except HTTPException:
        raise
    except Exception as e:
        return _safe_internal_failure("add_chat_message_setup", e)

@app.route('/api/chat/messages/<session_id>', methods=['GET'])
@require_auth
def get_chat_messages_by_session_id(session_id):
    """根据 session_id 获取会话的所有消息。"""
    try:
        connection = get_db_connection()
        if not connection:
            return jsonify({'error': '数据库连接失败'}), 500

        try:
            with connection.cursor() as cursor:
                _require_session_owner(cursor, session_id)
                sql = """
                    SELECT id, session_id, from_who, round, timestamp, uuid,
                           content, think_msg, create_time, has_report, report_title
                    FROM conversation_detail
                    WHERE session_id = %s
                    ORDER BY round ASC, 
                     timestamp ASC, from_who DESC;
                """
                cursor.execute(sql, (session_id,))
                messages = cursor.fetchall()

                # 轍datetime对象为字符串
                converted_messages = []
                for message in messages:
                    converted_message = {}
                    for key, value in message.items():
                        converted_message[key] = convert_datetime_to_string(value)
                    converted_messages.append(converted_message)

                return jsonify({
                    'success': True,
                    'session_id': session_id,
                    'messages': converted_messages,
                    'count': len(converted_messages)
                }), 200

        except HTTPException:
            raise
        except Exception as e:
            return _safe_internal_failure("get_chat_messages", e)
        finally:
            connection.close()

    except HTTPException:
        raise
    except Exception as e:
        return _safe_internal_failure("get_chat_messages_setup", e)


def _redact_conversation_log(value: str, limit: int = 120000) -> str:
    """Remove obvious credentials and bound exported log size."""
    text = str(value or "")
    text = re.sub(
        r"(?im)^\s*((?:MODEL_REQUEST_TOKEN|LLAMA_CLOUD_API_KEY|MCP_AUTH_TOKEN|OPENAI_API_KEY|API_KEY)\s*[:=])[^\r\n]*",
        r"\1 [REDACTED]",
        text,
    )
    text = re.sub(r"(?i)(Bearer\s+)[A-Za-z0-9._\-+/=]+", r"\1[REDACTED]", text)
    if len(text) > limit:
        text = text[:limit] + "\n...[log truncated for export]"
    return text


def _conversation_markdown(session_id: str, messages: list[dict]) -> str:
    """Build a complete, auditable Markdown transcript for one chat session."""
    lines = [
        "# SciAssistant 会话完整导出",
        "",
        f"- 会话 ID：`{session_id}`",
        f"- 导出时间：{datetime.datetime.now().isoformat(timespec='seconds')}",
        f"- 消息数：{len(messages)}",
        "",
        "> 本文件包含本会话的各轮问题、回答、推理字段（如有）和对应运行日志。日志中的明显密钥已脱敏。",
    ]
    seen_logs = set()
    for index, message in enumerate(messages, 1):
        sender = "用户" if message.get("from_who") == "user" else "AI"
        round_no = message.get("round") or index
        timestamp = message.get("timestamp") or message.get("create_time") or ""
        content = str(message.get("content") or "").strip()
        lines.extend([
            "",
            f"## 第 {round_no} 轮 · {sender}",
            "",
            f"- 消息时间：{timestamp}",
            f"- 消息 ID：`{message.get('id') or message.get('uuid') or ''}`",
        ])
        if message.get("report_title"):
            lines.append(f"- 报告标题：{message.get('report_title')}")
        lines.extend(["", content or "（空消息）"])
        think = str(message.get("think_msg") or "").strip()
        if think:
            lines.extend(["", "### 推理/过程字段", "", think])

        task_id = str(message.get("uuid") or "").strip()
        if message.get("from_who") == "ai" and task_id and task_id not in seen_logs:
            seen_logs.add(task_id)
            log_path = LOG_DIR / f"web_task_{task_id}.txt"
            diagnostics_path = LOG_DIR / f"web_task_{task_id}.diagnostics.jsonl"
            if log_path.is_file():
                try:
                    log_text = _redact_conversation_log(log_path.read_text(encoding="utf-8", errors="replace"))
                    lines.extend(["", "### 本轮运行日志", "", "```text", log_text, "```"])
                except OSError as exc:
                    lines.extend(["", f"### 本轮运行日志读取失败：`{exc}`"])
            if diagnostics_path.is_file():
                try:
                    diagnostic_text = _redact_conversation_log(
                        diagnostics_path.read_text(encoding="utf-8", errors="replace"), 80000
                    )
                    lines.extend(["", "### 本轮阶段诊断 JSONL", "", "```jsonl", diagnostic_text, "```"])
                except OSError as exc:
                    lines.extend(["", f"### 本轮阶段诊断读取失败：`{exc}`"])
            if not log_path.is_file() and not diagnostics_path.is_file():
                lines.extend(["", "### 本轮运行日志", "", "（未找到独立任务日志；本轮可用的过程字段已在上方导出。）"])
    return "\n".join(lines).strip() + "\n"


@app.route('/api/chat/sessions/<session_id>/export', methods=['GET'])
@require_auth
def export_chat_session(session_id):
    """Download every message and available task log for one conversation."""
    if not session_id or Path(session_id).name != session_id:
        return jsonify({'error': '无效的会话 ID'}), 400
    connection = get_db_connection()
    if not connection:
        return jsonify({'error': '数据库连接失败'}), 500
    try:
        with connection.cursor() as cursor:
            _require_session_owner(cursor, session_id)
            cursor.execute(
                """SELECT id, session_id, from_who, round, timestamp, uuid,
                          content, think_msg, create_time, has_report, report_title
                   FROM conversation_detail
                   WHERE session_id = %s
                   ORDER BY round ASC, timestamp ASC, from_who DESC""",
                (session_id,),
            )
            raw_messages = cursor.fetchall()
        messages = []
        for message in raw_messages:
            item = dict(message)
            for key, value in item.items():
                item[key] = convert_datetime_to_string(value)
            messages.append(item)
    except HTTPException:
        raise
    except Exception as exc:
        return _safe_internal_failure("export_conversation", exc)
    finally:
        connection.close()
    if not messages:
        return jsonify({'error': '该会话没有可导出的消息'}), 404
    output_dir = BASE_DIR / "logs" / "conversation_exports"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / f"conversation_{safe_filename_unicode(session_id)}.md"
    output_path.write_text(_conversation_markdown(session_id, messages), encoding='utf-8')
    return send_file(output_path, as_attachment=True, download_name=f"sciassistant_conversation_{session_id}.md")


# 统一使用项目根目录下?workspaces
PDF_DIR = BASE_DIR / "workspaces"  # 统一跾

    # 上传文件目录与配置。
UPLOAD_DIR = BASE_DIR / "uploads"
ALLOWED_EXTENSIONS = {'.txt', '.md', '.csv', '.json', '.log', '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.xml', '.html', '.htm', '.rtf', '.odt', '.epub', '.yaml', '.yml'}
MAX_UPLOAD_SIZE = 30 * 1024 * 1024
MAX_TOTAL_UPLOAD_SIZE = 60 * 1024 * 1024
UPLOAD_DIR.mkdir(exist_ok=True)

def _find_workspace_file(session_id: str, filename: str) -> Optional[Path]:
    """
    查找 workspaces 业文件
    
    Args:
        session_id: 会话ID
        filename: 文件名（?"final_report.pdf"?    
    Returns:
        找到的文件路径，如果不存在则返回 None
    """
    file_path = PDF_DIR / session_id / filename
    if file_path.is_file():
        return file_path
    return None


def _report_markdown_path(session_id: str) -> Path:
    """Return the session report path after rejecting path traversal input."""
    if not session_id or Path(session_id).name != session_id:
        abort(400)
    report_dir = PDF_DIR / session_id / "report"
    candidates = (report_dir / "final_report.md", PDF_DIR / session_id / "final_report.md")
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    abort(404)


def _ensure_report_export(session_id: str, report_format: str) -> Path:
    """Create a requested report artifact from the canonical Markdown report."""
    markdown_path = _report_markdown_path(session_id)
    report_dir = markdown_path.parent
    requested = "md" if report_format == "md" else "pdf"
    output_path = report_dir / f"final_report.{requested}"
    if output_path.is_file() and output_path.stat().st_mtime >= markdown_path.stat().st_mtime:
        return output_path
    exported = export_report_files(
        markdown_path.read_text(encoding="utf-8"),
        report_dir,
        basename="final_report",
        formats=requested,
    )
    exported_path = exported.get("markdown" if requested == "md" else "pdf")
    if not exported_path:
        abort(500)
    return Path(exported_path)


@app.route("/api/export_report", methods=["GET"])
@require_auth
def export_report():
    """Generate and download a Markdown or PDF report on demand."""
    session_id = request.args.get("session_id") or abort(400)
    _require_legacy_report_owner(session_id)
    report_format = (request.args.get("format") or "pdf").lower()
    if report_format not in {"md", "pdf", "both"}:
        return jsonify({"success": False, "error": "format must be md, pdf, or both"}), 400

    if report_format == "both":
        pdf_path = _ensure_report_export(session_id, "pdf")
        markdown_path = _ensure_report_export(session_id, "md")
        return jsonify({
            "success": True,
            "session_id": session_id,
            # Never expose server filesystem layout to browser clients.  The
            # filename is display-safe and download_urls remains the supported
            # authenticated retrieval mechanism.
            "files": {"pdf": pdf_path.name, "markdown": markdown_path.name},
            "download_urls": {
                "pdf": f"/api/export_report?session_id={session_id}&format=pdf",
                "markdown": f"/api/export_report?session_id={session_id}&format=md",
            },
        })

    file_path = _ensure_report_export(session_id, report_format)
    return send_file(file_path, as_attachment=True, download_name=file_path.name)

@app.route('/api/context/upload', methods=['POST'])
@require_auth
def upload_context_file():
    """接收上文文件上传，保存到服务器并返回文件信息与下载地?
    
    攌两模式?    1. 临时上传：保存到uploads盽，用于当前会?    2. 同到文档库：果提供user_id和save_to_library=true，同时保存到文档?    """
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': '未找到文件字段：file'}), 400
    file = request.files['file']
    if not file or file.filename == '':
        return jsonify({'success': False, 'message': '未选择文件'}), 400

    # 获取可选参数。
    user_id = g.current_user_id
    save_to_library = request.form.get('save_to_library', 'false').lower() == 'true'  # 昐同到文档库

    ext = Path(file.filename).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        return jsonify({'success': False, 'message': f'不支持的文件类型: {ext}'}), 400

    # 计算大小（兼容不同环境的文件流）
    try:
        file.stream.seek(0, os.SEEK_END)
        size = file.stream.tell()
        file.stream.seek(0)
    except Exception:
        # 回退方案：保存后再获取大小。
        size = None

    if size is not None and size > MAX_UPLOAD_SIZE:
        return jsonify({'success': False, 'message': f'文件大小超过{MAX_UPLOAD_SIZE / 1024 / 1024:.0f}MB限制'}), 413

    file_id = uuid.uuid4().hex
    # 处理文件名编码。
    original_filename = file.filename
    # 尝试解码 URL 编码的文件名。
    try:
        if isinstance(original_filename, bytes):
            original_filename = original_filename.decode('utf-8', errors='replace')
        elif '%' in original_filename:
            # 如果包含 URL 编码字符，尝试解码。
            import urllib.parse
            original_filename = urllib.parse.unquote(original_filename, encoding='utf-8')
    except Exception:
        pass  # 如果解码失败，使用原始文件名
    
    # 使用攌世的文件名处理函数
    safe_name = safe_filename_unicode(original_filename)
    save_name = f"{file_id}_{safe_name}"
    save_path = UPLOAD_DIR / save_name
    
    # 保存文件，理可能的编码
    try:
        # 硿盽存在
        save_path.parent.mkdir(parents=True, exist_ok=True)
        # 保存文件（使用字符串跾以避免编码问题）
        file.save(str(save_path))
    except Exception as e:
        return _safe_internal_failure("save_context_file", e)

    # 若之前未能获取大小，保存后补充。
    if size is None:
        size = save_path.stat().st_size
    if size > MAX_UPLOAD_SIZE:
        try:
            save_path.unlink(missing_ok=True)
        except Exception:
            pass
        return jsonify({'success': False, 'message': f'文件大小超过{MAX_UPLOAD_SIZE / 1024 / 1024:.0f}MB限制'}), 413

    # 尝试读取文本内容。
    text_content = ''
    TEXT_EXTENSIONS = {'.txt', '.md', '.csv', '.json', '.log', '.xml', '.yaml', '.yml'}
    if ext in TEXT_EXTENSIONS:
        try:
            with open(save_path, 'r', encoding='utf-8', errors='ignore') as f:
                text_content = f.read()
        except Exception:
            text_content = ''

    # 如需同步到文档库，创建对应记录。
    library_file_id = None
    file_already_in_library = False
    if save_to_library and user_id:
        logger.info(f"开始同步文件到文档库: user_id={user_id}, filename={original_filename}")
        try:
            connection = get_db_connection()
            logger.debug("数据库连接成功")
            try:
                with connection.cursor() as cursor:
                    # 首先?查文件名昐已存在于文档库中
                    check_sql = """
                        SELECT file_id, stored_filename, file_path 
                        FROM user_files 
                        WHERE user_id = %s AND original_filename = %s
                        LIMIT 1
                    """
                    cursor.execute(check_sql, (user_id, original_filename))
                    existing_file = cursor.fetchone()
                    
                    if existing_file:
                        # 文件已存在，复用其 ID。
                        library_file_id = existing_file['file_id']
                        file_already_in_library = True
                        logger.info(f"文件已在文档库中: {original_filename}, library_file_id={library_file_id}")
                    else:
                        # 文件不存圼新建记录
                        logger.debug("文件不在文档库中，开始创建记录")
                        
                        # 获取用户上传盽
                        user_dir = get_user_upload_dir(user_id)
                        logger.debug("已解析用户上传目录: user_id=%s", user_id)
                        
                        # 生成文档库文件ID和存储文件名
                        library_file_id = str(uuid.uuid4())
                        file_extension = ext.lstrip('.')  # 移除点号
                        library_safe_filename = f"{library_file_id}.{file_extension}"
                        library_file_path = user_dir / library_safe_filename
                        logger.debug("已生成文档库存储名: file_id=%s", library_file_id)
                        
                        # 复制文件到文档库盽
                        logger.debug("开始复制文件到文档库: file_id=%s", library_file_id)
                        shutil.copy2(str(save_path), str(library_file_path))
                        logger.debug("文件复制成功")
                        
                        # 将文件信恭入数捺
                        sql = """
                            INSERT INTO user_files 
                            (file_id, user_id, original_filename, stored_filename, file_path, 
                             file_size, file_type, status, upload_time)
                            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, NOW())
                        """
                        logger.debug(f"准备插入数据: file_id={library_file_id}")
                        cursor.execute(sql, (
                            library_file_id,
                            user_id,
                            original_filename,
                            library_safe_filename,
                            str(library_file_path),
                            size,
                            file_extension,
                            'processed',
                        ))
                        connection.commit()
                        logger.info(f"文件已同步到文档库: {original_filename}, library_file_id={library_file_id}, size={size} bytes")
            finally:
                connection.close()
        except Exception as e:
            logger.error("同步文件到文档库失败: %s", type(e).__name__)
            # 保留临时文件，并在响应中标记文档库保存失败。

    download_url = f"/api/context/files/{file_id}"
    response_data = {
        'success': True,
        'file_id': file_id,
        'filename': original_filename,  # 返回原文件名（包含世），前显示使用
        'size': size,
        'download_url': download_url,
        'text_content': text_content,
        'file_type': ext
    }
    with _RESOURCE_OWNER_LOCK:
        _CONTEXT_FILE_OWNERS[file_id] = str(g.current_user_id)
        _persist_context_file_owners_locked()
    
    # 如果同到了文档库，返回文档库文件ID
    if library_file_id:
        response_data['library_file_id'] = library_file_id
        response_data['saved_to_library'] = True
        response_data['already_in_library'] = file_already_in_library  # 标识文件昐已在文档库中
    elif save_to_library and user_id:
        # 用户想保存到文档库，但保存失败了
        response_data['saved_to_library'] = False
        response_data['library_save_failed'] = True
        response_data['library_error'] = '文档库保存失败，文件已保存到临时盽'
        logger.warning(f"文档库保存失败，但临时文件上传成功: {original_filename}")
    
    return jsonify(response_data), 200

@app.route('/api/context/files/<file_id>', methods=['GET'])
@require_auth
def download_context_file(file_id: str):
    """根据file_id下载原文件"""
    with _RESOURCE_OWNER_LOCK:
        owner = _CONTEXT_FILE_OWNERS.get(str(file_id))
    if owner != str(g.current_user_id):
        abort(404)
    candidates = list(UPLOAD_DIR.glob(f"{file_id}_*"))
    if not candidates:
        abort(404)
    p = candidates[0]
    # 从保存的文件名中提取原始文件名。
    saved_name = p.name
    if '_' in saved_name:
        original_name = saved_name.split('_', 1)[1]
    else:
        original_name = saved_name
    
    return send_from_directory(
        directory=str(UPLOAD_DIR),
        path=p.name,
        as_attachment=True,
        download_name=original_name
    )
    
@app.route("/api/download_pdf")
@require_auth
def download_pdf():
    session_id = request.args.get("session_id") or abort(400)
    _require_legacy_report_owner(session_id)
    
    # 查询数据库获取报告标题。
    report_title = None
    try:
        connection = get_db_connection()
        if connection:
            with connection.cursor() as cursor:
                # 查ession_id下有报告的消恚report_title
                sql = """
                    SELECT report_title 
                    FROM conversation_detail 
                    WHERE uuid = %s AND has_report = 1 AND report_title IS NOT NULL AND report_title != ''
                    LIMIT 1
                """
                cursor.execute(sql, (session_id,))
                result = cursor.fetchone()
                if result and result.get('report_title'):
                    report_title = result['report_title']
            connection.close()
    except Exception as e:
        logger.error("查询报告标题失败: %s", type(e).__name__)
    
    # Prefer an existing legacy artifact, otherwise render the PDF on demand.
    file_path = _find_workspace_file(session_id, "final_report.pdf")
    if not file_path:
        file_path = _ensure_report_export(session_id, "pdf")
    
        # 构建下载文件名：如果有报告标题则使用标，否则使用默认名?
    if report_title:
        # 使用safe_filename_unicode函数处理文件名，硿攌世
        safe_title = safe_filename_unicode(report_title)
        download_name = f"{safe_title}.pdf"
    else:
        download_name = f"report_{session_id}.pdf"
    
    return send_from_directory(
        directory=file_path.parent,
        path=file_path.name,
        as_attachment=True,
        download_name=download_name
    )


@app.route("/api/download_md")
@require_auth
def download_md():
    """下载 Markdown 格式的报告。"""
    session_id = request.args.get("session_id") or abort(400)
    _require_legacy_report_owner(session_id)
    
    # 查询数据库获取报告标题。
    report_title = None
    try:
        connection = get_db_connection()
        if connection:
            with connection.cursor() as cursor:
                # 查ession_id下有报告的消恚report_title
                sql = """
                    SELECT report_title 
                    FROM conversation_detail 
                    WHERE uuid = %s AND has_report = 1 AND report_title IS NOT NULL AND report_title != ''
                    LIMIT 1
                """
                cursor.execute(sql, (session_id,))
                result = cursor.fetchone()
                if result and result.get('report_title'):
                    report_title = result['report_title']
            connection.close()
    except Exception as e:
        logger.error("查询报告标题失败: %s", type(e).__name__)
    
    # Ensure the Markdown artifact exists for reports produced by either path.
    md_path = _ensure_report_export(session_id, "md")
    
    # 构建下载文件名。
    if report_title:
        # 使用safe_filename_unicode函数处理文件名，硿攌世
        safe_title = safe_filename_unicode(report_title)
        download_name = f"{safe_title}.md"
    else:
        download_name = f"report_{session_id}.md"
    
    return send_from_directory(
        directory=md_path.parent,
        path=md_path.name,
        as_attachment=True,
        download_name=download_name
    )


# ?易RAG?紼在上传目录中?索文朖件，切片并按查词重合度打分
import re as _re


def _file_owned_by_user(file_id: str, user_id: str) -> bool:
    """Resolve temporary or library-file ownership before reading its bytes."""
    with _RESOURCE_OWNER_LOCK:
        temporary_owner = _CONTEXT_FILE_OWNERS.get(str(file_id))
    if temporary_owner is not None:
        return temporary_owner == str(user_id)
    connection = None
    try:
        connection = get_db_connection()
        with connection.cursor() as cursor:
            cursor.execute(
                'SELECT 1 FROM user_files WHERE file_id = %s AND user_id = %s LIMIT 1',
                (file_id, user_id),
            )
            return cursor.fetchone() is not None
    except Exception as exc:
        logger.error("检查文件归属失败: %s", type(exc).__name__)
        return False
    finally:
        if connection:
            connection.close()


def _find_uploaded_path_by_id(file_id: str) -> Optional[Path]:
    logger.debug(f"[DEBUG] Searching for file_id: {file_id}")
    
    # 首先在临时上传目录中查找
    for p in UPLOAD_DIR.glob(f"{file_id}_*"):
        logger.debug("[DEBUG] Found temporary upload: file_id=%s", file_id)
        return p
    
    logger.debug(f"[DEBUG] Not found in UPLOAD_DIR, searching database...")
    
    # 如果临时盽没找到，尝试从数捺丟找文档库文件
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        # MySQL使用%s作为占位符，查字是file_id而不是id
        cursor.execute('SELECT file_path FROM user_files WHERE file_id = %s', (file_id,))
        row = cursor.fetchone()
        conn.close()
        
        logger.debug("[DEBUG] Database lookup completed: file_id=%s found=%s", file_id, bool(row))
        
        if row:
            # 处理字典或元组两种返回格?
            file_path_str = row.get('file_path') if isinstance(row, dict) else row[0]
            if file_path_str:
                file_path = Path(file_path_str)
                logger.debug(
                    "[DEBUG] Stored file resolved: file_id=%s exists=%s",
                    file_id,
                    file_path.exists(),
                )
                if file_path.exists():
                    return file_path
                else:
                    logger.error("[ERROR] Stored file is missing: file_id=%s", file_id)
    except Exception as e:
        logger.error("数据库文件查找失败: %s", type(e).__name__)
    
    logger.error(f"[ERROR] File not found anywhere: {file_id}")
    return None

def _read_text_file(path: Path) -> str:
    try:
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            return f.read()
    except Exception:
        return ''

def _clean_extracted_pdf_text(raw_text: str) -> str:
    if not raw_text:
        return ''
    cleaned = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', raw_text)
    cleaned = cleaned.replace('\r\n', '\n').replace('\r', '\n')
    cleaned = re.sub(r'\n{4,}', '\n\n\n', cleaned)
    return cleaned.strip()

def _format_pdf_pages_for_citation(pages: List[Dict[str, Any]]) -> str:
    parts = []
    for page in pages:
        page_text = (page.get('text') or '').strip()
        if not page_text:
            continue
        parts.append(f"[[page={page.get('page')}]]\n{page_text}")
    return "\n\n".join(parts)

def _extract_pdf_pages_legacy(path: Path) -> Dict[str, Any]:
    result = {
        'success': False,
        'parser': None,
        'pages': [],
        'text': '',
        'page_count': 0,
        'content_length': 0,
        'error': None
    }
    if not path.exists():
        result['error'] = 'PDF file does not exist'
        return result
    if path.stat().st_size == 0:
        result['error'] = 'PDF file is empty'
        return result
    try:
        with open(path, 'rb') as f:
            if f.read(5) != b'%PDF-':
                result['error'] = 'File header is not PDF'
                return result
    except Exception:
        result['error'] = 'Unable to read PDF header.'
        return result

        # 优先使用 PyMuPDF，保留页码，供文引用定?
    try:
        import fitz  # PyMuPDF
        pages = []
        with fitz.open(str(path)) as doc:
            for idx, page in enumerate(doc, 1):
                page_text = _clean_extracted_pdf_text(page.get_text() or '')
                if page_text:
                    pages.append({'page': idx, 'text': page_text, 'char_count': len(page_text)})
        text = _format_pdf_pages_for_citation(pages)
        if text:
            result.update({
                'success': True,
                'parser': 'pymupdf',
                'pages': pages,
                'text': text,
                'page_count': len(pages),
                'content_length': len(text),
                'error': None
            })
            return result
    except Exception:
        result['error'] = 'PyMuPDF failed.'

    # 其使用 pdfminer.six；不能稳定保留页码时，作为全文解析回?
    try:
        from pdfminer.high_level import extract_text
        text = _clean_extracted_pdf_text(extract_text(str(path)) or '')
        if text:
            pages = [{'page': 1, 'text': text, 'char_count': len(text)}]
            result.update({
                'success': True,
                'parser': 'pdfminer.six',
                'pages': pages,
                'text': _format_pdf_pages_for_citation(pages),
                'page_count': 1,
                'content_length': len(text),
                'error': None
            })
            return result
    except Exception:
        result['error'] = 'PDF parsing failed with available text parsers.'

    # 最后使用 pypdf（文本质量一般，但保留页码）
    try:
        from pypdf import PdfReader
        pages = []
        with open(path, 'rb') as f:
            reader = PdfReader(f)
            for idx, page in enumerate(reader.pages, 1):
                page_text = _clean_extracted_pdf_text(page.extract_text() or '')
                if page_text:
                    pages.append({'page': idx, 'text': page_text, 'char_count': len(page_text)})
        text = _format_pdf_pages_for_citation(pages)
        if text:
            result.update({
                'success': True,
                'parser': 'pypdf',
                'pages': pages,
                'text': text,
                'page_count': len(pages),
                'content_length': len(text),
                'error': None
            })
            return result
    except Exception:
        result['error'] = 'PDF parsing failed with all available text parsers.'
    return result

def _read_pdf_text(path: Path) -> str:
    return _extract_pdf_pages(path).get('text') or ''

def _split_chunks(text: str, max_chars: int = 1500, overlap: int = 200):
    chunks = []
    i = 0
    n = len(text)
    while i < n:
        end = min(i + max_chars, n)
        chunk = text[i:end]
        chunks.append(chunk)
        if end >= n:
            break
        i = max(0, end - overlap)
    return chunks

def _build_pdf_parse_result(parser: str, pages: List[Dict[str, Any]], page_count: int) -> Dict[str, Any]:
    text_page_count = sum(1 for page in pages if (page.get('text') or '').strip())
    text = _format_pdf_pages_for_citation(pages)
    if text:
        return {
            'success': True,
            'parser': parser,
            'pages': pages,
            'text': text,
            'page_count': page_count,
            'text_page_count': text_page_count,
            'empty_page_count': max(0, page_count - text_page_count),
            'content_length': len(text),
            'extraction_status': 'parsed',
            'error': None,
        }
    return {
        'success': False,
        'parser': parser,
        'pages': pages,
        'text': '',
        'page_count': page_count,
        'text_page_count': 0,
        'empty_page_count': page_count,
        'content_length': 0,
        'extraction_status': 'needs_ocr',
        'error': 'No extractable text was found. This PDF may be scanned or image-only and requires OCR.',
    }


def _extract_pdf_pages_legacy_v2(path: Path) -> Dict[str, Any]:
    result = {
        'success': False,
        'parser': None,
        'pages': [],
        'text': '',
        'page_count': 0,
        'text_page_count': 0,
        'empty_page_count': 0,
        'content_length': 0,
        'extraction_status': 'failed',
        'error': None,
    }
    if not path.exists():
        result['error'] = 'PDF file does not exist'
        return result
    if path.stat().st_size == 0:
        result['error'] = 'PDF file is empty'
        return result
    try:
        with open(path, 'rb') as f:
            if f.read(5) != b'%PDF-':
                result['error'] = 'File header is not PDF'
                return result
    except Exception:
        result['error'] = 'Unable to read PDF header.'
        return result

    try:
        import fitz
        pages = []
        with fitz.open(str(path)) as doc:
            for page_number, page in enumerate(doc, 1):
                page_text = _clean_extracted_pdf_text(page.get_text() or '')
                pages.append({'page': page_number, 'text': page_text, 'char_count': len(page_text)})
            page_count = len(doc)
        parsed = _build_pdf_parse_result('pymupdf', pages, page_count)
        if parsed['success']:
            return parsed
        result.update(parsed)
    except Exception:
        result['error'] = 'PyMuPDF failed.'

    try:
        from pdfminer.high_level import extract_text
        page_texts = (extract_text(str(path)) or '').split('\f')
        if page_texts and not page_texts[-1].strip():
            page_texts.pop()
        pages = []
        for page_number, raw_text in enumerate(page_texts, 1):
            page_text = _clean_extracted_pdf_text(raw_text)
            pages.append({'page': page_number, 'text': page_text, 'char_count': len(page_text)})
        parsed = _build_pdf_parse_result('pdfminer.six', pages, len(pages))
        if parsed['success']:
            return parsed
        result.update(parsed)
    except Exception:
        result['error'] = 'PDF parsing failed with available text parsers.'

    try:
        from pypdf import PdfReader
        pages = []
        with open(path, 'rb') as f:
            reader = PdfReader(f)
            for page_number, page in enumerate(reader.pages, 1):
                page_text = _clean_extracted_pdf_text(page.extract_text() or '')
                pages.append({'page': page_number, 'text': page_text, 'char_count': len(page_text)})
            page_count = len(reader.pages)
        parsed = _build_pdf_parse_result('pypdf', pages, page_count)
        if parsed['success']:
            return parsed
        result.update(parsed)
    except Exception:
        result['error'] = 'PDF parsing failed with all available text parsers.'
    return result


def _extract_pdf_pages(path: Path) -> Dict[str, Any]:
    """Use the shared, page-aware parser for every web-uploaded PDF."""
    return parse_pdf_with_layout(path)


def _split_pdf_pages(pages: List[Dict[str, Any]], max_chars: int = 1500, overlap: int = 200) -> List[Dict[str, Any]]:
    """Split each physical PDF page independently so citations stay precise."""
    max_chars = max(200, max_chars)
    overlap = max(0, min(overlap, max_chars - 1))
    chunks = []
    for page in pages:
        page_text = (page.get('text') or '').strip()
        if not page_text:
            continue
        for chunk_index, chunk in enumerate(_split_chunks(page_text, max_chars=max_chars, overlap=overlap), 1):
            chunks.append({
                'chunk': chunk,
                'page': page.get('page'),
                'chunk_index': chunk_index,
            })
    return chunks


def _pdf_citation(filename: str, page: Optional[int]) -> str:
    return f"{filename}, p. {page}" if page else filename


def _score_chunk(query: str, chunk: str) -> float:
    """
    计算查与文有段的相关性分数（改进版：攌世?    """
    import re
    
    # 提取查词：攌世和英?    # 世：\u4e00-\u9fff 范围
    # 英文数字：\w+
    q_words = re.findall(r'[\u4e00-\u9fff]+|\w+', query.lower())
    c_words = re.findall(r'[\u4e00-\u9fff]+|\w+', chunk.lower())
    
    if not q_words or not c_words:
        return 0.0
    
    q_set = set(q_words)
    c_set = set(c_words)
    common = len(q_set & c_set)  # 共同词汇?    
    if common == 0:
        return 0.0
    
    # 计算分数：共同词汇数 / (片词汇数的平方?+ 1)
        # 这样即使片很长，也能保持一定的相关?
    score = common / ((len(c_set) ** 0.5) + 1)
    
        # 额奖励：果查询词在片段中出现频率?
    if len(q_set) > 0:
        match_ratio = common / len(q_set)
        score = score * (1 + match_ratio * 0.5)  # 增加匹配比例权重
    
    return min(score, 1.0)  # 限制?大?为1.0

@app.route('/api/user_files/download_and_parse', methods=['POST'])
@require_auth
def download_and_parse_user_files():
    """
    下载并解析用户上传的文件，供Agent系统使用
    
    请求? {
        "file_ids": ["file_id_1", "file_id_2"],
        "target_workspace": "/path/to/workspace"
    }
    
    返回: {
        "success": true,
        "files": [
            {
                "file_id": "xxx",
                "filename": "document.pdf",
                "download_url": "/api/files/download/xxx",
                "content": "文档内...",
                "metadata": {...}
            }
        ]
    }
    """
    data = request.get_json(silent=True) or {}
    file_ids = data.get('file_ids') or []
    target_workspace = data.get('target_workspace') or ''
    
    if not file_ids:
        return jsonify({'success': False, 'message': '缺少file_ids参数'}), 400

    if any(not _file_owned_by_user(str(file_id), g.current_user_id) for file_id in file_ids):
        abort(404)
    
    results = []
    for file_id in file_ids:
        # 查找上传的文?
        p = _find_uploaded_path_by_id(file_id)
        if not p:
            results.append({
                'file_id': file_id,
                'success': False,
                'error': 'File not found'
            })
            continue
        
        # 读取文件内
        ext = p.suffix.lower()
        content = ''
        parse_metadata = {
            'parser': None,
            'page_count': 0,
            'text_page_count': 0,
            'empty_page_count': 0,
            'extraction_status': None,
            'pages': [],
            'parse_error': None
        }
        pdf_result = {}
        risk_summary = {}
        if ext == '.pdf':
            pdf_result = _extract_pdf_pages(p)
            content = pdf_result.get('text') or ''
            parse_metadata = build_parse_metadata(pdf_result, preview_chars=300)
            risk_summary = parse_metadata.get('risk_summary', {})
        elif ext in {'.txt', '.md', '.csv', '.json', '.log', '.xml', '.yaml', '.yml', '.html', '.htm'}:
            content = _read_text_file(p)
        
                # 返回文件信息 - 尝试从数捺获取原文件?
        filename = p.name.split('_', 1)[1] if '_' in p.name else p.name
        
        # 如果文件名是UUID格式，尝试从数据库查询原始文件名
        if filename == p.name and len(filename) > 30:  # 參是UUID
            try:
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute('SELECT original_filename FROM user_files WHERE file_id = %s', (file_id,))
                row = cursor.fetchone()
                conn.close()
                if row:
                    original_filename = row.get('original_filename') if isinstance(row, dict) else row[0]
                    if original_filename:
                        filename = original_filename
                        logger.debug(f"[DEBUG] Found original filename from DB: {filename}")
            except Exception as e:
                logger.error("查询原始文件名失败: %s", type(e).__name__)
        
        full_content = bool(data.get('full_content'))
        try:
            content_limit = int(data.get('content_limit', 50000))
        except (TypeError, ValueError):
            content_limit = 50000
        content_for_response = content if full_content else content[:max(0, content_limit)]
        parse_status = 'parsed' if ext != '.pdf' or pdf_result.get('success') else pdf_result.get('extraction_status', 'empty_or_failed')

        file_result = {
            'file_id': file_id,
            'filename': filename,
            'download_url': f'/api/files/download/{file_id}',
            'content': content_for_response if content else '',
            'content_length': len(content),
            'file_type': ext,
            'parse_status': parse_status,
            'parse_metadata': parse_metadata,
            'risk_summary': risk_summary,
            'citation_hint': 'For PDF evidence, use [n] (p. N). The text cache contains [[page=N]] markers and must not be cited without a page number.',
            'success': True
        }
        logger.info("[API] Successfully processed file: file_id=%s filename=%s", file_id, filename)
        results.append(file_result)
    
    return jsonify({
        'success': True,
        'files': results,
        'total_files': len(results)
    })

@app.route('/api/rag/search', methods=['POST'])
@require_auth
def rag_search():
    data = request.get_json(silent=True) or {}
    query = (data.get('query') or '').strip()
    file_ids = data.get('file_ids') or []
    # 兼字串入参：攌单个ID或?号分隔多个ID
    if isinstance(file_ids, str):
        file_ids = [s.strip() for s in file_ids.split(',') if s.strip()]
    elif not isinstance(file_ids, list):
        file_ids = []
    top_k = int(data.get('top_k') or 5)
    # 新?模式：snippets（默认）?full（全文作为提示词?
    mode = (data.get('mode') or 'snippets').lower()
    # ?参数：臮义切片大小与重叠
    chunk_size = int(data.get('chunk_size') or 1500)
    overlap = int(data.get('overlap') or 200)

    if not query:
        return jsonify({'success': False, 'message': '缺少query'}), 400

    if any(not _file_owned_by_user(str(file_id), g.current_user_id) for file_id in file_ids):
        abort(404)

    TEXT_EXTENSIONS = {'.txt', '.md', '.csv', '.json', '.log', '.xml', '.yaml', '.yml', '.html', '.htm'}
    results = []
    warnings = []

    for fid in file_ids:
        p = _find_uploaded_path_by_id(fid)
        if not p:
            continue
        ext = p.suffix.lower()
        parse_quality = {}
        risk_summary = {}
        if ext == '.pdf':
            pdf_result = _extract_pdf_pages(p)
            text = pdf_result.get('text') or ''
            parse_quality = pdf_result.get('parse_quality') or {}
            risk_summary = build_risk_summary(pdf_result)
            if not pdf_result.get('success'):
                warnings.append({
                    'file_id': fid,
                    'filename': p.name,
                    'status': pdf_result.get('extraction_status'),
                    'message': pdf_result.get('error'),
                })
            elif parse_quality.get('failure_modes'):
                warnings.append({
                    'file_id': fid,
                    'filename': p.name,
                    'status': 'parse_quality_warning',
                    'parse_quality': parse_quality,
                    'risk_summary': risk_summary,
                    'message': risk_summary.get('message') or 'PDF contains layout, formula, table, or figure extraction risks.',
                })
        elif ext in TEXT_EXTENSIONS:
            text = _read_text_file(p)
        else:
            # 其他二进制文档暂不解析。
            text = ''
        if not text.strip():
            continue
        if mode == 'full':
            max_full_chars = int(data.get('max_full_chars') or 8000)
            full_chunk = text.strip()[:max_full_chars]
            if full_chunk:
                page_match = re.search(r'\[\[page=(\d+)\]\]', full_chunk)
                page = int(page_match.group(1)) if page_match else None
                source_confidence = pdf_page_confidence(parse_quality, page) if ext == '.pdf' else None
                results.append({
                    'file_id': fid,
                    'filename': p.name.split('_', 1)[1] if '_' in p.name else p.name,
                    'chunk': full_chunk,
                    'raw_score': 1.0,
                    'score': confidence_adjusted_score(1.0, source_confidence) if ext == '.pdf' else 1.0,
                    'page': page,
                    'citation': _pdf_citation(p.name, page) if ext == '.pdf' else p.name,
                    'parse_quality': parse_quality if ext == '.pdf' else {},
                    'risk_summary': risk_summary if ext == '.pdf' else {},
                    'source_confidence': source_confidence,
                    'parse_risk_level': risk_summary.get('level') if ext == '.pdf' else None,
                })
        else:
            if ext == '.pdf':
                chunks = _split_pdf_pages(pdf_result.get('pages', []), max_chars=chunk_size, overlap=overlap)
            else:
                chunks = [{'chunk': chunk, 'page': None, 'chunk_index': index} for index, chunk in enumerate(_split_chunks(text, max_chars=chunk_size, overlap=overlap), 1)]
            scored = []
            for chunk_data in chunks:
                raw_score = _score_chunk(query, chunk_data['chunk'])
                source_confidence = pdf_page_confidence(parse_quality, chunk_data.get('page')) if ext == '.pdf' else None
                score = confidence_adjusted_score(raw_score, source_confidence) if ext == '.pdf' else round(raw_score, 4)
                scored.append((chunk_data, raw_score, score, source_confidence))
            scored.sort(key=lambda x: x[2], reverse=True)
            for chunk_data, raw_score, score, source_confidence in scored[:top_k]:
                filename = p.name.split('_', 1)[1] if '_' in p.name else p.name
                results.append({
                    'file_id': fid,
                    'filename': filename,
                    'chunk': chunk_data['chunk'],
                    'raw_score': round(raw_score, 4),
                    'score': score,
                    'page': chunk_data['page'],
                    'chunk_index': chunk_data['chunk_index'],
                    'citation': _pdf_citation(filename, chunk_data['page']) if ext == '.pdf' else filename,
                    'parse_quality': parse_quality if ext == '.pdf' else {},
                    'risk_summary': risk_summary if ext == '.pdf' else {},
                    'source_confidence': source_confidence,
                    'parse_risk_level': risk_summary.get('level') if ext == '.pdf' else None,
                })

    results.sort(key=lambda x: x['score'], reverse=True)
    return jsonify({'success': True, 'snippets': results[:top_k], 'warnings': warnings})

# 文件上传配置
UPLOAD_BASE_DIR = BASE_DIR / "user_files"  # 基文件存储盽
ALLOWED_EXTENSIONS_LIBRARY = {'pdf', 'doc', 'docx', 'png', 'jpg', 'jpeg', 'ppt', 'pptx', 'txt', 'xlsx', 'xls'}
MAX_FILE_SIZE = 50 * 1024 * 1024


class _UploadLimitExceeded(RuntimeError):
    pass


def _file_storage_size(file_storage) -> Optional[int]:
    """Measure a seekable upload without consuming it; otherwise defer."""
    try:
        position = file_storage.stream.tell()
        file_storage.stream.seek(0, os.SEEK_END)
        size = file_storage.stream.tell()
        file_storage.stream.seek(position)
        return int(size)
    except (AttributeError, OSError, TypeError, ValueError):
        return None


def _remove_uploaded_paths(paths) -> None:
    for path in paths:
        try:
            Path(path).unlink(missing_ok=True)
        except OSError:
            logger.warning("上传失败后的文件清理失败: %s", Path(path).name)

# 硿基上传盽存在
UPLOAD_BASE_DIR.mkdir(parents=True, exist_ok=True)

def allowed_file(filename):
    """检查文档库上传允许的扩展名。"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS_LIBRARY


def get_user_upload_dir(user_id):
    """获取用户专属的上传目录。"""
    user_dir = UPLOAD_BASE_DIR / str(user_id)
    user_dir.mkdir(parents=True, exist_ok=True)
    return user_dir


def get_file_size_mb(size_bytes):
    """将字节转捸MB"""
    return round(size_bytes / (1024 * 1024), 2)


# ------------------- 文件管理接口 -------------------
def _library_links():
    from research_library import LibraryLinks
    return LibraryLinks(RESEARCH_LIBRARY_STATE_PATH)


def _library_owned_file(file_id):
    if not isinstance(file_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", file_id):
        abort(404)
    connection = get_db_connection()
    try:
        with connection.cursor() as cursor:
            cursor.execute("""SELECT file_id, user_id, original_filename, stored_filename,
                file_path, file_size, file_type, status, upload_time FROM user_files
                WHERE file_id=%s AND user_id=%s""", (file_id, g.current_user_id))
            row = cursor.fetchone()
            if not row:
                abort(404)
            return row
    finally:
        connection.close()


def _library_outcomes(file_id):
    from research_library import snapshot
    from multi_agent_agents import sanitize_artifact_text
    rows = []
    for link in _library_links().tasks(g.current_user_id, file_id):
        task_id = link["task_id"]
        with _RESOURCE_OWNER_LOCK:
            if _SCIENCE_TASK_OWNERS.get(task_id) != str(g.current_user_id):
                rows.append({"task_id": None, "conversation_id": None, "status": "unavailable",
                             "report_available": False, "query": "任务归属记录暂不可用", "created_at": None,
                             "_snapshot": None})
                continue
        task = snapshot(SCIENCE_TASK_STATE_DIR, task_id)
        if not task or task.get("library_file_id") != file_id:
            rows.append({"task_id": task_id, "conversation_id": None, "status": "unavailable",
                         "report_available": False, "query": "任务记录暂不可用", "created_at": None,
                         "_snapshot": None})
            continue
        rows.append({"task_id": task_id, "conversation_id": task.get("conversation_id"),
                     "status": task.get("status"), "report_available": bool(task.get("report_available")),
                     "query": sanitize_artifact_text(str(task.get("query") or ""))[:500],
                     "created_at": task.get("created_at"), "_snapshot": task})
    return rows


def _library_summary(row):
    from research_library import processing_state, LABELS
    file_id = row.get("file_id", row.get("id"))
    outcomes = _library_outcomes(file_id)
    state = (processing_state(outcomes[0]["_snapshot"]) if outcomes and outcomes[0]["_snapshot"]
             else 'unavailable' if outcomes else 'uploaded')
    # Keep truthful successful index history even if a later task failed.
    indexed = any(processing_state(item["_snapshot"]) == "indexed" for item in outcomes)
    name = row.get("original_filename", row.get("name", ""))
    return {"id": file_id, "name": name, "size": row.get("file_size", row.get("size", 0)),
            "type": row.get("file_type") or str(name).rsplit('.', 1)[-1].lower(),
            "status": LABELS[state], "processing_state": state, "has_indexed_run": indexed,
            "index_scope": "private_task" if indexed else None,
            "upload_time": convert_datetime_to_string(row.get("upload_time")),
            "can_analyze": str(name).lower().endswith(".pdf"), "can_qa": str(name).lower().endswith(".pdf"),
            "outcomes": [{key: value for key, value in item.items() if key != "_snapshot"} for item in outcomes],
            "outcomes_scope": "recent_20_tasks", "unavailable_outcome_count": sum(item['_snapshot'] is None for item in outcomes),
            "index_note": "索引属于对应任务；新问题仍需重新检索和审查，不等于全库已入库。"}


@app.route('/api/research-library/files/<file_id>', methods=['GET'])
@require_auth
def research_library_detail(file_id):
    try:
        return jsonify(success=True, file=_library_summary(_library_owned_file(file_id)))
    except HTTPException:
        raise
    except (OSError, sqlite3.Error, pymysql.MySQLError) as exc:
        return _safe_internal_failure("research_library_detail", exc)


@app.route('/api/research-library/files/<file_id>/pdf', methods=['GET'])
@require_auth
def research_library_pdf(file_id):
    try:
        from research_library import original_path
        from multi_agent_local_pdf import validate_pdf_input
        row = _library_owned_file(file_id)
        path = validate_pdf_input(original_path(UPLOAD_BASE_DIR, g.current_user_id, row))
        return send_file(path, mimetype='application/pdf', as_attachment=False,
                         download_name=safe_filename_unicode(row['original_filename']), max_age=0)
    except HTTPException:
        raise
    except (OSError, ValueError):
        abort(404)
    except pymysql.MySQLError as exc:
        return _safe_internal_failure("research_library_pdf", exc)


@app.route('/api/research-library/files/<file_id>/pages/<int:page>', methods=['GET'])
@require_auth
def research_library_page(file_id, page):
    try:
        from io import BytesIO
        from research_library import original_path, render_preview, PreviewError
        from multi_agent_local_pdf import validate_pdf_input
        row = _library_owned_file(file_id)  # Authorize before opening/rendering.
        path = validate_pdf_input(original_path(UPLOAD_BASE_DIR, g.current_user_id, row))
        meta, png = render_preview(path, page)
        response = send_file(BytesIO(png), mimetype='image/png', max_age=0)
        response.headers['X-PDF-Page-Count'] = str(meta['page_count'])
        response.headers['X-PDF-Page'] = str(meta['page'])
        return response
    except HTTPException:
        raise
    except PreviewError as exc:
        code = str(exc)
        return jsonify(success=False, error=code, message='原文页暂不可用，可下载 PDF 原件查看。'), (503 if code in {'PREVIEW_BUSY', 'PREVIEW_TIMEOUT'} else 422)
    except (OSError, ValueError):
        abort(404)
    except pymysql.MySQLError as exc:
        return _safe_internal_failure("research_library_page", exc)


@app.route('/api/research-library/files', methods=['GET'])
@require_auth
def research_library_list():
    return get_user_files(g.current_user_id)


@app.route('/api/research-library/upload', methods=['POST'])
@app.route('/api/files/upload', methods=['POST'])
@require_auth
def upload_files(_owned_files=None, _library=False):
    """
    上传文件接口
    请求：multipart/form-data
    - files: 文件列表
    - user_id: 用户ID
    """
    try:
        # 获取用户ID
        user_id = g.current_user_id

        # 获取上传的文件列表。
        files = request.files.getlist('files') if _owned_files is None else _owned_files
        library_upload = _library or request.path.endswith('/research-library/upload')
        if not files:
            return jsonify({'success': False, 'message': '没有上传文件'}), 400

                # ?查文件数?
        if len(files) > 10:
            return jsonify({'success': False, 'message': '一次最多上传 10 个文件'}), 400

        # Validate the complete batch before opening the database or writing
        # its first member, so a bad later member cannot leave earlier files.
        measured_total = 0
        non_empty_files = []
        for candidate in files:
            if not candidate.filename:
                continue
            if not allowed_file(candidate.filename):
                return jsonify({
                    'success': False,
                    'message': f'文件 {candidate.filename} 格式不支持'
                }), 400
            measured_size = _file_storage_size(candidate)
            if library_upload:
                if not candidate.filename.lower().endswith('.pdf') or len(candidate.filename) > 255:
                    return jsonify(error="LIBRARY_PDF_REQUIRED", message="科研资料库目前只接受 PDF。"), 400
                if measured_size is not None and measured_size > 30 * 1024 * 1024:
                    return jsonify(error="LOCAL_PDF_SIZE_LIMIT", message="单篇 PDF 不能超过 30MiB。"), 413
                position = candidate.stream.tell()
                header = candidate.stream.read(1024)
                candidate.stream.seek(position)
                if not header.lstrip().startswith(b'%PDF-'):
                    return jsonify(error="INVALID_LIBRARY_PDF", message="文件不是有效 PDF。"), 400
            if measured_size is not None:
                measured_total += measured_size
                if measured_total > MAX_FILE_SIZE:
                    return jsonify({
                        'success': False,
                        'message': '文件总大小超过 50MB 限制'
                    }), 413
            non_empty_files.append(candidate)
        if not non_empty_files:
            return jsonify({'success': False, 'message': '没有上传文件'}), 400

        # 获取用户上传盽
        user_dir = get_user_upload_dir(user_id)

        # 数据库连接。
        connection = get_db_connection()
        uploaded_files = []
        saved_paths = []
        total_size = 0

        try:
            with connection.cursor() as cursor:
                for file in non_empty_files:

                    # 验证文件类型
                    if not allowed_file(file.filename):
                        return jsonify({
                            'success': False,
                            'message': f'文件 {file.filename} 格式不支持'
                        }), 400

                    # 生成安全的文件名
                    # 保存原始文件名用于显示。
                    original_filename = file.filename
                    file_id = str(uuid.uuid4())
                    
                    # 安全地提取文件扩展名
                    if '.' in original_filename:
                        file_extension = original_filename.rsplit('.', 1)[1].lower()
                    else:
                        return jsonify({
                            'success': False,
                            'message': f'文件 {file.filename} 缺少文件扩展名'
                        }), 400
                    
                    # 使用 UUID 生成安全的服务器文件名。
                    safe_filename = f"{file_id}.{file_extension}"

                    # 保存文件
                    file_path = user_dir / safe_filename
                    saved_paths.append(file_path)
                    file.save(str(file_path))

                    # 获取文件大小
                    file_size = os.path.getsize(file_path)
                    if library_upload and file_size > 30 * 1024 * 1024:
                        raise _UploadLimitExceeded('library_pdf')
                    total_size += file_size

                    # 检查总大小限制。
                    if total_size > MAX_FILE_SIZE:
                        raise _UploadLimitExceeded()

                    # 将文件信恭入数捺
                    sql = """
                        INSERT INTO user_files 
                        (file_id, user_id, original_filename, stored_filename, file_path, 
                         file_size, file_type, status, upload_time)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, NOW())
                    """
                    cursor.execute(sql, (
                        file_id,
                        user_id,
                        original_filename,
                        safe_filename,
                        str(file_path),
                        file_size,
                        file_extension,
                        'processing',
                    ))

                    uploaded_files.append({
                        'file_id': file_id,
                        'filename': original_filename,
                        'size': file_size,
                        'processing_state': 'uploaded',
                        'status': '已上传，尚未索引'
                    })

                # Existing MySQL enum is retained for compatibility. Upload is
                # storage only; the library API derives real index state from
                # task-owned progress, never this legacy status column.
                connection.commit()

                return jsonify({
                    'success': True,
                    'message': '文件上传成功',
                    'uploaded_count': len(uploaded_files),
                    'files': uploaded_files
                }), 200

        except _UploadLimitExceeded as limit_error:
            connection.rollback()
            _remove_uploaded_paths(saved_paths)
            return jsonify({
                'success': False,
                'message': '单篇 PDF 超过 30MiB 限制' if limit_error.args == ('library_pdf',) else '文件总大小超过 50MB 限制'
            }), 413
        except Exception as e:
            connection.rollback()
            _remove_uploaded_paths(saved_paths)
            raise e
        finally:
            connection.close()

    except HTTPException:
        raise
    except Exception as e:
        return _safe_internal_failure("upload_files", e)


@app.route('/api/files/list/<user_id>', methods=['GET'])
@require_auth
def get_user_files(user_id):
    """
    获取用户的文件列?    """
    try:
        _require_requested_user_is_current(user_id)
        connection = get_db_connection()
        try:
            with connection.cursor() as cursor:
                sql = """
                    SELECT file_id, original_filename as name, file_size as size, file_type,
                           status, upload_time, 
                           CASE 
                               WHEN status = 'processed' THEN TRUE 
                               ELSE FALSE 
                           END as can_qa
                    FROM user_files
                    WHERE user_id = %s
                    ORDER BY upload_time DESC
                    LIMIT 1000
                """
                cursor.execute(sql, (user_id,))
                files = cursor.fetchall()

                # 轍数据格式
                file_list = []
                for file in files:
                    file_list.append(_library_summary(file))

                return jsonify({
                    'success': True,
                    'files': file_list
                }), 200

        finally:
            connection.close()

    except HTTPException:
        raise
    except Exception as e:
        return _safe_internal_failure("list_files", e)


@app.route('/api/files/download/<file_id>', methods=['GET'])
@require_auth
def download_file(file_id):
    """
    下载文件
    """
    try:
        connection = get_db_connection()
        try:
            with connection.cursor() as cursor:
                # 查文件信息
                sql = """
                    SELECT user_id, original_filename, stored_filename, file_path
                    FROM user_files
                    WHERE file_id = %s AND user_id = %s
                """
                cursor.execute(sql, (file_id, g.current_user_id))
                file_info = cursor.fetchone()

                if not file_info:
                    return jsonify({'success': False, 'message': '文件不存在'}), 404

                # 获取文件跾
                from research_library import original_path
                file_path = original_path(UPLOAD_BASE_DIR, g.current_user_id, file_info)

                if not file_path.exists():
                    return jsonify({'success': False, 'message': '文件已删除'}), 404

                # 发送下载文件。
                return send_file(
                    file_path,
                    as_attachment=True,
                    download_name=file_info['original_filename']
                )

        finally:
            connection.close()

    except Exception as e:
        return _safe_internal_failure("download_file", e)


@app.route('/api/files/delete/<file_id>', methods=['DELETE'])
@require_auth
def delete_file(file_id):
    """
    删除文件
    """
    try:
        connection = get_db_connection()
        try:
            with connection.cursor() as cursor:
                # 查文件信息
                sql = """
                    SELECT user_id, file_path
                    FROM user_files
                    WHERE file_id = %s AND user_id = %s
                """
                cursor.execute(sql, (file_id, g.current_user_id))
                file_info = cursor.fetchone()

                if not file_info:
                    return jsonify({'success': False, 'message': '文件不存在'}), 404

                # 删除物理文件
                from research_library import original_path
                file_path = original_path(UPLOAD_BASE_DIR, g.current_user_id, file_info, must_exist=False)
                if file_path.exists():
                    os.remove(file_path)

                # 从数捺删除记录
                sql_delete = "DELETE FROM user_files WHERE file_id = %s AND user_id = %s"
                cursor.execute(sql_delete, (file_id, g.current_user_id))
                connection.commit()

                return jsonify({
                    'success': True,
                    'message': '文件删除成功'
                }), 200

        except Exception as e:
            connection.rollback()
            raise e
        finally:
            connection.close()

    except Exception as e:
        return _safe_internal_failure("delete_file", e)


@app.route('/api/files/batch-delete', methods=['POST'])
@require_auth
def batch_delete_files():
    """
    批量删除文件
    """
    try:
        # 获取请求数据
        data = request.get_json(silent=True) or {}
        file_ids = list(dict.fromkeys(data.get('file_ids', [])))
        
        if not file_ids or not isinstance(file_ids, list):
            return jsonify({'success': False, 'message': '无效的文件ID列表'}), 400
        
        connection = get_db_connection()
        try:
            with connection.cursor() as cursor:
                # 查?有删除的文件信?
                placeholders = ','.join(['%s'] * len(file_ids))
                sql = f"""
                    SELECT user_id, file_path, file_id
                    FROM user_files
                    WHERE file_id IN ({placeholders}) AND user_id = %s
                """
                cursor.execute(sql, (*file_ids, g.current_user_id))
                files_to_delete = cursor.fetchall()
                
                # ?查是否有文件存在
                if len(files_to_delete) != len(file_ids):
                    return jsonify({'success': False, 'message': '文件不存在或无权删除'}), 404
                
                # 收集实际要删除的文件ID
                actual_file_ids = [file['file_id'] for file in files_to_delete]
                
                # 删除物理文件
                from research_library import original_path
                # Validate every path before deleting any member of the batch.
                owned_paths = [original_path(UPLOAD_BASE_DIR, g.current_user_id, row, must_exist=False) for row in files_to_delete]
                for file_path in owned_paths:
                    if file_path.exists():
                        os.remove(file_path)
                
                # 从数捺批量删除记录
                sql_delete = f"DELETE FROM user_files WHERE file_id IN ({placeholders}) AND user_id = %s"
                cursor.execute(sql_delete, (*actual_file_ids, g.current_user_id))
                connection.commit()
                
                return jsonify({
                    'success': True,
                    'message': f'成功删除 {len(actual_file_ids)} 个文件',
                    'deleted_count': len(actual_file_ids)
                }), 200
        
        except Exception as e:
            connection.rollback()
            raise e
        finally:
            connection.close()

    except Exception as e:
        return _safe_internal_failure("batch_delete_files", e)


@app.route('/api/files/start_qa', methods=['POST'])
@require_auth
def start_file_qa():
    """启动文件问答模式。"""

    try:
        data = request.get_json(silent=True) or {}
        file_id = data.get('file_id')
        session_id = data.get('session_id')

        if not file_id or not session_id:
            return jsonify({'success': False, 'message': '缺少必参数'}), 400

        connection = get_db_connection()
        try:
            with connection.cursor() as cursor:
                # 查文件信息
                sql = """
                    SELECT file_id, original_filename, status
                    FROM user_files
                    WHERE file_id = %s AND user_id = %s
                """
                cursor.execute(sql, (file_id, g.current_user_id))
                file_info = cursor.fetchone()

                if not file_info:
                    return jsonify({'success': False, 'message': '文件不存在'}), 404

                if file_info['status'] != 'processed':
                    return jsonify({'success': False, 'message': '文件尚未处理完成'}), 400

                if not _session_owned(cursor, session_id, g.current_user_id):
                    return jsonify({'success': False, 'message': '会话不存在或无权访问'}), 404

                # TODO: 这里叻创建文件闭会话，关联file_id和session_id
                # 例：将file_id存入会话上下文，供后绗答使?
                return jsonify({
                    'success': True,
                    'message': f'已为文件 {file_info["original_filename"]} 吊闭模式',
                    'file_id': file_id,
                    'filename': file_info['original_filename']
                }), 200

        finally:
            connection.close()

    except Exception as e:
        return _safe_internal_failure("start_file_qa", e)

@app.route('/api/literature/papers', methods=['GET'])
@require_auth
def list_literature_papers():
    """列出本地缓存的文献 PDF（arxiv/hal/zenodo 等下载的论文）。"""
    try:
        try:
            offset = max(0, int(request.args.get('offset', '0')))
        except ValueError:
            return jsonify(error='INVALID_CACHE_PAGE'), 400
        lit_dir = _user_literature_root()
        papers = []
        if offset == 0 and lit_dir.exists():
            for sub in sorted(lit_dir.iterdir()):
                if sub.is_symlink() or not sub.is_dir():
                    continue
                pdfs = list(sub.glob("*.pdf"))
                if not pdfs:
                    continue
                total_size = sum(p.stat().st_size for p in sub.iterdir() if p.is_file())
                mtime = max((p.stat().st_mtime for p in sub.iterdir() if p.is_file()), default=0)
                papers.append({
                    "id": sub.name,
                    "source": sub.name.split("_")[0],
                    "dir": sub.name,
                    "pdf_count": len(pdfs),
                    "size_mb": round(total_size / 1024 / 1024, 2),
                    "mtime": mtime,
                })
        from multi_agent_web import cached_papers, run_directory
        with _RESOURCE_OWNER_LOCK:
            task_ids = [task_id for task_id, owner in _SCIENCE_TASK_OWNERS.items()
                        if owner == str(g.current_user_id) and re.fullmatch(r'[0-9a-f]{12}', task_id)]
        def modified(task_id):
            try:
                return run_directory(task_id).stat().st_mtime
            except (OSError, ValueError):
                return 0
        task_ids.sort(key=modified, reverse=True)
        batch = task_ids[offset:offset + 40]
        for task_id in batch:
            try:
                papers.extend(cached_papers(task_id))
            except (OSError, ValueError):
                continue
        papers.sort(key=lambda x: x['mtime'], reverse=True)
        return jsonify(success=True, papers=papers, scanned_tasks=len(batch),
                       next_offset=offset + len(batch) if offset + len(batch) < len(task_ids) else None,
                       note='仅当前账号实际下载的原文；未下载的候选和归属不明的共享缓存不列入。缓存不代表通过科研审查。')
    except Exception as e:
        return _safe_internal_failure("list_literature_papers", e)


@app.route('/api/literature/papers/<path:dir_name>', methods=['DELETE'])
@require_auth
def delete_literature_paper(dir_name):
    """删除一篇本地缓存的文献（整个源目录）。"""
    try:
        lit_dir = _user_literature_root()
        target = lit_dir / dir_name
        if (not re.fullmatch(r'[A-Za-z0-9_.-]{1,180}', dir_name) or dir_name in {'.', '..'}
                or target.is_symlink() or not target.resolve().is_relative_to(lit_dir.resolve())
                or not target.exists() or not target.is_dir()):
            return jsonify({"success": False, "message": "目录不存在"}), 404
        import shutil
        shutil.rmtree(target)
        return jsonify({"success": True})
    except Exception as e:
        return _safe_internal_failure("delete_literature_paper", e)


def _user_literature_root():
    from user_credentials import owner_id
    base = Path(os.getenv('SCIASSISTANT_WORKSPACE', str(BASE_DIR / 'workspace'))).resolve()
    user = base / 'users' / owner_id(g.current_user_id)
    result = user / 'literature'
    if user.is_symlink() or result.is_symlink() or not result.resolve().is_relative_to(base):
        raise ValueError('UNSAFE_USER_WORKSPACE')
    return result


@app.get('/api/literature/tasks/<task_id>/papers/<document_id>/pdf')
@require_auth
def task_cached_paper_pdf(task_id, document_id):
    _require_science_task_owner(task_id)
    from multi_agent_web import cached_paper_path
    try:
        path = cached_paper_path(task_id, document_id)
    except (OSError, ValueError):
        abort(404)
    response = send_file(path, mimetype='application/pdf', as_attachment=True, download_name=document_id + '.pdf')
    response.headers['Cache-Control'] = 'no-store'
    return response


@app.post('/api/literature/tasks/<task_id>/papers/<document_id>/save')
@require_auth
def task_cached_paper_save(task_id, document_id):
    _require_science_task_owner(task_id)
    from multi_agent_web import cached_paper_path
    from werkzeug.datastructures import FileStorage
    try:
        path = cached_paper_path(task_id, document_id)
    except (OSError, ValueError):
        abort(404)
    # Use the normal validation, own-user UUID path, SQL transaction and rollback.
    with path.open('rb') as stream:
        return upload_files(_owned_files=[FileStorage(stream=stream, filename=document_id + '.pdf', content_type='application/pdf')], _library=True)


@app.route('/api/health', methods=['GET'])
def health_check():
    """健康检查接口。"""
    return jsonify({'status': 'healthy', 'message': '服务器运行正常',
                    'runtime': _GATEWAY_RUNTIME.snapshot()})


@app.route('/api/readyz', methods=['GET'])
def readiness_check():
    """Report whether the gateway can currently serve database-backed requests."""
    storage_ready = has_minimum_free_space(
        (LOG_DIR, UPLOAD_DIR, UPLOAD_BASE_DIR), RUNTIME_STORAGE_MIN_FREE_BYTES
    )
    if not storage_ready:
        logger.warning("Gateway readiness storage check failed")
        return jsonify({"status": "not_ready", "components": {
            "database": "not_checked", "runtime_storage": "unavailable"
        }}), 503
    connection = None
    try:
        connection = get_db_connection()
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            cursor.fetchone()
    except Exception as exc:  # noqa: BLE001 - readiness must not expose internals
        logger.warning("Gateway readiness database check failed: %s", type(exc).__name__)
        return jsonify({"status": "not_ready", "components": {
            "database": "unavailable", "runtime_storage": "ready"
        }}), 503
    finally:
        if connection:
            connection.close()
    return jsonify({"status": "ready", "components": {
        "database": "ready", "runtime_storage": "ready"
    }})


if __name__ == '__main__':
    try:
        bind_host, bind_port = _configured_account_listener()
    except RuntimeError:
        print("Error: LOCAL_BIND_REQUIRED", file=sys.stderr)
        raise SystemExit(2) from None
    # Direct launches receive the same fail-closed schema gate as the Windows
    # launcher and account container. Gunicorn runs the gate in its Docker CMD.
    from account_schema import run as run_account_schema
    schema_report, schema_exit = run_account_schema("check")
    if schema_exit:
        logger.error("账户数据库结构检查失败: %s", schema_report.get("error", "UNKNOWN"))
        raise SystemExit(schema_exit)
    app.run(debug=False, host=bind_host, port=bind_port)
