"""Small, privacy-preserving request correlation for Flask services.

The project deliberately logs route templates instead of raw URLs: query
strings can contain research questions, file names, or credentials.  A client
may supply a correlation ID only when it matches the conservative format
below; otherwise the service creates a new opaque ID.
"""

from __future__ import annotations

import re
import time
import uuid
from logging import Logger

from flask import Flask, g, request


REQUEST_ID_HEADER = "X-Request-ID"
REQUEST_ID_PATTERN = re.compile(r"[A-Za-z0-9_-]{8,64}")


def install_request_observability(app: Flask, logger: Logger, component: str) -> None:
    """Attach safe request IDs and completion logs to one Flask application."""

    @app.before_request
    def _start_request_observability() -> None:
        supplied = str(request.headers.get(REQUEST_ID_HEADER) or "")
        g.request_id = supplied if REQUEST_ID_PATTERN.fullmatch(supplied) else uuid.uuid4().hex
        g.request_started_monotonic = time.monotonic()

    @app.after_request
    def _finish_request_observability(response):
        request_id = str(getattr(g, "request_id", "") or uuid.uuid4().hex)
        response.headers[REQUEST_ID_HEADER] = request_id
        started = getattr(g, "request_started_monotonic", None)
        elapsed_ms = 0
        if isinstance(started, (int, float)):
            elapsed_ms = max(0, round((time.monotonic() - started) * 1000))
        route = request.url_rule.rule if request.url_rule is not None else "unmatched"
        logger.info(
            "http_complete component=%s request_id=%s method=%s route=%s status=%s duration_ms=%s",
            component,
            request_id,
            request.method,
            route,
            response.status_code,
            elapsed_ms,
        )
        return response
