"""Public-safe source identity captured at import, not export-time Git HEAD.

This is an operational fingerprint, not attestation of every loaded dependency.
No environment, private file, path, prompt or credential is fingerprinted.
"""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import uuid

ROOT = Path(__file__).resolve().parent
IDENTITY_FILES = (
    "app.py", "web_app.py", "runtime_identity.py", "research_runtime.py", "process_cleanup.py",
    "request_observability.py", "source_delivery.py",
    "rag_storage_lock.py",
    "external_embedding.py",
    "science_pdf_sessions.py", "multi_agent_local_pdf.py", "multi_agent_sources.py", "chatAi/pdf_session.js", "chatAi/conversation_selection.js",
    "multi_agent_web.py", "multi_agent_agents.py", "multi_agent_workflow.py", "multi_agent_presentation.py",
    "multi_agent_pipeline_v2.py", "multi_agent_rag.py", "multi_agent_live.py", "multi_agent_report.py", "multi_agent_status.py", "multi_agent_evidence.py", "multi_agent_quality.py",
    "multi_agent_handoffs.py", "multi_agent_report_contracts.py", "multi_agent_sections.py", "multi_agent_skills.py", "multi_agent_publication.py", "multi_agent_audit_batches.py",
    "tools/multi_agent_cli.py", "tools/multi_agent_parse_pdf.py", "tools/multi_agent_download_pdf.py",
    "deepdiver_v2/src/literature_sources.py",
    "multi_agent_demo_runner.py", "tools/rag_cloud.py", "tools/rag_startup.py",
    "deepdiver_v2/requirements.rag.cloud.hashes.txt", "deepdiver_v2/rag.cloud.artifacts.json",
    "chatAi/multi_agent_rag.js", "chatAi/multi_agent_rag.css",
    "chatAi/chat_theme.js", "chatAi/chat_theme.css",
    "research_library.py", "chatAi/research_library.js", "chatAi/research_library.css",
    "user_credentials.py", "chatAi/account_keys.js", "chatAi/attachment_menu.js", "pdf_pipeline.py",
    "deepdiver_v2/config/config.py", "deepdiver_v2/src/tools/llama_vision_client.py",
    "deepdiver_v2/src/tools/__init__.py",
    "deepdiver_v2/requirements.txt", "deepdiver_v2/requirements.cloud.txt",
    "deepdiver_v2/constraints.cloud.txt", "deepdiver_v2/requirements.cloud.hashes.txt",
    "tools/dependency_lock.py",
    "deepdiver_v2/cli/demo.py", "deepdiver_v2/src/bounded_paper.py",
    "deepdiver_v2/src/model_key_pool.py", "deepdiver_v2/src/tools/mcp_client.py",
    "chatAi/login.html", "chatAi/register.html", "chatAi/ai_chat.html",
    "chatAi/forgot-password.html", "chatAi/assets/manifest.json",
)


def source_fingerprint(root=ROOT):
    digest = hashlib.sha256()
    complete = True
    for name in IDENTITY_FILES:
        try:
            content = (Path(root) / name).read_bytes()
        except OSError:
            complete = False
            content = b"<missing>"
        digest.update(name.encode() + b"\0" + hashlib.sha256(content).digest())
    return digest.hexdigest(), complete


def image_revision(root=ROOT):
    try:
        value = json.loads((Path(root) / ".build-info.json").read_text(encoding="utf-8"))["revision"]
        return value if isinstance(value, str) and re.fullmatch(r"[0-9a-f]{7,40}|unknown", value) else "unknown"
    except (OSError, ValueError, KeyError, TypeError):
        return "unknown"


class RuntimeIdentity:
    def __init__(self, component, root=ROOT):
        self.root = Path(root)
        self.component = component
        self.started_at = datetime.now(timezone.utc).isoformat()
        self.instance_id = uuid.uuid4().hex
        self.fingerprint, self.complete = source_fingerprint(root)
        self.revision = image_revision(root)
        try:
            build = json.loads((self.root / ".build-info.json").read_text(encoding="utf-8"))
            self.image_source_matches = (build.get("schema") == "sciassistant.build/v1"
                and isinstance(build.get("revision"), str)
                and bool(re.fullmatch(r"[0-9a-f]{7,40}|unknown", build["revision"]))
                and build.get("source_fingerprint") == self.fingerprint)
        except (OSError, ValueError, TypeError, AttributeError):
            # Unstamped local checkout is unknown; malformed present stamp fails.
            self.image_source_matches = False if (self.root / ".build-info.json").exists() else None
            build = {}
        dependency = build.get("dependency_lock") if isinstance(build, dict) else None
        self.dependency_lock = dependency if (
            isinstance(dependency, dict)
            and re.fullmatch(r"[0-9a-f]{64}", str(dependency.get("sha256", "")))
            and re.fullmatch(r"[0-9a-f]{64}", str(dependency.get("constraints_sha256", "")))
            and isinstance(dependency.get("package_count"), int)
            and dependency["package_count"] > 0
            and isinstance(dependency.get("base_image"), str)
            and "@sha256:" in dependency["base_image"]
            and dependency.get("platform") == "linux/amd64"
        ) else None

    def snapshot(self):
        current, complete = source_fingerprint(self.root)
        return {"schema": "sciassistant.runtime/v1", "component": self.component,
                "instance_id": self.instance_id, "started_at": self.started_at,
                "image_revision": self.revision, "source_fingerprint": self.fingerprint,
                "source_complete": self.complete,
                "image_source_matches_startup": self.image_source_matches,
                "dependency_lock": self.dependency_lock,
                "code_on_disk_matches_startup": complete and self.complete and current == self.fingerprint}
