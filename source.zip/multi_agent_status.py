"""Chinese presentation metadata, kept separate from scientific answer text."""
from collections import Counter
from html import escape
from collections.abc import Mapping

EXECUTION_NOTICE_POLICY = "recorded-source-execution-outside-scientific-claims/v1"
_SOURCE_PROBLEMS = {"source_unreachable": "无法连接来源", "unreachable": "无法连接来源",
    "rate_limited": "来源限流", "cooldown_skipped": "来源冷却，跳过查询",
    "skipped": "查询跳过", "deadline_skipped": "剩余时间不足，跳过查询",
    "no_results": "查询未返回候选", "parse_failed": "来源响应解析失败"}


def source_execution_notice(run_id, evidence):
    """Workflow-owned execution facts; no paper content or scientific verdict.

    Queries/paths/provider details are deliberately not exported. Count only
    recorded public queries, never equate candidate count with indexed papers.
    """
    counts, seen = Counter(), set()
    observations = evidence.get("observations", []) if isinstance(evidence, Mapping) else []
    for row in observations[:200] if isinstance(observations, list) else []:
        if not isinstance(row, Mapping) or row.get("source") != "arxiv" or "query" not in row:
            continue
        status = row.get("source_status")
        if not isinstance(status, str) or status not in _SOURCE_PROBLEMS:
            continue
        key = (row.get("request_id"), row.get("group_id"), row.get("query"), bool(row.get("recovery")), status)
        if not all(value is None or isinstance(value, (str, bool)) for value in key):
            continue
        if key in seen:
            continue
        seen.add(key)
        counts[status] += 1
    return {"schema_version": "sciassistant.source-execution-notice/v1", "policy": EXECUTION_NOTICE_POLICY,
            "run_id": run_id, "source": "arxiv", "problems": [
                {"status": status, "count": count} for status, count in sorted(counts.items())]}


def source_execution_lines(notice, run_id):
    """Render validated fields, not model-provided text or another run's notice."""
    if (not isinstance(notice, Mapping) or notice.get("schema_version") != "sciassistant.source-execution-notice/v1"
            or notice.get("policy") != EXECUTION_NOTICE_POLICY or notice.get("run_id") != run_id
            or notice.get("source") != "arxiv" or not isinstance(notice.get("problems"), list)
            or len(notice["problems"]) > len(_SOURCE_PROBLEMS)):
        return []
    parts, seen = [], set()
    for row in notice["problems"]:
        if (not isinstance(row, Mapping) or set(row) != {"status", "count"}
                or not isinstance(row.get("status"), str) or row["status"] not in _SOURCE_PROBLEMS
                or row["status"] in seen or type(row.get("count")) is not int or not 1 <= row["count"] <= 200):
            return []
        seen.add(row["status"])
        parts.append(_SOURCE_PROBLEMS[row["status"]] + f" {row['count']} 次")
    return ["公开来源执行记录：arXiv — " + "；".join(parts),
            "这只是本轮查询的执行情况，不代表相关论文不存在；正文仅使用已经取得并批准的证据。"] if parts else []


STATUS_COPY = {
    "completed": ("已完成：主要问题已覆盖，回答通过审查", "success",
        "本轮主要问题已有获批证据支持，保留的回答声明通过了引用审查。这不代表结论在所有模型、硬件或实验条件下都成立。",
        "可阅读和使用正文；引用具体数字时，仍应核对原文位置、实验条件和适用范围。"),
    "partial": ("有限回答：已审查内容可用，但证据覆盖不完整", "partial",
        "已有可靠证据形成有限回答，保留的声明通过审查；部分子问题、指标或可比实验仍有缺口。缺少数据或实验不可比，不等于现有回答有错误。",
        "可使用正文中有引用且说明适用范围的结论；不要把缺项补成确定数字，也不要将吞吐、显存改善直接当作延迟降低。"),
    "needs_review": ("需要复核：仍有审查疑点，不能当作已核验结论", "review",
        "本轮资料或回答仍存在未解决的审查疑点，例如证据冲突、引用支持或原文定位问题。它与“有限回答”不同：不只是覆盖不完整，可靠性也需要进一步核对。",
        "正文仅供待核对的研究线索；请先查看疑点与原文证据，再决定是否采用。未经核对，不应直接作为定量结论或正式报告依据。"),
    "failed": ("分析未完成：未能形成可安全使用的回答", "error",
        "本轮未能完成分析或没有可用证据，不能视为科研结论。安全失败说明并不代表该领域没有研究。",
        "查看失败说明，确认检索、网络或模型服务状态后再决定是否重试；不要从失败状态推断科学结论。"),
    "timed_out": ("分析超时：预算内未完成", "error", "本轮达到时间预算，已停止后续处理；不能视为已审查完成的回答。", "可查看已保存证据，缩小问题范围后重试。"),
    "cancelled": ("已取消：分析已停止", "neutral", "用户已停止本轮分析，已保存的片段不等于最终审查结论。", "如需完整回答，请重新提交任务。"),
}
COVERAGE_COPY = {"missing": "缺少证据", "partial": "仅部分覆盖", "not_reported": "所选片段未报告指标",
                 "not_comparable": "实验不可直接比较", "conflicting": "存在证据冲突"}
METRIC_COPY = {"latency": "延迟", "single_request_latency": "单请求延迟", "throughput": "吞吐量",
               "memory": "显存/内存", "quality": "生成质量", "generation quality": "生成质量",
               "generation_quality": "生成质量", "preference alignment": "偏好一致性",
               "sample efficiency": "样本效率", "planning quality": "规划质量", "generalization": "泛化能力"}
OUTCOME_CSS = ".result-status{border:1px solid #ccd4de;border-left:5px solid #27805d;border-radius:8px;padding:1rem;margin:1rem 0;overflow-wrap:anywhere}.result-status.partial{background:#fff8df;border-left-color:#b78300}.result-status.review{background:#fff0e6;border-left-color:#b45309}.result-status.error{background:#fff0f0;border-left-color:#b42318}.result-status h2{font-size:1.1rem;margin-top:0}"
OUTCOME_CSS += ".billing-alert{border:2px solid #b42318;border-left-width:7px;border-radius:10px;background:#fff1f0;color:#7a271a;padding:18px;margin:0 0 16px;overflow-wrap:anywhere}.billing-alert h3{font-size:1.2rem;font-weight:800;margin:0 0 10px}.billing-alert p{margin:8px 0;line-height:1.7}"


def billing_notice(failure_code):
    """Only a structured provider 402 triggers this fixed, credential-free copy."""
    if failure_code != "MODEL_HTTP_402":
        return None
    return {"code": "MODEL_HTTP_402", "title": "余额不足 / 额度不可用（HTTP 402）",
            "message": "当前账号的模型服务拒绝了后续调用。请检查供应商余额、可用额度及 API Key 所属账号。",
            "guidance": "充值或更换自己的有效 Key 后，请手动重新发送问题。系统不会因打开此提示自动重试；本轮此前已完成的调用仍可能计费。"}


def describe_status(status, *, audit=None, coverage=None, workflow_notice=None, plan=None, failure_code=None):
    title, tone, description, guidance = STATUS_COPY.get(status, (
        "处理中：尚未形成最终结论", "neutral", "工作流仍在处理或状态尚未确认。", "请等待终态，不要将中间结果当作已核验回答。"))
    audit = audit or {}
    if audit.get("code_issues") or audit.get("rejected_claim_ids") or audit.get("status") in {"needs_review", "needs_revision"}:
        audit_label = "存在引用或声明审查疑点"
    elif audit.get("status") in {"passed", "completed"}:
        audit_label = "保留声明的引用审查已通过"
    else:
        audit_label = "未提供已通过的引用审查结果"
    counts = Counter(row.get("status") or row.get("evidence_status") for row in (coverage or []) if isinstance(row, dict))
    findings = [f"{label}：{counts[key]} 项" for key, label in COVERAGE_COPY.items() if counts[key]]
    display = {"title": title, "tone": tone, "description": description, "guidance": guidance,
               "audit_label": audit_label, "findings": findings}
    notice = billing_notice(failure_code)
    if notice:
        display["billing_notice"] = notice
    labels = {g.get("id"): ", ".join(g.get("core") or []) or str(g.get("question") or g.get("id"))[:120]
              for g in (plan or {}).get("groups", []) if isinstance(g, dict)}
    topics = {}
    for row in (coverage or [])[:30]:
        if not isinstance(row, dict) or not row.get("group_id"):
            continue
        key = row["group_id"]
        topic = topics.setdefault(key, {"group_id": key, "title": labels.get(key, key), "findings": []})
        metric = str(row.get("metric") or "研究问题")[:100]
        state = row.get("status") or row.get("evidence_status")
        label = {"direct": "有直接证据", "indirect": "仅有间接证据", **COVERAGE_COPY}.get(state, "尚未确认")
        text = f"{METRIC_COPY.get(metric.lower(), metric)}：{label}"
        if text not in topic["findings"]:
            topic["findings"].append(text)
    display["topic_summaries"] = list(topics.values())[:3]
    reasons = {"UNAPPROVED_CITATION": "引用未获批准或引用列表为空", "UNSUPPORTED_NUMBER": "数字未被所引原文支持",
               "MISSING_CLAIMS_OR_ANSWER": "缺少可审计声明或回答", "INVALID_REPORT_SECTION": "回答结构不符合约定",
               "WEAK_EVIDENCE_CONFIDENCE": "摘要或未定位片段被赋予过高置信度",
               "MISSING_TOP_LEVEL_CONCLUSION": "缺少通过审查的顶层比较结论"}
    reasons.update({"INVALID_CLAIM_DEPENDENCY": "声明依赖关系无效",
                    "INVALID_CLAIM_SCOPE": "结论适用范围或详细审查记录的格式不符合约定",
                    "CITATION_MISMATCH": "声明与所引原文不匹配",
                    "MISSING_QUALIFICATION": "结论缺少必要的适用范围说明"})
    failure_reasons = {
        "MODEL_SCHEMA_REJECTED": "模型结构化输出连续不符合协议，未进入完整检索流程",
        "MODEL_JSON_INVALID": "模型返回内容不是可解析的结构化结果，未进入完整检索流程",
        "NO_AUDITED_CLAIMS": "已取得资料，但生成的科研声明均未通过完整引用审查",
        "INSUFFICIENT_EVIDENCE": "已检索资料不足以形成可审查结论",
    }
    findings = [reasons.get(r.get("reason"), "声明审查未通过")
                for r in audit.get("code_issues", []) if isinstance(r, dict)]
    for row in audit.get("issues", []):
        if isinstance(row, dict) and row.get("reason_code") != "SUPPORTED":
            key = str(row.get("claim_id") or "未定位声明")[:80]
            findings.append(f"{key}：" + reasons.get(row.get("reason_code"), "原文支持或适用范围需复核"))
    if audit.get("contract_errors"):
        findings.append("引用审查结果不完整或相互矛盾，未确认的声明已阻止发布")
    if failure_code in failure_reasons:
        findings.append(failure_reasons[failure_code])
    display["audit_findings"] = list(dict.fromkeys(findings))[:8]
    if isinstance(workflow_notice, str) and workflow_notice.strip():
        display["workflow_notice"] = workflow_notice[:600]
    return display


def topic_lines(display):
    return [topic["title"] + " — " + "；".join(topic["findings"]) for topic in display.get("topic_summaries", [])]


def published_scope_lines(display):
    topics = display.get("answer_scope", {}).get("topics", [])
    answered = [r["title"] for r in topics if r["status"] == "published_limited_content"]
    missing = [r["title"] for r in topics if r["status"] != "published_limited_content"]
    return (["本次已形成可发布内容：" + "；".join(answered) + "（有内容不等于全部指标覆盖充分）"] if answered else []) + (
        ["本次尚未形成可发布核心回答：" + "；".join(missing)] if missing else [])


def status_markdown(display):
    lines = ["## 结果状态与使用建议", "", f"**{display['title']}**", "", display["description"], "",
             "使用建议：" + display["guidance"], "", "引用审查：" + display["audit_label"]]
    recorded_notice = display.get("billing_notice")
    notice = billing_notice(recorded_notice.get("code") if isinstance(recorded_notice, Mapping) else None)
    if notice:
        lines[2:2] = [f"### ⚠ {notice['title']}", "", notice["message"], "", notice["guidance"], ""]
    if display["findings"]:
        lines += ["", "证据缺口：" + "；".join(display["findings"])]
    if display.get("workflow_notice"):
        lines += ["", display["workflow_notice"]]
    for text in display.get("source_execution_lines", []):
        lines += ["", text]
    for text in published_scope_lines(display):
        lines += ["", text]
    for text in topic_lines(display):
        lines += ["", "主题覆盖：" + text]
    if display.get("audit_findings"):
        lines += ["", "需要核对：" + "；".join(display["audit_findings"])]
    return "\n".join(lines) + "\n\n---\n\n"


def status_html(display):
    paragraphs = [display["description"], "使用建议：" + display["guidance"], "引用审查：" + display["audit_label"]]
    if display["findings"]:
        paragraphs.append("证据缺口：" + "；".join(display["findings"]))
    if display.get("workflow_notice"):
        paragraphs.append(display["workflow_notice"])
    paragraphs += display.get("source_execution_lines", [])
    paragraphs += published_scope_lines(display)
    paragraphs += ["主题覆盖：" + text for text in topic_lines(display)]
    if display.get("audit_findings"):
        paragraphs.append("需要核对：" + "；".join(display["audit_findings"]))
    recorded_notice = display.get("billing_notice")
    notice = billing_notice(recorded_notice.get("code") if isinstance(recorded_notice, Mapping) else None)
    alert = ('<section class="billing-alert" role="alert" aria-label="模型服务余额提醒">'
             f'<h3>⚠ {escape(notice["title"])}</h3><p>{escape(notice["message"])}</p>'
             f'<p>{escape(notice["guidance"])}</p></section>') if notice else ""
    return (f'<section id="result-status" class="result-status {escape(display["tone"], quote=True)}" aria-label="结果状态与使用建议">'
            + alert + f'<h2>{escape(display["title"])}</h2>' + "".join(f"<p>{escape(text)}</p>" for text in paragraphs) + "</section>")
