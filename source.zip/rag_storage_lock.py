"""Non-blocking OS leases for supported CLI/Web writers sharing RAG storage.

Lock files are permanent: unlinking them would split the lock inode. The OS
releases the lease even when the supervised worker is terminated.
"""
import errno
import hashlib
import os
from pathlib import Path


class RagStorageBusy(RuntimeError):
    pass


class StorageLease:
    def __init__(self, *roots):
        self.roots = sorted({Path(root).resolve() for root in roots})
        self.streams = []

    def acquire(self):
        if self.streams:
            raise RuntimeError("STORAGE_LEASE_ALREADY_ACQUIRED")
        try:
            for root in self.roots:
                root.mkdir(parents=True, exist_ok=True)
                lock = root / ".rag-writer.lock"
                if lock.is_symlink():
                    raise ValueError("UNSAFE_STORAGE_LOCK")
                stream = lock.open("a+b")
                self.streams.append(stream)
                try:
                    stream.seek(0)
                    if os.name == "nt":
                        import msvcrt
                        msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
                    else:
                        import fcntl
                        fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                except OSError as exc:
                    if exc.errno in {errno.EACCES, errno.EAGAIN, errno.EDEADLK}:
                        raise RagStorageBusy("RAG_STORAGE_BUSY") from None
                    raise
                stream.seek(0, os.SEEK_END)
                if stream.tell() == 0:
                    stream.write(b"0")
                    stream.flush()
            return self
        except BaseException:
            self.close()
            raise

    def close(self):
        while self.streams:
            try:
                self.streams.pop().close()
            except OSError:
                pass

    def __enter__(self):
        return self.acquire()

    def __exit__(self, *_):
        self.close()


def writer_roots(storage_root, *, vector_enabled=True):
    roots = [Path(storage_root)]
    if vector_enabled:
        url = os.getenv("SCIASSISTANT_QDRANT_URL")
        if url:
            identity = url.rstrip("/") + "|" + os.getenv("SCIASSISTANT_QDRANT_COLLECTION", "sciassistant_evidence")
            namespace = hashlib.sha256(identity.encode()).hexdigest()
            lock_root = Path(os.getenv("SCIASSISTANT_MULTI_AGENT_VECTOR_LOCK_ROOT",
                                      str(Path(__file__).resolve().parent / "logs/rag_vector_locks")))
            roots.append(lock_root / namespace)
        else:
            roots.append(Path(os.getenv("SCIASSISTANT_QDRANT_PATH", "logs/qdrant_evidence")))
    return roots
