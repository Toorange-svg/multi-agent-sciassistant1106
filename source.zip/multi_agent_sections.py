"""Workflow-owned report composition. Bindings are not scientific approval.

Design references: pinned STORM section jobs and PaperQA question-bound evidence.
No upstream source, framework, word limit, model score or shared session copied.
"""
from copy import deepcopy
import hashlib
import json
import math
import re

from multi_agent_report_contracts import REQUIREMENTS_SCHEMA, report_budget, GLOBAL_GUIDANCE_KINDS
from multi_agent_skills import ASSERTION_POLICY, ASSERTION_MODES

SECTION_DRAFT_SCHEMA = 'sciassistant.claim-draft/v4'
SECTION_POLICY = 'requirement-outline-approved-dossiers-bounded-writing/v2'
SECTION_POLICIES = {SECTION_POLICY, 'requirement-outline-approved-dossiers-bounded-writing/v1'}
OUTLINE_SCHEMA = 'sciassistant.report-outline/v1'
DOSSIER_SCHEMA = 'sciassistant.section-evidence/v1'
JOB_SCHEMA = 'sciassistant.writer-job/v1'
GUIDANCE_KINDS = GLOBAL_GUIDANCE_KINDS
PROPOSAL_KINDS = {'proposal', 'evaluation_protocol', 'falsifiable_decision', 'conditional_recommendation'}
BOUNDARY_KINDS = {'scope_check', 'report_consistency'}
REVISION_DELIVERY_POLICY = 'section-patches-and-last-complete-reviewed-checkpoint/v1'
MAX_REVISION_JOBS = 4
WRITER_MATERIAL_POLICY = 'single-approved-source-view-and-bound-section-references/v1'
INITIAL_DELIVERY_BUDGET_POLICY = 'requirement-workload-before-optional-research/v2'
CROSS_SECTION_BINDING_POLICY = 'assigned-job-requirements-with-own-section-overlap/v1'
BODY_DELIVERY_POLICY = 'visible-body-table-pointer-before-coverage/v1'


def initial_delivery_budget(ledger, plan, profile, *, protocol_retry_available=True):
    """Estimate delivery calls before optional research, never cap prose.

    One source-audited claim per content ask is a workload estimate, not a
    Writer target or completeness proof. Actual audit partitioning still uses
    the actual draft. Legacy plans keep their prior reserve.
    """
    from multi_agent_audit_batches import MAX_AUDIT_CLAIMS
    config = report_budget(profile)
    content = [r for r in (ledger or {}).get('requirements', [])
               if r['answer_kind'] not in GUIDANCE_KINDS]
    writers = audits = 0
    if content:
        outline = report_outline(ledger, plan)
        writers = min(config['maximum_initial_writer_batches'],
                      max(1, math.ceil(len(outline['sections']) / 2)))
        audits = 1 if len(content) <= MAX_AUDIT_CLAIMS else math.ceil(len(content) / MAX_AUDIT_CLAIMS) + 1
        # The planner may merge several asks into fewer requirement rows.
        # For multi-question reports keep capacity for two source batches and
        # a whole-report review even when the one-claim-per-ask estimate fits
        # one batch. This reserves calls, never forces extra calls or caps text.
        if len(content) > 1:
            audits = max(audits, 3)
    correction = int(bool(protocol_retry_available)) if content else 0
    return {'schema_version': 'sciassistant.initial-delivery-budget/v1',
        'policy': INITIAL_DELIVERY_BUDGET_POLICY, 'report_profile': profile,
        'baseline_reserved_calls': config['reserved_delivery_calls'],
        'content_requirement_count': len(content), 'estimated_claim_count': len(content),
        'estimated_writer_calls': writers, 'estimated_audit_calls': audits,
        'multi_question_source_batch_capacity_floor': 2 if len(content) > 1 else 1,
        'reserve_does_not_force_extra_calls': True,
        'auditor_protocol_correction_calls': correction,
        'estimated_delivery_calls': max(config['reserved_delivery_calls'], writers + audits + correction),
        'estimate_is_not_output_limit': True, 'automatic_profile_escalation': False,
        'semantic_auto_approval': False}


def report_outline(ledger, plan):
    if ledger.get('schema_version') != REQUIREMENTS_SCHEMA or not ledger.get('requirements'):
        raise ValueError('REPORT_REQUIREMENTS_REQUIRED')
    rows = ledger['requirements']
    groups = {g['id']: g for g in plan.get('groups', [])}
    guidance = [r['requirement_id'] for r in rows if r['answer_kind'] in GUIDANCE_KINDS]
    content = [r for r in rows if r['requirement_id'] not in guidance]
    sections = [{'section_id': 'summary', 'title': '直接回答', 'role': 'direct_conclusion',
        'requirement_ids': [r['requirement_id'] for r in content], 'research_group_ids': list(groups),
        'purpose': 'Give the actual answer first; this summary is not proof of complete delivery.'}]
    buckets = {}
    for row in content:
        kind = row['answer_kind']
        bound = row['research_group_ids']
        if kind in PROPOSAL_KINDS:
            key, title, role = 'proposals', '建议与实验方案', 'synthesis'
        elif kind == 'conclusion_summary':
            key, title, role = 'conclusions', '读后结论与不能推出的结论', 'synthesis'
        elif kind in BOUNDARY_KINDS:
            key, title, role = 'boundaries', '结论范围与证据边界', 'evidence_boundary'
        else:
            owner = next((g for g in bound if g in groups), None)
            key = 'analysis-' + (owner or 'report')
            label = (groups.get(owner, {}).get('question_quote') or groups.get(owner, {}).get('question') or '研究问题')
            label = ' '.join(label.split())
            title = '分项分析：' + (label if len(label) <= 160 else label[:160] + '…')
            role = 'topic_analysis'
        if key not in buckets:
            buckets[key] = {'section_id': key, 'title': title, 'role': role,
                'requirement_ids': [], 'research_group_ids': [], 'purpose': 'Answer the bound asks, not a generic topic paragraph.'}
        target = buckets[key]
        target['requirement_ids'].append(row['requirement_id'])
        target['research_group_ids'] = list(dict.fromkeys([*target['research_group_ids'], *bound]))
    # Keep analyses in first-user-occurrence order. Proposals/boundaries are not
    # dropped even though STORM's upstream generator skips introduction/summary.
    sections.extend(v for k, v in buckets.items() if k not in {'proposals', 'boundaries', 'conclusions'})
    sections.extend(buckets[k] for k in ('proposals', 'boundaries', 'conclusions') if k in buckets)
    return {'schema_version': OUTLINE_SCHEMA, 'policy': SECTION_POLICY,
        'cross_section_binding_policy': CROSS_SECTION_BINDING_POLICY,
        'body_delivery_policy': BODY_DELIVERY_POLICY,
        'question_sha256': ledger['question_sha256'], 'sections': sections, 'planned_group_ids': list(groups),
        'guidance_requirement_ids': guidance, 'requirements': deepcopy(rows),
        'instructions': 'Titles/order are Workflow-owned. All original asks remain in requirements. '
            'Guidance is a constraint, not an answered research claim. Do not repeat all answers in the summary. '
            'Facts require original approved evidence; proposed experiments are not reported experiments. '
            'A planned section is not a completed answer; use explicit unanswered records when needed.',
        'semantic_auto_approval': False, 'publication_coverage_verified': False}


def section_dossiers(outline, approved, review):
    rows = approved.get('evidence', [])
    if any(e.get('review_status') != 'approved' for e in rows):
        raise ValueError('DOSSIER_UNAPPROVED_SOURCE')
    ids = [e['evidence_id'] for e in rows]
    if len(ids) != len(set(ids)):
        raise ValueError('DOSSIER_DUPLICATE_SOURCE')
    by_req = {r['requirement_id']: r for r in outline['requirements']}
    dossiers = []
    for section in outline['sections']:
        groups = set(section['research_group_ids'])
        matches = [e for e in rows if not groups or groups.intersection(
            e.get('reviewed_group_ids') or e.get('group_ids') or [e.get('group_id')])]
        dossiers.append({'section_id': section['section_id'], 'title': section['title'],
            'requirements': [deepcopy(by_req[k]) for k in section['requirement_ids']],
            'approved_evidence_ids': [e['evidence_id'] for e in matches],
            'evidence': deepcopy(matches),
            'coverage_records': [deepcopy(c) for c in review.get('coverage', []) if c.get('group_id') in groups],
            'selection_basis': 'reviewed_group_association_not_claim_support',
            'missing_source': not matches, 'semantic_support_verified': False})
    return {'schema_version': DOSSIER_SCHEMA, 'policy': SECTION_POLICY, 'dossiers': dossiers,
        'original_evidence_preserved': True, 'excerpts_summarized_or_truncated': False,
        'semantic_auto_approval': False}


def writer_jobs(outline, dossiers, profile, remaining_calls):
    """Calls are partitions, never word/claim/requirement count targets.

    Leave one audit and an optional revision/re-audit pair. When those optional
    calls are already unavailable, retain at least one final audit call.
    """
    config = report_budget(profile)
    if type(remaining_calls) is not int or remaining_calls < 2:
        raise ValueError('REPORT_DELIVERY_CALLS_UNAVAILABLE')
    maximum = config['maximum_initial_writer_batches']
    count = min(maximum, max(1, remaining_calls - 3), max(1, math.ceil(len(outline['sections']) / 2)))
    sections = outline['sections']
    # Advisory kinds must not make historical/standalone partition jobs depend
    # on a complete typed ledger. Keep every assigned ID; an unknown kind is
    # not a delivery verdict or permission to bypass upstream binding checks.
    kinds_by_requirement = {r['requirement_id']: r.get('answer_kind', 'unclassified')
                            for r in outline.get('requirements', [])}
    jobs = []
    by_section = {d['section_id']: d for d in dossiers['dossiers']}
    # Balance assigned asks, including the all-asks summary, rather than just
    # counting chapter headings. Keep order, batch count and every section.
    weights = [max(1, len(s['requirement_ids'])) for s in sections]
    costs = {(0, 0): (0, [])}
    for batches in range(1, count + 1):
        for end in range(batches, len(sections) + 1):
            choices = [(max(costs[batches-1, start][0], sum(weights[start:end])),
                        costs[batches-1, start][1] + [(start, end)])
                       for start in range(batches-1, end) if (batches-1, start) in costs]
            costs[batches, end] = min(choices, key=lambda c: (c[0], c[1]))
    # If one indivisible summary fixes the maximum, also balance the other
    # batches instead of leaving all remaining chapters in the final call.
    ceiling = costs[count, len(sections)][0]
    costs = {(0, 0): (0, [])}
    for batches in range(1, count + 1):
        for end in range(batches, len(sections) + 1):
            choices = [(costs[batches-1, start][0] + sum(weights[start:end]) ** 2,
                        costs[batches-1, start][1] + [(start, end)])
                       for start in range(batches-1, end) if (batches-1, start) in costs
                       and sum(weights[start:end]) <= ceiling]
            if choices:
                costs[batches, end] = min(choices, key=lambda c: (c[0], c[1]))
    for index, (start, end) in enumerate(costs[count, len(sections)][1]):
        chosen = sections[start:end]
        selected_ids = [s['section_id'] for s in chosen]
        ids = list(dict.fromkeys(r for s in chosen for r in s['requirement_ids']))
        evidence_ids = list(dict.fromkeys(e for k in selected_ids for e in by_section[k]['approved_evidence_ids']))
        jobs.append({'schema_version': JOB_SCHEMA, 'policy': SECTION_POLICY, 'job_id': f'b{index+1}',
            **({'cross_section_binding_policy': CROSS_SECTION_BINDING_POLICY}
               if outline.get('cross_section_binding_policy') == CROSS_SECTION_BINDING_POLICY else {}),
            'initial_batch': True, 'section_ids': selected_ids, 'sections': deepcopy(chosen),
            'requirement_ids': ids, 'guidance_requirement_ids': list(outline['guidance_requirement_ids']),
            'planned_group_ids': list(outline['planned_group_ids']),
            'allowed_evidence_ids': evidence_ids,
            'delivery_checklist': [{'section_id': s['section_id'],
                'requirement_ids': list(s['requirement_ids']),
                'answer_kinds': list(dict.fromkeys(kinds_by_requirement.get(r, 'unclassified') for r in s['requirement_ids'])),
                'requested_table_rows_in_main_text': s['section_id'] != 'summary' and any(
                    kinds_by_requirement.get(r) == 'table_reading' for r in s['requirement_ids']),
                'expected_content': ('Separate supported conclusions from non-conclusions in this closing section; '
                    'reconcile with the opening, without inventing facts or treating a heading as an answer.'
                    if s['section_id'] == 'conclusions' else
                    'Give the unexecuted experiment, controls, repeated-run protocol and decision rule, '
                    'not merely a statement that the paper lacks this future experiment.'
                    if s['section_id'] == 'proposals' else
                    'Answer the assigned literal asks using approved sources, with specific limitations where needed.')}
                for s in chosen],
            'partition_policy': 'ordered-minimax-assigned-requirements/v1',
            'instructions': 'Write ONLY assigned sections using this job approved excerpts. Return claim-draft/v4. '
                'Each claim has report_section_id and requirement_ids. Workflow derives the section enum from the outline. '
                'Under cross_section_binding_policy a claim must answer at least one requirement of its own section; '
                'additional bindings may only name requirements assigned to THIS job, never another batch or a new ask. '
                'Bindings are candidates for independent coverage review, not proof of support or completion. '
                'requirement_results is OPTIONAL diagnostic metadata, never scientific approval. '
                'If supplied use answered/limited/unanswered, claim_ids, reason. Do not use internal claim IDs in prose. '
                'Keep required tables, definitions and decisive conditions in main text, not only qualification. '
                'Use delivery_checklist to check later assigned sections BEFORE expanding the opening. '
                'Keep the opening a direct conclusion, not a second copy of all detailed sections. '
                'No target word or claim count. Do not invent claims to fill a section. '
                'An unanswered row needs a specific reason and no claim IDs.'})
    return jobs


def writer_job_evidence(job, dossiers):
    wanted = set(job['allowed_evidence_ids'])
    selected, seen = [], set()
    for d in dossiers['dossiers']:
        if d['section_id'] not in job['section_ids']:
            continue
        for row in d['evidence']:
            key = row['evidence_id']
            if key in wanted and key not in seen:
                selected.append(deepcopy(row))
                seen.add(key)
    if seen != wanted:
        raise ValueError('WRITER_JOB_SOURCE_MISSING')
    return {'schema_version': 'sciassistant.evidence-set/v1', 'evidence': selected}


def writer_job_material(job, dossiers, source, source_artifact_id):
    """Reference a single exact source view; never summarize or approve text."""
    rows = source['evidence']
    by_id = {r['evidence_id']: r for r in rows}
    if (len(rows) != len(by_id) or set(by_id) != set(job['allowed_evidence_ids'])
            or any(r.get('review_status') != 'approved' for r in rows)):
        raise ValueError('WRITER_MATERIAL_SOURCE_INVALID')
    selected = []
    for dossier in dossiers['dossiers']:
        if dossier['section_id'] not in job['section_ids']:
            continue
        if (set(dossier['approved_evidence_ids']) != {r['evidence_id'] for r in dossier['evidence']}
                or any(r != by_id.get(r['evidence_id']) for r in dossier['evidence'])):
            raise ValueError('WRITER_MATERIAL_SOURCE_MISMATCH')
        row = deepcopy(dossier)
        del row['evidence']
        row['requirement_ids'] = [r['requirement_id'] for r in row.pop('requirements')]
        selected.append(row)
    if [r['section_id'] for r in selected] != job['section_ids']:
        raise ValueError('WRITER_MATERIAL_SECTION_MISMATCH')
    return {'schema_version': 'sciassistant.section-writing-material/v2',
        'policy': WRITER_MATERIAL_POLICY, 'sections': selected,
        'source_artifact_id': source_artifact_id,
        'source_sha256': outline_digest(source), 'approved_sources_only': True,
        'instructions': 'Resolve approved_evidence_ids in the supplied approved-section-evidence artifact. '
            'Resolve requirement_ids in the supplied user requirements. Source text and locators are unchanged. '
            'Section association is not proof that a source supports a claim.',
        'excerpts_summarized_or_truncated': False, 'semantic_auto_approval': False}


def writer_job_issues(draft, job):
    """Only structural/citation binding checks; never infer answer correctness."""
    issues = []
    if draft.get('schema_version') != SECTION_DRAFT_SCHEMA:
        return [{'claim_id': 'draft', 'reason': 'WRITER_SECTION_SCHEMA_REQUIRED'}]
    claims = draft.get('claims')
    if not isinstance(claims, list) or len(claims) > 80:
        return [{'claim_id': 'draft', 'reason': 'WRITER_SECTION_CLAIMS_INVALID'}]
    section_map = {s['section_id']: s for s in job['sections']}
    by_claim = {}
    for c in claims:
        if not isinstance(c, dict) or not isinstance(c.get('claim_id'), str) or not c['claim_id'] or c['claim_id'] in by_claim:
            issues.append({'claim_id': 'draft', 'reason': 'WRITER_SECTION_IDS_INVALID'})
            continue
        key = c['claim_id']
        by_claim[key] = c
        if job.get('assertion_policy') == ASSERTION_POLICY and (
                not isinstance(c.get('assertion_mode'), str) or c['assertion_mode'] not in ASSERTION_MODES):
            issues.append({'claim_id': key, 'reason': 'ASSERTION_MODE_INVALID'})
        if (not isinstance(c.get('text'), str) or not 1 <= len(c['text'].strip()) <= 4000
                or not isinstance(c.get('scope_note'), str) or len(c['scope_note']) > 600
                or not isinstance(c.get('qualification', ''), str) or len(c.get('qualification', '')) > 4000
                or not isinstance(c.get('claim_type'), str)
                or c['claim_type'] not in {'technical', 'quantitative', 'comparative', 'limitation'}):
            issues.append({'claim_id': key, 'reason': 'WRITER_SECTION_TEXT_INVALID'})
        target = section_map.get(c.get('report_section_id')) if isinstance(c.get('report_section_id'), str) else None
        bindings = c.get('requirement_ids')
        own_requirements = set(target['requirement_ids']) if target else set()
        allowed_requirements = (set(job['requirement_ids'])
            if job.get('cross_section_binding_policy') == CROSS_SECTION_BINDING_POLICY else own_requirements)
        if (not target or not isinstance(bindings, list) or not bindings
                or any(not isinstance(r, str) for r in bindings)
                or len(set(bindings)) != len(bindings)
                or not set(bindings).issubset(allowed_requirements)
                or not own_requirements.intersection(bindings)
                or c.get('section') != target['role']):
            issues.append({'claim_id': key, 'reason': 'WRITER_SECTION_BINDING_INVALID'})
        cited = c.get('evidence_ids')
        if (not isinstance(cited, list) or not cited or any(not isinstance(e, str) for e in cited)
                or not set(cited).issubset(job['allowed_evidence_ids'])):
            issues.append({'claim_id': key, 'reason': 'WRITER_JOB_CITATION_INVALID'})
        if c.get('group_id') not in job['planned_group_ids']:
            issues.append({'claim_id': key, 'reason': 'WRITER_SECTION_GROUP_INVALID'})
        deps = c.get('depends_on_claim_ids', [])
        if not isinstance(deps, list) or any(not isinstance(d, str) for d in deps):
            issues.append({'claim_id': key, 'reason': 'WRITER_SECTION_DEPENDENCY_INVALID'})
    external = set(job.get('external_claim_ids', [])) if (
        job.get('revision_delivery_policy') == REVISION_DELIVERY_POLICY and not job.get('initial_batch', True)) else set()
    for key, c in by_claim.items():
        if isinstance(c.get('depends_on_claim_ids', []), list) and any(d not in by_claim and d not in external for d in c.get('depends_on_claim_ids', [])):
            issues.append({'claim_id': key, 'reason': 'WRITER_SECTION_DEPENDENCY_INVALID'})
    return issues


def writer_result_issues(draft, job):
    """Administrative self-reports cannot veto scientifically auditable text."""
    issues, seen = [], set()
    by_claim = {c['claim_id']: c for c in draft.get('claims', []) if isinstance(c, dict) and isinstance(c.get('claim_id'), str)}
    results = draft.get('requirement_results')
    if results is None:
        return []  # Optional. Missing self-report cannot invalidate source-backed claims.
    if not isinstance(results, list):
        return [{'claim_id': 'draft', 'reason': 'WRITER_REQUIREMENT_RESULTS_INVALID'}]
    for row in results:
        if (not isinstance(row, dict) or set(row) != {'requirement_id', 'status', 'claim_ids', 'reason'}
                or not isinstance(row.get('requirement_id'), str)
                or row['requirement_id'] not in job['requirement_ids'] or row['requirement_id'] in seen):
            issues.append({'claim_id': 'draft', 'reason': 'WRITER_REQUIREMENT_RESULT_INVALID'})
            continue
        seen.add(row['requirement_id'])
        refs = row['claim_ids']
        if (not isinstance(row['status'], str) or row['status'] not in {'answered', 'limited', 'unanswered'}
                or not isinstance(row['reason'], str) or len(row['reason']) > 1000
                or not isinstance(refs, list) or any(not isinstance(c, str) for c in refs)
                or len(set(refs)) != len(refs)
                or any(c not in by_claim or row['requirement_id'] not in by_claim[c].get('requirement_ids', []) for c in refs)
                or row['status'] == 'unanswered' and (refs or not row['reason'].strip())
                or row['status'] in {'answered', 'limited'} and not refs):
            issues.append({'claim_id': 'draft', 'reason': 'WRITER_REQUIREMENT_RESULT_INVALID'})
    if seen != set(job['requirement_ids']):
        issues.append({'claim_id': 'draft', 'reason': 'WRITER_REQUIREMENT_RESULTS_INCOMPLETE'})
    return issues


def project_writer_job(draft, job, *, isolate=True):
    """Derive role labels only. Never fix facts, citations or requirement IDs."""
    result = deepcopy(draft)
    if result.get('schema_version') != SECTION_DRAFT_SCHEMA:
        return result
    # These are Workflow fields, never authority granted by model output.
    result.pop('isolated_claims', None)
    result.pop('binding_isolation', None)
    sections = {s['section_id']: s for s in job['sections']}
    changes = []
    for c in result.get('claims', []) if isinstance(result.get('claims'), list) else []:
        if not isinstance(c, dict) or not isinstance(c.get('report_section_id'), str):
            continue
        target = sections.get(c['report_section_id'])
        if job.get('assertion_policy') == ASSERTION_POLICY and 'assertion_mode' not in c:
            c['assertion_mode'] = 'unclassified'  # Missing declaration is not approval or a body veto.
        if target and c.get('section') != target['role']:
            changes.append({'claim_id': c.get('claim_id'), 'field': 'section', 'derived_from': target['section_id']})
            c['section'] = target['role']
    binding_errors = writer_job_issues(result, job)
    # Isolate only locally identifiable malformed bindings. Duplicate/unknown
    # IDs are global ambiguity and still require the counted format correction.
    if isolate and binding_errors and not any(e['claim_id'] == 'draft' for e in binding_errors):
        blocked = {e['claim_id'] for e in binding_errors}
        while True:
            dependent = {c['claim_id'] for c in result['claims'] if
                isinstance(c.get('depends_on_claim_ids', []), list)
                and any(d in blocked for d in c.get('depends_on_claim_ids', []) if isinstance(d, str))}
            if dependent <= blocked:
                break
            blocked |= dependent
        result['isolated_claims'] = [deepcopy(c) for c in result['claims'] if c['claim_id'] in blocked]
        result['claims'] = [c for c in result['claims'] if c['claim_id'] not in blocked]
        result['binding_isolation'] = {'policy': SECTION_POLICY, 'issues': binding_errors,
            'blocked_claim_ids': sorted(blocked), 'automatic_semantic_approval': False}
    diagnostics = writer_result_issues(result, job)
    result['requirement_result_diagnostics'] = diagnostics
    if diagnostics:
        # Keep the model's structured observations, but never reinterpret a
        # malformed/overclaiming completion row as evidence or a completed ask.
        result.setdefault('reported_requirement_results', deepcopy(result.get('requirement_results')))
        result['requirement_results'] = []
    result['section_projection'] = {'policy': SECTION_POLICY, 'changes': changes,
        'scientific_text_or_ids_changed': False, 'semantic_auto_approval': False}
    return result


def merge_writer_batches(outline, batches):
    claims, results, provenance = [], [], []
    for job, draft, artifact_id in batches:
        if writer_job_issues(draft, job):
            raise ValueError('INVALID_BATCH_CANNOT_MERGE')
        mapping = {c['claim_id']: job['job_id'] + '-' + c['claim_id'] for c in draft['claims']}
        for source in draft['claims']:
            c = deepcopy(source)
            c['claim_id'] = mapping[c['claim_id']]
            c['depends_on_claim_ids'] = [mapping[k] for k in c.get('depends_on_claim_ids', [])]
            claims.append(c)
            provenance.append({'claim_id': c['claim_id'], 'source_claim_id': source['claim_id'],
                'batch_artifact_id': artifact_id, 'job_id': job['job_id']})
        for row in draft.get('requirement_results', []):
            results.append({**deepcopy(row), 'claim_ids': [mapping[k] for k in row['claim_ids']], 'job_id': job['job_id']})
    if len({c['claim_id'] for c in claims}) != len(claims):
        raise ValueError('REPORT_BATCH_NAMESPACE_COLLISION')
    canonical = []
    for rid in dict.fromkeys(r for s in outline['sections'] for r in s['requirement_ids']):
        rows = [r for r in results if r['requirement_id'] == rid]
        refs = list(dict.fromkeys(k for r in rows for k in r['claim_ids']))
        observed = [c['claim_id'] for c in claims if rid in c['requirement_ids']]
        status = ('limited' if any(r['status'] != 'answered' for r in rows) else 'answered') if refs else ('unassessed' if observed else 'unanswered')
        canonical.append({'requirement_id': rid, 'status': status, 'claim_ids': refs,
            'reason': '按各批次自报汇总，尚未核算审计后的交付；原始理由保存在draft_requirement_observations。' if refs
                else '有草稿绑定，尚无有效完成自报或发布覆盖判定。' if observed
                else '本轮没有有效分节草稿绑定此项；不据此判断文献是否存在。'})
    return {'schema_version': SECTION_DRAFT_SCHEMA, 'direct_answer': '分节草稿；最终正文仅由通过审计的声明生成。',
        'claims': claims, 'report_outline': deepcopy(outline), 'requirement_results': canonical,
        'draft_requirement_observations': results,
        'observed_requirement_bindings': [{'requirement_id': rid,
            'claim_ids': [c['claim_id'] for c in claims if rid in c['requirement_ids']],
            'is_answered_verdict': False} for rid in dict.fromkeys(r for s in outline['sections'] for r in s['requirement_ids'])],
        'composition_policy': SECTION_POLICY, 'batch_provenance': provenance,
        'draft_self_reports_not_publication_coverage': True}


def revision_job(outline, approved):
    return {'schema_version': JOB_SCHEMA, 'policy': SECTION_POLICY, 'job_id': 'revision',
        **({'cross_section_binding_policy': CROSS_SECTION_BINDING_POLICY}
           if outline.get('cross_section_binding_policy') == CROSS_SECTION_BINDING_POLICY else {}),
        'initial_batch': False, 'section_ids': [s['section_id'] for s in outline['sections']],
        'sections': deepcopy(outline['sections']),
        'requirement_ids': list(dict.fromkeys(r for s in outline['sections'] for r in s['requirement_ids'])),
        'guidance_requirement_ids': list(outline['guidance_requirement_ids']),
        'planned_group_ids': list(outline['planned_group_ids']),
        'allowed_evidence_ids': [e['evidence_id'] for e in approved['evidence']],
        'instructions': 'Revise the merged draft under exact audit feedback. Keep stable global claim IDs, '
            'report_section_id and requirement_ids. Preserve independently correct sections and required tables. '
            'Do not restore an unsupported claim to fill a requirement. Unanswered requirements need explicit reasons. '
            'The full revised draft still needs a new audit.'}


def revision_jobs(draft, approved, feedback, recovery):
    """One section per patch; omissions retain old text, never erase a report.

    Target IDs are Workflow-owned. Existing IDs keep their bindings; new text
    has a per-job namespace. The full merged report still requires audit.
    """
    outline = draft['report_outline']
    claims = {c['claim_id']: c for c in draft['claims']}
    targets = {r.get('claim_id') for r in feedback.get('code_issues', []) if r.get('claim_id') in claims}
    targets.update(k for k in feedback.get('model_audit', {}).get('rejected_claim_ids', []) if k in claims)
    gap_ids = {r['requirement_id'] for r in (recovery or {}).get('requirements', [])}
    issue_sections = {claims[k]['report_section_id'] for k in targets}
    gap_sections = {s['section_id'] for s in outline['sections'] if s['section_id'] != 'summary'
                    and gap_ids.intersection(s['requirement_ids'])}
    selected = sorted((s for s in outline['sections'] if s['section_id'] in issue_sections | gap_sections),
        key=lambda s: (s['section_id'] not in issue_sections, outline['sections'].index(s)))
    jobs = []
    for index, section in enumerate(selected):
        target_ids = [k for k in claims if k in targets and claims[k]['report_section_id'] == section['section_id']]
        requirements = set(section['requirement_ids']) & gap_ids
        requirements.update(r for k in target_ids for r in claims[k]['requirement_ids'])
        job = revision_job(outline, approved)
        # Cross-section bindings are part of the original target, not new
        # permission to change its IDs or edit the secondary section.
        requirement_order = (list(dict.fromkeys(r for s in outline['sections'] for r in s['requirement_ids']))
            if job.get('cross_section_binding_policy') == CROSS_SECTION_BINDING_POLICY else section['requirement_ids'])
        job.update(job_id=f'rev-{index+1:03d}', section_ids=[section['section_id']], sections=[deepcopy(section)],
            requirement_ids=[r for r in requirement_order if r in requirements],
            revision_delivery_policy=REVISION_DELIVERY_POLICY, assertion_policy=ASSERTION_POLICY,
            target_claim_ids=target_ids, external_claim_ids=[k for k in claims if k not in target_ids],
            new_claim_prefix=f'rev-{index+1:03d}-new-')
        job['instructions'] = (
            'Return ONLY patches for target_claim_ids and new claims answering this job requirement_ids, '
            'not the whole report or an unchanged section. Existing IDs must keep original section/group/requirement '
            'bindings. New IDs must start with new_claim_prefix. Dependencies may refer to external_claim_ids, '
            'but those are context, not source approval. Omitting an old target does NOT delete it; it stays '
            'subject to the original rejection and new audit. Do not rewrite independent correct claims. '
            'All changed/new claims need full source and whole-report re-audit. No word/claim count target.')
        jobs.append(job)
    return jobs


def merge_revision_jobs(prior, batches):
    """Apply exact scoped patches. No omission-based deletion or auto approval."""
    result = deepcopy(prior)
    original = {c['claim_id']: c for c in prior['claims']}
    merged = {k: deepcopy(c) for k, c in original.items()}
    provenance, seen = [], set()
    for job, patch, artifact_id in batches:
        if (job.get('revision_delivery_policy') != REVISION_DELIVERY_POLICY
                or writer_job_issues(patch, job)):
            raise ValueError('REVISION_JOB_INVALID')
        for c in patch['claims']:
            key = c['claim_id']
            if not set(c['requirement_ids']).issubset(job['requirement_ids']):
                raise ValueError('REVISION_REQUIREMENT_OUTSIDE_JOB')
            if key in seen:
                raise ValueError('REVISION_PATCH_ID_COLLISION')
            if key in original:
                if (key not in job['target_claim_ids'] or any(c.get(f) != original[key].get(f)
                        for f in ('report_section_id', 'requirement_ids', 'group_id'))):
                    raise ValueError('REVISION_UNTARGETED_CLAIM_CHANGED')
            elif not re.fullmatch(re.escape(job['new_claim_prefix']) + r'[A-Za-z0-9_-]{1,40}', key):
                raise ValueError('REVISION_NEW_ID_INVALID')
            merged[key] = deepcopy(c)
            seen.add(key)
            provenance.append({'claim_id': key, 'job_id': job['job_id'], 'artifact_id': artifact_id})
    result['claims'] = list(merged.values())
    if len(result['claims']) > 80:
        raise ValueError('REVISION_AGGREGATE_CAPACITY_EXCEEDED')
    result['revision_batch_provenance'] = provenance
    result['revision_delivery_policy'] = REVISION_DELIVERY_POLICY
    result['draft_self_reports_not_publication_coverage'] = True
    return result


def outline_digest(outline):
    return hashlib.sha256(json.dumps(outline, sort_keys=True, ensure_ascii=False).encode('utf-8')).hexdigest()
