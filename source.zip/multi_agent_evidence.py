"""Code-owned source scope; model approval is not a full-text upgrade."""

import re

DOCUMENT_DESCRIPTION_POLICY = "passage-attribution-not-document-genre/v1"
ANSWER_STYLE_POLICY = "necessary-conditions-without-repeated-disclaimers/v1"


def report_source_identity(draft, item):
    """New exports carry identity; legacy replay must not acquire new fields."""
    return ({'source_identity': source_identity_record(item)}
            if draft.get('answer_style_policy') == ANSWER_STYLE_POLICY else {})


def source_identity_record(item):
    """Preserve retrieved bibliography, not author guesses from cited surnames."""
    raw = item.get('authors')
    authors = []
    if isinstance(raw, list):
        for name in raw[:100]:
            if not isinstance(name, str):
                continue
            name = ' '.join(name.split())
            if name and len(name) <= 160 and name not in authors:
                authors.append(name)
    origin = item.get('author_metadata_source') if authors else 'unavailable'
    if origin not in {'arxiv_api', 'verified_local_public_cache'}:
        origin = 'unverified_metadata' if authors else 'unavailable'
    return {'policy': 'retrieved-bibliography-not-mentioned-researcher/v1',
            'paper_id': item.get('paper_id'), 'title': item.get('title'),
            'authors': authors, 'author_metadata_source': origin,
            'semantic_support_verified': False,
            'instruction': 'Bibliographic authors identify this document, not every method it discusses. '
                'A surname in related work is not this paper\'s experimenter. If identity is unavailable, '
                'use the paper title or this study, not a guessed author. Explicit secondary attribution '
                'still needs support in the actual cited passage.'}


def document_description_record(item):
    """Literal approved-passage cues, not a document-genre classifier.

    A method paper can discuss other methods; a survey can also propose a
    framework. Neither cue alone certifies genre or original-method authority.
    """
    text = str(item.get("excerpt") or item.get("text") or "")
    cues = []
    for match in re.finditer(
            r"\b(?:we|this (?:paper|work))\s+(?:propose|introduce|present|develop)(?:s)?\b"
            r"[^.!?\n]{0,200}|本文(?:提出|介绍|设计)[^。！？\n]{0,100}", text, re.I):
        cues.append({"start": match.start(), "end": match.end(), "quote": match.group()})
        if len(cues) == 3:
            break
    attribution = item.get("source_attribution") if isinstance(item.get("source_attribution"), dict) else {}
    return {"policy": DOCUMENT_DESCRIPTION_POLICY, "evidence_id": item.get("evidence_id"),
        "paper_id": item.get("paper_id"), "title": item.get("title"),
        "page": (item.get("locator") or {}).get("page"),
        "survey_title_hint": bool(re.search(r"\b(?:survey|review)\b|综述", str(item.get("title") or ""), re.I)),
        "survey_abstract_hint": attribution.get("survey_abstract_hint") is True,
        "self_contribution_cues": cues, "document_genre_verified": False,
        "primary_method_verified": False,
        "instructions": "Secondary account of another method does not mean survey/review paper. "
            "Use neutral citing/subsequent paper unless genre has explicit source support. "
            "Self-contribution cues are reading pointers, not proof the paper cannot be a survey. "
            "Do not call a later method paper a review solely because its excerpt summarizes DETR or another method."}


def source_attribution_hint(item, *, document_abstract=""):
    """Mark secondary passages without certifying original method details.

    Offsets refer to the unchanged excerpt. A located quotation only proves
    what this document says. Missing headings never imply primary authority.
    """
    text = str(item.get("excerpt") or item.get("text") or "")
    section = str((item.get("locator") or {}).get("section") or "").strip()
    secondary = r"(?:related works?|literature review|prior work|background|相关工作|文献综述)"
    headings = re.compile(r"(?im)^[ \t]*(?:(?:\d+(?:\.\d+)*|[IVX]+)\.?[ \t]+)?"
                          r"(" + secondary + r"|methods?|methodology|experiments?|results?|"
                          r"conclusions?|discussion|方法|实验|结果|结论)[ \t]*$")
    ranges = []
    start = 0 if re.fullmatch(secondary, section, re.I) else None
    for boundary in headings.finditer(text):
        if start is not None and boundary.start() > start:
            ranges.append({"start": start, "end": boundary.start(), "kind": "secondary_discussion"})
        start = boundary.start() if re.fullmatch(secondary, boundary.group(1), re.I) else None
    if start is not None and start < len(text):
        ranges.append({"start": start, "end": len(text), "kind": "secondary_discussion"})
    survey = bool(re.search(r"\b(?:survey|review)\b|综述", str(item.get("title") or ""), re.I))
    # Some reviews have no 'survey' in their title. Only explicit self-description
    # from retrieved metadata is a hint; a passing mention of prior reviews is not.
    survey_abstract = bool(re.search(
        r"\bin this (?:review|survey)\b|\b(?:we|this (?:paper|article|work))\s+"
        r"(?:present(?:s)?|provide(?:s)?|offer(?:s)?)\s+(?:a|an)\s+"
        r"(?:(?:systematic|comprehensive|critical)\s+){0,2}(?:review|survey)\b|"
        r"\bwe\s+(?:systematically\s+)?(?:review|survey)\s+(?:existing|recent|the literature)\b|"
        r"本文(?:系统)?综述", str(document_abstract or "")[:4000], re.I))
    secondary_chars = sum(row["end"] - row["start"] for row in ranges)
    kind = ("secondary_summary" if survey or survey_abstract or secondary_chars == len(text) and text else
            "mixed_primary_unverified_and_secondary" if ranges else "unclassified")
    labels = {"secondary_summary": "综述或相关工作转述 · 非原方法核验",
              "mixed_primary_unverified_and_secondary": "含相关工作转述 · 需逐声明区分来源",
              "unclassified": "来源贡献未分类 · 不等于原方法已核验"}
    return {"schema_version": "sciassistant.source-attribution/v1", "classification": kind,
            "secondary_ranges": ranges, "survey_title_hint": survey,
            "survey_abstract_hint": survey_abstract, "label": labels[kind],
            "primary_method_verified": False,
            "policy": "quotation_match_is_not_primary_method_verification"}


def excerpt_content_scope(item):
    """Conservative new-ingest hint; do not reinterpret historical exports."""
    locator = item.get("locator") or {}
    section = str(locator.get("section") or "").strip().lower()
    if section in {"abstract", "摘要"}:
        return "abstract_only"
    text = str(item.get("excerpt") or item.get("text") or "")
    header = re.search(r"(?im)^\s*(?:abstract|摘要)\s*(?:[:：]\s*|\n|$)", text)
    if not header:
        return "body_or_unclassified"
    # Multi-column extraction can place the Introduction heading before the
    # abstract. Numbered affiliations are NOT body-section headings.
    before = text[:header.start()]
    body_before = re.search(r"(?im)^\s*(?:\d+(?:\.\d+)*\.?\s+)?"
                            r"(?:introduction|background|methods?|results?|discussion|conclusions?)\s*$", before)
    remainder = text[header.end():]
    body = re.search(r"(?im)^\s*(?:\d+(?:\.\d+)*\.?\s+[A-Z][^\n]{1,100}|"
                     r"introduction\s*$|background\s*$|(?:table|figure)\s+\d+\b)", remainder)
    return "mixed_abstract_body" if body or body_before else "abstract_only"

LABELS = {
    "fulltext_located": "全文片段 · 已定位原文页",
    "abstract_only": "摘要级弱证据 · 未核验全文",
    "fulltext_unlocated": "全文片段 · 原文位置待核验",
    "legacy_unclassified": "历史证据 · 来源层级未记录",
}


def evidence_strength(item):
    # Derive from tool metadata, never trust a model-supplied strength label.
    scope = item.get("coverage_scope")
    section = str((item.get("locator") or {}).get("section") or "").strip().lower()
    if scope == "abstract" or scope == "selected_chunks" and (
            section in {"abstract", "摘要"} or item.get("content_scope") == "abstract_only"):
        return "abstract_only"
    if scope == "selected_chunks":
        page = (item.get("locator") or {}).get("page")
        return "fulltext_located" if isinstance(page, int) and not isinstance(page, bool) and page > 0 else "fulltext_unlocated"
    return "legacy_unclassified"


def weak_evidence(item):
    return evidence_strength(item) in {"abstract_only", "fulltext_unlocated"}


def evidence_label(item):
    return LABELS[evidence_strength(item)]
