@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
if not exist "venv\Scripts\python.exe" (
  echo Project virtual environment not found: venv\Scripts\python.exe
  pause
  exit /b 1
)
"venv\Scripts\python.exe" "tools\diagnose_arxiv_429.py" %*
set EXIT_CODE=%ERRORLEVEL%
echo.
pause
endlocal & exit /b %EXIT_CODE%
