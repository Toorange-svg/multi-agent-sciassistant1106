"""Durable, bounded orchestration primitives for multi-agent literature work.

This module deliberately contains no provider SDK, prompt, or database handle
exposed to an agent role.  The coordinator owns transitions, budgets and the
SQLite store; role adapters will receive validated dictionaries and return new
validated dictionaries in a later integration step.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import sqlite3
import time
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterator, Mapping
from multi_agent_report_contracts import report_budget, is_soft_time_policy, PROFILE_SOFT_POLICY


DEFAULT_MAX_MODEL_CALLS = 10
DEFAULT_TIME_BUDGET_SECONDS = 360
MAX_RESEARCH_GROUPS = 3
SCHEMA_VERSION = 1

TERMINAL_STATUSES = frozenset({"completed", "partial", "needs_review", "failed", "timed_out", "cancelled"})
RUN_STATUSES = frozenset({
    "created", "planned", "retrieving", "reviewing", "writing", "auditing",
    *TERMINAL_STATUSES,
})
_TRANSITIONS = {
    "created": frozenset({"planned", "failed", "timed_out", "cancelled"}),
    "planned": frozenset({"retrieving", "failed", "timed_out", "cancelled"}),
    "retrieving": frozenset({"reviewing", "partial", "needs_review", "failed", "timed_out", "cancelled"}),
    # The coordinator may run a bounded, structured evidence-recovery round
    # after review.  Roles cannot select this edge or schedule themselves.
    "reviewing": frozenset({"retrieving", "writing", "partial", "needs_review", "failed", "timed_out", "cancelled"}),
    "writing": frozenset({"auditing", "partial", "needs_review", "failed", "timed_out", "cancelled"}),
    # One bounded writer revision is permitted after an audit.  The
    # coordinator, not the auditor, decides whether to take this edge.
    "auditing": frozenset({"writing", "completed", "partial", "needs_review", "failed", "timed_out", "cancelled"}),
}
_SENSITIVE_KEY = re.compile(r"(?:authorization|api[_ -]?key|token|secret|password|cookie)", re.I)
_FORBIDDEN_AGENT_FIELDS = frozenset({"prompt", "raw_response", "chain_of_thought", "reasoning_trace"})
_SAFE_ID = re.compile(r"[A-Za-z0-9_-]{1,128}\Z")


class WorkflowError(ValueError):
    """A stable, caller-safe workflow contract violation."""


class WorkflowBudgetExceeded(WorkflowError):
    """The coordinator must not issue another model call."""


class WorkflowStoreError(RuntimeError):
    """Persistence could not satisfy a workflow operation."""


@dataclass(frozen=True)
class ModelCallPermit:
    run_id: str
    role: str
    call_number: int
    remaining_calls: int
    deadline_at: float


def configured_workflow_path(value: str | None = None) -> Path:
    """Return a local durable workflow-state path without creating it."""
    raw = value if value is not None else os.getenv(
        "SCIASSISTANT_MULTI_AGENT_STATE_PATH", "logs/multi_agent_workflow.sqlite3"
    )
    return Path(str(raw)).expanduser()


def _now() -> float:
    return time.time()


def _require_identifier(value: str, label: str) -> str:
    normalized = str(value or "")
    if not _SAFE_ID.fullmatch(normalized):
        raise WorkflowError(f"invalid {label}")
    return normalized


def _json_copy(value: Any) -> dict:
    if not isinstance(value, Mapping):
        raise WorkflowError("artifact must be an object")
    try:
        copied = json.loads(json.dumps(dict(value), ensure_ascii=False, allow_nan=False))
    except (TypeError, ValueError) as exc:
        raise WorkflowError("artifact must be JSON serializable") from exc
    return copied


def _bounded_text(value: Any, field: str, maximum: int = 12_000, *, allow_empty: bool = False) -> str:
    if not isinstance(value, str):
        raise WorkflowError(f"{field} must be text")
    normalized = value.strip()
    if (not normalized and not allow_empty) or len(normalized) > maximum:
        raise WorkflowError(f"invalid {field}")
    return normalized


def _reject_sensitive(value: Any, key: str = "") -> None:
    if _SENSITIVE_KEY.search(key) or key in _FORBIDDEN_AGENT_FIELDS:
        raise WorkflowError("sensitive or raw agent field is not allowed")
    if isinstance(value, Mapping):
        for nested_key, nested_value in value.items():
            if not isinstance(nested_key, str):
                raise WorkflowError("artifact keys must be text")
            _reject_sensitive(nested_value, nested_key)
    elif isinstance(value, list):
        for item in value:
            _reject_sensitive(item)


def _validate_common(payload: dict) -> None:
    if payload.get("schema_version") != SCHEMA_VERSION:
        raise WorkflowError("unsupported schema version")
    _reject_sensitive(payload)


def validate_artifact(artifact_type: str, value: Mapping[str, Any]) -> dict:
    """Validate a role hand-off object and return a canonical JSON copy.

    The narrow schemas make it impossible to smuggle a prompt, raw model
    response or credentials through a generic ``metadata`` object.  User
    questions and allowed answer/excerpt fields are the only free-text fields.
    """
    payload = _json_copy(value)
    # These fields were added after the first workflow contracts shipped.
    # Supplying an empty, safe default keeps previously persisted/test role
    # fixtures readable while the canonical stored representation is explicit.
    if artifact_type == "evidence_set" and "retrieval_summary" not in payload:
        payload["retrieval_summary"] = []
    if artifact_type == "evidence_review" and "coverage" not in payload:
        payload["coverage"] = []
    _validate_common(payload)
    if artifact_type == "question_envelope":
        allowed = {"schema_version", "task_id", "question", "conversation_facts", "deadline_at", "remaining_model_calls"}
        if set(payload) != allowed:
            raise WorkflowError("invalid question envelope fields")
        _require_identifier(payload["task_id"], "task id")
        _bounded_text(payload["question"], "question", 20_000)
        if not isinstance(payload["conversation_facts"], list) or len(payload["conversation_facts"]) > 20:
            raise WorkflowError("invalid conversation facts")
        for item in payload["conversation_facts"]:
            _bounded_text(item, "conversation fact", 1_000)
        if not isinstance(payload["deadline_at"], (int, float)) or not isinstance(payload["remaining_model_calls"], int):
            raise WorkflowError("invalid question envelope budget")
    elif artifact_type == "research_plan":
        allowed = {"schema_version", "groups", "assumptions", "out_of_scope"}
        if set(payload) != allowed or not isinstance(payload["groups"], list):
            raise WorkflowError("invalid research plan")
        if not 1 <= len(payload["groups"]) <= MAX_RESEARCH_GROUPS:
            raise WorkflowError("invalid research group count")
        group_ids: set[str] = set()
        for group in payload["groups"]:
            if not isinstance(group, dict) or set(group) != {"id", "question", "queries", "priority"}:
                raise WorkflowError("invalid research group")
            group_id = _require_identifier(group["id"], "group id")
            if group_id in group_ids:
                raise WorkflowError("duplicate group id")
            group_ids.add(group_id)
            _bounded_text(group["question"], "group question", 4_000)
            if not isinstance(group["queries"], list) or not 1 <= len(group["queries"]) <= 8:
                raise WorkflowError("invalid group queries")
            for query in group["queries"]:
                _bounded_text(query, "group query", 500)
            if not isinstance(group["priority"], int) or not 1 <= group["priority"] <= MAX_RESEARCH_GROUPS:
                raise WorkflowError("invalid group priority")
        for list_name in ("assumptions", "out_of_scope"):
            if not isinstance(payload[list_name], list) or len(payload[list_name]) > 20:
                raise WorkflowError(f"invalid {list_name}")
            for item in payload[list_name]:
                _bounded_text(item, list_name, 1_000)
    elif artifact_type == "research_gap":
        allowed = {"schema_version", "round", "groups"}
        if set(payload) != allowed or not isinstance(payload["round"], int) or payload["round"] not in {1, 2}:
            raise WorkflowError("invalid research gap")
        if not isinstance(payload["groups"], list) or len(payload["groups"]) > MAX_RESEARCH_GROUPS:
            raise WorkflowError("invalid research gap groups")
        seen_group_ids: set[str] = set()
        for group in payload["groups"]:
            if not isinstance(group, dict) or set(group) != {"group_id", "queries"}:
                raise WorkflowError("invalid research gap group")
            group_id = _require_identifier(group["group_id"], "gap group id")
            if group_id in seen_group_ids:
                raise WorkflowError("duplicate research gap group")
            seen_group_ids.add(group_id)
            if not isinstance(group["queries"], list) or not 1 <= len(group["queries"]) <= 4:
                raise WorkflowError("invalid research gap queries")
            for query in group["queries"]:
                _bounded_text(query, "gap query", 500)
    elif artifact_type == "evidence_review":
        allowed = {"schema_version", "coverage_status", "supported_claims", "unsupported_questions", "conflicts", "allowed_evidence_ids", "coverage"}
        if set(payload) != allowed or payload["coverage_status"] not in {"sufficient", "partial", "insufficient"}:
            raise WorkflowError("invalid evidence review")
        for list_name, maximum, item_limit in (
            ("supported_claims", 100, 2_000), ("unsupported_questions", 30, 1_000),
            ("conflicts", 30, 1_000), ("allowed_evidence_ids", 100, 128),
        ):
            if not isinstance(payload[list_name], list) or len(payload[list_name]) > maximum:
                raise WorkflowError(f"invalid {list_name}")
            for item in payload[list_name]:
                _bounded_text(item, list_name, item_limit)
        if not isinstance(payload["coverage"], list) or len(payload["coverage"]) > MAX_RESEARCH_GROUPS:
            raise WorkflowError("invalid evidence coverage")
        seen_coverage_groups: set[str] = set()
        for item in payload["coverage"]:
            if not isinstance(item, dict) or set(item) != {"group_id", "status", "evidence_ids", "reason"}:
                raise WorkflowError("invalid evidence coverage item")
            group_id = _require_identifier(item["group_id"], "coverage group id")
            if group_id in seen_coverage_groups:
                raise WorkflowError("duplicate evidence coverage group")
            seen_coverage_groups.add(group_id)
            if item["status"] not in {"direct", "partial", "not_reported", "not_comparable", "missing"}:
                raise WorkflowError("invalid evidence coverage status")
            if not isinstance(item["evidence_ids"], list) or len(item["evidence_ids"]) > 60:
                raise WorkflowError("invalid evidence coverage ids")
            for evidence_id in item["evidence_ids"]:
                _require_identifier(evidence_id, "coverage evidence id")
            if item["status"] == "missing" and item["evidence_ids"]:
                raise WorkflowError("missing coverage cannot cite evidence")
            if item["status"] != "missing" and not item["evidence_ids"]:
                raise WorkflowError("supported coverage needs evidence")
            _bounded_text(item["reason"], "coverage reason", 1_000)
    elif artifact_type == "evidence_set":
        allowed = {"schema_version", "records", "retrieval_summary"}
        if set(payload) != allowed or not isinstance(payload["records"], list) or len(payload["records"]) > 60:
            raise WorkflowError("invalid evidence set")
        evidence_ids: set[str] = set()
        for record in payload["records"]:
            allowed_record = {
                "evidence_id", "group_id", "paper_id", "title", "source", "publication_date",
                "claim_support", "excerpt", "fulltext_available", "provenance",
            }
            if not isinstance(record, dict) or set(record) != allowed_record:
                raise WorkflowError("invalid evidence record")
            evidence_id = _require_identifier(record["evidence_id"], "evidence id")
            if evidence_id in evidence_ids:
                raise WorkflowError("duplicate evidence id")
            evidence_ids.add(evidence_id)
            _require_identifier(record["group_id"], "group id")
            _bounded_text(record["paper_id"], "paper id", 256)
            _bounded_text(record["title"], "paper title", 1_000)
            _bounded_text(record["source"], "evidence source", 64)
            if record["publication_date"] is not None:
                _bounded_text(record["publication_date"], "publication date", 64)
            if not isinstance(record["claim_support"], list) or len(record["claim_support"]) > 20:
                raise WorkflowError("invalid claim support")
            for claim_id in record["claim_support"]:
                _require_identifier(claim_id, "claim id")
            _bounded_text(record["excerpt"], "evidence excerpt", 8_000, allow_empty=True)
            if not isinstance(record["fulltext_available"], bool):
                raise WorkflowError("invalid fulltext flag")
            if not isinstance(record["provenance"], dict) or set(record["provenance"]) != {"retrieval_run_id"}:
                raise WorkflowError("invalid evidence provenance")
            _require_identifier(record["provenance"]["retrieval_run_id"], "retrieval run id")
        if not isinstance(payload["retrieval_summary"], list) or len(payload["retrieval_summary"]) > 96:
            raise WorkflowError("invalid retrieval summary")
        for item in payload["retrieval_summary"]:
            if not isinstance(item, dict) or set(item) != {
                "group_id", "source", "source_status", "candidate_count", "accepted_count",
                "contextual_count", "rejected_count", "round",
            }:
                raise WorkflowError("invalid retrieval summary item")
            _require_identifier(item["group_id"], "retrieval group id")
            _bounded_text(item["source"], "retrieval source", 64)
            _bounded_text(item["source_status"], "retrieval source status", 64)
            if not isinstance(item["round"], int) or item["round"] not in {0, 1, 2}:
                raise WorkflowError("invalid retrieval round")
            for count_name in ("candidate_count", "accepted_count", "contextual_count", "rejected_count"):
                if not isinstance(item[count_name], int) or not 0 <= item[count_name] <= 100:
                    raise WorkflowError("invalid retrieval count")
    elif artifact_type == "draft_answer":
        allowed = {"schema_version", "answer", "claim_evidence_map", "coverage_status", "unresolved_questions"}
        if set(payload) != allowed or payload["coverage_status"] not in {"sufficient", "partial"}:
            raise WorkflowError("invalid draft answer")
        _bounded_text(payload["answer"], "answer", 30_000)
        if not isinstance(payload["claim_evidence_map"], list) or len(payload["claim_evidence_map"]) > 100:
            raise WorkflowError("invalid claim evidence map")
        for item in payload["claim_evidence_map"]:
            if not isinstance(item, dict) or set(item) != {"claim_id", "evidence_ids"}:
                raise WorkflowError("invalid claim evidence entry")
            _require_identifier(item["claim_id"], "claim id")
            if not isinstance(item["evidence_ids"], list) or not item["evidence_ids"]:
                raise WorkflowError("invalid evidence id list")
            for evidence_id in item["evidence_ids"]:
                _require_identifier(evidence_id, "evidence id")
        if not isinstance(payload["unresolved_questions"], list) or len(payload["unresolved_questions"]) > 30:
            raise WorkflowError("invalid unresolved questions")
        for item in payload["unresolved_questions"]:
            _bounded_text(item, "unresolved question", 1_000)
    elif artifact_type == "citation_audit":
        allowed = {"schema_version", "status", "claim_results", "rejected_claim_ids"}
        if set(payload) != allowed or payload["status"] not in {"passed", "needs_revision", "failed"}:
            raise WorkflowError("invalid citation audit")
        if not isinstance(payload["claim_results"], list) or len(payload["claim_results"]) > 100:
            raise WorkflowError("invalid citation audit results")
        for item in payload["claim_results"]:
            if not isinstance(item, dict) or set(item) != {"claim_id", "evidence_ids", "status"}:
                raise WorkflowError("invalid citation audit claim")
            _require_identifier(item["claim_id"], "claim id")
            if item["status"] not in {"supported", "unsupported", "partial"}:
                raise WorkflowError("invalid citation claim status")
            if not isinstance(item["evidence_ids"], list):
                raise WorkflowError("invalid citation evidence list")
            for evidence_id in item["evidence_ids"]:
                _require_identifier(evidence_id, "evidence id")
        if not isinstance(payload["rejected_claim_ids"], list):
            raise WorkflowError("invalid rejected claims")
        for claim_id in payload["rejected_claim_ids"]:
            _require_identifier(claim_id, "claim id")
    else:
        raise WorkflowError("unsupported artifact type")
    return payload


class WorkflowStore:
    """The only persistence boundary used by the deterministic coordinator."""

    def __init__(self, path: str | Path | None = None, *, clock=_now):
        self.path = configured_workflow_path(str(path) if path is not None else None)
        self._clock = clock

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        connection = None
        try:
            try:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                connection = sqlite3.connect(self.path, timeout=10, isolation_level=None)
                connection.row_factory = sqlite3.Row
                connection.execute("PRAGMA journal_mode=WAL")
                connection.execute("PRAGMA foreign_keys=ON")
                self._initialize(connection)
            except sqlite3.Error as exc:
                raise WorkflowStoreError("workflow storage unavailable") from exc
            # SQLite's transaction context commits/rolls back, but does not close.
            with connection:
                yield connection
        finally:
            if connection is not None:
                connection.close()

    @staticmethod
    def _initialize(connection: sqlite3.Connection) -> None:
        connection.executescript("""
            CREATE TABLE IF NOT EXISTS workflow_run (
                run_id TEXT PRIMARY KEY,
                owner_ref TEXT NOT NULL,
                status TEXT NOT NULL,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL,
                deadline_at REAL NOT NULL,
                max_model_calls INTEGER NOT NULL,
                model_calls_used INTEGER NOT NULL DEFAULT 0,
                failure_code TEXT
            );
            CREATE TABLE IF NOT EXISTS workflow_stage (
                run_id TEXT NOT NULL REFERENCES workflow_run(run_id) ON DELETE CASCADE,
                sequence INTEGER NOT NULL,
                stage TEXT NOT NULL,
                status TEXT NOT NULL,
                created_at REAL NOT NULL,
                details_json TEXT NOT NULL,
                PRIMARY KEY (run_id, sequence)
            );
            CREATE TABLE IF NOT EXISTS workflow_artifact (
                run_id TEXT NOT NULL REFERENCES workflow_run(run_id) ON DELETE CASCADE,
                artifact_type TEXT NOT NULL,
                ordinal INTEGER NOT NULL,
                created_at REAL NOT NULL,
                sha256 TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                PRIMARY KEY (run_id, artifact_type, ordinal)
            );
            CREATE TABLE IF NOT EXISTS workflow_timing (
                run_id TEXT PRIMARY KEY REFERENCES workflow_run(run_id) ON DELETE CASCADE,
                policy TEXT NOT NULL
            );
        """)

    def create_run(self, run_id: str, owner_ref: str, *, max_model_calls: int | None = None,
                   time_budget_seconds: int | None = None,
                   time_policy: str = "hard-deadline/v1", report_profile: str | None = None) -> dict:
        run_id = _require_identifier(run_id, "run id")
        owner_ref = _require_identifier(owner_ref, "owner reference")
        try:
            policy = report_budget('standard' if report_profile is None else report_profile,
                time_budget=time_budget_seconds, model_calls=max_model_calls)
        except ValueError as exc:
            raise WorkflowError(str(exc)) from None
        max_model_calls, time_budget_seconds = policy['model_call_limit'], policy['time_budget_seconds']
        if (time_policy != 'hard-deadline/v1' and not is_soft_time_policy(time_policy)
                or time_policy == PROFILE_SOFT_POLICY and report_profile is None):
            raise WorkflowError("invalid time policy")
        now = float(self._clock())
        try:
            with self._connection() as connection:
                connection.execute("BEGIN IMMEDIATE")
                connection.execute(
                    "INSERT INTO workflow_run(run_id, owner_ref, status, created_at, updated_at, deadline_at, max_model_calls) "
                    "VALUES (?, ?, 'created', ?, ?, ?, ?)",
                    (run_id, owner_ref, now, now, now + int(time_budget_seconds), int(max_model_calls)),
                )
                connection.execute("INSERT INTO workflow_timing(run_id, policy) VALUES (?, ?)", (run_id, time_policy))
                if report_profile is not None:
                    # Only new writes create this table. Opening an old run for
                    # inspect/replay must not migrate its byte-identical store.
                    connection.execute("CREATE TABLE IF NOT EXISTS workflow_report_profile (run_id TEXT PRIMARY KEY REFERENCES workflow_run(run_id), payload_json TEXT NOT NULL)")
                    connection.execute("INSERT INTO workflow_report_profile VALUES (?, ?)",
                        (run_id, json.dumps(policy, sort_keys=True)))
                self._append_stage(connection, run_id, "created", "entered", now, {})
                return self._read_run(connection, run_id)
        except sqlite3.IntegrityError as exc:
            raise WorkflowError("workflow run already exists") from exc
        except sqlite3.Error as exc:
            raise WorkflowStoreError("workflow storage unavailable") from exc

    @staticmethod
    def _append_stage(connection: sqlite3.Connection, run_id: str, stage: str, status: str,
                      created_at: float, details: Mapping[str, Any]) -> None:
        next_sequence = connection.execute(
            "SELECT COALESCE(MAX(sequence), 0) + 1 FROM workflow_stage WHERE run_id = ?", (run_id,)
        ).fetchone()[0]
        safe_details = json.dumps(dict(details), ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        connection.execute(
            "INSERT INTO workflow_stage(run_id, sequence, stage, status, created_at, details_json) VALUES (?, ?, ?, ?, ?, ?)",
            (run_id, next_sequence, stage, status, created_at, safe_details),
        )

    @staticmethod
    def _read_run(connection: sqlite3.Connection, run_id: str) -> dict:
        row = connection.execute("SELECT * FROM workflow_run WHERE run_id = ?", (run_id,)).fetchone()
        if row is None:
            raise WorkflowError("workflow run not found")
        result = dict(row)
        timing = connection.execute("SELECT policy FROM workflow_timing WHERE run_id=?", (run_id,)).fetchone()
        result["time_policy"] = timing[0] if timing else "hard-deadline/v1"
        if connection.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='workflow_report_profile'").fetchone():
            policy = connection.execute("SELECT payload_json FROM workflow_report_profile WHERE run_id=?", (run_id,)).fetchone()
            if policy:
                result.update(json.loads(policy[0]))
        result["remaining_model_calls"] = result["max_model_calls"] - result["model_calls_used"]
        return result

    def get_run(self, run_id: str) -> dict:
        run_id = _require_identifier(run_id, "run id")
        with self._connection() as connection:
            return self._read_run(connection, run_id)

    def transition(self, run_id: str, next_status: str, *, details: Mapping[str, Any] | None = None,
                   failure_code: str | None = None) -> dict:
        run_id = _require_identifier(run_id, "run id")
        if next_status not in RUN_STATUSES:
            raise WorkflowError("invalid workflow status")
        if failure_code is not None and not re.fullmatch(r"[A-Z0-9_]{1,64}", failure_code):
            raise WorkflowError("invalid failure code")
        normalized_details = _json_copy(details or {})
        _reject_sensitive(normalized_details)
        now = float(self._clock())
        try:
            with self._connection() as connection:
                connection.execute("BEGIN IMMEDIATE")
                current = self._read_run(connection, run_id)
                if current["status"] in TERMINAL_STATUSES or next_status not in _TRANSITIONS.get(current["status"], frozenset()):
                    raise WorkflowError("invalid workflow transition")
                connection.execute(
                    "UPDATE workflow_run SET status=?, updated_at=?, failure_code=? WHERE run_id=?",
                    (next_status, now, failure_code, run_id),
                )
                self._append_stage(connection, run_id, next_status, "entered", now, normalized_details)
                return self._read_run(connection, run_id)
        except sqlite3.Error as exc:
            raise WorkflowStoreError("workflow storage unavailable") from exc

    def assert_active(self, run_id: str) -> dict:
        """Check wall-clock budget between non-model stages without issuing a permit."""
        run_id = _require_identifier(run_id, "run id")
        now = float(self._clock())
        exceeded = False
        try:
            with self._connection() as connection:
                connection.execute("BEGIN IMMEDIATE")
                run = self._read_run(connection, run_id)
                if run["status"] in TERMINAL_STATUSES:
                    raise WorkflowBudgetExceeded("workflow is terminal")
                if run["time_policy"] == "hard-deadline/v1" and now >= run["deadline_at"]:
                    connection.execute(
                        "UPDATE workflow_run SET status='timed_out', updated_at=?, failure_code='TIME_BUDGET_EXCEEDED' WHERE run_id=?",
                        (now, run_id),
                    )
                    self._append_stage(connection, run_id, "timed_out", "entered", now, {"reason": "time_budget"})
                    exceeded = True
                else:
                    return run
        except sqlite3.Error as exc:
            raise WorkflowStoreError("workflow storage unavailable") from exc
        if exceeded:
            raise WorkflowBudgetExceeded("workflow time budget exhausted")
        raise WorkflowBudgetExceeded("workflow is terminal")

    def reserve_model_call(self, run_id: str, role: str) -> ModelCallPermit:
        """Atomically issue one model call permission or fail before any provider call."""
        run_id = _require_identifier(run_id, "run id")
        role = _require_identifier(role, "role")
        now = float(self._clock())
        budget_reason: str | None = None
        try:
            with self._connection() as connection:
                connection.execute("BEGIN IMMEDIATE")
                run = self._read_run(connection, run_id)
                if run["status"] in TERMINAL_STATUSES:
                    budget_reason = "workflow is terminal"
                elif run["time_policy"] == "hard-deadline/v1" and now >= run["deadline_at"]:
                    connection.execute(
                        "UPDATE workflow_run SET status='timed_out', updated_at=?, failure_code='TIME_BUDGET_EXCEEDED' WHERE run_id=?",
                        (now, run_id),
                    )
                    self._append_stage(connection, run_id, "timed_out", "entered", now, {"reason": "time_budget"})
                    budget_reason = "workflow time budget exhausted"
                elif run["model_calls_used"] >= run["max_model_calls"]:
                    connection.execute(
                        "UPDATE workflow_run SET status='failed', updated_at=?, failure_code='MODEL_CALL_BUDGET_EXCEEDED' WHERE run_id=?",
                        (now, run_id),
                    )
                    self._append_stage(connection, run_id, "failed", "entered", now, {"reason": "model_call_budget"})
                    budget_reason = "workflow model call budget exhausted"
                else:
                    call_number = int(run["model_calls_used"]) + 1
                    connection.execute(
                        "UPDATE workflow_run SET model_calls_used=?, updated_at=? WHERE run_id=?", (call_number, now, run_id)
                    )
                    self._append_stage(connection, run_id, "model_call", "reserved", now, {"role": role, "call_number": call_number})
                    permit = ModelCallPermit(
                        run_id=run_id, role=role, call_number=call_number,
                        remaining_calls=int(run["max_model_calls"]) - call_number,
                        deadline_at=float(run["deadline_at"]) if run["time_policy"] == "hard-deadline/v1" else now + 120,
                    )
        except sqlite3.Error as exc:
            raise WorkflowStoreError("workflow storage unavailable") from exc
        if budget_reason:
            raise WorkflowBudgetExceeded(budget_reason)
        return permit

    def remaining_seconds(self, run_id: str) -> float:
        """Return the persisted wall-clock allowance without mutating the run."""
        run = self.get_run(run_id)
        return max(0.0, float(run["deadline_at"]) - float(self._clock()))

    def record_event(self, run_id: str, stage: str, status: str,
                     details: Mapping[str, Any] | None = None) -> dict:
        """Append a safe incremental event without changing workflow state."""
        run_id = _require_identifier(run_id, "run id")
        stage = _require_identifier(stage, "event stage")
        status = _require_identifier(status, "event status")
        normalized_details = _json_copy(details or {})
        _reject_sensitive(normalized_details)
        now = float(self._clock())
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            run = self._read_run(connection, run_id)
            self._append_stage(connection, run_id, stage, status, now, normalized_details)
            return run

    def force_terminal(self, run_id: str, status: str, *, failure_code: str | None = None,
                       details: Mapping[str, Any] | None = None, interrupt_unpublished_result: bool = False) -> dict:
        """Synchronize an outer timeout/cancel decision with the durable run.

        This is intentionally owned by the workflow boundary, not by an Agent.
        Repeating the same terminal decision is idempotent.
        """
        run_id = _require_identifier(run_id, "run id")
        if status not in {"failed", "timed_out", "cancelled"}:
            raise WorkflowError("invalid forced terminal status")
        if failure_code is not None and not re.fullmatch(r"[A-Z0-9_]{1,64}", failure_code):
            raise WorkflowError("invalid failure code")
        normalized_details = _json_copy(details or {})
        _reject_sensitive(normalized_details)
        now = float(self._clock())
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            run = self._read_run(connection, run_id)
            if run["status"] in TERMINAL_STATUSES and not (
                    interrupt_unpublished_result and run["status"] in {"completed", "partial", "needs_review"}):
                return run
            connection.execute(
                "UPDATE workflow_run SET status=?, updated_at=?, failure_code=? WHERE run_id=?",
                (status, now, failure_code, run_id),
            )
            self._append_stage(connection, run_id, status, "entered", now, normalized_details)
            return self._read_run(connection, run_id)

    def publish_degraded(self, run_id: str, *, failure_code: str,
                         details: Mapping[str, Any] | None = None) -> dict:
        """Publish a model-backed general answer after an evidence failure.

        This is deliberately separate from ``force_terminal``: a retrieval or
        evidence outage may still produce a useful, explicitly non-cited
        answer, while provider authentication/billing errors, cancellation and
        hard timeouts must remain failures.
        """
        run_id = _require_identifier(run_id, "run id")
        if failure_code is not None and not re.fullmatch(r"[A-Z0-9_]{1,64}", failure_code):
            raise WorkflowError("invalid failure code")
        normalized_details = _json_copy(details or {})
        _reject_sensitive(normalized_details)
        now = float(self._clock())
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            run = self._read_run(connection, run_id)
            if run["status"] in {"completed", "partial", "needs_review", "timed_out", "cancelled"}:
                return run
            connection.execute(
                "UPDATE workflow_run SET status='needs_review', updated_at=?, failure_code=? WHERE run_id=?",
                (now, failure_code, run_id),
            )
            self._append_stage(connection, run_id, "needs_review", "entered", now,
                               {**normalized_details, "degraded_answer": True})
            return self._read_run(connection, run_id)

    def add_artifact(self, run_id: str, artifact_type: str, value: Mapping[str, Any]) -> dict:
        run_id = _require_identifier(run_id, "run id")
        payload = validate_artifact(artifact_type, value)
        encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        digest = hashlib.sha256(encoded.encode("utf-8")).hexdigest()
        now = float(self._clock())
        try:
            with self._connection() as connection:
                connection.execute("BEGIN IMMEDIATE")
                self._read_run(connection, run_id)
                ordinal = connection.execute(
                    "SELECT COALESCE(MAX(ordinal), 0) + 1 FROM workflow_artifact WHERE run_id=? AND artifact_type=?",
                    (run_id, artifact_type),
                ).fetchone()[0]
                connection.execute(
                    "INSERT INTO workflow_artifact(run_id, artifact_type, ordinal, created_at, sha256, payload_json) "
                    "VALUES (?, ?, ?, ?, ?, ?)", (run_id, artifact_type, ordinal, now, digest, encoded),
                )
                return {"artifact_type": artifact_type, "ordinal": ordinal, "sha256": digest, "created_at": now}
        except sqlite3.Error as exc:
            raise WorkflowStoreError("workflow storage unavailable") from exc

    def list_artifacts(self, run_id: str) -> list[dict]:
        run_id = _require_identifier(run_id, "run id")
        with self._connection() as connection:
            self._read_run(connection, run_id)
            rows = connection.execute(
                "SELECT artifact_type, ordinal, created_at, sha256, payload_json FROM workflow_artifact "
                "WHERE run_id=? ORDER BY artifact_type, ordinal", (run_id,)
            ).fetchall()
        return [{
            "artifact_type": row["artifact_type"], "ordinal": row["ordinal"], "created_at": row["created_at"],
            "sha256": row["sha256"], "payload": json.loads(row["payload_json"]),
        } for row in rows]

    def list_stages(self, run_id: str) -> list[dict]:
        run_id = _require_identifier(run_id, "run id")
        with self._connection() as connection:
            self._read_run(connection, run_id)
            rows = connection.execute(
                "SELECT sequence, stage, status, created_at, details_json FROM workflow_stage "
                "WHERE run_id=? ORDER BY sequence", (run_id,)
            ).fetchall()
        return [{
            "sequence": row["sequence"], "stage": row["stage"], "status": row["status"],
            "created_at": row["created_at"], "details": json.loads(row["details_json"]),
        } for row in rows]
