"""Standalone page-aware PDF API for the currently repair-in-progress SciAssistant backend."""

import os
import uuid
from pathlib import Path
from typing import Any, Dict, Iterable, List

from flask import Flask, jsonify, request, send_from_directory
from werkzeug.utils import secure_filename

from pdf_pipeline import build_parse_metadata, parse_pdf, search_pdf


BASE_DIR = Path(__file__).resolve().parent
DEFAULT_STORAGE_DIR = BASE_DIR / 'pdf_uploads'
MAX_CONTENT_CHARS = 50_000


def _parse_file_ids(value: Any) -> List[str]:
    if isinstance(value, str):
        return [item.strip() for item in value.split(',') if item.strip()]
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    return []


def _file_payload(file_id: str, filename: str, parsed: Dict[str, Any], content_limit: int, full_content: bool) -> Dict[str, Any]:
    content = parsed.get('text') or ''
    content_for_response = content if full_content else content[:content_limit]
    parse_metadata = build_parse_metadata(parsed, preview_chars=300)
    return {
        'file_id': file_id,
        'filename': filename,
        'file_type': '.pdf',
        'parse_status': parsed.get('extraction_status'),
        'content': content_for_response,
        'content_length': parsed.get('content_length', 0),
        'parse_metadata': parse_metadata,
        'risk_summary': parse_metadata.get('risk_summary', {}),
        'citation_hint': 'Cite a PDF-backed claim as [n] (p. N). Do not cite a PDF claim without its source page.',
        'success': bool(parsed.get('success')),
    }


def create_app(storage_dir: Path | None = None) -> Flask:
    app = Flask(__name__)
    root = Path(storage_dir or DEFAULT_STORAGE_DIR).resolve()
    root.mkdir(parents=True, exist_ok=True)
    app.config['PDF_STORAGE_DIR'] = root
    app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024

    def path_for(file_id: str) -> Path | None:
        candidate = root / f'{file_id}.pdf'
        return candidate if candidate.exists() else None

    @app.get('/api/pdf/health')
    def health():
        return jsonify({'success': True, 'service': 'pdf-service'})

    @app.post('/api/pdf/upload')
    def upload_pdf():
        upload = request.files.get('file')
        if upload is None or not upload.filename:
            return jsonify({'success': False, 'message': 'Missing PDF file.'}), 400
        filename = secure_filename(upload.filename) or 'document.pdf'
        if not filename.lower().endswith('.pdf'):
            return jsonify({'success': False, 'message': 'Only PDF files are supported.'}), 400

        file_id = str(uuid.uuid4())
        pdf_path = root / f'{file_id}.pdf'
        upload.save(pdf_path)
        parsed = parse_pdf(pdf_path)
        response = _file_payload(file_id, filename, parsed, MAX_CONTENT_CHARS, False)
        response['download_url'] = f'/api/pdf/files/{file_id}'
        return jsonify(response), 201

    @app.post('/api/pdf/parse')
    def parse_files():
        data = request.get_json(silent=True) or {}
        file_ids = _parse_file_ids(data.get('file_ids'))
        if not file_ids:
            return jsonify({'success': False, 'message': 'Missing file_ids.'}), 400
        full_content = bool(data.get('full_content'))
        try:
            content_limit = max(0, int(data.get('content_limit', MAX_CONTENT_CHARS)))
        except (TypeError, ValueError):
            content_limit = MAX_CONTENT_CHARS

        files = []
        for file_id in file_ids:
            pdf_path = path_for(file_id)
            if not pdf_path:
                files.append({'file_id': file_id, 'success': False, 'error': 'File not found.'})
                continue
            parsed = parse_pdf(pdf_path)
            files.append(_file_payload(file_id, f'{file_id}.pdf', parsed, content_limit, full_content))
        return jsonify({'success': True, 'files': files, 'total_files': len(files)})

    @app.post('/api/pdf/search')
    def search_files():
        data = request.get_json(silent=True) or {}
        query = (data.get('query') or '').strip()
        file_ids = _parse_file_ids(data.get('file_ids'))
        if not query:
            return jsonify({'success': False, 'message': 'Missing query.'}), 400
        if not file_ids:
            return jsonify({'success': False, 'message': 'Missing file_ids.'}), 400
        try:
            top_k = max(1, min(20, int(data.get('top_k', 5))))
            chunk_size = max(200, min(10_000, int(data.get('chunk_size', 1500))))
            overlap = max(0, min(chunk_size - 1, int(data.get('overlap', 200))))
        except (TypeError, ValueError):
            return jsonify({'success': False, 'message': 'Invalid retrieval parameters.'}), 400

        snippets = []
        warnings = []
        for file_id in file_ids:
            pdf_path = path_for(file_id)
            if not pdf_path:
                warnings.append({'file_id': file_id, 'status': 'missing', 'message': 'File not found.'})
                continue
            result = search_pdf(pdf_path, query, top_k=top_k, chunk_size=chunk_size, overlap=overlap)
            if not result['success']:
                parsed = result['parse']
                warnings.append({'file_id': file_id, 'status': parsed.get('extraction_status'), 'message': parsed.get('error')})
                continue
            for snippet in result['snippets']:
                snippets.append({'file_id': file_id, 'filename': pdf_path.name, **snippet})
        snippets.sort(key=lambda item: item['score'], reverse=True)
        return jsonify({'success': True, 'snippets': snippets[:top_k], 'warnings': warnings})

    @app.get('/api/pdf/files/<file_id>')
    def download_pdf(file_id: str):
        pdf_path = path_for(file_id)
        if not pdf_path:
            return jsonify({'success': False, 'message': 'File not found.'}), 404
        return send_from_directory(root, pdf_path.name, as_attachment=True)

    return app


if __name__ == '__main__':
    port = int(os.getenv('PDF_SERVICE_PORT', '5001'))
    create_app().run(host='127.0.0.1', port=port, debug=False)
