"""Reviewed business skills, selected by Workflow; no filesystem/tool authority.

Inspired by pinned Deep Agents progressive disclosure and immutable snapshots.
No upstream implementation is copied, no remote/user supplied skill is loaded.
"""
from copy import deepcopy
import hashlib
import json

SKILL_POLICY = 'workflow-selected-reviewed-business-skills/v1'
ASSERTION_POLICY = 'declared-fact-inference-proposal-with-independent-audit/v1'
PRECISE_REVISION_POLICY = 'exact-rejected-fields-preserve-supported-fields-reaudit/v1'
ASSERTION_MODES = {
    'reported_fact': '文献报告', 'attributed_interpretation': '作者解释',
    'synthesis': '综合推断', 'proposal': '实验建议（尚未验证）',
    'source_observation': '本轮证据范围',
    'unclassified': '待审查分型',
}
_CATALOG = {
    'multi-question-coverage': {
        'roles': ['planner', 'reviewer', 'writer', 'citation_auditor'],
        'description': 'Keep each literal user ask and its position, not just topics.',
        'instructions': [
            'Separate substantive asks from background and global formatting constraints; never classify a question as background to avoid planning it.',
            'Check tail and middle asks against the question. Requirement IDs are navigation, not proof an ask was answered.',
            'A summary must answer first, not duplicate every section. Keep full requested data in the main report; no word/claim count target.',
            'An explicit concluding comparison or list of what follows/does not follow is an answer deliverable (conclusion_summary), not a formatting-only instruction. Keep it bound to the closing section and check it after publication.',
        ],
        'output_requirements': ['literal requirement_ids', 'assigned section_ids', 'specific incomplete reasons'],
        'template': {'requirement_id': '<current ID>', 'claim_ids': ['<actual draft IDs>'], 'status': 'limited'},
        'counterexamples': ['A topic paragraph does not answer the requested experimental design.', 'A correct ID binding can still contain irrelevant text.'],
    },
    'evidence-synthesis': {
        'roles': ['reviewer', 'writer', 'citation_auditor'],
        'description': 'Separate reported findings, author interpretation, synthesis and reading scope.',
        'instructions': [
            'For each claim declare assertion_mode: reported_fact, attributed_interpretation, synthesis, proposal, or source_observation.',
            'All modes still cite approved evidence. For synthesis/proposal those citations justify factual premises, not a claim the source performed the proposal.',
            'Check EVERY factual premise and numerical clause, even inside advice. Separate a source finding from your inference and state the inference assumptions visibly.',
            'A selected-excerpt inventory is checked against the actual cited text, not by demanding an author sentence saying the excerpt omits something. If the information exists in the excerpt reject the inventory claim.',
            'Source observations must say selected excerpts in each relevant field. They cannot assert the entire paper lacks experiments. An explicit author omission needs an actual source witness.',
        ],
        'output_requirements': ['assertion_mode per claim', 'approved evidence_ids', 'three report fields remain independently auditable'],
        'template': {'assertion_mode': 'synthesis', 'text': '<bounded inference and assumptions>', 'evidence_ids': ['<premise evidence>']},
        'counterexamples': ['A hypothesis label cannot legalize an invented measured number.', 'No result in selected text does not mean no experiment in the full paper.'],
    },
    'comparison-report': {
        'roles': ['planner', 'reviewer', 'writer', 'citation_auditor'],
        'description': 'Compare matching metrics/conditions, retaining directions, ties and source attribution.',
        'instructions': [
            'Keep metric name, dataset, baseline and experimental setting with each number. Do not rank across incompatible protocols.',
            'Distinguish an observed maximum from a desirable optimum: loss can have a reported largest value without that value being best. Lower loss is usually better; source-specific interpretation still needs review.',
            'Retain all printed ties and exceptions. Author configuration is not necessarily a unique optimum. Tables and requested complete rows belong in main text.',
        ],
        'output_requirements': ['metric/conditions', 'all relevant ties', 'comparability boundary'],
        'template': {'method': '<source method>', 'metric': '<exact metric>', 'setting': '<source conditions>', 'result': '<printed value>'},
        'counterexamples': ['Throughput is not single-request latency.', 'Reporting largest loss 1.23/r1 is not recommending maximizing loss.'],
    },
    'experimental-design': {
        'roles': ['planner', 'reviewer', 'writer', 'citation_auditor'],
        'description': 'Deliver a falsifiable unexecuted plan, grounded in evidence without inventing source experiments.',
        'instructions': [
            'Use assertion_mode=proposal and visibly label the plan unexecuted. State hypothesis, manipulated factor, controlled factors, metrics, repeated runs, decision rule and confounders.',
            'Design choices are not paper-reported values. Say they must be pre-registered; do not invent a source seed count or error bar.',
            'Do not treat overlapping score distributions or non-significance as proof of equivalence. For equivalence predefine an application-relevant margin and justified test; otherwise report estimates/uncertainty without claiming equivalence.',
            'A plan needs sound logic and approved evidence for its factual premises, not a paper that has already run exactly this future experiment.',
            'Name a reference configuration for the between-setting contrast. Repeated runs within one setting estimate variability; they are not themselves a control group for another setting. Match randomization/seed blocks where justified and state potential hyperparameter-tuning confounds.',
            'Keep design choices and paper observations in separate sentences/claims. The proposal does not need a boilerplate claim that the entire paper lacks seeds, uncertainty or a future experiment. If missing information is consequential, name only what the selected cited excerpts do not provide in that exact field.',
        ],
        'output_requirements': ['hypothesis', 'factor/controls', 'metric', 'repeats and uncertainty', 'predefined decision rule', 'confounds'],
        'template': {'assertion_mode': 'proposal',
            'text': '<unexecuted factor contrast with a reference, matched controls, repeated measurements and a predefined decision rule>',
            'scope_note': '该方案尚未执行，不是论文报告的实验结果。',
            'qualification': '<only consequential source-bound premises or design limitations; may be empty>'},
        'counterexamples': ['Failure to find significance is not evidence of no difference.', 'A future repeated-run count is a design choice, not a cited paper fact.'],
    },
    'report-revision': {
        'roles': ['writer', 'citation_auditor'],
        'description': 'Repair exact rejected fields while preserving independently supported content.',
        'instructions': [
            'Read exact-field-revision targets. Only detail_only targets explicitly verified by Workflow allow keeping text/scope and changing qualification alone.',
            'For other targets actually repair the identified assertion or remove it. Do not rename IDs, move the same error to a different field, or restore isolated claims just to fill a section.',
            'When the current writer-job declares revision_delivery_policy and target_claim_ids, return only the assigned section patch with stable target IDs and job-prefixed new IDs, not the whole report. Otherwise return the complete revised draft. Workflow merges patches without omission-based deletion; all revised and unchanged claims undergo a new complete audit, and an edit is not approval.',
        ],
        'output_requirements': ['stable IDs', 'actual exact-field edits', 'writer-job scoped patch, otherwise complete revised draft'],
        'template': {'claim_id': '<stable ID>', 'qualification': '<corrected detail, not just a confidence change>'},
        'counterexamples': ['Changing a correct main sentence unnecessarily can introduce a new error.', 'Deleting all claims to avoid repair is not a usable report.'],
    },
}


def _hash(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True).encode('utf-8')).hexdigest()


def _role_skill(key, value, role):
    result = deepcopy(value)
    if key == 'report-revision' and role == 'citation_auditor':
        result['instructions'] = [
            'Audit the supplied current draft against approved sources using the active audit schema. Return audit decisions, never rewritten prose or a section patch.',
            'Recheck changed AND unchanged claims in the assigned audit batch, including every visible field, exact witnesses, dependencies and requirement bindings. Prior approval and an edit are not current approval.',
            'Identify the exact current field and supported reason for each rejection. Do not attribute a removed old assertion to the current draft. Workflow alone routes Writer repairs and merges patches.',
        ]
        result['output_requirements'] = ['current audit schema', 'exact current fields', 'source support and dependency checks']
        result['template'] = {'claim_id': '<current ID>', 'decision': '<evidence-based audit verdict>'}
    return result


def skill_catalog():
    return {'schema_version': 'sciassistant.business-skill-catalog/v1', 'policy': SKILL_POLICY,
        'skills': [{'skill_id': k, 'version': _skill_version(k), 'sha256': _hash(v),
                    'role_sha256': {role: _hash(_role_skill(k, v, role)) for role in v['roles']}, 'description': v['description'],
                    'roles': list(v['roles'])} for k, v in _CATALOG.items()],
        'remote_or_user_skills_allowed': False, 'tool_permissions_added': False}


def _skill_version(key):
    return 3 if key == 'report-revision' else 2 if key in {'multi-question-coverage', 'experimental-design'} else 1


def skill_bundle(role, ledger=None, *, revision=False):
    if role not in {'planner', 'retriever', 'reviewer', 'gap_analyst', 'writer', 'citation_auditor'}:
        raise ValueError('SKILL_ROLE_UNKNOWN')
    rows = (ledger or {}).get('requirements', [])
    kinds = {r.get('answer_kind') for r in rows}
    selected = {'multi-question-coverage', 'evidence-synthesis'}
    if kinds & {'comparison', 'quantitative', 'table_reading'}:
        selected.add('comparison-report')
    if kinds & {'proposal', 'evaluation_protocol', 'falsifiable_decision', 'conditional_recommendation'}:
        selected.add('experimental-design')
    if revision:
        selected.add('report-revision')
    skills = []
    for k, v in _CATALOG.items():
        if k in selected and role in v['roles']:
            content = _role_skill(k, v, role)
            skills.append({'skill_id': k, 'version': _skill_version(k),
                           'sha256': _hash(content), **content})
    return {'schema_version': 'sciassistant.business-skill-load/v1', 'policy': SKILL_POLICY,
        'agent_role': role, 'skills': skills, 'selection': 'workflow-requirement-kinds-and-stage',
        'catalog_sha256': _hash(skill_catalog()), 'bundle_sha256': _hash(skills),
        'allowed_actions_override': False, 'remote_or_user_skills_allowed': False,
        'semantic_auto_approval': False}


def assertion_issues(draft):
    if draft.get('assertion_policy') != ASSERTION_POLICY:
        return []  # Historical drafts are not reinterpreted.
    return [{'claim_id': c.get('claim_id', 'draft'), 'reason': 'ASSERTION_MODE_INVALID',
             'field': 'assertion_mode', 'policy': ASSERTION_POLICY}
            for c in draft.get('claims', []) if not isinstance(c.get('assertion_mode'), str)
            or c['assertion_mode'] not in ASSERTION_MODES]


def assertion_packet(draft):
    """Declared modes and review questions, not a classification or verdict."""
    return {'schema_version': 'sciassistant.assertion-modes/v1', 'policy': ASSERTION_POLICY,
        'claims': [{'claim_id': c['claim_id'], 'declared_mode': c.get('assertion_mode'),
            'evidence_ids': list(c.get('evidence_ids') or []),
            'premises_and_logic_still_require_audit': True} for c in draft.get('claims', [])],
        'audit_instructions': [
            'Verify declared mode against the actual text, scope_note AND qualification; reject mislabeled measured facts, unsupported numbers and hidden causal leaps using existing per-field verdicts.',
            'For proposal verify controls, decision rule and factual premises; not executed is not a defect. Its source_witnesses support premises, not the future experiment as a reported result.',
            'For source_observation verify actual cited text and field-local scope; the source need not explicitly state that it omits something in a selected excerpt.',
            'For synthesis distinguish proposed inference from measured superiority and test all assumptions.',
            'unclassified means the model omitted a valid declaration; infer no approval or fact status from it. Audit the actual statement normally, and explain its role in field_results.detail.',
        ], 'semantic_auto_approval': False}
