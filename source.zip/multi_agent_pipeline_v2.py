"""Workflow-owned six-Agent literature pipeline used by the CLI demo."""

from __future__ import annotations

import json
import hashlib
from copy import deepcopy
from decimal import Decimal
import re
import time
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from multi_agent_agents import AgentContractError, AgentWorker, ArtifactDirectory, make_agent_input, make_rework_ticket, sanitize_artifact_text
from multi_agent_workflow import TERMINAL_STATUSES, WorkflowBudgetExceeded, WorkflowError, WorkflowStore
from multi_agent_rag import _token_estimate
from multi_agent_handoffs import (PLAN_SCHEMA, TYPED_PLAN_SCHEMAS, HANDOFF_POLICY, AUDIT_JOB_POLICY,
    plan_handoff_issues, evidence_need_contract, route_need_titles, need_flow_snapshot, compile_search_plan,
    comparison_observations, COMPARISON_POLICY, SOURCE_CONFIDENCE_POLICY)
from multi_agent_evidence import evidence_strength, evidence_label, weak_evidence, source_identity_record, ANSWER_STYLE_POLICY
from multi_agent_quality import answer_requirements, check_audit, publication_rejections, publication_decisions, evidence_flow_diagnostics, distinctive_entities, scope_plan_to_question, attach_reviewed_source_scope, citation_audit_input, check_claim_revision, source_boundary_brief, writer_revision_brief, check_semantic_boundaries, check_reading_scope, check_metric_direction, METRIC_DIRECTION_POLICY, PRINTED_METRIC_DIRECTION_POLICY, PROCESSING_OBSERVATION_POLICY, SEMANTIC_BOUNDARY_POLICY, READING_SCOPE_POLICY, QUANTITY_FEEDBACK_POLICY, AUDIT_PROTOCOL_POLICY, ABSENCE_AUDIT_SCHEMA, ABSENCE_SCOPE_POLICY, REPORT_REFERENCE_POLICY, audit_witness_options, report_evidence
from multi_agent_status import source_execution_notice, EXECUTION_NOTICE_POLICY
from multi_agent_skills import (SKILL_POLICY, ASSERTION_POLICY, PRECISE_REVISION_POLICY,
    ASSERTION_MODES, skill_bundle, skill_catalog, assertion_issues, assertion_packet)
from multi_agent_publication import (PUBLICATION_POLICY, AUDIT_MATERIAL_POLICY, audit_material,
    review_request, check_review as check_report_review, conflict_issues, coverage as publication_coverage, recovery_brief, retain_untargeted_claims)
from multi_agent_audit_batches import (AUDIT_BATCH_POLICY, AUDIT_BATCH_RECOVERY_POLICY, MAX_AUDIT_CLAIMS, is_batched,
    required_audit_calls, source_batches, merge_source_audits, global_review_input, digest as audit_digest)
from multi_agent_quality import check_evaluation_roles, EVALUATION_ROLE_POLICY
from multi_agent_quality import check_memory_component_scope, MEMORY_COMPONENT_POLICY
from multi_agent_quality import check_symbol_roles, SYMBOL_ROLE_POLICY
from multi_agent_quality import check_condition_denials, CONDITION_DENIAL_POLICY
from multi_agent_quality import audit_revision_context, AUDIT_CONTEXT_POLICY, AUDIT_QUOTE_MENU_POLICY
from multi_agent_quality import SCIENTIFIC_REVIEW_FRAME_POLICY, audit_correction_brief
from multi_agent_quality import (WITNESS_CHOICE_POLICY, resolve_witness_choices,
    witness_selection_diagnostics, WITNESS_SELECTION_FEEDBACK_POLICY)
from multi_agent_quality import SOURCE_ROLE_INVENTORY_POLICY, check_printed_type_denials
from multi_agent_quality import (TERM_BINDING_POLICY, check_term_family_aliases,
    ABSENCE_CHOICE_POLICY, resolve_absence_choices, answer_focus_brief, SHORT_CHOICE_POLICY,
    PASSAGE_EXCLUSIVITY_POLICY, check_passage_exclusivity,
    AUDIT_ROW_RETENTION_POLICY, retain_valid_audit_rows)
from multi_agent_quality import PRIMARY_SOURCE_POLICY, answer_scope_summary
from multi_agent_quality import PREMISE_CHECK_POLICY, checked_premise_assessments
from multi_agent_quality import EMPTY_FIELD_ABSENCE_POLICY
from multi_agent_quality import RANK_TABLE_TREND_POLICY, check_rank_table_trends
from multi_agent_report_contracts import (report_budget, is_soft_time_policy, PROFILE_SOFT_POLICY,
    REPORT_PLAN_SCHEMA, question_inventory, compile_user_requirements)
from multi_agent_sections import (SECTION_DRAFT_SCHEMA, SECTION_POLICY, SECTION_POLICIES, report_outline, section_dossiers,
    writer_jobs, writer_job_evidence, writer_job_material, writer_job_issues, merge_writer_batches, revision_job, outline_digest, project_writer_job,
    REVISION_DELIVERY_POLICY, MAX_REVISION_JOBS, revision_jobs, merge_revision_jobs,
    initial_delivery_budget, INITIAL_DELIVERY_BUDGET_POLICY)
from multi_agent_quality import ABSENCE_MENU_POLICY, ABSENCE_REASON_POLICY, ABSENCE_INVENTORY_POLICY, WITNESS_COPY_POLICY, WITNESS_CAPACITY_POLICY, witness_quote_limit

SearchFunction = Callable[[str, int], Mapping[str, Any]]
COVERAGE_STATUSES = {"direct", "indirect", "partial", "not_reported", "not_comparable", "conflicting", "missing"}
REVIEW_REASONS = {"SUPPORTED", "IRRELEVANT", "INSUFFICIENT_CONTEXT", "WEAK_SOURCE",
                 "METRIC_MISMATCH", "LOCATOR_INCOMPLETE", "CONFLICTING", "REASON_NOT_PROVIDED"}
SOFT_TIME_POLICY = "research-start-300-complete-inflight/v1"
RESEARCH_START_CUTOFF_SECONDS = 300


class PipelineExecutionError(RuntimeError):
    def __init__(self, code, *, diagnostic_artifact_ids=()):
        super().__init__(code)
        self.code = code
        self.diagnostic_artifact_ids = tuple(diagnostic_artifact_ids)


class ReviewContractError(WorkflowError):
    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


def canonical_metric(value: str) -> str:
    """Normalize spelling, not different scientific measurements."""
    key = re.sub(r"[\s-]+", "_", value.strip().lower())
    return {"single_request_latency": "latency", "end_to_end_latency": "latency",
            "generation_quality": "quality", "memory_footprint": "memory", "memory_usage": "memory",
            "kv_memory": "memory", "time_to_first_token": "ttft", "time_per_output_token": "tpot"}.get(key, key)


def complete_initial_search_actions(plan: Mapping, requests: Sequence[Mapping], *, action="request_arxiv_search") -> tuple[list[dict], list[str]]:
    """Cover each planned topic without another LLM call or invented queries.

    Reject malformed/over-budget proposals first. For a missing topic only,
    execute its Planner-provided first query. Recovery remains gap-only.
    """
    groups = plan["groups"]
    grouped = {group["id"]: [] for group in groups}
    seen = set()
    if len(requests) > 6:
        raise WorkflowError("too many initial search actions")
    for row in requests:
        args = row.get("arguments") or {}
        key, query, request_id = args.get("group_id"), args.get("query"), row.get("request_id")
        if (row.get("action") != action or key not in grouped or not isinstance(query, str)
                or not query.strip() or len(query) > 500 or not isinstance(request_id, str) or request_id in seen):
            raise WorkflowError("invalid initial search action")
        seen.add(request_id)
        grouped[key].append(dict(row))
        if len(grouped[key]) > 2:
            raise WorkflowError("too many queries per group")
    recovered = []
    for group in groups:
        key = group["id"]
        if grouped[key]:
            continue
        queries = group.get("queries") or []
        if not isinstance(queries, list) or not queries or not isinstance(queries[0], str) or not 1 <= len(queries[0].strip()) <= 500:
            raise WorkflowError("missing topic has no valid planned query")
        request_id = f"plan-fallback-{key}"
        while request_id in seen:
            request_id += "-f"
        grouped[key].append({"request_id": request_id, "action": action,
                             "arguments": {"group_id": key, "query": queries[0].strip()}})
        recovered.append(key)
    # First query of every topic before any second query; deadline is shared.
    return [grouped[g["id"]][n] for n in range(2) for g in groups if len(grouped[g["id"]]) > n], recovered


def fallback_research_plan(question: str) -> dict:
    """Build the smallest query-only handoff after a Planner format failure.

    It copies the user's question as the sole search query.  No topic,
    entity, metric, paper title, or scientific conclusion is invented; later
    Reviewer and Auditor stages remain the authority for evidence and claims.
    """
    query = re.sub(r"\s+", " ", str(question or "")).strip()[:500]
    return {"schema_version": "sciassistant.research-plan/fallback-v1",
            "groups": [{"id": "g1", "question": str(question or "").strip()[:1200],
                        "queries": [query], "core": [query], "support": [], "metrics": []}],
            "fallback_policy": "literal-user-question-only-no-model-plan"
            }


def _mentions_entity(value, entity):
    return re.search(r"(?<![A-Za-z0-9])" + re.escape(entity) + r"(?![A-Za-z0-9])",
                     unicodedata.normalize("NFKC", value), re.I) is not None


def prioritize_named_entity_actions(plan, requests, requirements):
    """Keep a requested distinctive entity in its group's query SET.

    Same two-query quota; never adds an unplanned group or an extra network call.
    Generic acronyms such as SOTA/MLLM are deliberately not pinned.
    """
    result, changes = list(requests), []
    entities = distinctive_entities(requirements["explicit_entities"])
    for group in plan["groups"]:
        topic = " ".join([str(group.get("question", "")), *group.get("core", [])]).lower()
        entity = next((e for e in entities if _mentions_entity(topic, e)), None)
        if not entity:
            continue
        positions = [n for n, r in enumerate(result) if r["arguments"]["group_id"] == group["id"]]
        if not positions:
            continue
        # A second query already covers the named entity. Replacing the first
        # can destroy a different requested entity's original-paper search.
        if any(_mentions_entity(result[n]["arguments"]["query"], entity) for n in positions):
            continue
        if any(_query_has_exclusion(result[n]["arguments"]["query"]) for n in positions):
            continue
        n = positions[0]
        result[n] = {**result[n], "arguments": {**result[n]["arguments"],
                     "query": f'(ti:"{entity}" OR abs:"{entity}")'}}
        changes.append({"group_id": group["id"], "entity": entity, "reason_code": "EXPLICIT_ENTITY_QUERY"})
    return result, changes


def _query_has_exclusion(query):
    unquoted = re.sub(r'"(?:\\.|[^"\\])*"', "", query)
    return re.search(r"\b(?:NOT|ANDNOT)\b", unquoted, re.I) is not None


def query_targets_title(query, title):
    """Recognize a conservative quoted title prefix, not a paper's identity.

    A short generic entity is not a title search. Negative/ambiguous queries
    deliberately do not establish positive coverage of a source clue.
    """
    if _query_has_exclusion(query):
        return False
    def words(value):
        return re.findall(r"\w+", unicodedata.normalize("NFKC", value).casefold())
    title_words = words(title)
    if not title_words:
        return False
    clauses = re.findall(r'\b(?:ti|abs)\s*:\s*"([^"\n]+)"', query, re.I)
    for clause in clauses:
        fragment = words(clause)
        if fragment == title_words:
            return True
        # >=4 words AND >=half the title, in original order, anchored at its
        # start. 'ViT', 'deep learning', or an interior method name do not count.
        if len(fragment) >= 4 and len(fragment) * 2 >= len(title_words) and title_words[:len(fragment)] == fragment:
            return True
    return query.strip().casefold() == title.strip().casefold()


def prepare_primary_source_plan(plan, question, source_scope):
    """Reserve an EXISTING query slot from question-only Planner title clues.

    No PDF content, paper IDs or new topic is introduced. An explicit original
    source request has a deterministic retrieval opportunity, not an approval.
    """
    from copy import deepcopy
    result = deepcopy(plan)
    report = {"schema_version": "sciassistant.primary-source-plan/v1", "policy": PRIMARY_SOURCE_POLICY,
              "changes": [], "targets": [], "source_scope": source_scope}
    result.pop("primary_source_targets", None)
    result.pop("primary_source_policy", None)
    # Chinese users often say 原始LoRA rather than LoRA原始论文. These names
    # must match question-only Planner title clues; no PDF/context vocabulary
    # or remembered paper IDs can become a public query.
    leading_names = re.findall(r"(?:原始(?:方法)?|原版|最初的?)\s*([A-Za-z][A-Za-z0-9+./-]{1,50})", question)
    leading_names += re.findall(r"\boriginal\s+([A-Za-z][A-Za-z0-9+./-]{1,50})", question, re.I)
    leading_names = [n for n in leading_names if n.casefold() not in {
        'pdf', 'url', 'api', 'http', 'json', 'paper', 'papers', 'method', 'model', 'models', 'version', 'source', 'sources'}]
    if (source_scope not in {"arxiv", "uploaded_pdf_and_arxiv"} or re.search(
            r"(?:不要|不必|无需|不需要|不允许).{0,15}(?:原始|原版|奠基).{0,8}(?:论文|[A-Za-z])|do not.{0,20}(?:original|primary)", question, re.I) or not (leading_names or re.search(
            r"原始(?:方法)?论文|原版论文|奠基性论文|original\s+(?:method\s+)?papers?|primary\s+sources?", question, re.I))):
        return result, report
    names = re.findall(r"([A-Za-z][A-Za-z0-9+./-]*)\s*(?:的\s*)?原始(?:方法)?论文", question)
    names += leading_names
    seen = set()
    for group in result["groups"]:
        hints, queries = group.get("source_hints") or [], group.get("queries") or []
        if not hints:
            report["changes"].append({"group_id": group["id"], "reason_code": "NO_PLANNED_TITLE_CLUE"})
            continue
        if (not isinstance(hints, list) or len(hints) > 2 or any(not isinstance(t, str)
                or not 4 <= len(t.strip()) <= 200 or re.search(r'[\x00-\x1f\x7f"\\<>]|https?://', t, re.I) for t in hints)):
            raise WorkflowError("invalid source title clue")
        if not 1 <= len(queries) <= 2 or any(_query_has_exclusion(q) for q in queries):
            continue
        matching = [t for t in hints if any(_mentions_entity(t.split(":", 1)[0], name) for name in names)]
        if names and not matching:
            continue
        title = (matching or hints)[0].strip()
        normalized = " ".join(re.findall(r"\w+", title.casefold()))
        if normalized in seen:
            continue
        seen.add(normalized)
        query = f'ti:"{title}"'
        position = next((i for i, q in enumerate(queries) if query_targets_title(q, title)), len(queries)-1)
        # Auto keeps one local opportunity AND one public opportunity/topic.
        if source_scope == "uploaded_pdf_and_arxiv" and len(queries) == 1:
            group["queries"] = [queries[0], query]
        else:
            group["queries"][position] = query
        target = {"group_id": group["id"], "query": query, "source_title_clue": title}
        report["targets"].append(target)
        report["changes"].append({**target, "reason_code": "QUESTION_REQUESTED_ORIGINAL_OPPORTUNITY"})
    result["primary_source_policy"] = PRIMARY_SOURCE_POLICY
    result["primary_source_targets"] = report["targets"]
    return result, report


def prioritize_source_title_actions(plan, requests, requirements):
    """Replace an existing slot with a Planner clue, never add a search/citation.

    Actual metadata is still required, and explicit entity searches keep first
    priority. The title match later affects reading order, NOT source approval.
    """
    result, changes = list(requests), []
    entities = distinctive_entities(requirements["explicit_entities"])
    required = {t["group_id"]: t for t in plan.get("primary_source_targets", [])}
    for group in plan["groups"]:
        hints = group.get("source_hints") or []
        if group["id"] in required:
            hints = [required[group["id"]]["source_title_clue"]]
        if not hints:
            continue
        if (not isinstance(hints, list) or len(hints) > 2 or any(
                not isinstance(title, str) or not 4 <= len(title.strip()) <= 200
                or re.search(r'[\x00-\x1f\x7f"\\<>]|https?://', title, re.I) for title in hints)):
            raise WorkflowError("invalid source title clue")
        positions = [n for n, row in enumerate(result) if row["arguments"]["group_id"] == group["id"]]
        if not positions or (len(positions) < 2 and group["id"] not in required):
            continue
        # Do not undo an explicit exclusion selected by Retriever.
        if any(_query_has_exclusion(result[n]["arguments"]["query"]) for n in positions):
            continue
        # At most one original-title slot: ANY planned title already covered
        # satisfies it. Do not force hints[0] over another original/title clue.
        covered = [(n, title) for title in hints for n in positions
                   if query_targets_title(result[n]["arguments"]["query"], title)]
        if covered:
            n, title = covered[0]
            if title.casefold() not in result[n]["arguments"]["query"].casefold():
                changes.append({"group_id": group["id"], "source_title_clue": title.strip(),
                    "matching_request_ids": [result[pos]["request_id"] for pos, _ in covered],
                    "query_replaced": False, "reason_code": "PLANNED_TITLE_FRAGMENT_ALREADY_SEARCHED"})
            continue
        title = hints[0]
        position = positions[-1]
        old_query = result[position]["arguments"]["query"]
        if any(_mentions_entity(old_query, entity)
               and not _mentions_entity(f'ti:"{title.strip()}"', entity)
               and not any(_mentions_entity(result[n]["arguments"]["query"], entity)
                           for n in positions if n != position) for entity in entities):
            continue
        result[position] = {**result[position], "arguments": {**result[position]["arguments"],
                            "query": f'ti:"{title.strip()}"'}}
        changes.append({"group_id": group["id"], "source_title_clue": title.strip(),
                        "previous_query": old_query, "reason_code": "PLANNED_SOURCE_TITLE_QUERY"})
    return result, changes


@dataclass(frozen=True)
class PipelineAgents:
    planner: AgentWorker
    retriever: AgentWorker
    reviewer: AgentWorker
    gap_analyst: AgentWorker
    writer: AgentWorker
    citation_auditor: AgentWorker

    def by_role(self, role: str) -> AgentWorker:
        return getattr(self, role)


class DeterministicLiteratureExecutor:
    """Validated tool boundary. Persist a snapshot after each completed query."""

    def __init__(self, search: SearchFunction):
        self.search = search

    def execute(self, requests: Sequence[Mapping[str, Any]], *, recovery: bool = False,
                group_ids: set[str] | None = None, deadline: float | None = None,
                progress: Callable[[dict], None] | None = None) -> dict[str, Any]:
        if len(requests) > (2 if recovery else 6):
            raise WorkflowError("too many search actions")
        counts: dict[str, int] = {}
        request_ids: set[str] = set()
        for item in requests:
            arguments = item.get("arguments") or {}
            query, group_id = str(arguments.get("query") or "").strip(), str(arguments.get("group_id") or "")
            if item.get("action") != "request_arxiv_search" or not query or len(query) > 500:
                raise WorkflowError("invalid arXiv action")
            if not group_id or (group_ids is not None and group_id not in group_ids):
                raise WorkflowError("unknown research group")
            if item["request_id"] in request_ids:
                raise WorkflowError("duplicate search request")
            request_ids.add(item["request_id"])
            counts[group_id] = counts.get(group_id, 0) + 1
            if counts[group_id] > 2:
                raise WorkflowError("too many queries per group")
        evidence: dict[str, dict] = {}
        observations: list[dict] = []
        for item in requests:
            args = item["arguments"]
            query, group_id = str(args["query"]).strip(), str(args["group_id"])
            if deadline is not None and time.monotonic() >= deadline:
                result = {"status": "deadline_skipped", "papers": []}
            else:
                result = self.search(query, 5)
            status = str(result.get("status") or "error") if isinstance(result, Mapping) else "error"
            accepted = 0
            if isinstance(result, Mapping) and status == "ok":
                for paper in list(result.get("papers") or [])[:5]:
                    if not isinstance(paper, Mapping):
                        continue
                    paper_id = str(paper.get("paper_id") or paper.get("id") or "").strip()
                    title = str(paper.get("title") or "").strip()
                    if not paper_id or not title:
                        continue
                    evidence_id = f"arxiv-{paper_id.replace('.', '-').replace('/', '-')}"
                    if evidence_id in evidence:
                        if group_id not in evidence[evidence_id]["group_ids"]:
                            evidence[evidence_id]["group_ids"].append(group_id)
                        continue
                    evidence[evidence_id] = {
                        "evidence_id": evidence_id, "group_id": group_id, "group_ids": [group_id],
                        "paper_id": paper_id, "title": title[:1_000], "source": "arxiv",
                        "authors": source_identity_record(paper)['authors'],
                        "author_metadata_source": (result.get('retrieval_origin') or 'arxiv_api'),
                        "excerpt": str(paper.get("abstract") or "")[:4_000],
                        "official_url": str(paper.get("landing_url") or paper.get("url") or "")[:2_000],
                        "published_at": paper.get("published_at"), "updated_at": paper.get("updated_at"),
                        "locator": {"page": None, "section": "abstract", "bbox": None,
                                    "anchor_text": str(paper.get("abstract") or "")[:240]},
                    }
                    accepted += 1
            observations.append({"request_id": item["request_id"], "group_id": group_id,
                                 "query": query, "executed_query": result.get("executed_query", query) if isinstance(result, Mapping) else query,
                                 "source_status": status, "accepted_count": accepted})
            snapshot = {"schema_version": "sciassistant.evidence-set/v2", "evidence": list(evidence.values()),
                        "observations": list(observations), "recovery": recovery}
            if progress:
                progress(snapshot)
        return {"schema_version": "sciassistant.evidence-set/v2", "evidence": list(evidence.values()),
                "observations": observations, "recovery": recovery}


def review_targets(evidence, plan, previous=None):
    """A code-owned checklist, not an approval or a replacement for excerpts."""
    ids = [row["evidence_id"] for row in evidence["evidence"]]
    if len(ids) != len(set(ids)):
        raise WorkflowError("duplicate current review evidence")
    previous = previous or {}
    prior = set(previous.get("allowed_evidence_ids") or [])
    decided = {row["evidence_id"] for row in previous.get("decisions") or [] if isinstance(row, Mapping) and isinstance(row.get("evidence_id"), str)}
    current = set(ids)
    return {"schema_version": "sciassistant.review-targets/v1",
            "current_evidence_ids": ids,
            "new_evidence_ids": [key for key in ids if key not in decided],
            "new_or_previously_unapproved_ids": [key for key in ids if key not in prior],
            "prior_approved_current_ids": [key for key in ids if key in prior],
            "historical_only_ids": sorted(prior - current),
            "requested_coverage": [{"group_id": group["id"], "metric": metric}
                for group in plan.get("groups", []) for metric in group.get("metrics", [])],
            "all_current_ids_require_new_decision": True,
            "previous_decisions_are_context_only": True,
            "task_fit_checklist": {
                "enabled": plan.get('task_fit_review_policy') == 'both-task-sides-before-application/v1',
                "current_evidence_ids": ids,
                "questions": [
                    {"role": "method_task", "question": "Does this excerpt explain the named method's actual task or outputs?"},
                    {"role": "target_task", "question": "Does this excerpt explain the requested target task, labels, or outputs? It need NOT mention the source method."},
                    {"role": "direct_application", "question": "Does this excerpt actually apply/evaluate the method on that target, rather than merely explain either side?"}],
                "instructions": "Evaluate these as SEPARATE support questions for EVERY excerpt. A no on direct_application "
                    "does not negate a yes on target_task or method_task. Do not reject target-task definitions solely because "
                    "the source method is absent. Reference lists or an incidental target keyword are not task definitions. "
                    "Approve only real useful content; put actual roles in task_side_roles and explain in detail.",
                "automatic_approval": False},
            "automatic_approval": False}


def check_review(review: Mapping[str, Any], evidence: Mapping[str, Any], groups: set[str], *, plan: Mapping | None = None) -> dict:
    result = dict(review)
    if result.get("schema_version") not in {None, "sciassistant.evidence-review/v1", "sciassistant.evidence-review/v2",
                                          "sciassistant.evidence-review/v3", "sciassistant.evidence-review/v4",
                                          "sciassistant.evidence-review/v5"}:
        raise ReviewContractError("REVIEW_SCHEMA_UNKNOWN")
    if result.get("coverage_status") not in {"sufficient", "partial", "insufficient", "needs_review"}:
        raise ReviewContractError("REVIEW_COVERAGE_STATUS_INVALID")
    ids = {item["evidence_id"] for item in evidence["evidence"]}
    sources = {item["evidence_id"]: item for item in evidence["evidence"]}
    approved = result.get("allowed_evidence_ids")
    if not isinstance(approved, list) or not all(isinstance(key, str) for key in approved) or not set(approved).issubset(ids):
        raise ReviewContractError("REVIEW_APPROVED_EVIDENCE_UNKNOWN")
    coverage = result.get("coverage") or []
    if not isinstance(coverage, list) or len(coverage) > 30:
        raise ReviewContractError("REVIEW_COVERAGE_MATRIX_INVALID")
    result["coverage"] = coverage = [dict(row) if isinstance(row, Mapping) else row for row in coverage]
    for row in coverage:
        if not isinstance(row, Mapping) or not isinstance(row.get("group_id"), str) or row.get("group_id") not in groups or not isinstance(row.get("status"), str) or row.get("status") not in COVERAGE_STATUSES:
            raise ReviewContractError("REVIEW_COVERAGE_ROW_INVALID")
        row_ids = row.get("evidence_ids", [])
        if not isinstance(row_ids, list) or not all(isinstance(key, str) for key in row_ids):
            raise ReviewContractError("REVIEW_COVERAGE_IDS_INVALID")
        if not set(row_ids).issubset(set(approved)):
            raise ReviewContractError("REVIEW_COVERAGE_UNAPPROVED_EVIDENCE")
        if row["status"] in {"not_reported", "not_comparable"} and not row.get("evidence_ids"):
            # Lack of a selected source is a gap, not evidence that a paper
            # omitted the metric. Preserve the usable evidence and qualify it.
            row["status"] = "missing"
            row["recommended_action"] = "qualified_answer"
        if row["status"] != "missing" and not row.get("evidence_ids"):
            raise ReviewContractError("REVIEW_CONCLUSION_WITHOUT_EVIDENCE")
        if row_ids and all(weak_evidence(sources[key]) for key in row_ids):
            if row["status"] == "direct":
                row["status"] = "partial"
                row["recommended_action"] = "qualified_answer"
            if row["status"] == "not_reported" and all(evidence_strength(sources[key]) == "abstract_only" for key in row_ids):
                row["status"] = "missing"
                row["recommended_action"] = "targeted_search"
    # A model cannot declare full coverage by silently omitting a requested metric.
    # Legacy plans without explicit metrics retain their previous contract.
    aliases = {"latency": {"latency"},
               "quality": {"quality", "generation_quality", "accuracy", "perplexity"},
               "memory": {"memory", "memory_usage", "kv_memory"}}
    for group in (plan or {}).get("groups") or []:
        metrics = group.get("metrics", [])
        if not isinstance(metrics, list) or len(metrics) > 8:
            raise ReviewContractError("REVIEW_REQUESTED_METRIC_INVALID")
        for metric in metrics:
            if not isinstance(metric, str) or not 1 <= len(metric) <= 100:
                raise ReviewContractError("REVIEW_REQUESTED_METRIC_INVALID")
            metric_key = canonical_metric(metric)
            accepted_names = {canonical_metric(name) for name in aliases.get(metric_key, {metric_key})}
            if not any(row["group_id"] == group["id"] and canonical_metric(str(row.get("metric", ""))) in accepted_names for row in coverage):
                coverage.append({"gap_id": f"{group['id']}-metric-{len(coverage) + 1}", "group_id": group["id"],
                                 "metric": metric, "status": "missing", "evidence_ids": [],
                                 "comparability": "unknown", "recommended_action": "targeted_search"})
    if len(coverage) > 30:
        raise ReviewContractError("REVIEW_COVERAGE_MATRIX_INVALID")
    if not approved:
        result["coverage_status"] = "insufficient"
    elif result["coverage_status"] == "insufficient":
        result["coverage_status"] = "partial"
    if approved and all(weak_evidence(sources[key]) for key in approved) and result["coverage_status"] == "sufficient":
        result["coverage_status"] = "partial"
    if any(row["status"] in {"indirect", "partial", "not_reported", "not_comparable", "missing"} for row in coverage):
        if result["coverage_status"] == "sufficient":
            result["coverage_status"] = "partial"
    if result.get("conflicts") or any(row["status"] == "conflicting" for row in coverage):
        result["coverage_status"] = "needs_review" if approved else "insufficient"
    # Backward compatible, but never invent a rejection rationale for old runs.
    decisions = result.get("decisions", [])
    if not isinstance(decisions, list) or len(decisions) > 12:
        raise ReviewContractError("REVIEW_DECISIONS_INVALID")
    by_id = {}
    for row in decisions:
        if (not isinstance(row, Mapping) or not isinstance(row.get("evidence_id"), str)
                or row["evidence_id"] not in ids or row["evidence_id"] in by_id
                or not isinstance(row.get("decision"), str) or not isinstance(row.get("reason_code"), str)
                or row.get("decision") not in {"approved", "rejected"}
                or row.get("reason_code") not in REVIEW_REASONS
                or (row["decision"] == "approved") != (row["evidence_id"] in approved)):
            raise ReviewContractError("REVIEW_DECISIONS_INVALID")
        if result.get("schema_version") in {"sciassistant.evidence-review/v3", "sciassistant.evidence-review/v4", "sciassistant.evidence-review/v5"}:
            related = row.get("group_ids")
            if (not isinstance(row.get("detail"), str) or not 1 <= len(row["detail"].strip()) <= 600
                    or not isinstance(related, list) or any(not isinstance(key, str) for key in related)
                    or not set(related).issubset(groups) or len(set(related)) != len(related)
                    or (row["decision"] == "approved" and not related)
                    or (row["decision"] == "approved") != (row["reason_code"] == "SUPPORTED")
                    or row["reason_code"] == "REASON_NOT_PROVIDED"):
                raise ReviewContractError("REVIEW_DECISION_REASON_INVALID")
        if result.get("schema_version") in {"sciassistant.evidence-review/v4", "sciassistant.evidence-review/v5"}:
            if row.get("task_relevance") not in {"direct_task_evidence", "adjacent_context", "unrelated"}:
                raise ReviewContractError("REVIEW_TASK_RELEVANCE_INVALID")
            if row["decision"] == "approved" and row["task_relevance"] == "unrelated":
                raise ReviewContractError("REVIEW_UNRELATED_EVIDENCE_APPROVED")
        if (result.get("schema_version") == "sciassistant.evidence-review/v5"
                and "source_domain" in row and (not isinstance(row["source_domain"], str) or len(row["source_domain"].strip()) > 80)):
            raise ReviewContractError("REVIEW_SOURCE_DOMAIN_INVALID")
        if (result.get("schema_version") == "sciassistant.evidence-review/v5"
                and row["decision"] == "approved" and row.get("task_relevance") == "adjacent_context"
                and (not isinstance(row.get("source_domain"), str) or not 1 <= len(row["source_domain"].strip()) <= 80)):
            raise ReviewContractError("REVIEW_SOURCE_DOMAIN_MISSING")
        if 'task_side_roles' in row:
            from multi_agent_quality import TASK_SIDE_ROLES
            roles = row['task_side_roles']
            if (not isinstance(roles, list) or len(roles) > len(TASK_SIDE_ROLES)
                    or any(not isinstance(role, str) or role not in TASK_SIDE_ROLES for role in roles)
                    or len(set(roles)) != len(roles) or (row['decision'] == 'approved' and not roles)):
                raise ReviewContractError('REVIEW_TASK_SIDE_ROLES_INVALID')
        by_id[row["evidence_id"]] = {key: row[key] for key in ("evidence_id", "decision", "reason_code", "detail", "group_ids", "task_relevance", "source_domain", "task_side_roles") if key in row}
    if result.get("schema_version") in {"sciassistant.evidence-review/v3", "sciassistant.evidence-review/v4", "sciassistant.evidence-review/v5"} and set(by_id) != ids:
        raise ReviewContractError("REVIEW_DECISIONS_INCOMPLETE")
    result["decisions"] = [by_id.get(item["evidence_id"], {
        "evidence_id": item["evidence_id"], "decision": "approved" if item["evidence_id"] in approved else "rejected",
        "reason_code": "SUPPORTED" if item["evidence_id"] in approved else "REASON_NOT_PROVIDED",
    }) for item in evidence["evidence"]]
    if result.get("schema_version") in {"sciassistant.evidence-review/v4", "sciassistant.evidence-review/v5"}:
        for row in coverage:
            if row["status"] == "direct" and row.get("evidence_ids") and all(
                    by_id[key]["task_relevance"] == "adjacent_context" for key in row["evidence_ids"]):
                row["status"] = "indirect"
                row["recommended_action"] = "qualified_answer"
                if result["coverage_status"] == "sufficient":
                    result["coverage_status"] = "partial"
    if "premise_assessments" in result or (plan or {}).get("premise_checks"):
        assessment = checked_premise_assessments(result, plan or {}, evidence)
        result["premise_assessments"] = assessment["assessments"]
        result["premise_assessment_validation"] = assessment
    return result


def recover_review_subset(review, evidence, groups, *, plan=None):
    """Isolate bad decisions; never manufacture approval or positive coverage.

    Called only on a checksummed, role-bound artifact after one correction.
    Old review schemas and untrustworthy top-level fields cannot be salvaged.
    """
    if (review.get("schema_version") not in {"sciassistant.evidence-review/v3", "sciassistant.evidence-review/v4", "sciassistant.evidence-review/v5"}
            or review.get("coverage_status") not in {"sufficient", "partial", "insufficient", "needs_review"}
            or not isinstance(review.get("allowed_evidence_ids"), list)
            or any(not isinstance(key, str) for key in review["allowed_evidence_ids"])
            or not isinstance(review.get("decisions"), list) or len(review["decisions"]) > 24
            or not isinstance(review.get("coverage", []), list)
            or len(review.get("coverage", [])) > 30
            or not isinstance(review.get("conflicts", []), list)):
        raise ReviewContractError("REVIEW_RECOVERY_UNTRUSTED")
    sources = {row["evidence_id"]: row for row in evidence["evidence"]}
    if len(sources) != len(evidence["evidence"]):
        raise ReviewContractError("REVIEW_RECOVERY_UNTRUSTED")
    allowed = set(review["allowed_evidence_ids"])
    grouped, rejected_rows, normalizations = {}, [], []
    for original in review["decisions"]:
        if not isinstance(original, Mapping) or not isinstance(original.get("evidence_id"), str):
            rejected_rows.append({"reason_code": "INVALID_DECISION_ROW"})
            continue
        grouped.setdefault(original["evidence_id"], []).append(dict(original))
    valid = []
    quarantined = set(allowed - sources.keys())
    for key, rows in grouped.items():
        if key not in sources or any(row != rows[0] for row in rows):
            quarantined.add(key)
            continue
        if len(rows) > 1:
            normalizations.append({"evidence_id": key, "action": "deduplicate_identical", "original_count": len(rows)})
        row = rows[0]
        # detail/reason/decision/group_ids are REQUIRED support assessments.
        candidate = {"schema_version": review["schema_version"], "coverage_status": "partial",
                     "allowed_evidence_ids": [key] if key in allowed else [],
                     "coverage": [], "conflicts": [], "decisions": [row]}
        try:
            checked = check_review(candidate, {"evidence": [sources[key]]}, groups)
            source_groups = set(sources[key].get("group_ids") or [sources[key].get("group_id")]) - {None}
            # v5 permits semantic association with any already planned topic.
            # Retrieval group IDs remain provenance, not the meaning of a paper.
            # Legacy recovery policy is unchanged for historical artifacts.
            if (review.get("schema_version") != "sciassistant.evidence-review/v5"
                    and source_groups and not set(row.get("group_ids", [])).issubset(source_groups)):
                raise ReviewContractError("REVIEW_GROUP_ASSOCIATION_INVALID")
            valid.extend(checked["decisions"])
        except ReviewContractError:
            quarantined.add(key)
    quarantined |= sources.keys() - {r["evidence_id"] for r in valid}
    keep = {r["evidence_id"] for r in valid if r["decision"] == "approved"}
    subset = {**evidence, "evidence": [row for row in evidence["evidence"] if row["evidence_id"] not in quarantined]}
    recovered = {"schema_version": review["schema_version"], "coverage_status": review["coverage_status"],
                 "allowed_evidence_ids": sorted(keep), "decisions": valid,
                 "coverage": [], "conflicts": review.get("conflicts", [])}
    bad_coverage = []
    for index, row in enumerate(review.get("coverage", [])):
        try:
            check_review({**recovered, "coverage": [row]}, subset, groups)
            recovered["coverage"].append(dict(row))
        except (ReviewContractError, TypeError):
            bad_coverage.append(index)
    unresolved = bool(quarantined or rejected_rows or bad_coverage)
    if unresolved:
        recovered["coverage_status"] = "needs_review" if keep else "insufficient"
    recovered = check_review(recovered, subset, groups, plan=plan)
    if unresolved:
        recovered.update(recovery_status="subset", recovery_notice=
                         "审查未完整完成：仅使用逐条校验合格的批准证据；隔离项及无效覆盖结论不用于正文，尚有疑点需复核。")
        # Quarantined rows are gaps, not positive coverage or invented rejections.
        for group in sorted(groups):
            if any(group in (sources[key].get("group_ids") or [sources[key].get("group_id")]) for key in quarantined if key in sources):
                recovered["coverage"].append({"gap_id": f"{group}-review-quarantine", "group_id": group,
                    "metric": "unreviewed_evidence", "status": "missing", "evidence_ids": [],
                    "comparability": "unknown", "recommended_action": "targeted_search"})
        if len(recovered["coverage"]) > 30:
            raise ReviewContractError("REVIEW_COVERAGE_MATRIX_INVALID")
    recovered["reviewed_evidence_ids"] = sorted({r["evidence_id"] for r in valid})
    report = {"schema_version": "sciassistant.validation-report/v1", "stage": "reviewer",
              "policy": "reviewer-subset-recovery/v1",
              "topic_association_policy": ("planned-topics-semantic-review/v1" if review.get("schema_version") == "sciassistant.evidence-review/v5"
                                           else "retrieval-groups-only/v1"), "retained_evidence_ids": sorted(keep),
              "quarantined_evidence_ids": sorted(quarantined), "invalid_row_count": len(rejected_rows),
              "quarantined_coverage_indices": bad_coverage, "normalizations": normalizations,
              "unresolved": unresolved, "semantic_auto_approval": False}
    return recovered, report


def _reported_quantities(text: str) -> set[tuple[Decimal, str]]:
    """Normalize printed multiplier notation, not metric semantics.

    PDF extraction commonly uses ``2.51x`` while Chinese reports use ``2.51×``.
    Token matching also prevents accepting 12% merely because 112% occurs.
    The semantic Auditor still checks the metric, baseline and conditions.
    """
    normalized = text.replace("％", "%")
    quantities = set()
    for match in re.finditer(r"(?<![\d.])(\d+(?:\.\d+)?)\s*(%|×|[xX](?![a-z]))", normalized):
        number, unit = match.groups()
        # 256x256 pixels / 32×32×3 tensors are products or dimensions,
        # not a claim of a 256-fold improvement. Only classify printed
        # percentage and standalone multiplier notation here; the semantic
        # Auditor still checks dimensions, experiments and actual metrics.
        if unit != "%" and re.match(r"\s*\d", normalized[match.end():]):
            continue
        quantities.add((Decimal(number), "%" if unit == "%" else "multiplier"))
    return quantities


def _reported_item_counts(text, *, modifiers=False):
    """Only explicit numeric item counts, not formulas, page IDs or dimensions."""
    pattern = r"(?<![A-Za-z0-9_.%×])(\d+(?:[,\s]\d{3})*)"
    if modifiers:
        # Only normalize PDF word wrapping for numeric matching, never quotes.
        text = re.sub(r'(?<=[A-Za-z])-\s+(?=[a-z])', '', text)
    modifier = (r'|randomly\s+(?:chosen|selected|sampled)|random|independent'
                if modifiers else '')
    noun = re.compile(r"^\s*(?:(?:AI[- ]generated|real|synthetic|training|test|and|or" + modifier +
                      r")\s+|\d+(?:[,\s]\d{3})*\s+){0,8}(?:张|个样本|条样本|幅|samples?\b|images?\b)", re.I)
    return {(Decimal(re.sub(r"[,\s]", "", match[1])), "item_count")
            for match in re.finditer(pattern, text)
            if not re.search(r"\d\s*[x×]\s*$", text[:match.start()])
            and noun.match(text[match.end():match.end()+120])}


def quantity_feedback(claim, available, *, include_counts=False, include_printed=True, count_modifiers=False):
    """Locate unsupported printed quantities; candidates are not citations or proof.

    Keep the source-token test unchanged. In particular, do not silently derive
    80% from a printed 20%, or borrow an uncited packet's 85% as support.
    """
    ids = claim.get("evidence_ids") or []
    def parsed_quantities(text):
        return (_reported_quantities(text) if include_printed else set()) | (_reported_item_counts(text, modifiers=count_modifiers) if include_counts else set())
    supported = set().union(*(parsed_quantities(str(available[key].get("excerpt") or ""))
                              for key in ids if key in available))
    errors = []
    for field in ("text", "scope_note", "qualification"):
        missing = parsed_quantities(str(claim.get(field) or "")) - supported
        if not missing:
            continue
        quantities = []
        for value, unit in sorted(missing):
            candidates = sorted(key for key, item in available.items()
                if key not in ids and item.get("review_status") == "approved"
                and (value, unit) in parsed_quantities(str(item.get("excerpt") or "")))[:8]
            quantities.append({"value": format(value, "f"), "unit": unit,
                               "candidate_evidence_ids": candidates})
        errors.append({"field": field, "unsupported_quantities": quantities})
    if not errors:
        return None
    return {"claim_id": claim.get("claim_id"), "reason": "UNSUPPORTED_NUMBER",
            "feedback_policy": QUANTITY_FEEDBACK_POLICY, "field_errors": errors,
            "cited_evidence_ids": list(ids), "automatic_citation_repair": False,
            "detail": "原文数字匹配失败，不代表算术已被证明错误。核对具体字段；可删除非必要推导，"
                      "或由Writer核对候选原文后补正确引用。候选仅有同数值，不证明指标/实验一致；不得自动批准。"}


def actionable_review_gaps(review, *, include_qualified=False):
    """A validated, supported qualified answer does not need blind re-search."""
    current = review.get("schema_version") == "sciassistant.evidence-review/v5"
    approved = set(review.get("allowed_evidence_ids", []))
    return [row for row in review.get("coverage", []) if row.get("status") in {"missing", "partial"}
            and not (not include_qualified and current and row["status"] == "partial" and row.get("recommended_action") == "qualified_answer"
                     and row.get("evidence_ids") and set(row["evidence_ids"]).issubset(approved))]


GAP_SELECTION_POLICY = 'uncovered-topics-first-one-target-per-topic/v1'


def select_recovery_targets(missing, review, plan):
    """Bounded fair scheduling, not source approval or permission expansion."""
    order = {group['id']: i for i, group in enumerate(plan['groups'])}
    approved = set(review.get('allowed_evidence_ids', []))
    queues = {}
    for row in missing:
        if row.get('group_id') in order and row.get('status') in {'missing', 'partial'}:
            queues.setdefault(row['group_id'], []).append(row)
    counts = {key: len({eid for row in review.get('coverage', []) if row.get('group_id') == key
                        for eid in row.get('evidence_ids', []) if eid in approved}) for key in queues}
    for key, rows in queues.items():
        rows.sort(key=lambda row: (row.get('status') != 'missing', bool(row.get('evidence_ids'))))
    group_order = sorted(queues, key=lambda key: (counts[key] > 0,
        queues[key][0].get('status') != 'missing', order[key]))
    selected = []
    for depth in range(max((len(rows) for rows in queues.values()), default=0)):
        for key in group_order:
            if depth < len(queues[key]):
                selected.append(queues[key][depth])
                if len(selected) == 2:
                    return selected
    return selected


def validate_gap_plan(gap, targets, original_queries):
    """Validate the ticket's bounded targets, not every partial row in the review.

    A rejected optional plan is not permission to execute its valid-looking
    subset. Legacy reviews without metric/ID fields keep their old group scope.
    """
    issues = []
    rows = gap.get("gaps") if isinstance(gap, Mapping) else None
    if isinstance(gap, Mapping) and gap.get("schema_version") not in (None, "sciassistant.gap-search-plan/v1"):
        issues.append({"reason_code": "GAP_PLAN_SCHEMA_INVALID"})
    if not isinstance(rows, list) or not 1 <= len(rows) <= 2:
        issues.append({"reason_code": "GAP_PLAN_SIZE_INVALID"})
    else:
        seen = set()
        for index, row in enumerate(rows):
            code = None
            if not isinstance(row, Mapping) or set(row) - {"gap_id", "group_id", "metric", "query"}:
                code = "GAP_PLAN_FIELDS_INVALID"
            elif (not isinstance(row.get("group_id"), str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", row["group_id"])
                    or (row.get("gap_id") is not None and (not isinstance(row["gap_id"], str)
                        or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", row["gap_id"])))
                    or (row.get("metric") is not None and (not isinstance(row["metric"], str)
                        or not 1 <= len(row["metric"].strip()) <= 100))):
                code = "GAP_PLAN_FIELDS_INVALID"
            elif not any(row.get("group_id") == target["group_id"]
                    and (not target.get("gap_id") or row.get("gap_id") == target["gap_id"])
                    and (not target.get("metric") or row.get("metric") == target["metric"])
                    for target in targets):
                code = "GAP_TARGET_OUTSIDE_TICKET"
            elif not isinstance(row.get("query"), str) or not 1 <= len(row["query"].strip()) <= 500:
                code = "GAP_QUERY_INVALID"
            elif row["query"].strip().casefold() in original_queries:
                code = "GAP_QUERY_REPEATED"
            else:
                key = (row.get("gap_id"), row["group_id"], row.get("metric"))
                if key in seen:
                    code = "GAP_TARGET_DUPLICATED"
                seen.add(key)
            if code:
                issues.append({"row_index": index, "reason_code": code})
    return {"schema_version": "sciassistant.validation-report/v1", "stage": "gap_plan",
            "valid": not issues, "reason_code": "GAP_PLAN_REJECTED" if issues else None,
            "issues": issues, "action_count": len(rows) if isinstance(rows, list) else 0,
            "recovery_action": "keep_prior_review_no_new_evidence_no_network" if issues else "execute_validated_gap_plan"}


def blocked_retrieval_reason(evidence: Mapping[str, Any]) -> str | None:
    """No completed search is not a scientific absence-of-evidence verdict.

    Never discard usable packets, or suppress recovery after a genuine empty
    successful search. Classify only an entirely blocked initial retrieval.
    """
    if evidence.get("evidence"):
        return None
    statuses = [row.get("source_status") for row in evidence.get("observations", []) if "query" in row]
    blocked = {"source_unreachable", "rate_limited", "cooldown_skipped", "deadline_skipped"}
    if not statuses or any(status not in blocked for status in statuses):
        return None
    if any(status in {"rate_limited", "cooldown_skipped"} for status in statuses):
        return "RETRIEVAL_SOURCE_RATE_LIMITED"
    if all(status == "deadline_skipped" for status in statuses):
        return "RETRIEVAL_SOURCE_DEADLINE"
    return "RETRIEVAL_SOURCE_UNREACHABLE"


def check_draft(draft: Mapping[str, Any], evidence: Mapping[str, Any], *, require_summary: bool = False) -> list[dict]:
    """Code-owned citation checks supplement the model's semantic audit."""
    failures = check_passage_exclusivity(draft, evidence) + assertion_issues(draft)
    from multi_agent_quality import DETAIL_CITATION_POLICY, FIELD_QUANTITY_POLICY, PREVIOUS_FIELD_QUANTITY_POLICY, check_field_citations
    if draft.get("detail_citation_policy") == DETAIL_CITATION_POLICY:
        failures.extend(check_field_citations(draft, evidence))
    available = {item["evidence_id"]: item for item in evidence["evidence"]}
    claims = draft.get("claims") or []
    seen = set()
    from multi_agent_quality import DRAFT_SCHEMA, MODERN_DRAFT_SCHEMAS, claim_scope
    if not draft.get("direct_answer") or not isinstance(claims, list) or not claims or len(claims) > 80:
        return [{"claim_id": "draft", "reason": "MISSING_CLAIMS_OR_ANSWER"}]
    for claim in claims:
        if not isinstance(claim, Mapping):
            failures.append({"claim_id": "draft", "reason": "INVALID_CLAIM"})
            continue
        claim_id = str(claim.get("claim_id") or "")
        if draft.get("schema_version") in MODERN_DRAFT_SCHEMAS and (
                not isinstance(claim.get("scope_note"), str) or len(claim["scope_note"]) > 600
                or not isinstance(claim.get("qualification", ""), str)
                or len(claim.get("qualification", "")) > 4_000):
            failures.append({"claim_id": claim_id or "draft", "reason": "INVALID_CLAIM_SCOPE"})
        if claim.get("section", "topic_analysis") not in {"direct_conclusion", "topic_analysis", "synthesis", "evidence_boundary"}:
            failures.append({"claim_id": claim_id or "draft", "reason": "INVALID_REPORT_SECTION"})
        ids = claim.get("evidence_ids") or []
        if not claim_id or claim_id in seen or not isinstance(ids, list) or not ids or not set(ids).issubset(available):
            failures.append({"claim_id": claim_id or "draft", "reason": "UNAPPROVED_CITATION"})
        seen.add(claim_id)
        dependencies = claim.get("depends_on_claim_ids", [])
        all_ids = {c["claim_id"] for c in claims if isinstance(c, Mapping) and isinstance(c.get("claim_id"), str)}
        if (not isinstance(dependencies, list) or any(not isinstance(key, str) for key in dependencies)
                or not set(dependencies).issubset(all_ids) or claim_id in dependencies):
            failures.append({"claim_id": claim_id or "draft", "reason": "INVALID_CLAIM_DEPENDENCY"})
        if ids and all(key in available for key in ids) and all(weak_evidence(available[key]) for key in ids):
            if claim.get("confidence") != "low":
                failures.append({"claim_id": claim_id, "reason": "WEAK_EVIDENCE_CONFIDENCE"})
        all_fields = draft.get("field_quantity_policy") in {FIELD_QUANTITY_POLICY, PREVIOUS_FIELD_QUANTITY_POLICY}
        if claim.get("claim_type") == "quantitative" or all_fields:
            # Preserve field/packet boundaries: "2×" followed by a separate
            # "256x256 images" note must not become a synthetic product.
            issue = quantity_feedback(claim, available, include_counts=all_fields,
                                      include_printed=claim.get("claim_type") == "quantitative",
                                      count_modifiers=draft.get('field_quantity_policy') == FIELD_QUANTITY_POLICY)
            if issue:
                failures.append(issue if draft.get("quantity_feedback_policy") == QUANTITY_FEEDBACK_POLICY
                                else {"claim_id": claim_id, "reason": "UNSUPPORTED_NUMBER"})
        cited = [available[key] for key in ids if key in available]
        if not (claim.get("claim_type") == "limitation" and claim.get("section") == "evidence_boundary"):
            visible = str(claim.get("text") or "") + " " + claim_scope(draft, claim)
            hidden_domains = sorted({item["source_domain"].strip() for item in cited
                if item.get("source_scope_policy") == "reviewer-v5-visible-domain/v1"
                and item.get("task_relevance") == "adjacent_context" and item.get("source_domain")
                and item["source_domain"].strip() not in visible})
            if hidden_domains:
                failures.append({"claim_id": claim_id, "reason": "SOURCE_DOMAIN_NOT_VISIBLE",
                                 "required_source_domains": hidden_domains})
        if cited and all(item.get("task_relevance") == "adjacent_context" for item in cited):
            if claim.get("claim_type") in {"quantitative", "comparative"}:
                failures.append({"claim_id": claim_id, "reason": "ADJACENT_EVIDENCE_NOT_TASK_RESULT"})
    graph = {c["claim_id"]: c.get("depends_on_claim_ids", []) for c in claims
             if isinstance(c, Mapping) and isinstance(c.get("claim_id"), str)}
    cycle_cache = {}
    def cyclic(key, visiting):
        if key in visiting:
            return True
        if key in cycle_cache:
            return cycle_cache[key]
        edges = graph.get(key, [])
        cycle_cache[key] = isinstance(edges, list) and any(isinstance(e, str) and cyclic(e, visiting | {key}) for e in edges)
        return cycle_cache[key]
    for key in graph:
        if cyclic(key, set()) and not any(r["claim_id"] == key and r["reason"] == "INVALID_CLAIM_DEPENDENCY" for r in failures):
            failures.append({"claim_id": key, "reason": "INVALID_CLAIM_DEPENDENCY"})
    # New runs opt into the source-backed regression policy. Historical replay
    # must not reinterpret old publication decisions using a newly added rule.
    if draft.get("semantic_boundary_policy") == SEMANTIC_BOUNDARY_POLICY:
        failures.extend(check_semantic_boundaries(draft, evidence))
    if draft.get("reading_scope_policy") == READING_SCOPE_POLICY:
        failures.extend(check_reading_scope(draft, evidence))
    from multi_agent_quality import LEGACY_METRIC_DIRECTION_POLICY, PREVIOUS_METRIC_DIRECTION_POLICY, COORDINATED_METRIC_DIRECTION_POLICY, NEGATION_METRIC_DIRECTION_POLICY
    if draft.get("metric_direction_policy") in {METRIC_DIRECTION_POLICY, NEGATION_METRIC_DIRECTION_POLICY, COORDINATED_METRIC_DIRECTION_POLICY, PRINTED_METRIC_DIRECTION_POLICY, PREVIOUS_METRIC_DIRECTION_POLICY, LEGACY_METRIC_DIRECTION_POLICY}:
        failures.extend(check_metric_direction(draft, evidence, policy=draft['metric_direction_policy']))
    failures.extend(check_rank_table_trends(draft, evidence))
    if draft.get("evaluation_role_policy") == EVALUATION_ROLE_POLICY:
        failures.extend(check_evaluation_roles(draft, evidence))
    if draft.get("memory_component_policy") == MEMORY_COMPONENT_POLICY:
        failures.extend(check_memory_component_scope(draft, evidence))
    if draft.get("symbol_role_policy") == SYMBOL_ROLE_POLICY:
        failures.extend(check_symbol_roles(draft, evidence))
    if draft.get("condition_denial_policy") == CONDITION_DENIAL_POLICY:
        failures.extend(check_condition_denials(draft, evidence))
    failures.extend(check_printed_type_denials(draft, evidence))
    failures.extend(check_term_family_aliases(draft, evidence))
    if require_summary and not any(isinstance(c, Mapping) and c.get("section") == "direct_conclusion"
                                   and c.get("text") and c.get("evidence_ids") for c in claims):
        failures.append({"claim_id": "report_summary", "reason": "MISSING_TOP_LEVEL_CONCLUSION"})
    if draft.get('composition_policy') == SECTION_POLICY:
        failures.extend(writer_job_issues(draft, revision_job(draft['report_outline'], evidence)))
    return failures


def render_claims(draft: Mapping[str, Any], evidence: Mapping[str, Any], *, rejected: set[str] | None = None,
                  plan: Mapping | None = None) -> str:
    """Render structured claims with deterministic citation numbering."""
    rejected = rejected or set()
    from multi_agent_quality import claim_scope
    numbering = {item["evidence_id"]: index for index, item in enumerate(report_evidence(draft, evidence, rejected), 1)}
    available = {item["evidence_id"]: item for item in evidence["evidence"]}
    paragraphs = []
    structured = (any(isinstance(claim, Mapping) and claim.get("section") for claim in draft.get("claims") or [])
                  or any(item.get("coverage_scope") in {"abstract", "selected_chunks"} for item in evidence["evidence"]))
    sections = {key: [] for key in ("direct_conclusion", "topic_analysis", "synthesis", "evidence_boundary")}
    labels = {group["id"]: str(group.get("heading") or group.get("question") or ", ".join(group.get("core") or []) or group["id"])[:80]
              for group in (plan or {}).get("groups") or []}
    chapter_paragraphs = {}
    for claim in draft.get("claims") or []:
        if not isinstance(claim, Mapping) or claim.get("claim_id") in rejected:
            continue
        text = str(claim.get("text") or "").strip()
        if not text:
            continue
        text = re.sub(r"\[\d+(?:,\s*p\.\s*\d+)?\]", "", text).strip()
        markers = "".join(f"[{numbering[key]}]" for key in claim.get("evidence_ids") or [] if key in numbering)
        scope = re.sub(r"\[\d+(?:,\s*p\.\s*\d+)?\]", "", claim_scope(draft, claim)).strip()
        compact_cautions = draft.get('answer_style_policy') == ANSWER_STYLE_POLICY
        # Only remove a literally identical complete scope field, not a hedge
        # inferred to be unnecessary. The original audited fields stay intact.
        duplicate_scope = compact_cautions and scope == text
        paragraph = f"{text}" + (f" {scope}" if scope and not duplicate_scope else "") + markers
        cited = [available[key] for key in claim.get("evidence_ids") or [] if key in available]
        if cited and all(weak_evidence(item) for item in cited):
            badge = '摘要级依据' if all(evidence_strength(item) == 'abstract_only' for item in cited) else '含未定位原文依据'
            paragraph += (f"（{badge}）" if compact_cautions else "（" + "；".join(dict.fromkeys(evidence_label(item) for item in cited)) + "；仅作低置信度线索，不是已核验的全文实验结论。）")
        if draft.get('assertion_policy') == ASSERTION_POLICY and claim.get('assertion_mode') in {'synthesis', 'proposal', 'attributed_interpretation'}:
            paragraph = '【' + ASSERTION_MODES[claim['assertion_mode']] + '】' + paragraph
        paragraphs.append(paragraph)
        chapter_paragraphs.setdefault(claim.get('report_section_id'), []).append(paragraph)
        section = claim.get("section", "topic_analysis")
        if section in sections:
            sections[section].append((claim.get("group_id"), paragraph))
    if paragraphs:
        if draft.get('composition_policy') in SECTION_POLICIES:
            output = []
            for chapter in draft['report_outline']['sections']:
                output.append('### ' + chapter['title'].replace('\n', ' '))
                output.extend(chapter_paragraphs.get(chapter['section_id']) or [
                    '本节尚未形成通过审查的内容；不将规划安排或草稿中的内容计为已经回答。'])
            return '\n\n'.join(output)
        if structured:
            output = []
            if not sections["direct_conclusion"]:
                # Never publish the model's unaudited direct_answer as a summary.
                # Reuse at most one already-audited claim per topic, verbatim.
                output = ["### 直接回答", "尚未形成通过审计的顶层结论。以下仅摘录已通过审计的分项发现，不代表完整回答，也不能据此直接比较不同实验的性能数字。"]
                seen_groups = set()
                for group_id, paragraph in sections["topic_analysis"]:
                    if group_id not in seen_groups and len(seen_groups) < 3:
                        output.append(paragraph)
                        seen_groups.add(group_id)
            titles = {"direct_conclusion": "直接回答", "topic_analysis": "分项分析",
                      "synthesis": "综合判断", "evidence_boundary": "证据边界"}
            for section, items in sections.items():
                if not items:
                    continue
                output.append("### " + titles[section])
                if section == "topic_analysis":
                    grouped = {}
                    for group_id, paragraph in items:
                        grouped.setdefault(group_id, []).append(paragraph)
                    for group_id, content in grouped.items():
                        if group_id in labels:
                            output.append("#### " + labels[group_id].replace("\n", " "))
                        output.extend(content)
                else:
                    output.extend(paragraph for _, paragraph in items)
            return "\n\n".join(output)
        return "\n\n".join(paragraphs)
    if rejected:
        return "已有部分资料可供查看，但本轮回答的引用未能通过审计，无法给出可靠的定量或比较结论。"
    return str(draft.get("direct_answer") or "").strip()


def render_approved_evidence_fallback(evidence: Mapping[str, Any], *, limit: int = 6) -> str:
    """Render a conservative local-document fallback when every claim is isolated.

    This is deliberately an evidence digest, not a synthesized answer: it only
    repeats reviewer-approved excerpts and their locators.  It prevents a
    successful PDF parse/review from becoming an opaque ``failed`` result while
    keeping every rejected Writer claim unpublished.
    """
    rows = [row for row in evidence.get("evidence", [])
            if isinstance(row, Mapping) and str(row.get("excerpt") or row.get("text") or "").strip()]
    if not rows:
        return ""
    paragraphs = [
        "已读取并审查了上传文档，但本轮生成的综合声明均未通过完整引用审查。",
        "下面仅列出已批准原文片段的事实摘要，不把它们拼接成新的科研结论；请结合原文位置人工复核。",
    ]
    for index, row in enumerate(rows[:limit], 1):
        text = re.sub(r"\s+", " ", str(row.get("excerpt") or row.get("text") or "")).strip()
        if len(text) > 700:
            text = text[:700].rstrip() + "…"
        locator = row.get("locator") or {}
        page = locator.get("page") if isinstance(locator, Mapping) else None
        title = str(row.get("title") or row.get("paper_id") or "上传文档")
        suffix = f"（{title}，第 {page} 页）" if page else f"（{title}）"
        paragraphs.append(f"原文片段 {index}：{text} {suffix}")
    return "\n\n".join(paragraphs)


class LiteraturePipelineV2:
    """Explicit state machine with one shared monotonic deadline and bounded rework."""

    GENERAL_FALLBACK_FAILURE_CODES = frozenset({
        "INSUFFICIENT_EVIDENCE", "NO_AUDITED_CLAIMS", "MODEL_SCHEMA_REJECTED",
        "MODEL_JSON_INVALID", "RETRIEVAL_SOURCE_UNREACHABLE",
        "RETRIEVAL_SOURCE_RATE_LIMITED", "RETRIEVAL_SOURCE_DEADLINE",
        "LOCAL_PDF_PARSE_FAILED", "LOCAL_PDF_TEXT_EMPTY", "LOCAL_PDF_READ_FAILED",
    })

    def __init__(self, store: WorkflowStore, artifacts: ArtifactDirectory, agents: PipelineAgents,
                 executor: DeterministicLiteratureExecutor, *, event_path: str | Path | None = None,
                 time_budget_seconds: int | None = None, configuration_fingerprint: str = "default-v2",
                 time_policy: str = "hard-deadline/v1", initialization_elapsed_seconds: float = 0,
                 report_profile: str = 'standard', general_fallback=None):
        self.store, self.artifacts, self.agents, self.executor = store, artifacts, agents, executor
        self.general_fallback = general_fallback
        self.event_path = Path(event_path) if event_path else None
        self.report_config = report_budget(report_profile, time_budget=time_budget_seconds)
        self.time_budget_seconds = self.report_config['time_budget_seconds']
        self.configuration_fingerprint = configuration_fingerprint
        if time_policy != 'hard-deadline/v1' and not is_soft_time_policy(time_policy):
            raise WorkflowError("invalid time policy")
        self.time_policy = time_policy
        self.initialization_elapsed_seconds = max(0.0, initialization_elapsed_seconds)
        self.research_started_at = 0.0
        self.deadline = 0.0
        self.stage_usage = []
        self.reading_stop_reason = "not_started"
        self.planner_format_retry_used = False
        self.retriever_format_retry_used = False
        self.reviewer_format_retry_used = False
        self.audit_protocol_retry_used = False
        self.writer_format_retry_used = False

    def _event(self, event: Mapping[str, Any]) -> None:
        event = sanitize_artifact_text(dict(event))
        if self.event_path:
            self.event_path.parent.mkdir(parents=True, exist_ok=True)
            with self.event_path.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps({"at": time.time(), **event}, ensure_ascii=False, sort_keys=True) + "\n")
            with (self.event_path.parent / "console.log").open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(dict(event), ensure_ascii=False, sort_keys=True) + "\n")

    def _active(self, run_id: str) -> None:
        if not is_soft_time_policy(self.time_policy) and time.monotonic() >= self.deadline:
            self.store.force_terminal(run_id, "timed_out", failure_code="TIME_BUDGET_EXCEEDED")
            raise WorkflowBudgetExceeded("workflow deadline exceeded")
        self.store.assert_active(run_id)

    def _stage_remaining(self):
        # A stage/request still has its own timeout; 360 is now an estimate,
        # not a deadline that can discard an in-flight research round or report.
        return float(self.report_config['duration_target_seconds']) if is_soft_time_policy(self.time_policy) else self.deadline - time.monotonic()

    def _research_elapsed(self):
        return max(0.0, time.monotonic() - self.research_started_at)

    def _invoke(self, run_id: str, role: str, goal: str, input_ids: Sequence[str]) -> tuple[dict, dict]:
        self._active(run_id)
        bundle = skill_bundle(role, getattr(self, '_skill_ledger', None),
            revision=bool(getattr(self, '_revision_active', False)))
        if bundle['skills']:
            skill_ref = self.artifacts.put('business-skill-load', bundle)['artifact_id']
            input_ids = list(dict.fromkeys([*input_ids, skill_ref]))
            if hasattr(self, '_skill_load_records'):
                self._skill_load_records.append({'agent_role': role, 'artifact_id': skill_ref,
                    'bundle_sha256': bundle['bundle_sha256'], 'skill_ids': [s['skill_id'] for s in bundle['skills']]})
                self._run_refs['skill_loads'] = self.artifacts.put('business-skill-loads', {
                    'schema_version': 'sciassistant.business-skill-loads/v1', 'policy': SKILL_POLICY,
                    'catalog': skill_catalog(), 'loads': list(self._skill_load_records),
                    'permissions_expanded': False})['artifact_id']
            self._event({'event': 'business_skills_loaded', 'role': role, 'artifact_id': skill_ref,
                'skill_ids': [s['skill_id'] for s in bundle['skills']], 'bundle_sha256': bundle['bundle_sha256']})
        if getattr(self, "source_context_ref", None):
            input_ids = list(dict.fromkeys([*input_ids, self.source_context_ref]))
        if role in {'reviewer','gap_analyst','writer','citation_auditor'} and getattr(self, 'answer_focus_ref', None):
            input_ids = list(dict.fromkeys([*input_ids, self.answer_focus_ref]))
        if role != 'planner' and getattr(self, 'user_requirements_ref', None):
            input_ids = list(dict.fromkeys([*input_ids, self.user_requirements_ref]))
        if role in {'retriever', 'reviewer', 'gap_analyst', 'writer'} and getattr(self, 'need_contract_ref', None):
            input_ids = list(dict.fromkeys([*input_ids, self.need_contract_ref]))
        if role == 'writer' and getattr(self, 'need_flow_ref', None):
            input_ids = list(dict.fromkeys([*input_ids, self.need_flow_ref]))
        if role == 'writer' and getattr(self, 'comparison_ref', None):
            if not getattr(self, 'writer_job_ref', None):
                input_ids = list(dict.fromkeys([*input_ids, self.comparison_ref]))
        if role == 'writer' and getattr(self, 'writer_job_ref', None):
            input_ids = list(dict.fromkeys([*input_ids, self.writer_job_ref]))
        if role == "reviewer":
            supplied = [self.artifacts.get(key) for key in input_ids]
            current = [row for row in supplied if str(row.get("schema_version", "")).startswith("sciassistant.evidence-set/")]
            if len(current) != 1:
                raise WorkflowError("invalid current review evidence")
            plan = next((row for key, row in zip(input_ids, supplied) if key.startswith("research-plan-")), {})
            previous = next((row for key, row in zip(input_ids, supplied) if key.startswith("evidence-review-")), {})
            targets = review_targets(current[0], plan, previous)
            target_ref = self.artifacts.put("review-targets", targets)["artifact_id"]
            input_ids = [*input_ids, target_ref]
            self._event({"event": "review_targets_prepared", "artifact_id": target_ref,
                         "current_count": len(targets["current_evidence_ids"]),
                         "new_or_previously_unapproved_count": len(targets["new_or_previously_unapproved_ids"]),
                         "prior_approved_current_count": len(targets["prior_approved_current_ids"])})
        permit = self.store.reserve_model_call(run_id, role)
        packet = make_agent_input(run_id=run_id, role=role, goal=goal, input_artifact_ids=input_ids,
                                  remaining_model_calls=permit.remaining_calls,
                                  deadline_at=time.time() + (120 if is_soft_time_policy(self.time_policy) else max(0.0, self.deadline - time.monotonic())),
                                  configuration_fingerprint=self.configuration_fingerprint,
                                  report_profile=self.report_config['report_profile'])
        packet["allowed_actions"] = sorted(self.agents.by_role(role).allowed_actions)
        self._event({"event": "agent_started", "role": role, "call_number": permit.call_number,
                     "input_artifact_ids": list(input_ids)})
        started = time.monotonic()
        try:
            result = self.agents.by_role(role).run(packet, self.artifacts)
        except AgentContractError as exc:
            # Fixed categories only: never echo a model response, query or private passage.
            reason = {"invalid tool request fields": "TOOL_REQUEST_FIELDS_INVALID",
                      "invalid tool request id": "TOOL_REQUEST_ID_INVALID",
                      "tool request is outside this worker's source scope": "TOOL_SOURCE_SCOPE_REJECTED",
                      "invalid agent result status": "AGENT_STATUS_INVALID",
                      "invalid rework ticket": "REWORK_TICKET_INVALID"}.get(str(exc), "AGENT_CONTRACT_REJECTED")
            self._event({"event": "agent_contract_rejected", "role": role,
                         "call_number": permit.call_number, "reason_code": reason})
            result = {"schema_version": "sciassistant.agent-result/v1", "status": "failed",
                      "output_artifact_ids": [], "tool_requests": [], "rework_ticket": None,
                      "usage": {"model_calls": 1, "elapsed_ms": round((time.monotonic() - started) * 1000)}, "error_code": "AGENT_CONTRACT_REJECTED"}
        result_ref = self.artifacts.put("agent-result", result)
        if self.event_path:
            directory = self.event_path.parent / "agents"
            directory.mkdir(exist_ok=True)
            (directory / f"{permit.call_number:02d}-{role}.json").write_text(json.dumps({
                "input": packet, "result_artifact_id": result_ref["artifact_id"],
            }, ensure_ascii=False, indent=2), encoding="utf-8")
        self._event({"event": "agent_finished", "role": role, "status": result["status"],
                     "usage": result["usage"], "output_artifact_ids": result["output_artifact_ids"],
                     "result_sha256": result_ref["sha256"], "configuration_fingerprint": self.configuration_fingerprint})
        self.stage_usage.append({"role": role, "call_number": permit.call_number, "status": result["status"],
                                 "error_code": result.get("error_code"),
                                 "elapsed_ms": round((time.monotonic() - started) * 1000)})
        self._active(run_id)
        if result["status"] in {"failed", "blocked"}:
            if (role == "reviewer" and result["status"] == "failed"
                    and result.get("error_code") in {"MODEL_JSON_INVALID", "MODEL_SCHEMA_REJECTED"}
                    and not any(key.startswith("evidence-review-") for key in input_ids)
                    and not self.reviewer_format_retry_used
                    and self.store.get_run(run_id)["remaining_model_calls"] >= 3
                    # One repair plus Writer and Auditor; leave their reserve.
                    and self._stage_remaining() > 130):
                self.reviewer_format_retry_used = True
                self._event({"event": "agent_format_retry", "role": role,
                             "reason_code": result["error_code"], "retry_number": 1,
                             "failed_call_number": permit.call_number})
                # Rebuild exactly one current checklist. Do not parse/approve
                # fragments from the broken response or inherit new decisions.
                retry_inputs = [key for key in input_ids if not key.startswith("review-targets-")]
                return self._invoke(run_id, role, goal +
                    "；上次JSON格式不合法。仅依据相同结构化工件重新生成完整紧凑JSON，"
                    "对每个当前Evidence ID给出决定，批准集合、决定和覆盖引用必须一致。"
                    "字符串双引号与换行须转义，不输出Markdown；可以拒绝或partial，"
                    "不得自动批准、补造证据或修补损坏回复内容。", retry_inputs)
            if (role == "planner" and result["status"] == "failed"
                    and result.get("error_code") in {"MODEL_JSON_INVALID", "MODEL_SCHEMA_REJECTED"}
                    and not self.planner_format_retry_used
                    and self.store.get_run(run_id)["remaining_model_calls"] >= 5
                    # Reserve 40s for this repair, 40s for retrieval planning,
                    # and 130s for evidence review, writing and citation audit.
                    and self._stage_remaining() > 210):
                self.planner_format_retry_used = True
                self._event({"event": "agent_format_retry", "role": role,
                             "reason_code": result["error_code"], "retry_number": 1,
                             "failed_call_number": permit.call_number})
                # The sanitized diagnostic contains only known field paths,
                # shape errors and counts/lengths, not raw provider content.
                feedback_ids = [key for key in result.get('output_artifact_ids') or []
                    if self.artifacts.get(key).get('schema_version') == 'sciassistant.model-format-diagnostic/v1']
                retry_inputs = list(dict.fromkeys([*input_ids,*feedback_ids]))
                self._event({'event':'planner_format_feedback_prepared',
                    'input_artifact_ids':feedback_ids,'raw_provider_response_included':False})
                return self._invoke(run_id, role, goal +
                    "；上次输出格式不合法。只依据相同问题和结构化工件重新生成完整、紧凑的JSON对象；"
                    "字符串里的双引号与换行必须正确转义，不输出Markdown或解释。"
                    "output.schema_version必须为sciassistant.research-plan/v7，groups为对象数组，kind区分research/report；"
                    "程序按需求原句定位自动关联输入段；可标注背景段，未分类段保留复核，不要计算字符索引或凭语义乱连段号；"
                    "每项需求复制唯一原句，填写answer_kind、research_group_ids、report_obligation_ids；不得遗漏后置要求。"
                    "research须有逐实体evidence_needs（entity可英文别名，每项question_quote须来自原问题）与1到4条query_candidates，程序编译最多2个执行查询；report不可有查询；user_statement的assumption须原样等于question_quote，不扩写用户信念。"
                    "每组core/support/metrics必须为字符串数组，不能用字典或嵌套对象代替。"
                    "查看附加model-format-diagnostic中的term_issues和handoff_issues，按具体字段路径修正类型/条目数/引文和交接字段。"
                    "合并重复规划术语、用简短metric名，保留全部用户问题，不截断或猜补科学内容。"
                    "不得增加用户未问的必答指标、工具动作或自行补造论文。", retry_inputs)
            if (role == "writer" and result["status"] == "failed"
                    and result.get("error_code") in {"MODEL_OUTPUT_TRUNCATED", "MODEL_JSON_INVALID", "MODEL_SCHEMA_REJECTED"}
                    and not self.writer_format_retry_used
                    and self.store.get_run(run_id)["remaining_model_calls"] >= max(2, getattr(self, '_writer_pending_calls', 0) + 2)
                    and self._stage_remaining() > 90):
                self.writer_format_retry_used = True
                diagnostic_ids = list(result.get('output_artifact_ids') or []) if getattr(self, 'writer_job_ref', None) else []
                self._event({"event": "writer_format_retry", "reason_code": result["error_code"],
                             "failed_call_number": permit.call_number, "retry_number": 1})
                return self._invoke(run_id, role, goal +
                    "；上次输出不完整。只依据同一批准证据重新生成有效且完整的JSON，保留全部核心回答和必要条件；"
                    "不设声明条数或正文字符上限。删除重复背景与重复说明以适应本次模型输出容量，不删关键主题，"
                    "不要补全损坏回复或增造证据，优先直接回答和覆盖关键主题。"
                    "有writer-job时须保持v4章节和需求绑定；requirement_results只是可选诊断；查看附加格式诊断的精确错误。",
                    list(dict.fromkeys([*input_ids, *diagnostic_ids])))
            # Each repair is a real, separately reserved model call. Never retry
            # HTTP failures, truncation or tool permission/contract violations.
            if (role == "retriever" and result["status"] == "failed"
                    and result.get("error_code") in {"MODEL_JSON_INVALID", "MODEL_SCHEMA_REJECTED"}
                    and not self.retriever_format_retry_used
                    and self.store.get_run(run_id)["remaining_model_calls"] >= 4
                    # Repair itself can take 40s; preserve another 130s for
                    # review, writing and audit rather than consuming their reserve.
                    and self._stage_remaining() > 170):
                self.retriever_format_retry_used = True
                self._event({"event": "agent_format_retry", "role": role,
                             "reason_code": result["error_code"], "retry_number": 1,
                             "failed_call_number": permit.call_number})
                return self._invoke(run_id, role, goal +
                    "；上次输出格式不合法。重新依据相同结构化工件生成完整JSON对象；"
                    "查询字符串中的双引号必须转义，不输出Markdown或解释。", input_ids)
            raise PipelineExecutionError(result.get("error_code") or "AGENT_EXECUTION_FAILED",
                diagnostic_artifact_ids=[key for key in result.get('output_artifact_ids') or []
                    if self.artifacts.get(key).get('schema_version') == 'sciassistant.model-format-diagnostic/v1'])
        output = self.artifacts.get(result["output_artifact_ids"][-1]) if result["output_artifact_ids"] else {}
        return result, output

    @staticmethod
    def _merge_evidence(first: Mapping[str, Any], second: Mapping[str, Any], *, retained_evidence_ids: Sequence[str] = ()) -> dict:
        combined = {}
        for item in [*(second.get("evidence") or []), *(first.get("evidence") or [])]:
            key = item["evidence_id"]
            if key in combined:
                combined[key]["group_ids"] = list(dict.fromkeys([
                    *(combined[key].get("group_ids") or [combined[key]["group_id"]]),
                    *(item.get("group_ids") or [item["group_id"]]),
                ]))
            else:
                combined[key] = dict(item)
        # An earlier approval applies to an immutable excerpt, not just an ID.
        retained = set(retained_evidence_ids)
        for item in first.get("evidence") or []:
            if item["evidence_id"] in retained:
                combined[item["evidence_id"]] = dict(item)
        # Keep already-approved sources before filling free slots with recovery.
        selected, used, selected_ids, group_counts = [], 0, set(), {}
        for item in first.get("evidence") or []:
            if item["evidence_id"] not in retained:
                continue
            cost = _token_estimate(str(item.get("excerpt") or item.get("text") or ""))
            if len(selected) >= 12 or used + cost > 12_000:
                raise WorkflowError("approved evidence cannot fit recovery context")
            selected.append(combined[item["evidence_id"]])
            selected_ids.add(item["evidence_id"])
            group_counts[item["group_id"]] = group_counts.get(item["group_id"], 0) + 1
            used += cost
        # Round-robin groups and count all selected text towards the shared context budget.
        by_group = {}
        for item in combined.values():
            by_group.setdefault(item["group_id"], []).append(item)
        for rank in range(5):
            for group in by_group.values():
                if rank >= len(group):
                    continue
                item = group[rank]
                if item["evidence_id"] in selected_ids:
                    continue
                if group_counts.get(item["group_id"], 0) >= 5:
                    continue
                cost = _token_estimate(str(item.get("excerpt") or item.get("text") or ""))
                if len(selected) < 12 and used + cost <= 12_000:
                    selected.append(item)
                    selected_ids.add(item["evidence_id"])
                    group_counts[item["group_id"]] = group_counts.get(item["group_id"], 0) + 1
                    used += cost
        observations, seen = [], set()
        for row in [*(first.get("observations") or []), *(second.get("observations") or [])]:
            key = json.dumps(row, ensure_ascii=False, sort_keys=True)
            if key not in seen:
                observations.append(row)
                seen.add(key)
        return {"schema_version": "sciassistant.evidence-set/v2", "evidence": selected,
                "observations": observations,
                **({"reading_summary": second["reading_summary"]} if "reading_summary" in second else {})}

    def _retrieve(self, run_id: str, requests: Sequence[Mapping], groups: set[str], *, recovery=False,
                  prior: Mapping | None = None, retained_evidence_ids: Sequence[str] = (), reading_only=False,
                  focus_groups: set[str] | None = None) -> dict:
        def progress(snapshot):
            self._active(run_id)
            merged = self._merge_evidence(prior or {}, snapshot, retained_evidence_ids=retained_evidence_ids)
            ref = self.artifacts.put("evidence-set", merged)
            if self.event_path:
                directory = self.event_path.parent / "tools"
                directory.mkdir(exist_ok=True)
                observation = sanitize_artifact_text(snapshot["observations"][-1]) if snapshot["observations"] else {"source_status": "no_actions"}
                filename = f"query-{len(merged.get('observations') or []):03d}-{'recovery' if recovery else 'initial'}.json"
                (directory / filename).write_text(json.dumps({"observation": observation, "artifact_id": ref["artifact_id"],
                                                               "sha256": ref["sha256"]}, ensure_ascii=False), encoding="utf-8")
            last = snapshot["observations"][-1] if snapshot["observations"] else {"source_status": "no_actions"}
            event = "retrieval_query" if "query" in last else "literature_reading"
            self.store.record_event(run_id, event, "completed", {
                "evidence_count": len(merged["evidence"]), "artifact_id": ref["artifact_id"],
                "public_progress": {**snapshot.get("reading_summary", {}),
                                    "phase": last.get("phase", last.get("source_status", "retrieving")),
                                    "queries_finished": len([r for r in snapshot["observations"] if "query" in r])},
            })
            self._event({"event": event, "artifact_id": ref["artifact_id"], **last})
        # A final review can use 40s; Writer + Auditor retain another 90s.
        reserve = min(130.0, self.time_budget_seconds / 2)
        started = time.monotonic()
        stage_deadline = time.monotonic() + 180 if is_soft_time_policy(self.time_policy) else self.deadline - reserve
        if reading_only:
            result = self.executor.continue_reading(deadline=stage_deadline, progress=progress, focus_groups=focus_groups)
        else:
            result = self.executor.execute(requests, recovery=recovery, group_ids=groups,
                                           deadline=stage_deadline, progress=progress)
        self.stage_usage.append({"stage": "reading_batch" if reading_only else "retrieval", "recovery": recovery,
                                 "elapsed_ms": round((time.monotonic() - started) * 1000)})
        self._active(run_id)
        return self._merge_evidence(prior or {}, result, retained_evidence_ids=retained_evidence_ids)

    def _validated_followup_review(self, run_id, review, previous, evidence, groups, plan, refs):
        try:
            return check_review(review, evidence, groups, plan=plan)
        except ReviewContractError as exc:
            refs["rejected_recovery_review"] = self.artifacts.put("rejected-evidence-review", review)["artifact_id"]
            self._event({"event": "recovery_review_rejected", "reason_code": exc.code,
                         "retained_approved_count": len(previous["allowed_evidence_ids"])})
            if review.get("schema_version") in {"sciassistant.evidence-review/v3", "sciassistant.evidence-review/v4", "sciassistant.evidence-review/v5"}:
                try:
                    recovered, report = recover_review_subset(review, evidence, groups, plan=plan)
                except ReviewContractError:
                    # A malformed new review cannot invalidate the independently
                    # validated prior snapshot. It also cannot approve new IDs.
                    recovered = None
                if recovered is not None:
                    return self._merge_recovered_review(run_id, recovered, report, previous, evidence, groups, plan, refs, exc.code)
            return self._retain_previous_review(run_id, previous, evidence, groups, plan, exc.code)

    def _merge_recovered_review(self, run_id, recovered, report, previous, evidence, groups, plan, refs, reason_code):
        report["input_review_artifact_id"] = refs["rejected_recovery_review"]
        refs["review_validation"] = self.artifacts.put("validation-report", report)["artifact_id"]
        explicit_rejected = {r["evidence_id"] for r in recovered["decisions"] if r["decision"] == "rejected"}
        if set(previous["allowed_evidence_ids"]).issubset(set(recovered["allowed_evidence_ids"]) | explicit_rejected):
            return recovered
        # Respect individually validated withdrawals even if other rows failed.
        previous = {**previous, "allowed_evidence_ids": [key for key in previous["allowed_evidence_ids"] if key not in explicit_rejected],
                    "decisions": [r for r in previous.get("decisions", []) if r["evidence_id"] not in explicit_rejected],
                    "coverage": [r for r in previous.get("coverage", []) if not set(r.get("evidence_ids", [])) & explicit_rejected]}
        return self._retain_previous_review(run_id, previous, evidence, groups, plan, reason_code)

    def _retain_previous_review(self, run_id, previous, evidence, groups, plan, reason_code):
        if not previous["allowed_evidence_ids"]:
            raise ReviewContractError(reason_code)
        # Retest approvals against current immutable IDs; only obsolete rejected
        # decisions may be removed, never missing/changed approved packets.
        present = {item["evidence_id"] for item in evidence["evidence"]}
        scoped = dict(previous)
        obsolete = [row for row in previous.get("decisions", [])
                    if row["evidence_id"] not in present and row["decision"] == "rejected"]
        scoped["decisions"] = [row for row in previous.get("decisions", []) if row not in obsolete]
        reviewed_ids = {row["evidence_id"] for row in scoped["decisions"]}
        retained = check_review(scoped, {**evidence, "evidence": [row for row in evidence["evidence"]
                                if row["evidence_id"] in reviewed_ids]}, groups, plan=plan)
        self._event({"event": "prior_review_retained", "obsolete_rejected_decision_count": len(obsolete),
                     "retained_approved_count": len(retained["allowed_evidence_ids"]), "new_approved_count": 0})
        return {**retained, "coverage_status": "needs_review", "recovery_status": "rejected",
                "reviewed_evidence_ids": sorted(reviewed_ids), "recovery_reason_code": reason_code,
                "recovery_notice": "后续复审输出未通过结构校验；本回答仅使用此前有效批准的片段，首轮批准证据不会被新候选挤出；未解决的缺口需人工复核。"}

    def _followup_review(self, run_id, goal, input_ids, previous, evidence, groups, plan, refs):
        try:
            _, raw = self._invoke(run_id, "reviewer", goal, input_ids)
        except PipelineExecutionError as exc:
            if exc.code not in {"MODEL_JSON_INVALID", "MODEL_SCHEMA_REJECTED", "MODEL_OUTPUT_TRUNCATED"}:
                raise
            # No new decision exists. Use only the old, strictly validated snapshot.
            raw = {"execution_error": exc.code}
            self._event({"event": "followup_review_execution_rejected", "reason_code": exc.code})
        return self._validated_followup_review(run_id, raw, previous, evidence, groups, plan, refs)

    def _reject_optional_recovery(self, run_id, review, validation, refs):
        # Cancellation/deadline must win even if an optional plan was rejected.
        self._active(run_id)
        refs["source_recovery_validation"] = self.artifacts.put("validation-report", validation)["artifact_id"]
        event = {"event": "gap_plan_rejected" if validation["stage"] == "gap_plan" else "source_recovery_rejected",
                 "stage": validation["stage"], "reason_code": validation["reason_code"],
                 "retained_approved_evidence_count": len(review["allowed_evidence_ids"]),
                 "validation_artifact_id": refs["source_recovery_validation"]}
        self._event(event)
        self.store.record_event(run_id, "optional_recovery_rejected", "completed", event)
        transient = validation['reason_code'] in {'MODEL_SERVICE_UNAVAILABLE','MODEL_HTTP_502','MODEL_HTTP_503','MODEL_HTTP_504'}
        retained = {**review, "coverage_status": "needs_review" if review["allowed_evidence_ids"] else "insufficient",
                    "recovery_status": "rejected", "recovery_reason_code": validation["reason_code"],
                    "recovery_notice": "可选补查遇到临时模型服务故障，未启动本轮文献工具检索；保留此前已审查资料，仍需写作和引用审计。" if transient else "补检索计划或动作不符合返工范围、格式或来源规则，未执行；本回答仅使用此前已审查证据，未解决的缺口需核对。"}
        refs["review"] = self.artifacts.put("evidence-review", retained)["artifact_id"]
        if self.store.get_run(run_id)["status"] != "reviewing":
            self.store.transition(run_id, "reviewing", details={"recovery_rejected": True})
        return retained

    def _recover_evidence(self, run_id, review, evidence, plan, missing, search_actions,
                          group_ids, recovery_context, refs):
        selected = select_recovery_targets(missing, review, plan) if is_soft_time_policy(self.time_policy) else missing[:2]
        targets = [{key: row[key] for key in ("gap_id", "group_id", "metric") if row.get(key)}
                   for row in selected] or [{"group_id": group["id"]} for group in plan["groups"]]
        refs["gap_targets"] = self.artifacts.put("gap-targets", {
            "schema_version": "sciassistant.gap-targets/v1", "targets": targets, "max_queries": 2,
            "policy": "ticket_targets_only_no_extra_groups_metrics_or_gap_ids",
            "selection_policy": GAP_SELECTION_POLICY if is_soft_time_policy(self.time_policy) else 'legacy-first-two',
            "actionable_gap_count": len(missing)})["artifact_id"]
        self._event({'event': 'gap_targets_selected', 'targets': targets,
            'selection_policy': GAP_SELECTION_POLICY if is_soft_time_policy(self.time_policy) else 'legacy-first-two'})
        gap_ticket = make_rework_ticket(run_id=run_id, from_role="reviewer", to_role="retriever",
            reason_code="EVIDENCE_GAP", artifact_ids=[refs["review"], refs["gap_targets"]],
            required_changes=[f"补强{row['group_id']}的{row.get('metric') or '证据'}" for row in targets])
        refs["gap_ticket"] = self._ticket(gap_ticket)
        stage = "gap_plan"
        try:
            _, gap = self._invoke(run_id, "gap_analyst", "只按gap-targets返工范围生成最多两条查询，不扩大主题或指标",
                [*recovery_context, refs["plan"], refs["review"], refs["gap_ticket"], refs["gap_targets"]])
            refs["proposed_gap"] = self.artifacts.put("proposed-gap-plan", gap)["artifact_id"]
            validation = validate_gap_plan(gap, targets,
                {str(item["arguments"]["query"]).strip().casefold() for item in search_actions})
            if not validation["valid"]:
                return self._reject_optional_recovery(run_id, review, validation, refs), evidence
            gaps = gap["gaps"]
            refs["gap"] = self.artifacts.put("gap-plan", gap)["artifact_id"]
            self.store.transition(run_id, "retrieving", details={"recovery": True})
            stage = "source_recovery"
            recovery, _ = self._invoke(run_id, "retriever", "仅将本轮缺口转成最多两条检索动作，不重复初始查询",
                [*recovery_context, refs["plan"], refs["gap"], refs["gap_targets"]])
        except PipelineExecutionError as exc:
            # Optional protocol/transient suggestion failures may preserve an
            # already valid review. Auth/payment/deadline/cancel remain terminal.
            transient_optional = (exc.code in {'MODEL_SERVICE_UNAVAILABLE','MODEL_HTTP_502','MODEL_HTTP_503','MODEL_HTTP_504'}
                and bool(review.get('allowed_evidence_ids')) and bool(getattr(self,'_skill_ledger',None)))
            if exc.code not in {"AGENT_CONTRACT_REJECTED", "MODEL_JSON_INVALID", "MODEL_SCHEMA_REJECTED", "MODEL_OUTPUT_TRUNCATED"} and not transient_optional:
                raise
            validation = {"schema_version": "sciassistant.validation-report/v1", "stage": stage,
                          "valid": False, "reason_code": exc.code,
                          "recovery_action": "keep_prior_review_no_new_evidence_no_network"}
            return self._reject_optional_recovery(run_id, review, validation, refs), evidence
        allowed = {(row.get("gap_id"), row["group_id"], row["query"].strip()) for row in gaps}
        requests = recovery["tool_requests"]
        invalid_fields = any(not isinstance(row["arguments"].get("group_id"), str)
            or not isinstance(row["arguments"].get("query"), str)
            or (row["arguments"].get("gap_id") is not None and not isinstance(row["arguments"]["gap_id"], str))
            for row in requests)
        if not requests or len(requests) > 2 or invalid_fields or len({row["request_id"] for row in requests}) != len(requests) or any(
                (row["arguments"].get("gap_id"), row["arguments"].get("group_id"),
                 str(row["arguments"].get("query", "")).strip()) not in allowed for row in requests):
            validation = {"schema_version": "sciassistant.validation-report/v1", "stage": "source_recovery",
                          "valid": False, "reason_code": "SOURCE_RECOVERY_ACTION_REJECTED",
                          "recovery_action": "keep_prior_review_no_new_evidence_no_network"}
        else:
            validation = self.executor.validate_recovery_actions(requests, gaps, group_ids) if hasattr(
                self.executor, "validate_recovery_actions") else {"valid": True}
        if not validation["valid"]:
            return self._reject_optional_recovery(run_id, review, validation, refs), evidence
        previous_review = review
        evidence = self._retrieve(run_id, requests, group_ids, recovery=True, prior=evidence,
                                  retained_evidence_ids=previous_review["allowed_evidence_ids"])
        refs["evidence"] = self.artifacts.put("evidence-set", evidence)["artifact_id"]
        self.store.transition(run_id, "reviewing", details={"recovery": True, "evidence_count": len(evidence["evidence"])})
        review = self._followup_review(run_id, "复审补检索证据", [refs["question"], refs["requirements"],
            refs["plan"], refs["evidence"], refs["review"]], previous_review, evidence, group_ids, plan, refs)
        refs["review"] = self.artifacts.put("evidence-review", review)["artifact_id"]
        return review, evidence

    def _audit(self, run_id, goal, input_ids, draft, refs):
        if is_batched(draft):
            return self._audit_batched(run_id, goal, input_ids, draft, refs)
        return self._audit_single(run_id, goal, input_ids, draft, refs)

    def _audit_batched(self, run_id, goal, input_ids, draft, refs):
        self._active(run_id)
        approved = self.artifacts.get(refs['approved'])
        if draft.get('assertion_policy') == ASSERTION_POLICY:
            refs['assertion_modes'] = self.artifacts.put('assertion-modes',assertion_packet(draft))['artifact_id']
        parts = source_batches(draft)
        manifest = {'schema_version':'sciassistant.audit-batches/v1', 'policy':AUDIT_BATCH_POLICY,
            'draft_artifact_id':refs['draft'], 'draft_sha256':audit_digest(draft),
            'previous_audit_batches_artifact_id':refs.get('audit_batches'),
            'approved_sha256':audit_digest(approved), 'maximum_claims_per_source_batch':MAX_AUDIT_CLAIMS,
            'whole_report_review_reserved_calls':1, 'batches':[], 'source_or_claim_truncated':False}
        records = []
        def persist():
            refs['audit_batches'] = self.artifacts.put('audit-batches',manifest)['artifact_id']
        persist()
        for index, part in enumerate(parts):
            self._active(run_id)
            row = {k:v for k,v in part.items() if k != 'draft'}
            manifest['batches'].append(row)
            if self.store.get_run(run_id)['remaining_model_calls'] < 2:
                row.update(status='skipped', reason_code='AUDIT_BATCH_BUDGET_RESERVED_FOR_REPORT_REVIEW')
                records.append({**row, 'audit':{}})
                persist()
                continue
            batch_refs = dict(refs)
            batch_refs['draft'] = self.artifacts.put('audit-batch-draft',part['draft'])['artifact_id']
            batch_inputs = [batch_refs['draft'] if key == refs['draft'] else key for key in input_ids]
            self._event({'event':'source_audit_batch_started','batch_id':part['batch_id'],
                'claim_ids':part['claim_ids'],'maximum_claims':MAX_AUDIT_CLAIMS})
            _, audit = self._audit_single(run_id,goal+'；只审查本批原文声明，不输出需求覆盖',
                batch_inputs,part['draft'],batch_refs,reserve_calls=len(parts)-index)
            row.update(status='invalid' if audit.get('contract_errors') else 'completed',
                audit_artifact_id=self.artifacts.put('source-batch-audit',audit)['artifact_id'],
                audit_input_artifact_id=batch_refs['audit_input'],
                diagnostic_artifact_ids={k:batch_refs[k] for k in ('audit_validation','witness_resolution','audit_row_retention') if k in batch_refs},
                contract_errors=audit.get('contract_errors',[]))
            records.append({**row,'audit':audit})
            persist()
            self._event({'event':'source_audit_batch_finished',**row})
        combined = merge_source_audits(draft,approved,records)
        if combined.get('source_batch_recoveries'):
            refs['audit_batch_recovery'] = self.artifacts.put('audit-batch-recovery', {
                'schema_version':'sciassistant.audit-batch-recoveries/v1',
                'policy':AUDIT_BATCH_RECOVERY_POLICY, 'records':combined['source_batch_recoveries'],
                'original_audit_artifact_ids':[r.get('audit_artifact_id') for r in records],
                'scientific_auto_approval':False})['artifact_id']
            manifest['recovery_artifact_id'] = refs['audit_batch_recovery']
            self._event({'event':'source_audit_rows_recovered',
                'artifact_id':refs['audit_batch_recovery'],
                'retained_claim_ids':[k for r in combined['source_batch_recoveries'] for k in r['retained_claim_ids']],
                'unreviewed_claim_ids':combined['source_unreviewed_claim_ids']})
        self._active(run_id)
        packet = global_review_input(self._skill_ledger,draft,approved,combined)
        refs['audit_input'] = self.artifacts.put('report-global-review-input',packet)['artifact_id']
        global_inputs = list(dict.fromkeys([refs[k] for k in ('question','requirements','plan','answer_focus_brief') if k in refs]
            +[refs['audit_input']]))
        raw, checked = {}, check_report_review(None,self._skill_ledger,draft)
        if self.store.get_run(run_id)['remaining_model_calls'] >= 1:
            def invoke_global(ids):
                try:
                    _, output = self._invoke(run_id,'citation_auditor',
                        '全报告复核：output直接为report-review/v1，仅schema_version/requirements/consistency。'
                        '不要输出claim_results/issues/rejected_claim_ids源判定字段。'
                        '按每项eligible_claim_ids选择实际回答者，不得跨需求借ID或输出原文逐声明审计。',ids)
                except PipelineExecutionError as exc:
                    if exc.code not in {'MODEL_JSON_INVALID','MODEL_SCHEMA_REJECTED','MODEL_OUTPUT_TRUNCATED'}:
                        raise
                    return {}, {'errors':[exc.code], 'rows':{}, 'conflicts':[], 'consistency_verified':False,
                        'diagnostics':[{'path':'report_review','reason':exc.code}], 'semantic_auto_approval':False,
                        'model_format_diagnostic_artifact_ids':list(exc.diagnostic_artifact_ids)}
                validation = check_report_review(output.get('report_review'),self._skill_ledger,draft)
                if any(output.get(key) for key in ('claim_results','issues','rejected_claim_ids')):
                    validation['errors'].append('REPORT_REVIEW_PHASE_SOURCE_VERDICTS_FORBIDDEN')
                return output,validation
            self._event({'event':'whole_report_review_started','claim_count':len(draft['claims']),
                'source_batch_count':len(parts),'source_approvals_cannot_be_added':True})
            raw,checked = invoke_global(global_inputs)
            if (checked['errors'] and not self.audit_protocol_retry_used
                    and self.store.get_run(run_id)['remaining_model_calls'] >= 1 and self._stage_remaining()>45):
                self.audit_protocol_retry_used = True
                feedback = {'schema_version':'sciassistant.validation-report/v1','stage':'citation_auditor',
                    'reason_codes':checked['errors'], 'report_review_diagnostics':checked['diagnostics'],
                    'expected_report_review':packet['report_review_request'],
                    'instructions':'一次全报告协议纠正；只从每需求eligible_claim_ids选择，不能新增绑定或源批准。'}
                refs['audit_validation'] = self.artifacts.put('validation-report',feedback)['artifact_id']
                self._event({'event':'audit_protocol_retry','phase':'whole_report_review','reason_codes':checked['errors']})
                raw,checked = invoke_global([*global_inputs,refs['audit_validation'],
                    *checked.get('model_format_diagnostic_artifact_ids',[])])
        combined['report_review'] = raw.get('report_review') if 'REPORT_REVIEW_PHASE_SOURCE_VERDICTS_FORBIDDEN' not in checked['errors'] else None
        combined['report_review_validation'] = checked
        refs['report_review'] = self.artifacts.put('report-review', {
            'schema_version':'sciassistant.report-review-validation/v1','policy':PUBLICATION_POLICY,**checked})['artifact_id']
        manifest['whole_report_review'] = {'status':'needs_review' if checked['errors'] else 'completed',
            'input_artifact_id':refs['audit_input'],'validation_artifact_id':refs['report_review'],
            'reason_codes':checked['errors']}
        manifest['unreviewed_claim_ids'] = combined['source_unreviewed_claim_ids']
        persist()
        return {'status':'completed'},combined

    def _audit_single(self, run_id, goal, input_ids, draft, refs, *, reserve_calls=0):
        # Every audit, including protocol correction and Writer re-audit, sees
        # the same actual question and the full user-visible statement. This
        # extra deterministic artifact is not an extra model call or approval.
        approved = self.artifacts.get(refs["approved"]) if "approved" in refs else None
        if draft.get('assertion_policy') == ASSERTION_POLICY:
            refs['assertion_modes'] = self.artifacts.put('assertion-modes', assertion_packet(draft))['artifact_id']
        if (draft.get('audit_context_policy') == AUDIT_CONTEXT_POLICY
                and refs.get('citation_feedback') in input_ids):
            context = audit_revision_context(draft, self.artifacts.get(refs['citation_feedback']), refs.get('draft'))
            refs['audit_revision_context'] = self.artifacts.put('audit-revision-context', context)['artifact_id']
            input_ids = [refs['audit_revision_context'] if key == refs['citation_feedback'] else key for key in input_ids]
            self._event({'event':'current_audit_context_prepared',
                'artifact_id':refs['audit_revision_context'], 'current_draft_artifact_id':refs.get('draft'),
                'prior_issue_count':len(context['prior_issues_not_current_verdicts'])})
        prepared_input = citation_audit_input(draft, approved)
        report_enabled = draft.get('publication_review_policy') == PUBLICATION_POLICY
        if report_enabled:
            prepared_input['report_review_request'] = review_request(self._skill_ledger, draft)
        # Save the single view the Agent actually reads, not duplicate claim/menu
        # representations that can exceed the artifact ceiling before any audit.
        stored_input = audit_material(prepared_input) if draft.get('audit_material_policy') == AUDIT_MATERIAL_POLICY else prepared_input
        try:
            refs["audit_input"] = self.artifacts.put("citation-audit-input", stored_input)["artifact_id"]
        except AgentContractError as exc:
            if str(exc) != 'artifact exceeds size limit': raise
            self._event({'event':'audit_material_capacity_exceeded','claim_count':len(draft.get('claims',[])),
                'policy':draft.get('audit_material_policy'), 'source_or_claim_truncated':False})
            raise PipelineExecutionError('AUDIT_MATERIAL_CAPACITY_EXCEEDED') from exc
        initial_options = prepared_input.get("source_witness_options", {"options": []})
        if prepared_input.get('audit_job_policy') == AUDIT_JOB_POLICY:
            self._event({'event': 'claim_scoped_audit_handoff', 'artifact_id': refs['audit_input'],
                         'job_count': len(prepared_input['audit_jobs']), 'policy': AUDIT_JOB_POLICY,
                         'automatic_rebinding': False})
        absence_options = prepared_input.get('absence_assertion_options', {'options':[]})
        selection_issues = []
        input_ids = list(dict.fromkeys([refs[key] for key in ("question", "requirements", "plan", "answer_focus_brief") if key in refs]
                                      + list(input_ids) + [refs["audit_input"]]))
        def invoke_audit(call_goal, ids):
            try:
                return self._invoke(run_id, "citation_auditor", call_goal, ids)
            except PipelineExecutionError as exc:
                if exc.code not in {"MODEL_JSON_INVALID", "MODEL_SCHEMA_REJECTED", "MODEL_OUTPUT_TRUNCATED"}:
                    raise  # Cancellation, deadline and HTTP errors retain their terminal rules.
                return {"status": "completed"}, {"schema_version": "sciassistant.citation-audit/v3",
                    "status": "needs_review", "contract_errors": [exc.code]}
        def resolve_selected_quotes(raw, menu, phase):
            problems = witness_selection_diagnostics(raw, menu, draft)
            selection_issues.extend(problems)
            if problems:
                self._event({'event': 'audit_witness_selection_invalid', 'phase': phase,
                    'policy': WITNESS_SELECTION_FEEDBACK_POLICY, 'count': len(problems),
                    'reason_codes': list(dict.fromkeys(r['reason'] for r in problems)),
                    'automatic_rebinding': False})
            normalized, resolution = resolve_witness_choices(raw, menu, draft, approved)
            if resolution["resolutions"]:
                refs["witness_resolution"] = self.artifacts.put("witness-choice-resolution", resolution)["artifact_id"]
                self._event({"event": "audit_witness_choices_resolved", "artifact_id": refs["witness_resolution"],
                             "phase": phase, "count": len(resolution["resolutions"]), "semantic_auto_approval": False})
            return normalized
        def resolve_selected_absences(raw, phase):
            if draft.get('absence_choice_policy') != ABSENCE_CHOICE_POLICY:
                return raw
            normalized, resolution = resolve_absence_choices(raw, absence_options, draft)
            if resolution['resolutions']:
                ref = self.artifacts.put('absence-choice-resolution', resolution)['artifact_id']
                self._event({'event':'audit_absence_choices_resolved','phase':phase,
                    'artifact_id':ref,'count':len(resolution['resolutions']),'semantic_auto_approval':False})
            return normalized
        result, raw = invoke_audit(goal, input_ids)
        if draft.get("audit_quote_menu_policy") == AUDIT_QUOTE_MENU_POLICY:
            raw = resolve_selected_quotes(raw, initial_options, "initial")
        raw = resolve_selected_absences(raw, 'initial')
        checked = check_audit(raw, draft, approved)
        report_check = check_report_review(checked.get('report_review'),self._skill_ledger,draft) if report_enabled else {'errors':[]}
        if checked["contract_errors"] or checked.get("witness_issues") or checked.get("protocol_issues") or report_check['errors']:
            invalid = self.artifacts.put("rejected-citation-audit", raw)["artifact_id"]
            report = {"schema_version": "sciassistant.validation-report/v1", "stage": "citation_auditor",
                      "reason_codes": list(dict.fromkeys([*checked["contract_errors"], *report_check['errors'],
                          *[row["reason"] for row in [*checked.get("witness_issues", []), *checked.get("protocol_issues", [])]]])),
                      "source_witness_issues": checked.get("witness_issues", []),
                      "witness_selection_policy": WITNESS_SELECTION_FEEDBACK_POLICY,
                      "witness_selection_issues": selection_issues,
                      "source_witness_options": audit_witness_options(checked, draft, approved),
                      "field_protocol_issues": checked.get("protocol_issues", []),
                      "absence_assertion_options": absence_options,
                      "input_audit_artifact_id": invalid,
                      "expected_claim_ids": [r["claim_id"] for r in draft.get("claims", [])],
                      "expected_scope_checks": ["family_scope", "comparison_design", "task_scope", "metric_semantics"],
                      "expected_field_results": {"fields": ["text", "scope_note", "qualification"],
                          "instructions": "v7: exact status/detail/absence_checks per field; not_applicable only for empty fields; overall verdict must agree. Each negative record: exact assertion/basis/witness_index; source_reported binds an actual zero-based witness, other bases use null"},
                      "expected_source_witnesses": f"any supported v7 field: 1-4 verbatim 20-{witness_quote_limit(draft)} character quotations from cited approved excerpts",
                      "policy": draft.get("audit_protocol_policy", "complete-audit-protocol-no-subset-publication-v7-absence-basis")}
            if report_enabled:
                report['expected_report_review'] = review_request(self._skill_ledger,draft)
                report['report_review_diagnostics'] = report_check['diagnostics']
            if draft.get('scientific_review_frame_policy') == SCIENTIFIC_REVIEW_FRAME_POLICY:
                report['current_field_correction_brief'] = audit_correction_brief(draft, checked)
            refs["audit_validation"] = self.artifacts.put("validation-report", report)["artifact_id"]
            if (not self.audit_protocol_retry_used and self.store.get_run(run_id)["remaining_model_calls"] >= 1+reserve_calls
                    and self._stage_remaining() > 45):
                self.audit_protocol_retry_used = True
                self._event({"event": "audit_protocol_retry", "reason_codes": report["reason_codes"]})
                # The invalid audit is diagnostic, not a prior approval to copy.
                prior_result, prior_checked = result, checked
                from copy import deepcopy
                prior_context = deepcopy({'draft':draft, 'evidence':approved})
                result, raw = invoke_audit("仅一次协议纠正：先读validation-report.witness_selection_issues的具体错选原因及本声明可选句柄；若有report_review_diagnostics，按具体requirement_id/invalid_claim_ids/eligible_claim_ids纠正需求行，不跨需求借ID，未能回答用unanswered和[]，不能猜测新增绑定。优先按当前claim_id逐行选择精确choice_label，不把另一声明的hash抄来，即使同源同句也不能串用；source_witnesses输出{evidence_id,choice_label}，也可选本声明quote_id或citation-audit-input.witness_limits范围内的合法原句。否定记录优先选择本声明本字段的choice_label，仍须自行给basis/witness_index和判决。禁止翻译拼接，仍须重新审计全部字段，选择候选不是自动批准", [*input_ids, refs["audit_validation"]])
                options = {"options": [*initial_options["options"], *report["source_witness_options"]["options"]]}
                raw = resolve_selected_quotes(raw, options, "correction")
                raw = resolve_selected_absences(raw, 'correction')
                checked = check_audit(raw, draft, approved)
                if (draft.get("audit_protocol_policy") == AUDIT_PROTOCOL_POLICY
                        and prior_checked.get("schema_version") == ABSENCE_AUDIT_SCHEMA
                        and not prior_checked["contract_errors"] and checked["contract_errors"]):
                    # Same draft/evidence; a worse correction cannot erase an
                    # already complete, consistent audit. All original local
                    # faults remain blocked; no new decision is inferred.
                    correction = self.artifacts.put("rejected-citation-audit", raw)["artifact_id"]
                    self._event({"event": "audit_correction_prior_retained",
                        "correction_artifact_id": correction, "reason_codes": checked["contract_errors"],
                        "retained_blocked_claim_ids": sorted(publication_rejections(prior_checked, draft))})
                    result, checked = prior_result, prior_checked
                elif draft.get('audit_row_retention_policy') == AUDIT_ROW_RETENTION_POLICY:
                    checked, retention = retain_valid_audit_rows(prior_checked, checked, draft, approved,
                        prior_context=prior_context)
                    if retention['retained_claim_ids']:
                        retention['prior_audit_artifact_id'] = invalid
                        retention['correction_audit_artifact_id'] = self.artifacts.put('correction-citation-audit', raw)['artifact_id']
                        refs['audit_row_retention'] = self.artifacts.put('audit-row-retention', retention)['artifact_id']
                        self._event({'event':'audit_valid_rows_retained',
                            'artifact_id':refs['audit_row_retention'],
                            'claim_ids':retention['retained_claim_ids'], 'semantic_auto_approval':False})
        if report_enabled:
            report_check = check_report_review(checked.get('report_review'),self._skill_ledger,draft)
            checked['report_review_validation'] = report_check
            refs['report_review'] = self.artifacts.put('report-review', {
                'schema_version':'sciassistant.report-review-validation/v1','policy':PUBLICATION_POLICY,
                **report_check})['artifact_id']
        return result, checked

    def _write_sections(self, run_id, ledger, plan, approved, review, refs):
        outline = report_outline(ledger, plan)
        dossiers = section_dossiers(outline, approved, review)
        refs['report_outline'] = self.artifacts.put('report-outline', outline)['artifact_id']
        refs['section_evidence'] = self.artifacts.put('section-evidence', dossiers)['artifact_id']
        jobs = writer_jobs(outline, dossiers, self.report_config['report_profile'],
            self.store.get_run(run_id)['remaining_model_calls'])
        for job in jobs:
            job['assertion_policy'] = ASSERTION_POLICY
        refs['writer_jobs'] = self.artifacts.put('writer-jobs', {
            'schema_version': 'sciassistant.writer-jobs/v1', 'policy': SECTION_POLICY, 'jobs': jobs,
            'outline_sha256': outline_digest(outline), 'no_automatic_profile_escalation': True})['artifact_id']
        manifest = {'schema_version': 'sciassistant.section-writing/v1', 'policy': SECTION_POLICY,
            'outline_artifact_id': refs['report_outline'], 'dossiers_artifact_id': refs['section_evidence'],
            'batches': [], 'draft_self_reports_not_publication_coverage': True}
        completed = []
        self._event({'event': 'report_sections_prepared', 'outline_artifact_id': refs['report_outline'],
            'dossiers_artifact_id': refs['section_evidence'], 'section_count': len(outline['sections']),
            'writer_batches': len(jobs), 'semantic_auto_approval': False})
        try:
            for index, job in enumerate(jobs):
                row = {'job_id': job['job_id'], 'section_ids': job['section_ids'], 'status': 'pending'}
                manifest['batches'].append(row)
                # Never spend the last call on more prose instead of its audit.
                if self.store.get_run(run_id)['remaining_model_calls'] < 2:
                    row.update(status='skipped', reason_code='FINAL_AUDIT_CALL_RESERVED')
                    continue
                self._writer_pending_calls = len(jobs) - index - 1
                self.writer_job_ref = self.artifacts.put('writer-job', job)['artifact_id']
                subset = writer_job_evidence(job, dossiers)
                source_ref = self.artifacts.put('approved-section-evidence', subset)['artifact_id']
                material = writer_job_material(job, dossiers, subset, source_ref)
                packet_ref = self.artifacts.put('section-writing-material', material)['artifact_id']
                boundary_ref = self.artifacts.put('source-boundary-brief', source_boundary_brief(subset))['artifact_id']
                table_ref = self.artifacts.put('comparison-observations', comparison_observations(subset))['artifact_id']
                self._event({'event': 'writer_batch_started', 'job_id': job['job_id'],
                    'writer_job_artifact_id': self.writer_job_ref, 'evidence_artifact_id': source_ref,
                    'material_artifact_id': packet_ref, 'material_policy': material['policy'],
                    'unique_source_count': len(subset['evidence']),
                    'material_json_utf8_bytes': len(json.dumps(material, ensure_ascii=False).encode('utf-8'))})
                try:
                    _, draft = self._invoke(run_id, 'writer',
                        '按writer-job写完指定章节和子问；只依据本批批准原文，完整表格与实验方案放正文，不引用内部编号',
                        [refs['question'], refs['requirements'], refs['report_outline'], source_ref,
                         packet_ref, boundary_ref, table_ref, refs['answer_focus_brief']])
                except PipelineExecutionError as exc:
                    if exc.code not in {'MODEL_OUTPUT_TRUNCATED', 'MODEL_JSON_INVALID', 'MODEL_SCHEMA_REJECTED'}:
                        raise  # No recovery from cancellation/HTTP/permission errors.
                    row.update(status='rejected_output', reason_code=exc.code)
                    continue
                draft = project_writer_job(draft, job)
                errors = writer_job_issues(draft, job)
                if errors:
                    row.update(status='rejected_output', reason_code='WRITER_JOB_CONTRACT_REJECTED', issues=errors)
                    row['rejected_artifact_id'] = self.artifacts.put('rejected-section-draft', draft)['artifact_id']
                else:
                    ref = self.artifacts.put('section-draft', draft)['artifact_id']
                    completed.append((job, draft, ref))
                    row.update(status='completed_with_isolations' if draft.get('isolated_claims') else 'completed', draft_artifact_id=ref,
                        isolated_claim_ids=[c['claim_id'] for c in draft.get('isolated_claims', [])],
                        draft_claim_count=len(draft['claims']))
                self._event({'event': 'writer_batch_finished', **row})
                refs['section_writing'] = self.artifacts.put('section-writing', manifest)['artifact_id']
        finally:
            self.writer_job_ref = None
            self._writer_pending_calls = 0
            refs['section_writing'] = self.artifacts.put('section-writing', manifest)['artifact_id']
        self.section_writing_fault = any(r['status'] != 'completed' for r in manifest['batches'])
        merged = merge_writer_batches(outline, completed)
        merged['assertion_policy'] = ASSERTION_POLICY
        merged['precise_revision_policy'] = PRECISE_REVISION_POLICY
        merged['publication_review_policy'] = PUBLICATION_POLICY
        merged['audit_material_policy'] = AUDIT_MATERIAL_POLICY
        merged['audit_delivery_policy'] = AUDIT_BATCH_POLICY
        merged['revision_delivery_policy'] = REVISION_DELIVERY_POLICY
        refs['report_composition'] = self.artifacts.put('report-composition', {
            'schema_version': 'sciassistant.report-composition/v1', 'policy': SECTION_POLICY,
            'batch_provenance': merged['batch_provenance'],
            'draft_requirement_observations': merged['draft_requirement_observations'],
            'initial_batches': len(jobs), 'valid_batches': len(completed),
            'publication_coverage_verified': False, 'semantic_auto_approval': False})['artifact_id']
        refs['composed_draft'] = self.artifacts.put('composed-draft', merged)['artifact_id']
        if len(merged['claims']) > 80:
            # Existing Auditor envelope, not a desired length. Never clip the
            # last chapters to make a too-large audit silently appear complete.
            raise PipelineExecutionError('REPORT_AGGREGATE_CAPACITY_EXCEEDED')
        if not merged['claims']:
            raise PipelineExecutionError('REPORT_NO_VALID_WRITING_BATCH')
        return merged

    def _reviewed_checkpoint(self, run_id, draft, approved, audit, audit_result, refs, require_summary):
        """Persist an exact reviewed state, never a second route to approval."""
        if draft.get('revision_delivery_policy') != REVISION_DELIVERY_POLICY:
            return
        checked = check_audit(audit, draft, approved)
        validation = check_report_review(checked.get('report_review'), self._skill_ledger, draft)
        if (checked.get('contract_errors') or validation['errors'] or not validation['consistency_verified']
                or audit_result.get('status') == 'rework_required' and checked.get('status') == 'passed'):
            return
        checked['report_review_validation'] = validation
        checked['code_issues'] = (check_draft(draft, approved, require_summary=require_summary)
            + checked.get('witness_issues', []) + checked.get('absence_issues', [])
            + checked.get('protocol_issues', []) + conflict_issues(validation))
        blocked = publication_rejections(checked, draft)
        if not any(c['claim_id'] not in blocked for c in draft['claims']):
            return
        audit_ref = self.artifacts.put('checkpoint-citation-audit', checked)['artifact_id']
        state = self.store.get_run(run_id)
        checkpoint = {'schema_version':'sciassistant.reviewed-checkpoint/v1',
            'policy':REVISION_DELIVERY_POLICY, 'run_id':run_id, 'owner_ref':state['owner_ref'],
            'draft_sha256':audit_digest(draft), 'approved_sha256':audit_digest(approved),
            'ledger_sha256':audit_digest(self._skill_ledger), 'require_summary':require_summary,
            'artifact_refs':{**deepcopy(refs), 'audit':audit_ref},
            'blocked_claim_ids':sorted(blocked), 'semantic_auto_approval':False}
        refs['reviewed_checkpoint'] = self.artifacts.put('reviewed-checkpoint', checkpoint)['artifact_id']
        self._event({'event':'reviewed_checkpoint_saved','artifact_id':refs['reviewed_checkpoint'],
            'draft_artifact_id':refs['draft'],'blocked_claim_ids':sorted(blocked)})

    def _restore_reviewed_checkpoint(self, run_id, refs, error):
        if (not self._revision_active or error.code not in
                {'MODEL_JSON_INVALID', 'MODEL_SCHEMA_REJECTED', 'MODEL_OUTPUT_TRUNCATED',
                 'REVISION_REAUDIT_BUDGET_UNAVAILABLE'}
                or not refs.get('reviewed_checkpoint')):
            return None
        try:
            self._active(run_id)  # Cancellation/deadline/owner state still wins.
            saved = self.artifacts.get(refs['reviewed_checkpoint'])
            state = self.store.get_run(run_id)
            original = saved['artifact_refs']
            prior = self.artifacts.get(original['draft'])
            approved = self.artifacts.get(original['approved'])
            if (saved.get('policy') != REVISION_DELIVERY_POLICY or saved.get('run_id') != run_id
                    or saved.get('owner_ref') != state['owner_ref']
                    or saved['draft_sha256'] != audit_digest(prior)
                    or saved['approved_sha256'] != audit_digest(approved)
                    or saved['approved_sha256'] != audit_digest(self.artifacts.get(refs['approved']))
                    or saved['ledger_sha256'] != audit_digest(self._skill_ledger)):
                return None
            checked = check_audit(self.artifacts.get(original['audit']), prior, approved)
            validation = check_report_review(checked.get('report_review'), self._skill_ledger, prior)
            if checked['contract_errors'] or validation['errors'] or not validation['consistency_verified']:
                return None
            checked['report_review_validation'] = validation
            checked['code_issues'] = (check_draft(prior, approved, require_summary=saved['require_summary'])
                + checked.get('witness_issues', []) + checked.get('absence_issues', [])
                + checked.get('protocol_issues', []) + conflict_issues(validation))
            blocked = publication_rejections(checked, prior)
            if not any(c['claim_id'] not in blocked for c in prior['claims']):
                return None
            failed_refs = deepcopy(refs)
            restored = {**original, 'reviewed_checkpoint':refs['reviewed_checkpoint']}
            # Keep diagnostics/call records, never replace the reviewed draft
            # with partial, unaudited revision text or a new approval list.
            if refs.get('skill_loads'):
                restored['skill_loads'] = refs['skill_loads']
            restored['revision_fallback'] = self.artifacts.put('revision-fallback', {
                'schema_version':'sciassistant.revision-fallback/v1','policy':REVISION_DELIVERY_POLICY,
                'run_id':run_id,'reason_code':error.code,
                'checkpoint_artifact_id':refs['reviewed_checkpoint'],
                'failed_revision_artifact_refs':failed_refs, 'restored_draft_artifact_id':original['draft'],
                'blocked_claim_ids':sorted(blocked), 'new_revision_claims_published':False,
                'semantic_auto_approval':False})['artifact_id']
            restored['audit'] = self.artifacts.put('citation-audit', checked)['artifact_id']
            restored['publication'] = self.artifacts.put('publication-decisions',
                publication_decisions(checked, prior, restored['audit']))['artifact_id']
            coverage = publication_coverage(self._skill_ledger, prior, checked, blocked)
            restored['publication_coverage'] = self.artifacts.put('publication-coverage', coverage)['artifact_id']
            answer = render_claims(prior, approved, rejected=blocked)
            if not answer:
                return None
            if state['status'] == 'writing':
                self.store.transition(run_id, 'auditing', details={'revision_fallback':True})
            self.store.transition(run_id, 'needs_review', details={
                'reason_code':'REVISION_FAILED_REVIEWED_CHECKPOINT_RESTORED',
                'revision_error_code':error.code, 'unresolved_requirement_ids':coverage['unresolved_requirement_ids']})
            refs.clear()
            refs.update(restored)
            self._event({'event':'reviewed_checkpoint_restored','artifact_id':restored['revision_fallback'],
                'revision_error_code':error.code,'blocked_claim_ids':sorted(blocked)})
            return answer
        except (WorkflowError, AgentContractError, KeyError, ValueError, TypeError):
            return None  # Invalid checkpoint or cancellation is never a license to publish.
        finally:
            self.writer_job_ref = None
            self._writer_pending_calls = 0

    def _reserve_initial_delivery(self, run_id, plan, review, refs):
        estimate = initial_delivery_budget(getattr(self, '_skill_ledger', None), plan,
            self.report_config['report_profile'], protocol_retry_available=not self.audit_protocol_retry_used)
        # With no approved source there is nothing to write yet. Keep the
        # existing bounded attempt to obtain evidence rather than reserving
        # an imaginary complete report and prematurely refusing the task.
        applied = bool(review.get('allowed_evidence_ids'))
        reserve = estimate['estimated_delivery_calls'] if applied else estimate['baseline_reserved_calls']
        receipt = {**estimate, 'applied_to_optional_research': applied, 'reserved_calls': reserve,
            'user_requirements_sha256': audit_digest(getattr(self, '_skill_ledger', None)),
            'remaining_model_calls': self.store.get_run(run_id)['remaining_model_calls']}
        refs['initial_delivery_budget'] = self.artifacts.put('initial-delivery-budget', receipt)['artifact_id']
        self._event({'event': 'initial_delivery_budget_reserved',
            'artifact_id': refs['initial_delivery_budget'], **receipt})
        return reserve

    def _revision_audit_reserve(self, draft):
        # The single protocol correction is shared across the run. Keep it
        # available after revision until a source/global audit actually uses it.
        return required_audit_calls(draft) + int(not self.audit_protocol_retry_used)

    def _write_revision_sections(self, run_id, draft, evidence, recovery, refs):
        feedback = self.artifacts.get(refs['citation_feedback'])
        jobs = revision_jobs(draft, evidence, feedback, recovery)
        manifest = {'schema_version':'sciassistant.revision-writing/v1','policy':REVISION_DELIVERY_POLICY,
            'budget_policy':'merged-draft-full-audit-and-one-protocol-correction/v1',
            'prior_draft_artifact_id':refs['draft'], 'jobs':[], 'maximum_jobs':MAX_REVISION_JOBS,
            'unattempted_sections':[], 'original_claims_removed_by_omission':False}
        completed, last_error = [], None
        try:
            for index, job in enumerate(jobs):
                current = merge_revision_jobs(draft, completed) if completed else draft
                reserve = self._revision_audit_reserve(current)
                if (index >= MAX_REVISION_JOBS or self.store.get_run(run_id)['remaining_model_calls'] < 1+reserve
                        or self._stage_remaining() <= 90):
                    manifest['unattempted_sections'].extend(j['section_ids'][0] for j in jobs[index:])
                    last_error = PipelineExecutionError('REVISION_REAUDIT_BUDGET_UNAVAILABLE')
                    break
                self._writer_pending_calls = max(0, reserve-1)  # Format repair must preserve full re-audit.
                self.writer_job_ref = self.artifacts.put('writer-job', job)['artifact_id']
                selected = {**draft, 'claims':[c for c in draft['claims'] if c['claim_id'] in job['target_claim_ids']]}
                selected_feedback = {**feedback,
                    'code_issues':[r for r in feedback.get('code_issues', []) if r.get('claim_id') in job['target_claim_ids']],
                    'model_audit':{'schema_version':feedback.get('model_audit', {}).get('schema_version'),
                        'claim_results':[r for r in feedback.get('model_audit', {}).get('claim_results', [])
                        if r.get('claim_id') in job['target_claim_ids']]}}
                slice_ref = self.artifacts.put('revision-draft-slice', selected)['artifact_id']
                brief_ref = self.artifacts.put('writer-revision-brief',writer_revision_brief(selected,selected_feedback,evidence))['artifact_id']
                gaps = {**(recovery or {}), 'requirements':[r for r in (recovery or {}).get('requirements', [])
                    if r['requirement_id'] in job['requirement_ids']]}
                gap_ref = self.artifacts.put('publication-recovery-slice', gaps)['artifact_id']
                row = {'job_id':job['job_id'],'section_ids':job['section_ids'],
                    'job_artifact_id':self.writer_job_ref,'slice_artifact_id':slice_ref,'status':'pending'}
                manifest['jobs'].append(row)
                self._event({'event':'writer_revision_section_started',**row})
                try:
                    _, patch = self._invoke(run_id, 'writer',
                        '只返回本writer-job指定声明的修订或新需求声明，不返回整篇报告；保留原ID/绑定，新ID用new_claim_prefix。只基于批准证据，不用遗漏表示删除。',
                        [refs['question'],refs['requirements'],refs['approved'],slice_ref,brief_ref,gap_ref,refs['answer_focus_brief']])
                    patch = project_writer_job(patch, job)
                    artifact_id = self.artifacts.put('revision-section-draft', patch)['artifact_id']
                    try:
                        candidate = merge_revision_jobs(draft, [*completed,(job,patch,artifact_id)])
                    except ValueError:
                        last_error = PipelineExecutionError('MODEL_SCHEMA_REJECTED')
                        row.update(status='rejected_output',reason_code='REVISION_PATCH_CONTRACT_REJECTED')
                    else:
                        actual_reserve = self._revision_audit_reserve(candidate)
                        remaining = self.store.get_run(run_id)['remaining_model_calls']
                        if remaining < actual_reserve:
                            # Store the complete proposal for diagnosis, but do
                            # not merge/truncate it or publish unaudited additions.
                            row.update(status='deferred_budget', patch_artifact_id=artifact_id,
                                patch_claim_count=len(patch['claims']),
                                reason_code='REVISION_REAUDIT_BUDGET_UNAVAILABLE',
                                merged_claim_count=len(candidate['claims']),
                                required_audit_model_calls=actual_reserve, remaining_model_calls=remaining,
                                patch_applied=False)
                            last_error = PipelineExecutionError('REVISION_REAUDIT_BUDGET_UNAVAILABLE')
                            manifest['unattempted_sections'].extend(j['section_ids'][0] for j in jobs[index+1:])
                            self._event({'event':'writer_revision_section_finished',**row})
                            break
                        completed.append((job,patch,artifact_id))
                        row.update(status='completed_with_isolations' if patch.get('isolated_claims') else 'completed',
                            patch_artifact_id=artifact_id,
                            patch_claim_count=len(patch['claims']),
                            patch_outcome='returned_claims' if patch['claims'] else 'no_change',
                            isolated_claim_ids=[c['claim_id'] for c in patch.get('isolated_claims',[])])
                except PipelineExecutionError as exc:
                    if exc.code not in {'MODEL_JSON_INVALID','MODEL_SCHEMA_REJECTED','MODEL_OUTPUT_TRUNCATED'}:
                        raise
                    last_error = exc
                    row.update(status='rejected_output',reason_code=exc.code)
                self._event({'event':'writer_revision_section_finished',**row})
        finally:
            self.writer_job_ref = None
            self._writer_pending_calls = 0
            refs['writer_revision_batches'] = self.artifacts.put('revision-writing', manifest)['artifact_id']
        if not completed:
            raise last_error or PipelineExecutionError('MODEL_SCHEMA_REJECTED')
        self.section_writing_fault = getattr(self, 'section_writing_fault', False) or bool(manifest['unattempted_sections']) or any(
            j['status'] != 'completed' for j in manifest['jobs'])
        return merge_revision_jobs(draft, completed)

    def _ticket(self, ticket: Mapping) -> str:
        ref = self.artifacts.put("rework-ticket", ticket)
        self._event({"event": "rework_requested", "artifact_id": ref["artifact_id"],
                     "from_role": ticket["from_role"], "to_role": ticket["to_role"]})
        if self.event_path:
            folder = self.event_path.parent / "rework_tickets"
            folder.mkdir(exist_ok=True)
            (folder / f"{ticket['ticket_id']}.json").write_text(json.dumps(ticket, ensure_ascii=False), encoding="utf-8")
        return ref["artifact_id"]

    def run(self, run_id: str, owner_ref: str, question: str, *, conversation_context: dict | None = None) -> dict[str, Any]:
        self.store.create_run(run_id, owner_ref, time_budget_seconds=self.time_budget_seconds,
            time_policy=self.time_policy, report_profile=self.report_config['report_profile'])
        started = time.monotonic()
        self.research_started_at = started - self.initialization_elapsed_seconds
        self.deadline = started + self.time_budget_seconds
        self.stage_usage = []
        self.reading_stop_reason = "not_started"
        self.planner_format_retry_used = False
        self.retriever_format_retry_used = False
        self.reviewer_format_retry_used = False
        self.audit_protocol_retry_used = False
        self.writer_format_retry_used = False
        self.source_context_ref = None
        self.answer_focus_ref = None
        self.need_contract_ref = None
        self.need_flow_ref = None
        self.comparison_ref = None
        self.user_requirements_ref = None
        self.writer_job_ref = None
        self._writer_pending_calls = 0
        self.section_writing_fault = False
        refs: dict[str, str] = {}
        self._run_refs = refs
        self._skill_load_records = []
        self._skill_ledger = None
        self._revision_active = False
        failure_code = None
        answer = ""
        fallback_generated = False
        try:
            if not isinstance(question, str) or not 1 <= len(question.strip()) <= 20_000:
                raise WorkflowError("invalid research question")
            question_packet = {"schema_version": "sciassistant.question/v1", "question": question}
            if conversation_context is not None:
                if (not isinstance(conversation_context, dict)
                        or set(conversation_context) != {"schema_version", "previous_question", "previous_answer", "paper_ids", "evidence_policy"}
                        or conversation_context.get("schema_version") != "sciassistant.followup-context/v1"
                        or not isinstance(conversation_context.get("previous_question"), str)
                        or len(conversation_context["previous_question"]) > 1200
                        or not isinstance(conversation_context.get("previous_answer"), str)
                        or len(conversation_context["previous_answer"]) > 6000
                        or not isinstance(conversation_context.get("paper_ids"), list)
                        or len(conversation_context["paper_ids"]) > 10
                        or any(not isinstance(value, str) or len(value) > 80 for value in conversation_context["paper_ids"])
                        or conversation_context.get("evidence_policy") != "context_only_retrieve_again"):
                    raise WorkflowError("invalid follow-up context")
                question_packet["schema_version"] = "sciassistant.question/v2"
                question_packet["conversation_context"] = conversation_context
            refs["question"] = self.artifacts.put("question", question_packet)["artifact_id"]
            if getattr(self.executor, "source_context", None):
                refs["source_context"] = self.artifacts.put("research-source", self.executor.source_context)["artifact_id"]
                self.source_context_ref = refs["source_context"]
            planning_context = conversation_context
            planning_question_ref = refs["question"]
            if getattr(self.executor, "source_context", {}).get("planning_context_policy") == "current-question-only/v1":
                planning_context = None
                planning_question_ref = self.artifacts.put("public-planning-question", {
                    "schema_version": "sciassistant.question/v1", "question": question})["artifact_id"]
                refs["public_planning_question"] = planning_question_ref
            requirements = answer_requirements(question, planning_context)
            refs["requirements"] = self.artifacts.put("answer-requirements", requirements)["artifact_id"]
            inventory = question_inventory(question)
            refs['question_inventory'] = self.artifacts.put('question-inventory', inventory)['artifact_id']
            refs['report_budget'] = self.artifacts.put('report-budget', self.report_config)['artifact_id']
            try:
                _, plan = self._invoke(run_id, "planner", "围绕当前问题拆分主题，逐项保留全部用户要求；定义与关系题不改造成性能测评",
                    [planning_question_ref, refs["requirements"], refs['question_inventory'], refs['report_budget']])
            except PipelineExecutionError as exc:
                # A second Planner format failure should not make a public
                # question unusable.  Preserve the exact user wording as one
                # bounded query and let retrieval/review/audit decide what is
                # supportable.  This fallback never invents topics or claims.
                if exc.code not in {"MODEL_JSON_INVALID", "MODEL_SCHEMA_REJECTED"}:
                    raise
                plan = fallback_research_plan(question)
                refs["planner_fallback"] = self.artifacts.put("planner-fallback", {
                    "schema_version": "sciassistant.planner-fallback/v1",
                    "reason_code": exc.code,
                    "policy": plan["fallback_policy"],
                    "question_sha256": hashlib.sha256(str(question).encode("utf-8")).hexdigest(),
                })["artifact_id"]
                self._event({"event": "planner_format_fallback",
                             "reason_code": exc.code,
                             "artifact_id": refs["planner_fallback"],
                             "semantic_auto_approval": False})
            if plan_handoff_issues(plan, question):
                raise WorkflowError('invalid typed planning handoff')
            groups = plan.get("groups")
            if not isinstance(groups, list) or not 1 <= len(groups) <= 3:
                raise WorkflowError("invalid research groups")
            group_ids = {group.get("id") for group in groups if isinstance(group, Mapping)}
            if len(group_ids) != len(groups) or any(not isinstance(key, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", key) for key in group_ids):
                raise WorkflowError("invalid research group identifiers")
            plan, scope_validation = scope_plan_to_question(plan, requirements)
            ledger = compile_user_requirements(question, plan, inventory)
            self._skill_ledger = ledger
            self.user_requirements_ref = self.artifacts.put('user-requirements', ledger)['artifact_id']
            refs['user_requirements'] = self.user_requirements_ref
            self._event({'event': 'user_requirements_prepared', 'artifact_id': self.user_requirements_ref,
                'requirement_count': len(ledger['requirements']), 'segment_count': len(ledger['segments']),
                'classification_status': ledger['classification_status'], 'semantic_auto_approval': False})
            # Scope normalization can fold an output-only group into report
            # obligations. Retrieval permissions must use the effective IDs.
            groups = plan['groups']
            group_ids = {group['id'] for group in groups}
            if requirements.get('answer_focus', {}).get('utility_relation_requested'):
                plan['task_fit_review_policy'] = 'both-task-sides-before-application/v1'
            plan, compilation = compile_search_plan(plan,
                getattr(self.executor, "source_context", {}).get("source_scope", "arxiv"))
            refs['search_plan_compilation'] = self.artifacts.put('search-plan-compilation', compilation)['artifact_id']
            if compilation['groups']:
                self._event({'event': 'search_plan_compiled', 'artifact_id': refs['search_plan_compilation'],
                             'query_count': sum(len(g['queries']) for g in compilation['groups'])})
            plan, primary_plan = prepare_primary_source_plan(plan, question,
                getattr(self.executor, "source_context", {}).get("source_scope", "arxiv"))
            refs["primary_source_plan"] = self.artifacts.put("primary-source-plan", primary_plan)["artifact_id"]
            refs["plan_scope_validation"] = self.artifacts.put("plan-scope-validation", scope_validation)["artifact_id"]
            if scope_validation["changes"] or scope_validation.get("premise_changes") or scope_validation.get('delivery_group_changes'):
                self._event({"event": "plan_scoped_to_user_question", **scope_validation})
            refs["plan"] = self.artifacts.put("research-plan", plan)["artifact_id"]
            if plan.get('schema_version') in TYPED_PLAN_SCHEMAS:
                self.need_contract_ref = self.artifacts.put('evidence-needs', evidence_need_contract(plan))['artifact_id']
                refs['evidence_needs'] = self.need_contract_ref
                self._event({'event': 'typed_plan_handoff_prepared', 'artifact_id': self.need_contract_ref,
                             'research_groups': len(plan['groups']), 'report_obligations': len(plan.get('report_obligations', []))})
            refs['answer_focus_brief'] = self.artifacts.put('answer-focus-brief',
                answer_focus_brief(requirements, plan))['artifact_id']
            self.answer_focus_ref = refs['answer_focus_brief']
            self._event({'event':'answer_focus_prepared','artifact_id':self.answer_focus_ref,
                'before_evidence_review':True,'automatic_evidence_approval':False})
            if hasattr(self.executor, "configure_plan"):
                self.executor.configure_plan(plan)
            if hasattr(self.executor, "configure_source_clues"):
                self.executor.configure_source_clues(requirements)
            self.store.transition(run_id, "planned", details={"group_count": len(groups)})
            self.store.transition(run_id, "retrieving", details={"recovery": False})
            search_action = getattr(self.executor, "search_action", "request_arxiv_search")
            try:
                retrieval, _ = self._invoke(run_id, "retriever", "按来源范围生成每组最多两条检索动作；使用计划的已编译queries，不把query_candidates逐条转成动作", [planning_question_ref, refs["requirements"], refs["plan"]])
                search_actions, recovered_groups = complete_initial_search_actions(plan, retrieval["tool_requests"], action=search_action)
            except PipelineExecutionError as exc:
                # A malformed Retriever response must not discard a valid
                # Planner handoff.  Reuse only the queries already compiled
                # into the immutable plan; no new wording or source is
                # invented and no additional model call is made.
                if (exc.code not in {"MODEL_JSON_INVALID", "MODEL_SCHEMA_REJECTED"}
                        or not (hasattr(self.executor, "documents") or hasattr(self.executor, "local"))):
                    raise
                search_actions, recovered_groups = complete_initial_search_actions(plan, [], action=search_action)
                refs["retriever_fallback"] = self.artifacts.put("retriever-fallback", {
                    "schema_version": "sciassistant.retriever-fallback/v1",
                    "reason_code": exc.code,
                    "policy": "compiled-plan-queries-only-no-new-model-or-source",
                    "tool_request_count": len(search_actions),
                    "group_ids": [row["arguments"]["group_id"] for row in search_actions],
                })["artifact_id"]
                self._event({"event": "retriever_format_fallback",
                             "reason_code": exc.code,
                             "artifact_id": refs["retriever_fallback"],
                             "planner_fallback_group_ids": recovered_groups,
                             "semantic_auto_approval": False})
            entity_changes, source_title_changes = [], []
            if search_action == "request_arxiv_search":
                search_actions, entity_changes = prioritize_named_entity_actions(plan, search_actions, requirements)
                search_actions, source_title_changes = prioritize_source_title_actions(plan, search_actions, requirements)
            search_actions, need_title_changes = route_need_titles(plan, search_actions)
            refs["initial_search_actions"] = self.artifacts.put("initial-search-actions", {
                "schema_version": "sciassistant.initial-search-actions/v1", "tool_requests": search_actions,
                "planner_fallback_group_ids": recovered_groups, "policy": "one_query_per_topic_before_second_queries",
                "source_title_query_policy": PRIMARY_SOURCE_POLICY
                    if search_action in {"request_arxiv_search", "request_research_search"} else "not-applicable-local-document",
                "entity_priority_changes": entity_changes,
                "source_title_priority_changes": source_title_changes,
                'evidence_need_title_changes': need_title_changes,
            })["artifact_id"]
            self._event({"event": "initial_topic_search_coverage", "action_count": len(search_actions),
                         "planner_fallback_group_ids": recovered_groups, "artifact_id": refs["initial_search_actions"]})
            evidence = self._retrieve(run_id, search_actions, group_ids)
            if plan.get('schema_version') in TYPED_PLAN_SCHEMAS:
                refs['need_flow_retrieved'] = self.artifacts.put('need-flow-retrieved',
                    need_flow_snapshot(plan, search_actions, evidence))['artifact_id']
            refs["evidence"] = self.artifacts.put("evidence-set", evidence)["artifact_id"]
            source_failure = blocked_retrieval_reason(evidence)
            if source_failure:
                self._event({"event": "gap_recovery_skipped", "reason_code": source_failure,
                             "source_statuses": [r.get("source_status") for r in evidence.get("observations", []) if "query" in r]})
                raise PipelineExecutionError(source_failure)
            self.store.transition(run_id, "reviewing", details={"evidence_count": len(evidence["evidence"])})
            _, review = self._invoke(run_id, "reviewer", "逐片段审查与当前问题的相关性、覆盖及可比性", [refs["question"], refs["requirements"], refs["plan"], refs["evidence"]])
            try:
                review = check_review(review, evidence, group_ids, plan=plan)
            except ReviewContractError as exc:
                refs["invalid_review"] = self.artifacts.put("rejected-evidence-review", review)["artifact_id"]
                self._event({"event": "initial_review_contract_rejected", "reason_code": exc.code})
                if self.store.get_run(run_id)["remaining_model_calls"] < self.report_config["reserved_delivery_calls"] + 1 or self._stage_remaining() <= 130:
                    raise
                from multi_agent_quality import review_repair_feedback
                refs["review_feedback"] = self.artifacts.put("review-feedback", review_repair_feedback(review, exc.code, evidence))["artifact_id"]
                try:
                    _, corrected = self._invoke(run_id, "reviewer", "仅一次纠正审查协议：按反馈核对批准列表、逐片段决定和覆盖引用，允许partial，不自动放行", [refs["question"], refs["requirements"], refs["plan"], refs["evidence"], refs["review_feedback"]])
                except PipelineExecutionError as correction_error:
                    if correction_error.code not in {"MODEL_JSON_INVALID", "MODEL_SCHEMA_REJECTED", "MODEL_OUTPUT_TRUNCATED"}:
                        raise
                    corrected = review  # Original valid JSON, never the broken reply.
                try:
                    review = check_review(corrected, evidence, group_ids, plan=plan)
                except ReviewContractError as corrected_error:
                    refs["invalid_corrected_review"] = self.artifacts.put("rejected-evidence-review", corrected)["artifact_id"]
                    try:
                        review, report = recover_review_subset(corrected, evidence, group_ids, plan=plan)
                    except ReviewContractError:
                        raise corrected_error
                    report["input_review_artifact_id"] = refs["invalid_corrected_review"]
                    refs["review_validation"] = self.artifacts.put("validation-report", report)["artifact_id"]
                    self._event({"event": "review_subset_recovered", **report})
            refs["review"] = self.artifacts.put("evidence-review", review)["artifact_id"]
            delivery_reserve = self._reserve_initial_delivery(run_id, plan, review, refs)
            # Read existing candidates before spending calls on new searches.
            # Only live executors own the optional PDF-batch API; mock/legacy tools remain compatible.
            while not is_soft_time_policy(self.time_policy) and hasattr(self.executor, "has_more_reading"):
                missing = [row for row in review.get("coverage") or [] if row["status"] in {"missing", "partial"}]
                focus = {row["group_id"] for row in missing} or group_ids
                if review["coverage_status"] != "insufficient" and not missing:
                    self.reading_stop_reason = "coverage_sufficient" if review["coverage_status"] == "sufficient" else "qualified_research_boundary"
                    break
                if not self.executor.has_more_reading(focus):
                    stats = self.executor.reading_summary()
                    self.reading_stop_reason = "paper_or_batch_limit" if stats["papers_attempted"] >= 15 or stats["batches_used"] >= 3 else "no_more_candidates"
                    break
                if self.store.get_run(run_id)["remaining_model_calls"] < delivery_reserve + 1:
                    self.reading_stop_reason = "writer_auditor_call_reserve"
                    break
                if self.deadline - time.monotonic() <= min(130.0, self.time_budget_seconds / 2) + 10:
                    self.reading_stop_reason = "writer_auditor_time_reserve"
                    break
                previous_review = review
                before = self.executor.pdf_reads
                self.store.transition(run_id, "retrieving", details={"existing_candidate_batch": True})
                evidence = self._retrieve(run_id, [], group_ids, reading_only=True, prior=evidence, focus_groups=focus,
                                          retained_evidence_ids=previous_review["allowed_evidence_ids"])
                refs["evidence"] = self.artifacts.put("evidence-set", evidence)["artifact_id"]
                self.store.transition(run_id, "reviewing", details={"reading_summary": self.executor.reading_summary()})
                if before == self.executor.pdf_reads:
                    self.reading_stop_reason = "reading_deadline"
                    break
                review = self._followup_review(run_id, "复审下一批文献及已批准片段；逐主题逐指标更新覆盖", [refs["question"], refs["requirements"], refs["plan"], refs["evidence"], refs["review"]], previous_review, evidence, group_ids, plan, refs)
                refs["review"] = self.artifacts.put("evidence-review", review)["artifact_id"]
                delivery_reserve = self._reserve_initial_delivery(run_id, plan, review, refs)
                if review.get("recovery_status") == "rejected":
                    self.reading_stop_reason = "followup_review_rejected"
                    break
            missing = actionable_review_gaps(review, include_qualified=is_soft_time_policy(self.time_policy))
            recovery_needed = review["coverage_status"] == "insufficient" or bool(missing)
            reading = self.executor.reading_summary() if hasattr(self.executor, "reading_summary") else {}
            capacity_exhausted = (review.get("schema_version") == "sciassistant.evidence-review/v5" and bool(reading)
                and getattr(self.executor, "search_action", "request_arxiv_search") != "request_document_search"
                and (reading.get("papers_attempted", 0) >= reading.get("paper_limit", 15)
                     or reading.get("batches_used", 0) >= reading.get("batch_limit", 3)))
            recover = (recovery_needed and (self._research_elapsed() <= self.report_config['research_start_cutoff_seconds'] if is_soft_time_policy(self.time_policy) else self.deadline - time.monotonic() > 150)
                       and self.store.get_run(run_id)["remaining_model_calls"] >= delivery_reserve + 3 and not capacity_exhausted)
            if recovery_needed and not recover:
                self._event({"event": "gap_recovery_skipped", "reason_code": "PDF_READING_CAPACITY_EXHAUSTED" if capacity_exhausted else "RESEARCH_START_CUTOFF" if is_soft_time_policy(self.time_policy) and self._research_elapsed() > self.report_config['research_start_cutoff_seconds'] else "FINAL_ANSWER_BUDGET_RESERVED",
                             "required_delivery_calls": delivery_reserve, "next_research_calls": 3,
                             "remaining_model_calls": self.store.get_run(run_id)["remaining_model_calls"],
                             "remaining_seconds": round(max(0, self.deadline - time.monotonic()), 2)})
            while recover:
                self._active(run_id)
                # Recheck immediately before issuing the round's first call.
                if is_soft_time_policy(self.time_policy) and self._research_elapsed() > self.report_config['research_start_cutoff_seconds']:
                    self._event({"event": "gap_recovery_skipped", "reason_code": "RESEARCH_START_CUTOFF"})
                    break
                self._event({"event": "gap_recovery_started", "elapsed_seconds": round(self._research_elapsed(), 2), "time_policy": self.time_policy})
                recovery_context = [planning_question_ref, refs["requirements"]] if search_action == "request_research_search" else []
                review, evidence = self._recover_evidence(run_id, review, evidence, plan, missing,
                    search_actions, group_ids, recovery_context, refs)
                delivery_reserve = self._reserve_initial_delivery(run_id, plan, review, refs)
                self._event({"event": "gap_recovery_completed", "elapsed_seconds": round(self._research_elapsed(), 2),
                             "retained_approved_count": len(review["allowed_evidence_ids"])})
                if not is_soft_time_policy(self.time_policy) or review.get("recovery_status") in {"rejected", "subset"}:
                    break
                # Previously attempted recovery queries are also non-repeatable.
                if refs.get("gap"):
                    search_actions = [*search_actions, *[{"arguments": {"query": row["query"]}} for row in self.artifacts.get(refs["gap"])["gaps"]]]
                missing = actionable_review_gaps(review, include_qualified=True)
                reading = self.executor.reading_summary() if hasattr(self.executor, "reading_summary") else {}
                capacity_exhausted = (getattr(self.executor, "search_action", "request_arxiv_search") != "request_document_search"
                    and (reading.get("papers_attempted", 0) >= reading.get("paper_limit", 15) or reading.get("batches_used", 0) >= reading.get("batch_limit", 3)))
                recovery_needed = review["coverage_status"] == "insufficient" or bool(missing)
                recover = (recovery_needed and self._research_elapsed() <= self.report_config['research_start_cutoff_seconds']
                           and self.store.get_run(run_id)["remaining_model_calls"] >= delivery_reserve + 3 and not capacity_exhausted)
                if recovery_needed and not recover:
                    self._event({"event": "gap_recovery_skipped", "reason_code": "RESEARCH_START_CUTOFF" if self._research_elapsed() > self.report_config['research_start_cutoff_seconds'] else "PDF_READING_CAPACITY_EXHAUSTED" if capacity_exhausted else "FINAL_ANSWER_BUDGET_RESERVED",
                                 "required_delivery_calls": delivery_reserve, "next_research_calls": 3,
                                 "elapsed_seconds": round(self._research_elapsed(), 2), "remaining_model_calls": self.store.get_run(run_id)["remaining_model_calls"]})
            assessment = review.get("premise_assessment_validation") or checked_premise_assessments(review, plan, evidence)
            refs["premise_assessment"] = self.artifacts.put("premise-assessment", assessment)["artifact_id"]
            self._event({"event": "question_premises_reviewed", "policy": PREMISE_CHECK_POLICY,
                         "artifact_id": refs["premise_assessment"],
                         "assessed_count": len(assessment["assessments"]),
                         "unresolved_count": len(assessment["unresolved_check_ids"]),
                         "semantic_auto_approval": False})
            approved = set(review["allowed_evidence_ids"])
            if not approved:
                failure_code = "REVIEW_PROTOCOL_INCOMPLETE" if review.get("recovery_status") == "subset" else "INSUFFICIENT_EVIDENCE"
                answer = "未获得可审查证据，无法形成可靠科研结论。请查看查询结果与来源状态。"
                self.store.transition(run_id, "failed", failure_code=failure_code)
            else:
                review_decisions = {row["evidence_id"]: row for row in review.get("decisions", [])}
                if plan.get('schema_version') in TYPED_PLAN_SCHEMAS:
                    refs['need_flow_reviewed'] = self.artifacts.put('need-flow-reviewed',
                        need_flow_snapshot(plan, search_actions, evidence, review))['artifact_id']
                    self.need_flow_ref = refs['need_flow_reviewed']
                # Transport/query records belong to Workflow, not paper-backed
                # claims. Keep raw observations in evidence artifacts but do
                # not feed them as part of the Writer's approved source set.
                refs["source_execution"] = self.artifacts.put("source-execution-notice",
                    source_execution_notice(run_id, evidence))["artifact_id"]
                evidence = {**evidence, "evidence": [dict(item, citation_index=i + 1, review_status="approved", evidence_strength=evidence_strength(item))
                           for i, item in enumerate(item for item in evidence["evidence"] if item["evidence_id"] in approved)]}
                for item in evidence["evidence"]:
                    decision = review_decisions[item["evidence_id"]]
                    item["task_relevance"] = decision.get("task_relevance", "not_classified")
                    # Ignore any source/PDF-supplied labels. Only a validated
                    # Reviewer decision can label approved task-side support.
                    item.pop('task_side_roles', None)
                    if 'task_side_roles' in decision:
                        item['task_side_roles'] = list(decision['task_side_roles'])
                    if review.get("schema_version") == "sciassistant.evidence-review/v5":
                        item["source_domain"] = decision.get("source_domain", "")
                        item["source_scope_policy"] = "reviewer-v5-visible-domain/v1"
                        item["reviewed_group_ids"] = list(decision["group_ids"])
                        item["topic_association_policy"] = "planned-topics-semantic-review/v1"
                evidence = {key: value for key, value in evidence.items() if key != "observations"}
                refs["approved"] = self.artifacts.put("approved-evidence", evidence)["artifact_id"]
                observations = comparison_observations(evidence)
                self.comparison_ref = self.artifacts.put('comparison-observations', observations)['artifact_id']
                refs['comparison_observations'] = self.comparison_ref
                self._event({'event': 'comparison_observations_prepared', 'artifact_id': self.comparison_ref,
                    'table_count': len(observations['records']), 'semantic_auto_approval': False})
                refs["source_boundaries"] = self.artifacts.put("source-boundary-brief", source_boundary_brief(evidence))["artifact_id"]
                self._event({"event": "source_boundaries_prepared", "artifact_id": refs["source_boundaries"],
                             "cue_count": len(self.artifacts.get(refs["source_boundaries"])["cues"])})
                self.store.transition(run_id, "writing", details={"coverage_status": review["coverage_status"]})
                if ledger.get('classification_status') in {'explicit', 'explicit_partial'}:
                    draft = self._write_sections(run_id, ledger, plan, evidence, review, refs)
                else:
                    _, draft = self._invoke(run_id, "writer", "先核对source-boundary-brief与answer-focus-brief，再直接回答；只保留当前问题所需且有依据的结论和边界，每条一个主要断言", [refs["question"], refs["requirements"], refs["plan"], refs["approved"], refs["review"], refs["source_boundaries"], refs['answer_focus_brief']])
                draft, source_scope_format = attach_reviewed_source_scope(
                    {**draft, 'source_confidence_policy': SOURCE_CONFIDENCE_POLICY,
                     'publication_gate_policy': 'evidence-backed-limited-release/v1'}, evidence)
                draft = {**draft, "semantic_boundary_policy": SEMANTIC_BOUNDARY_POLICY,
                         "memory_component_policy": MEMORY_COMPONENT_POLICY,
                         "symbol_role_policy": SYMBOL_ROLE_POLICY,
                         "condition_denial_policy": CONDITION_DENIAL_POLICY,
                         "audit_context_policy": AUDIT_CONTEXT_POLICY,
                         "audit_quote_menu_policy": AUDIT_QUOTE_MENU_POLICY,
                         "source_role_inventory_policy": SOURCE_ROLE_INVENTORY_POLICY,
                         "term_binding_policy": TERM_BINDING_POLICY,
                         "absence_choice_policy": ABSENCE_CHOICE_POLICY,
                         "absence_menu_policy": ABSENCE_MENU_POLICY,
                         "absence_reason_policy": ABSENCE_REASON_POLICY,
                         "absence_inventory_policy": ABSENCE_INVENTORY_POLICY,
                         "witness_copy_policy": WITNESS_COPY_POLICY,
                         "witness_capacity_policy": WITNESS_CAPACITY_POLICY,
                         "short_choice_policy": SHORT_CHOICE_POLICY,
                         "passage_exclusivity_policy": PASSAGE_EXCLUSIVITY_POLICY,
                         "audit_row_retention_policy": AUDIT_ROW_RETENTION_POLICY,
                         "audit_batch_recovery_policy": AUDIT_BATCH_RECOVERY_POLICY,
                         "metric_direction_policy": METRIC_DIRECTION_POLICY,
                         "processing_observation_policy": PROCESSING_OBSERVATION_POLICY,
                         "rank_table_trend_policy": RANK_TABLE_TREND_POLICY,
                         "evaluation_role_policy": EVALUATION_ROLE_POLICY,
                         "detail_citation_policy": "report-field-evidence-mentions-within-claim-citations/v1",
                         "field_quantity_policy": "printed-item-counts-all-claim-fields/v2",
                         "answer_style_policy": ANSWER_STYLE_POLICY,
                         "scientific_review_frame_policy": SCIENTIFIC_REVIEW_FRAME_POLICY,
                         'audit_job_policy': AUDIT_JOB_POLICY,
                         'comparison_context_policy': COMPARISON_POLICY,
                         "reading_scope_policy": READING_SCOPE_POLICY,
                         "quantity_feedback_policy": QUANTITY_FEEDBACK_POLICY,
                         "absence_scope_policy": ABSENCE_SCOPE_POLICY,
                         "witness_choice_policy": WITNESS_CHOICE_POLICY,
                         "report_reference_policy": REPORT_REFERENCE_POLICY,
                         "audit_protocol_policy": AUDIT_PROTOCOL_POLICY,
                         "empty_field_absence_policy": EMPTY_FIELD_ABSENCE_POLICY}
                refs["source_scope_format"] = self.artifacts.put("source-scope-formatting", source_scope_format)["artifact_id"]
                refs["draft"] = self.artifacts.put("draft-answer", draft)["artifact_id"]
                self.store.transition(run_id, "auditing")
                audit_result, audit = self._audit(run_id, "审计声明、引用与限定语", [refs["draft"], refs["approved"], refs["review"]], draft, refs)
                require_summary = any(item.get("coverage_scope") in {"selected_chunks", "abstract"} for item in evidence["evidence"])
                issues = check_draft(draft, evidence, require_summary=require_summary) + audit.get("witness_issues", []) + audit.get("absence_issues", []) + audit.get("protocol_issues", [])
                report_enabled = draft.get('publication_review_policy') == PUBLICATION_POLICY
                recovery = None
                if report_enabled:
                    issues += conflict_issues(audit['report_review_validation'])
                    interim_audit = {**audit,'code_issues':issues}
                    delivery = publication_coverage(ledger,draft,interim_audit,publication_rejections(interim_audit,draft))
                    refs['initial_publication_coverage'] = self.artifacts.put('publication-coverage',delivery)['artifact_id']
                    recovery = recovery_brief(delivery,evidence)
                    refs['publication_recovery'] = self.artifacts.put('publication-recovery',recovery)['artifact_id']
                # An invented/spliced Auditor quotation is not a Writer defect.
                # After the one audit correction, block only affected claims;
                # do not spend a Writer revision solely on that audit fault.
                writer_issues = [row for row in issues if row not in audit.get("protocol_issues", []) and row.get("reason") not in {
                    "AUDIT_WITNESS_NOT_IN_SOURCE", "AUDIT_SOURCE_WITNESSES_INVALID"}]
                unbound_absence_ids = {row['claim_id'] for row in audit.get('protocol_issues', [])
                    if row.get('reason') == 'AUDIT_ABSENCE_REASON_WITHOUT_ASSERTION'}
                only_unbound_audit_reason = (draft.get('absence_reason_policy') == ABSENCE_REASON_POLICY
                    and bool(unbound_absence_ids) and not audit.get('contract_errors')
                    and not (set(audit.get('rejected_claim_ids', [])) - unbound_absence_ids))
                # After the single Auditor correction, a still-unbound audit
                # category quarantines its claim; it is not evidence that the
                # Writer's factual text must be rewritten. Other scientific
                # rejections still use the existing bounded Writer revision.
                if only_unbound_audit_reason and not writer_issues:
                    self._event({'event': 'audit_unbound_reason_isolated',
                        'claim_ids': sorted(unbound_absence_ids), 'writer_rewrite_requested': False,
                        'semantic_auto_approval': False})
                coverage_repair = bool(recovery and recovery['requirements'] and recovery['allowed_evidence_ids']
                    and not delivery['review_errors'])
                transport_only = bool(audit.get('source_unreviewed_claim_ids')) and not writer_issues and all(
                    r['decision']=='approved' or r['reason_code']=='AUDIT_BATCH_UNREVIEWED' for r in audit.get('claim_results',[]))
                if transport_only:
                    coverage_repair = False  # Writer cannot repair an Auditor transport/format failure.
                revise = coverage_repair or bool(writer_issues) or (not only_unbound_audit_reason and (
                    not transport_only and (audit_result["status"] == "rework_required" or audit.get("status") not in {"passed", "completed"})))
                if revise and not audit["contract_errors"] and self.store.get_run(run_id)["remaining_model_calls"] >= 1+self._revision_audit_reserve(draft) and self._stage_remaining() > 90:
                    self._reviewed_checkpoint(run_id, draft, evidence, audit, audit_result, refs, require_summary)
                    refs["citation_feedback"] = self.artifacts.put("citation-feedback", {
                        "schema_version": "sciassistant.citation-feedback/v1",
                        "code_issues": issues, "model_audit": audit,
                        "allowed_evidence_ids": [item["evidence_id"] for item in evidence["evidence"]],
                        "policy": "repair_or_remove_identified_claims_no_new_evidence",
                    })["artifact_id"]
                    refs["writer_revision_brief"] = self.artifacts.put("writer-revision-brief",
                        writer_revision_brief(draft, self.artifacts.get(refs["citation_feedback"]), evidence))["artifact_id"]
                    self._event({"event": "writer_revision_brief_prepared",
                                 "artifact_id": refs["writer_revision_brief"]})
                    if recovery:
                        self._event({'event':'publication_recovery_started',
                            'artifact_id':refs['publication_recovery'],
                            'requirement_ids':[r['requirement_id'] for r in recovery['requirements']],
                            'new_research_allowed':False,'uses_existing_revision_round':True})
                    ticket = audit_result.get("rework_ticket") or make_rework_ticket(
                        run_id=run_id, from_role="citation_auditor", to_role="writer", reason_code="CITATION_REJECTED",
                        artifact_ids=[refs["draft"]], required_changes=["删除无批准证据或无数字原文支撑的声明；不得补造证据。"],
                    )
                    if ticket["from_role"] != "citation_auditor" or ticket["to_role"] != "writer":
                        raise WorkflowError("invalid writer rework target")
                    refs["ticket"] = self._ticket(ticket)
                    self.store.transition(run_id, "writing", details={"revision": 1})
                    prior_draft = draft
                    retained_eligible = {k for r in (delivery['requirements'] if report_enabled else [])
                        if r['status']=='answered' for k in r['reviewed_claim_ids']}
                    self._revision_active = True
                    if draft.get('composition_policy') == SECTION_POLICY:
                        job = revision_job(draft['report_outline'], evidence)
                        job['assertion_policy'] = ASSERTION_POLICY
                        refs['writer_revision_job'] = self.artifacts.put('writer-job', job)['artifact_id']
                        self.writer_job_ref = refs['writer_revision_job']
                    if (draft.get('revision_delivery_policy') == REVISION_DELIVERY_POLICY
                            and len(draft['claims']) > MAX_AUDIT_CLAIMS):
                        draft = self._write_revision_sections(run_id, draft, evidence, recovery, refs)
                    else:
                        _, draft = self._invoke(run_id, "writer", "先逐条处理writer-revision-brief的实际问题字段；如有publication-recovery，只针对其中未交付要求用批准证据补写，保留正确章节。不能照抄带错字段或恢复无依据声明", [refs["question"], refs["requirements"], refs["plan"], refs["draft"], refs["ticket"], refs["approved"], refs["review"], refs["citation_feedback"], refs["source_boundaries"], refs["writer_revision_brief"], refs['answer_focus_brief'], *([refs['publication_recovery']] if recovery else [])])
                    self.writer_job_ref = None
                    if prior_draft.get('composition_policy') == SECTION_POLICY:
                        draft = project_writer_job(draft, revision_job(prior_draft['report_outline'], evidence))
                        self.section_writing_fault = self.section_writing_fault or bool(draft.get('isolated_claims'))
                        draft = {**draft, 'composition_policy': SECTION_POLICY,
                            'assertion_policy': ASSERTION_POLICY, 'precise_revision_policy': PRECISE_REVISION_POLICY,
                            'publication_review_policy': PUBLICATION_POLICY, 'audit_material_policy':AUDIT_MATERIAL_POLICY,
                            'publication_gate_policy': 'evidence-backed-limited-release/v1',
                            'revision_delivery_policy':prior_draft.get('revision_delivery_policy'),
                            'audit_delivery_policy':AUDIT_BATCH_POLICY,
                            'report_outline': prior_draft['report_outline'],
                            'batch_provenance': prior_draft['batch_provenance'],
                            'draft_requirement_observations': prior_draft['draft_requirement_observations']}
                        if report_enabled:
                            draft, retained = retain_untargeted_claims(prior_draft,draft,retained_eligible,
                                [r['requirement_id'] for r in recovery['requirements']] if recovery else [])
                            refs['pre_reaudit_retention'] = self.artifacts.put('pre-reaudit-retention',retained)['artifact_id']
                    draft, source_scope_format = attach_reviewed_source_scope(
                        {**draft, 'source_confidence_policy': SOURCE_CONFIDENCE_POLICY}, evidence)
                    draft = {**draft, "semantic_boundary_policy": SEMANTIC_BOUNDARY_POLICY,
                             "memory_component_policy": MEMORY_COMPONENT_POLICY,
                             "symbol_role_policy": SYMBOL_ROLE_POLICY,
                             "condition_denial_policy": CONDITION_DENIAL_POLICY,
                             "audit_context_policy": AUDIT_CONTEXT_POLICY,
                             "audit_quote_menu_policy": AUDIT_QUOTE_MENU_POLICY,
                             "source_role_inventory_policy": SOURCE_ROLE_INVENTORY_POLICY,
                             "term_binding_policy": TERM_BINDING_POLICY,
                             "absence_choice_policy": ABSENCE_CHOICE_POLICY,
                             "absence_menu_policy": ABSENCE_MENU_POLICY,
                             "absence_reason_policy": ABSENCE_REASON_POLICY,
                             "absence_inventory_policy": ABSENCE_INVENTORY_POLICY,
                             "witness_copy_policy": WITNESS_COPY_POLICY,
                             "witness_capacity_policy": WITNESS_CAPACITY_POLICY,
                             "short_choice_policy": SHORT_CHOICE_POLICY,
                             "passage_exclusivity_policy": PASSAGE_EXCLUSIVITY_POLICY,
                             "audit_row_retention_policy": AUDIT_ROW_RETENTION_POLICY,
                             "audit_batch_recovery_policy": AUDIT_BATCH_RECOVERY_POLICY,
                             "metric_direction_policy": METRIC_DIRECTION_POLICY,
                             "processing_observation_policy": PROCESSING_OBSERVATION_POLICY,
                             "rank_table_trend_policy": RANK_TABLE_TREND_POLICY,
                             "evaluation_role_policy": EVALUATION_ROLE_POLICY,
                             "detail_citation_policy": "report-field-evidence-mentions-within-claim-citations/v1",
                             "field_quantity_policy": "printed-item-counts-all-claim-fields/v2",
                             "answer_style_policy": ANSWER_STYLE_POLICY,
                             "scientific_review_frame_policy": SCIENTIFIC_REVIEW_FRAME_POLICY,
                             'audit_job_policy': AUDIT_JOB_POLICY,
                             'comparison_context_policy': COMPARISON_POLICY,
                             "reading_scope_policy": READING_SCOPE_POLICY,
                             "quantity_feedback_policy": QUANTITY_FEEDBACK_POLICY,
                             "absence_scope_policy": ABSENCE_SCOPE_POLICY,
                             "witness_choice_policy": WITNESS_CHOICE_POLICY,
                             "report_reference_policy": REPORT_REFERENCE_POLICY,
                             "audit_protocol_policy": AUDIT_PROTOCOL_POLICY,
                             "empty_field_absence_policy": EMPTY_FIELD_ABSENCE_POLICY}
                    refs["source_scope_format"] = self.artifacts.put("source-scope-formatting", source_scope_format)["artifact_id"]
                    refs["draft"] = self.artifacts.put("draft-answer", draft)["artifact_id"]
                    if len(draft.get('claims',[]))>80:
                        raise PipelineExecutionError('REPORT_AGGREGATE_CAPACITY_EXCEEDED')
                    revision_check = check_claim_revision(prior_draft, draft, self.artifacts.get(refs["citation_feedback"]), evidence)
                    refs["revision_check"] = self.artifacts.put("claim-revision-check", revision_check)["artifact_id"]
                    self._event({"event": "claim_revision_checked", "artifact_id": refs["revision_check"],
                                 "unresolved_claim_ids": [row["claim_id"] for row in revision_check["code_issues"]]})
                    self.store.transition(run_id, "auditing", details={"revision": 1})
                    audit_result, audit = self._audit(run_id, "最终复审：对照原拒绝理由，核实核心断言是否真正修正，不能仅凭新增限制说明批准", [refs["draft"], refs["approved"], refs["review"], refs["citation_feedback"], refs["revision_check"]], draft, refs)
                    issues = check_draft(draft, evidence, require_summary=require_summary) + revision_check["code_issues"] + audit.get("witness_issues", []) + audit.get("absence_issues", []) + audit.get("protocol_issues", [])
                    if report_enabled:
                        issues += conflict_issues(audit['report_review_validation'])
                elif revise and not audit['contract_errors']:
                    self._event({'event':'writer_revision_skipped',
                        'reason_code':'FULL_REAUDIT_BUDGET_NOT_AVAILABLE' if self.store.get_run(run_id)['remaining_model_calls'] < 1+self._revision_audit_reserve(draft) else 'REVISION_STAGE_TIME_NOT_AVAILABLE',
                        'required_model_calls':1+self._revision_audit_reserve(draft),
                        'remaining_model_calls':self.store.get_run(run_id)['remaining_model_calls'],
                        'approved_body_not_auto_rejected':True})
                if audit_result["status"] == "rework_required" and audit.get("status") == "passed":
                    audit = {**audit, "status": "needs_review", "contract_errors": [
                        *audit.get("contract_errors", []), "AUDIT_AGENT_STATUS_INCONSISTENT"]}
                audit = {**audit, "code_issues": issues}
                refs["audit"] = self.artifacts.put("citation-audit", audit)["artifact_id"]
                refs["publication"] = self.artifacts.put("publication-decisions", publication_decisions(audit, draft, refs["audit"]))["artifact_id"]
                rejected = publication_rejections(audit, draft)
                if report_enabled:
                    delivery = publication_coverage(ledger,draft,audit,rejected)
                    refs['publication_coverage'] = self.artifacts.put('publication-coverage',delivery)['artifact_id']
                    self._event({'event':'publication_coverage_checked','artifact_id':refs['publication_coverage'],
                        'unresolved_requirement_ids':delivery['unresolved_requirement_ids'],
                        'all_content_answered':delivery['all_content_answered'],
                        'recovery_stop_reason':'bounded_revision_used_or_insufficient_budget' if delivery['unresolved_requirement_ids'] else 'no_gap'})
                audit_failed = bool(issues) or audit.get("status") not in {"passed", "completed"} or audit_result["status"] == "rework_required" or bool(rejected)
                if audit_result["status"] == "rework_required" and not rejected:
                    rejected = {item.get("claim_id") for item in draft.get("claims") or [] if isinstance(item, Mapping)} or {"draft"}
                self._event({"event": "claim_publication_decision", "claim_count": len(draft.get("claims", [])),
                             "blocked_claim_ids": sorted(rejected), "contract_errors": audit.get("contract_errors", []),
                             "approved_evidence_count": len(evidence["evidence"])})
                answer = render_claims(draft, evidence, rejected=rejected, plan=plan)
                if not answer:
                    answer = "已有资料，但无法形成通过引用审计的结论，请人工复核。"
                status = "needs_review" if audit_failed or review["coverage_status"] == "needs_review" else ("completed" if review["coverage_status"] == "sufficient" else "partial")
                if report_enabled and not delivery['all_content_answered']:
                    status = 'needs_review' if delivery['review_errors'] or not delivery['consistency_verified'] or any(
                        r['status']=='needs_review' for r in delivery['requirements']) or audit_failed else 'partial'
                if ledger.get('classification_status') == 'explicit_partial':
                    status='needs_review'
                    self._event({'event':'input_classification_needs_review',
                        'user_requirements_artifact_id':refs['user_requirements'],
                        'unclassified_segment_ids':[s['segment_id'] for s in ledger['segments'] if s['disposition']=='unclassified'],
                        'approved_claims_not_auto_rejected':True})
                if self.section_writing_fault:
                    status = 'needs_review'
                if (draft.get("audit_protocol_policy") == AUDIT_PROTOCOL_POLICY
                        and not any(row["claim_id"] not in rejected for row in draft.get("claims", []))):
                    local_document = getattr(self.executor, "source_context", {}).get("source_scope") == "uploaded_pdf"
                    if local_document and evidence.get("evidence"):
                        # A parsed and reviewed private document still has
                        # useful, auditable material even when every Writer
                        # synthesis is isolated. Keep the task usable without
                        # publishing any rejected claim.
                        status, failure_code = "needs_review", None
                        answer = render_approved_evidence_fallback(evidence)
                        self._event({"event": "approved_evidence_fallback_rendered",
                                     "reason_code": "NO_AUDITED_CLAIMS",
                                     "approved_evidence_count": len(evidence.get("evidence", [])),
                                     "published_claim_count": 0,
                                     "semantic_auto_approval": False})
                    else:
                        status, failure_code = "failed", "NO_AUDITED_CLAIMS"
                        answer = "已获得资料，但没有任何声明通过完整引用审查，未能交付可用科研回答。请查看逐声明审查与隔离原因。"
                        if self.general_fallback is not None:
                            try:
                                permit = self.store.reserve_model_call(run_id, "general_fallback")
                                general_answer = self.general_fallback(question, failure_code, permit)
                                self.store.publish_degraded(run_id, failure_code=failure_code,
                                    details={"reason": failure_code, "source_backed": False})
                                status = "needs_review"
                                fallback_generated = True
                                answer = (
                                    "## 降级回答：现有证据未形成可发布声明\n\n"
                                    "本轮资料没有形成通过引用审查的声明，下面先给出基于模型通用知识的解释。"
                                    "这部分不是本轮论文核验结论，也不包含虚构引用；如果需要可核验结论，请稍后重试或补充资料。\n\n"
                                    + str(general_answer).strip()
                                )
                                self._event({"event": "general_fallback_published", "reason_code": failure_code,
                                             "source_backed": False})
                            except Exception as fallback_exc:
                                failure_code = getattr(fallback_exc, "code", "MODEL_SERVICE_UNAVAILABLE")
                if not fallback_generated:
                    self.store.transition(run_id, status, failure_code=failure_code, details={"coverage_status": review["coverage_status"], "audit_status": audit.get("status")})
        except KeyboardInterrupt:
            failure_code = "USER_CANCELLED"
            answer = "任务已取消，已完成的查询和工件保留供检查。"
            self.store.force_terminal(run_id, "cancelled", failure_code=failure_code)
        except Exception as exc:
            restored = self._restore_reviewed_checkpoint(run_id, refs, exc) if isinstance(exc, PipelineExecutionError) else None
            current = self.store.get_run(run_id)
            fallback_generated = False
            if restored:
                failure_code = None
                answer = restored
            else:
                failure_code = (current["failure_code"] if current["status"] in TERMINAL_STATUSES else
                                exc.code if isinstance(exc, (PipelineExecutionError, ReviewContractError)) else
                                "PIPELINE_CONTRACT_REJECTED" if isinstance(exc, (WorkflowError, AgentContractError)) else
                                "PIPELINE_FAILED")
                if (self.general_fallback is not None
                        and failure_code in self.GENERAL_FALLBACK_FAILURE_CODES
                        and current["status"] not in {"completed", "partial", "needs_review", "timed_out", "cancelled"}):
                    try:
                        permit = self.store.reserve_model_call(run_id, "general_fallback")
                        answer = self.general_fallback(question, failure_code, permit)
                        self.store.publish_degraded(run_id, failure_code=failure_code,
                                                    details={"reason": failure_code, "source_backed": False})
                        fallback_generated = True
                        self._event({"event": "general_fallback_published", "reason_code": failure_code,
                                     "source_backed": False})
                    except Exception as fallback_exc:
                        failure_code = getattr(fallback_exc, "code", "MODEL_SERVICE_UNAVAILABLE")
                if not fallback_generated and current["status"] not in TERMINAL_STATUSES:
                    self.store.force_terminal(run_id, "failed", failure_code=failure_code)
            if not restored and not fallback_generated:
                answer = "多智能体流水线未能安全完成，请查看脱敏运行报告。"
            if restored:
                pass  # The exact reviewed body is rendered above; status holds the warning.
            elif fallback_generated:
                answer = (
                    "## 降级回答：文献证据暂时不可用\n\n"
                    "本轮公开文献检索或证据服务暂时不可用，下面先给出基于模型通用知识的解释。"
                    "这部分不是本轮论文核验结论，也不包含虚构引用；待检索恢复后可重新运行以补充文献依据。\n\n"
                    + str(answer).strip()
                )
            elif failure_code == "RETRIEVAL_SOURCE_UNREACHABLE":
                answer = "本轮文献来源不可达，未能完成检索；无法据此判断是否存在相关研究。请查看逐查询来源状态，稍后再试。"
            elif failure_code == "RETRIEVAL_SOURCE_RATE_LIMITED":
                answer = "本轮文献来源触发限流或处于冷却，未取得可审查资料；这不代表没有相关研究。请查看已保存的逐查询记录，稍后再试。"
            elif failure_code == "RETRIEVAL_SOURCE_DEADLINE":
                answer = "本轮文献请求未能在检索等待预算内完成，尚无法评判证据是否充分。已保存逐查询记录；请稍后再试。"
            elif failure_code in {"LOCAL_PDF_PARSE_FAILED", "LOCAL_PDF_TEXT_EMPTY", "LOCAL_PDF_READ_FAILED"}:
                answer = "上传 PDF 未能提取可检索的原文。请检查文件是否损坏、加密或仅含扫描图片；本轮没有联网补造证据。"
        state = self.store.get_run(run_id)
        reading = self.executor.reading_summary() if hasattr(self.executor, "reading_summary") else None
        if reading and reading["remaining_candidates"] and (reading["batches_used"] >= 3 or reading["papers_attempted"] >= 15):
            self.reading_stop_reason = "paper_or_batch_limit"
        elif reading and self.reading_stop_reason == "no_more_candidates" and reading["remaining_candidates"]:
            # Recovery may introduce new candidates after the local pool was exhausted.
            self.reading_stop_reason = "bounded_recovery_completed"
        budget = {"schema_version": "sciassistant.budget-measurement/v1", "model_call_limit": state["max_model_calls"],
                  "report_profile": self.report_config['report_profile'], 'report_budget_policy': self.report_config['policy'],
                  'reserved_delivery_calls': self.report_config['reserved_delivery_calls'],
                  'initial_delivery_budget_policy': INITIAL_DELIVERY_BUDGET_POLICY,
                  'initial_delivery_budget': self.artifacts.get(refs['initial_delivery_budget']) if refs.get('initial_delivery_budget') else None,
                  "time_policy": self.time_policy, "time_budget_is_estimate": is_soft_time_policy(self.time_policy),
                  "research_start_cutoff_seconds": self.report_config['research_start_cutoff_seconds'] if is_soft_time_policy(self.time_policy) else None,
                  "model_calls_used": state["model_calls_used"], "time_budget_seconds": self.time_budget_seconds,
                  "elapsed_seconds": round(time.monotonic() - started, 2),
                  "remaining_seconds": round(max(0, self.deadline - time.monotonic()), 2),
                  "reading_stop_reason": self.reading_stop_reason, "stages": self.stage_usage,
                  "reading": reading,
                  "candidate_reading_decisions": self.executor.reading_decisions(self.reading_stop_reason) if hasattr(self.executor, "reading_decisions") else [],
                  "budget_suitability": "requires_live_quality_evaluation"}
        if refs.get("evidence"):
            if not refs.get("source_execution"):
                refs["source_execution"] = self.artifacts.put("source-execution-notice",
                    source_execution_notice(run_id, self.artifacts.get(refs["evidence"])))["artifact_id"]
            presented = self.artifacts.get(refs["evidence"]).get("evidence", [])
            decisions = {row["evidence_id"]: row for row in self.artifacts.get(refs["review"]).get("decisions", [])} if refs.get("review") else {}
            for row in budget["candidate_reading_decisions"]:
                base = re.sub(r"v\d+$", "", row["paper_id"])
                packets = [p for p in presented if re.sub(r"v\d+$", "", p.get("paper_id", "")) == base]
                row["presented_packets"] = len(packets)
                row["approved_packets"] = sum(decisions.get(p["evidence_id"], {}).get("decision") == "approved" for p in packets)
                row["review_decisions"] = [decisions[p["evidence_id"]] for p in packets if p["evidence_id"] in decisions]
                row["evidence_selection_status"] = ("approved" if row["approved_packets"] else "reviewer_rejected" if row["review_decisions"]
                                                     else "indexed_not_presented" if row["reading_status"] == "pdf_indexed" else "not_indexed")
        refs["budget"] = self.artifacts.put("budget-measurement", budget)["artifact_id"]
        diagnostics = evidence_flow_diagnostics(
            self.artifacts.get(refs["requirements"]) if refs.get("requirements") else {},
            self.artifacts.get(refs["evidence"]) if refs.get("evidence") else {},
            self.artifacts.get(refs["review"]) if refs.get("review") else {},
            self.artifacts.get(refs["draft"]) if refs.get("draft") else {},
            self.artifacts.get(refs["audit"]) if refs.get("audit") else {})
        refs["evidence_flow"] = self.artifacts.put("evidence-flow", diagnostics)["artifact_id"]
        summary = answer_scope_summary(self.artifacts.get(refs["plan"]) if refs.get("plan") else {},
            self.artifacts.get(refs["draft"]) if refs.get("draft") else {},
            self.artifacts.get(refs["approved"]) if refs.get("approved") else {},
            self.artifacts.get(refs["audit"]) if refs.get("audit") else {})
        refs["answer_scope"] = self.artifacts.put("answer-scope", summary)["artifact_id"]
        if hasattr(self.executor, "routing_summary"):
            refs["source_routing"] = self.artifacts.put("source-routing", self.executor.routing_summary())["artifact_id"]
        final = {"schema_version": "sciassistant.final-result/v1", "run_id": run_id,
                 "status": self.store.get_run(run_id)["status"], "failure_code": failure_code,
                 "direct_answer": answer, "artifact_refs": refs}
        final_id = self.artifacts.put("final-result", final)["artifact_id"]
        self._event({"event": "workflow_finished", "status": final["status"], "failure_code": failure_code,
                     "final_artifact_id": final_id})
        return {"run": self.store.get_run(run_id), "final_artifact_id": final_id, "direct_answer": answer}
