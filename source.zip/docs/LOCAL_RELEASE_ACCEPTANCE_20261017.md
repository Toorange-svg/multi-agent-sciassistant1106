# 本地候选发布统一验收（执行版）

范围 2/3/5；范围1科研质量微调暂停，范围4服务器/域名/HTTPS按用户指令延期。
先读 `RELEASE_AND_RESTORE_20261017.md`。不重复启动已通过的付费科研题，不改历史 run。

## A. 冻结源码与零费用回归

- 对照交付 `release.json` 的 source_fingerprint 和 manifest，不以当前 HEAD 或旧测试数替代。
- `freeze_release verify` 校验 ZIP 全集与每文件 SHA；在 `source/` 跑 repo-check。
- 运行 `tests/test_freeze_release.py`、`tests/test_account_backup.py`、`tests/test_frontend_send_button.py` 与既有账户/前端专项。
- 全量 pytest 使用独立日志与测试状态，不能读写线上 owner/keys/vector。
- Git 当前分支、HEAD、50项暂存及 index SHA 必须与冻结前一致。本地 release 分支允许新增，不推送。

## B. 浏览器与账户隔离

- 优先只读复核 `logs/research_web_validation/release-tenant-20261017-01/tenant_result.json`、`release-web-20261017-05/result.json`。
- 若重跑，使用全新 run-id；这是实际浏览器/API/MySQL + 固定模型，不是科研质量验收。
- 逐项核查：登录和 Key 引导；不同账户 key/files/tasks/report/assets 隔离；输入启用真正发送按钮且附件仍是回形针；原生文件选择→上传→发送→实质报告→追问复用→刷新恢复；引用点击→页码/框；认证 MD 下载。
- 1366/877/462截图与真实鼠标拖拽；删除500不得清正文，迟到列表不得抢回会话；取消后外层与Workflow均终态；临时网关重启不自动重跑。
- A=200/B=404/匿名401，报告资产URL无token。日志不能保存JWT/密码/原始供应商响应。
- 曾失败的02/03/04 run保留；发送按钮误选已由05实测关闭，不倒改前次结果。

## C. 发布包

- 白名单必须包含运行时 source identity 全集、锁文件、Docker配置、`deploy/mysql-init/001_schema.sql`。
- 不含真实 env/数据库/日志/文献/模型。ZIP与source目录同字节；运行模型另交。
- 发布分支是独立快照，不是把当前50项暂存代提交。
- 工具故障、篡改、缺文件、未知条目、覆盖现有发布目录或分支须失败。

## D. 本地恢复预演

- 只读复核 `backup_restore_staging/release-restore-20261017-03/result.json`。
- 真实mysqldump/mysql + 两个全新测试库；校验schema、口令哈希、会话、五目录、owner/终态、密钥隔离、错误主密钥与篡改包拒绝。
- 如需重跑，只能用新测试库/目录；不得导入产品数据库，不得自动DROP保留库。
- 本地fixture恢复 ≠ 生产数据/Qdrant/Linux卷灾备。生产master key备份必须单独确认。

## E. 当前5000与延期项

- 读取本项目启动器 StatusOnly，code_matches必须true；需要维护时先验项目归属和无活动任务，仅5000可重启。
- 本批服务器/域名/HTTPS/Docker构建/生产灾备明确未执行，不能要求下位Agent擅自启动。
- 本批不关闭任何既有科研语义疑点，不以mock回答替代真实模型质量结果。

输出五件套：result.md、test_summary.json、browser_and_account_checks.json、release_snapshot_checks.json、local_restore_checks.json。
分别结论：本地浏览器功能、候选版本冻结、本地恢复、科研质量（不在本批）、生产部署（延期）。
