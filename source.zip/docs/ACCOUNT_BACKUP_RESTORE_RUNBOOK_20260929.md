# SciAssistant 账户部署备份与恢复预检手册

日期：2026-09-29

工具：`tools/account_backup.py`

当前实现提交：`1e993be`

## 1. 能力边界

该工具处理的是已经由运维人员一致性导出的离线材料：

- 一个 MySQL SQL dump；
- `logs`、`uploads`、`user_files`、`web_uploads`、`arxiv` 五个持久化目录；
- 明确的源码 revision。

它可以：

- 创建带 SHA-256、大小、UTC 时间和布局版本的备份目录；
- 拒绝符号链接、Windows 重解析点、特殊文件、路径穿越、额外文件和缺失目录；
- 检测内容篡改、SQL dump 非法、源文件在复制期间变化、文件/容量上限超限；
- 验证备份后，将内容复制到一个原本不存在的新 staging 目录；
- 在发布 staging restore 前再次校验复制结果；
- 输出只含检查代码和计数的 JSON，不回显绝对路径或文件内容。

它不会：

- 连接 MySQL、Docker、产品服务或模型供应商；
- 自动暂停线上写入或证明上游导出时已经一致；
- 把 SQL 导入数据库、覆盖现有目录或替换 Docker 命名卷；
- 加密或签名备份；SHA-256 能发现内容变化，但不能证明备份来自可信操作者；
- 保留 ACL、扩展属性或平台特有元数据；
- 代替隔离环境中的真实 MySQL restore 与产品回归。

因此 `restore-stage` 成功的准确含义是“备份包结构和内容通过校验，并已安全复制到新目录”，不是“灾难恢复演练已经完成”。

## 2. 输入目录与备份结构

离线导出根目录必须具有以下五个直接子目录，空目录也必须存在：

```text
export-root/
├── logs/
├── uploads/
├── user_files/
├── web_uploads/
└── arxiv/
```

MySQL dump 单独提供。工具要求非空文本中至少存在 `CREATE TABLE`；它不解析业务数据，也不会将内容写入 JSON 报告。

生成的备份目录：

```text
backup.sciassistant-backup/
├── manifest.json
└── payload/
    ├── database.sql
    └── data/
        ├── logs/
        ├── uploads/
        ├── user_files/
        ├── web_uploads/
        └── arxiv/
```

`manifest.json` 只包含相对路径、字节数、SHA-256、revision、UTC 时间和固定布局信息，不包含源目录绝对路径、JWT、数据库密码或文件正文。

## 3. 一致性导出前提

生产导出必须在授权维护窗口完成。推荐顺序：

1. 确认当前 revision、部署项目名、命名卷和可用磁盘空间。
2. 停止账户网关与共享 MCP 的新写入，数据库暂时保持运行。
3. 使用部署环境的私有凭据生成 MySQL dump，不把密码放入报告、Shell 历史或命令行参数。
4. 在应用仍保持停止写入的期间，把五个命名卷导出为上述目录。
5. 完成导出后再恢复服务。
6. 在离线主机运行本工具创建并校验备份。

不同托管平台的卷导出和凭据注入方式不同，本仓库不提供一个可能误操作生产卷的通用复制命令。运维报告必须记录“如何阻止写入、如何导出、停写起止时间和返回码”，但不得记录密码值。

如果无法证明导出期间停止写入，只能把包标记为 `consistency not established`，不能因为本工具校验通过就宣称它是可恢复的一致性备份。

## 4. 创建备份包

在仓库根目录执行，输出必须位于仓库和导出源之外，并且目标不得预先存在：

```powershell
venv\Scripts\python.exe tools/account_backup.py create `
    --source-root D:\secure-export\data `
    --database-dump D:\secure-export\database.sql `
    --output E:\encrypted-backups\backup-20260929.sciassistant-backup `
    --revision 1e993be
```

成功返回码为 0，输出 JSON 的 `passed=true`、`operation=create`、检查码为 `bundle_created`。失败返回码为 2，错误 JSON 不含输入路径或异常正文。

默认上限：

- 200,000 个文件（包含 database.sql）；
- 50 GiB 总数据；
- 4 MiB manifest。

只有经过容量评审才使用 `--max-files` 或 `--max-bytes` 调整，不能为了绕过异常包而随意放大。

## 5. 独立验证

备份创建完成后、复制到异地介质后以及每次恢复前都应重新执行：

```powershell
venv\Scripts\python.exe tools/account_backup.py verify `
    --bundle E:\encrypted-backups\backup-20260929.sciassistant-backup
```

要求返回码 0、`passed=true`、检查码 `bundle_verified`。工具会比较 manifest 与实际文件集合、大小和 SHA-256；增加、删除、修改或重命名任何文件都应失败。

## 6. 安全恢复到 staging

目标目录必须不存在，工具永远不会合并或覆盖已有目录：

```powershell
venv\Scripts\python.exe tools/account_backup.py restore-stage `
    --bundle E:\encrypted-backups\backup-20260929.sciassistant-backup `
    --target D:\isolated-restore\restore-20260929
```

成功后再次验证新目录：

```powershell
venv\Scripts\python.exe tools/account_backup.py verify `
    --bundle D:\isolated-restore\restore-20260929
```

恢复到 staging 后的后续步骤仍需单独授权：

1. 建立独立的 MySQL 实例和全新测试卷，禁止指向生产卷。
2. 导入 `payload/database.sql`，记录 MySQL 返回码和表数量。
3. 将五个数据目录复制到对应的全新测试卷。
4. 使用匹配 revision 的镜像启动隔离 staging。
5. 执行健康检查、登录、会话/文件/任务归属、下载和抽样内容核对。
6. 记录恢复时间目标和数据时间点目标。
7. 只有人工批准后才能规划正式切换；本工具不执行切换。

## 7. 敏感信息与保存策略

- 备份包含账号数据、密码哈希、上传文件和任务材料，必须按最高敏感等级处理。
- 备份不得进入 Git、普通聊天附件、公开对象存储或未加密移动介质。
- 建议在存储层启用加密、不可变保留、独立访问控制和审计日志。
- SHA-256 manifest 应随加密包保存；需要来源真实性时，再由组织密钥对 manifest 做外部签名。
- 定期从异地副本执行隔离 restore drill；“备份任务成功”不等于“能够恢复”。
- 删除过期备份属于破坏性操作，应按组织保留策略和双人复核执行，本工具不提供删除命令。

## 8. 当前已验证与仍待验证

已在 Windows 离线环境验证：

- 合成 MySQL dump 和五目录的创建、验证、staged restore、二次验证；
- 空目录保留；
- 内容篡改、额外文件、manifest 注入、路径穿越、链接/重解析点、覆盖目标、非法 revision、非法 SQL 和容量上限拒绝；
- CLI 返回码、JSON 结构及路径/正文不回显；
- 全量 Python 回归。

仍需 Linux/Docker staging 验证：

- 实际命名卷的一致性导出；
- 真实 MySQL dump 导入；
- 五个卷恢复后的权限与所有者；
- 新实例健康、账号登录、跨账号隔离及抽样数据正确性；
- 加密、异地保存、保留策略、RTO/RPO 和正式切换流程。
