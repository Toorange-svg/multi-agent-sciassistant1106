# PyMuPDF：AGPL 部署路径（2026-10-21）

项目负责人已选择开源许可路径，不声明购买商业许可证。
本说明替代旧部署指南中“生产仅接受 commercial”的限制；不是法律意见或合规完成证明。

## 许可边界

PyMuPDF/MuPDF 的 AGPL-3.0 义务与本项目原始代码的 Apache-2.0 声明同时需要处理。
不删除原作者版权、Apache LICENSE/NOTICE 或第三方许可；不能仅以 Apache 声明覆盖整个组合。
AGPL 涉及网络用户的对应源码获取权，具体组合范围须按实际依赖和集成方式核查。
参考 https://pymupdf.readthedocs.io/en/latest/faq/index.html 与
https://www.gnu.org/licenses/agpl-3.0.html 。不收费或科研用途不自动豁免。

## 发布前必须完成（当前尚未全部完成）

1. 冻结实际部署版本的完整对应源码，包括修改、构建/安装脚本、版本锁和配置模板。
   `tools/freeze_release.py` 可生成并校验项目源码包；它只覆盖项目允许清单，
   不能替代核查完整对应源码范围，也不包含 PyMuPDF/MuPDF 等依赖源码。
2. 准备与实际安装版本一致的 AGPL 依赖对应源码和适用构建材料，保留许可证全文、
   修改记录及归属。仅提供上游首页、wheel 或 Docker 镜像不视为完成此项。
3. 为所有实际网站用户提供清晰、可访问、无额外收费的对应源码获取入口，
   精确对应部署版本。检查下载内容和版本，而不只检查 HTTP 200。
   不要求将私人 PDF、API Key、密码、数据库或会话内容公开。
4. 在网站可见位置提供“开源许可与对应源码”入口及 AGPL 许可说明；
   2026-10-23已在登录页与聊天侧栏实现`/open-source`。完整配置与运行指纹绑定后显示链接/SHA，
   缺配置或错版本503且明确未交付；本地Chrome实际入口点击通过。
   **页面实现不等于实际对应源码材料已发布/已核完整**，不能因预检通过就声称全部完成。
5. 完成上述检查后才在服务器私有配置设置：

```dotenv
PYMUPDF_LICENSE_MODE=agpl
PYMUPDF_COMMERCIAL_LICENSE_CONFIRMED=false
PYMUPDF_AGPL_OBLIGATIONS_CONFIRMED=true
PYMUPDF_CORRESPONDING_SOURCE_CONFIRMED=true
PYMUPDF_SOURCE_URL=https://实际源码发布地址/对应版本
SCIASSISTANT_SOURCE_FINGERPRINT=实际运行源码的64位SHA256指纹
SCIASSISTANT_SOURCE_ARCHIVE_SHA256=实际可下载对应源码材料包的64位SHA256
```

不要直接复制占位地址。预检只校验模式、人工确认和 URL 形态，不会联网验证源码完整性，
新版网页只在全部确认和版本绑定通过后展示URL；不合格时不泄露误配置地址。
尚未准备材料时保持 false/review-required；普通用户启动预检同样不自动设置这些值。

## 构建

基础镜像和 RAG 应用使用相同源码版本。构建基础应用时使用
`--build-arg PYMUPDF_LICENSE_MODE=agpl`，不要沿用旧文档中的 commercial 参数。
此参数仅标记镜像使用路径；构建成功不证明许可材料已交付。
当前未执行本批 Docker 构建、服务器部署或对外发布。
