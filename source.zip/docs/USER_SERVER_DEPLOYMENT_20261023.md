# 普通用户 Linux 部署交接（无 sudo）

本轮暂停回答质量调整，只准备网页、启动、恢复和源码交付。这里是操作说明，**不是服务器已通过报告**。
已知目标 Ubuntu 22.04/x86_64，srp 无 sudo、现有 Python 3.10；当前锁要求 **CPython 3.11/Linux x86_64**。
不能复制 Windows venv，不能用系统 3.10 安装后声称匹配，也不应在共享服务器自行更改权限/防火墙/系统数据库。

## 部署方需要提供的东西

1. 可用的 3.11 解释器及 venv/ensurepip（由管理员提供，或经批准的用户目录解释器）。本工具不下载/安装解释器。
2. 现有 MySQL 8 专用应用账户及已迁移空库，运行用户只需应用 CRUD 权限；建库/迁移由独立授权账户完成。
   应用当前使用默认 MySQL TCP 端口3306，不凭空承诺其他端口已支持。
3. 单独托管的 MCP 及共享服务认证，Qdrant 的受保护 HTTPS 地址和独立 Key；内部服务不对公网直开。
   普通用户方案不要求 Docker，但也不会自动替代这两个服务。无管理员不等于可以省略它们。
4. 已导出的 multilingual-e5-small CPU 模型（384维），按可信渠道交付并记录目录/文件哈希。
5. 一个可写的独立应用目录及持久存储空间、后台托管方式；域名/反向代理/HTTPS由有权限的负责人落实。
6. 实际对应源码下载材料和地址，确认后填写版本指纹与包SHA，不能把模板确认项直接改true冒充交付。

不要在聊天、命令参数或工单中粘贴密码、私钥、完整.env。服务器地址、SSH用户名/端口及认证方式可单独提供；本轮尚未获得可供工具连接的目标信息。

## 解包和安装

使用本轮新生成候选目录中的 `source/`，原开发目录、旧候选包保持不变。先在可信渠道核对release.json及source.zip SHA，运行：

```bash
# 以下均在新解包的 source 目录；python3.11 必须已经存在。
python3.11 -m venv .venv
.venv/bin/python -m pip install --require-hashes --no-deps -r deepdiver_v2/requirements.cloud.hashes.txt
.venv/bin/python -m pip install --require-hashes --no-deps --extra-index-url https://download.pytorch.org/whl/cpu -r deepdiver_v2/requirements.rag.cloud.hashes.txt
.venv/bin/python -m pip check
.venv/bin/python tools/rag_cloud.py verify-installed
```

固定锁会拒绝缺包/版本不符/额外运行包；下载失败应保留错误定位，不取消hash或改成无约束升级。wheel镜像可以由部署方提供，但须匹配固定SHA。
模型不包含在小源码ZIP中，可在已有缓存机器运行 `tools/export_embedding_model.py --output <全新导出目录>` 后单独交付。

复制 `deploy/user-server.env.example` 至**应用目录之外**的私有配置文件，例如用户的专用配置目录；Linux权限0600、所属用户为运行者。只编辑这一私有副本。
不要同时在release根目录或deepdiver_v2/config创建旧.env；启动预检拒绝这种不透明fallback。

配置使用 `MYSQL_USER/MYSQL_PASSWORD`（普通用户工具），不是Compose中的 `MYSQL_APP_*`；两份模板不可直接混用。
全局DeepSeek、Llama、Embedding Key保持空；注册用户通过“我的 API Keys”自行填写。签名密钥与凭据加密主密钥独立、长期稳定。

## 预检和启动

```bash
.venv/bin/python tools/user_server.py check --env-file /absolute/private/server.env
.venv/bin/python tools/user_server.py serve --env-file /absolute/private/server.env
```

`check`：校验Linux/x86_64/3.11/venv、私有配置、loopback非特权端口、个人Key边界、源码绑定，随后检查依赖、MySQL schema、CPU模型、保护向量服务和MCP健康。只产生必要的探针/锁记录；不建库、不迁移、不调用回答模型，不打印配置值。
`serve`：预检通过才以当前venv前台执行Gunicorn，**1 worker/4 threads**，不daemon、不sudo、不杀占用端口的旧进程。由运维选用用户级托管器；SSH退出后是否继续运行/开机启动，需在目标环境确认。没有linger或系统服务权限时不要承诺重启自启。
进程只监听127.0.0.1的1024以上端口。SSH隧道可供私有预览，但不能算公网HTTPS通过。已有HTTPS反代超时需覆盖在途科研阶段，不能以360/720秒为硬切断保证。
多用户共用数据仍以MySQL为账户权威；该工具不切换SQLite账户库。

## 状态与回滚

本工具把owner、任务、凭据、PDF绑定、资料库及RAG状态固定到当前release的logs子树，旧五个持久目录为：
`logs / uploads / user_files / web_uploads / arxiv`。版本升级时不能只换源码后忘记这些目录。

1. 先停止接收新任务，确认无运行/排队任务，再由托管器优雅停服务；不要无差别kill Python。
2. 用数据库备份与停写后的五目录制作一致性备份；外部Qdrant做独立快照，模型记录版本/哈希。
3. 私有配置和凭据主密钥单独加密保存。备份工具本身不加密，源码ZIP不是数据备份。
4. 恢复到**全新目录和全新数据库**，不能覆盖原生产库/原状态目录。重新校验文件SHA、SQLite、登录、个人Key解密、A/B隔离、历史引用资产及新任务。
5. 失败时回到旧release和它原来的库/目录；不让旧代码直接打开已被新版本迁移的生产库。若已迁移，使用对应旧版一致性备份另建库。
6. 只有新实例验收通过才切换反代，保留可恢复旧版。SQLite须用backup API或完全停写关闭，不能漏WAL。

## 源码页面

登录页和聊天侧栏提供 `/open-source`。配置完整且 `SCIASSISTANT_SOURCE_FINGERPRINT` 等于**运行进程指纹**才显示下载链接和SHA；未配置/旧版本绑定则503并明确提示未交付。
`PYMUPDF_SOURCE_URL` 必须是无凭据、无token查询参数的公开HTTPS地址。
`SCIASSISTANT_SOURCE_ARCHIVE_SHA256` 应是**实际对应源码材料包**的SHA，不一定是仅含项目代码的source.zip。
源码材料必须由负责人检查实际部署版本的项目、必要依赖源码及构建/安装材料；本工具不自动作许可完整性结论。
本轮仅实现页面/版本绑定，不把未发布的源码地址、依赖源码归档或法律核查算作通过。

## 上线前在目标机执行

同一源码版本的health/readyz/science.readyz、code_matches=true；外部真实访问和TLS；一次本文/一次公开任务，引用与认证下载；并发排队/取消/重启；新目录新库恢复和回滚；源码链接下载与实际材料SHA核对。
本地Windows测试、模拟供应商和源码ZIP验证不能替代以上结果。
