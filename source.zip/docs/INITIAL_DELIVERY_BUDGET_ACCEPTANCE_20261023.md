# 初稿前按需求工作量保护审计额度：实施与验收

2026-10-23。本指南为已实现新策略的验收入口；最终提交/指纹/测试和真实首次结果以`initial_delivery_budget_development_20261023/`收据为准，收据未出现的项目不能计已通过。部署五门槛见`DEPLOYMENT_READINESS_ACCEPTANCE_20261023.md`。

中间v1实现`8ab806e`/指纹`e05a7c33592b08ae18eda164e70a79f25432dae5465d7d1878b4bbc420b8a5bd`，10文件352/全量3759通过，但首次真实题Planner只归6个内容要求，预留3仍不足18条审计，后6条未审、仅7条发布。原首次保留，不套作最终v2通过。最终v2源码指纹与门禁见最终收据；Prompt仍v101。

最终v2源指纹`50c7c3c9c8ac5a7b65e12c12fb24d312921148948e4ec459d91a0bc2cb99aa5e`/True；新增24预算+2浏览器工具契约，11文件368/35.46s、全量3765/1skip/31subtests/1既有warning/403.44s，0失败，repo95/95/前端88/6Python AST/Node/diff通过。真实质量以最终首次收据为准，不套v1门禁或结果。

最终科研提交90c8c62；追加打包白名单修复5631e57/18例后，最终全量3783/1skip/31subtests/1既有warning/353.41s，0失败，科研指纹不变。真实v2首次129.78墙钟/108.02Workflow、7调用、22稿来源12/10+global全完成、17发布5refs、0未审/0length，needs_review且质量not_all_passed；优先复用`logs/initial_delivery_budget_20261023/v2_live_local_first/runs/report-sections-local`，不重复同版付费。tenant02当前30API+16浏览器通过（0费fixture），完整研究引用浏览器/Llama/服务器仍未验。

## A. 改变的逻辑

策略`requirement-workload-before-optional-research/v2`：只统计非constraint/report_structure内容子问；以每个子问至少一条声明作为**工作量估算**，加上大纲推导的Writer批次、每12条的来源审计/全局审查和尚未使用的一次Auditor格式纠正，取不低于原档位预留的值。**多个内容子问时，另至少保留两批来源审计+全局的容量（3次审计）**，避免Planner合并要求后低估。标准多问至少Writer1+来源2+全局1+纠正1=5。只是预留，并不强制实际调用3次审计；实际稿不超12条仍可一次审完。不是声明数目标，不限制报告长度，实际审计仍看实际草稿。

例如标准档17个内容子问：Writer1+来源2+全局1+协议纠正1=5调用；旧固定预留2。已持有批准证据、剩6调用时，不再启动需要3调用的补查；直接交付已有证据。没有批准证据时保留旧有界恢复机会，不能为一份尚无依据的报告预留而过早拒绝。只改可选研究/候选复审准入，不改10/20次数、300/600研究截止或360/720约目标，不提高任何来源/声明批准权限。

`initial-delivery-budget/v1`工件和事件记录估算、实际预留、剩余次数、需求哈希、是否已有批准证据；manifest与budget_usage记录策略。旧任务只读，不给旧未审声明补批准。需求数量只是估算，不能保证任意多声明/多次错误都能在10调用内完成。

## B. 零费门禁

```powershell
New-Item -ItemType Directory -Force logs/initial_delivery_budget_acceptance_20261023
$env:PYTHONDONTWRITEBYTECODE='1'
$env:PYTHONIOENCODING='utf-8'
.\venv\Scripts\python.exe -m pytest tests/test_multi_agent_initial_delivery_budget.py tests/test_multi_agent_sections.py tests/test_multi_agent_report_requirements.py tests/test_multi_agent_pipeline_v2.py tests/test_multi_agent_gap_recovery.py tests/test_multi_agent_audit_batches.py tests/test_multi_agent_revision_delivery.py tests/test_multi_agent_publication.py tests/test_multi_agent_retrieval_deadline.py tests/test_multi_agent_report_fields.py -q --basetemp logs/initial_delivery_budget_acceptance_20261023/target_tmp
.\venv\Scripts\python.exe -m pytest -q --basetemp logs/initial_delivery_budget_acceptance_20261023/full_tmp
.\venv\Scripts\python.exe tools/cloud_release.py repo-check
.\venv\Scripts\python.exe tools/check_frontend_assets.py
git diff --check
```

检查多个要求即有两批审计容量、25条需求继续增长、约束不膨胀、旧协议不改、已用协议纠正不重复预留、无批准来源仍允许原恢复；完整标准mock含一次Reviewer纠正，分别按6/17内容要求写19稿，全部进入12/7+global；伪引文及依赖仍隔离而不借此省审计。不按改断言凑绿，mock不证明科研正确。

## C. 只读旧案例与真实首次

旧源：`logs/report_profile_delivery_20261023/live_local_first/runs/report-sections-local`，源指纹014fff56、19稿/6发布/后7未审、192文件树SHA a899723519fe234af8ae19dea957094013385c9e1d2a6a47a6699e0ed529d546。读取原需求、首轮复审及预算，核对5预留在剩6调用时拒绝3调用补查；不得改变旧发布/终态/hash，0模型0网络。

```powershell
.\venv\Scripts\python.exe initial_delivery_budget_development_20261023/probe.py --run-dir logs/report_profile_delivery_20261023/live_local_first/runs/report-sections-local
```

门禁通过并冻结后，原2763字本地LoRA Table18/standard/hybrid检索/local解析/0外部0Llama，个人7，仅一次新目录付费实测。完整题与PDF标识沿用上批，不缩短；优先复用本批开发首次结果：

```powershell
$env:SCIASSISTANT_MODEL_JSON_MODE='1'
.\venv\Scripts\python.exe report_skills_development_20261022/run_checks.py --source local --report-profile standard --credential-user 7 --output-root logs/initial_delivery_budget_acceptance_20261023/live_local_first
```

逐项核：是否减少可选补查、实际Writer后预算、来源批/全局全完成、是否仍有AUDIT_BATCH_UNREVIEWED；Table18六并列和BLEU方向、表注条件、描述/统计/因果、建议身份、尾部结论。没有未审批不等于语义全过；若仍有机制误译/范围误拒等，逐声明记录，不自动解封或用模型passed关闭。不能拿本地题通过代替公开/混合/云/浏览器验收。

## D. 导出与交接

inspect/replay0且源树不变；发布=map、refs恰为已发布所用批准源、定位层级真实、导出一致。记录初始化/Workflow/wall与所有错误调用、无length；协议/上游预算/科研质量分别结论。

本轮不擅自重启5000或修改原部署包；磁盘变更后旧5000可能code_matches=false，需单独空闲维护后才能计当前网页通过。五件套：result.md、test_summary.json、historical_budget_checks.json、live_quality_checks.json、mapping_checks.json。保存所有失败，不覆盖原run；不提交Key/PDF/运行库。生产部署仍按五门槛另验。
