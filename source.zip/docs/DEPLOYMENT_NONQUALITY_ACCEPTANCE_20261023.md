# 网页、服务器准备、恢复与源码交付：本轮统一验收入口

2026-10-23，按用户最新指令：**回答质量收尾暂停**。不新跑科研答案挑优，不修改六角色/规划/检索/撰写/审计政策；旧质量未过项保留。
当前批次只补其余三项：网页闭环、服务器准备、恢复/回滚及源码入口。版本/测试数以本轮最终结果文件为准。

## A. 隔离离线门禁

在项目根目录，使用现有venv，禁止测试写真实owner/Key库或运行中Qdrant。

```powershell
$env:PYTHONDONTWRITEBYTECODE='1'
$env:PYTHONIOENCODING='utf-8'
.\venv\Scripts\python.exe -m pytest tests/test_source_delivery.py tests/test_user_server.py tests/test_multi_agent_llama_pdf.py tests/test_account_backup.py tests/test_freeze_release.py tests/test_cloud_release.py tests/test_frontend_default_research.py -q -p no:cacheprovider
.\venv\Scripts\python.exe -m pytest -q -p no:cacheprovider
.\venv\Scripts\python.exe tools/cloud_release.py repo-check
.\venv\Scripts\python.exe tools/check_frontend_assets.py
node --check tools/check_research_web_browser.cjs
git diff --check
```

检查：源码页无token/私有下载路径，未完成配置503，旧指纹不得挂旧源码；原LICENSE/NOTICE保留；Compose透传公开配置、不带共享用户Key。
普通用户工具拒绝Windows/3.10/公网明文/特权端口/root数据库账户/私有配置进源码/共享Key；不自动提权或安装。
Llama实际客户端的上传/创建/轮询/删除均经过同一个受限HTTP适配器；独立导入Llama不再加载旧MCP Agent或启动服务器。

## B. 网页真实操作（零供应商费用）

```powershell
.\venv\Scripts\python.exe tools/check_user_isolation.py --run-id deploy-tenant-NEW --browser
.\venv\Scripts\python.exe tools/check_research_web_flow.py --run-id deploy-web-NEW --pdf <已有公开论文PDF绝对路径> --model-mode mock --browser
```

随机回环临时服务；真实注册/登录/MySQL/认证HTTP和Chrome，供应商模拟；不会启停5000/MCP/MySQL。
检查登录→上传/选资料库→默认本文→发送→引用到页框/PNG→下载→追问复用→刷新；1366/877/462px与鼠标拖拽；DELETE500不清正文；迟到会话列表不抢回；运行中取消与Workflow终态一致；重启后私有归属/会话/报告/计数保留，不重跑收费；删除原件不破坏任务副本。
A本人资源200，B404、匿名401；四类个人Key不串账户，清空后不回退共享Key。截图是实际浏览器操作，不以API200代替。

## C. 真实解析（不评价回答质量）

```powershell
.\venv\Scripts\python.exe tools/check_pdf_parser_delivery.py --run-id deploy-parsers-NEW --pdf <公开PDF绝对路径> --credential-user 7 --modes local llama_full hybrid --allow-cloud
```

需已有账户7个人LlamaKey，用户明确授权云上传。只检验解析，不调用回答LLM。
顺序每模式一次；首失败停止保留。检查请求确实发出、云完成、原页数和有序页映射、本地/云来源分开、云块不借bbox；hybrid回退不能算云成功。
两种早期失败均保留：工具包提前导入旧MCP导致ModuleNotFoundError(config)，HTTP适配器缺get/post/delete；离线覆盖+真实新版本复测才能关闭，不把旧失败改通过。
只提交计数/分类，不提交原文解析文本、Key或完整供应商响应。

## D. 恢复与源码（本地可执行部分）

```powershell
.\venv\Scripts\python.exe tools/check_local_restore.py --run-id deploy-restore-NEW --mysql-bin 'E:/MySQL/MySQL Server 8.0/bin'
```

必须使用两座新随机测试库、虚构账户和密钥，不能导出/导入产品库。真实mysqldump/mysql、文件SHA、密码验证、会话、owner、PDF绑定/跨账号、资料库链接/跨账号、Workflow终态/调用账本、个人Key及错主密钥/损坏包拒绝均通过。
测试库/包保留，不自动DROP；临时MySQL配置删除，凭据主密钥不入报告。此段不证明生产Qdrant卷/真实线上用户/HTTPS恢复。
源码页未配置时显示未完成；配置测试用专用fixture，不修改真实.env的确认项。实际公开交付仍须取回对应材料核验版本/hash/依赖源码，不以页面200作结论。

## E. 服务器及新候选包

按`USER_SERVER_DEPLOYMENT_20261023.md`，目标Linux 3.11、MySQL/MCP/Qdrant/model/private config及源码地址到位后，执行check/serve及真实HTTPS/恢复/回滚。
本地没有目标访问条件时明确未执行，不把Windows上的负向拒绝当Linux启动通过。

```powershell
# 本轮固定输出新目录，旧candidate-01不覆盖。
.\venv\Scripts\python.exe tools/freeze_release.py freeze --output dist/web-20261023-candidate-02
.\venv\Scripts\python.exe tools/freeze_release.py verify --archive dist/web-20261023-candidate-02/source.zip
.\venv\Scripts\python.exe tools/cloud_release.py repo-check --root dist/web-20261023-candidate-02/source
```

包内应包含source_delivery、普通用户检查工具/模板、两份本轮指南；没有私有.env/Key/DB/用户PDF/运行日志/venv/models。
这仍是项目源码候选，**不替代必要依赖对应源码材料和真实服务器验收**。

## 交付和停止条件

五件套：result.md / test_summary.json / web_and_security_checks.json / parser_delivery_checks.json / release_and_restore.json。
分别判定网页、真实解析、本地恢复、服务器、源码交付，回答质量标“用户暂停”。含失败首测与修复后首测，不反复抽卡。
泄漏、跨账户、历史修改、误停其他进程、恢复覆盖生产目录立即停对应段；不提交私有数据。
