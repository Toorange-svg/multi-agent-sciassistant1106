# 本地发布冻结与隔离恢复操作说明

本批范围：浏览器完整用户路径、源码发布快照、本地恢复预演。输出质量调整暂缓。
服务器、域名、HTTPS 与正式 Linux 卷灾备由用户明确延期，不作为本批通过项。

## 1. 发布快照不等于生产部署

在项目根目录、最终测试通过后执行：

```powershell
New-Item -ItemType Directory -Path dist -Force
.\venv\Scripts\python.exe tools/freeze_release.py freeze --output dist/web-20261017-01 --git-ref refs/heads/release/web-20261017-01
.\venv\Scripts\python.exe tools/freeze_release.py verify --archive dist/web-20261017-01/source.zip
.\venv\Scripts\python.exe tools/cloud_release.py repo-check --root dist/web-20261017-01/source
```

- `source/` 与 ZIP 保存当前磁盘的原始字节，包括尚未加入 Git 的运行必需模块。
- 单独的本地 `release/…` 分支是不带历史父提交的源码快照；不切分支、不推送、不改变现有暂存区。
- `release.json` 提供 release commit、源码指纹和 ZIP SHA256；`RELEASE_MANIFEST.json` 提供每文件 SHA256。
- ZIP 只包含白名单源码、前端、测试、部署文件和空库 schema；不包含私有 env、真实文件、密钥库、SQL dump、模型或运行日志。
- `.env*.example` 是模板，不是可用部署密钥。实际环境文件由部署者私下提供。
- 发布时使用 `source/` 或 ZIP，不对当前混合开发目录直接 `git pull/checkout`。模型单独导出并验证，不能遗漏。
- 哈希用于一致性校验，不是数字签名或来源认证；压缩包需通过可信渠道交付。
- 该发布快照是“已验证本地候选版本”，不因生成 ZIP 就自动成为“可公网发布版本”。

## 2. 本地浏览器功能验收（无供应商费用）

依赖现有 Chrome、Playwright、项目 venv、可用 MySQL。命令从真实项目根目录执行。

```powershell
.\venv\Scripts\python.exe tools/check_user_isolation.py --run-id release-tenant-<unique> --browser
.\venv\Scripts\python.exe tools/check_research_web_flow.py --run-id release-web-<unique> --pdf <已有公开论文PDF> --model-mode mock --browser
```

临时网关只绑定随机回环端口，永不占用或重启 5000；生产认证和数据库路径真实执行。
测试新建专用账户，文件、任务、密钥库、向量和账本使用隔离目录；专用账户行保留，不冒用真实用户。
mock 的账户密钥仅为不可用的虚构字符串，模型执行固定化；不是科研质量、公开源稳定性或真实供应商配额验收。

第二条命令覆盖登录、资料库预览/选用、真实页面上传与发送、追问复用、刷新恢复、引用到页框、认证下载、宽窄屏与拖拽、删除500、迟到列表、运行中取消、隔离网关重启和删除原件后历史报告可访问。
失败目录不可覆盖；修复后换新的 run-id，保留原失败。

## 3. 本地 MySQL + 文件 + 密钥库恢复预演

```powershell
.\venv\Scripts\python.exe tools/check_local_restore.py --run-id release-restore-<unique> --mysql-bin 'E:/MySQL/MySQL Server 8.0/bin'
```

此工具仅连接本机 MySQL；使用两座全新随机命名 `sci_dr_*_src/dst` 测试库，不导出或改写产品数据库。
需现有账户有创建测试数据库权限；不自动提升权限、不修改 grants。
源码所带空库 schema + 虚构账户/会话组成源库，调用真正 mysqldump/mysql 导出和导入。
同时执行现有 `account_backup` 的 create/verify/restore-stage，恢复后核对口令哈希、会话、文件哈希、owner、终态和用户密钥隔离。
错加密主密钥必须拒绝解密，篡改包必须拒绝验证。

测试库、有效包与损坏副本保留在本机，不自动 DROP；临时 MySQL 密码配置准确删除，虚构密钥的主密钥仅驻内存。
工具只输出安全代码、计数与测试库名，不打印密码/JWT/供应商密钥/SQL 正文。
本预演使用模拟内容文件，不是公开论文解析测试，也不证明生产数据、线上认证恢复或 Qdrant 服务恢复。

## 4. 真正生产备份仍须补齐

沿用 `ACCOUNT_BACKUP_RESTORE_RUNBOOK_20260929.md` 的停写、一致性导出与新项目恢复原则，另外必须包括：

1. 当前 MySQL 数据、五个应用持久目录，以及实际自定义到目录外的所有状态路径。
2. `logs/user_credentials.sqlite3`，以及账户任务 owner、PDF会话绑定、资料库、Workflow工件、正文与 PDF/PNG 资产。
3. **独立、保密备份 `USER_CREDENTIAL_ENCRYPTION_KEY`；未设置时保留旧 `SECRET_KEY`。** 改签名密钥而丢失旧加密来源会让用户自有密钥无法解密。密钥与数据分开存放，不放 Git、公开验收报告或源代码 ZIP。
4. 使用 SQLite backup API 或完全停写/关闭连接后导出；不能只复制活跃的 `.sqlite3` 而遗漏 WAL。
5. 独立 Qdrant 的一致性快照、collection 与租户映射，模型导出目录及版本/哈希。旧五目录工具**不会自动备份 Qdrant 卷或模型**。
6. 私有部署配置与必要密钥（数据库、MCP、Qdrant），由受控密码库/加密备份保管；普通备份包没有加密功能。
7. 在全新 Linux Compose project/命名卷恢复，验真实用户登录、A/B隔离、报告/PDF下载、检索和取消；原部署与原卷不能当恢复目标。

正式服务器、HTTPS 和生产灾备未执行前，不得把本地预演写成“已上线就绪”。
