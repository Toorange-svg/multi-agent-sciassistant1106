@echo off
setlocal
call "%~dp0bin\windows\run_demo.cmd" %*
set DEMO_EXIT=%ERRORLEVEL%
endlocal & exit /b %DEMO_EXIT%
