"""Deterministic Markdown/HTML report export for CLI pipeline runs."""

from __future__ import annotations

import html
import json
import math
import re
from pathlib import Path
from typing import Any, Mapping

from multi_agent_agents import ArtifactDirectory
from multi_agent_evidence import report_source_identity


def read_run_manifest(run_dir: str | Path, *, fallback_run_id: str | None = None) -> dict:
    """Read BOM-compatible metadata; only termination boundaries may recover.

    A broken manifest does not authorize publishing any previously unverified
    output. A fallback contains identifiers, not guessed prompts or citations.
    """
    path = Path(run_dir) / "manifest.json"
    try:
        if path.is_symlink() or path.stat().st_size > 256_000:
            raise ValueError("invalid manifest file")
        value = json.loads(path.read_text(encoding="utf-8-sig"))
        if not isinstance(value, dict):
            raise ValueError("manifest must be an object")
        if fallback_run_id is not None and value.get("run_id") != fallback_run_id:
            raise ValueError("manifest run id mismatch")
        return value
    except (OSError, ValueError, UnicodeError):
        if fallback_run_id is None:
            raise ValueError("CLI_MANIFEST_INVALID") from None
        return {"schema_version": "sciassistant.run-manifest/v1", "run_id": fallback_run_id,
                "mode": "live", "manifest_read_status": "missing_or_invalid"}


def _find_payload(root: Path, prefix: str, *, last: bool = True) -> dict[str, Any] | None:
    matches = sorted(root.glob(f"{prefix}-*.json"), key=lambda path: path.stat().st_mtime_ns)
    if not matches:
        return None
    return ArtifactDirectory(root).get((matches[-1] if last else matches[0]).stem)


def _official_link(item: Mapping[str, Any]) -> str:
    paper_id = str(item.get("paper_id") or "")
    if not re.fullmatch(r"(?:\d{4}\.\d{4,5}|[a-z-]+(?:\.[A-Z]{2})?/\d{7})(?:v[1-9]\d*)?", paper_id):
        return ""
    return "https://arxiv.org/abs/" + paper_id


def source_preview_geometry(source_page, locator: Mapping[str, Any]) -> dict:
    """Display coordinates only; never replace the audited source locator.

    PyMuPDF text boxes use unrotated page points. The rendered preview uses
    the page's rotation, so both coordinate systems must be kept distinct.
    A missing box may use an actual, unique text match, never a guessed one.
    """
    page_rect = source_page.rect
    width, height = float(page_rect.width), float(page_rect.height)
    if not all(math.isfinite(value) and value > 0 for value in (width, height)):
        raise ValueError("invalid preview dimensions")
    result = {"schema_version": "sciassistant.page-preview/v1",
              "coordinate_space": "rendered_page_points", "page_size": [width, height],
              "bbox": None, "highlight_method": "none",
              "notice": "原文页已定位，但此片段没有可用坐标框；请结合原文锚点人工核对。"}
    try:
        import pymupdf as fitz
    except ImportError:
        import fitz
    box = locator.get("bbox")
    if (isinstance(box, (list, tuple)) and len(box) == 4
            and all(isinstance(value, (int, float)) and not isinstance(value, bool)
                    and math.isfinite(value) for value in box)
            and box[2] > box[0] and box[3] > box[1]):
        displayed = (fitz.Rect(box) * source_page.rotation_matrix) & page_rect
        if not displayed.is_empty and all(math.isfinite(value) for value in displayed):
            result.update(bbox=list(displayed), highlight_method="bbox",
                          notice="黄色框为解析坐标对应的引用位置，已按页面旋转转换；请结合证据片段核对。")
            return result
    anchor = locator.get("anchor_text")
    if isinstance(anchor, str) and 0 < len(anchor.strip()) <= 500:
        matches = source_page.search_for(anchor.strip())
        # Multiple rectangles can be repeated or multiline matches. Without
        # stronger occurrence metadata, do not choose the first as authoritative.
        if len(matches) == 1:
            displayed = (matches[0] * source_page.rotation_matrix) & page_rect
            if not displayed.is_empty and all(math.isfinite(value) for value in displayed):
                result.update(bbox=list(displayed), highlight_method="anchor_text",
                              notice="未提供可用解析坐标；黄色框来自本页唯一原文锚点匹配，不是原始解析坐标。")
                return result
        result["notice"] = ("原文页已定位，但锚点出现多处或跨行；未自动选择高亮，请人工核对。" if matches
                            else "原文页已定位，但未匹配到原文锚点；没有生成位置高亮，请人工核对。")
    return result


def _source_view(run_dir: Path, item: Mapping[str, Any]) -> str | None:
    """Make a static page image with bbox highlight; fall back to PDF page."""
    document_id = str(item.get("document_id") or "")
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,100}", document_id):
        return None
    relative = Path("pdf") / document_id / "source.pdf"
    pdf = run_dir / relative
    if not pdf.is_file() or pdf.is_symlink() or not pdf.resolve().is_relative_to(run_dir.resolve()):
        return None
    locator = item.get("locator") or {}
    page = locator.get("page")
    if not isinstance(page, int) or isinstance(page, bool) or page < 1:
        return relative.as_posix()
    fallback = relative.as_posix() + f"#page={page}"
    try:
        try:
            import pymupdf as fitz
        except ImportError:
            import fitz
        with fitz.open(pdf) as document:
            if page > document.page_count:
                return fallback
            source_page = document[page - 1]
            page_rect = source_page.rect
            area = page_rect.width * page_rect.height
            if not math.isfinite(area) or area <= 0:
                return fallback
            # Include rounding headroom and a dimension cap for thin/huge pages.
            scale = min(1.2, math.sqrt(4_980_000 / area), 8191 / max(page_rect.width, page_rect.height))
            pixels = source_page.get_pixmap(matrix=fitz.Matrix(scale, scale))
            (run_dir / "pages").mkdir(exist_ok=True)
            image_name = f"evidence-{item['citation']}.png"
            pixels.save(run_dir / "pages" / image_name)
            preview = source_preview_geometry(source_page, locator)
            overlay = ""
            if preview["bbox"]:
                rect = fitz.Rect(preview["bbox"])
                overlay = ('<span style="position:absolute;border:3px solid #e39c00;background:#ffd54f40;'
                           f'left:{100 * rect.x0 / page_rect.width:.3f}%;top:{100 * rect.y0 / page_rect.height:.3f}%;'
                           f'width:{100 * rect.width / page_rect.width:.3f}%;height:{100 * rect.height / page_rect.height:.3f}%"></span>')
            view_name = f"source-{item['citation']}.html"
            anchor = str(locator.get("anchor_text") or "")[:500]
            anchor_markup = f'<p>原文锚点：{html.escape(anchor)}</p>' if anchor else ''
            (run_dir / view_name).write_text(
                '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>原文定位</title>'
                f'<p>第 {page} 页。{html.escape(preview["notice"])}</p>'
                f'{anchor_markup}'
                f'<p><a href="{fallback}">打开 PDF 原文页</a> · <a href="final_answer.html#evidence-{item["citation"]}">返回证据卡</a></p>'
                '<div style="position:relative;max-width:1000px">'
                f'<img src="pages/{image_name}" style="width:100%;display:block">{overlay}</div></html>', encoding="utf-8",
            )
            return view_name
    except Exception:
        return fallback


def export_run_report(run_dir: str | Path) -> dict[str, str]:
    run_dir = Path(run_dir)
    artifact_root = run_dir / "artifacts"
    artifacts = ArtifactDirectory(artifact_root)
    manifest = read_run_manifest(run_dir) if (run_dir / "manifest.json").is_file() else {}
    final = artifacts.get(manifest["final_artifact_id"]) if manifest.get("final_artifact_id") else (_find_payload(artifact_root, "final-result") or {})
    refs = final.get("artifact_refs") or {}
    for name in ('question_inventory', 'user_requirements', 'report_budget', 'report_outline',
                 'section_evidence', 'writer_jobs', 'section_writing', 'report_composition', 'skill_loads', 'assertion_modes',
                 'publication_coverage', 'publication_recovery', 'report_review', 'audit_batches'):
        if refs.get(name):
            (run_dir / (name + '.json')).write_text(json.dumps(artifacts.get(refs[name]), ensure_ascii=False, indent=2), encoding='utf8')
    if refs.get("budget"):
        (run_dir / "budget_usage.json").write_text(json.dumps(artifacts.get(refs["budget"]), ensure_ascii=False, indent=2), encoding="utf-8")
    if refs.get("evidence_flow"):
        (run_dir / "evidence_flow_diagnostics.json").write_text(json.dumps(artifacts.get(refs["evidence_flow"]), ensure_ascii=False, indent=2), encoding="utf-8")
    if refs.get("plan_scope_validation"):
        (run_dir / "plan_scope_validation.json").write_text(json.dumps(artifacts.get(refs["plan_scope_validation"]), ensure_ascii=False, indent=2), encoding="utf-8")
    if refs.get("source_scope_format"):
        (run_dir / "source_scope_formatting.json").write_text(json.dumps(artifacts.get(refs["source_scope_format"]), ensure_ascii=False, indent=2), encoding="utf-8")
    if refs.get("audit_input"):
        (run_dir / "citation_audit_input.json").write_text(json.dumps(artifacts.get(refs["audit_input"]), ensure_ascii=False, indent=2), encoding="utf-8")
    if refs.get("source_boundaries"):
        (run_dir / "source_boundary_brief.json").write_text(json.dumps(artifacts.get(refs["source_boundaries"]), ensure_ascii=False, indent=2), encoding="utf-8")
    for name in ("publication", "review_validation", "audit_validation"):
        if refs.get(name):
            (run_dir / (name + "_decisions.json" if name == "publication" else name + ".json")).write_text(
                json.dumps(artifacts.get(refs[name]), ensure_ascii=False, indent=2), encoding="utf-8")
    evidence_ref = refs.get("approved") or refs.get("evidence")
    evidence_set = artifacts.get(evidence_ref) if evidence_ref else (_find_payload(artifact_root, "evidence-set") or {})
    answer = str(final.get("direct_answer") or "").strip()
    status = str(final.get("status") or "failed")
    # Search candidates are not answer references. Keep them in the internal
    # run artifacts, never present an unreviewed list as cited final evidence.
    evidence = [item for item in evidence_set.get("evidence") or [] if item.get("review_status") == "approved"]
    from multi_agent_quality import check_audit, publication_rejections, report_evidence, REPORT_REFERENCE_POLICY
    audit = artifacts.get(refs["audit"]) if refs.get("audit") else (_find_payload(artifact_root, "citation_auditor-output") or {"status": "not_available"})
    claim_map = artifacts.get(refs["draft"]) if refs.get("draft") else (_find_payload(artifact_root, "draft-answer") or {})
    if claim_map.get("claims"):
        audit = check_audit(audit, claim_map, {"evidence": evidence})
    rejected = publication_rejections(audit, claim_map)
    all_approved = evidence
    evidence = report_evidence(claim_map, {"evidence": evidence}, rejected)
    if claim_map.get("report_reference_policy") == REPORT_REFERENCE_POLICY:
        used_ids = {e["evidence_id"] for e in evidence}
        (run_dir / "reference_selection.json").write_text(json.dumps({
            "schema_version": "sciassistant.reference-selection/v1", "policy": REPORT_REFERENCE_POLICY,
            "cited_evidence_ids": [e["evidence_id"] for e in evidence],
            "other_approved_evidence_ids": [e["evidence_id"] for e in all_approved if e["evidence_id"] not in used_ids],
            "all_approved_preserved_in_artifacts": True}, ensure_ascii=False, indent=2), encoding="utf-8")
    references = []
    ledger = []
    from multi_agent_evidence import evidence_strength, evidence_label
    for index, item in enumerate(evidence, 1):
        locator = item.get("locator") or {}
        location = f"p. {locator.get('page')}" if locator.get("page") else (locator.get("section") or "原文位置未定位")
        source_label = "用户上传 PDF" if item.get("source") == "uploaded_pdf" else "arXiv:" + str(item.get("paper_id"))
        references.append(f"[{index}] {item.get('title')} — {source_label} ({location}；{evidence_label(item)})")
        ledger.append({"citation": index, "evidence_id": item.get("evidence_id"), "paper_id": item.get("paper_id"),
                       "title": item.get("title"), "source": item.get("source", "arxiv"), "official_url": _official_link(item), "locator": locator,
                       **report_source_identity(claim_map, item),
                       "document_id": item.get("document_id"), "review_status": item.get("review_status", "not_approved"),
                       "coverage_scope": item.get("coverage_scope"), "content_scope": item.get("content_scope"),
                       "parser_provenance": item.get("parser_provenance"),
                       "source_attribution": item.get("source_attribution"),
                       "evidence_strength": evidence_strength(item),
                       "evidence_strength_label": evidence_label(item),
                       "task_relevance": item.get("task_relevance", "not_classified"),
                       "source_domain": item.get("source_domain", ""), "source_scope_policy": item.get("source_scope_policy"),
                       "reviewed_group_ids": item.get("reviewed_group_ids"), "topic_association_policy": item.get("topic_association_policy"),
                       "retrieval_group_ids": item.get("group_ids") or [item.get("group_id")],
                       "published_at": item.get("published_at"), "updated_at": item.get("updated_at"),
                       "excerpt": str(item.get("excerpt") or "")[:16_000],
                       "excerpt_truncated": len(str(item.get("excerpt") or "")) > 16_000})
    from multi_agent_status import describe_status, status_markdown, status_html, source_execution_lines, OUTCOME_CSS
    review = artifacts.get(refs["review"]) if refs.get("review") else {}
    display = describe_status(status, audit=audit, coverage=review.get("coverage"), workflow_notice=review.get("recovery_notice"), failure_code=final.get("failure_code"),
                              plan=artifacts.get(refs["plan"]) if refs.get("plan") else None)
    if refs.get("source_execution"):
        notice = artifacts.get(refs["source_execution"])
        display["source_execution_lines"] = source_execution_lines(notice, final.get("run_id"))
        (run_dir / "source_execution_notice.json").write_text(json.dumps(notice, ensure_ascii=False, indent=2), encoding="utf-8")
    if refs.get("answer_scope"):
        scope = artifacts.get(refs["answer_scope"])
        display["answer_scope"] = scope
        (run_dir / "answer_scope_summary.json").write_text(json.dumps(scope, ensure_ascii=False, indent=2), encoding="utf-8")
    markdown = "# 多智能体科研报告\n\n" + status_markdown(display) + "## 回答正文\n\n" + (answer or '未生成科研结论。')
    if references:
        markdown += "\n\n## 参考文献\n\n" + "\n".join(references)
    (run_dir / "review_decisions.json").write_text(json.dumps(review.get("decisions", []), ensure_ascii=False, indent=2), encoding="utf-8")
    (run_dir / "references.json").write_text(json.dumps(ledger, ensure_ascii=False, indent=2), encoding="utf-8")
    rejected = publication_rejections(audit, claim_map)
    allowed_ids = {item.get("evidence_id") for item in ledger if item.get("review_status") == "approved"}
    claims = [item for item in claim_map.get("claims") or [] if isinstance(item, dict)
              and item.get("claim_id") not in rejected and "draft" not in rejected
              and item.get("evidence_ids")
              and set(item.get("evidence_ids") or []).issubset(allowed_ids)]
    from multi_agent_presentation import POLICY, LINKED_POLICY, report_content, bibliography, evidence_review, CSS, COMPACT_CSS, coverage_report, compact_status
    layout_policy = manifest.get('report_presentation_policy')
    modern = layout_policy in {POLICY,LINKED_POLICY}
    compact = layout_policy == POLICY
    report_display = compact_status(display) if compact else display
    presentation = None
    if modern:
        presentation, body, md_cards = report_content(answer or '未生成科研结论。', claims,
            review.get('coverage'), ledger, artifacts.get(refs['plan']) if refs.get('plan') else None, markdown=True,policy=layout_policy)
        markdown = '# 多智能体科研报告\n\n' + status_markdown(report_display) + '## 回答正文\n\n' + body
        markdown += '\n\n## 原文证据与对应说明\n\n' + (coverage_report(presentation,ledger,markdown=True)+'\n\n' if compact else '') + '\n\n'.join(md_cards)
        markdown += '\n\n' + bibliography(presentation, markdown=True) + '\n'
        (run_dir / 'report_presentation.json').write_text(json.dumps(presentation, ensure_ascii=False, indent=2), encoding='utf8')
    elif claims:
        markdown += "\n\n## 逐声明审查记录（实验条件与证据局限）\n\n"
        for claim in claims:
            markers = "".join(f'[{row["citation"]}]' for row in ledger if row["evidence_id"] in claim["evidence_ids"])
            markdown += str(claim.get("text") or "") + markers + "\n\n"
            if claim.get("scope_note"):
                markdown += "结论适用范围：" + str(claim["scope_note"]) + "\n\n"
            if claim.get("qualification"):
                markdown += "实验条件与证据局限：" + str(claim["qualification"]) + "\n\n"
    delivery_text = ''
    if refs.get('publication_coverage'):
        from multi_agent_publication import delivery_markdown
        delivery_text = delivery_markdown(artifacts.get(refs['publication_coverage']))
        # Separate report appendix, not an extra evidence gap in the Web body.
        marker='## 参考文献'
        pos=markdown.rfind(marker)
        markdown=(markdown[:pos]+delivery_text+'\n\n'+markdown[pos:]) if pos>=0 else markdown+'\n\n'+delivery_text
    # Keep detailed conditions even when v2 intentionally omits them from body.
    (run_dir / "final_answer.md").write_text(markdown, encoding="utf-8-sig")
    (run_dir / "claim_evidence_map.json").write_text(
        json.dumps(claims, ensure_ascii=False, indent=2), encoding="utf-8",
    )
    escaped = html.escape(answer or "未生成科研结论。")
    valid_numbers = {item["citation"] for item in ledger}
    escaped = re.sub(r"\[(\d+)\]", lambda match: f'<a href="#evidence-{match[1]}">[{match[1]}]</a>'
                     if int(match[1]) in valid_numbers else match[0], escaped)
    # Only code-recognized headings become markup; all claim text stays escaped.
    rendered_answer = []
    for block in escaped.split("\n\n"):
        heading = re.fullmatch(r"(#{3,4}) ([^\n]+)", block)
        if heading:
            level = len(heading[1])
            rendered_answer.append(f"<h{level}>{heading[2]}</h{level}>")
        else:
            rendered_answer.append("<p>" + block.replace("\n", "<br>") + "</p>")
    if modern:
        from multi_agent_presentation import render_answer
        rendered_answer = [render_answer(answer or '未生成科研结论。', presentation, ledger)]
    cards = []
    from multi_agent_quality import claim_review_html
    for item in ledger:
        index = item["citation"]
        locator = item["locator"]
        page = locator.get("page")
        official = html.escape(str(item.get("official_url") or "#"), quote=True)
        source_link = official + (f"#page={int(page)}" if page and "arxiv.org/pdf" in official else "")
        local_link = _source_view(run_dir, item)
        related = [claim for claim in claims if item["evidence_id"] in claim.get("evidence_ids", [])]
        cards.append(
            f'<article id="evidence-{index}"><h3>[{index}] {html.escape(str(item.get("title") or ""))}</h3>'
            f'<p>位置：{html.escape(json.dumps(locator, ensure_ascii=False))}</p>'
            f'<blockquote>{html.escape(str(item.get("excerpt") or ""))}</blockquote>'
            f'<p>审核：{html.escape(str(item.get("review_status")))}</p>'
            f'<p>证据等级：{html.escape(item["evidence_strength_label"])}</p>'
            + (f'<p>来源用途：{html.escape(str(item["source_attribution"].get("label", "")))}</p>' if item.get("source_attribution") else '')
            + (evidence_review(presentation, item['evidence_id'], ledger) if modern else
               '<details><summary>对应结论与审查记录</summary>' + claim_review_html(related) + '</details>' if related else '')
            + (f'<p><a href="{html.escape(local_link, quote=True)}">查看本地原文位置</a></p>' if local_link else '')
            + (f'<p><a href="{source_link}" target="_blank" rel="noopener">查看官方原文</a></p>' if item.get("official_url") else '<p>用户上传 PDF；没有自动生成官方外链。</p>')
            + '</article>'
        )
    html_report = f"""<!doctype html><html lang="zh-CN"><meta charset="utf-8">
<title>多智能体科研报告</title><style>body{{max-width:960px;margin:2rem auto;font:16px/1.7 sans-serif;padding:0 1rem}}article{{border-top:1px solid #ccc;padding:1rem 0}}.warning{{background:#fff3cd;padding:1rem}}blockquote{{white-space:pre-wrap}}</style>
<style>{OUTCOME_CSS}{COMPACT_CSS if compact else CSS if modern else ''}</style><h1>多智能体科研报告</h1>{status_html(report_display)}
<section id="answer"><h2>回答正文</h2>{''.join(rendered_answer)}</section>
<section><h2>证据卡</h2>{coverage_report(presentation,ledger) if compact else ''}{''.join(cards)}</section>{'<section id="report-delivery"><pre>'+html.escape(delivery_text)+'</pre></section>' if delivery_text else ''}{bibliography(presentation) if modern else ''}</html>"""
    (run_dir / "final_answer.html").write_text(html_report, encoding="utf-8")
    (run_dir / "evidence_ledger.json").write_text(json.dumps(ledger, ensure_ascii=False, indent=2), encoding="utf-8")
    (run_dir / "citation_audit.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"markdown": str(run_dir / "final_answer.md"), "html": str(run_dir / "final_answer.html")}
