"""Concrete but dependency-injected role adapters for literature coordination.

The adapters deliberately keep provider credentials inside ``model_json`` and
search/network access inside ``search``/``read_evidence`` closures.  No role
receives a workflow database or another role's natural-language output.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from typing import Any, Callable, Mapping

from multi_agent_literature import LiteratureRoles
from multi_agent_workflow import WorkflowError


ModelJson = Callable[[str, Mapping[str, Any]], Mapping[str, Any]]
Search = Callable[[str, int], Mapping[str, Any]]
ScreenSearch = Callable[[str, str, Mapping[str, Any]], Mapping[str, Any]]
ReadEvidence = Callable[[Mapping[str, Any]], Mapping[str, Any] | None]


def _object(value: Mapping[str, Any] | str) -> dict:
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except ValueError as exc:
            raise WorkflowError("role returned invalid JSON") from exc
    if not isinstance(value, Mapping):
        raise WorkflowError("role returned invalid object")
    return dict(value)


def _short_text(value: Any, limit: int) -> str:
    return " ".join(str(value or "").split())[:limit]


def _safe_count(value: Any) -> int:
    try:
        return min(100, max(0, int(value)))
    except (TypeError, ValueError):
        return 0


def _compact_records(evidence_set: Mapping[str, Any], excerpt_limit: int = 1_200) -> list[dict]:
    """Create a bounded evidence snapshot for model roles; raw source payloads stay out."""
    return [{
        "evidence_id": record["evidence_id"], "group_id": record["group_id"],
        "paper_id": record["paper_id"], "title": record["title"], "source": record["source"],
        "publication_date": record["publication_date"], "claim_support": record["claim_support"],
        "excerpt": _short_text(record["excerpt"], excerpt_limit),
        "fulltext_available": record["fulltext_available"],
    } for record in evidence_set["records"]]


def _as_research_plan(value: Mapping[str, Any]) -> dict:
    """Normalize a provider plan into the coordinator's narrow artifact shape."""
    raw_groups = value.get("groups")
    if not isinstance(raw_groups, list):
        raise WorkflowError("planner did not return groups")
    groups = []
    for index, item in enumerate(raw_groups[:3], 1):
        if not isinstance(item, Mapping):
            continue
        queries = item.get("queries") or item.get("query") or []
        if isinstance(queries, str):
            queries = [queries]
        if not isinstance(queries, list):
            continue
        normalized_queries = [_short_text(query, 500) for query in queries if _short_text(query, 500)][:8]
        question = _short_text(item.get("question") or item.get("topic") or "", 4_000)
        if question and normalized_queries:
            groups.append({"id": f"group-{index}", "question": question, "queries": normalized_queries, "priority": index})
    if not groups:
        raise WorkflowError("planner returned no usable group")
    return {
        "schema_version": 1, "groups": groups,
        "assumptions": [_short_text(item, 1_000) for item in value.get("assumptions", []) if _short_text(item, 1_000)][:20],
        "out_of_scope": [_short_text(item, 1_000) for item in value.get("out_of_scope", []) if _short_text(item, 1_000)][:20],
    }


@dataclass
class LiteratureRoleAdapters:
    """Build coordinator roles without granting them persistence or scheduling."""

    model_json: ModelJson
    search: Search
    screen_search: ScreenSearch | None = None
    source: str = "arxiv"
    read_evidence: ReadEvidence | None = None
    # Full-text reads have their own network budget. Keep this below the
    # workflow's 360-second wall clock rather than allowing each group to
    # independently start a potentially slow PDF read.
    max_fulltext_reads: int = 1
    _fulltext_reads: int = 0
    _evidence_labels: dict[str, str] | None = None

    def planner(self, question: Mapping[str, Any]) -> Mapping[str, Any]:
        response = self.model_json("planner", {
            "question": question["question"],
            "instruction": (
                "Return JSON only. Split the research question into at most three independent literature groups. "
                "Each group needs a short English topic and 1-2 executable English scholarly search queries. "
                "Do not answer the question or include citations."
            ),
        })
        return _as_research_plan(_object(response))

    def retriever(self, group: Mapping[str, Any]) -> Mapping[str, Any]:
        papers: list[dict] = []
        seen: set[tuple[str, str]] = set()
        retrieval_summary: list[dict] = []
        recovery_round = int(group.get("recovery_round", 0) or 0)
        for query in group["queries"][:2]:
            raw_result = self.search(str(query), 5)
            result = (self.screen_search(str(query), str(group["question"]), raw_result)
                      if self.screen_search is not None and isinstance(raw_result, Mapping) else raw_result)
            raw_papers = result.get("papers") if isinstance(result, Mapping) else []
            screening = result.get("screening") if isinstance(result, Mapping) else {}
            if not isinstance(screening, Mapping):
                screening = {}
            candidate_count = screening.get("candidate_count", len(raw_papers) if isinstance(raw_papers, list) else 0)
            accepted_count = screening.get("accepted_count", len(raw_papers) if isinstance(raw_papers, list) else 0)
            contextual_count = screening.get("contextual_count", 0)
            rejected_count = screening.get("rejected_count", max(0, _safe_count(candidate_count) - _safe_count(accepted_count)))
            retrieval_summary.append({
                "group_id": group["id"], "source": self.source, "source_status": _short_text(
                    result.get("status") if isinstance(result, Mapping) else "error", 64
                ) or "error",
                "candidate_count": _safe_count(candidate_count),
                "accepted_count": _safe_count(accepted_count),
                "contextual_count": _safe_count(contextual_count),
                "rejected_count": _safe_count(rejected_count),
                "round": recovery_round,
            })
            if not isinstance(result, Mapping) or result.get("status") != "ok":
                continue
            for paper in result.get("papers") or []:
                if not isinstance(paper, Mapping):
                    continue
                paper_id = _short_text(paper.get("paper_id") or paper.get("id"), 256)
                title = _short_text(paper.get("title"), 1_000)
                source = _short_text(paper.get("source") or self.source, 64).lower()
                key = (source, paper_id.lower())
                if not paper_id or not title or key in seen:
                    continue
                seen.add(key)
                papers.append(dict(paper))
                if len(papers) >= 12:
                    break
            if len(papers) >= 12:
                break

        records = []
        for ordinal, paper in enumerate(papers, 1):
            paper_id = _short_text(paper.get("paper_id") or paper.get("id"), 256)
            source = _short_text(paper.get("source") or self.source, 64).lower()
            excerpt = _short_text(paper.get("abstract"), 2_000)
            fulltext_available = False
            if self.read_evidence is not None and self._fulltext_reads < max(0, int(self.max_fulltext_reads)):
                self._fulltext_reads += 1
                extracted = self.read_evidence(paper)
                if isinstance(extracted, Mapping):
                    candidate = _short_text(extracted.get("excerpt") or extracted.get("text"), 8_000)
                    if candidate:
                        excerpt = candidate
                        fulltext_available = bool(extracted.get("fulltext_available", True))
            digest = hashlib.sha256(f"{group['id']}|{source}|{paper_id}|{ordinal}".encode("utf-8")).hexdigest()[:16]
            records.append({
                "evidence_id": f"evidence-{digest}", "group_id": group["id"], "paper_id": paper_id,
                "title": _short_text(paper.get("title"), 1_000), "source": source,
                "publication_date": _short_text(paper.get("published") or paper.get("year"), 64) or None,
                "claim_support": [], "excerpt": excerpt, "fulltext_available": fulltext_available,
                "provenance": {"retrieval_run_id": f"retrieval-{group['id']}"},
            })
        return {"schema_version": 1, "records": records, "retrieval_summary": retrieval_summary}

    def reviewer(self, plan: Mapping[str, Any], evidence_set: Mapping[str, Any]) -> Mapping[str, Any]:
        self._evidence_labels = {
            record["evidence_id"]: f"{record['source']}:{record['paper_id']}"
            for record in evidence_set["records"]
        }
        response = self.model_json("reviewer", {
            "plan": {"groups": plan["groups"]}, "evidence": _compact_records(evidence_set),
            "instruction": (
                "Return JSON only: coverage_status (sufficient, partial, or insufficient), supported_claims, "
                "unsupported_questions, conflicts, allowed_evidence_ids, coverage. coverage is one entry per planned "
                "group: {group_id, status, evidence_ids, reason}; status must be direct, partial, not_reported, "
                "not_comparable, or missing. Only approve evidence IDs present in the input. "
                "Use partial whenever one or more factual claims can be supported but requested metrics are absent, "
                "not directly comparable, or only reported as throughput/memory rather than latency. Use insufficient "
                "only when no factual claim can be tied to an evidence record. Treat not_reported and not_comparable "
                "as valid research findings when backed by a paper; do not invent a percentage. Do not guess."
            ),
        })
        value = _object(response)
        available = {record["evidence_id"] for record in evidence_set["records"]}
        coverage = []
        raw_coverage = value.get("coverage")
        if isinstance(raw_coverage, list):
            for item in raw_coverage[:3]:
                if not isinstance(item, Mapping):
                    continue
                evidence_ids = [str(evidence_id) for evidence_id in item.get("evidence_ids", [])
                                if str(evidence_id) in available][:60]
                status = _short_text(item.get("status"), 32)
                group_id = _short_text(item.get("group_id"), 128)
                reason = _short_text(item.get("reason"), 1_000)
                if group_id and status in {"direct", "partial", "not_reported", "not_comparable", "missing"} and reason:
                    if status == "missing":
                        evidence_ids = []
                    elif not evidence_ids:
                        continue
                    coverage.append({"group_id": group_id, "status": status,
                                     "evidence_ids": evidence_ids, "reason": reason})
        # Preserve a safe, deterministic fallback when a provider has not yet
        # adopted the newer coverage field.  It prevents a non-empty approved
        # evidence set from being discarded merely due to a schema upgrade.
        if not coverage:
            approved = [str(evidence_id) for evidence_id in value.get("allowed_evidence_ids", [])
                        if str(evidence_id) in available]
            for group in plan["groups"]:
                group_ids = [record["evidence_id"] for record in evidence_set["records"]
                             if record["group_id"] == group["id"] and record["evidence_id"] in approved]
                coverage.append({
                    "group_id": group["id"],
                    "status": "partial" if group_ids else "missing",
                    "evidence_ids": group_ids,
                    "reason": "已有审查证据支持部分结论" if group_ids else "本轮未获得可审查证据",
                })
        coverage_evidence = [evidence_id for item in coverage for evidence_id in item["evidence_ids"]]
        allowed = list(dict.fromkeys([
            *[str(evidence_id) for evidence_id in value.get("allowed_evidence_ids", []) if str(evidence_id) in available],
            *coverage_evidence,
        ]))
        coverage_status = _short_text(value.get("coverage_status"), 32)
        if coverage_evidence and coverage_status == "insufficient":
            coverage_status = "partial"
        return {
            "schema_version": 1, "coverage_status": coverage_status,
            "supported_claims": value.get("supported_claims", []),
            "unsupported_questions": value.get("unsupported_questions", []),
            "conflicts": value.get("conflicts", []),
            "allowed_evidence_ids": allowed, "coverage": coverage,
        }

    def gap_analyst(self, plan: Mapping[str, Any], review: Mapping[str, Any], evidence_set: Mapping[str, Any],
                    round_number: int) -> Mapping[str, Any]:
        response = self.model_json("gap_analyst", {
            "round": round_number, "plan": {"groups": plan["groups"]}, "review": review,
            "evidence": _compact_records(evidence_set, 800),
            "instruction": (
                "Return JSON only with groups: [{group_id, queries}]. For each unresolved group, provide 1-4 narrow "
                "English scholarly queries targeting the missing metric, experiment condition, quality effect, or comparison. "
                "Do not request a uniform percentage when the literature may report non-comparable hardware, batch, model, "
                "or throughput results. Return an empty groups list only when targeted retrieval cannot improve the evidence."
            ),
        })
        value = _object(response)
        groups = []
        for item in value.get("groups", [])[:3]:
            if not isinstance(item, Mapping):
                continue
            queries = item.get("queries") or []
            if isinstance(queries, str):
                queries = [queries]
            if not isinstance(queries, list):
                continue
            normalized = [_short_text(query, 500) for query in queries if _short_text(query, 500)][:2]
            group_id = _short_text(item.get("group_id"), 128)
            if group_id and normalized:
                groups.append({"group_id": group_id, "queries": normalized})
        return {"schema_version": 1, "round": round_number, "groups": groups}

    def writer(self, question: Mapping[str, Any], review: Mapping[str, Any], evidence_set: Mapping[str, Any],
               prior_audit: Mapping[str, Any] | None = None) -> Mapping[str, Any]:
        response = self.model_json("writer", {
            "question": question["question"], "review": review,
            "evidence": [record for record in _compact_records(evidence_set, 2_000)
                         if record["evidence_id"] in set(review["allowed_evidence_ids"])],
            "prior_audit": prior_audit,
            "instruction": (
                "Return JSON only with answer, claim_evidence_map, coverage_status, unresolved_questions. "
                "Answer in Chinese using only approved evidence IDs. Every factual claim needs a claim_id and one or more "
                "approved evidence IDs. Cite factual claims inline only as [source:paper_id], using the exact source and paper_id "
                "from the supplied evidence. If coverage is partial, clearly state the uncertainty and unresolved questions."
            ),
        })
        value = _object(response)
        return {
            "schema_version": 1, "answer": value.get("answer"), "claim_evidence_map": value.get("claim_evidence_map", []),
            "coverage_status": value.get("coverage_status"), "unresolved_questions": value.get("unresolved_questions", []),
        }

    def auditor(self, draft: Mapping[str, Any], review: Mapping[str, Any]) -> Mapping[str, Any]:
        response = self.model_json("auditor", {
            "draft": draft, "review": review,
            "instruction": (
                "Return JSON only with status (passed, needs_revision, or failed), claim_results, rejected_claim_ids. "
                "Reject any claim whose evidence IDs are not in review.allowed_evidence_ids; do not add new claim IDs."
            ),
        })
        value = _object(response)
        result = {
            "schema_version": 1, "status": value.get("status"), "claim_results": value.get("claim_results", []),
            "rejected_claim_ids": value.get("rejected_claim_ids", []),
        }
        # The model's semantic audit is useful but not authoritative for the
        # literal citation namespace.  Reject source:id labels that cannot be
        # derived from this run's evidence records before the coordinator can
        # declare the answer complete.
        labels = set((self._evidence_labels or {}).values())
        cited_labels = set(re.findall(r"\[([A-Za-z][A-Za-z0-9_-]{0,31}:[^\]\r\n]{1,128})\]", str(draft.get("answer") or "")))
        if cited_labels - labels:
            result["status"] = "needs_revision"
            result["rejected_claim_ids"] = [item["claim_id"] for item in draft.get("claim_evidence_map", [])]
        return result

    def roles(self) -> LiteratureRoles:
        return LiteratureRoles(self.planner, self.retriever, self.reviewer, self.writer, self.auditor, self.gap_analyst)
