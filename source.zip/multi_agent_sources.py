"""Consent-gated source routing for the existing six-role pipeline.

All document/vector state stays in the private run. Public query vocabulary is
fixed by the question-only Planner before any uploaded passages are retrieved.
Agents select actions; they cannot enable networking or choose an index/path.
"""
from __future__ import annotations

import time
import re
from collections import Counter

from multi_agent_local_pdf import LocalPdfRagExecutor
from multi_agent_workflow import WorkflowError


MIXED_SCOPE = "uploaded_pdf_and_arxiv"
SEARCH_ACTION = "request_research_search"


def source_options(*, has_pdf: bool, policy=None, allow_public=False, question=""):
    if not isinstance(allow_public, bool):
        raise ValueError("INVALID_PUBLIC_SEARCH_PERMISSION")
    policy = ("local" if has_pdf else "public") if policy is None else policy
    if not isinstance(policy, str) or policy not in {"local", "auto", "public"}:
        raise ValueError("INVALID_SOURCE_POLICY")
    if not has_pdf and policy != "public":
        raise ValueError("SOURCE_POLICY_REQUIRES_PDF")
    if has_pdf and policy == "public":
        raise ValueError("UPLOADED_PDF_CANNOT_BE_IGNORED")
    if policy == "auto" and not allow_public:
        raise ValueError("PUBLIC_SEARCH_PERMISSION_REQUIRED")
    # A public-only task has no private document whose contents could be
    # exposed; allowing public literature lookup is its normal default.  The
    # consent restriction applies only to the PDF+public hybrid route.
    if policy != "auto" and allow_public and has_pdf:
        raise ValueError("PUBLIC_SEARCH_PERMISSION_REQUIRES_AUTO")
    if policy == "auto" and re.search(
            r"不要联网|禁止联网|不(?:要)?检索外部|仅(?:依据|根据|使用|限于).{0,16}(?:本文|本篇|上传|这份|这篇)|仅本文|"
            r"do not (?:search|browse)|no (?:external|public|internet) (?:search|sources)|only (?:the |this |uploaded )*(?:pdf|paper|document)",
            question, re.I):
        return {"source_policy": "local", "public_search_allowed": False, "source_scope": "uploaded_pdf",
                "source_policy_reason": "USER_DOCUMENT_ONLY"}
    return {"source_policy": policy, "public_search_allowed": allow_public,
            "source_scope": MIXED_SCOPE if policy == "auto" else "uploaded_pdf" if has_pdf else "arxiv"}


class AutoSourceExecutor:
    search_action = SEARCH_ACTION

    def __init__(self, run_dir, pdf, *, allow_public=False, rag_mode="hybrid", public_factory=None, **local_options):
        source_options(has_pdf=True, policy="auto", allow_public=allow_public)
        self.local = LocalPdfRagExecutor(run_dir, pdf, rag_mode=rag_mode, **local_options)
        self.run_dir, self.services = self.local.run_dir, self.local.services
        self.public_factory = public_factory
        self.public = None
        self.plan = {"groups": []}
        self.public_queries = set()
        self.primary_targets = {}
        self.source_clues = {}
        self.local_snapshot, self.public_snapshot = {}, {}
        self.routes = []
        # No private filename, PDF hash, passages or prior answer in Planner context.
        self.source_context = {"schema_version": "sciassistant.research-source/v1",
            "source_scope": MIXED_SCOPE, "source_policy": "auto", "public_search_allowed": True,
            "title": "user-uploaded document", "parser": self.local.pdf_parse_mode, **self.local.parser_options,
            "public_query_policy": "question-plan-allowlist/v1",
            "planning_context_policy": "current-question-only/v1",
            "evidence_policy": "selected_passages_require_review_and_citation_audit"}

    def configure_plan(self, plan):
        for group in plan["groups"]:
            queries = group.get("queries")
            if (not isinstance(queries, list) or not 1 <= len(queries) <= 2
                    or any(not isinstance(query, str) or not 1 <= len(query.strip()) <= 500 for query in queries)):
                raise WorkflowError("invalid question-only source queries")
        self.plan = plan
        self.local.configure_plan(plan)
        self.public_queries = {(group["id"], query.strip()) for group in plan["groups"]
            for query in group.get("queries", []) if isinstance(query, str) and 1 <= len(query.strip()) <= 500}
        from multi_agent_quality import PRIMARY_SOURCE_POLICY
        self.primary_targets = {}
        if plan.get("primary_source_policy") == PRIMARY_SOURCE_POLICY:
            for target in plan.get("primary_source_targets", []):
                pair = (target.get("group_id"), target.get("query"))
                if pair not in self.public_queries:
                    raise WorkflowError("original title must be inside question-only plan")
                self.primary_targets[pair[0]] = pair[1]
        if self.public:
            self.public.configure_plan(plan)

    def configure_source_clues(self, requirements):
        self.source_clues = requirements
        if self.public and hasattr(self.public, "configure_source_clues"):
            self.public.configure_source_clues(requirements)

    def _public_executor(self):
        if self.public is None:
            if self.public_factory:
                self.public = self.public_factory()
            else:
                from multi_agent_live import LiveArxivRagExecutor
                self.public = LiveArxivRagExecutor(self.run_dir, self.local.storage_root / "external",
                    rag_mode=self.local.rag_mode, services=self.services, evidence_store=self.local.evidence_store)
            if hasattr(self.public, "configure_plan"):
                self.public.configure_plan(self.plan)
            if hasattr(self.public, "configure_source_clues"):
                self.public.configure_source_clues(self.source_clues)
        return self.public

    def _requests(self, requests, recovery, group_ids):
        from multi_agent_pipeline_v2 import complete_initial_search_actions
        if len(requests) > (2 if recovery else 6):
            raise WorkflowError("too many source search actions")
        complete_initial_search_actions(self.plan, requests, action=SEARCH_ACTION)
        local, public = [], []
        for row in requests:
            args = row["arguments"]
            if set(args) - {"source", "query", "group_id", "gap_id"}:
                raise WorkflowError("source search cannot choose a path, URL or index")
            if args["group_id"] not in group_ids:
                raise WorkflowError("unknown source search group")
            source = args.get("source", "uploaded_pdf")
            if not isinstance(source, str) or source not in {"uploaded_pdf", "arxiv"}:
                raise WorkflowError("invalid search source")
            if source == "arxiv" and (args["group_id"], args["query"].strip()) not in self.public_queries:
                raise WorkflowError("public query is outside question-only plan")
            converted = {**row, "action": "request_document_search" if source == "uploaded_pdf" else "request_arxiv_search",
                         "arguments": {key: value for key, value in args.items() if key != "source"}}
            (local if source == "uploaded_pdf" else public).append(converted)
        if not recovery:
            # All proposed actions were permission-checked above. Fulfill an
            # explicit original-source request using a pre-PDF planned slot;
            # never rewrite recovery terms or admit an unplanned public query.
            for group_id, query in self.primary_targets.items():
                if any(r["arguments"]["group_id"] == group_id and r["arguments"]["query"] == query for r in public):
                    continue
                candidates = [r for r in [*public, *local] if r["arguments"]["group_id"] == group_id]
                old = next((r for r in candidates if r["arguments"]["query"] == query), candidates[-1] if candidates else None)
                if old is None:
                    raise WorkflowError("original source group has no action")
                (public if old in public else local).remove(old)
                public.append({**old, "action": "request_arxiv_search", "arguments": {**old["arguments"], "query": query}})
                self.routes.append({"group_id": group_id, "source": "arxiv", "query": query,
                    "source_status": "planned_original_action", "reason_code": "QUESTION_REQUESTED_ORIGINAL_OPPORTUNITY"})
        # Always examine the uploaded source first. Keep <=2 total slots/topic.
        if not recovery:
            for group in self.plan["groups"]:
                if not any(row["arguments"]["group_id"] == group["id"] for row in local):
                    candidates = [row for row in public if row["arguments"]["group_id"] == group["id"]]
                    if len(candidates) == 2:
                        removable = next((row for row in reversed(candidates)
                            if row["arguments"]["query"] != self.primary_targets.get(group["id"])), candidates[-1])
                        public.remove(removable)
                    local.append({"request_id": "local-first-" + group["id"], "action": "request_document_search",
                        "arguments": {"group_id": group["id"], "query": group["queries"][0]}})
        return local, public

    def validate_recovery_actions(self, requests, gaps, group_ids):
        """Reject proposed recovery before tools run; never reinterpret its source."""
        allowed = {(row["gap_id"], row["group_id"], row["query"].strip()) for row in gaps}
        try:
            if not requests or any((row["arguments"].get("gap_id"), row["arguments"].get("group_id"),
                    str(row["arguments"].get("query", "")).strip()) not in allowed for row in requests):
                raise WorkflowError("source recovery does not match approved gaps")
            self._requests(requests, True, group_ids)
        except WorkflowError:
            return {"schema_version": "sciassistant.validation-report/v1", "stage": "source_recovery",
                "valid": False, "reason_code": "SOURCE_RECOVERY_ACTION_REJECTED", "action_count": len(requests),
                "recovery_action": "keep_prior_review_no_new_evidence_no_network"}
        return {"schema_version": "sciassistant.validation-report/v1", "stage": "source_recovery", "valid": True}

    def _snapshot(self, recovery=False, active_source=None):
        local = self.local_snapshot.get("evidence", [])
        public = self.public_snapshot.get("evidence", [])
        # Balanced source opportunity, never approval. Reviewer sees every selected ID.
        rows, seen = [], set()
        if local and public:
            streams = [local[:6], public[:6]]
            for rank in range(6):
                for stream in streams:
                    if rank < len(stream) and stream[rank]["evidence_id"] not in seen:
                        rows.append(stream[rank]); seen.add(stream[rank]["evidence_id"])
        else:
            rows = list(local or public)[:12]
        local_events = self.local_snapshot.get("observations", [])
        public_events = [{"source": "arxiv", **row} for row in self.public_snapshot.get("observations", [])]
        events = ([*self.routes, *public_events, *local_events] if active_source == "uploaded_pdf" else
            [*self.routes, *local_events, *public_events] if active_source == "arxiv" else
            [*local_events, *public_events, *self.routes])
        return {"schema_version": "sciassistant.evidence-set/v2", "evidence": rows,
            "observations": events,
            "reading_summary": self.reading_summary(), "recovery": recovery}

    def execute(self, requests, *, recovery=False, group_ids=None, deadline=None, progress=None):
        group_ids = set(group_ids or [group["id"] for group in self.plan["groups"]])
        local, public = self._requests(requests, recovery, group_ids)
        def update_local(snapshot):
            self.local_snapshot = snapshot
            if progress: progress(self._snapshot(recovery, active_source="uploaded_pdf"))
        def update_public(snapshot):
            self.public_snapshot = snapshot
            if progress: progress(self._snapshot(recovery, active_source="arxiv"))
        if local:
            self.local_snapshot = self.local.execute(local, recovery=recovery, group_ids=group_ids,
                deadline=deadline, progress=update_local)
        if public:
            if deadline is not None and time.monotonic() >= deadline:
                self.routes.append({"source": "arxiv", "source_status": "deadline_skipped", "reason_code": "FINAL_ANSWER_BUDGET_RESERVED"})
            else:
                from requests import RequestException
                from multi_agent_rag import RagError
                try:
                    self.public_snapshot = self._public_executor().execute(public, recovery=recovery,
                        group_ids=group_ids, deadline=deadline, progress=update_public)
                except (RequestException, TimeoutError, RagError):
                    self.routes.append({"source": "arxiv", "source_status": "error", "reason_code": "EXTERNAL_SOURCE_UNAVAILABLE"})
        self.routes.append({"source_status": "source_routing_completed", "local_actions": len(local),
            "public_actions": len(public), "recovery": recovery})
        result = self._snapshot(recovery)
        if progress: progress(result)
        return result

    @property
    def pdf_reads(self):
        return self.local.pdf_reads + getattr(self.public, "pdf_reads", 0)

    def has_more_reading(self, focus_groups=None):
        return bool(self.public and hasattr(self.public, "has_more_reading") and self.public.has_more_reading(focus_groups))

    def continue_reading(self, *, deadline, progress=None, focus_groups=None):
        def update(snapshot):
            self.public_snapshot = snapshot
            if progress: progress(self._snapshot(active_source="arxiv"))
        self.public_snapshot = self.public.continue_reading(deadline=deadline, progress=update, focus_groups=focus_groups)
        return self._snapshot()

    def reading_summary(self):
        local = self.local.reading_summary()
        public = self.public.reading_summary() if self.public and hasattr(self.public, "reading_summary") else {}
        return {**local, "paper_limit": 16, "batch_limit": 4,
            **{key: local.get(key, 0) + public.get(key, 0) for key in
                ("papers_attempted", "papers_indexed", "batches_used", "candidates_observed", "remaining_candidates")}}

    def reading_decisions(self, stop_reason):
        public = self.public.reading_decisions(stop_reason) if self.public and hasattr(self.public, "reading_decisions") else []
        return [*self.local.reading_decisions(stop_reason), *public]

    def retrieval_configuration(self):
        from multi_agent_live import READING_PRIORITY_POLICY
        return {**self.local.retrieval_configuration(), "source_scope": MIXED_SCOPE, "source_policy": "auto",
            "public_search_allowed": True, "public_query_policy": "question-plan-allowlist/v1",
            "pdf_paper_limit": 16, "pdf_batch_limit": 4, "public_paper_limit": 15,
            "pdf_download_hosts": 2, "pdf_download_total_budget_seconds": 30,
            "pdf_download_max_attempts": 2, "pdf_download_deadline_policy": "isolated-process-shared-deadline/v1",
            "packet_selection": "local-first-balanced-sources-6-plus-6", "vector_scope": "private_run_local",
            "public_reading_priority_policy": READING_PRIORITY_POLICY}

    def routing_summary(self):
        return {"schema_version": "sciassistant.source-routing/v1", "policy": "auto",
            "public_search_allowed": True, "public_query_policy": "question-plan-allowlist/v1",
            "planned_public_query_count": len(self.public_queries),
            "selected_sources": dict(Counter(row["source"] for row in self._snapshot()["evidence"])),
            "routes": self.routes}
