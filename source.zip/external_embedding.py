"""Bounded embedding transport. No Agent, model token, or provider response logging."""
from __future__ import annotations

import hashlib
import ipaddress
import json
import math
import os
import sqlite3
from pathlib import Path
from urllib.parse import urlsplit

from multi_agent_rag import RagError


def checked_endpoint(value):
    parts = urlsplit(value)
    allowed = {v.strip().lower() for v in os.getenv('SCIASSISTANT_EMBEDDING_ALLOWED_HOSTS', '').split(',') if v.strip()}
    host = (parts.hostname or '').lower()
    if (parts.scheme != 'https' or not host or host not in allowed or parts.username or parts.password
            or parts.query or parts.fragment or parts.port not in {None, 443}
            or host == 'localhost' or host.endswith(('.localhost', '.local'))):
        raise RagError('EMBEDDING_ENDPOINT_REJECTED')
    try:
        ipaddress.ip_address(host)
    except ValueError:
        return value
    raise RagError('EMBEDDING_ENDPOINT_REJECTED')


def checked_vectors(rows, count, dimension):
    if not isinstance(rows, list) or len(rows) != count:
        raise RagError('EMBEDDING_RESPONSE_INVALID')
    result = []
    for row in rows:
        if (not isinstance(row, list) or len(row) != dimension
                or any(type(v) not in {int, float} or not math.isfinite(v) for v in row)):
            raise RagError('EMBEDDING_RESPONSE_INVALID')
        norm = math.sqrt(sum(float(v) ** 2 for v in row))
        if not math.isfinite(norm) or norm <= 0:
            raise RagError('EMBEDDING_RESPONSE_INVALID')
        result.append([float(v) / norm for v in row])
    return result


class ExternalEmbedding:
    """Explicit /embeddings JSON contract; support must be verified per supplier."""
    external = True

    def __init__(self):
        from user_credentials import provider_value
        self._endpoint = checked_endpoint(os.getenv('SCIASSISTANT_EMBEDDING_URL', ''))
        self._key = provider_value('EMBEDDING_API_KEY')
        self.model_name = os.getenv('SCIASSISTANT_EXTERNAL_EMBEDDING_MODEL', '').strip()
        try:
            self.dimension = int(os.getenv('SCIASSISTANT_EXTERNAL_EMBEDDING_DIMENSION', '0'))
        except ValueError:
            raise RagError('EMBEDDING_CONFIG_INVALID') from None
        if not self._key or not self.model_name or len(self.model_name) > 200 or not 1 <= self.dimension <= 8192:
            raise RagError('EMBEDDING_CONFIG_INVALID')
        self.revision = 'external-json-v1-' + hashlib.sha256(json.dumps(
            [self._endpoint, self.model_name, self.dimension,
             os.getenv('SCIASSISTANT_EXTERNAL_EMBEDDING_REVISION', 'unpinned')], separators=(',', ':')).encode()).hexdigest()
        self.request_count = 0

    def embed(self, texts):
        if not texts:
            return []
        if len(texts) > 32 or any(not isinstance(t, str) or not t or len(t) > 32000 for t in texts):
            raise RagError('EMBEDDING_INPUT_LIMIT')
        import requests
        try:
            # No inherited proxy, no redirect of bearer keys, no hidden retries.
            with requests.Session() as session:
                session.trust_env = False
                self.request_count += 1
                with session.post(self._endpoint, json={'model': self.model_name, 'input': list(texts),
                        'encoding_format': 'float'}, headers={'Authorization': 'Bearer ' + self._key},
                        timeout=(5, 20), allow_redirects=False, stream=True) as response:
                    if response.status_code != 200:
                        code = 'RATE_LIMITED' if response.status_code == 429 else 'REQUEST_FAILED'
                        raise RagError('EMBEDDING_' + code)
                    data = bytearray()
                    import time
                    deadline = time.monotonic() + 25
                    for part in response.iter_content(65536):
                        data.extend(part)
                        if len(data) > 2 * 1024 * 1024 or time.monotonic() > deadline:
                            raise RagError('EMBEDDING_RESPONSE_LIMIT')
                    raw = json.loads(data)
                    rows = raw.get('data') if isinstance(raw, dict) else None
                    if not isinstance(rows, list) or len(rows) != len(texts):
                        raise RagError('EMBEDDING_RESPONSE_INVALID')
                    if any(not isinstance(row, dict) or type(row.get('index')) is not int for row in rows):
                        raise RagError('EMBEDDING_RESPONSE_INVALID')
                    ordered = sorted(rows, key=lambda row: row['index'])
                    if [row['index'] for row in ordered] != list(range(len(texts))):
                        raise RagError('EMBEDDING_RESPONSE_INVALID')
                    return checked_vectors([row['embedding'] for row in ordered], len(texts), self.dimension)
        except RagError:
            raise
        except Exception:
            raise RagError('EMBEDDING_REQUEST_FAILED') from None

    def embed_query(self, query):
        return self.embed([query])[0]


class CachedEmbedding:
    """Owner/store-local cache. Only hashes and vectors, never raw document text."""
    def __init__(self, provider, path):
        self.provider, self.path = provider, Path(path)
        self.model_name, self.dimension = provider.model_name, provider.dimension
        self.revision = getattr(provider, 'revision', '')
        self.external = getattr(provider, 'external', False)
        self.identity = hashlib.sha256(json.dumps([self.model_name, self.dimension, self.revision]).encode()).hexdigest()
        self.hits = self.misses = 0

    def embed(self, texts):
        keys = [hashlib.sha256((self.identity + '\0' + t).encode()).hexdigest() for t in texts]
        self.path.parent.mkdir(parents=True, exist_ok=True)
        con = sqlite3.connect(self.path, timeout=5)
        try:
            con.execute('CREATE TABLE IF NOT EXISTS embedding_cache (key TEXT PRIMARY KEY, vector TEXT NOT NULL)')
            found = {}
            for key in dict.fromkeys(keys):
                row = con.execute('SELECT vector FROM embedding_cache WHERE key=?', (key,)).fetchone()
                if row:
                    try:
                        found[key] = checked_vectors([json.loads(row[0])], 1, self.dimension)[0]
                    except (RagError, ValueError, TypeError):
                        pass  # Invalid local cache is recomputed, never sent as a vector.
            missing = list(dict.fromkeys(k for k in keys if k not in found))
            self.hits += len(keys) - len(missing)
            self.misses += len(missing)
            if missing:
                originals = {key: text for key, text in zip(keys, texts)}
                vectors = checked_vectors(self.provider.embed([originals[k] for k in missing]), len(missing), self.dimension)
                for key, vector in zip(missing, vectors):
                    found[key] = vector
                    con.execute('INSERT OR REPLACE INTO embedding_cache VALUES (?,?)', (key, json.dumps(vector)))
                con.commit()
            return [found[key] for key in keys]
        finally:
            con.close()

    def embed_query(self, query):
        # E5's query prefix/pooling differs from passage embedding; do not share.
        if hasattr(self.provider, 'embed_query'):
            return self.provider.embed_query(query)
        return self.provider.embed([query])[0]

    def clear(self):
        # Deletion evicts all derived vectors in this store, including old model
        # revisions. Other documents may be recomputed; no deleted vector lingers.
        if self.path.exists():
            with sqlite3.connect(self.path, timeout=5) as con:
                con.execute('DELETE FROM embedding_cache')
