"""Structured, stateless Agent runtime for the bounded literature pipeline."""

from __future__ import annotations

import hashlib
import json
import os
import re
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence
from multi_agent_report_contracts import report_budget


AGENT_INPUT_SCHEMA = "sciassistant.agent-input/v1"
AGENT_INPUT_V2_SCHEMA = "sciassistant.agent-input/v2"
AGENT_RESULT_SCHEMA = "sciassistant.agent-result/v1"
ARTIFACT_REF_SCHEMA = "sciassistant.artifact-ref/v1"
REWORK_TICKET_SCHEMA = "sciassistant.rework-ticket/v1"
AGENT_ROLES = frozenset({"planner", "retriever", "reviewer", "gap_analyst", "writer", "citation_auditor"})
AGENT_STATUSES = frozenset({"completed", "rework_required", "blocked", "failed", "skipped"})
MODEL_DELIVERY_SCHEMA = "sciassistant.model-delivery/v1"
ROLE_ALLOWED_ACTIONS = {
    "planner": frozenset({"create_research_plan"}),
    "retriever": frozenset({"request_arxiv_search", "request_document_search", "request_research_search"}),
    "reviewer": frozenset({"review_evidence", "request_gap_analysis"}),
    "gap_analyst": frozenset({"create_gap_search_plan"}),
    "writer": frozenset({"write_approved_claims", "revise_answer"}),
    "citation_auditor": frozenset({"audit_citations", "request_writer_revision"}),
}
_SAFE_ID = re.compile(r"[A-Za-z0-9_.-]{1,160}\Z")
_SENSITIVE_KEY = re.compile(r"(?:authorization|api[_ -]?key|token|secret|password|cookie|chain.of.thought|reasoning.trace)", re.I)


def sanitize_artifact_text(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: sanitize_artifact_text(item) for key, item in value.items()}
    if isinstance(value, list):
        return [sanitize_artifact_text(item) for item in value]
    if isinstance(value, str):
        text = re.sub(r"(?i)\bbearer\s+[a-z0-9._-]+", "Bearer [REDACTED]", value)
        text = re.sub(r"(?i)\b(?:authorization|api[_ -]?key|token|secret|password)\s*[:=]\s*[^\s,;\"']+", "[REDACTED]", text)
        text = re.sub(r"\beyJ[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+\b", "[REDACTED]", text)
        text = re.sub(r"(?i)\b[A-Z]:[\\/][^\s\"<>]+", "[REDACTED_PATH]", text)
        text = re.sub(r"(?<![\w:/])/(?:home|Users|var|tmp|app|opt|etc)/[^\s\"<>]+", "[REDACTED_PATH]", text)
        return text
    return value


class AgentContractError(ValueError):
    """The Agent packet violates the public structured contract."""


def _id(value: Any, label: str) -> str:
    text = str(value or "")
    if not _SAFE_ID.fullmatch(text):
        raise AgentContractError(f"invalid {label}")
    return text


def _json_copy(value: Any) -> Any:
    try:
        return json.loads(json.dumps(value, ensure_ascii=False, allow_nan=False))
    except (TypeError, ValueError) as exc:
        raise AgentContractError("value must be JSON serializable") from exc


def _reject_sensitive(value: Any, key: str = "") -> None:
    if _SENSITIVE_KEY.search(key):
        raise AgentContractError("sensitive field is not allowed")
    if isinstance(value, Mapping):
        for nested_key, nested_value in value.items():
            if not isinstance(nested_key, str):
                raise AgentContractError("object keys must be text")
            _reject_sensitive(nested_value, nested_key)
    elif isinstance(value, list):
        for item in value:
            _reject_sensitive(item)


def validate_agent_input(value: Mapping[str, Any]) -> dict[str, Any]:
    packet = _json_copy(dict(value))
    expected = {
        "schema_version", "run_id", "agent_role", "goal", "input_artifact_ids",
        "remaining_model_calls", "deadline_at", "allowed_actions", "configuration_fingerprint",
    }
    current = packet.get('schema_version') == AGENT_INPUT_V2_SCHEMA
    if current:
        expected.add('report_profile')
    if set(packet) != expected or packet.get("schema_version") not in {AGENT_INPUT_SCHEMA, AGENT_INPUT_V2_SCHEMA}:
        raise AgentContractError("invalid AgentInput fields")
    _id(packet["run_id"], "run id")
    role = _id(packet["agent_role"], "agent role")
    if role not in AGENT_ROLES:
        raise AgentContractError("unsupported agent role")
    if not isinstance(packet["goal"], str) or not 1 <= len(packet["goal"].strip()) <= 4_000:
        raise AgentContractError("invalid agent goal")
    if not isinstance(packet["input_artifact_ids"], list) or len(packet["input_artifact_ids"]) > 20:
        raise AgentContractError("invalid input artifact ids")
    for artifact_id in packet["input_artifact_ids"]:
        _id(artifact_id, "artifact id")
    try:
        maximum_calls = report_budget(packet['report_profile'] if current else 'standard')['model_call_limit']
    except ValueError:
        raise AgentContractError('invalid report profile') from None
    if type(packet["remaining_model_calls"]) is not int or not 0 <= packet["remaining_model_calls"] <= maximum_calls:
        raise AgentContractError("invalid remaining call budget")
    if not isinstance(packet["deadline_at"], (int, float)):
        raise AgentContractError("invalid deadline")
    if not isinstance(packet["allowed_actions"], list):
        raise AgentContractError("invalid allowed actions")
    actions = set(packet["allowed_actions"])
    if not actions.issubset(ROLE_ALLOWED_ACTIONS[role]):
        raise AgentContractError("agent action is not allowed for role")
    _id(packet["configuration_fingerprint"], "configuration fingerprint")
    _reject_sensitive(packet)
    return packet


def _validate_tool_request(role: str, request: Mapping[str, Any]) -> dict[str, Any]:
    value = _json_copy(dict(request))
    if set(value) != {"request_id", "action", "arguments"}:
        raise AgentContractError("invalid tool request fields")
    _id(value["request_id"], "tool request id")
    action = _id(value["action"], "tool action")
    if action not in ROLE_ALLOWED_ACTIONS[role]:
        raise AgentContractError("tool action is not allowed for role")
    if not isinstance(value["arguments"], dict):
        raise AgentContractError("tool arguments must be an object")
    _reject_sensitive(value)
    return value


def validate_rework_ticket(value: Mapping[str, Any], *, run_id: str) -> dict[str, Any]:
    ticket = _json_copy(dict(value))
    expected = {
        "schema_version", "ticket_id", "run_id", "from_role", "to_role", "reason_code",
        "artifact_ids", "required_changes", "round",
    }
    if set(ticket) != expected or ticket.get("schema_version") != REWORK_TICKET_SCHEMA:
        raise AgentContractError("invalid rework ticket")
    _id(ticket["ticket_id"], "ticket id")
    if _id(ticket["run_id"], "run id") != run_id:
        raise AgentContractError("rework run mismatch")
    if _id(ticket["from_role"], "from role") not in AGENT_ROLES:
        raise AgentContractError("invalid rework source")
    if _id(ticket["to_role"], "to role") not in AGENT_ROLES:
        raise AgentContractError("invalid rework target")
    _id(ticket["reason_code"], "reason code")
    if not isinstance(ticket["artifact_ids"], list) or len(ticket["artifact_ids"]) > 20:
        raise AgentContractError("invalid rework artifacts")
    for artifact_id in ticket["artifact_ids"]:
        _id(artifact_id, "artifact id")
    if not isinstance(ticket["required_changes"], list) or not 1 <= len(ticket["required_changes"]) <= 20:
        raise AgentContractError("invalid required changes")
    if any(not isinstance(item, str) or not item.strip() or len(item) > 1_000 for item in ticket["required_changes"]):
        raise AgentContractError("invalid required change")
    if ticket["round"] not in {1}:
        raise AgentContractError("only one rework round is allowed")
    _reject_sensitive(ticket)
    return ticket


def validate_agent_result(value: Mapping[str, Any], *, role: str, run_id: str) -> dict[str, Any]:
    packet = _json_copy(dict(value))
    expected = {
        "schema_version", "status", "output_artifact_ids", "tool_requests",
        "rework_ticket", "usage", "error_code",
    }
    if set(packet) != expected or packet.get("schema_version") != AGENT_RESULT_SCHEMA:
        raise AgentContractError("invalid AgentResult fields")
    if packet["status"] not in AGENT_STATUSES:
        raise AgentContractError("invalid agent result status")
    if not isinstance(packet["output_artifact_ids"], list) or len(packet["output_artifact_ids"]) > 20:
        raise AgentContractError("invalid output artifact ids")
    for artifact_id in packet["output_artifact_ids"]:
        _id(artifact_id, "artifact id")
    if not isinstance(packet["tool_requests"], list) or len(packet["tool_requests"]) > 8:
        raise AgentContractError("invalid tool requests")
    packet["tool_requests"] = [_validate_tool_request(role, item) for item in packet["tool_requests"]]
    if packet["rework_ticket"] is not None:
        packet["rework_ticket"] = validate_rework_ticket(packet["rework_ticket"], run_id=run_id)
    usage = packet["usage"]
    if not isinstance(usage, dict) or set(usage) != {"model_calls", "elapsed_ms"}:
        raise AgentContractError("invalid agent usage")
    if not isinstance(usage["model_calls"], int) or usage["model_calls"] not in {0, 1}:
        raise AgentContractError("invalid model call usage")
    if not isinstance(usage["elapsed_ms"], int) or usage["elapsed_ms"] < 0:
        raise AgentContractError("invalid elapsed time")
    if packet["error_code"] is not None:
        _id(packet["error_code"], "error code")
    _reject_sensitive(packet)
    return packet


class ArtifactDirectory:
    """Content-addressed JSON artifacts; Agent workers only receive IDs."""

    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def put(self, artifact_type: str, payload: Mapping[str, Any]) -> dict[str, Any]:
        artifact_type = _id(artifact_type, "artifact type")
        value = sanitize_artifact_text(_json_copy(dict(payload)))
        _reject_sensitive(value)
        encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        if len(encoded.encode("utf-8")) > 1_000_000:
            raise AgentContractError("artifact exceeds size limit")
        digest = hashlib.sha256(encoded.encode("utf-8")).hexdigest()
        artifact_id = f"{artifact_type}-{digest[:20]}"
        path = self.root / f"{artifact_id}.json"
        if not path.exists():
            temporary = self.root / f".{artifact_id}-{uuid.uuid4().hex}.tmp"
            try:
                temporary.write_text(encoded, encoding="utf-8")
                os.replace(temporary, path)
            finally:
                temporary.unlink(missing_ok=True)
        return {"schema_version": ARTIFACT_REF_SCHEMA, "artifact_id": artifact_id,
                "artifact_type": artifact_type, "sha256": digest}

    def get(self, artifact_id: str) -> dict[str, Any]:
        artifact_id = _id(artifact_id, "artifact id")
        path = self.root / f"{artifact_id}.json"
        if path.is_symlink() or not path.is_file() or path.stat().st_size > 1_000_000:
            raise AgentContractError("artifact not found")
        value = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise AgentContractError("artifact must be an object")
        encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
        digest = hashlib.sha256(encoded.encode("utf-8")).hexdigest()[:20]
        if not artifact_id.endswith("-" + digest):
            raise AgentContractError("artifact checksum mismatch")
        _reject_sensitive(value)
        return value


def decode_json_object(value: Mapping[str, Any] | str) -> dict[str, Any]:
    """One deterministic JSON repair: strip a single Markdown code fence."""
    if isinstance(value, Mapping):
        return dict(value)
    candidate = str(value or "").strip()
    if candidate.startswith("```"):
        candidate = re.sub(r"^```(?:json)?\s*|\s*```$", "", candidate, flags=re.I)
    try:
        decoded = json.loads(candidate)
    except ValueError as exc:
        raise AgentContractError("agent returned invalid JSON") from exc
    if not isinstance(decoded, dict):
        raise AgentContractError("agent returned invalid JSON object")
    return decoded


AgentHandler = Callable[[Mapping[str, Any]], Mapping[str, Any] | str]


@dataclass
class AgentWorker:
    """One role, one call, no scheduler/database/tool ownership."""

    role: str
    handler: AgentHandler
    allowed_actions: Sequence[str]
    uses_model: bool = True

    def __post_init__(self) -> None:
        if self.role not in AGENT_ROLES:
            raise AgentContractError("unsupported agent role")
        if not set(self.allowed_actions).issubset(ROLE_ALLOWED_ACTIONS[self.role]):
            raise AgentContractError("worker requests forbidden action")

    def run(self, agent_input: Mapping[str, Any], artifacts: ArtifactDirectory) -> dict[str, Any]:
        packet = validate_agent_input(agent_input)
        if packet["agent_role"] != self.role:
            raise AgentContractError("AgentInput role mismatch")
        if not set(self.allowed_actions).issubset(set(packet["allowed_actions"])):
            raise AgentContractError("AgentInput action set mismatch")
        if time.time() >= float(packet["deadline_at"]):
            return validate_agent_result({
                "schema_version": AGENT_RESULT_SCHEMA, "status": "blocked", "output_artifact_ids": [],
                "tool_requests": [], "rework_ticket": None,
                "usage": {"model_calls": 0, "elapsed_ms": 0}, "error_code": "AGENT_DEADLINE_EXCEEDED",
            }, role=self.role, run_id=packet["run_id"])
        inputs = [{"artifact_id": artifact_id, "payload": artifacts.get(artifact_id)}
                  for artifact_id in packet["input_artifact_ids"]]
        started = time.monotonic()
        remaining = max(0.0, float(packet["deadline_at"]) - time.time())
        try:
            raw = decode_json_object(self.handler({
                "schema_version": packet['schema_version'],
                "run_id": packet["run_id"], "role": self.role, "goal": packet["goal"],
                "inputs": inputs, "allowed_actions": list(self.allowed_actions),
                "remaining_model_calls": packet["remaining_model_calls"], "deadline_at": packet["deadline_at"],
                **({'report_profile': packet['report_profile']} if 'report_profile' in packet else {}),
            }))
            if time.monotonic() - started >= remaining:
                return validate_agent_result({
                    "schema_version": AGENT_RESULT_SCHEMA, "status": "blocked", "output_artifact_ids": [],
                    "tool_requests": [], "rework_ticket": None,
                    "usage": {"model_calls": int(self.uses_model),
                              "elapsed_ms": round((time.monotonic() - started) * 1000)},
                    "error_code": "AGENT_DEADLINE_EXCEEDED",
                }, role=self.role, run_id=packet["run_id"])
            output = raw.get("output")
            if any(item.get("action") not in self.allowed_actions for item in raw.get("tool_requests", [])):
                raise AgentContractError("tool request is outside this worker's source scope")
            output_ids: list[str] = []
            delivery = raw.get("delivery_metadata")
            if isinstance(delivery, Mapping) and delivery.get("schema_version") == MODEL_DELIVERY_SCHEMA:
                # Separate diagnostics, never a role output or a scientific verdict.
                # Keep output_artifact_ids compatible: consumers use both first
                # and last entries to load the actual role result.
                fields = {"schema_version", "finish_reason", "output_limit", "visible_char_count",
                          "completion_units", "prompt_units"}
                counts = {"output_limit", "visible_char_count", "completion_units", "prompt_units"}
                framing = delivery.get('json_framing_repair')
                if ((set(delivery) == fields or (set(delivery) == fields | {'json_framing_repair'}
                        and framing == 'AUDITOR_EMPTY_TOOL_TAIL' and self.role == 'citation_auditor'
                        and delivery.get('finish_reason') == 'stop'))
                        and delivery.get("finish_reason") in {"stop", "length", "content_filter", "tool_calls", "unknown"}
                        and all(delivery[key] is None or (type(delivery[key]) is int and 0 <= delivery[key] <= 10_000_000)
                                for key in counts)):
                    artifacts.put("model-delivery", {**dict(delivery), "run_id": packet["run_id"],
                        "agent_role": self.role, "input_artifact_ids": packet["input_artifact_ids"]})
            if output is not None:
                if not isinstance(output, Mapping):
                    raise AgentContractError("agent output must be an object")
                output_ids.append(artifacts.put(f"{self.role}-output", output)["artifact_id"])
            result = {
                "schema_version": AGENT_RESULT_SCHEMA,
                "status": raw.get("status", "completed"),
                "output_artifact_ids": output_ids,
                "tool_requests": raw.get("tool_requests", []),
                "rework_ticket": raw.get("rework_ticket"),
                "usage": {"model_calls": 1 if self.uses_model else 0,
                          "elapsed_ms": round((time.monotonic() - started) * 1000)},
                "error_code": raw.get("error_code"),
            }
            return validate_agent_result(result, role=self.role, run_id=packet["run_id"])
        except AgentContractError:
            raise
        except Exception as exc:
            return validate_agent_result({
                "schema_version": AGENT_RESULT_SCHEMA, "status": "failed", "output_artifact_ids": [],
                "tool_requests": [], "rework_ticket": None,
                "usage": {"model_calls": 1 if self.uses_model else 0,
                          "elapsed_ms": round((time.monotonic() - started) * 1000)},
                "error_code": "AGENT_EXECUTION_FAILED",
            }, role=self.role, run_id=packet["run_id"])


def make_agent_input(*, run_id: str, role: str, goal: str, input_artifact_ids: Sequence[str],
                     remaining_model_calls: int, deadline_at: float,
                     configuration_fingerprint: str = "default-v1", report_profile: str | None = None) -> dict[str, Any]:
    packet = {
        "schema_version": AGENT_INPUT_SCHEMA, "run_id": run_id, "agent_role": role, "goal": goal,
        "input_artifact_ids": list(input_artifact_ids), "remaining_model_calls": remaining_model_calls,
        "deadline_at": deadline_at, "allowed_actions": sorted(ROLE_ALLOWED_ACTIONS[role]),
        "configuration_fingerprint": configuration_fingerprint,
    }
    if report_profile is not None:
        packet.update(schema_version=AGENT_INPUT_V2_SCHEMA, report_profile=report_profile)
    return validate_agent_input(packet)


def make_rework_ticket(*, run_id: str, from_role: str, to_role: str, reason_code: str,
                       artifact_ids: Sequence[str], required_changes: Sequence[str]) -> dict[str, Any]:
    return validate_rework_ticket({
        "schema_version": REWORK_TICKET_SCHEMA, "ticket_id": f"ticket-{uuid.uuid4().hex[:16]}",
        "run_id": run_id, "from_role": from_role, "to_role": to_role, "reason_code": reason_code,
        "artifact_ids": list(artifact_ids), "required_changes": list(required_changes), "round": 1,
    }, run_id=run_id)
