# Copyright (c) 2025 Huawei Technologies Co., Ltd. All rights reserved.
# Copyright (c) 2026 South China Sea Institute of Oceanology, Chinese Academy of Sciences (SCSIO, CAS). All rights reserved.
import os
from typing import Optional, Dict, Any, Iterator
from dataclasses import dataclass
from copy import copy
from contextlib import contextmanager
from contextvars import ContextVar
import logging
from pathlib import Path
from dotenv import load_dotenv, dotenv_values


# Load .env file from config directory
env_path = Path(__file__).parent / '.env'
load_dotenv(dotenv_path=env_path)
# A parent web process may load the repository-level `.env` first. That file
# intentionally contains blank placeholders, and python-dotenv will then keep
# those blanks instead of loading the real project configuration above. Use
# the config file as a fallback only when the inherited value is empty; a
# non-empty process environment variable still wins for deployment overrides.
_CONFIG_ENV = dotenv_values(env_path)
for _key, _value in _CONFIG_ENV.items():
    if os.getenv('SCIASSISTANT_PROVIDER_OWNER') and _key in {'MODEL_REQUEST_TOKEN', 'MODEL_REQUEST_TOKENS', 'LLAMA_CLOUD_API_KEY', 'OPENROUTER_API_KEY', 'OPENAI_API_KEY', 'DEEPSEEK_API_KEY'}:
        continue  # An empty user credential must stay empty, not inherit .env.
    if _value and not os.getenv(_key):
        os.environ[_key] = _value

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class APIConfig:
    """Configuration class for API keys and settings"""
    
    # Custom LLM Service Configuration
    # Your own deployed LLM service accessed via requests
    model_request_url: Optional[str] = None
    model_request_token: Optional[str] = None
    model_name: str = "pangu_auto"  # Default model name
    
    # Custom Planner Mode
    planner_mode: str = "auto"  # Default planner mode
    
    # MCP Server Configuration
    mcp_server_url: Optional[str] = None
    mcp_auth_token: Optional[str] = None
    mcp_use_stdio: bool = True  # Default to stdio for backward compatibility
    
    # Search Engine Configuration (Generic)
    search_engine_base_url: Optional[str] = None
    search_engine_api_keys: Optional[str] = None  # Can be comma-separated for rotation
    
    # URL Crawler Configuration (Generic)
    url_crawler_base_url: Optional[str] = None
    url_crawler_api_keys: Optional[str] = None  # Can be comma-separated for rotation
    url_crawler_max_tokens: int = 100000
    
    # Model Interaction Configuration
    model_temperature: float = 0.3
    model_max_tokens: int = 8192
    model_request_timeout: int = 6000
    
    # Tool Trajectory and Output Configuration  
    trajectory_storage_path: str = "./workspace"
    report_output_path: str = "./report"
    document_analysis_path: str = "./doc_analysis"
    
    # Per-agent iteration controls (optional; resolved by agent factories)
    planner_max_iterations: Optional[int] = None
    information_seeker_max_iterations: Optional[int] = None
    writer_max_iterations: Optional[int] = None
    
    # General Settings
    debug_mode: bool = False
    max_retries: int = 3
    timeout: int = 30

    # PDF parsing strategy. ``hybrid`` keeps local geometry as the anchor,
    # uses whole-PDF LlamaParse for content, and uses regional LlamaParse only
    # for visual supplements such as figures and flowcharts.
    pdf_parse_mode: str = "local"
    llama_vision_enabled: bool = False
    llama_cloud_api_key: str = ""
    llama_parse_tier: str = "agentic"
    llama_parse_endpoint: str = "https://api.cloud.llamaindex.ai"
    llama_parse_poll_interval: float = 2.0
    # Operational cap per PDF review round; LlamaParse credits are not fixed
    # per region, so this limits worst-case task count rather than promising a
    # precise credit conversion.
    llama_vision_max_regions: int = 20
    llama_vision_timeout: int = 60
    llama_vision_max_retries: int = 2
    llama_vision_max_tokens: int = 2048
    llama_vision_min_confidence: float = 0.85
    llama_vision_allow_override: bool = True
    # Optional whole-document LlamaParse transcription.  This is deliberately
    # separate from region review: full-document output is a supplemental
    # Writer source and never replaces local page/bbox evidence automatically.
    llama_full_pdf_enabled: bool = False
    llama_full_pdf_timeout: int = 600
    llama_full_pdf_max_retries: int = 1
    llama_full_pdf_use_as_writer_source: bool = True
    
    def __post_init__(self):
        """Load configuration from environment variables"""
        self.load_from_env()
    
    def load_from_env(self):
        """Load API keys and settings from environment variables"""
        # Custom LLM Service
        self.model_request_url = os.getenv('MODEL_REQUEST_URL')
        self.model_request_token = os.getenv('MODEL_REQUEST_TOKEN')
        self.model_name = os.getenv('MODEL_NAME', 'pangu-auto')
        # DeepSeek's OpenAI-compatible endpoint rejects the historical
        # ``pangu_auto`` placeholder. Keep old local .env files usable while
        # sending a model name accepted by the configured provider.
        if self.model_name.lower().replace('-', '_') == 'pangu_auto' and self.model_request_url:
            if 'api.deepseek.com' in self.model_request_url.lower():
                self.model_name = 'deepseek-v4-flash'
        
        # Custom Planner Mode
        self.planner_mode = os.getenv("PLANNER_MODE", self.planner_mode)
        
        # MCP Server
        self.mcp_server_url = os.getenv("MCP_SERVER_URL")
        self.mcp_auth_token = os.getenv("MCP_AUTH_TOKEN")
        self.mcp_use_stdio = os.getenv("MCP_USE_STDIO", "true").lower() == "true"
        
        # Search Engine Configuration
        self.search_engine_base_url = os.getenv("SEARCH_ENGINE_BASE_URL")
        self.search_engine_api_keys = os.getenv("SEARCH_ENGINE_API_KEYS")
        
        # URL Crawler Configuration
        self.url_crawler_base_url = os.getenv("URL_CRAWLER_BASE_URL")
        self.url_crawler_api_keys = os.getenv("URL_CRAWLER_API_KEYS")
        self.url_crawler_max_tokens = int(os.getenv("URL_CRAWLER_MAX_TOKENS", self.url_crawler_max_tokens))
        
        # Model Interaction Configuration
        self.model_temperature = float(os.getenv("MODEL_TEMPERATURE", self.model_temperature))
        self.model_max_tokens = int(os.getenv("MODEL_MAX_TOKENS", self.model_max_tokens))
        self.model_request_timeout = int(os.getenv("MODEL_REQUEST_TIMEOUT", self.model_request_timeout))
        
        # Tool Trajectory and Output Configuration
        self.trajectory_storage_path = os.getenv("TRAJECTORY_STORAGE_PATH", self.trajectory_storage_path)
        self.report_output_path = os.getenv("REPORT_OUTPUT_PATH", self.report_output_path)
        self.document_analysis_path = os.getenv("DOCUMENT_ANALYSIS_PATH", self.document_analysis_path)
        
        # Per-agent iteration controls
        self.planner_max_iterations = (
            int(os.getenv("PLANNER_MAX_ITERATION")) if os.getenv("PLANNER_MAX_ITERATION") else None
        )
        self.information_seeker_max_iterations = (
            int(os.getenv("INFORMATION_SEEKER_MAX_ITERATION")) if os.getenv("INFORMATION_SEEKER_MAX_ITERATION") else None
        )
        self.writer_max_iterations = (
            int(os.getenv("WRITER_MAX_ITERATION")) if os.getenv("WRITER_MAX_ITERATION") else None
        )
        
        # General Settings
        self.debug_mode = os.getenv("DEBUG_MODE", "false").lower() == "true"
        self.max_retries = int(os.getenv("MAX_RETRIES", self.max_retries))
        self.timeout = int(os.getenv("TIMEOUT", self.timeout))

        requested_mode = os.getenv("PDF_PARSE_MODE", "").strip().lower()
        legacy_full = os.getenv("LLAMA_FULL_PDF_ENABLED", "false").lower() == "true"
        legacy_vision = os.getenv("LLAMA_VISION_ENABLED", "false").lower() == "true"
        if requested_mode not in {"local", "llama_full", "hybrid"}:
            requested_mode = "hybrid" if legacy_full and legacy_vision else "llama_full" if legacy_full else "local"
        self.pdf_parse_mode = requested_mode
        self.llama_vision_enabled = os.getenv("LLAMA_VISION_ENABLED", "false").lower() == "true"
        self.llama_cloud_api_key = os.getenv("LLAMA_CLOUD_API_KEY", "")
        legacy_llama_key = os.getenv("OPENROUTER_API_KEY", "")
        if not self.llama_cloud_api_key and legacy_llama_key.startswith("llx-"):
            self.llama_cloud_api_key = legacy_llama_key
        self.llama_parse_tier = os.getenv("LLAMA_PARSE_TIER", self.llama_parse_tier)
        self.llama_parse_endpoint = os.getenv("LLAMA_PARSE_ENDPOINT", self.llama_parse_endpoint).rstrip("/")
        self.llama_parse_poll_interval = float(os.getenv("LLAMA_PARSE_POLL_INTERVAL", self.llama_parse_poll_interval))
        self.llama_vision_max_regions = int(os.getenv("LLAMA_VISION_MAX_REGIONS", self.llama_vision_max_regions))
        self.llama_vision_timeout = int(os.getenv("LLAMA_VISION_TIMEOUT", self.llama_vision_timeout))
        self.llama_vision_max_retries = int(os.getenv("LLAMA_VISION_MAX_RETRIES", self.llama_vision_max_retries))
        self.llama_vision_max_tokens = int(os.getenv("LLAMA_VISION_MAX_TOKENS", self.llama_vision_max_tokens))
        self.llama_vision_min_confidence = float(os.getenv("LLAMA_VISION_MIN_CONFIDENCE", self.llama_vision_min_confidence))
        self.llama_vision_allow_override = os.getenv("LLAMA_VISION_ALLOW_OVERRIDE", "true").lower() == "true"
        self.llama_full_pdf_enabled = os.getenv("LLAMA_FULL_PDF_ENABLED", "false").lower() == "true"
        self.llama_full_pdf_timeout = int(os.getenv("LLAMA_FULL_PDF_TIMEOUT", self.llama_full_pdf_timeout))
        self.llama_full_pdf_max_retries = int(os.getenv("LLAMA_FULL_PDF_MAX_RETRIES", self.llama_full_pdf_max_retries))
        self.llama_full_pdf_use_as_writer_source = os.getenv(
            "LLAMA_FULL_PDF_USE_AS_WRITER_SOURCE", "true"
        ).lower() == "true"
        # The strategy is authoritative; legacy flags remain supported for
        # older .env files but cannot accidentally enable both cloud paths.
        if self.pdf_parse_mode == "local":
            self.llama_vision_enabled = False
            self.llama_full_pdf_enabled = False
        elif self.pdf_parse_mode == "llama_full":
            self.llama_vision_enabled = False
            self.llama_full_pdf_enabled = True
        else:  # hybrid
            self.llama_vision_enabled = True
            self.llama_full_pdf_enabled = True
    
    def get_custom_llm_config(self) -> Dict[str, Any]:
        """Get configuration for custom LLM service"""
        return {
            "url": self.model_request_url,
            "token": self.model_request_token,
            "model": self.model_name,
            "temperature": self.model_temperature,
            "max_tokens": self.model_max_tokens,
            "timeout": self.model_request_timeout,
            "base_url": self.model_request_url  # For backward compatibility with model_config.get('base_url')
        }
    
    def get_available_search_providers(self) -> list:
        """Get list of available search providers based on API keys"""
        providers = []
        if self.search_engine_api_keys:
            providers.append("custom")
        return providers
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert config to dictionary (excluding sensitive data)"""
        config_dict = {}
        for key, value in self.__dict__.items():
            if "api_key" in key.lower() or "password" in key.lower():
                config_dict[key] = "***" if value else None
            else:
                config_dict[key] = value
        return config_dict

# Global configuration instance
config = APIConfig()


_pdf_parse_mode_override: ContextVar[Optional[str]] = ContextVar(
    "pdf_parse_mode_override", default=None
)
_PDF_PARSE_MODES = {"local", "llama_full", "hybrid"}


@contextmanager
def temporary_pdf_parse_mode(mode: Optional[str]) -> Iterator[None]:
    """Apply a PDF parsing strategy only within the current request context."""
    if mode is None:
        yield
        return
    normalized_mode = str(mode).strip().lower()
    if normalized_mode not in _PDF_PARSE_MODES:
        raise ValueError(f"Unsupported PDF parsing mode: {mode}")
    token = _pdf_parse_mode_override.set(normalized_mode)
    try:
        yield
    finally:
        _pdf_parse_mode_override.reset(token)


def get_config() -> APIConfig:
    """Get configuration, applying the request-local PDF strategy when set."""
    mode = _pdf_parse_mode_override.get()
    try:
        from user_credentials import current_capability, provider_value
        cap = current_capability()
    except ModuleNotFoundError as exc:
        # A copied config-only admin utility remains env-only compatible.
        # An account-scoped worker must never fall back if its scope module is missing.
        if exc.name != 'user_credentials' or os.getenv('SCIASSISTANT_PROVIDER_OWNER'):
            raise
        cap = None
    if not mode and cap is None:
        return config
    # ``dataclasses.replace`` invokes APIConfig.__post_init__ and rereads the
    # process environment, so use a shallow copy for a request-local override.
    overridden_config = copy(config)
    if mode:
        overridden_config.pdf_parse_mode = mode
        overridden_config.llama_full_pdf_enabled = mode in {"llama_full", "hybrid"}
        overridden_config.llama_vision_enabled = mode == "hybrid"
    if cap:
        overridden_config.model_request_token = provider_value('MODEL_REQUEST_TOKEN')
        overridden_config.llama_cloud_api_key = provider_value('LLAMA_CLOUD_API_KEY')
    return overridden_config


def reload_config():
    """Reload configuration from environment variables"""
    global config
    config = APIConfig()
    logger.info("Configuration reloaded")


def validate_api_key(api_key: Optional[str], service_name: str) -> bool:
    """Validate that an API key is present and not empty"""
    if not api_key or api_key.strip() == "":
        logger.error(f"Missing or empty API key for {service_name}")
        return False
    return True


def get_url_crawler_config() -> Dict[str, Any]:
    """Get generic URL crawler configuration"""
    api_keys = config.url_crawler_api_keys
    base_url = config.url_crawler_base_url
    
    if not base_url:
        return {}
    
    # Parse comma-separated API keys for rotation (can be empty for free services)
    api_key_list = []
    if api_keys:
        api_key_list = [key.strip() for key in api_keys.split(",")] if isinstance(api_keys, str) else [api_keys]
    
    return {
        "api_keys": api_key_list,
        "base_url": base_url,
        "max_tokens": config.url_crawler_max_tokens,
        "timeout": config.timeout
    }


def get_search_engine_config() -> Dict[str, Any]:
    """Get generic search engine configuration"""
    api_keys = config.search_engine_api_keys
    base_url = config.search_engine_base_url
    
    if not api_keys:
        return {}
    
    # Parse comma-separated API keys for rotation
    api_key_list = [key.strip() for key in api_keys.split(",")] if isinstance(api_keys, str) else [api_keys]
    
    return {
        "api_keys": api_key_list,
        "base_url": base_url,
        "timeout": config.timeout
    }


def get_model_config() -> Dict[str, Any]:
    """Get model interaction configuration for custom LLM service"""
    return config.get_custom_llm_config()


def get_storage_config() -> Dict[str, Any]:
    """Get storage and trajectory configuration"""
    return {
        "trajectory_storage_path": config.trajectory_storage_path,
        "report_output_path": config.report_output_path,
        "document_analysis_path": config.document_analysis_path
    }


def get_mcp_config() -> Dict[str, Any]:
    """Get MCP server specific configuration"""
    return {
        "server_url": config.mcp_server_url,
        "auth_token": config.mcp_auth_token,
        "use_stdio": config.mcp_use_stdio,
        "timeout": config.timeout
    }


# Example usage and testing
if __name__ == "__main__":
    print("=== Multi Agent System Configuration ===")
    print(f"Debug Mode: {config.debug_mode}")
    print(f"Custom LLM Service URL: {config.model_request_url}")
    print(f"Available Search Providers: {config.get_available_search_providers()}")
    print("\nConfiguration Summary:")
    for key, value in config.to_dict().items():
        print(f"  {key}: {value}") 
