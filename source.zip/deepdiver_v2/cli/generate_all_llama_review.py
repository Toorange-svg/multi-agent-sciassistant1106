"""Create an offline dark manual-review package for a whole-PDF LlamaParse run.

The package deliberately separates original PDF pages from LlamaParse text.
It only calls a right-side section a page match when the provider exposed an
explicit page list with exactly the same number of pages as the original PDF.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import html
import json
from pathlib import Path
from typing import Any

import fitz


def _find_full_result(log_path: Path) -> dict[str, Any]:
    for line in log_path.read_text(encoding="utf-8").splitlines():
        try:
            record = json.loads(line)
        except json.JSONDecodeError:
            continue
        if record.get("tool_name") != "arxiv_read_paper":
            continue
        data = record.get("output_result", {}).get("data", {})
        full = data.get("llama_full_pdf") or {}
        if isinstance(full, dict) and full.get("status") == "completed" and full.get("text_path"):
            return data
    raise RuntimeError(f"No completed whole-PDF LlamaParse result found in {log_path}")


def _uri(pix: fitz.Pixmap) -> str:
    return "data:image/png;base64," + base64.b64encode(pix.tobytes("png")).decode("ascii")


def _load_pages(full: dict[str, Any], pdf_pages: int) -> tuple[list[str], bool]:
    pages_path = Path(str(full.get("pages_path") or ""))
    if pages_path.is_file():
        try:
            pages = json.loads(pages_path.read_text(encoding="utf-8"))
            if isinstance(pages, list) and len(pages) == pdf_pages and all(isinstance(item, str) for item in pages):
                return pages, True
        except (OSError, json.JSONDecodeError):
            pass
    markdown = Path(full["text_path"]).read_text(encoding="utf-8", errors="replace")
    return [markdown], False


def _text_signals(markdown: str) -> str:
    signals = []
    if "|" in markdown and "---" in markdown:
        signals.append("可能含 Markdown 表格")
    if "$$" in markdown or "\\[" in markdown or "\\(" in markdown:
        signals.append("可能含公式")
    if "figure" in markdown.lower() or "fig." in markdown.lower() or "图" in markdown:
        signals.append("可能含图形/图注")
    return "；".join(signals) or "未依据规则检测到结构标记"


def _card(index: int, image: str, transcription: str, mapped: bool) -> str:
    mapping = "服务明确按页返回，可与左侧原 PDF 第 %s 页逐项比对。" % index if mapped else (
        "服务没有返回可验证的逐页分段。右侧为整篇转写，不能声称与左侧本页精确对应；"
        "请先使用全文搜索定位内容，再回到原 PDF 核验。"
    )
    section = html.escape(transcription)
    return f'''<article class="card" id="page-{index}" data-page="{index}">
<header><h2>第 {index} 页</h2><span>{"逐页对应可用" if mapped else "逐页对应不可确认"}</span></header>
<div class="grid"><section><img src="{image}" alt="原 PDF 第 {index} 页"><p class="hint">左侧：原 PDF 整页渲染，没有裁剪或模型框选。</p></section>
<section><p class="mapping">{mapping}</p><p class="signals">结构提示：{html.escape(_text_signals(transcription))}</p>
<h3>LlamaParse 返回</h3><pre>{section}</pre>
<label>人工结论 <select data-field="decision"><option>未核验</option><option>通过</option><option>部分通过</option><option>不通过</option></select></label>
<label>核验备注 <textarea data-field="note" placeholder="逐项记录阅读顺序、公式字符、表格单元格、图中数据点、图例或连线等问题。"></textarea></label></section></div></article>'''


def build(project_root: Path, run_workspace: Path, output: Path) -> None:
    log_files = sorted((run_workspace / "tool_call_logs").glob("tool_calls_*.jsonl"))
    if not log_files:
        raise RuntimeError(f"No tool-call log found in {run_workspace}")
    data = _find_full_result(log_files[-1])
    full = data["llama_full_pdf"]
    pdf_path = Path(data["pdf_path"])
    document = fitz.open(pdf_path)
    chunks, page_mapped = _load_pages(full, document.page_count)
    cards = []
    if page_mapped:
        for index in range(1, document.page_count + 1):
            pix = document[index - 1].get_pixmap(matrix=fitz.Matrix(1.15, 1.15), alpha=False)
            cards.append(_card(index, _uri(pix), chunks[index - 1], True))
    else:
        whole = chunks[0]
        for index in range(1, document.page_count + 1):
            pix = document[index - 1].get_pixmap(matrix=fitz.Matrix(1.15, 1.15), alpha=False)
            cards.append(_card(index, _uri(pix), whole if index == 1 else "（整篇转写仅在第 1 项展示，避免重复嵌入大文本。）", False))
    document.close()
    digest = hashlib.sha256(pdf_path.read_bytes()).hexdigest()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>all_Llama - {html.escape(data.get("paper_id", ""))} 人工核验包</title>
<style>:root{{color-scheme:dark}}body{{max-width:1500px;margin:0 auto;padding:28px;font:15px "Segoe UI",Arial,sans-serif;background:#111827;color:#e5e7eb}}h1,h2,h3{{color:#f9fafb}}h1{{margin-bottom:4px}}.meta,.warning{{background:#1f2937;border:1px solid #374151;border-radius:7px;padding:14px;margin:14px 0}}.warning{{border-left:5px solid #fbbf24;color:#fef3c7}}.toolbar{{position:sticky;top:10px;z-index:3;background:#1f2937;border:1px solid #374151;border-radius:7px;padding:10px;display:flex;gap:10px;align-items:center}}button{{background:#1d4ed8;color:#fff;border:1px solid #60a5fa;border-radius:4px;padding:8px 12px;cursor:pointer}}button.secondary{{background:#374151;border-color:#6b7280}}.save{{color:#a7f3d0;font-size:13px}}.card{{background:#1f2937;border:1px solid #374151;border-radius:8px;margin:22px 0}}header{{display:flex;justify-content:space-between;align-items:center;padding:0 18px;border-bottom:1px solid #374151}}header span{{background:#3f3513;color:#fde68a;border-radius:4px;padding:4px 8px;font-size:13px}}.grid{{display:grid;grid-template-columns:minmax(440px,1.15fr) minmax(400px,1fr);gap:18px;padding:18px}}img{{width:100%;height:auto;background:#fff;border:1px solid #64748b}}.hint,.mapping,.signals{{font-size:13px;color:#cbd5e1}}.mapping{{background:#172554;border-left:4px solid #60a5fa;padding:9px}}.signals{{color:#a5b4fc}}pre{{max-height:520px;overflow:auto;white-space:pre-wrap;word-break:break-word;background:#0b1220;border:1px solid #334155;border-radius:5px;padding:12px;font-size:12px;color:#d1d5db}}label{{display:block;margin-top:10px}}textarea,select{{box-sizing:border-box;background:#111827;color:#f3f4f6;border:1px solid #4b5563;border-radius:4px;padding:7px}}textarea{{width:100%;height:78px;margin-top:4px;resize:vertical}}select{{margin-left:8px}}code{{color:#bfdbfe;overflow-wrap:anywhere}}@media(max-width:950px){{body{{padding:14px}}.grid{{grid-template-columns:1fr}}}}</style></head><body>
<h1>all_Llama - arXiv:{html.escape(str(data.get("paper_id", "")))} 整篇 PDF 人工核验包</h1><p>来自一次真实 <code>run_demo</code> 的整篇 LlamaParse 解析。此包是人工审计工具，不表示模型输出已被验证。</p>
<div class="toolbar"><button id="export" type="button">导出填写结果（JSON）</button><button id="clear" class="secondary" type="button">清除本机暂存</button><span id="state" class="save">填写内容会自动暂存在当前浏览器。</span></div>
<div class="warning"><strong>核验原则：</strong>整篇 LlamaParse 转写可辅助定位内容，但不能自动确认公式字符、表格单元格、图表数值、流程图连线或页码。任何错误或不确定项都应在备注中写明。</div>
<div class="meta"><b>原 PDF：</b><code>{html.escape(str(pdf_path))}</code><br><b>SHA-256：</b><code>{digest}</code><br><b>服务：</b>{html.escape(str(full.get("provider", "llamaparse")))} / {html.escape(str(full.get("model", "")))} / tier={html.escape(str(full.get("tier", "")))}<br><b>任务 ID：</b><code>{html.escape(str(full.get("job_id", "")))}</code><br><b>耗时：</b>{html.escape(str(full.get("elapsed_ms", "")))} ms；<b>转写长度：</b>{html.escape(str(full.get("markdown_chars", "")))} 字符；<b>页映射：</b>{"服务明确返回并匹配" if page_mapped else "未能确认，禁止当作精确逐页对应"}</div>
{''.join(cards)}
<script>const key='sciassistant.all_llama.{html.escape(str(data.get("paper_id", "paper")))}';const state=document.querySelector('#state');function all(){{return [...document.querySelectorAll('.card')].map(x=>({{page:Number(x.dataset.page),decision:x.querySelector('[data-field=decision]').value,note:x.querySelector('[data-field=note]').value}}));}}function save(){{localStorage.setItem(key,JSON.stringify({{saved_at:new Date().toISOString(),reviews:all()}}));state.textContent='已自动暂存：'+new Date().toLocaleTimeString();}}function restore(){{try{{const d=JSON.parse(localStorage.getItem(key)||'null');if(!d?.reviews)return;for(const r of d.reviews){{const c=document.querySelector('#page-'+r.page);if(c){{c.querySelector('[data-field=decision]').value=r.decision||'未核验';c.querySelector('[data-field=note]').value=r.note||'';}}}}state.textContent='已恢复本机暂存：'+new Date(d.saved_at).toLocaleString();}}catch{{state.textContent='本机暂存读取失败，不影响导出。';}}}}document.querySelectorAll('[data-field]').forEach(x=>x.addEventListener('input',save));document.querySelector('#export').onclick=()=>{{const payload={{format:'sciassistant_all_llama_manual_review/v1',exported_at:new Date().toISOString(),paper_id:{json.dumps(data.get("paper_id", ""), ensure_ascii=False)},pdf_sha256:{json.dumps(digest)},llamaparse:{{job_id:{json.dumps(full.get("job_id", ""))},tier:{json.dumps(full.get("tier", ""))},page_mapping_verified:{str(page_mapped).lower()}}},reviews:all()}};const b=new Blob([JSON.stringify(payload,null,2)],{{type:'application/json;charset=utf-8'}});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='all_Llama_{html.escape(str(data.get("paper_id", "paper")))}_manual_review.json';a.click();URL.revokeObjectURL(a.href);}};document.querySelector('#clear').onclick=()=>{{if(confirm('仅清除当前浏览器自动暂存，不会删除已导出的 JSON。是否继续？')){{localStorage.removeItem(key);document.querySelectorAll('[data-field=decision]').forEach(x=>x.value='未核验');document.querySelectorAll('[data-field=note]').forEach(x=>x.value='');state.textContent='本机暂存已清除。';}}}};restore();</script></body></html>''', encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", required=True, help="run_demo workspace containing tool_call_logs")
    parser.add_argument("--output", default="docs/all_Llama_2409.12421v1_20260815.html")
    args = parser.parse_args()
    project_root = Path(__file__).resolve().parents[2]
    build(project_root, Path(args.workspace).resolve(), project_root / args.output)


if __name__ == "__main__":
    main()
