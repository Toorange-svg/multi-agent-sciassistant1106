"""Generate a text-only acceptance package for intent and answer quality."""

from __future__ import annotations

import argparse
import html
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from deepdiver_v2.src.answer_contract import build_answer_contract, validate_answer_structure  # noqa: E402
from deepdiver_v2.src.query_intent import analyze_query_intent  # noqa: E402


CASES = [
    ("章节总结", "上传的 PDF 中 Creating a Sufficiently Large Dataset 主要讲了什么？", "section_summary"),
    ("章节总结", "这一节主要讨论了数据集如何构建？", "section_summary"),
    ("章节总结", "论文中的 Data Engine 部分介绍了什么？", "section_summary"),
    ("章节总结", "请概括方法章节的核心内容。", "section_summary"),
    ("概念解释", "解释一下论文中的 promptable segmentation 是什么。", "concept_explanation"),
    ("概念解释", "什么是 zero-shot transfer？", "concept_explanation"),
    ("概念解释", "请讲解这篇论文提出的方法原理。", "concept_explanation"),
    ("实验证据", "论文在 COCO 上的实验结果和指标是多少？", "experimental_evidence"),
    ("实验证据", "实验结果表明模型性能如何？", "experimental_evidence"),
    ("实验证据", "请找出论文报告的 benchmark 数值。", "experimental_evidence"),
    ("公式解释", "论文中的核心公式是什么意思？", "formula_explanation"),
    ("公式解释", "请解释 equation (1) 中各符号。", "formula_explanation"),
    ("公式解释", "这个损失函数如何推导？", "formula_explanation"),
    ("方法比较", "比较 Transformer 和 RNN 的主要差异。", "comparison"),
    ("方法比较", "这篇方法与基线方法有什么区别？", "comparison"),
    ("方法比较", "对比两种模型的优缺点和适用场景。", "comparison"),
    ("批判分析", "论文有哪些局限和潜在问题？", "critical_analysis"),
    ("批判分析", "批判性分析作者方法的不足。", "critical_analysis"),
    ("聚焦回答", "作者为什么要采用这个训练策略？", "focused_answer"),
    ("整体总结", "请对上传的论文做一个整体总结。", "general_summary"),
]


def run_rounds() -> list[dict]:
    rounds = []
    for round_no in range(1, 21):
        checks = []
        for label, query, expected_type in CASES:
            actual = analyze_query_intent(query, has_upload=True)
            checks.append({
                "query": query,
                "expected_task_type": expected_type,
                "actual_task_type": actual.get("task_type"),
                "label": label,
                "passed": actual.get("task_type") == expected_type and actual.get("scope") == "uploaded_pdf",
                "actual": actual,
            })
        rounds.append({"round": round_no, "passed": all(x["passed"] for x in checks), "case_count": len(checks), "checks": checks})
    return rounds


def run_answer_rounds() -> list[dict]:
    """Exercise the third-layer guard with good, short, and scope-drift answers."""
    fixtures = [
        ({"task_type": "section_summary"}, "直接回答：本节介绍数据集构建及其动机。依据见第 3 页；限制是只覆盖本节，具体数字需回查原文。", True),
        ({"task_type": "section_summary"}, "论文概览：本文主要提出一个模型。依据见第 1 页。", False),
        ({"task_type": "concept_explanation"}, "直接回答：该概念表示一种训练方法及其使用方式。原文依据见第 2 页；限制是上下文可能不完整。", True),
        ({"task_type": "experimental_evidence"}, "直接回答：实验在 COCO 上比较模型性能和泛化表现。证据见第 8 页，具体数字需回查原文表格；限制是当前摘要没有完整实验上下文。", True),
        ({"task_type": "comparison"}, "直接结论：A 更适合场景一，B 在另一类条件下更有优势。依据见第 4 页；限制是未覆盖所有数据集，结论不能外推到其他任务。", True),
    ]
    return [{"round": n, "passed": all(bool(validate_answer_structure(answer, build_answer_contract(intent))["status"] == ("passed" if expected else "needs_review")) for intent, answer, expected in fixtures), "fixture_count": len(fixtures)} for n in range(1, 21)]


def render(payload: dict) -> str:
    rows = []
    for item in payload["cases"]:
        actual = item["actual"]
        intent_status = "通过" if item["passed"] else "需修复"
        contract = item["contract"]
        check = item["answer_structure_check"]
        rows.append(f"""
        <article class=\"case\"><h2>{html.escape(item['label'])}</h2><p class=\"query\">{html.escape(item['query'])}</p>
        <div class=\"columns\"><section><h3>第一层：问题意图</h3><p>预期：<b>{html.escape(item['expected_task_type'])}</b></p><p>实际：<b>{html.escape(str(actual.get('task_type')))}</b>；范围：<b>{html.escape(str(actual.get('scope')))}</b></p><p class=\"{('ok' if item['passed'] else 'bad')}\">自动判定：{intent_status}</p><details><summary>查看完整识别 JSON</summary><pre>{html.escape(json.dumps(actual, ensure_ascii=False, indent=2))}</pre></details><label>人工判定 <select data-field=\"intent\"><option>待核验</option><option>通过</option><option>部分通过</option><option>不通过</option></select></label></section>
        <section><h3>第三层：回答质量</h3><p>回答输入：{('已提供' if item['answer'] else '未提供，需粘贴网页实际回答')}</p><p>自动检查：<b>{html.escape(str(check.get('status')))}</b>；缺少：{html.escape(', '.join(check.get('missing') or []) or '无')}</p><p>要求结构：{html.escape('、'.join(contract.get('sections') or []))}</p><div class=\"checklist\"><label><input type=\"checkbox\"> 首段直接回答问题</label><label><input type=\"checkbox\"> 没有用整篇概览替代局部问题</label><label><input type=\"checkbox\"> 关键结论没有超出问题范围</label><label><input type=\"checkbox\"> 证据/限制说明与回答匹配</label></div><label>人工判定 <select data-field=\"answer\"><option>待核验</option><option>通过</option><option>部分通过</option><option>不通过</option></select></label></section></div><label>备注<textarea data-field=\"notes\" placeholder=\"只记录意图错误、遗漏、跑题、无依据推断等文本问题\"></textarea></label></article>""")
    rounds = payload["intent_rounds"]
    passed_rounds = sum(1 for x in rounds if x["passed"])
    answer_passed = sum(1 for x in payload["answer_rounds"] if x["passed"])
    return f"""<!doctype html><html lang=\"zh-CN\"><meta charset=\"utf-8\"><title>文本质量验收</title><style>body{{margin:0;background:#0f172a;color:#e5e7eb;font:14px system-ui}}main{{max-width:1250px;margin:auto;padding:24px}}article{{background:#1e293b;border:1px solid #475569;border-radius:8px;padding:18px;margin:16px 0}}.columns{{display:grid;grid-template-columns:1fr 1fr;gap:16px}}section{{background:#0f172a;padding:14px;border-radius:6px}}.query{{font-size:18px;color:#93c5fd}}pre{{white-space:pre-wrap;max-height:240px;overflow:auto;color:#c4b5fd}}label{{display:block;margin:10px 0}}select,textarea{{display:block;background:#111827;color:#e5e7eb;border:1px solid #64748b;padding:7px;width:100%;box-sizing:border-box}}textarea{{min-height:65px}}.ok{{color:#86efac}}.bad{{color:#fca5a5}}.checklist label{{margin:7px 0}}button{{background:#2563eb;color:white;border:0;padding:9px 14px;border-radius:5px;margin-right:8px}}.deferred{{background:#422006;border:1px solid #f59e0b;padding:12px;border-radius:6px}}@media(max-width:800px){{.columns{{grid-template-columns:1fr}}}}</style><main><h1>文本回答质量人工验收</h1><p>本包只验收第一层“问题意图”和第三层“回答质量”。图片、表格、公式、图注和版面定位不计入本轮结论，已延期。</p><p>自动回归：20 轮 × {len(CASES)} 个问题；通过轮次：{passed_rounds}/20。</p><div class=\"deferred\"><b>延期提醒：</b>后续仍需单独处理图片/图表/公式信息的视觉核验，本包不对这些内容作通过判断。</div><button id=\"export\">导出人工核验 JSON</button><button id=\"clear\">清空本地记录</button><h2>逐题核验</h2>{''.join(rows)}</main><script>const key='sciassistant-text-quality-acceptance';const els=[...document.querySelectorAll('[data-field],input[type=checkbox]')];function save(){{const d={{}};els.forEach((e,i)=>d[i]=e.type==='checkbox'?e.checked:e.value);localStorage.setItem(key,JSON.stringify(d));return d}}function load(){{const d=JSON.parse(localStorage.getItem(key)||'{{}}');els.forEach((e,i)=>{{if(d[i]!==undefined){{if(e.type==='checkbox')e.checked=d[i];else e.value=d[i]}}}})}}els.forEach(e=>e.addEventListener(e.type==='checkbox'?'change':'input',save));document.getElementById('export').onclick=()=>{{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify({{source:'text-only',reviews:save()}},null,2)],{{type:'application/json'}}));a.download='text_quality_reviews.json';a.click()}};document.getElementById('clear').onclick=()=>{{localStorage.removeItem(key);location.reload()}};load();</script></html>"""


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT / "docs" / "text_quality_acceptance_20260826")
    parser.add_argument("--answers", type=Path)
    args = parser.parse_args()
    answers = {}
    if args.answers:
        data = json.loads(args.answers.read_text(encoding="utf-8"))
        answers = {str(x.get("query")): str(x.get("answer") or "") for x in data} if isinstance(data, list) else {str(k): str(v) for k, v in data.items()}
    cases = []
    for label, query, expected in CASES:
        intent = analyze_query_intent(query, has_upload=True)
        contract = build_answer_contract(intent)
        answer = answers.get(query, "")
        cases.append({"label": label, "query": query, "expected_task_type": expected, "actual": intent, "passed": intent.get("task_type") == expected and intent.get("scope") == "uploaded_pdf", "contract": contract, "answer": answer, "answer_structure_check": validate_answer_structure(answer, contract) if answer else {"status": "not_run", "missing": ["answer_input"]}})
    payload = {"generated_at": datetime.now(timezone.utc).isoformat(), "scope": "text_only", "deferred": ["image", "table", "formula", "figure_caption", "bbox_visual_review"], "intent_rounds": run_rounds(), "answer_rounds": run_answer_rounds(), "rounds": run_rounds(), "cases": cases}
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "acceptance.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    (args.output / "index.html").write_text(render(payload), encoding="utf-8")
    print(f"generated={args.output / 'index.html'} intent_rounds=20 answer_rounds=20 cases={len(cases)} intent_passed={sum(1 for x in payload['intent_rounds'] if x['passed'])} answer_passed={sum(1 for x in payload['answer_rounds'] if x['passed'])}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
