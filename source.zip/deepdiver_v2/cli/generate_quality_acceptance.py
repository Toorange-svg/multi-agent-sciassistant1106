"""Generate a human-review package for intent, PDF evidence, and answer quality.

This is deliberately offline: it never calls a model and never uploads the PDF.
Use the web task output as the answer input, then review the generated checklist.
"""

from __future__ import annotations

import argparse
import html
import json
import sys
import re
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from pdf_pipeline import parse_pdf  # noqa: E402
from deepdiver_v2.src.answer_contract import build_answer_contract, validate_answer_structure  # noqa: E402
from deepdiver_v2.src.evidence_blocks import build_evidence_blocks, select_evidence_blocks  # noqa: E402
from deepdiver_v2.src.query_intent import analyze_query_intent  # noqa: E402


def _render_review_pages(pdf_path: Path, payload: dict, output: Path) -> None:
    """Render only pages containing visual/risk evidence and draw bbox overlays."""
    try:
        import fitz
    except ImportError:
        return
    by_page: dict[int, list[list[float]]] = {}
    for case in payload["cases"]:
        for item in case.get("visual_evidence", []):
            page = item.get("page")
            bbox = item.get("bbox")
            if isinstance(page, int) and isinstance(bbox, list) and len(bbox) == 4:
                by_page.setdefault(page, []).append(bbox)
    if not by_page:
        return
    render_dir = output / "review_pages"
    render_dir.mkdir(parents=True, exist_ok=True)
    document = fitz.open(pdf_path)
    for page_number, boxes in by_page.items():
        if not 1 <= page_number <= len(document):
            continue
        page = document.load_page(page_number - 1)
        pix = page.get_pixmap(matrix=fitz.Matrix(1.25, 1.25), alpha=False)
        image = fitz.Pixmap(pix, 0) if pix.alpha else pix
        shape = page.new_shape()
        for box in boxes:
            shape.draw_rect(fitz.Rect(*box))
        shape.finish(color=(1, 0.2, 0.1), width=2)
        shape.commit()
        page.get_pixmap(matrix=fitz.Matrix(1.25, 1.25), alpha=False).save(str(render_dir / f"page-{page_number}.png"))
    payload["review_pages"] = sorted(by_page)


DEFAULT_CASES = [
    "这篇论文的摘要主要讲了什么？",
    "论文中 Creating a Sufficiently Large Dataset 主要讲了什么？",
    "论文的实验结果和关键指标是什么？",
    "论文中的核心公式和符号分别表示什么？",
    "这篇论文与相关方法相比有什么主要差异？",
]


def _load_answers(path: Path | None) -> dict[str, str]:
    if not path:
        return {}
    data = json.loads(path.read_text(encoding="utf-8"))
    return {str(item.get("query")): str(item.get("answer") or "") for item in data} if isinstance(data, list) else {str(k): str(v) for k, v in data.items()}


def _case_payload(query: str, blocks: list[dict], answers: dict[str, str]) -> dict:
    intent = analyze_query_intent(query, has_upload=True)
    selected = select_evidence_blocks(blocks, query, limit=8)
    contract = build_answer_contract(intent)
    answer = answers.get(query, "")
    visual = [item for item in selected if item.get("visual_review_required")]
    if not visual:
        visual = [item for item in blocks if item.get("visual_review_required")][:3]
    return {
        "query": query,
        "intent": intent,
        "contract": contract,
        "answer_structure_check": validate_answer_structure(answer, contract) if answer else {"status": "not_run", "missing": ["answer_input"]},
        "evidence": selected,
        "visual_evidence": visual,
        "review": {"intent": "", "evidence": "", "answer": "", "notes": ""},
    }


def _evidence_rows(items: list[dict]) -> str:
    rows = []
    for item in items:
        rows.append(
            "<tr><td><code>{id}</code></td><td>{page}</td><td><code>{bbox}</code></td>"
            "<td>{kind}</td><td>{risk}</td><td>{text}</td><td>{visual}</td><td><select data-review-field=\"evidence\">"
            "<option value=\"\">待核验</option><option>通过</option><option>部分通过</option><option>不通过</option></select></td></tr>".format(
                id=html.escape(str(item.get("evidence_id"))), page=html.escape(str(item.get("page"))),
                bbox=html.escape(str(item.get("bbox"))), kind=html.escape(str(item.get("block_type"))),
                risk=html.escape(", ".join(item.get("risk_flags") or []) or "无"),
                text=html.escape(str(item.get("text") or "")),
                visual="需要看原页图" if item.get("visual_review_required") else "正文抽查",
            )
        )
    return "".join(rows)


def render(payload: dict, pdf_path: Path) -> str:
    generated = datetime.now(timezone.utc).isoformat()
    cases = []
    for index, case in enumerate(payload["cases"], 1):
        intent = case["intent"]
        check = case["answer_structure_check"]
        cases.append(f"""
        <article class=\"case\" data-case=\"{index}\">
          <h2>验收项 {index}</h2><p class=\"query\">{html.escape(case['query'])}</p>
          <div class=\"grid\"><section><h3>问题意图层</h3><pre>{html.escape(json.dumps(intent, ensure_ascii=False, indent=2))}</pre>
          <label>人工判定 <select data-review-field=\"intent\"><option value=\"\">待核验</option><option>通过</option><option>部分通过</option><option>不通过</option></select></label></section>
          <section><h3>回答结构层</h3><p>自动检查：<b>{html.escape(check.get('status', 'not_run'))}</b></p><p>缺少项：{html.escape(', '.join(check.get('missing') or []) or '无')}</p>
          <label>人工判定 <select data-review-field=\"answer\"><option value=\"\">待核验</option><option>通过</option><option>部分通过</option><option>不通过</option></select></label></section></div>
          <h3>候选证据块（请回看原 PDF）</h3><p>看到“需要看原页图”时，必须检查图片、表格、公式或图注；“正文抽查”只需确认页码、框和文字连续性。</p><table><thead><tr><th>ID</th><th>页</th><th>BBox</th><th>类型</th><th>风险</th><th>文本</th><th>检查方式</th><th>核验</th></tr></thead><tbody>{_evidence_rows(case['evidence'])}</tbody></table>
          <label>备注<textarea data-review-field=\"notes\" placeholder=\"记录原 PDF 对照结果、跑题、数字/公式风险等\"></textarea></label>
        </article>""")
    page_images = ''.join(f'<figure><figcaption>原 PDF 第 {p} 页（红框=需人工核对的图片/表格/公式/风险区）</figcaption><img src="review_pages/page-{p}.png" loading="lazy"></figure>' for p in payload.get("review_pages", []))
    return f"""<!doctype html><html lang=\"zh-CN\"><meta charset=\"utf-8\"><title>回答质量三层验收</title>
    <style>body{{background:#111827;color:#e5e7eb;font:14px system-ui;margin:0}}main{{max-width:1400px;margin:auto;padding:24px}}.case{{border:1px solid #374151;background:#1f2937;padding:18px;margin:18px 0;border-radius:8px}}.grid{{display:grid;grid-template-columns:1fr 1fr;gap:16px}}section{{background:#111827;padding:12px}}pre{{white-space:pre-wrap;max-height:260px;overflow:auto;color:#c4b5fd}}table{{width:100%;border-collapse:collapse;font-size:12px}}th,td{{border:1px solid #4b5563;padding:6px;vertical-align:top}}td:nth-child(6){{min-width:360px}}select,textarea{{background:#111827;color:#e5e7eb;border:1px solid #6b7280;padding:6px}}textarea{{width:100%;min-height:70px;box-sizing:border-box}}.query{{font-size:18px;color:#93c5fd}}button{{background:#2563eb;color:#fff;border:0;padding:8px 14px;border-radius:5px;margin-right:8px}}figure{{display:inline-block;background:#030712;padding:10px;margin:8px;vertical-align:top;max-width:46%}}figure img{{max-width:100%;height:auto}}figcaption{{color:#fca5a5;margin-bottom:8px}}</style>
    <main><h1>回答质量三层人工验收</h1><p>PDF：<code>{html.escape(str(pdf_path))}</code><br>生成时间：{generated}</p><p>验收顺序：①先看问题意图；②再核对证据页码/bbox；③最后检查回答结构。标红的原页图只针对图片、表格、公式、图注和解析风险区，避免人工逐页翻查。</p><button id=\"save\">导出核验 JSON</button><button id=\"clear\">清空本地记录</button><h2>需人工看原页图的区域</h2>{page_images}<h2>逐题验收</h2>{''.join(cases)}</main>
    <script>const key='sciassistant-quality-acceptance';function fields(){{return [...document.querySelectorAll('[data-review-field]')]}}function load(){{const d=JSON.parse(localStorage.getItem(key)||'{{}}');fields().forEach((e,i)=>{{if(d[i]!=null)e.value=d[i]}})}}function save(){{const d={{}};fields().forEach((e,i)=>d[i]=e.value);localStorage.setItem(key,JSON.stringify(d));return d}}fields().forEach(e=>e.addEventListener('change',save));document.querySelectorAll('textarea').forEach(e=>e.addEventListener('input',save));document.getElementById('save').onclick=()=>{{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify({{source:{json.dumps(str(pdf_path))},reviews:save()}},null,2)],{{type:'application/json'}}));a.download='quality_acceptance_reviews.json';a.click()}};document.getElementById('clear').onclick=()=>{{localStorage.removeItem(key);location.reload()}};load();</script></html>"""


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pdf", type=Path)
    parser.add_argument("--output", type=Path, default=ROOT / "docs" / "quality_acceptance")
    parser.add_argument("--query", action="append", dest="queries")
    parser.add_argument("--answers", type=Path, help="JSON object/list containing query -> answer")
    args = parser.parse_args()
    parsed = parse_pdf(args.pdf, enable_ocr=True)
    if not parsed.get("success"):
        raise SystemExit(f"PDF 解析失败：{parsed.get('error')}")
    blocks = build_evidence_blocks(parsed)
    queries = args.queries or DEFAULT_CASES
    payload = {"source_pdf": str(args.pdf.resolve()), "page_count": parsed.get("page_count"), "block_count": len(blocks), "cases": [_case_payload(q, blocks, _load_answers(args.answers)) for q in queries]}
    args.output.mkdir(parents=True, exist_ok=True)
    _render_review_pages(args.pdf, payload, args.output)
    (args.output / "acceptance.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    (args.output / "index.html").write_text(render(payload, args.pdf.resolve()), encoding="utf-8")
    print(f"已生成：{args.output / 'index.html'}")
    print(f"页数：{payload['page_count']}；证据块：{payload['block_count']}；验收项：{len(queries)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
