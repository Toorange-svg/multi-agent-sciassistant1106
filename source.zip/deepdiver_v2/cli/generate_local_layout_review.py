"""Create an offline visual audit package for local PDF reading order."""
from __future__ import annotations

import argparse
import base64
import hashlib
import html
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import fitz

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from pdf_pipeline import build_parse_metadata, parse_pdf  # noqa: E402
from pdf_chunker import build_document_chunks  # noqa: E402


TYPE_CLASS = {
    "formula": "formula",
    "table": "table",
    "figure_caption": "figure",
    "text": "text",
}

REGION_CLASS = {
    "left_column": "left",
    "right_column": "right",
    "full_width": "full",
    "visual_object": "visual",
    "unresolved_visual": "unresolved",
}


def _data_uri(pixmap: fitz.Pixmap) -> str:
    encoded = base64.b64encode(pixmap.tobytes("png")).decode("ascii")
    return "data:image/png;base64," + encoded


def _number(value: Any, fallback: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return fallback


def _page_risk(page: dict[str, Any], chunk_page: dict[str, Any] | None = None) -> bool:
    chunk_page = chunk_page or {}
    return (
        chunk_page.get("layout", page.get("layout")) in {"two_column", "layout_uncertain"}
        or chunk_page.get("parser_layout") != chunk_page.get("layout")
        or _number(page.get("reading_order_confidence"), 1.0) < 0.75
        or bool((page.get("visuals") or {}).get("figure_structure_risk"))
    )


def _serialize_block(block: dict[str, Any], index: int) -> dict[str, Any]:
    bbox = block.get("bbox") or [0, 0, 0, 0]
    return {
        "id": f"b{index}",
        "source_block_id": str(block.get("block_id") or f"b{index}"),
        "sequence": index,
        "page": int(block.get("page") or 0),
        "type": str(block.get("type") or "text"),
        "column": str(block.get("column") or "unknown"),
        "bbox": [round(_number(value), 2) for value in bbox[:4]],
        "confidence": round(_number(block.get("confidence"), 0.0), 2),
        "text": str(block.get("text") or ""),
    }


def build_review_data(pdf_path: Path, parsed: dict[str, Any]) -> dict[str, Any]:
    metadata = build_parse_metadata(parsed, preview_chars=300)
    raw_blocks = parsed.get("layout_blocks") or []
    blocks = [_serialize_block(block, index) for index, block in enumerate(raw_blocks, 1)]
    by_page: dict[int, list[dict[str, Any]]] = defaultdict(list)
    for block in blocks:
        by_page[block["page"]].append(block)
    pages = metadata.get("pages") or []
    quality = parsed.get("parse_quality") or {}
    chunks = build_document_chunks(str(pdf_path), parsed)
    regions_by_page = {int(item["page"]): item["regions"] for item in chunks["pages"]}
    return {
        "paper_id": pdf_path.stem,
        "pdf_path": str(pdf_path.resolve()),
        "pdf_sha256": hashlib.sha256(pdf_path.read_bytes()).hexdigest(),
        "parser": parsed.get("parser"),
        "success": bool(parsed.get("success")),
        "page_count": int(parsed.get("page_count") or 0),
        "overall_confidence": quality.get("overall_confidence"),
        "failure_modes": quality.get("failure_modes") or [],
        "block_type_counts": dict(sorted(Counter(item["type"] for item in blocks).items())),
        "pages": pages,
        "blocks_by_page": dict(by_page),
        "chunks": chunks,
        "regions_by_page": regions_by_page,
    }


def _region_overlay_html(regions: list[dict[str, Any]], width: float, height: float) -> str:
    overlays = []
    for region in regions:
        x0, y0, x1, y1 = region["bbox"]
        left = max(0.0, min(100.0, x0 / width * 100))
        top = max(0.0, min(100.0, y0 / height * 100))
        box_width = max(0.3, min(100.0 - left, (x1 - x0) / width * 100))
        box_height = max(0.3, min(100.0 - top, (y1 - y0) / height * 100))
        kind = REGION_CLASS.get(region["kind"], "unresolved")
        overlays.append(
            f'<button class="region-overlay {kind}" data-target="{region["region_id"]}" '
            f'style="left:{left:.4f}%;top:{top:.4f}%;width:{box_width:.4f}%;height:{box_height:.4f}%" '
            f'title="区域 #{region["order"]} {html.escape(region["kind"])}">R{region["order"]}</button>'
        )
    return "".join(overlays)


def _region_html(region: dict[str, Any], blocks_by_id: dict[str, dict[str, Any]]) -> str:
    bbox = ", ".join(str(value) for value in region["bbox"])
    children = [blocks_by_id[item] for item in region.get("child_block_ids") or [] if item in blocks_by_id]
    preview = " ".join(item["text"].replace("\n", " ") for item in children)[:320] or "（纯图形或无可提取文字）"
    child_details = "".join(
        f'<details class="child-block"><summary>子块 {index}：{html.escape(item["type"])}；{html.escape(item["column"])}；置信度 {item["confidence"]}</summary>'
        f'<code>bbox=[{", ".join(str(value) for value in item["bbox"])}]</code><pre>{html.escape(item["text"] or "（无可提取文本）")}</pre></details>'
        for index, item in enumerate(sorted(children, key=lambda item: item["sequence"]), 1)
    ) or '<p class="no-children">此区域没有可提取文字子块，仅含原生图形或图片。</p>'
    status = "完整候选" if region.get("complete") else "未完整候选，不可作为完整图表证据"
    return f'''<details class="region {REGION_CLASS.get(region['kind'], 'unresolved')}" id="{region['region_id']}" data-id="{region['region_id']}">
<summary><b>R{region['order']}</b><span>{html.escape(region['kind'])}</span><span>{status}</span><span>完整性 {float(region.get('completeness', 0)):.2f}</span><em>{html.escape(preview)}</em></summary>
<div class="region-body"><code>bbox=[{bbox}]</code><p>生成依据：{html.escape(str(region.get('reason') or 'unknown'))}</p><details class="children"><summary>查看此区域的子块（{len(children)}）</summary>{child_details}</details></div></details>'''


def _page_card(
    page: dict[str, Any], chunk_page: dict[str, Any] | None, image: str,
    blocks: list[dict[str, Any]], regions: list[dict[str, Any]],
) -> str:
    number = int(page.get("page") or 0)
    width = _number(page.get("width"), 612.0)
    height = _number(page.get("height"), 792.0)
    chunk_page = chunk_page or {}
    parser_layout = str(chunk_page.get("parser_layout") or page.get("layout") or "unknown")
    layout = str(chunk_page.get("layout") or parser_layout)
    confidence = _number(page.get("reading_order_confidence"), 0.0)
    visuals = page.get("visuals") or {}
    risk = _page_risk(page, chunk_page)
    open_attr = " open" if risk else ""
    signals = []
    if visuals.get("figure_structure_risk"):
        signals.append("含图形结构风险")
    if any(item["type"] == "table" for item in blocks):
        signals.append("含表格候选")
    if any(item["type"] == "formula" for item in blocks):
        signals.append("含公式候选")
    signal_text = "；".join(signals) or "无额外结构候选"
    blocks_by_id = {key: item for item in blocks for key in (item["id"], item["source_block_id"])}
    region_summary = ", ".join(f"R{item['order']}:{item['kind']}" for item in regions) or "无"
    return f'''<details class="page-card{' risk' if risk else ''}" id="page-{number}" data-page="{number}"{open_attr}>
<summary><b>第 {number} 页</b><span>有效布局={html.escape(layout)}</span><span>原解析标签={html.escape(parser_layout)}</span><span>原解析顺序置信度={confidence:.2f}</span><span>{html.escape(signal_text)}</span><span>区域={len(regions)}；块={len(blocks)}</span></summary>
<div class="page-grid"><section><div class="page-visual"><img src="{image}" alt="原 PDF 第 {number} 页">{_region_overlay_html(regions, width, height)}</div><p class="hint">页面仅显示 R 区域框；R1、R2、R3 即右侧唯一的阅读顺序。点击区域框可定位右侧区域。</p></section>
<section><p class="sequence">本页唯一阅读顺序：<code>{html.escape(region_summary)}</code></p><p class="hint">区域排序只由本地几何和栏位决定，不经过 Llama 或 Writer。子块只用于查看该区域的原始文字，不参与第二套排序。</p><div class="regions">{''.join(_region_html(item, blocks_by_id) for item in regions)}</div>
<label>人工结论 <select class="page-review-decision" data-field="decision"><option>未核验</option><option>版式正确</option><option>左右栏串读</option><option>单双栏误判</option><option>全宽块位置错误</option><option>无法判断</option></select></label>
<label>核验备注 <textarea class="page-review-note" data-field="note" placeholder="记录错误块编号、实际顺序、漏框/错框、图表/公式/表格的影响。"></textarea></label></section></div></details>'''


def build_html(
    pdf_path: Path,
    parsed: dict[str, Any],
    output: Path,
    review_key_suffix: str = "",
) -> dict[str, Any]:
    report = build_review_data(pdf_path, parsed)
    document = fitz.open(pdf_path)
    cards = []
    pages_by_number = {int(page.get("page") or 0): page for page in report["pages"]}
    chunk_pages_by_number = {int(page.get("page") or 0): page for page in report["chunks"]["pages"]}
    for number in range(1, document.page_count + 1):
        page = pages_by_number.get(number, {"page": number, "width": document[number - 1].rect.width, "height": document[number - 1].rect.height})
        pix = document[number - 1].get_pixmap(matrix=fitz.Matrix(1.05, 1.05), alpha=False)
        cards.append(_page_card(
            page, chunk_pages_by_number.get(number), _data_uri(pix),
            report["blocks_by_page"].get(number, []), report["regions_by_page"].get(number, []),
        ))
    document.close()
    risk_pages = [
        int(page.get("page") or 0)
        for page in report["pages"]
        if _page_risk(page, chunk_pages_by_number.get(int(page.get("page") or 0)))
    ]
    layouts = Counter(str(page.get("layout") or "unknown") for page in report["chunks"]["pages"])
    parser_layouts = Counter(str(page.get("parser_layout") or "unknown") for page in report["chunks"]["pages"])
    regions = report["chunks"]["regions"]
    region_counts = Counter(str(item["kind"]) for item in regions)
    incomplete_visuals = sum(1 for item in regions if item["kind"] == "unresolved_visual" or not item.get("complete"))
    output.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(report, ensure_ascii=False)
    output.write_text(f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>本地双栏核验 - {html.escape(report['paper_id'])}</title>
<style>:root{{color-scheme:dark}}body{{max-width:1580px;margin:0 auto;padding:24px;background:#10151f;color:#e5e7eb;font:15px "Segoe UI",Arial,sans-serif}}h1,h2{{color:#f8fafc}}.meta,.warning,.toolbar{{background:#182230;border:1px solid #334155;border-radius:7px;padding:14px;margin:14px 0}}.warning{{border-left:5px solid #f59e0b;color:#fde68a}}.toolbar{{position:sticky;top:8px;z-index:20;display:flex;gap:10px;align-items:center;flex-wrap:wrap}}button{{background:#1d4ed8;color:#fff;border:1px solid #60a5fa;border-radius:4px;padding:8px 12px;cursor:pointer}}button.secondary{{background:#334155;border-color:#64748b}}.save{{color:#a7f3d0;font-size:13px}}.page-card{{background:#182230;border:1px solid #334155;border-radius:8px;margin:18px 0}}.page-card.risk{{border-left:5px solid #f59e0b}}.page-card>summary{{padding:14px;cursor:pointer;display:flex;gap:12px;flex-wrap:wrap;align-items:center}}summary span{{font-size:13px;color:#bfdbfe}}.page-grid{{display:grid;grid-template-columns:minmax(460px,1.12fr) minmax(430px,1fr);gap:18px;padding:0 16px 16px}}.page-visual{{position:relative;line-height:0;background:#fff}}.page-visual img{{display:block;width:100%;height:auto}}.region-overlay{{position:absolute;line-height:1;min-width:21px;min-height:21px;border:3px solid #a78bfa;background:rgba(139,92,246,.07);color:#4c1d95;padding:0;font-size:10px;font-weight:700;overflow:hidden}}.region-overlay.left{{border-color:#2563eb}}.region-overlay.right{{border-color:#16a34a}}.region-overlay.full{{border-color:#f97316}}.region-overlay.visual{{border-color:#db2777}}.region-overlay.unresolved{{border-color:#dc2626;border-style:dashed}}.region-overlay.active,.region.active{{outline:3px solid #f8fafc;z-index:6}}.hint,.sequence{{font-size:13px;color:#cbd5e1;line-height:1.5}}.sequence{{background:#0f172a;border-left:4px solid #60a5fa;padding:9px}}.regions{{max-height:760px;overflow:auto;border:1px solid #334155;background:#0b1220}}.region{{border-bottom:1px solid #263447;padding:8px}}.region summary{{cursor:pointer;display:flex;gap:7px;align-items:baseline}}.region summary span{{background:#334155;border-radius:3px;padding:2px 5px;font-size:12px}}.region summary em{{font-style:normal;color:#cbd5e1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}}.region.left{{border-left:4px solid #2563eb}}.region.right{{border-left:4px solid #16a34a}}.region.full{{border-left:4px solid #f97316}}.region.visual{{border-left:4px solid #db2777}}.region.unresolved{{border-left:4px dashed #dc2626}}.children,.child-block{{margin-top:8px;padding:7px;border:1px solid #334155;background:#111827}}.child-block summary{{cursor:pointer;color:#bfdbfe}}.child-block pre{{white-space:pre-wrap;word-break:break-word;max-height:260px;overflow:auto;color:#dbeafe}}.no-children{{color:#fbbf24}}label{{display:block;margin-top:10px}}textarea,select{{box-sizing:border-box;background:#0f172a;color:#f8fafc;border:1px solid #475569;border-radius:4px;padding:7px}}textarea{{display:block;width:100%;height:78px;margin-top:4px}}code{{color:#bfdbfe;overflow-wrap:anywhere}}@media(max-width:980px){{body{{padding:12px}}.page-grid{{grid-template-columns:1fr}}}}</style></head><body>
<h1>本地 PDF 分块与双栏排序人工核验：arXiv:{html.escape(report['paper_id'])}</h1><p>本包仅使用本地 <code>parse_pdf</code> 与 PDF 原生几何。Llama 区域复核与整篇转写均已明确关闭。</p>
<div class="toolbar"><button id="export" type="button">导出填写结果（JSON）</button><button id="clear" class="secondary" type="button">清除本机暂存</button><span id="state" class="save">填写内容会自动暂存在当前浏览器。</span></div>
<div class="warning"><b>核验规则：</b>先看粗框 R 是否切出完整图表/流程图/图注，再检查区域排序；双栏正文应左栏自上而下、再右栏自上而下。红色虚线框为未完整视觉候选，不能当作完整图表证据。</div>
<div class="meta"><b>PDF SHA-256：</b><code>{report['pdf_sha256']}</code><br><b>解析器：</b>{html.escape(str(report['parser']))}；<b>页数：</b>{report['page_count']}；<b>整体置信度：</b>{report['overall_confidence']}<br><b>有效布局统计：</b>{html.escape(json.dumps(dict(sorted(layouts.items())), ensure_ascii=False))}；<b>原解析布局统计：</b>{html.escape(json.dumps(dict(sorted(parser_layouts.items())), ensure_ascii=False))}<br><b>分块统计：</b>{html.escape(json.dumps(dict(sorted(region_counts.items())), ensure_ascii=False))}；<b>未完整视觉候选：</b>{incomplete_visuals}<br><b>风险页：</b>{', '.join(map(str, risk_pages)) or '无'}；<b>失败模式：</b>{html.escape(', '.join(map(str, report['failure_modes'])) or '无')}<br><b>Llama：</b>区域复核 disabled；整篇转写 disabled</div>
{''.join(cards)}
<script>const key='sciassistant.local_chunks.{html.escape(report['paper_id'])}.{html.escape(review_key_suffix)}';const state=document.querySelector('#state');function all(){{return [...document.querySelectorAll('.page-card')].map(x=>({{page:Number(x.dataset.page),decision:x.querySelector('[data-field=decision]').value,note:x.querySelector('[data-field=note]').value}}));}}function save(){{localStorage.setItem(key,JSON.stringify({{saved_at:new Date().toISOString(),reviews:all()}}));state.textContent='已自动暂存：'+new Date().toLocaleTimeString();}}function restore(){{try{{const d=JSON.parse(localStorage.getItem(key)||'null');if(!d?.reviews)return;for(const r of d.reviews){{const c=document.querySelector('#page-'+r.page);if(c){{c.querySelector('[data-field=decision]').value=r.decision||'未核验';c.querySelector('[data-field=note]').value=r.note||'';}}}}state.textContent='已恢复本机暂存：'+new Date(d.saved_at).toLocaleString();}}catch{{state.textContent='本机暂存读取失败，不影响导出。';}}}}document.querySelectorAll('[data-field]').forEach(x=>x.addEventListener('input',save));document.querySelectorAll('.overlay,.region-overlay').forEach(x=>x.addEventListener('click',()=>{{const id=x.dataset.target;document.querySelectorAll('.active').forEach(y=>y.classList.remove('active'));x.classList.add('active');const b=document.querySelector('#'+id);if(b){{b.classList.add('active');b.open=true;b.scrollIntoView({{behavior:'smooth',block:'center'}});}}}}));document.querySelector('#export').onclick=()=>{{const payload={{format:'sciassistant_pdf_chunk_review/v1',paper_id:{json.dumps(report['paper_id'], ensure_ascii=False)},pdf_sha256:{json.dumps(report['pdf_sha256'])},llama:{{vision:'disabled',full_pdf:'disabled'}},exported_at:new Date().toISOString(),reviews:all(),chunk_summary:{json.dumps({'region_counts': dict(region_counts), 'incomplete_visuals': incomplete_visuals}, ensure_ascii=False)}}};const b=new Blob([JSON.stringify(payload,null,2)],{{type:'application/json;charset=utf-8'}});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='pdf_chunks_{html.escape(report['paper_id'])}_{html.escape(review_key_suffix)}_manual_review.json';a.click();URL.revokeObjectURL(a.href);}};document.querySelector('#clear').onclick=()=>{{if(confirm('仅清除当前浏览器暂存，不删除已导出的 JSON。是否继续？')){{localStorage.removeItem(key);document.querySelectorAll('[data-field=decision]').forEach(x=>x.value='未核验');document.querySelectorAll('[data-field=note]').forEach(x=>x.value='');state.textContent='本机暂存已清除。';}}}};restore();</script></body></html>''', encoding="utf-8")
    # The original page-level review script remains for backwards compatibility.
    # This extension makes the visible per-region transcript reviewable and exportable.
    compare_script = f'''<script>
const compareReviewKey = 'sciassistant.local_chunks.{html.escape(report['paper_id'])}.{html.escape(review_key_suffix)}';
function collectPageReviews() {{ return [...document.querySelectorAll('.page-card')].map(card => ({{ page:Number(card.dataset.page), decision:card.querySelector('.page-review-decision').value, note:card.querySelector('.page-review-note').value }})); }}
function collectRegionReviews() {{ return [...document.querySelectorAll('.region[data-id]')].map(region => ({{ page:Number(region.closest('.page-card').dataset.page), region_id:region.dataset.id, decision:region.querySelector('[data-region-field=decision]').value, note:region.querySelector('[data-region-field=note]').value }})); }}
function saveCompareReview() {{ localStorage.setItem(compareReviewKey, JSON.stringify({{saved_at:new Date().toISOString(), reviews:collectPageReviews(), region_reviews:collectRegionReviews()}})); state.textContent='已自动暂存：'+new Date().toLocaleTimeString(); }}
function restoreCompareReview() {{ try {{ const draft=JSON.parse(localStorage.getItem(compareReviewKey)||'null'); if(!draft) return; for(const item of draft.reviews||[]) {{ const card=document.querySelector('#page-'+item.page); if(card) {{ card.querySelector('.page-review-decision').value=item.decision||'未核验'; card.querySelector('.page-review-note').value=item.note||''; }} }} for(const item of draft.region_reviews||[]) {{ const region=document.getElementById(item.region_id); if(region) {{ region.querySelector('[data-region-field=decision]').value=item.decision||'未核验'; region.querySelector('[data-region-field=note]').value=item.note||''; }} }} state.textContent='已恢复本机暂存：'+new Date(draft.saved_at).toLocaleString(); }} catch {{ state.textContent='本机暂存读取失败，不影响导出。'; }} }}
document.querySelectorAll('[data-field],[data-region-field]').forEach(node => node.addEventListener('input', saveCompareReview));
document.querySelector('#export').onclick=()=>{{ const payload={{format:'sciassistant_pdf_chunk_review/v2',paper_id:{json.dumps(report['paper_id'], ensure_ascii=False)},pdf_sha256:{json.dumps(report['pdf_sha256'])},llama:{{vision:'disabled',full_pdf:'disabled'}},exported_at:new Date().toISOString(),reviews:collectPageReviews(),region_reviews:collectRegionReviews(),chunk_summary:{json.dumps({'region_counts': dict(region_counts), 'incomplete_visuals': incomplete_visuals}, ensure_ascii=False)}}}; const blob=new Blob([JSON.stringify(payload,null,2)],{{type:'application/json;charset=utf-8'}}); const link=document.createElement('a'); link.href=URL.createObjectURL(blob); link.download='pdf_chunks_{html.escape(report['paper_id'])}_{html.escape(review_key_suffix)}_manual_review.json'; link.click(); URL.revokeObjectURL(link.href); }};
restoreCompareReview();
</script>'''
    # Keep the v5 page-level review presentation: no additional transcript panel.
    compare_script = ""
    output.write_text(output.read_text(encoding="utf-8").replace("</body>", compare_script + "</body>"), encoding="utf-8")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pdf", type=Path, help="local PDF path")
    parser.add_argument("--output", type=Path, default=Path("docs/local_layout_2103.00020_20260815.html"))
    parser.add_argument(
        "--review-key-suffix",
        default="",
        help="unique browser draft namespace; use a batch/version identifier to avoid restoring an older review",
    )
    args = parser.parse_args()
    source = args.pdf.resolve()
    parsed = parse_pdf(source, enable_ocr=True)
    if not parsed.get("success"):
        raise RuntimeError(f"Local PDF parsing failed: {source}")
    output = args.output if args.output.is_absolute() else ROOT / args.output
    build_html(source, parsed, output, review_key_suffix=args.review_key_suffix)
    print(json.dumps({"pdf": str(source), "output": str(output), "pages": parsed.get("page_count"), "llama": "disabled"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
