"""Build a local visual manual-review package from real run_demo logs.

The output deliberately keeps LlamaParse text separate from the source image.
It is an audit aid, not a source of evidence or an automatic acceptance tool.
"""

from __future__ import annotations

import argparse
import base64
import html
import json
import shutil
import tempfile
from pathlib import Path
from typing import Any

import fitz


DEFAULT_RUNS = (
    (
        "2409.12421v1",
        Path("workspaces/c862d8fa-a691-4a3d-8849-34368d667cd6"),
    ),
    (
        "2103.00020",
        Path("workspaces/195682d4-6401-4dae-a97b-d768d0c6a20e"),
    ),
)


def _find_llama_result(log_path: Path) -> dict[str, Any]:
    for line in log_path.read_text(encoding="utf-8").splitlines():
        record = json.loads(line)
        if record.get("tool_name") != "arxiv_read_paper":
            continue
        data = record.get("output_result", {}).get("data", {})
        if data.get("llama_vision", {}).get("regions"):
            return data
    raise RuntimeError(f"No LlamaParse regions found in {log_path}")


def _data_uri(image_path: Path) -> str:
    payload = base64.b64encode(image_path.read_bytes()).decode("ascii")
    return f"data:image/png;base64,{payload}"


def _render_region(page: fitz.Page, region: dict[str, Any], destination: Path) -> None:
    expanded = fitz.Rect(region["expanded_bbox"])
    original = fitz.Rect(region["original_bbox"])
    # Drawing into the page is not acceptable. Render overlay in a temporary PDF page instead.
    scratch = fitz.open()
    scratch_page = scratch.new_page(width=expanded.width, height=expanded.height)
    scratch_page.show_pdf_page(scratch_page.rect, page.parent, page.number, clip=expanded)
    original_local = fitz.Rect(
        original.x0 - expanded.x0,
        original.y0 - expanded.y0,
        original.x1 - expanded.x0,
        original.y1 - expanded.y0,
    )
    overlay = scratch_page.new_shape()
    overlay.draw_rect(scratch_page.rect)
    overlay.finish(color=(0.1, 0.4, 0.9), width=1.6)
    overlay = scratch_page.new_shape()
    overlay.draw_rect(original_local)
    overlay.finish(color=(0.9, 0.12, 0.12), width=1.6)
    overlay.commit()
    matrix = fitz.Matrix(1.75, 1.75)
    pix = scratch_page.get_pixmap(matrix=matrix, alpha=False)
    pix.save(destination)
    scratch.close()


def _region_text(region: dict[str, Any]) -> str:
    review = region.get("review", {}).get("review", {})
    if not review:
        return "LlamaParse 未返回可用结果。"
    text = review.get("transcription") or review.get("latex") or "LlamaParse 未返回转写内容。"
    uncertainty = "; ".join(review.get("uncertainties") or [])
    if uncertainty:
        text += f"\n\n不确定性说明（服务原文）：{uncertainty}"
    return text


def _display_type(value: str) -> str:
    return {"table": "表格候选", "formula": "公式候选", "figure": "图形候选", "image": "图像候选"}.get(value, value)


def _display_status(value: str) -> str:
    return {"suggestion": "仅建议，未覆盖", "accepted": "已接受", "failed": "复核失败", "unknown": "未知"}.get(value, value)


def _card(paper_id: str, index: int, region: dict[str, Any], image_uri: str) -> str:
    review = region.get("review", {})
    review_payload = review.get("review", {})
    status = region.get("review_status", "unknown")
    result = html.escape(_region_text(region))
    card_id = f"{paper_id}-{index}"
    return f"""
    <article class=\"card {html.escape(status)}\" id=\"{card_id}\" data-paper-id=\"{html.escape(paper_id)}\" data-region-index=\"{index}\" data-page=\"{region['page']}\" data-content-type=\"{html.escape(region.get('content_type', 'unknown'))}\">
      <div class=\"heading\"><h3>#{index} - 第 {region['page']} 页 - {html.escape(_display_type(region.get('content_type', 'unknown')))}</h3><span>{html.escape(_display_status(status))}</span></div>
      <div class=\"grid\">
        <section><img src=\"{image_uri}\" alt=\"PDF 第 {region['page']} 页复核截图\"><p class=\"legend\"><b>蓝框</b>：实际发送给 LlamaParse 的扩边截图范围。<b>红框</b>：本地解析器最初提出的候选范围。</p></section>
        <section class=\"result\"><h4>LlamaParse 原始转写</h4><pre>{result}</pre>
          <dl><dt>原始坐标框</dt><dd>{html.escape(str(region['original_bbox']))}</dd><dt>扩边坐标框</dt><dd>{html.escape(str(region['expanded_bbox']))}</dd><dt>服务报告置信度</dt><dd>{html.escape(str(review_payload.get('model_confidence', '无')))}</dd><dt>服务耗时</dt><dd>{html.escape(str(review.get('elapsed_ms', '无')))} ms</dd></dl>
          <label for=\"decision-{card_id}\">人工结论 <select id=\"decision-{card_id}\" data-field=\"decision\"><option value=\"未核验\">未核验</option><option value=\"通过\">通过</option><option value=\"部分通过\">部分通过</option><option value=\"不通过\">不通过</option></select></label>
          <label for=\"note-{card_id}\">核验备注 <textarea id=\"note-{card_id}\" data-field=\"note\" placeholder=\"记录缺失字符、表格行列/单元格、图中数据点或连线等问题。\"></textarea></label>
        </section>
      </div>
    </article>"""


def build_report(project_root: Path, output: Path) -> None:
    # Keep the final HTML self-contained so it can be opened or copied without
    # a companion directory of screenshots.
    asset_dir = Path(tempfile.mkdtemp(prefix="llamaparse_visual_review_"))
    cards: list[str] = []
    summaries: list[str] = []

    for paper_id, workspace_rel in DEFAULT_RUNS:
        workspace = project_root / workspace_rel
        data = _find_llama_result(workspace / "tool_call_logs/tool_calls_2026-08-15.jsonl")
        pdf_path = Path(data["pdf_path"])
        document = fitz.open(pdf_path)
        regions = data["llama_vision"]["regions"]
        info = data["llama_vision"]
        summaries.append(
            f"<li><a href=\"#{paper_id}\">{paper_id}</a>：选中 {len(regions)} 个区域，"
            f"成功 {info.get('success_count', 0)} 个，失败 {info.get('failure_count', 0)} 个。"
            f"原始 PDF：<code>{html.escape(str(pdf_path))}</code></li>"
        )
        cards.append(f"<h2 id=\"{paper_id}\">arXiv:{paper_id}</h2>")
        for index, region in enumerate(regions, start=1):
            image_path = asset_dir / f"{paper_id}_{index:02d}_p{region['page']}.png"
            _render_region(document[region["page"] - 1], region, image_path)
            cards.append(_card(paper_id, index, region, _data_uri(image_path)))
        document.close()

    output.write_text(
        """<!doctype html><html lang=\"zh-CN\"><head><meta charset=\"utf-8\"><title>LlamaParse 视觉人工核验包</title>
<style>
:root{color-scheme:dark}body{font-family:Segoe UI,Arial,sans-serif;background:#111827;color:#e5e7eb;margin:0 auto;max-width:1440px;padding:30px}h1{margin-bottom:4px;color:#f9fafb}h2{margin-top:48px;border-bottom:2px solid #60a5fa;padding-bottom:8px;color:#f9fafb}.note{background:#2d270d;border-left:5px solid #fbbf24;padding:14px;color:#fef3c7}.toolbar{position:sticky;top:12px;z-index:2;display:flex;flex-wrap:wrap;gap:10px;align-items:center;background:#1f2937;border:1px solid #374151;border-radius:8px;padding:12px;box-shadow:0 8px 24px #0008}.toolbar button{border:1px solid #60a5fa;border-radius:5px;background:#1d4ed8;color:#fff;padding:8px 12px;font-weight:600;cursor:pointer}.toolbar button:hover{background:#2563eb}.toolbar .secondary{background:#374151;border-color:#6b7280}.save-state{font-size:13px;color:#a7f3d0}.card{background:#1f2937;border:1px solid #374151;border-radius:8px;margin:18px 0;box-shadow:0 1px 3px #0008}.heading{display:flex;justify-content:space-between;align-items:center;padding:0 18px;border-bottom:1px solid #374151}.heading h3{color:#f3f4f6}.heading span{background:#3f3513;color:#fde68a;padding:4px 8px;border-radius:4px;font-size:13px}.grid{display:grid;grid-template-columns:minmax(420px,1.2fr) minmax(360px,1fr);gap:18px;padding:18px}.grid img{width:100%;height:auto;border:1px solid #64748b;background:#fff}.legend{font-size:13px;color:#cbd5e1}.legend b:first-child{color:#60a5fa}.legend b:nth-child(2){color:#f87171}.result{min-width:0}.result h4{color:#f3f4f6}pre{white-space:pre-wrap;word-break:break-word;max-height:330px;overflow:auto;background:#0b1220;color:#d1d5db;padding:12px;border:1px solid #334155;border-radius:5px;font-size:12px}dl{display:grid;grid-template-columns:135px 1fr;font-size:13px}dt{font-weight:600;color:#cbd5e1}dd{margin:0 0 5px;overflow-wrap:anywhere;color:#94a3b8}label{display:block;margin-top:10px;font-size:13px;color:#e5e7eb}textarea,select{box-sizing:border-box;background:#111827;color:#f3f4f6;border:1px solid #4b5563;border-radius:4px;padding:7px}textarea{width:100%;height:66px;margin-top:4px;resize:vertical}select{margin-left:8px}code{color:#bfdbfe}a{color:#93c5fd}@media(max-width:900px){.grid{grid-template-columns:1fr}body{padding:14px}.toolbar{top:6px}}</style></head><body>
<h1>LlamaParse 视觉人工核验包</h1><p>基于 2026-08-15 的两次真实 <code>run_demo</code> 运行生成。</p>
<div class=\"toolbar\"><button id=\"export-review\" type=\"button\">导出填写结果（JSON）</button><button id=\"clear-draft\" class=\"secondary\" type=\"button\">清除本机暂存</button><span id=\"save-state\" class=\"save-state\">填写内容会自动暂存在当前浏览器。</span></div>
<p class=\"note\"><strong>使用方式：</strong>左侧是来自原始 PDF 的实际裁剪截图，右侧是该截图对应的 LlamaParse 原始返回。蓝框是传给服务的扩边范围，红框是本地解析器最初提出的区域。返回内容即使看似结构化也不能直接视为可信证据；请逐一以左图和原 PDF 核验公式字符、表格单元格、图中数据点及流程图连线。完成后点击“导出填写结果（JSON）”，把下载的 JSON 文件发给我即可。</p>
<ul>"""
        + "\n".join(summaries)
        + "</ul>\n"
        + "\n".join(cards)
        + """<script>
const draftKey = 'sciassistant.llamaparse.manual-review.20260815.visual-object-v1';
const stateNode = document.getElementById('save-state');
function collectReviews(){return [...document.querySelectorAll('.card[data-paper-id]')].map(card=>({paper_id:card.dataset.paperId,region_index:Number(card.dataset.regionIndex),page:Number(card.dataset.page),content_type:card.dataset.contentType,decision:card.querySelector('[data-field=decision]').value,note:card.querySelector('[data-field=note]').value}));}
function saveDraft(){localStorage.setItem(draftKey,JSON.stringify({saved_at:new Date().toISOString(),reviews:collectReviews()}));stateNode.textContent='已自动暂存：'+new Date().toLocaleTimeString();}
function restoreDraft(){try{const draft=JSON.parse(localStorage.getItem(draftKey)||'null');if(!draft?.reviews)return;for(const item of draft.reviews){const card=document.getElementById(`${item.paper_id}-${item.region_index}`);if(!card)continue;card.querySelector('[data-field=decision]').value=item.decision||'未核验';card.querySelector('[data-field=note]').value=item.note||'';}stateNode.textContent='已恢复本机暂存：'+new Date(draft.saved_at).toLocaleString();}catch{stateNode.textContent='本机暂存读取失败，不影响导出。';}}
document.querySelectorAll('[data-field]').forEach(field=>field.addEventListener('input',saveDraft));
document.getElementById('export-review').addEventListener('click',()=>{const payload={format:'sciassistant_llamaparse_manual_review/v1',exported_at:new Date().toISOString(),source:'两次 run_demo 真实运行：arXiv:2409.12421v1 与 arXiv:2103.00020',reviews:collectReviews()};const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json;charset=utf-8'});const link=document.createElement('a');link.href=URL.createObjectURL(blob);link.download='LLAMAPARSE_MANUAL_REVIEW_20260815.json';link.click();URL.revokeObjectURL(link.href);});
document.getElementById('clear-draft').addEventListener('click',()=>{if(confirm('仅清除当前浏览器的自动暂存，不会删除已导出的 JSON 文件。是否继续？')){localStorage.removeItem(draftKey);document.querySelectorAll('[data-field=decision]').forEach(node=>node.value='未核验');document.querySelectorAll('[data-field=note]').forEach(node=>node.value='');stateNode.textContent='本机暂存已清除。';}});
restoreDraft();
</script></body></html>""",
        encoding="utf-8",
    )
    shutil.rmtree(asset_dir)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default="docs/LLAMAPARSE_VISUAL_REVIEW_2409_2103_20260815.html")
    args = parser.parse_args()
    project_root = Path(__file__).resolve().parents[2]
    build_report(project_root, project_root / args.output)


if __name__ == "__main__":
    main()
