"""Build an offline evidence-boundary review package for a hybrid PDF run.

This is intentionally a reporting tool.  It does not invoke LlamaParse or
modify the evidence ledger.  Whole-document Markdown has no provider page map,
so the report labels its Figure/Table anchors as human-verifiable associations,
not page-level provider evidence.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import html
import json
from pathlib import Path
from typing import Any

import fitz


SAMPLES = (
    {
        "page": 3,
        "title": "样本 A：Figure 1 Transformer 架构图",
        "anchor": "Figure 1: The Transformer - model architecture.",
        "basis": "原 PDF 图注 “Figure 1” 与附近的 “3 Model Architecture” 标题；非服务逐页映射。",
        "checks": ("编码器与解码器两个堆栈是否都存在", "Multi-Head Attention / Masked Multi-Head Attention 标签是否正确", "箭头、残差连接和 Nx 重复层是否被错误省略或补造"),
    },
    {
        "page": 6,
        "title": "样本 B：Table 1 与位置编码公式",
        "anchor": "Table 1: Maximum path lengths",
        "basis": "原 PDF 的 Table 1 图注、随后 “3.5 Positional Encoding” 标题及公式文字锚点；非服务逐页映射。",
        "checks": ("Table 1 的四行层类型和列标题是否完整", "复杂度、最大路径长度和最少顺序操作是否逐格一致", "sin / cos 公式的下标、指数、分母和符号是否保留"),
    },
    {
        "page": 13,
        "title": "样本 C：Figure 3 注意力可视化",
        "anchor": "# Attention Visualizations",
        "basis": "原 PDF 标题 “Attention Visualizations” 和 Figure 3 图注锚点；非服务逐页映射。此页另有一个精确 bbox 的区域复核，见下一节。",
        "checks": ("“making...more difficult” 的词序是否完整", "不同颜色的注意力头是否被误写为确定拓扑", "图注是否与原文一致，尤其是 layer 5 of 6 与 Best viewed in color"),
    },
)


def uri(pix: fitz.Pixmap) -> str:
    return "data:image/png;base64," + base64.b64encode(pix.tobytes("png")).decode("ascii")


def escape(value: Any) -> str:
    return html.escape(str(value))


def context(markdown: str, anchor: str, radius: int = 1900) -> str:
    position = markdown.lower().find(anchor.lower())
    if position < 0:
        return "未在整篇 LlamaParse Markdown 中找到该锚点。"
    start = max(0, position - radius)
    end = min(len(markdown), position + radius)
    prefix = "[前文已省略]\n\n" if start else ""
    suffix = "\n\n[后文已省略]" if end < len(markdown) else ""
    return prefix + markdown[start:end] + suffix


def page_image(doc: fitz.Document, page: int, scale: float = 1.45) -> str:
    return uri(doc[page - 1].get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False))


def overlay_page(doc: fitz.Document, page_no: int, original: fitz.Rect, expanded: fitz.Rect) -> str:
    source = doc[page_no - 1]
    scratch = fitz.open()
    page = scratch.new_page(width=source.rect.width, height=source.rect.height)
    page.show_pdf_page(page.rect, doc, page_no - 1)
    shape = page.new_shape()
    shape.draw_rect(expanded)
    shape.finish(color=(0.12, 0.55, 1.0), width=2.0)
    shape = page.new_shape()
    shape.draw_rect(original)
    shape.finish(color=(1.0, 0.2, 0.2), width=2.0)
    shape.commit()
    result = uri(page.get_pixmap(matrix=fitz.Matrix(1.45, 1.45), alpha=False))
    scratch.close()
    return result


def crop_image(doc: fitz.Document, page_no: int, original: fitz.Rect, expanded: fitz.Rect) -> str:
    source = doc[page_no - 1]
    scratch = fitz.open()
    page = scratch.new_page(width=expanded.width, height=expanded.height)
    page.show_pdf_page(page.rect, doc, page_no - 1, clip=expanded)
    local = fitz.Rect(original.x0 - expanded.x0, original.y0 - expanded.y0, original.x1 - expanded.x0, original.y1 - expanded.y0)
    shape = page.new_shape()
    shape.draw_rect(page.rect)
    shape.finish(color=(0.12, 0.55, 1.0), width=2.0)
    shape = page.new_shape()
    shape.draw_rect(local)
    shape.finish(color=(1.0, 0.2, 0.2), width=2.0)
    shape.commit()
    result = uri(page.get_pixmap(matrix=fitz.Matrix(1.8, 1.8), alpha=False))
    scratch.close()
    return result


def checklist(values: tuple[str, ...]) -> str:
    return "".join(f"<li>{escape(value)}</li>" for value in values)


def sample_card(doc: fitz.Document, sample: dict[str, Any], markdown: str, local_page: dict[str, Any]) -> str:
    page = int(sample["page"])
    local_text = str(local_page.get("text") or "")
    local_excerpt = local_text[:3000] + ("\n\n[本地文本后文已省略]" if len(local_text) > 3000 else "")
    visuals = local_page.get("visuals") or {}
    local_summary = (
        f"layout={local_page.get('layout')}；reading_order_confidence={local_page.get('reading_order_confidence')}；"
        f"visual_confidence={visuals.get('visual_confidence')}；"
        f"figure_structure_risk={visuals.get('figure_structure_risk')}；"
        f"text_source={local_page.get('text_source')}"
    )
    return f'''<article class="card" data-kind="anchor" data-id="anchor-{page}">
<header><h2>{escape(sample["title"])}</h2><span class="weak">内容锚点匹配，非逐页服务映射</span></header>
<div class="grid sample-grid"><section><img src="{page_image(doc, page)}" alt="原 PDF 第 {page} 页"><p class="caption">原 PDF 第 {page} 页完整渲染。它是人工核验的原始依据。</p></section>
<section><h3>整篇 LlamaParse Markdown 片段</h3><p class="mapping"><b>页面关联依据：</b>{escape(sample["basis"])}</p><pre>{escape(context(markdown, sample["anchor"]))}</pre><details><summary>展开：本地解析器同页原始文本与风险摘要</summary><p class="local-summary">{escape(local_summary)}</p><pre>{escape(local_excerpt)}</pre></details></section>
<section><h3>人工核验项目</h3><ul>{checklist(sample["checks"])}</ul><label>人工结论 <select data-field="decision"><option>未核验</option><option>通过</option><option>部分通过</option><option>不通过</option></select></label><label>核验备注<textarea data-field="note" placeholder="写明原 PDF 位置、漏字/错字、表格单元格、公式符号、图形箭头或颜色语义的问题。"></textarea></label></section></div></article>'''


def vision_card(doc: fitz.Document, region: dict[str, Any], ledger: dict[str, Any]) -> str:
    review = region["review"]["review"]
    original = fitz.Rect(region["original_bbox"])
    expanded = fitz.Rect(region["expanded_bbox"])
    page = int(region["page"])
    ledger_entry = (ledger.get("entries") or [{}])[0]
    text = review.get("transcription") or review.get("latex") or "服务未返回转写。"
    return f'''<article class="card important" data-kind="vision" data-id="vision-1">
<header><h2>精确区域复核：第 {page} 页 Figure 3</h2><span class="risk">仅建议，未进入最终证据</span></header>
<p class="warning">这是唯一具有<strong>服务调用可回指页码与 bbox</strong>的增强项。它仍不可引用：服务自评置信度为 {escape(review.get("model_confidence"))}，并标记 <code>is_partial={escape(review.get("is_partial"))}</code>；本次 <code>override_count=0</code>。</p>
<div class="grid vision-grid"><section><h3>原 PDF 第 {page} 页和区域坐标</h3><img src="{overlay_page(doc, page, original, expanded)}" alt="第 {page} 页区域边框"><p class="caption"><b class="blue">蓝框</b>：实际传给服务的扩边范围。<b class="red">红框</b>：本地解析器的初始候选（仅 <code>&lt;EOS&gt;</code>）。图注位于蓝框下方，没有被送入这次区域截图。</p></section>
<section><h3>实际发送的裁剪图</h3><img src="{crop_image(doc, page, original, expanded)}" alt="实际区域裁剪"><p class="caption">此裁剪图与扩边 bbox 一一对应；红框为原始候选在裁剪图内的位置。</p></section>
<section><h3>LlamaParse 区域原始返回</h3><pre>{escape(text)}</pre><dl><dt>页码</dt><dd>{page}</dd><dt>初始 bbox</dt><dd>{escape(region["original_bbox"])}</dd><dt>扩边 bbox</dt><dd>{escape(region["expanded_bbox"])}</dd><dt>裁剪策略</dt><dd>{escape(region.get("crop_strategy"))}</dd><dt>本地置信度</dt><dd>{escape(region.get("original_confidence"))}</dd><dt>服务自评</dt><dd>{escape(review.get("model_confidence"))}</dd><dt>服务耗时</dt><dd>{escape(region["review"].get("elapsed_ms"))} ms</dd><dt>账本状态</dt><dd>{escape(ledger_entry.get("review_status"))}; citation_allowed={escape(ledger_entry.get("citation_allowed"))}</dd><dt>不确定性</dt><dd>{escape("; ".join(review.get("uncertainties") or []))}</dd></dl><h4>必须核对</h4><ul>{checklist(("上下两行 token 是否完整，且 “making” 是否确为焦点", "模型列出的 T18 到 B17/B18/B24/B25/B27 连线是否在原图中真实存在", "不同颜色的注意力权重不应被误写成没有颜色或权重含义的确定结构", "图注没有输入裁剪图；它在返回中出现时只能与原 PDF 图注另行核验"))}</ul><label>人工结论 <select data-field="decision"><option>未核验</option><option>通过</option><option>部分通过</option><option>不通过</option></select></label><label>核验备注<textarea data-field="note" placeholder="逐条记录 token、连线、颜色/权重、图注以及裁剪边界的真实情况。"></textarea></label></section></div></article>'''


def build(root: Path, run_data: Path, output: Path) -> None:
    result = json.loads(run_data.read_text(encoding="utf-8"))["data"]
    pdf = Path(result["pdf_path"])
    full = result["llama_full_pdf"]
    vision = result["llama_vision"]
    ledger = json.loads(Path(result["hybrid_evidence_path"]).read_text(encoding="utf-8"))
    markdown = Path(full["text_path"]).read_text(encoding="utf-8", errors="replace")
    parse_path = Path(result["parse_metadata_path"])
    pages_path = parse_path.with_name(parse_path.name.replace(".parse.json", ".pages.json"))
    local_pages = json.loads(pages_path.read_text(encoding="utf-8"))
    digest = hashlib.sha256(pdf.read_bytes()).hexdigest()
    doc = fitz.open(pdf)
    cards = "\n".join(sample_card(doc, sample, markdown, local_pages[int(sample["page"]) - 1]) for sample in SAMPLES)
    cards += "\n" + vision_card(doc, vision["regions"][0], ledger)
    doc.close()
    output.parent.mkdir(parents=True, exist_ok=True)
    metadata = {"paper_id": result["paper_id"], "pdf_sha256": digest, "pdf_pages": 15, "mode": result["pdf_parse_mode"], "full_job_id": full["job_id"], "full_elapsed_ms": full["elapsed_ms"], "full_markdown_chars": full["markdown_chars"], "vision_selected": vision["selected_count"], "vision_success": vision["success_count"], "vision_override": vision["override_count"]}
    output.write_text(f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>混合增强核验包 - 1706.03762</title><style>
:root{{color-scheme:dark}}body{{max-width:1780px;margin:auto;padding:26px;background:#0b1020;color:#e5e7eb;font:15px "Segoe UI",Arial,sans-serif;line-height:1.55}}h1,h2,h3,h4{{color:#f8fafc}}h1{{margin-bottom:0}}code{{color:#bfdbfe;overflow-wrap:anywhere}}.meta,.note,.warning{{border:1px solid #334155;border-radius:7px;padding:14px;margin:14px 0;background:#131c30}}.note{{border-left:5px solid #60a5fa}}.warning{{margin:14px 18px;border-left:5px solid #fbbf24;color:#fef3c7}}.toolbar{{position:sticky;top:8px;z-index:5;display:flex;gap:10px;flex-wrap:wrap;align-items:center;background:#162033;border:1px solid #334155;border-radius:7px;padding:10px}}button{{background:#1d4ed8;color:white;border:1px solid #60a5fa;border-radius:4px;padding:8px 12px;font-weight:600;cursor:pointer}}button.secondary{{background:#334155;border-color:#64748b}}.state{{font-size:13px;color:#a7f3d0}}.card{{margin:25px 0;background:#131c30;border:1px solid #334155;border-radius:8px;overflow:hidden}}.important{{border-color:#f59e0b}}header{{padding:0 18px;border-bottom:1px solid #334155;display:flex;justify-content:space-between;gap:16px;align-items:center}}header h2{{font-size:19px}}header span{{white-space:nowrap;padding:3px 8px;border-radius:4px;font-size:12px}}.weak{{background:#172554;color:#bfdbfe}}.risk{{background:#451a03;color:#fde68a}}.grid{{display:grid;gap:16px;padding:18px}}.sample-grid{{grid-template-columns:minmax(390px,1.05fr) minmax(360px,1fr) minmax(280px,.65fr)}}.vision-grid{{grid-template-columns:minmax(370px,1fr) minmax(340px,.95fr) minmax(390px,1.08fr)}}img{{width:100%;height:auto;background:#fff;border:1px solid #64748b}}.caption{{font-size:13px;color:#cbd5e1}}.blue{{color:#60a5fa}}.red{{color:#f87171}}.mapping{{background:#102446;border-left:4px solid #60a5fa;padding:9px;font-size:13px;color:#dbeafe}}pre{{max-height:465px;overflow:auto;white-space:pre-wrap;word-break:break-word;background:#070c18;border:1px solid #243247;border-radius:5px;padding:12px;color:#d1d5db;font-size:12px}}details{{margin-top:10px}}summary{{cursor:pointer;color:#93c5fd}}.local-summary{{font-size:12px;color:#a5b4fc;background:#111a2c;padding:8px;border-radius:4px}}dl{{display:grid;grid-template-columns:125px 1fr;gap:3px 10px;font-size:13px}}dt{{font-weight:600;color:#cbd5e1}}dd{{margin:0;color:#94a3b8;overflow-wrap:anywhere}}textarea,select{{box-sizing:border-box;background:#080e1c;color:#f3f4f6;border:1px solid #475569;border-radius:4px;padding:7px}}textarea{{display:block;width:100%;height:84px;margin-top:4px;resize:vertical}}select{{margin-left:8px}}label{{display:block;margin-top:12px}}li{{margin:7px 0}}@media(max-width:1100px){{.sample-grid,.vision-grid{{grid-template-columns:1fr}}body{{padding:13px}}}}</style></head><body>
<h1>混合增强模式人工核验包：arXiv:1706.03762</h1><p>生成时间：2026-08-16。此包来自一次真实混合模式读取，不重新调用任何外部服务。</p>
<div class="toolbar"><button id="export" type="button">导出填写结果（JSON）</button><button id="clear" class="secondary" type="button">清除本机暂存</button><span id="state" class="state">填写内容会自动保存在当前浏览器。</span></div>
<section class="meta"><b>运行概要：</b>PDF SHA-256 <code>{digest}</code>；原 PDF 15 页；模式 <code>{escape(result["pdf_parse_mode"])}</code>；整篇 LlamaParse：<code>completed</code>，job <code>{escape(full["job_id"])}</code>，{full["elapsed_ms"]} ms，{full["markdown_chars"]} 字符；区域复核：选中 {vision["selected_count"]}，成功 {vision["success_count"]}，覆盖原解析 {vision["override_count"]}。</section>
<section class="note"><b>证据边界：</b>整篇 LlamaParse Markdown 未返回可靠的逐页分段，因此前三个样本只能依据图题、标题和文本锚点与原 PDF 做人工关联，不能宣称服务已经给出逐页证据。最后一个区域复核具备页码与 bbox，但账本状态为 <code>suggestion</code>、<code>citation_allowed=false</code>，且没有覆盖本地结果。页面图片均来自原 PDF 的本地渲染。</section>
<h2>一、整篇转写的内容锚点对照</h2>{cards}
<section class="note"><b>提交人工结果时的重点：</b>请尤其记录模型是否把图的布局、颜色或连线编造成确定事实；是否漏掉公式符号、表格单元格；以及锚点关联是否实际落在左侧 PDF 页面。导出的 JSON 仅包含人工结论和备注，不包含 PDF 或 API 密钥。</section>
<script>const KEY='sciassistant.hybrid-review.1706.03762.20260816.v1';const state=document.getElementById('state');function cards(){{return [...document.querySelectorAll('[data-id]')].map(card=>({{id:card.dataset.id,kind:card.dataset.kind,decision:card.querySelector('[data-field=decision]').value,note:card.querySelector('[data-field=note]').value}}));}}function save(){{localStorage.setItem(KEY,JSON.stringify({{saved_at:new Date().toISOString(),metadata:{json.dumps(metadata,ensure_ascii=False)},reviews:cards()}}));state.textContent='已自动暂存：'+new Date().toLocaleTimeString();}}function restore(){{try{{const data=JSON.parse(localStorage.getItem(KEY)||'null');if(!data)return;data.reviews.forEach(item=>{{const card=document.querySelector(`[data-id="${{item.id}}"]`);if(card){{card.querySelector('[data-field=decision]').value=item.decision||'未核验';card.querySelector('[data-field=note]').value=item.note||'';}}}});state.textContent='已恢复本机暂存：'+new Date(data.saved_at).toLocaleString();}}catch{{state.textContent='本机暂存读取失败，不影响填写与导出。';}}}}document.querySelectorAll('[data-field]').forEach(n=>n.addEventListener('input',save));document.getElementById('export').onclick=()=>{{const out={{format:'sciassistant_hybrid_comparison_review/v1',exported_at:new Date().toISOString(),metadata:{json.dumps(metadata,ensure_ascii=False)},reviews:cards()}};const blob=new Blob([JSON.stringify(out,null,2)],{{type:'application/json;charset=utf-8'}});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='HYBRID_REVIEW_1706.03762_MANUAL_RESULTS.json';a.click();URL.revokeObjectURL(a.href);}};document.getElementById('clear').onclick=()=>{{if(confirm('仅清除当前浏览器暂存，不会删除已导出的文件。是否继续？')){{localStorage.removeItem(KEY);document.querySelectorAll('[data-field=decision]').forEach(n=>n.value='未核验');document.querySelectorAll('[data-field=note]').forEach(n=>n.value='');state.textContent='本机暂存已清除。';}}}};restore();</script></body></html>''', encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-data", default="tmp/hybrid_1706.03762_20260816.json")
    parser.add_argument("--output", default="docs/HYBRID_REVIEW_1706.03762_20260816.html")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    build(root, root / args.run_data, root / args.output)


if __name__ == "__main__":
    main()
