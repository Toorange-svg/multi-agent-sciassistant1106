"""Generate a human-review checklist from the current PDF parser."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from pdf_pipeline import parse_pdf  # noqa: E402


def run(pdf: Path) -> dict:
    parsed = parse_pdf(pdf, enable_ocr=False)
    quality = parsed.get("parse_quality") or {}
    page_conf = quality.get("page_confidence") or {}
    blocks = parsed.get("layout_blocks") or []
    items = []
    for index, block in enumerate(blocks, 1):
        kind = str(block.get("type") or "")
        if kind not in {"formula", "table"}:
            continue
        page = block.get("page")
        risks = []
        if kind == "formula":
            risks.append("formula_extraction_risk")
        if kind == "table":
            risks.append("table_structure_risk")
        items.append({
            "item_id": f"{pdf.stem}-b{index}", "page": page,
            "bbox": block.get("bbox"), "column": block.get("column"),
            "type": kind, "text": block.get("text", ""),
            "confidence": block.get("confidence"),
            "page_confidence": page_conf.get(str(page), page_conf.get(page)),
            "risks": risks, "reading_order_confidence": block.get("reading_order_confidence"),
            "manual_status": "待人工核验", "llama_status": "未调用（默认关闭）",
        })
    return {
        "pdf": str(pdf), "paper_id": pdf.stem, "success": parsed.get("success"),
        "page_count": parsed.get("page_count"), "parser": parsed.get("parser"),
        "parse_quality": quality, "formula_count": sum(x["type"] == "formula" for x in items),
        "table_count": sum(x["type"] == "table" for x in items), "items": items,
        "manual_instructions": [
            "按页码打开原 PDF，使用 bbox 定位区域；bbox 坐标单位为 PDF point。",
            "公式重点核对上下标、根号、希腊字母、分式、负号和公式编号。",
            "表格重点核对行列边界、表头、跨行跨列、数值小数点和单位。",
            "若原 PDF 与解析文本不一致，记录为失败，不要自行修改解析结果。",
        ],
    }


def markdown(report: dict) -> str:
    q = report["parse_quality"]
    lines = [f"# PDF 人工核验清单：{report['paper_id']}", "", f"- PDF：`{report['pdf']}`", f"- 解析成功：`{report['success']}`；页数：`{report['page_count']}`；解析器：`{report['parser']}`", f"- 总体置信度：`{q.get('overall_confidence')}`", f"- 公式候选：`{report['formula_count']}`；表格候选：`{report['table_count']}`", "- Llama 复核：未调用（`LLAMA_VISION_ENABLED=false`）", "", "## 核验规则", ""]
    lines += [f"- {x}" for x in report["manual_instructions"]]
    lines += ["", "## 逐项清单", "", "| ID | 类型 | 页 | bbox | 列 | 块置信度 | 页置信度 | 原始解析文本 | 人工结论 |", "|---|---|---:|---|---|---:|---:|---|---|"]
    for item in report["items"]:
        text = str(item["text"]).replace("|", "\\|").replace("\n", "<br>")
        lines.append(f"| {item['item_id']} | {item['type']} | {item['page']} | `{item['bbox']}` | {item.get('column') or ''} | {item.get('confidence')} | {item.get('page_confidence')} | {text} | 待人工核验 |")
    lines += ["", "## 页面风险摘要", "", "以下页面存在低置信度或版式风险，人工核验时优先检查：", ""]
    for page, conf in sorted((q.get("page_confidence") or {}).items(), key=lambda x: int(x[0])):
        if float(conf) < 0.85:
            lines.append(f"- 第 {page} 页：置信度 `{conf}`")
    lines += ["", "## 人工记录区", "", "请在逐项清单的‘人工结论’列记录：通过 / 部分正确 / 失败，并注明具体错误字符、单元格或 bbox。"]
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("pdf", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, default=Path("tests/pdf_manual_checklists"))
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    for pdf in args.pdf:
        report = run(pdf)
        (args.output / f"{pdf.stem}.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        (args.output / f"{pdf.stem}.md").write_text(markdown(report), encoding="utf-8")
        print(f"{pdf}: formulas={report['formula_count']} tables={report['table_count']} pages={report['page_count']}")


if __name__ == "__main__":
    main()
