"""Create a standalone dark manual-review package for real local-mode runs."""
from __future__ import annotations

import base64
import hashlib
import html
import json
import re
from pathlib import Path
from typing import Any

import fitz


PAPERS = ("2103.00020", "1706.03762", "2409.12421")


def redact_log(value: str) -> str:
    """Keep technical evidence useful without exposing credentials or payloads."""
    value = re.sub(r"(?im)((?:api[_ -]?key|token|secret|password|authorization)\s*[:=]\s*)([^\s'\";,]+)", r"\1[REDACTED]", value)
    value = re.sub(r"(?i)Bearer\s+[A-Za-z0-9._~+/=-]+", "Bearer [REDACTED]", value)
    value = re.sub(r"data:image/[^\s'\"]+", "data:image/[REDACTED]", value)
    return value[:90000]


def read_events(path: Path) -> list[dict[str, Any]]:
    if not path.is_file():
        return []
    rows = []
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            item = json.loads(line)
        except ValueError:
            continue
        if isinstance(item, dict):
            rows.append(item)
    return rows


def timeline_html(events: list[dict[str, Any]]) -> str:
    if not events:
        return "<p>本次入口未产出可读取的细分诊断事件。</p>"
    items = []
    for event in events:
        details = event.get("details") or {}
        elapsed = details.get("elapsed_ms", event.get("elapsed_ms", "-"))
        detail = "；".join(f"{esc(k)}={esc(v)}" for k, v in details.items() if k != "elapsed_ms")
        items.append(
            f"<li><code>{esc(event.get('stage'))}</code> - {esc(event.get('status'))}"
            f" - {esc(elapsed)} ms - {esc(event.get('reason'))} {detail}</li>"
        )
    return "<ol class='timeline'>" + "".join(items) + "</ol>"


def esc(value: Any) -> str:
    return html.escape(str(value or ""))


def data_uri(pix: fitz.Pixmap) -> str:
    return "data:image/png;base64," + base64.b64encode(pix.tobytes("png")).decode("ascii")


def newest_parse(root: Path, paper_id: str) -> Path:
    choices = sorted(root.glob(f"workspaces/**/arxiv/{paper_id}*.pdf.parse.json"),
                     key=lambda item: item.stat().st_mtime, reverse=True)
    if not choices:
        raise FileNotFoundError(f"parse metadata missing for {paper_id}")
    return choices[0]


def extract_answer(log: str) -> str:
    marker = log.rfind("Final Answer:")
    return log[marker + len("Final Answer:"):].strip() if marker >= 0 else log.strip()


def parse_ledger(answer: str) -> str:
    marker = answer.rfind("PDF EVIDENCE LEDGER")
    return answer[marker:].strip()[:5200] if marker >= 0 else "未在本次输出中发现证据账本。"


def choose_blocks(data: dict[str, Any]) -> list[dict[str, Any]]:
    blocks = list(data.get("layout_blocks") or [])
    risk_pages = set((data.get("parse_quality") or {}).get("low_reading_order_pages") or [])
    chosen: list[dict[str, Any]] = []
    for page in sorted(risk_pages):
        match = next((item for item in blocks if item.get("page") == page), None)
        if match:
            chosen.append(match)
    for kind in ("table", "formula", "figure", "text"):
        match = next((item for item in blocks if str(item.get("type", "")).lower() == kind), None)
        if match and match not in chosen:
            chosen.append(match)
    for item in blocks:
        if len(chosen) >= 8:
            break
        if item not in chosen:
            chosen.append(item)
    return chosen[:8]


def overlay(doc: fitz.Document, block: dict[str, Any]) -> str:
    page = doc[int(block["page"]) - 1]
    scratch = fitz.open()
    target = scratch.new_page(width=page.rect.width, height=page.rect.height)
    target.show_pdf_page(target.rect, doc, int(block["page"]) - 1)
    bbox = fitz.Rect(block.get("bbox") or (0, 0, 0, 0))
    shape = target.new_shape()
    shape.draw_rect(bbox)
    shape.finish(color=(0.2, 0.65, 1), width=2)
    shape.commit()
    result = data_uri(target.get_pixmap(matrix=fitz.Matrix(1.3, 1.3), alpha=False))
    scratch.close()
    return result


def review_card(doc: fitz.Document, block: dict[str, Any], index: int) -> str:
    preview = re.sub(r"\s+", " ", str(block.get("text") or "")).strip()
    page = int(block.get("page") or 0)
    block_type = str(block.get("type") or "text")
    confidence = block.get("confidence", "未报告")
    return f'''<article class="card" data-id="block-{index}"><header><h3>#{index} - 第 {page} 页 - {esc(block_type)} 候选</h3><span>{esc(block.get("column") or "未分栏")}</span></header><div class="grid"><section><img src="{overlay(doc, block)}" alt="原 PDF 第 {page} 页 bbox"><p>蓝框：本地解析块 <code>{esc(block.get("block_id"))}</code>，bbox={esc(block.get("bbox"))}</p></section><section><dl><dt>读取顺序</dt><dd>{esc(block.get("reading_order_index"))}</dd><dt>块置信度</dt><dd>{esc(confidence)}（仅风险提示）</dd><dt>排序策略</dt><dd>{esc(block.get("reading_order_strategy"))}</dd></dl><h4>本地提取文本</h4><pre>{esc(preview[:2500])}</pre></section><section><label>人工结论<select data-field="decision"><option>未核验</option><option>通过</option><option>部分通过</option><option>不通过</option></select></label><label>核验备注<textarea data-field="note" placeholder="对照原页确认 bbox、阅读顺序、文本、表格/公式/图形边界，以及是否能支持 Writer 的表述。"></textarea></label></section></div></article>'''


def paper_section(root: Path, paper_id: str) -> str:
    parse_path = newest_parse(root, paper_id)
    data = json.loads(parse_path.read_text(encoding="utf-8"))
    pdf = parse_path.with_name(parse_path.name.replace(".pdf.parse.json", ".pdf"))
    log_path = root / "logs" / "reliability_acceptance_20260817" / f"{paper_id[:4]}.run.log"
    answer = extract_answer(log_path.read_text(encoding="utf-8", errors="replace"))
    diagnostics_path = log_path.with_name(log_path.name.replace(".run.log", ".diagnostics.jsonl"))
    events = read_events(diagnostics_path)
    digest = hashlib.sha256(pdf.read_bytes()).hexdigest()
    doc = fitz.open(pdf)
    cards = "".join(review_card(doc, block, index + 1) for index, block in enumerate(choose_blocks(data)))
    doc.close()
    quality = data.get("parse_quality") or {}
    return f'''<section class="paper"><h2>arXiv:{paper_id}</h2><div class="meta">PDF SHA-256 <code>{digest}</code><br>页数：{esc(data.get("page_count"))}；本地解析器：{esc(data.get("parser"))}；总体风险分数：{esc(quality.get("overall_confidence"))}（非正确率）<br>本次入口：<code>run_demo.cmd --pdf-parse-mode local --query-mode paper_evidence</code></div><details open><summary>本次实际任务的阶段时间线</summary>{timeline_html(events)}</details><details><summary>技术诊断与脱敏原始日志</summary><pre>{esc(redact_log(log_path.read_text(encoding="utf-8", errors="replace")))}</pre></details><details open><summary>本次 Writer 输出（用于检查是否越过证据边界）</summary><pre>{esc(answer[:18000])}</pre></details><details><summary>确定性证据账本与许可规则</summary><pre>{esc(parse_ledger(answer))}</pre></details><h3>原 PDF 与本地解析块逐项核验</h3>{cards}</section>'''


def hybrid_section(root: Path) -> str:
    checks_path = root / "logs" / "reliability_acceptance_20260817" / "hybrid_degradation_checks.json"
    checks = json.loads(checks_path.read_text(encoding="utf-8")) if checks_path.is_file() else {}
    ledgers = sorted(root.glob("workspaces/**/arxiv/1706.03762.hybrid.evidence.json"),
                     key=lambda item: item.stat().st_mtime, reverse=True)
    ledger = json.loads(ledgers[0].read_text(encoding="utf-8")) if ledgers else {}
    entry = (ledger.get("entries") or [{}])[0]
    return f'''<section class="paper"><h2>混合增强：限定验收</h2><section class="note"><b>验收边界：</b>仅检查来源、页码、bbox 可回指，以及云端调用失败时本地证据仍保留。不会把 Llama 内容当作本轮质量结论；整篇 Llama 仅标为实验性。</section><details open><summary>已存在的真实混合证据账本回指样本</summary><pre>{esc(json.dumps({"pdf_sha256": ledger.get("pdf_sha256"), "mode": ledger.get("mode"), "entry": {key: entry.get(key) for key in ("evidence_id", "source", "page", "bbox", "original_bbox", "content_type", "citation_allowed", "review_status", "uncertainties")}}, ensure_ascii=False, indent=2))}</pre></details><details open><summary>受控失败降级演练（未使用真实 API Key，未访问 LlamaCloud）</summary><pre>{esc(json.dumps(checks, ensure_ascii=False, indent=2))}</pre><p class="note">两种演练均使用真实本地 PDF 的区域选择与裁剪链路；无效 Key 在网络调用前被拒绝，短超时使用本机未监听端口。所有区域均保留 <code>local_pdf</code> 来源。</p></details></section>'''


def main() -> None:
    root = Path(__file__).resolve().parents[2]
    output = root / "docs" / "reliability_acceptance_20260817" / "index.html"
    output.parent.mkdir(parents=True, exist_ok=True)
    sections = "".join(paper_section(root, paper) for paper in PAPERS) + hybrid_section(root)
    output.write_text(f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>本地解析可靠性验收包</title><style>:root{{color-scheme:dark}}body{{max-width:1720px;margin:auto;padding:24px;background:#090e1a;color:#e6edf7;font:15px Segoe UI,Arial,sans-serif;line-height:1.55}}h1,h2,h3{{color:#f8fbff}}.note,.meta{{margin:14px 0;padding:13px;background:#121d30;border:1px solid #304361;border-radius:7px}}.note{{border-left:4px solid #55b6ff}}.paper{{margin:34px 0;padding-top:12px;border-top:1px solid #38506f}}details{{margin:13px 0;background:#10192a;border:1px solid #304361;border-radius:6px}}summary{{padding:10px;cursor:pointer;color:#a9d7ff;font-weight:600}}pre{{max-height:430px;overflow:auto;white-space:pre-wrap;word-break:break-word;margin:0;padding:13px;background:#070b14;color:#d7e0ee;font:12px Consolas,monospace}}.timeline{{margin:0;padding:10px 30px;color:#c9d9eb;font:13px Consolas,monospace}}.card{{margin:18px 0;background:#111c2f;border:1px solid #354a68;border-radius:7px;overflow:hidden}}.card header{{display:flex;justify-content:space-between;align-items:center;padding:0 15px;border-bottom:1px solid #354a68}}.card header h3{{font-size:16px}}.card header span{{color:#9ecbff}}.grid{{display:grid;grid-template-columns:1.05fr 1fr .7fr;gap:14px;padding:15px}}img{{width:100%;background:white;border:1px solid #5c83af}}dl{{display:grid;grid-template-columns:110px 1fr;gap:4px 8px}}dt{{color:#aac4e2}}dd{{margin:0}}textarea,select{{box-sizing:border-box;width:100%;margin-top:5px;padding:8px;background:#070b14;color:#f2f7ff;border:1px solid #506988;border-radius:4px}}textarea{{height:100px}}label{{display:block;margin-top:12px}}button{{background:#1968b2;color:#fff;border:1px solid #65b9ff;border-radius:4px;padding:8px 12px;cursor:pointer}}.toolbar{{position:sticky;top:8px;background:#10192a;border:1px solid #304361;padding:10px;border-radius:7px;z-index:2}}@media(max-width:1050px){{.grid{{grid-template-columns:1fr}}}}</style><body><h1>本地解析可靠性验收包</h1><p>生成日期：2026-08-17。仅基于本次真实 <code>run_demo</code> 本地模式运行和原 PDF 本地渲染。</p><div class="toolbar"><button id="export">导出人工核验 JSON</button><span id="state">填写内容自动暂存于当前浏览器。</span></div><section class="note"><b>验收范围：</b>本包核验本地模式的块定位、双栏/阅读顺序、表格/公式/图形的风险边界，以及 Writer 是否将未获许可的内容写成确定事实。蓝框只是解析块，不等同于已验证表格、公式或图结构。全 Llama 不纳入本轮质量验收；混合模式另做 bbox/页码回指和故障降级测试。</section>{sections}<script>const K='sciassistant.reliability.acceptance.20260817';const cards=()=>[...document.querySelectorAll('[data-id]')].map(c=>({{id:c.dataset.id,decision:c.querySelector('[data-field=decision]').value,note:c.querySelector('[data-field=note]').value}}));function save(){{localStorage.setItem(K,JSON.stringify({{saved_at:new Date().toISOString(),reviews:cards()}}));document.querySelector('#state').textContent='已暂存 '+new Date().toLocaleTimeString()}}function restore(){{try{{const d=JSON.parse(localStorage.getItem(K)||'null');(d?.reviews||[]).forEach(x=>{{const c=document.querySelector('[data-id="'+x.id+'"]');if(c){{c.querySelector('[data-field=decision]').value=x.decision||'未核验';c.querySelector('[data-field=note]').value=x.note||''}}}})}}catch{{}}}}document.querySelectorAll('[data-field]').forEach(x=>x.addEventListener('input',save));document.querySelector('#export').onclick=()=>{{const b=new Blob([JSON.stringify({{format:'sciassistant_reliability_review/v1',exported_at:new Date().toISOString(),reviews:cards()}},null,2)],{{type:'application/json'}}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='LOCAL_RELIABILITY_REVIEW_20260817.json';a.click();URL.revokeObjectURL(a.href)}};restore()</script></body></html>''', encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()
