"""Generate a versioned offline review package for every PDF in a directory."""
from __future__ import annotations

import argparse
import html
import json
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from pdf_pipeline import parse_pdf  # noqa: E402
from deepdiver_v2.cli.generate_local_layout_review import build_html  # noqa: E402


def _write_index(output_dir: Path, entries: list[dict[str, object]], batch_id: str) -> Path:
    rows = "".join(
        f"<tr><td><a href=\"{html.escape(str(item['filename']))}\">{html.escape(str(item['paper_id']))}</a></td>"
        f"<td>{item['pages']}</td><td>{item['regions']}</td>"
        f"<td>{html.escape(json.dumps(item['region_counts'], ensure_ascii=False))}</td>"
        f"<td>{item['incomplete_visuals']}</td></tr>"
        for item in entries
    )
    total_pages = sum(int(item['pages']) for item in entries)
    total_regions = sum(int(item['regions']) for item in entries)
    index = output_dir / "index.html"
    index.write_text(
        f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>PDF 分块核验包 {html.escape(batch_id)}</title>
<style>:root{{color-scheme:dark}}body{{max-width:1100px;margin:0 auto;padding:28px;background:#10151f;color:#e5e7eb;font:16px "Segoe UI",Arial,sans-serif}}h1{{color:#f8fafc}}.meta{{background:#182230;border:1px solid #334155;border-radius:7px;padding:14px;line-height:1.7}}table{{width:100%;border-collapse:collapse;background:#182230;margin-top:18px}}th,td{{padding:12px;border:1px solid #334155;text-align:left;vertical-align:top}}th{{background:#1e293b}}a{{color:#93c5fd;font-weight:700}}code{{color:#bfdbfe}}.warning{{margin-top:16px;padding:12px;border-left:5px solid #f59e0b;background:#182230;color:#fde68a}}</style></head><body>
<h1>本地 PDF 分块与排序核验包</h1>
<div class="meta"><b>批次：</b><code>{html.escape(batch_id)}</code><br><b>论文：</b>{len(entries)} 篇；<b>页面：</b>{total_pages}；<b>区域：</b>{total_regions}<br>仅使用本地解析与几何分块。Llama 区域复核和整篇转写均为 disabled。每篇页面都有独立浏览器暂存键，可在各论文页面导出填写结果 JSON。</div>
<div class="warning">请从下表进入单篇核验页。红色虚线框代表未完整视觉候选，不应当作已确认的完整图表或表格证据。</div>
<table><thead><tr><th>论文</th><th>页数</th><th>区域数</th><th>区域类型统计</th><th>未完整视觉候选</th></tr></thead><tbody>{rows}</tbody></table>
</body></html>''',
        encoding="utf-8",
    )
    return index


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pdf_dir", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--batch-id", required=True)
    args = parser.parse_args()

    source_dir = args.pdf_dir.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=False)
    entries: list[dict[str, object]] = []
    for pdf_path in sorted(source_dir.glob("*.pdf")):
        parsed = parse_pdf(pdf_path, enable_ocr=True)
        if not parsed.get("success"):
            raise RuntimeError(f"Local PDF parsing failed: {pdf_path}")
        output = output_dir / f"pdf_chunks_{pdf_path.stem}_{args.batch_id}.html"
        report = build_html(pdf_path, parsed, output, review_key_suffix=args.batch_id)
        regions = report["chunks"]["regions"]
        counts = Counter(str(region["kind"]) for region in regions)
        entries.append({
            "paper_id": pdf_path.stem,
            "filename": output.name,
            "pages": int(parsed.get("page_count") or 0),
            "regions": len(regions),
            "region_counts": dict(sorted(counts.items())),
            "incomplete_visuals": sum(1 for region in regions if region["kind"] == "unresolved_visual" or not region.get("complete")),
        })
        print(json.dumps(entries[-1], ensure_ascii=False), flush=True)
    index = _write_index(output_dir, entries, args.batch_id)
    print(json.dumps({"output": str(index), "papers": len(entries), "pages": sum(int(item['pages']) for item in entries)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
