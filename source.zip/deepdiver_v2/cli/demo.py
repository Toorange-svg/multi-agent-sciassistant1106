# Copyright (c) 2025 Huawei Technologies Co., Ltd. All rights reserved.
#!/usr/bin/env python3
"""
CLI Demo for DeepDiver Long Writer Multi-Agent System

This demo showcases the multi-agent system that includes:
- PlannerAgent: Coordinates and orchestrates the entire process
- InformationSeekerAgent: Gathers and researches information  
- WriterAgent: Creates long-form content

Features:
- Loads configuration from config/.env file
- Shows real-time tool calls and reasoning traces
- Displays sub-agent responses and interactions
- Visualizes the complete execution flow
- Query preprocessing for safety and task suitability check
"""

import os
import sys
import json
import time
import logging
import argparse
import re
import requests
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Dict, Any, List, Optional
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.syntax import Syntax
from rich.markdown import Markdown

os.environ.setdefault("LITELLM_LOG", "ERROR")

# Windows can launch the module directly from a GBK console (without the
# wrapper's ``PYTHONIOENCODING`` setting). Rich/parser diagnostics contain
# symbols such as check marks, so make stdout/stderr lossless when possible.
for _stream in (sys.stdout, sys.stderr):
    try:
        if hasattr(_stream, "reconfigure"):
            _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

# Add project root to Python path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))
repo_root = project_root.parent
sys.path.insert(0, str(repo_root))


# Configure logging to keep the CLI clean
def setup_clean_logging(debug_mode: bool = False):
    """Configure logging to show only relevant information for the demo"""
    if debug_mode:
        # Debug mode: show all logs with timestamps
        logging.basicConfig(
            level=logging.DEBUG,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%H:%M:%S'
        )
    else:
        # Clean demo mode: suppress verbose logs
        
        # Suppress specific noisy loggers
        noisy_loggers = [
            'httpx',
            'httpcore', 
            'urllib3',
            'LiteLLM',
            'litellm',
            'src.tools.mcp_client',
            # 'src.agents.base_agent',
            'config.config'  # Also suppress config messages in quiet mode
        ]
        
        for logger_name in noisy_loggers:
            logging.getLogger(logger_name).setLevel(logging.ERROR)

# Set up default clean logging before any imports
setup_clean_logging(debug_mode=False)

# Import the multi-agent system components
from config.config import get_config, reload_config, temporary_pdf_parse_mode
from src.agents.planner_agent import create_planner_agent
from src.agents.base_agent import AgentResponse
from src.pdf_reliability import extract_explicit_arxiv_ids
from src.tools.mcp_tools import MCPTools
from src.arxiv_query import validate_arxiv_query
from src.literature_sources import (
    search_source,
    download_pdf as download_public_pdf,
    assess_evidence_sufficiency,
    citation_label,
    deduplicate,
    rerank_papers,
    source_skip_reason,
)
from src.tools.task_diagnostics import record as record_diagnostic, stage as diagnostic_stage
from src.model_key_pool import post_model_request
from src.query_router import (
    _marker_present,
    direct_query_profile,
    get_direct_cache,
    get_literature_cache,
    get_paper_evidence_cache,
    is_usable_answer,
    preferred_literature_source,
    put_direct_cache,
    put_literature_cache,
    put_paper_evidence_cache,
    build_science_evidence_notice,
    build_science_citation_report,
    build_literature_queries,
    build_literature_query_plan,
    build_problem_spec,
    build_followup_retrieval_query,
    build_adaptive_literature_queries,
    is_limitation_query,
    score_literature_relevance,
    infer_literature_relation,
    has_topic_anchor,
    MAX_QUERY_ROUTES,
    MAX_BROAD_QUERY_ROUTES,
    MAX_RETRIEVAL_ROUNDS,
    MAX_CANDIDATE_PAPERS,
    MAX_RESULTS_PER_SOURCE_CALL,
    RELEVANCE_THRESHOLD,
    get_relevance_threshold,
    set_relevance_threshold,
    MIN_CONCEPT_COVERAGE,
    route_query,
    requested_concepts,
    select_relevant_excerpt,
    verify_science_citations,
    is_obvious_short_query,
)
from src.report_export import export_report_files
from src.clarification_gate import apply_clarification_choice, build_clarification_request
from src.subquestions import decompose
from src.query_terms import extract_query_terms
from src.query_bridge import chinese_entity_fallback_queries
from src.query_terms import extract_query_terms

console = Console()
CONVERSATION_CONTEXT: dict = {"status": "none"}
MULTI_AGENT_WORKFLOW_RUN_ID: str | None = None


class DemoVisualizer:
    """Visualizes the execution of the multi-agent system"""
    
    def __init__(self, quiet_mode: bool = False):
        self.console = console
        self.execution_log = []
        self.quiet_mode = quiet_mode
        
    def _should_display(self, force: bool = False) -> bool:
        """Check if output should be displayed based on quiet mode"""
        return not self.quiet_mode or force
        
    def show_welcome(self):
        """Display welcome message and system info"""
        if not self._should_display():
            return
            
        welcome_text = """
# 🤖 DeepDiver Long Writer Multi-Agent System Demo

This demo showcases an advanced multi-agent system for research and long-form content generation.

## System Components:
- **🧠 PlannerAgent**: Orchestrates the entire process and coordinates sub-agents
- **🔍 InformationSeekerAgent**: Performs web research and gathers information
- **✍️  WriterAgent**: Creates comprehensive long-form content

## Features:
- Real-time tool execution visualization
- Sub-agent response tracking
- Complete reasoning trace display
- Configuration management
- Query safety and suitability pre-check
        """
        self.console.print(Panel(Markdown(welcome_text), title="[bold blue]Welcome", border_style="blue"))
    
    def show_config(self, config):
        """Display current configuration"""
        if not self._should_display():
            return
            
        config_table = Table(title="📋 System Configuration", show_header=True, header_style="bold magenta")
        config_table.add_column("Setting", style="cyan", no_wrap=True)
        config_table.add_column("Value", style="green")
        
        # Safe config display (hide sensitive values)
        safe_config = config.to_dict()
        for key, value in safe_config.items():
            if value is not None and str(value) != "None":
                key_lower = key.lower()
                is_sensitive = (
                    key_lower.endswith("_token")
                    or key_lower.endswith("_secret")
                    or key_lower.endswith("_password")
                    or "api_key" in key_lower
                    or "api_keys" in key_lower
                    or key_lower in {"token", "secret", "password", "auth"}
                )
                if is_sensitive:
                    display_value = "***" if str(value).strip() else ""
                else:
                    display_value = str(value)
                if len(display_value) > 60:
                    display_value = display_value[:57] + "..."
                config_table.add_row(key, display_value)
        
        self.console.print(config_table)
    
    def show_planner_start(self, query: str):
        """Show planner starting execution"""
        if not self._should_display():
            return
        self.console.print(Panel(
            f"[bold yellow]User Query:[/bold yellow] {query}\n\n"
            f"[bold green]🚀 Starting PlannerAgent execution...[/bold green]",
            title="[bold blue]Task Initiation",
            border_style="green"
        ))
    
    def show_reasoning_step(self, iteration: int, reasoning: str):
        """Display reasoning step"""
        if not self._should_display():
            return
        self.console.print(Panel(
            Markdown(f"**Iteration {iteration} - Reasoning:**\n\n{reasoning}"),
            title=f"[bold yellow]🧠 Agent Reasoning (Step {iteration})",
            border_style="yellow"
        ))
    
    def show_tool_call(self, iteration: int, tool_name: str, arguments: Dict[str, Any]):
        """Display tool call"""
        if not self._should_display():
            return
        args_json = json.dumps(arguments, indent=2, ensure_ascii=False)
        
        self.console.print(Panel(
            f"[bold cyan]Tool:[/bold cyan] {tool_name}\n\n"
            f"[bold cyan]Arguments:[/bold cyan]\n{Syntax(args_json, 'json', theme='monokai', line_numbers=True)}",
            title=f"[bold cyan]🔧 Tool Call (Step {iteration})",
            border_style="cyan"
        ))
    
    def show_tool_result(self, iteration: int, tool_name: str, result: Dict[str, Any]):
        """Display tool result"""
        if not self._should_display():
            return
        success = result.get("success", True)
        status_icon = "✅" if success else "❌"
        status_color = "green" if success else "red"
        
        # Format result for display
        if success and "data" in result:
            display_result = result["data"]
        elif "error" in result:
            display_result = {"error": result["error"]}
        else:
            display_result = result
        
        result_text = json.dumps(display_result, indent=2, ensure_ascii=False)
        if len(result_text) > 1000:
            result_text = result_text[:997] + "..."
        
        self.console.print(Panel(
            f"[bold {status_color}]Status:[/bold {status_color}] {status_icon} {'Success' if success else 'Failed'}\n\n"
            f"[bold {status_color}]Result:[/bold {status_color}]\n{Syntax(result_text, 'json', theme='monokai', line_numbers=True)}",
            title=f"[bold {status_color}]📋 Tool Result: {tool_name} (Step {iteration})",
            border_style=status_color
        ))
    
    def show_sub_agent_execution(self, agent_name: str, task_content: str):
        """Show sub-agent starting execution"""
        if not self._should_display():
            return
        self.console.print(Panel(
            f"[bold magenta]Agent:[/bold magenta] {agent_name}\n\n"
            f"[bold magenta]Task:[/bold magenta] {task_content[:500]}{'...' if len(task_content) > 500 else ''}",
            title="[bold magenta]🤝 Sub-Agent Execution",
            border_style="magenta"
        ))
    
    def show_sub_agent_result(self, agent_name: str, result: Dict[str, Any]):
        """Show sub-agent execution result"""
        if not self._should_display():
            return
        success = result.get("success", True)
        status_icon = "✅" if success else "❌"
        status_color = "green" if success else "red"
        
        # Extract key information
        iterations = result.get("iterations", 0)
        execution_time = result.get("execution_time", 0)
        
        summary = f"[bold {status_color}]Status:[/bold {status_color}] {status_icon} {'Success' if success else 'Failed'}\n"
        summary += f"[bold blue]Iterations:[/bold blue] {iterations}\n"
        summary += f"[bold blue]Execution Time:[/bold blue] {execution_time:.2f}s\n\n"
        
        if success and "data" in result:
            data = result["data"]
            if isinstance(data, dict):
                for key, value in data.items():
                    if isinstance(value, str) and len(value) > 200:
                        summary += f"[bold blue]{key}:[/bold blue] {value[:197]}...\n"
                    else:
                        summary += f"[bold blue]{key}:[/bold blue] {value}\n"
        elif "error" in result:
            summary += f"[bold red]Error:[/bold red] {result['error']}\n"
        
        self.console.print(Panel(
            summary,
            title=f"[bold {status_color}]📊 Sub-Agent Result: {agent_name}",
            border_style=status_color
        ))
    
    def show_final_result(self, response: AgentResponse):
        """Display final execution result"""
        # Always show final results, even in quiet mode
        if not self._should_display(force=True):
            return

        if self.quiet_mode:
            print("Final Status:", "Completed Successfully" if response.success else "Failed")
            print("Total Iterations:", response.iterations)
            # Retrieval rounds are a different counter from workflow
            # iterations: one workflow can sweep several sources over several
            # rounds. Printing both keeps the log from implying a single
            # attempt when five rounds actually ran.
            search_rounds = _search_rounds_of(response)
            if search_rounds is not None:
                print("Search Rounds:", search_rounds)
            print("Total Execution Time:", f"{response.execution_time:.2f}s")
            print("Agent:", response.agent_name)
            # Failed responses carry their explanation in final_answer too
            # (e.g. the evidence-sufficiency refusal). Printing it here is what
            # lets the Web layer extract a real reason instead of a bare
            # "Final Status: Failed" with no report body.
            if response.result:
                if isinstance(response.result, dict):
                    final_answer = response.result.get("final_answer")
                    if final_answer:
                        print("\nFinal Answer:")
                        print(final_answer)
                    else:
                        print("\nResult:")
                        print(json.dumps(response.result, ensure_ascii=False, indent=2))
                else:
                    print("\nResult:")
                    print(response.result)
            elif response.error:
                print("Error:", response.error)
            return
            
        success = response.success
        status_icon = "✅" if success else "❌"
        status_color = "green" if success else "red"
        
        summary = f"[bold {status_color}]Final Status:[/bold {status_color}] {status_icon} {'Completed Successfully' if success else 'Failed'}\n"
        summary += f"[bold blue]Total Iterations:[/bold blue] {response.iterations}\n"
        search_rounds = _search_rounds_of(response)
        if search_rounds is not None:
            summary += f"[bold blue]Search Rounds:[/bold blue] {search_rounds}\n"
        summary += f"[bold blue]Total Execution Time:[/bold blue] {response.execution_time:.2f}s\n"
        summary += f"[bold blue]Agent:[/bold blue] {response.agent_name}\n\n"
        
        if success and response.result:
            if isinstance(response.result, dict):
                for key, value in response.result.items():
                    if key == "final_answer":
                        summary += f"[bold blue]{key}:[/bold blue] {value}\n\n"
                    elif isinstance(value, str) and len(value) > 12000:
                        summary += f"[bold blue]{key}:[/bold blue] {value[:11997]}...\n\n"
                    else:
                        summary += f"[bold blue]{key}:[/bold blue] {value}\n\n"
        elif response.error:
            summary += f"[bold red]Error:[/bold red] {response.error}\n"
        
        self.console.print(Panel(
            summary,
            title=f"[bold {status_color}]🏁 Final Result",
            border_style=status_color
        ))
    
    def show_reasoning_trace(self, trace: List[Dict[str, Any]]):
        """Display detailed reasoning trace"""
        if not self._should_display():
            return
        if not trace:
            return
        
        trace_table = Table(title="🔍 Detailed Execution Trace", show_header=True, header_style="bold cyan")
        trace_table.add_column("Step", style="cyan", width=8)
        trace_table.add_column("Type", style="magenta", width=12)
        trace_table.add_column("Details", style="white")
        
        for i, step in enumerate(trace, 1):
            step_type = step.get("type", "unknown")
            
            if step_type == "reasoning":
                content = step.get("content", "")[:100] + ("..." if len(step.get("content", "")) > 100 else "")
                trace_table.add_row(str(i), "🧠 Reasoning", content)
            
            elif step_type == "action":
                tool = step.get("tool", "")
                result_status = "✅" if step.get("result", {}).get("success", True) else "❌"
                trace_table.add_row(str(i), "🔧 Tool Call", f"{result_status} {tool}")
            
            elif step_type == "error":
                error = step.get("error", "")[:100] + ("..." if len(step.get("error", "")) > 100 else "")
                trace_table.add_row(str(i), "❌ Error", error)
        
        self.console.print(trace_table)

    def show_unsupported_response(self):
        """Display the fixed response for unsupported queries"""
        # Always show this response, even in quiet mode
        if self.quiet_mode:
            print("Sorry, your question is not within the current scope of tasks for DeepDiver-V2.")
            return
        self.console.print(Panel(
            "Sorry, your question is not within the current scope of tasks for DeepDiver-V2. Please try asking a question related to long-form writing or complex knowledge Q&A instead.",
            title="[bold yellow]❌ Unsupported Query",
            border_style="yellow"
        ))


class AgentExecutionMonitor:
    """Monitors agent execution and provides real-time feedback"""
    
    def __init__(self, visualizer: DemoVisualizer):
        self.visualizer = visualizer
        self.current_iteration = 0
    
    def on_reasoning_step(self, iteration: int, reasoning: str):
        """Called when agent performs reasoning"""
        self.visualizer.show_reasoning_step(iteration, reasoning)
    
    def on_tool_call(self, iteration: int, tool_name: str, arguments: Dict[str, Any]):
        """Called when agent makes a tool call"""
        self.visualizer.show_tool_call(iteration, tool_name, arguments)
        
        # Check for sub-agent assignments
        if "assign_" in tool_name and "task" in tool_name:
            if "tasks" in arguments:
                for task in arguments.get("tasks", []):
                    task_content = task.get("task_content", "")
                    self.visualizer.show_sub_agent_execution("InformationSeeker", task_content)
            elif "task_content" in arguments:
                task_content = arguments.get("task_content", "")
                self.visualizer.show_sub_agent_execution("Writer", task_content)
    
    def on_tool_result(self, iteration: int, tool_name: str, result: Dict[str, Any]):
        """Called when tool execution completes"""
        self.visualizer.show_tool_result(iteration, tool_name, result)
        
        # Show sub-agent results if this was an assignment
        if "assign_" in tool_name and "task" in tool_name:
            if "data" in result and "tasks" in result["data"]:
                for task_result in result["data"]["tasks"]:
                    agent_name = task_result.get("agent_name", "InformationSeeker")
                    self.visualizer.show_sub_agent_result(agent_name, task_result)
            elif "data" in result:
                agent_name = result["data"].get("agent_name", "Writer")
                self.visualizer.show_sub_agent_result(agent_name, result["data"])


def classify_query(query: str, config, quiet: bool = False) -> Dict[str, Any]:
    """
    Classify a user query before running the full agent loop.

    Categories:
    - SAFE_SENSITIVE: unsafe or disallowed content.
    - NON_KNOWLEDGE: greetings, simple chat, or simple calculations.
    - NORMAL: research, paper search, analysis, or writing tasks.

    The classifier is intentionally conservative. If anything fails, the demo
    falls back to NORMAL so the user can still test the assistant.
    """
    logger = logging.getLogger(__name__)
    model_config = config.get_custom_llm_config()
    model_url = os.getenv("MODEL_REQUEST_URL") or model_config.get("url", "")
    model_token = os.getenv("MODEL_REQUEST_TOKEN") or model_config.get("token", "")
    model_name = config.model_name

    if not model_url:
        logger.warning("Model URL not configured; skipping query classification")
        return {"category": "NORMAL", "reasoning": "Model URL is not configured; defaulting to NORMAL."}

    headers = {"Content-Type": "application/json"}
    if model_token:
        headers["Authorization"] = f"Bearer {model_token}"
        headers["csb-token"] = model_token

    prompt = f"""
你是科研多智能体助手的任务分类器。请把用户问题分成三类之一：

1. SAFE_SENSITIVE：违法、暴力、色情、仇恨、辱骂、明显政治敏感或其它不适合处理的内容。
2. NON_KNOWLEDGE：寒暄、闲聊、简单计算、退出/帮助等不需要检索和多智能体处理的问题。
3. NORMAL：科研检索、arXiv论文查询、论文总结、资料分析、长文写作、复杂知识问答。

只允许输出两行：
第一行：一句简短分类理由。
第二行：SAFE_SENSITIVE、NON_KNOWLEDGE 或 NORMAL。

用户问题：{query}
""".strip()

    payload = {
        "model": model_name,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.1,
        "max_tokens": 300,
    }

    for attempt in range(1, 4):
        try:
            if not quiet:
                console.print(f"[cyan]API check {attempt}/3:[/cyan] {model_url}")
                console.print(f"[cyan]Classifier model:[/cyan] {model_name}")
            response = post_model_request(
                url=model_url,
                headers=headers,
                json=payload,
                timeout=model_config.get("timeout", 60),
            )
            if not quiet:
                console.print(f"[cyan]API status:[/cyan] {response.status_code}")
            response.raise_for_status()
            data = response.json()
            if isinstance(data, str):
                data = json.loads(data)
            if not quiet:
                console.print(f"[cyan]API response type:[/cyan] {type(data).__name__}")
            content = data["choices"][0]["message"]["content"].strip()
            lines = [line.strip() for line in content.splitlines() if line.strip()]
            if not lines:
                raise ValueError("Classifier returned empty content")

            category = lines[-1].upper()
            if category not in {"SAFE_SENSITIVE", "NON_KNOWLEDGE", "NORMAL"}:
                category = "NORMAL"
            reasoning = lines[0] if len(lines) > 1 else "Classifier completed."
            if not quiet:
                console.print(f"[cyan]Query category:[/cyan] {category}")
            return {"category": category, "reasoning": reasoning}
        except Exception as exc:
            logger.warning("Query classification attempt %s failed: %s", attempt, exc)
            if attempt < 3:
                time.sleep(1)

    return {"category": "NORMAL", "reasoning": "Classifier unavailable; defaulting to NORMAL."}


def looks_like_daily_arxiv_query(query: str) -> bool:
    lowered = query.lower()
    arxiv_markers = ["arxiv", "latest paper", "latest papers", "最新论文", "最新的论文", "论文"]
    daily_markers = ["latest", "recent", "today", "daily", "最新", "今天", "最近"]
    return any(marker in lowered for marker in arxiv_markers) and any(marker in lowered for marker in daily_markers)


def extract_arxiv_topic(query: str) -> str:
    """Extract a display/search topic from the user's wording only.

    This legacy summary route must not maintain a topic catalog. The main
    literature path uses the structured planner; this helper only trims
    common request framing for callers that still use the older endpoint.
    """
    for marker in ["关于", "方向", "about", "on"]:
        if marker in query:
            topic = query.split(marker, 1)[1]
            for tail in ["的最新", "最新", "论文", "papers", "and summarize"]:
                topic = topic.replace(tail, " ")
            topic = " ".join(topic.split()).strip("。,.，")
            if topic:
                return topic
    return " ".join(str(query or "").split()).strip()


def summarize_arxiv_papers(topic: str, papers: List[Dict[str, Any]], config) -> str:
    if not papers:
        return "No papers found."

    model_config = config.get_custom_llm_config()
    model_url = os.getenv("MODEL_REQUEST_URL") or model_config.get("url", "")
    model_token = os.getenv("MODEL_REQUEST_TOKEN") or model_config.get("token", "")
    if not model_url:
        return ""

    headers = {"Content-Type": "application/json"}
    if model_token:
        headers["Authorization"] = f"Bearer {model_token}"
        headers["csb-token"] = model_token

    paper_chunks = []
    for index, paper in enumerate(papers, 1):
        paper_chunks.append(
            f"{index}. Title: {paper.get('title', '')}\n"
            f"Authors: {paper.get('authors', '')}\n"
            f"Published: {paper.get('published_date', '')}\n"
            f"Link: {paper.get('url', '')}\n"
            f"Abstract: {paper.get('abstract', '')[:1200]}"
        )

    prompt = (
        f"Research topic: {topic}\n\n"
        "The following items are recent arXiv papers. Please answer in Chinese and include:\n"
        "1. Overall trends, 3-5 bullet points, citing paper numbers like [1], [2];\n"
        "2. A separate contribution paragraph for each paper, each with a citation marker;\n"
        "3. The paper most worth reading in a group meeting and why, with citation markers.\n"
        "Do not omit papers because of length; if space is tight, compress wording but keep all five papers covered.\n\n"
        + "\n\n".join(paper_chunks)
    )

    payload = {
        "model": config.model_name,
        "messages": [
            {
                "role": "system",
                "content": "You are a research paper assistant. Answer in Chinese. Use inline citation markers such as [1] and [2] for every claim tied to a paper. Format: put the citation number as a plain [n] in the text, and list all cited papers at the end as: [n] Paper Title, URL, Date. Do not invent information not supported by the provided paper metadata.",
            },
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.1,
        "max_tokens": int(os.getenv("ARXIV_SUMMARY_MAX_TOKENS", model_config.get("max_tokens", 8192) or 8192)),
        "thinking": {"type": "disabled"}, "enable_thinking": False, "reasoning_effort": "none",
    }

    try:
        response = post_model_request(model_url, headers=headers, json=payload, timeout=model_config.get("timeout", 60))
        response.raise_for_status()
        data = response.json()
        if isinstance(data, str):
            data = json.loads(data)
        return data["choices"][0]["message"]["content"].strip()
    except Exception:
        return ""


def format_arxiv_report(topic: str, papers: List[Dict[str, Any]], summary: str) -> str:
    lines = [f"# Daily arXiv Papers: {topic}", ""]
    if summary:
        lines.extend(["## Assistant Summary", summary, ""])
    if not papers:
        lines.append("No papers found.")
        return "\n".join(lines)

    lines.append("## Latest Papers")
    for index, paper in enumerate(papers, 1):
        authors = paper.get("authors", "")
        abstract = (paper.get("abstract", "") or "").replace("\n", " ").strip()
        lines.extend(
            [
                f"### {index}. {paper.get('title', '')}",
                f"- Citation: [{index}]",
                f"- arXiv ID: {paper.get('paper_id', '')}",
                f"- Published: {paper.get('published_date', '')[:10]}",
                f"- Authors: {authors}",
                f"- Link: {paper.get('url', '')}",
                f"- Abstract: {abstract} [{index}]",
                "",
            ]
        )
    lines.append("## References")
    for index, paper in enumerate(papers, 1):
        lines.append(f"[{index}] {paper.get('title', '')}. arXiv:{paper.get('paper_id', '')}. {paper.get('url', '')}")
    return "\n".join(lines).strip()


def run_daily_arxiv_query(query: str, config, visualizer: DemoVisualizer) -> AgentResponse:
    start_time = time.time()
    topic = extract_arxiv_topic(query)
    try:
        tools = MCPTools()
        result = tools.arxiv_search(topic, max_results=5)
        if not result.success:
            raise RuntimeError(result.error or "arxiv_search failed")
        papers = result.data.get("papers", []) if isinstance(result.data, dict) else []
        summary = summarize_arxiv_papers(topic, papers, config)
        report = format_arxiv_report(topic, papers, summary)
        response = AgentResponse(
            success=True,
            result={
                "task_name": "daily_arxiv_papers",
                "completion_status": "completed",
                "final_answer": report,
            },
            iterations=1,
            execution_time=time.time() - start_time,
            agent_name="DailyArxivAssistant",
        )
        visualizer.show_final_result(response)
        return response
    except Exception as exc:
        response = AgentResponse(
            success=False,
            error=f"Daily arXiv query failed: {exc}",
            iterations=1,
            execution_time=time.time() - start_time,
            agent_name="DailyArxivAssistant",
        )
        visualizer.show_final_result(response)
        return response


def should_answer_directly(query: str, category: str) -> bool:
    lowered = query.lower()
    research_markers = [
        "rag",
        "retrieval augmented generation",
        "arxiv",
        "论文",
        "paper",
        "llm",
        "大模型",
        "检索增强",
        "引用",
        "参考文献",
        "source",
        "citation",
    ]
    # A classifier can occasionally label a technical request NON_KNOWLEDGE.
    # Explicit paper/PDF requests must still go through Planner + MCP, never
    # the no-tool DirectLLM route.
    if any(_marker_present(lowered, marker) for marker in research_markers):
        return False
    direct_markers = [
        "introduce",
        "briefly",
        "what can you do",
        "system architecture",
        "project plan",
        "presentation outline",
        "介绍",
        "简短",
        "你能做什么",
        "系统架构",
        "项目方案",
        "开发计划",
        "汇报大纲",
        "等于多少",
    ]
    return (
        category == "NON_KNOWLEDGE"
        and not any(_marker_present(lowered, marker) for marker in research_markers)
    ) or any(_marker_present(lowered, marker) for marker in direct_markers)


def is_explicit_paper_request(query: str) -> bool:
    """Detect paper-bound requests before the optional LLM classifier."""
    lowered = query.lower()
    return bool(re.search(r"(?:arxiv\s*:\s*)?\d{4}\.\d{4,5}(?:v\d+)?", lowered)) or any(
        marker in lowered for marker in ("arxiv:", "arxiv.org/", "指定论文", "论文全文", "pdf全文")
    )


def _has_followup_context() -> bool:
    """Return whether a validated parent task supplied bounded context."""
    return CONVERSATION_CONTEXT.get("status") == "ready"


def _followup_context_for_retrieval() -> str:
    """Expose topic clues without treating a prior answer as new evidence."""
    if not _has_followup_context():
        return ""
    previous_intent = CONVERSATION_CONTEXT.get("previous_intent") or {}
    return (
        f"上一轮问题：{str(CONVERSATION_CONTEXT.get('previous_query') or '')[:1200]}\n"
        f"上一轮意图：{json.dumps(previous_intent, ensure_ascii=False)[:1600]}\n"
        f"上一轮论文 ID：{', '.join(CONVERSATION_CONTEXT.get('paper_ids') or []) or '未识别'}\n"
        f"上一轮回答摘要（仅作主题线索，不是本轮证据）："
        f"{str(CONVERSATION_CONTEXT.get('previous_answer') or '')[:3000]}"
    )


# A follow-up only needs the parent topic merged into its retrieval text when
# it is referential (pronouns / deictic words such as 它, 上述, 刚才, this,
# the above). A self-contained follow-up ("RAG 的检索器和生成器分别做什么？")
# must be planned from its own topic alone; merging the previous round's text
# lets the old vocabulary (e.g. LoRA/QLoRA from an earlier question) pollute
# the new query plan and the subquestion split.
_FOLLOWUP_REFERENTIAL_RE = re.compile(
    r"(?:刚才|上面|上述|前述|前者|后者|它|其(?:中|一)?|"
    r"那(?:个|些|篇|份|种)?|这(?:个|些|篇|份|种)?|"
    r"\b(?:the\s+above|above|former|latter|it|this|that|these|those)\b)",
    re.I,
)


def _merge_followup_query_for_retrieval(query: str) -> str:
    """Give rankers enough referents for terse follow-up questions.

    The merged text is used only for retrieval planning and candidate judging.
    It never enters the evidence ledger as if it were a newly verified source.
    Only referential turns get the parent question merged in; self-contained
    follow-ups keep their own wording so the planner cannot leak the previous
    topic into the new plan.
    """
    if not _has_followup_context():
        return query
    if not re.search(_FOLLOWUP_REFERENTIAL_RE, str(query or "")):
        return query
    return build_followup_retrieval_query(
        query,
        str(CONVERSATION_CONTEXT.get("previous_query") or ""),
        CONVERSATION_CONTEXT.get("previous_intent") or {},
    )


def _followup_writer_context() -> str:
    """Build a compact, explicitly non-evidentiary prompt block for answer models."""
    context = _followup_context_for_retrieval()
    if not context:
        return ""
    return (
        "\n\n这是同一会话中的后续问题。请结合以下上一轮主题理解代词、省略对象和“刚才”之类指代；"
        "但不要把上一轮回答或论文编号伪装成本轮新检索证据。\n"
        + context
    )


def _decide_followup_evidence_need(query: str) -> tuple[str, dict]:
    """Classify whether a follow-up needs fresh literature retrieval.

    The model receives only bounded conversation metadata and must return one
    enum value. This is deliberately a decision layer, not a topic vocabulary
    or paper map; an invalid/unavailable response falls back conservatively.
    """
    if not _has_followup_context():
        return "search_required", {"status": "not_followup", "decision": "search_required"}
    previous = str(CONVERSATION_CONTEXT.get("previous_query") or "")[:1200]
    current = str(query or "")[:1600]
    inherited = CONVERSATION_CONTEXT.get("paper_ids") or []
    if not inherited:
        return "search_required", {"status": "no_inherited_evidence", "decision": "search_required"}
    model_config = get_config().get_custom_llm_config() if 'get_config' in globals() else {}
    model_url = os.getenv("MODEL_REQUEST_URL") or model_config.get("url", "")
    token = os.getenv("MODEL_REQUEST_TOKEN") or model_config.get("token", "")
    if model_url:
        prompt = (
            "Classify this scientific follow-up's evidence need. Return JSON only: "
            '{"decision":"reuse_only|reuse_and_search|search_required","reason":"short"}. '
            "reuse_only means the prior verified papers can answer after re-reading; "
            "reuse_and_search means re-check prior papers and add fresh searches; "
            "search_required means the question introduces a new object, comparison, evidence type, "
            "latest claim, experiment, or mechanism not covered by the prior topic. Never return markdown.\n"
            f"Previous question: {previous}\nCurrent follow-up: {current}\n"
            f"Prior paper IDs: {', '.join(map(str, inherited[:10])) or 'none'}"
        )
        try:
            headers = {"Content-Type": "application/json"}
            if token:
                headers.update({"Authorization": f"Bearer {token}", "csb-token": token})
            response = post_model_request(
                model_url, headers=headers,
                json={"model": get_config().model_name, "messages": [{"role": "user", "content": prompt}],
                      "temperature": 0.0, "max_tokens": 120},
                timeout=min(int(model_config.get("timeout", 60) or 60), 20),
            )
            response.raise_for_status()
            raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", _extract_llm_text(response.json()).strip(), flags=re.I)
            data = json.loads(raw)
            decision = str(data.get("decision", "")).strip().lower()
            if decision in {"reuse_only", "reuse_and_search", "search_required"}:
                return decision, {"status": "model", "decision": decision, "reason": str(data.get("reason", ""))[:240]}
        except Exception as exc:
            logging.getLogger(__name__).info("Follow-up evidence decision fallback: %s", exc)
    # Conservative structural fallback. It does not name topics or papers.
    # A follow-up that stands on its own topic must not be demoted to
    # "reuse prior evidence only" just because the classifier is unavailable:
    # fresh multi-source retrieval is the safe default, and a missed search is
    # worse than one bounded extra round. Only a referential continuation
    # (pronouns, 上面, 刚才, this, the above, ...) gets reuse-first treatment,
    # and even then fresh searches still run alongside the inherited papers.
    referential = bool(re.search(_FOLLOWUP_REFERENTIAL_RE, current))
    decision = "reuse_and_search" if referential else "search_required"
    return decision, {"status": "fallback", "decision": decision, "reason": "model_unavailable_or_invalid"}


def _dynamic_query_phrases(query: str) -> list[str]:
    """English terminology extracted from the question; see query_terms.

    Kept as an alias because the retrieval trace reports the same list under
    this name. Chinese terminology never flows through here: it is translation
    input for the LLM planner (``extract_query_terms(query)["chinese"]``) and
    is dropped entirely when the planner is unavailable, instead of sending
    Chinese prose to arXiv.
    """
    return extract_query_terms(query)["english"]


def run_direct_llm_query(query: str, config, visualizer: DemoVisualizer) -> AgentResponse:
    start_time = time.time()
    model_config = config.get_custom_llm_config()
    model_url = os.getenv("MODEL_REQUEST_URL") or model_config.get("url", "")
    model_token = os.getenv("MODEL_REQUEST_TOKEN") or model_config.get("token", "")
    model_name = config.model_name
    profile = direct_query_profile(query)
    # A cached standalone answer may omit the parent topic, so follow-ups
    # always go to the model with their bounded conversation context.
    cached_answer = None if _has_followup_context() else get_direct_cache(query, model_name)
    if cached_answer:
        response = AgentResponse(
            success=True,
            result={
                "task_name": "direct_llm_answer",
                "completion_status": "completed",
                "final_answer": cached_answer,
                "route": "direct_llm",
                "evidence_mode": "general_knowledge",
                "cache_hit": True,
                "response_style": profile["style"],
            },
            iterations=0,
            execution_time=time.time() - start_time,
            agent_name="DirectLLMAssistant",
        )
        visualizer.show_final_result(response)
        return response

    if not model_url:
        response = AgentResponse(
            success=False,
            error="MODEL_REQUEST_URL is not configured.",
            iterations=1,
            execution_time=time.time() - start_time,
            agent_name="DirectLLMAssistant",
        )
        visualizer.show_final_result(response)
        return response

    headers = {"Content-Type": "application/json"}
    if model_token:
        headers["Authorization"] = f"Bearer {model_token}"
        headers["csb-token"] = model_token

    payload = {
        "model": model_name,
        "messages": [
            {
                "role": "system",
                "content": (
                    "你是 SciAssistant 的通用问答助手。只回答用户当前问题，不调用工具，不伪造检索、论文或引用。"
                    "本轮未进行实时检索；涉及最新事实、精确数据或来源时，明确说需要检索。"
                    "不确定时直接说明无法确认，不要用看似具体的内容补全空白。"
                    f"回答风格：{profile['style']}。先给结论，再给必要解释；避免重复题目和空泛套话。"
                ),
            },
            {"role": "user", "content": query.strip() + _followup_writer_context()},
        ],
        "temperature": 0.2,
        "max_tokens": int(profile["max_tokens"]),
        "thinking": {"type": "disabled"}, "enable_thinking": False, "reasoning_effort": "none",
    }

    try:
        answer = ""
        last_error = None
        for attempt in range(3):
            try:
                result = post_model_request(model_url, headers=headers, json=payload,
                                       timeout=min(int(model_config.get("timeout", 60) or 60), 45))
                result.raise_for_status()
                data = result.json()
                if isinstance(data, str):
                    data = json.loads(data)
                answer = _extract_llm_text(data)
                if not is_usable_answer(answer):
                    raise ValueError("模型返回空内容或接口内部片段，未将其视为有效回答")
                break
            except Exception as exc:
                last_error = exc
                if attempt < 2:
                    time.sleep(1.5 * (attempt + 1))
        if not answer:
            raise last_error or RuntimeError("模型未返回有效正文")
        if not _has_followup_context():
            put_direct_cache(query, model_name, answer)
        response = AgentResponse(
            success=True,
            result={
                "task_name": "direct_llm_answer",
                "completion_status": "completed",
                "final_answer": answer,
                "route": "direct_llm",
                "evidence_mode": "general_knowledge",
                "cache_hit": False,
                "response_style": profile["style"],
            },
            iterations=1,
            execution_time=time.time() - start_time,
            agent_name="DirectLLMAssistant",
        )
    except Exception as exc:
        response = AgentResponse(success=True, error=f"Direct LLM query unavailable after 3 retries: {exc}", result={
            "task_name": "direct_llm_answer", "completion_status": "partial",
            "final_answer": "回答模型暂时不可用（已重试 3 次）。以下不使用虚构来源，仅说明当前无法生成可靠的通用回答。",
            "route": "direct_llm", "evidence_mode": "general_knowledge", "model_unavailable": True,
        }, iterations=1, execution_time=time.time() - start_time, agent_name="DirectLLMAssistant")

    visualizer.show_final_result(response)
    return response


def _repair_keyword_json(content: str) -> dict | None:
    """Recover a truncated keyword object without inventing query terms.

    This is intentionally narrow: it only accepts quoted string values that
    appear inside a ``keywords`` array. It never turns arbitrary prose into a
    search term and returns ``None`` when no usable keyword is recoverable.
    """
    text = str(content or "").strip()
    match = re.search(r'"keywords"\s*:\s*\[([\s\S]*)', text, flags=re.I)
    if not match:
        return None
    values = []
    # Match complete JSON strings, including escaped quotes. A final
    # unterminated string is deliberately ignored rather than guessed.
    for item in re.findall(r'"((?:\\.|[^"\\])*)"', match.group(1)):
        try:
            value = json.loads('"' + item + '"')
        except json.JSONDecodeError:
            continue
        if isinstance(value, str) and value.strip():
            value = " ".join(value.split()).strip()
            if value.lower() not in {x.lower() for x in values}:
                values.append(value)
    return {"keywords": values} if values else None


# Global: stores the LLM-planned groups for the current query, used by
# the group-based scoring layer wrapped around score_literature_relevance.
CURRENT_QUERY_GROUPS: list[dict] = []


def _score_by_groups(paper: dict) -> dict | None:
    """Group-based scoring with Plan B refined.

    Plan B refined:
    - Generic dimension terms (lightweight LLM, deep learning, etc.) do NOT
      count as a "support hit" when searched alone, because they produce noisy
      candidates. Only concrete support terms or core terms count.
    - Concrete support hit alone = 0.6 (passes threshold 0.6)
    - Core hit alone = 0.5 (does NOT pass alone; needs a concrete support hit)
    - Core + concrete support both hit = 0.8
    - Generic support hit adds small bonus but cannot pass by itself
    """
    if not CURRENT_QUERY_GROUPS:
        return None
    title = str(paper.get("title", "") or "").lower()
    abstract = str(paper.get("abstract", "") or "").lower()
    haystack = f"{title} {abstract}"

    import re as _re
    _STOP_WORDS = {"the", "a", "an", "of", "in", "on", "for", "and", "or", "to", "with", "by", "from", "is", "are", "was", "were", "be", "been", "being", "have", "has", "had", "do", "does", "did", "will", "would", "could", "should", "may", "might", "can", "shall", "not", "no", "nor", "so", "yet", "both", "each", "few", "more", "most", "other", "some", "such", "than", "too", "very", "just", "about", "above", "after", "again", "against", "all", "am", "any", "because", "before", "between", "but", "down", "during", "further", "he", "her", "here", "hers", "herself", "him", "himself", "his", "how", "i", "if", "into", "it", "its", "itself", "me", "my", "myself", "only", "own", "same", "she", "their", "theirs", "them", "themselves", "then", "there", "these", "they", "this", "those", "through", "under", "until", "up", "very", "was", "we", "what", "when", "where", "which", "while", "who", "whom", "why", "you", "your", "yours", "yourself", "yourselves"}
    def _hit(phrase: str) -> bool:
        """Match if all content words in the phrase appear in haystack.
        Handles word-form variation (prompting vs prompts) and hyphen
        variation (tool-use vs tool use) without exact phrase match."""
        phrase_lower = phrase.lower().strip()
        if not phrase_lower:
            return False
        words = _re.findall(r'[a-z0-9]+', phrase_lower)
        content_words = [w for w in words if w not in _STOP_WORDS and len(w) > 1]
        if not content_words:
            return False
        # Short phrases (1-2 words): exact match, also try without hyphens
        if len(content_words) <= 2:
            pattern = r'\b' + _re.escape(phrase_lower) + r'\b'
            if _re.search(pattern, haystack):
                return True
            no_hyphen = phrase_lower.replace("-", " ")
            pattern2 = r'\b' + _re.escape(no_hyphen) + r'\b'
            if _re.search(pattern2, haystack):
                return True
            return False
        # Longer phrases: all content words must appear (word-boundary), order-independent.
        # Use prefix matching only for words longer than 6 chars (prefix length 6)
        # to handle inflection (prompting matches prompt/prompts) without false
        # positives (light should not match lightweight).
        for w in content_words:
            if len(w) > 6:
                stem = w[:6]
                pattern = r'\b' + _re.escape(stem)
                if not _re.search(pattern, haystack):
                    return False
            else:
                pattern = r'\b' + _re.escape(w) + r'\b'
                if not _re.search(pattern, haystack):
                    return False
        return True

    def _match_text(phrase: str, text: str) -> bool:
        phrase_lower = phrase.lower().strip()
        if not phrase_lower:
            return False
        words = _re.findall(r'[a-z0-9]+', phrase_lower)
        content_words = [w for w in words if w not in _STOP_WORDS and len(w) > 1]
        if not content_words:
            return False
        if len(content_words) <= 2:
            if _re.search(r'\b' + _re.escape(phrase_lower) + r'\b', text):
                return True
            no_hyphen = phrase_lower.replace("-", " ")
            if _re.search(r'\b' + _re.escape(no_hyphen) + r'\b', text):
                return True
            return False
        for w in content_words:
            if len(w) > 6:
                if not _re.search(r'\b' + _re.escape(w[:6]), text):
                    return False
            else:
                if not _re.search(r'\b' + _re.escape(w) + r'\b', text):
                    return False
        return True

    group_scores = []
    core_hits = []
    title_core_hits = []
    for g in CURRENT_QUERY_GROUPS:
        core = g.get("core", "").lower()
        support_items = g.get("support", []) or []
        # Support may be list of strings (old format) or list of dicts (new format)
        concrete_support = []
        generic_support = []
        for s in support_items:
            if isinstance(s, dict):
                term = str(s.get("term", "")).lower()
                if s.get("is_generic"):
                    generic_support.append(term)
                else:
                    concrete_support.append(term)
            elif s:
                concrete_support.append(str(s).lower())

        core_hit = _hit(core) if core else False
        concrete_support_hits = sum(1 for s in concrete_support if _hit(s))
        generic_support_hits = sum(1 for s in generic_support if _hit(s))
        has_concrete_support = concrete_support_hits > 0
        has_any_support = has_concrete_support or generic_support_hits > 0

        # If group has only core (synonym group): any hit = full score
        if not support_items:
            total = 1.0 if core_hit else 0.0
        # Plan B refined:
        # - Generic support hits alone (e.g. "lightweight LLM") do NOT pass (0.3)
        # - Core hit alone passes (core is concrete entity): 0.7
        # - Concrete support hit alone passes: 0.6
        # - Core + concrete support both hit: 1.0
        # - Generic support hit adds small 0.05 bonus
        elif not has_concrete_support and not core_hit and generic_support_hits > 0:
            total = 0.3  # generic-only, below threshold
        elif not has_concrete_support and not core_hit:
            total = 0.0
        elif core_hit and not has_concrete_support:
            total = 0.7  # core alone passes (core is concrete entity)
        elif not core_hit and has_concrete_support:
            total = 0.6  # concrete support alone passes
        else:
            total = 1.0  # core + concrete support
            if generic_support_hits > 0:
                total = min(total + 0.05, 1.0)
        group_scores.append(round(total, 3))
        core_hits.append(bool(core_hit))
        # Title-only core hit: the title reflects a paper's primary focus, so
        # a core term in the title (vs. an abstract related-work mention) is
        # the signal that this paper is actually about that group's concept.
        title_core_hits.append(bool(_match_text(core, title)) if core else False)

    # Threshold: each group needs >= 0.6 to count
    passed_groups = sum(1 for s in group_scores if s >= 0.6)
    total_groups = len(CURRENT_QUERY_GROUPS)
    # Need at least 1 group to pass (user confirmed: any 1 group = accepted)
    group_pass_ratio = passed_groups / total_groups if total_groups else 0
    accepted = passed_groups >= 1

    # When at least one group passes, the paper's relevance score is the actual
    # score of its best-matching group (0.6 / 1.0), NOT the pass ratio
    # (passed/total). The pass ratio used to be stored as ``score``, so a paper
    # matching 1 of 3 groups scored 0.333 and was then rejected by the semantic
    # fallback threshold (0.35), even though its matched group scored 0.6.
    best_group_score = max(group_scores, default=0.0)
    return {
        "score": round(best_group_score, 3) if accepted else round(group_pass_ratio, 3),
        "group_pass_ratio": round(group_pass_ratio, 3),
        "best_group_score": round(best_group_score, 3),
        "accepted": accepted,
        "group_scores": group_scores,
        "core_hits": core_hits,
        "title_core_hits": title_core_hits,
        "passed_groups": passed_groups,
        "total_groups": total_groups,
        "scoring_method": "grouped_plan_b_refined",
    }


def _plan_literature_queries(query: str, source: str, config, trace: dict | None = None) -> tuple[list[dict], str]:
    global CURRENT_QUERY_GROUPS
    """Turn a research question into independent, executable search facets.

    A deterministic plan is always present. When the answer model is
    configured, it may replace only the query text with better English
    scholarly vocabulary; dimensions and the local relevance gate remain
    authoritative.
    """
    if trace is not None:
        trace.clear()
        trace["input_query"] = query
    # Deterministic fallback: only extract capitalized entities from the question.
    # The old build_literature_query_plan hardcoded 12 question types x 3 dimensions,
    # which extracted only "ai" for Chinese questions. Now LLM is the main path;
    # this fallback just pulls capitalized English entities.
    import re as _re
    plan = []
    entities = _re.findall(r"\b[A-Z][A-Za-z0-9+.-]*\b", str(query or ""))
    entities = list(dict.fromkeys(e for e in entities if len(e) >= 2 and e.lower() not in {"the", "this", "that", "what", "when", "where", "which", "how", "why"}))
    for ent in entities[:4]:
        plan.append({"dimension": "entity", "relation": "focused", "query": f'(ti:"{ent}" OR abs:"{ent}")'})
    # Term extraction feeds two separate paths. English terminology may enter
    # query_local_term directly; local non-English terms are translation input
    # for the planner model only and never become query strings themselves.
    # When extraction yields nothing, no query_local_term route is added.
    local_terms = extract_query_terms(query)
    existing = {str(item.get("query", "")).lower() for item in plan}
    for phrase in local_terms["english"]:
        if phrase.lower() not in existing:
            plan.append({"dimension": "query_local_term", "relation": "focused", "query": phrase})
            existing.add(phrase.lower())
    plan = plan[:12]
    if trace is not None:
        trace["deterministic_plan"] = plan
        trace["deterministic_phrases"] = local_terms["english"]
        trace["local_terms"] = local_terms
    if source != "arxiv" or not config:
        if trace is not None:
            trace["planner_status"] = "deterministic_only"
        return plan, "deterministic"
    model_config = config.get_custom_llm_config()
    model_url = os.getenv("MODEL_REQUEST_URL") or model_config.get("url", "")
    model_token = os.getenv("MODEL_REQUEST_TOKEN") or model_config.get("token", "")
    # The model planner is most valuable exactly when the deterministic plan is
    # empty: a Chinese or French question has no English terminology to extract
    # locally, so the model is the only source of translatable query terms.
    # Requiring a non-empty plan here would skip translation for those
    # questions and leave retrieval with nothing to run.
    if not model_url:
        if trace is not None:
            trace["planner_status"] = "deterministic_only"
            trace["llm_unavailable"] = True
        return plan, "deterministic"
    # Keep the planner prompt independent from the deterministic fallback.
    prompt = (
        "You are the literature query planner. Read the user's question and return a JSON object.\n"
        "No prose, Markdown, or explanation.\n"
        "The only valid shape is:\n"
        '{"groups": [{"core": "keyword", "core_is_broad": false, '
        '"support": [{"term": "word", "is_generic": false}, ...]}, ...]}\n\n'
        "Rules:\n"
        "1. Split the question into independent sub-topics. Each sub-topic is one group.\n"
        "2. Each group has ONE core word and 0-4 support words.\n"
        "3. All words must be English scholarly terms. For non-English questions, translate to English.\n"
        "4. Every support word is an object {\"term\": ..., \"is_generic\": ...}.\n"
        "5. Set is_generic=true for ABSTRACT ASPECT/DIMENSION words (a property or angle, "
        "not a concrete thing): 'efficiency', 'energy efficiency', 'power density', "
        "'performance', 'accuracy', 'cost', 'latency', 'stability', 'robustness', "
        "'limitations', 'challenges', 'convergence', 'comparison', 'evaluation', "
        "'trade-off', 'advantage', 'quality'.\n"
        "6. Set is_generic=false for CONCRETE things: specific method names, model names, "
        "specific materials, devices, circuits, converters, inverters, datasets, tasks - "
        "e.g. 'LoRA', 'Mamba', 'GaN', 'SiC', 'converter', 'inverter', 'KV cache "
        "quantization', 'high-frequency inverter'.\n"
        "7. EXPAND BROAD CATEGORIES ONLY FOR APPLICATION/HOW-TO QUESTIONS: when the question "
        "names a broad technology or material category AND asks how to apply/improve/build "
        "something (words like 如何、怎样、怎么、如何提升、怎样实现、how to), do NOT use the "
        "broad category as a group core. Instead output ONE GROUP PER CONCRETE INSTANCE:\n"
        "   - 'how to improve devices using wide bandgap semiconductors' -> core 'GaN', core 'SiC'.\n"
        "   - 'how to compress models' -> core 'quantization', core 'pruning', core 'distillation'.\n"
        "   Put concrete application words (converter, inverter) in support is_generic=false; "
        "abstract aspect words (efficiency, power density) in support is_generic=true.\n"
        "   NEVER put the broad category itself (e.g. 'wide bandgap semiconductor') into an "
        "instance group support: it pulls parent-field papers instead of application papers.\n"
        "7b. DO NOT EXPAND FOR COMPARISON/DIFFERENCE QUESTIONS: when the question asks about "
        "the difference, comparison, properties, or mechanisms of named concepts/phenomena "
        "(words like 差异、区别、对比、对比、是什么、有什么不同、difference vs comparison), use "
        "the concept/phenomenon name itself as core. Do NOT replace it with a specific "
        "material or instance:\n"
        "   - 'topological insulator vs Weyl semimetal surface transport differences' -> "
        "core 'topological insulator', core 'Weyl semimetal' (NOT Bi2Se3/TaAs).\n"
        "   - 'classifier guidance vs classifier-free guidance trade-off' -> use those exact "
        "concept names as cores.\n"
        "8. If the question has only ONE specific core concept (e.g. 'world model'), output "
        "ONE group, core=that concept, synonyms in support (is_generic=false).\n"
        "9. If the question compares named methods A vs B (e.g. LoRA vs QLoRA), output one "
        "group per named method with that method as core.\n"
        "10. Set core_is_broad=true only when a core is unavoidably a broad field word; "
        "such a group MUST still carry at least one is_generic=false support word.\n"
        "11. GROUP COUNT LIMIT: output exactly one group per distinct named concept/method/"
        "phenomenon the question asks about. Do NOT create extra groups for background "
        "concepts, parent fields, or sub-mechanisms. If the question names 3 things, output "
        "at most 3 groups (a single-concept question gets 1 group).\n"
        "12. SUPPORT TERMS MUST BE SHORT: each support term is 1 to 3 words, never a full "
        "phrase or clause. Split long ideas into separate short terms or omit them. Use "
        "'rendering speed', not 'rendering quality and speed difference'.\n\n"
        "Good examples:\n"
        "Q: '世界模型'\n"
        'A: {"groups": [{"core": "world model", "core_is_broad": false, "support": '
        '[{"term": "world models", "is_generic": false}, '
        '{"term": "world-model-based reinforcement learning", "is_generic": false}]}]}\n\n'
        "Q: '依托宽禁带半导体、高频逆变、电力电子集成，怎样提升大功率设备的能效与功率密度？'\n"
        'A: {"groups": [{"core": "GaN", "core_is_broad": false, "support": '
        '[{"term": "converter", "is_generic": false}, '
        '{"term": "inverter", "is_generic": false}, '
        '{"term": "energy efficiency", "is_generic": true}, '
        '{"term": "power density", "is_generic": true}]}, '
        '{"core": "SiC", "core_is_broad": false, "support": '
        '[{"term": "inverter", "is_generic": false}, '
        '{"term": "converter", "is_generic": false}, '
        '{"term": "energy efficiency", "is_generic": true}, '
        '{"term": "power density", "is_generic": true}]}]}\n\n'
        "Q: 'LoRA 与 QLoRA 的核心差异是什么？'\n"
        'A: {"groups": [{"core": "LoRA", "core_is_broad": false, "support": '
        '[{"term": "low-rank adaptation", "is_generic": false}]}, '
        '{"core": "QLoRA", "core_is_broad": false, "support": '
        '[{"term": "quantized LoRA", "is_generic": false}]}]}\n\n'
        "Bad examples (don't do this):\n"
        '{"groups": [{"core": "wide bandgap semiconductor", "support": []}]} '
        '(broad category must be split into GaN/SiC instance groups)\n'
        '{"groups": [{"core": "energy efficiency", "support": []}]} (abstract aspect word)\n\n'
    )
    # Ground the translation in the question's own terminology: the locally
    # extracted non-English terms must each appear among the translated
    # keywords so no query-local concept is lost in translation.
    if local_terms["chinese"]:
        prompt += (
            "The question contains these non-English local terms: "
            + ", ".join(local_terms["chinese"])
            + ". Translate every one of them into standard English scholarly terminology "
            "and include each translation among the keywords. When the question is fully "
            "non-English and no English entity is extractable locally, your translated "
            "keywords are the ONLY entity source for retrieval: every keyword must contain "
            "a concrete English entity term (for 世界模型 output 'world model', never just "
            "'model' or 'limitations').\n\n"
        )
    prompt += f"User original question:\n{query}"
    if trace is not None:
        trace["llm_prompt"] = prompt
        trace["llm_model"] = config.model_name
        trace["llm_request_contract"] = {"response_format": {"type": "json_object"}}
    headers = {"Content-Type": "application/json"}
    if model_token:
        headers.update({"Authorization": f"Bearer {model_token}", "csb-token": model_token})
    payload = {
        "model": config.model_name,
        "messages": [
            {"role": "system", "content": "Return JSON only. No Markdown or explanation."},
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.0,
        # Reasoning models may spend a substantial part of the completion
        # budget on hidden reasoning before emitting the JSON object. 300
        # tokens can therefore produce an empty or truncated planner result.
        "max_tokens": int(os.getenv("LITERATURE_PLANNER_MAX_TOKENS", "16000")),
        "response_format": {"type": "json_object"},
    }
    parse_errors = []
    max_planner_attempts = 3
    for attempt in range(1, max_planner_attempts + 1):
        try:
            response = post_model_request(model_url, headers=headers, json=payload,
                                     timeout=min(int(model_config.get("timeout", 60) or 60), 30))
            response.raise_for_status()
            response_data = response.json()
            # Keep only choices[0].message.content (or the equivalent visible
            # text field). Never put the complete API envelope in the audit
            # field: it may contain reasoning, usage and provider metadata.
            choices_only = response_data.get("choices") if isinstance(response_data, dict) else None
            if isinstance(choices_only, list) and choices_only:
                content = _extract_llm_text({"choices": choices_only[:1]}).strip()
            else:
                content = _extract_llm_text(response_data).strip()
            original_content = content
            if trace is not None:
                trace["llm_raw_response_content"] = content
                trace["llm_attempts"] = attempt
            content = re.sub(r"^```(?:json)?\s*|\s*```$", "", content, flags=re.I).strip()
            if trace is not None:
                # This is the parseable content field used by the planner;
                # the provider's unmodified text remains in the audit field.
                trace["llm_raw_response"] = content
            if not content:
                raise ValueError("empty JSON planner response")
            try:
                generated = json.loads(content)
            except json.JSONDecodeError:
                # A reasoning model can be cut off after emitting several
                # keyword strings. Recover the object locally before spending
                # the retry, and record both the provider content and the
                # repaired JSON used by the planner.
                repaired = _repair_keyword_json(content)
                if repaired is None:
                    raise
                generated = repaired
                repaired_text = json.dumps(generated, ensure_ascii=False)
                if trace is not None:
                    trace["llm_raw_response_content"] = original_content
                    trace["llm_raw_response"] = repaired_text
                    trace["llm_json_repaired"] = True
            if not isinstance(generated, dict):
                raise ValueError("planner response must be a JSON object")
            break
        except (json.JSONDecodeError, ValueError) as exc:
            parse_errors.append(f"attempt {attempt}: invalid planner JSON")
            if attempt == max_planner_attempts:
                generated = None
                if trace is not None:
                    trace["llm_error"] = f"planner JSON remained invalid after {max_planner_attempts - 1} retries"
                break
            time.sleep(0.2)
        except Exception as exc:
            # Network timeouts / connection errors are transient: retry with a
            # short backoff instead of immediately degrading to an empty plan.
            parse_errors.append(f"attempt {attempt}: {type(exc).__name__}: {exc}")
            logging.getLogger(__name__).info(
                "Literature query planner attempt %d failed: %s", attempt, exc
            )
            if attempt == max_planner_attempts:
                generated = None
                if trace is not None:
                    trace["llm_error"] = (
                        f"planner request failed after {max_planner_attempts} attempts: "
                        f"{type(exc).__name__}"
                    )
                break
            # Backoff before retrying a network/connection error.
            time.sleep(2.0 * attempt)
    else:
        raise ValueError("planner request did not complete")
    try:
        # Support both old format {"keywords": [...]} and new format {"groups": [...]}
        raw_groups = generated.get("groups", []) if isinstance(generated, dict) else []
        if isinstance(raw_groups, list) and raw_groups:
            # Generic/broad word classification is primarily produced by the
            # LLM planner (each support object carries is_generic; the group
            # carries core_is_broad). The small set below is only a fallback
            # used when the model omits the flag or returns the legacy string
            # support format. It intentionally lists only the most obvious
            # non-specific terms; domain-specific judgement is the LLM's job.
            fallback_generic_words = {
                # bare aspect / relation words
                "limitations", "limitation", "challenges", "challenge",
                "overview", "review", "survey", "advantages", "advantage",
                "evaluation", "applications", "application", "mechanisms",
                "mechanism", "comparison", "comparisons", "differences",
                "difference", "future directions", "efficiency", "performance",
                "accuracy", "cost", "latency", "stability", "robustness",
                "convergence", "trade-off",
                # broad entity / field words
                "methods", "method", "models", "model", "approaches",
                "approach", "systems", "system", "network", "networks",
                "algorithm", "algorithms", "material", "materials",
                "device", "devices", "llm", "large language model",
                "deep learning", "machine learning", "neural network",
                "neural networks", "cell", "cells", "celestial body",
                "artificial intelligence", "ai",
            }

            def _fallback_generic(term: str) -> bool:
                return term.strip().lower() in fallback_generic_words

            CURRENT_QUERY_GROUPS = []
            for g in raw_groups:
                if not isinstance(g, dict):
                    continue
                core = str(g.get("core", "")).strip()
                llm_core_broad = g.get("core_is_broad")
                # Normalize support: accept both the new object format
                # {"term":..., "is_generic":...} and the legacy string format.
                support = []
                for s in (g.get("support") or []):
                    if isinstance(s, dict):
                        term = str(s.get("term", "")).strip()
                        if not term:
                            continue
                        flag = s.get("is_generic")
                        is_generic = bool(flag) if flag is not None else _fallback_generic(term)
                        support.append({"term": term, "is_generic": is_generic})
                    else:
                        term = str(s).strip()
                        if not term:
                            continue
                        support.append({"term": term, "is_generic": _fallback_generic(term)})
                # If core itself is an aspect/generic word, promote the first
                # concrete support word to core and move the generic core into
                # support. LLM flag wins when present.
                core_is_generic = (
                    bool(llm_core_broad) if llm_core_broad is not None
                    else _fallback_generic(core)
                )
                if core and core_is_generic:
                    concrete_support = [s for s in support if not s["is_generic"]]
                    if concrete_support:
                        new_core = concrete_support[0]["term"]
                        support = [s for s in support if s["term"] != new_core]
                        support.insert(0, {"term": core, "is_generic": True})
                        core = new_core
                        core_is_generic = False
                # A broad core (LLM, cell, model...) MUST have at least one
                # concrete support word, otherwise it produces noise.
                core_is_broad = (
                    bool(llm_core_broad) if llm_core_broad is not None
                    else _fallback_generic(core)
                )
                if core and core_is_broad:
                    concrete_support = [s for s in support if not s["is_generic"]]
                    if not concrete_support:
                        if trace is not None:
                            trace.setdefault("broad_core_rejected", []).append(core)
                        continue
                if core:
                    CURRENT_QUERY_GROUPS.append({"core": core, "support": support})
            if trace is not None:
                trace["query_groups"] = CURRENT_QUERY_GROUPS
            # Build arXiv fielded Boolean queries from the groups. A broad
            # category has already been split into concrete instance groups
            # (e.g. GaN, SiC); each instance core is AND-bound to the
            # question's concrete application words (converter, inverter),
            # which is what pulls eess application papers instead of
            # cond-mat materials physics. The core term uses an exact
            # title/abstract phrase match (avoids the GaN->GAN substring
            # false hits); application support words match more loosely.
            def _arxiv_clause(term: str, exact: bool = False) -> str:
                # Always quote the term: an unquoted short token such as GaN
                # is substring-matched by arXiv (GaN -> SeeingGAN), while a
                # quoted phrase requires an exact token match.
                t = " ".join(str(term).split()).strip()
                base = f'ti:"{t}" OR abs:"{t}"'
                if not exact:
                    all_field = f'all:"{t}"' if " " in t else f"all:{t}"
                    base += f" OR {all_field}"
                return f"({base})"

            def _build_group_query(g: dict) -> Optional[str]:
                core = str(g.get("core") or "").strip()
                core_clause = None if (not core or _fallback_generic(core)) else _arxiv_clause(core, exact=True)
                concrete = [s for s in g.get("support", []) if not s["is_generic"]]
                sup_clauses = [_arxiv_clause(s["term"]) for s in concrete if str(s.get("term") or "").strip()]
                if core_clause and sup_clauses:
                    return f'{core_clause} AND ({" OR ".join(sup_clauses)})'
                if core_clause:
                    return core_clause
                if sup_clauses:
                    return " OR ".join(sup_clauses)
                return None

            # Per group: high-precision AND query first, then a core-only
            # fallback for recall (does not exceed the old per-group word
            # count, so total API calls do not increase).
            and_queries = []
            core_queries = []
            for g in CURRENT_QUERY_GROUPS:
                q = _build_group_query(g)
                if q:
                    and_queries.append(q)
                    core = str(g.get("core") or "").strip()
                    if core and not _fallback_generic(core):
                        core_queries.append(_arxiv_clause(core, exact=True))
            raw_keywords = and_queries + core_queries
        else:
            raw_keywords = generated.get("keywords", []) if isinstance(generated, dict) else []
        if not isinstance(raw_keywords, list):
            raise ValueError("keyword response does not contain a list")
        blocked = {"and", "or", "the", "paper", "papers", "arxiv", "research"}
        # P6: bare relation or qualifier words are not searchable entities. The
        # planner prompt forbids them; this validator enforces the same rule
        # offline, so a model that echoes "limitations" alone cannot produce a
        # noise-only query route. Entity+aspect phrases ("transformer
        # limitations") remain valid and are the intended shape.
        bare_relation_words = {
            "limitations", "limitation", "challenges", "challenge", "issues",
            "issue", "problems", "problem", "overview", "review", "survey",
            "surveys", "advantages", "advantage", "benefits", "benefit",
            "evaluation", "evaluations", "applications", "application",
            "mechanisms", "mechanism", "methods", "method", "models", "model",
            "approaches", "approach", "architecture", "comparison",
            "comparisons", "difference", "differences", "future directions",
            "future direction",
        }

        def _valid_planner_keyword(candidate: str) -> bool:
            # Queries already assembled into arXiv fielded Boolean syntax are
            # validated as arXiv expressions (they legitimately contain
            # parentheses, quotes and AND/OR and exceed the plain-phrase
            # length cap), rather than as bare keyword phrases.
            if re.search(r"\b(?:ti|abs|all)\s*:", candidate):
                try:
                    ok, _reason = validate_arxiv_query(candidate)
                    return bool(ok)
                except Exception:
                    return False
            words = candidate.split()
            lowered = candidate.lower()
            is_bare_relation = (
                lowered in bare_relation_words
                or (bool(words) and all(word.lower() in bare_relation_words for word in words))
            )
            return (
                2 <= len(candidate) <= 80
                and 1 <= len(words) <= 7
                and candidate.isascii()
                and re.fullmatch(r"[\w][\w /+\-.]*", candidate, flags=re.UNICODE)
                and lowered not in blocked
                and not is_bare_relation
                and not re.search(r"\b(?:and|or)\b|https?://|arxiv|\b\d{4}\.\d{4,5}\b", candidate, re.I)
            )

        keywords = []
        rejected_keywords = []
        for raw in raw_keywords:
            candidate = " ".join(str(raw or "").split()).strip()
            if _valid_planner_keyword(candidate) and candidate.lower() not in {item.lower() for item in keywords}:
                keywords.append(candidate)
            elif candidate:
                rejected_keywords.append(candidate)
        # P1: a fully non-English question has no deterministic English entity to
        # fall back on - the model's translation is the only entity source. If
        # the first answer carried no usable ASCII keyword (e.g. it echoed the
        # Chinese wording), give it one bounded repair attempt that demands
        # ASCII-only scholarly terms, instead of silently degrading the whole
        # round to empty queries that every source must refuse.
        if not keywords and local_terms["chinese"]:
            repair_prompt = (
                prompt
                + "\nIMPORTANT: your previous answer contained no usable keyword. "
                "Every keyword MUST be pure ASCII English scholarly terminology; "
                "translate the non-English terms exactly. Return only the JSON object.\n"
            )
            repair_payload = {
                "model": config.model_name,
                "messages": [
                    {"role": "system", "content": "Return JSON only. No Markdown or explanation."},
                    {"role": "user", "content": repair_prompt},
                ],
                "temperature": 0.0,
                "max_tokens": int(os.getenv("LITERATURE_PLANNER_MAX_TOKENS", "1800")),
                "response_format": {"type": "json_object"},
            }
            try:
                repair_response = post_model_request(
                    model_url, headers=headers, json=repair_payload,
                    timeout=min(int(model_config.get("timeout", 60) or 60), 30),
                )
                repair_response.raise_for_status()
                repair_text = _extract_llm_text(repair_response.json()).strip()
                repair_text = re.sub(r"^```(?:json)?\s*|\s*```$", "", repair_text, flags=re.I).strip()
                repair_generated = json.loads(repair_text)
                if isinstance(repair_generated, dict):
                    for raw in repair_generated.get("keywords", []):
                        candidate = " ".join(str(raw or "").split()).strip()
                        if (_valid_planner_keyword(candidate)
                                and candidate.lower() not in {item.lower() for item in keywords}):
                            keywords.append(candidate)
                        elif candidate:
                            rejected_keywords.append(candidate)
                if trace is not None:
                    trace["llm_repair_attempted"] = True
                    trace["llm_repair_keywords"] = list(keywords)
            except Exception as exc:
                if trace is not None:
                    trace["llm_repair_error"] = f"{type(exc).__name__}: {exc}"
                logging.getLogger(__name__).info(
                    "Literature query planner repair attempt failed: %s", exc
                )
        if trace is not None:
            trace["llm_rejected_keywords"] = rejected_keywords[:20]
        if 1 <= len(keywords) <= 30:
            # The relation carrier is normally the deterministic plan, which
            # supplies the question's relation to each translated term. A
            # non-English question can leave that plan empty, so fall back to
            # the relation inferred from the question itself rather than
            # dividing by an empty plan.
            relation_carriers = plan or [{"relation": infer_literature_relation(query)}]
            model_routes = [
                {
                    # These are the translated, query-local terminology for
                    # this particular question. The label stays explicit in
                    # diagnostics while the origin distinguishes it from the
                    # program-only English fallback below.
                    "dimension": "query_local_term",
                    "relation": fallback.get("relation", "focused"),
                    "query": keyword,
                    "model_query": True,
                    "term_origin": "llm_translated",
                    "model_keywords": keywords,
                }
                for fallback, keyword in zip(
                    relation_carriers * (
                        (len(keywords) + len(relation_carriers) - 1) // len(relation_carriers)
                    ),
                    keywords,
                )
            ]
            merged = list(model_routes)
            seen = {str(item.get("query", "")).strip().lower() for item in merged}
            for fallback in plan:
                key = str(fallback.get("query", "")).strip().lower()
                if key and key not in seen:
                    merged.append(fallback)
                    seen.add(key)
            if trace is not None:
                trace["llm_keywords"] = keywords
                trace["final_plan"] = merged
                trace["planner_status"] = "llm_keywords_plus_deterministic"
            return merged, "llm_keywords_plus_deterministic"
    except Exception as exc:
        if trace is not None:
            trace["llm_error"] = f"{type(exc).__name__}: {exc}"
            trace["llm_parse_errors"] = parse_errors
        logging.getLogger(__name__).info("Literature query planner fallback: %s", exc)
    # P1 offline fallback: a fully non-English question whose deterministic
    # plan carries no usable English entity must not send entity-less queries
    # to sources that reject them. Use the standard scholarly translation of
    # the question's Chinese terms (translation table, not a topic-to-paper
    # mapping) as the final fallback routes before returning.
    if not any(re.search(r"[A-Za-z]", str(item.get("query", "") or "")) for item in plan):
        _fallback_added = False
        for phrase in chinese_entity_fallback_queries(query):
            if not any(str(item.get("query", "") or "").strip().lower() == phrase.lower() for item in plan):
                plan.append({
                    "dimension": "translated_entity",
                    "relation": infer_literature_relation(query),
                    "query": phrase,
                    "model_query": False,
                    "term_origin": "translation_fallback",
                })
                _fallback_added = True
        if trace is not None:
            trace["planner_status"] = "translation_fallback" if _fallback_added else "deterministic_fallback"
    elif trace is not None:
        trace["planner_status"] = "deterministic_fallback"
    # Safety net: when the LLM planner failed and CURRENT_QUERY_GROUPS is
    # empty, _score_by_groups returns None and every candidate falls back to
    # score_literature_relevance, which degrades to 0.0 for Chinese questions
    # (no English concepts resolvable). Rebuild minimal groups from the
    # deterministic plan's English query terms so the lexical gate can still
    # match papers by entity name (e.g. TransE, RotatE). Each extracted term
    # becomes a single-core group; a core-only hit scores 0.7, above the 0.6
    # threshold, so genuinely relevant papers are not silently rejected.
    if not CURRENT_QUERY_GROUPS:
        _rebuilt = []
        _seen_terms = set()
        for _item in plan:
            _q = str(_item.get("query", "") or "")
            # Extract quoted terms from ti:"..." / abs:"..." / all:"..."
            for _m in re.findall(r'(?:ti|abs|all):"([^"]+)"', _q):
                _t = _m.strip()
                if _t and re.search(r"[A-Za-z]{2,}", _t) and _t.lower() not in _seen_terms:
                    _rebuilt.append({"core": _t, "support": []})
                    _seen_terms.add(_t.lower())
            # Also accept bare ASCII keyword phrases
            if re.fullmatch(r"[A-Za-z][A-Za-z0-9 +\-/.]{1,40}", _q.strip()):
                _t = _q.strip()
                if _t.lower() not in _seen_terms:
                    _rebuilt.append({"core": _t, "support": []})
                    _seen_terms.add(_t.lower())
        if _rebuilt:
            CURRENT_QUERY_GROUPS.extend(_rebuilt[:8])
            if trace is not None:
                trace["query_groups_rebuilt_from_deterministic"] = True
                trace["query_groups"] = CURRENT_QUERY_GROUPS
    return plan, "deterministic"


def _adaptive_literature_queries(
    query: str,
    source: str,
    config,
    attempted_queries: list[str],
) -> tuple[list[str], str]:
    """Expand a failed literature query using the model, then safe fallbacks."""
    fallback_queries = build_adaptive_literature_queries(query, source)
    model_queries = []
    model_config = config.get_custom_llm_config() if config else {}
    model_url = os.getenv("MODEL_REQUEST_URL") or model_config.get("url", "")
    model_token = os.getenv("MODEL_REQUEST_TOKEN") or model_config.get("token", "")
    if model_url:
        headers = {"Content-Type": "application/json"}
        if model_token:
            headers["Authorization"] = f"Bearer {model_token}"
            headers["csb-token"] = model_token
        prompt = (
            "Expand this scientific literature search query for the specified source. "
            "Return only a JSON array of 3 to 6 concise search phrases, preferably in English. "
            "Include translations, synonyms, abbreviations, parent concepts, child concepts, "
            "and common benchmark or survey terms. Do not return paper IDs, explanations, or invented facts.\n"
            f"Source: {source}\nUser query: {query}\n"
            + ("This is a follow-up. Use this only to resolve omitted referents and generate new search phrases; "
               "do not treat it as evidence or return paper IDs.\n" + _followup_context_for_retrieval() + "\n" if _has_followup_context() else "")
            +
            f"Already attempted: {attempted_queries}"
        )
        try:
            response = post_model_request(
                model_url,
                headers=headers,
                json={
                    "model": config.model_name,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": 0.1,
                    "max_tokens": 300,
                },
                timeout=min(int(model_config.get("timeout", 60) or 60), 30),
            )
            response.raise_for_status()
            data = response.json()
            if isinstance(data, str):
                data = json.loads(data)
            content = _extract_llm_text(data).strip()
            content = re.sub(r"^```(?:json)?\s*|\s*```$", "", content, flags=re.IGNORECASE).strip()
            try:
                parsed = json.loads(content)
            except (TypeError, ValueError):
                parsed = re.findall(r"[\"']([^\"']{3,160})[\"']", content)
            if isinstance(parsed, dict):
                parsed = parsed.get("queries") or parsed.get("terms") or []
            if isinstance(parsed, list):
                model_queries = [str(item).strip() for item in parsed if str(item).strip()]
        except Exception as exc:
            logging.getLogger(__name__).debug("Adaptive literature query expansion failed: %s", exc)

    attempted = {" ".join(str(item).split()).lower() for item in attempted_queries}
    combined = []
    for item in [*model_queries, *fallback_queries]:
        normalized = " ".join(str(item).split()).strip()
        if not normalized or normalized.lower() in attempted:
            continue
        if normalized not in combined:
            combined.append(normalized)
    return combined, "model_and_deterministic" if model_queries else "deterministic"


def _semantic_filter_literature_candidates(
    query: str,
    candidates: list[dict],
    config,
) -> tuple[list[dict], dict]:
    """Use one bounded model call to reject lexical namesakes and domain drift."""
    if not candidates or not config:
        return candidates, {"status": "not_run", "reason": "no_candidates_or_config"}
    model_config = config.get_custom_llm_config()
    model_url = os.getenv("MODEL_REQUEST_URL") or model_config.get("url", "")
    model_token = os.getenv("MODEL_REQUEST_TOKEN") or model_config.get("token", "")
    if not model_url:
        return candidates, {"status": "fallback", "reason": "answer_model_not_configured"}
    payload_candidates = [
        {
            "paper_id": str(item.get("paper_id", "") or item.get("id", "")),
            "title": str(item.get("title", ""))[:300],
            "abstract": str(item.get("abstract", ""))[:1200],
        }
        for item in candidates[:40]
    ]
    # If groups are available, include them in the prompt so the semantic
    # filter knows that a paper only needs to address ONE group (e.g. one of
    # several compared methods) to be relevant, not all of them.
    groups_hint = ""
    if CURRENT_QUERY_GROUPS:
        group_descs = []
        for g in CURRENT_QUERY_GROUPS:
            core = g.get("core", "")
            support_terms = []
            for s in (g.get("support", []) or []):
                if isinstance(s, dict):
                    support_terms.append(str(s.get("term", "")))
                else:
                    support_terms.append(str(s))
            support = ", ".join(t for t in support_terms if t)
            if core and support:
                group_descs.append(f"- {core} (with: {support})")
            elif core:
                group_descs.append(f"- {core}")
        if group_descs:
            groups_hint = (
                "The user's question has these independent semantic groups. "
                "A paper is relevant if it substantively addresses AT LEAST ONE group; "
                "it does NOT need to address all groups. Groups:\n"
                + "\n".join(group_descs) + "\n"
            )
    prompt_prefix = (
        "Judge whether each paper can provide evidence for the user's research question. "
        + groups_hint +
        "Use title and abstract semantics, not isolated word overlap. Distinguish namesakes and domain "
        "drift (for example, the same term used in an unrelated discipline). Return JSON only as "
        '{"decisions":[{"paper_id":"...","label":"strong|partial|weak|rejected","reason":"short reason"}]}. '
        "strong means it directly addresses a central requested issue; partial means it substantively "
        "supports at least one requested sub-question or one semantic group; weak means only background or keyword overlap; "
        "rejected means unrelated. For comparison questions (A vs B vs C), a paper about only A is still partial/weak, not rejected. "
        "A paper that designs, proposes, or evaluates a concrete device, circuit, topology, or "
        "method involving a requested core entity (e.g. a GaN or SiC inverter/converter) is strong "
        "or partial evidence EVEN IF it does not quantify the exact target metric (efficiency, power "
        "density). Do NOT reject it merely for not reporting that metric. "
        "Reject ONLY when a matched term is a namesake in an unrelated field - e.g. 'voice conversion' "
        "not a power converter, a generative 'GAN' not the material 'GaN', or pure materials physics "
        "with no device/application angle. "
        "Do not invent paper IDs and decide every supplied candidate.\n"
    )

    def parse_decisions(content: str) -> list[dict]:
        cleaned = str(content or "").strip()
        # Models occasionally wrap JSON in prose, markdown fences, or return
        # the decisions array directly. Extract the first balanced JSON value
        # instead of treating those harmless wrappers as a filter failure.
        cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", cleaned, flags=re.I).strip()
        parsed = None
        for candidate in (cleaned,):
            try:
                parsed = json.loads(candidate)
                break
            except (TypeError, ValueError):
                pass
        if parsed is None:
            starts = [index for index, char in enumerate(cleaned) if char in "[{" ]
            for start in starts:
                opener = cleaned[start]
                closer = "]" if opener == "[" else "}"
                end = cleaned.rfind(closer)
                if end <= start:
                    continue
                try:
                    parsed = json.loads(cleaned[start:end + 1])
                    break
                except (TypeError, ValueError):
                    continue
        if isinstance(parsed, dict):
            decisions = parsed.get("decisions", [])
        elif isinstance(parsed, list):
            decisions = parsed
        else:
            raise ValueError("semantic filter returned no JSON decisions")
        if not isinstance(decisions, list):
            raise ValueError("semantic filter decisions is not a list")
        return decisions

    try:
        headers = {"Content-Type": "application/json"}
        if model_token:
            headers.update({"Authorization": f"Bearer {model_token}", "csb-token": model_token})
        decisions = []
        last_error = None
        # Keep each response comfortably below the model output limit. A
        # single request for 30-40 candidates frequently gets truncated and
        # used to force the whole filter into lexical fallback.
        offsets = list(range(0, len(payload_candidates), 10))
        batch_decisions_by_offset: dict[int, list[dict]] = {}
        batch_errors: dict[int, Exception] = {}

        def run_batch(offset: int) -> None:
            supplied = payload_candidates[offset:offset + 10]
            prompt = (
                prompt_prefix
                + f"User question: {query}\nCandidates: {json.dumps(supplied, ensure_ascii=False)}"
            )
            batch_decisions = []
            for attempt in range(2):
                try:
                    retry_supplied = supplied if attempt == 0 else [
                        {**item, "abstract": item["abstract"][:500]} for item in supplied
                    ]
                    retry_prompt = prompt_prefix + f"User question: {query}\nCandidates: {json.dumps(retry_supplied, ensure_ascii=False)}"
                    response = post_model_request(
                        model_url, headers=headers,
                        json={"model": config.model_name, "messages": [{"role": "user", "content": retry_prompt}],
                              "temperature": 0.0, "max_tokens": 1600},
                        timeout=min(int(model_config.get("timeout", 60) or 60), 45),
                    )
                    response.raise_for_status()
                    batch_decisions = parse_decisions(_extract_llm_text(response.json()))
                    if batch_decisions:
                        break
                    raise ValueError("semantic filter returned no decisions")
                except Exception as exc:
                    batch_errors[offset] = exc
            # A batch that yields nothing is reported rather than silently
            # dropped. Its candidates stay absent from ``decisions`` and are
            # therefore handled as unjudged below, which is recoverable;
            # abandoning the remaining batches would not be.
            if not batch_decisions:
                logging.getLogger(__name__).info(
                    "[semantic_filter] batch offset=%s, returned=0 decisions, likely truncated",
                    offset,
                )
            batch_decisions_by_offset[offset] = batch_decisions

        # Batches are independent LLM calls and run concurrently up to the
        # configured cap (default 4). Decisions are merged in batch order, not
        # completion order, so the resulting {paper_id: decision} mapping is
        # exactly the serial one regardless of which request finishes first.
        max_workers = min(
            max(1, int(os.getenv("LITERATURE_SEMANTIC_FILTER_CONCURRENCY", "4"))),
            max(1, len(offsets)),
        )
        if max_workers <= 1:
            for offset in offsets:
                run_batch(offset)
        else:
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                list(executor.map(run_batch, offsets))
        for offset in offsets:
            decisions.extend(batch_decisions_by_offset.get(offset, []))
        last_error = next((batch_errors[offset] for offset in offsets if offset in batch_errors), None)

        # Retry the candidates the model skipped. A model that omits ids has
        # not judged those papers, so re-asking in smaller batches recovers
        # them instead of letting an omission read as a rejection.
        def missing_payload(seen_ids: set) -> list[dict]:
            return [
                item for item in payload_candidates
                if item["paper_id"].lower() not in seen_ids
            ]

        def decision_ids(entries: list[dict]) -> set:
            return {
                str(item.get("paper_id", "")).lower()
                for item in entries if isinstance(item, dict) and item.get("paper_id")
            }

        outstanding = missing_payload(decision_ids(decisions))
        if len(outstanding) >= 2:
            missing_offsets = list(range(0, len(outstanding), 5))
            missing_results: dict[int, list[dict]] = {}
            missing_errors: dict[int, Exception] = {}

            def run_missing_batch(offset: int) -> None:
                supplied = outstanding[offset:offset + 5]
                prompt = (
                    prompt_prefix
                    + f"User question: {query}\nCandidates: "
                    + json.dumps(supplied, ensure_ascii=False)
                    + "\nReturn exactly one decision for every paper_id listed above."
                )
                try:
                    response = post_model_request(
                        model_url, headers=headers,
                        json={"model": config.model_name,
                              "messages": [{"role": "user", "content": prompt}],
                              "temperature": 0.0, "max_tokens": 1600},
                        timeout=min(int(model_config.get("timeout", 60) or 60), 45),
                    )
                    response.raise_for_status()
                    recovered = parse_decisions(_extract_llm_text(response.json()))
                    missing_results[offset] = recovered
                    logging.getLogger(__name__).info(
                        "[semantic_filter] missing-retry batch offset=%s, requested=%s, returned=%s",
                        offset, len(supplied), len(recovered),
                    )
                except Exception as exc:
                    missing_errors[offset] = exc
                    logging.getLogger(__name__).info(
                        "[semantic_filter] missing-retry batch offset=%s failed: %s",
                        offset, exc,
                    )

            missing_workers = min(
                max(1, int(os.getenv("LITERATURE_SEMANTIC_FILTER_CONCURRENCY", "4"))),
                max(1, len(missing_offsets)),
            )
            if missing_workers <= 1:
                for offset in missing_offsets:
                    run_missing_batch(offset)
            else:
                with ThreadPoolExecutor(max_workers=missing_workers) as executor:
                    list(executor.map(run_missing_batch, missing_offsets))
            for offset in missing_offsets:
                decisions.extend(missing_results.get(offset, []))
            if missing_errors:
                last_error = next(
                    (missing_errors[offset] for offset in missing_offsets if offset in missing_errors),
                    last_error,
                )

        if not decisions:
            raise last_error or ValueError("semantic filter returned no decisions")
        def _strip_arxiv_version(pid: str) -> str:
            # arXiv ids carry a version suffix (2503.01264v1 -> 2503.01264).
            # The judge often normalises it away when returning decisions, so
            # an exact match treated a judged paper as missing. Index and
            # lookup under both the raw id and its version-stripped form.
            return re.sub(r"v\d+$", "", str(pid or "").strip()).lower()

        by_id = {}
        for item in decisions:
            if isinstance(item, dict) and item.get("paper_id"):
                raw = str(item.get("paper_id", "")).lower()
                by_id[raw] = item
                by_id[_strip_arxiv_version(raw)] = item
        kept = []
        counts = {"strong": 0, "partial": 0, "weak": 0, "rejected": 0, "missing": 0}
        unjudged = []
        for candidate in candidates:
            paper_id = str(candidate.get("paper_id", "") or candidate.get("id", ""))
            decision = by_id.get(paper_id.lower()) or by_id.get(_strip_arxiv_version(paper_id))
            if not decision:
                # The model returned no decision for this paper. That is an
                # omission, not a judgement: scoring it as rejected discarded
                # papers the model simply never answered for.
                counts["missing"] += 1
                candidate["relevance"]["semantic_label"] = "unjudged"
                candidate["relevance"]["accepted"] = None
                candidate["relevance"]["unjudged_reason"] = "model_did_not_return_decision"
                unjudged.append(candidate)
                continue
            label = str(decision.get("label", "")).strip().lower()
            if label not in {"strong", "partial", "weak", "rejected"}:
                label = "rejected"
            counts[label] += 1
            candidate["relevance"]["semantic_label"] = label
            candidate["relevance"]["semantic_reason"] = str(decision.get("reason", ""))[:300]
            # weak papers are background/keyword-overlap but still topically
            # adjacent. Admit them so the ledger has something to work with
            # instead of zeroing out after a strict comparison/limitation gate.
            # The writer still sees semantic_label=weak and can de-prioritise.
            lex_score = float(candidate["relevance"].get("score", 0.0) or 0.0)
            if label == "rejected" and lex_score >= 0.9:
                # Safety net against an inconsistent judge: the lexical gate
                # found both the core entity and a concrete application word
                # (score >= 0.9), which is strong on-topic evidence. The
                # judge's rejection was observed to flip run to run even at
                # temperature 0 (the same GaN inverter paper was 'rejected'
                # in one run and 'strong' in another). Admit such a paper at
                # weak weight so the writer can use but de-prioritise it;
                # namesakes (voice conversion, generative GAN) never reach
                # score 0.9 because they miss the core entity.
                candidate["relevance"]["accepted"] = True
                candidate["relevance"]["semantic_label"] = "lexical_strong_override"
                candidate["relevance"]["semantic_reason"] = (
                    "judge rejected but lexical score>=0.9 (core+application matched); "
                    "admitted at weak weight. Judge reason: "
                    + str(decision.get("reason", ""))[:200]
                )
                kept.append(candidate)
            else:
                candidate["relevance"]["accepted"] = label in {"strong", "partial", "weak"}
                if candidate["relevance"]["accepted"]:
                    kept.append(candidate)

        # An unjudged paper is neither admitted nor discarded outright. It is
        # put through the same conservative lexical test the filter uses when
        # it cannot run at all: the global relevance gate plus query-local
        # concept evidence. Applying that same rule keeps one standard for
        # "the judge was unavailable" whether the judge failed or skipped.
        for item in unjudged:
            relevance = item.get("relevance", {}) or {}
            score = float(relevance.get("score", 0.0) or 0.0)
            concepts = set(relevance.get("matched_concepts") or [])
            if score >= get_relevance_threshold() and len(concepts) >= 1:
                relevance["accepted"] = True
                relevance["semantic_label"] = "fallback_unjudged"
                relevance["semantic_reason"] = (
                    "semantic judge returned no decision for this paper; "
                    "kept on lexical evidence"
                )
                kept.append(item)
            else:
                relevance["accepted"] = False
                relevance["semantic_label"] = "unjudged_final"
        logging.getLogger(__name__).info(
            "[semantic_filter] completed counts=%s kept=%s evaluated=%s",
            counts, len(kept), len(payload_candidates),
        )
        # Log first few decisions for debugging
        for d in decisions[:5]:
            logging.getLogger(__name__).info(
                "[semantic_filter] decision: %s",
                json.dumps(d, ensure_ascii=False)[:200],
            )
        # Unified strong-lexical safety net: any candidate with score >= 0.9
        # means the lexical gate found both the core entity and a concrete
        # application word - strong on-topic evidence. If the judge rejected
        # it, omitted it (common in 10-candidate batches), or a fallback path
        # discarded it because matched_concepts is empty (Chinese queries
        # extract no English concepts), admit it at weak weight. Namesakes
        # (voice conversion, generative GAN) never reach score 0.9 because
        # they miss the core entity, so this does not reintroduce noise.
        _kept_ids = {
            str(it.get("paper_id") or it.get("id") or "").lower()
            for it in kept
        }
        for item in candidates:
            rel = item.get("relevance", {}) or {}
            if rel.get("accepted"):
                continue
            if float(rel.get("score", 0.0) or 0.0) < 0.9:
                continue
            _pid = str(item.get("paper_id") or item.get("id") or "").lower()
            if _pid in _kept_ids:
                continue
            rel["accepted"] = True
            rel["semantic_label"] = "lexical_strong_override"
            rel["semantic_reason"] = (
                "score>=0.9 (core+application lexical match); admitted at "
                "weak weight after judge/fallback rejection or omission"
            )
            kept.append(item)
            _kept_ids.add(_pid)
        return kept, {
            "status": "completed",
            "counts": counts,
            "evaluated": len(payload_candidates),
            "unjudged_recovered": sum(
                1 for item in unjudged
                if item.get("relevance", {}).get("semantic_label") == "fallback_unjudged"
            ),
        }
    except Exception as exc:
        import traceback
        logging.getLogger(__name__).info("Semantic literature filter fallback: %s\n%s", exc, traceback.format_exc())
        # A failed semantic judge must not silently admit every lexical hit.
        # Keep only high-confidence lexical candidates and expose the degraded
        # decision in diagnostics so the search ladder can continue if needed.
        # A lexical score alone is unsafe for broad terms such as
        # ``multimodal`` or ``alignment``. Require at least two independently
        # matched concepts, or one concept plus a relation/technical signal in
        # the title or abstract. This remains topic-agnostic and does not map
        # fixed keywords to fixed papers.
        relation_signals = re.compile(
            r"\b(?:method|model|architecture|framework|benchmark|evaluation|"
            r"alignment|fusion|reasoning|hallucination|grounding|retrieval|"
            r"audio|video|vision|language|multimodal)\b", re.I
        )
        conservative = []
        for item in candidates:
            relevance = item.get("relevance", {}) or {}
            score = float(relevance.get("score", 0.0) or 0.0)
            concepts = set(relevance.get("matched_concepts") or [])
            text = f"{item.get('title', '')} {item.get('abstract', '')}"
            # The lexical scorer already applies the global relevance gate.
            # If the semantic judge is unavailable, keep a candidate that
            # matches a query-local concept and contains a technical signal;
            # requiring 0.55 here used to discard clearly relevant papers
            # scored at 0.4083 and force an unjustified generic fallback.
            title_hits = relevance.get("title_matched") or []
            if score >= get_relevance_threshold() and (len(concepts) >= 2 or (concepts and relation_signals.search(text)) or title_hits):
                relevance["accepted"] = True
                relevance["semantic_label"] = "fallback_partial"
                relevance["semantic_reason"] = "semantic judge unavailable; lexical concepts and technical signal matched"
                conservative.append(item)
        return conservative, {
            "status": "fallback_conservative",
            # P4: a bare exception class name ("ValueError") is not an
            # audit trail. Record the concrete failure so a fallback decision
            # can be attributed to its real cause.
            "reason": f"{type(exc).__name__}: {exc}",
            "kept": len(conservative),
            "kept": len(conservative),
            "evaluated": len(payload_candidates),
        }


def _search_relevant_literature(
    query: str,
    source: str,
    tools: MCPTools,
    config=None,
    minimum_evidence: int | None = None,
) -> tuple[list[dict], dict, bool]:
    """Search a bounded query ladder and return only evidence-eligible papers."""
    # Follow-ups such as "explain the projector just mentioned" are not
    # self-contained search queries. Resolve their referents before planning,
    # scoring, and semantic judging, while retaining ``query`` as the visible
    # user question and as the evidence-boundary reference.
    followup_context_used = _has_followup_context()
    retrieval_query = _merge_followup_query_for_retrieval(query)
    inherited_paper_ids = list(CONVERSATION_CONTEXT.get("paper_ids") or []) if followup_context_used else []
    followup_evidence_decision, followup_decision_diagnostics = _decide_followup_evidence_need(query)
    explicit_arxiv_ids = extract_explicit_arxiv_ids(query) if source == "arxiv" else []
    required_concepts = requested_concepts(query)
    # A request for several papers should not stop after the first canonical
    # match. Keep the evidence bar narrow and explicit so ordinary definition
    # questions retain their fast one-paper path.
    wants_multiple_papers = bool(re.search(r"(?:几篇|多篇|数篇|several\s+papers|multiple\s+papers)", str(query or ""), re.I))
    critical_synthesis = source == "arxiv" and is_limitation_query(query)
    # Multi-part/explanatory questions often need a second evidence batch when
    # the first few papers only cover one named method.  Ask the search ladder
    # for a pool of up to fifteen distinct papers up front; the reader below
    # still stops after the first sufficient batch of five.
    broad_evidence_request = (
        not explicit_arxiv_ids
        and (len(str(query or "")) >= 100
             or str(query or "").count("?") >= 2
             or str(query or "").count("？") >= 2
             or len(re.findall(r"[、,，;；]", str(query or ""))) >= 2)
    )
    minimum_papers = 15 if broad_evidence_request else (3 if wants_multiple_papers else (2 if critical_synthesis else 1))

    def evidence_goal_met(items: list[dict]) -> bool:
        accepted = [item for item in items if item.get("relevance", {}).get("accepted")]
        if explicit_arxiv_ids and any(
            item.get("relevance", {}).get("explicit_request") for item in accepted
        ):
            return True
        if len(accepted) < minimum_papers:
            return False
        if not required_concepts:
            return True
        covered = set()
        for item in accepted:
            covered.update(item.get("relevance", {}).get("matched_concepts") or [])
        return required_concepts.issubset(covered)

    # Build the deterministic plan before checking cache. A cache hit is still
    # a literature decision that users need to audit, so its diagnostics must
    # show the same planned evidence dimensions as a live search.
    query_plan = []
    query_plan_source = "explicit_id" if explicit_arxiv_ids else "deterministic"
    # Always available for diagnostics, even on the explicit-ID path.
    subquestions = decompose(retrieval_query)
    if not explicit_arxiv_ids:
        # For a follow-up, plan from the compact parent/current query rather
        # than the full previous answer. This preserves referents without
        # turning answer boilerplate into retrieval vocabulary.
        query_plan, query_plan_source = _plan_literature_queries(retrieval_query, source, config)
        # A compound question carries several requests. Planning only from the
        # whole string mixes their vocabulary and hides which part got no
        # evidence, so each part contributes its own queries and every plan
        # item is tagged with the part it serves.
        if len(subquestions) > 1:
            seen_queries = {str(item.get("query", "")).strip().lower() for item in query_plan}
            for subquestion in subquestions:
                # A referential branch ("如果是前者") takes its subject from an
                # earlier part, so its own text alone is not a usable query.
                if subquestion.referential:
                    continue
                sub_plan, _ = _plan_literature_queries(subquestion.text, source, None)
                for item in sub_plan:
                    key = str(item.get("query", "")).strip().lower()
                    if not key or key in seen_queries:
                        continue
                    seen_queries.add(key)
                    query_plan.append({**item, "subquestion": subquestion.index})
            query_plan_source = f"{query_plan_source}+subquestion_plans"

    # A query naming an arXiv paper must never be redirected by a broad-query
    # cache entry. It is a user-selected primary source, not a suggestion.
    # Multi-source retrieval may accumulate fifteen candidates even for a
    # short question; cache the complete pool so a repeat request does not
    # silently collapse back to the old five-paper limit.
    cache_limit = 15 if (broad_evidence_request or (source == "arxiv" and not explicit_arxiv_ids)) else MAX_RESULTS_PER_SOURCE_CALL
    # Prior context changes the semantic meaning of a terse question, so a
    # cache entry keyed only by its literal text is unsafe.
    # Generic arXiv requests now fan out to all configured public sources.
    # An old arXiv-only cache entry can contain duplicate/stale candidates and
    # would otherwise short-circuit the fan-out before Zenodo/HAL are reached.
    # Keep cache reuse for explicit IDs and follow-up-safe paths only; generic
    # multi-source searches always build a fresh, source-balanced pool.
    multi_source_enabled = source == "arxiv" and not explicit_arxiv_ids and followup_evidence_decision != "reuse_only"
    cached = None if (explicit_arxiv_ids or followup_context_used or multi_source_enabled) else get_literature_cache(source, query, cache_limit)
    cached_candidates = []
    if cached is not None:
        for paper in cached:
            if not isinstance(paper, dict):
                continue
            item = dict(paper)
            item["relevance"] = score_literature_relevance(
                " ".join(part for part in (retrieval_query, query) if str(part).strip()), item
            )
            # Group-based override: if LLM planned groups, use group scoring
            gv = _score_by_groups(item)
            if gv:
                item["relevance"]["group_score"] = gv["score"]
                item["relevance"]["group_accepted"] = gv["accepted"]
                item["relevance"]["group_details"] = {
                    "group_scores": gv["group_scores"],
                    "core_hits": gv["core_hits"],
                    "title_core_hits": gv["title_core_hits"],
                    "passed_groups": gv["passed_groups"],
                    "total_groups": gv["total_groups"],
                }
                # If group scoring says accepted, override the lexical gate.
                # Clear the old rejection reason so downstream stages don't
                # re-reject based on named_object_missing.
                # Always use group-based verdict when groups exist
                item["relevance"]["accepted"] = gv["accepted"]
                item["relevance"]["score"] = gv["score"]
                if gv["accepted"]:
                    item["relevance"]["rejection_reason"] = None
                    item["relevance"]["rejection_stage"] = None
                else:
                    item["relevance"]["rejection_reason"] = "no_group_passed"
                    item["relevance"]["rejection_stage"] = "group_gate"
                    item["relevance"]["rejection_reason"] = None
                    item["relevance"]["rejection_stage"] = None
            # Freeze the gate's own verdict before any semantic post-processing
            # can overwrite ``accepted``; diagnostics need both stages apart.
            item["relevance"]["lexical_accepted"] = item["relevance"]["accepted"]
            cached_candidates.append(item)
        cached_candidates.sort(key=lambda item: item["relevance"]["score"], reverse=True)
        cached_relevant = [item for item in cached_candidates if item["relevance"]["accepted"]]
        cached_semantic_diagnostics = {"status": "not_run"}
        if cached_relevant:
            cached_relevant, cached_semantic_diagnostics = _semantic_filter_literature_candidates(
                retrieval_query, cached_relevant, config
            )
        if evidence_goal_met(cached_relevant):
            diagnostics = {
                "search_rounds": 1,
                "queries_used": [query],
                "query_plan": query_plan,
                "query_groups": CURRENT_QUERY_GROUPS,
                "query_plan_source": query_plan_source,
                "followup_context_used": followup_context_used,
                "parent_task_id": CONVERSATION_CONTEXT.get("parent_task_id") if followup_context_used else None,
                "inherited_paper_ids": inherited_paper_ids,
                "problem_spec": build_problem_spec(query),
                "candidates_seen": len(cached_candidates),
                "relevant_papers": len(cached_relevant),
                "relevance_threshold": get_relevance_threshold(),
                "min_concept_coverage": MIN_CONCEPT_COVERAGE,
                "stop_reason": "cache_hit",
                "semantic_filter": cached_semantic_diagnostics,
                "candidate_scores": [
                    {"paper_id": item.get("paper_id", ""), "score": item["relevance"]["score"],
                     "lexical_accepted": item["relevance"].get("lexical_accepted", item["relevance"]["accepted"]),
                     "semantic_label": item["relevance"].get("semantic_label"),
                     "final_accepted": item["relevance"]["accepted"],
                     "rejection_stage": (
                         None if item["relevance"]["accepted"]
                         else ("lexical" if not item["relevance"].get("lexical_accepted", False) else "semantic")
                     )}
                    for item in cached_candidates
                ],
            }
            return cached_relevant, diagnostics, True

    if explicit_arxiv_ids:
        queries = [f"id:{paper_id}" for paper_id in explicit_arxiv_ids]
    else:
        queries = [item["query"] for item in query_plan] or build_literature_queries(query)
    # Re-read inherited papers as ordinary candidates. They are never forced
    # into the answer: the current retrieval score and semantic filter still
    # decide whether they address this follow-up.
    context_retrieval_queries = []
    if source == "arxiv" and followup_context_used and followup_evidence_decision in {"reuse_only", "reuse_and_search"}:
        # Preserve room in the bounded ladder for two genuinely new routes.
        # The selected parent paper is a re-check candidate, not a substitute
        # for fresh retrieval on a changed or more specific follow-up.
        context_retrieval_queries = [f"id:{paper_id}" for paper_id in inherited_paper_ids[:1]]
        queries = list(dict.fromkeys([*context_retrieval_queries, *queries]))
        if followup_evidence_decision == "reuse_only":
            queries = context_retrieval_queries
    # All non-explicit paper questions use the same dynamic query plan. No
    # topic or intent branch inserts a predetermined arXiv paper ID.

    # Reserve one bounded round for semantic expansion when the first query
    # ladder returns no evidence. This makes failure recovery different from
    # simply repeating the same malformed or overly literal query.
    # Every single-turn literature answer shares the same three-batch budget.
    # A query plan intentionally contains independent facets; execute them
    # before considering adaptive recovery, without exceeding 15 papers.
    # Fifteen papers means at most three API batches of five. It must not be
    # interpreted as fifteen independent API rounds, which violates arXiv's
    # one-request-per-three-seconds policy and magnifies transient failures.
    # A broad question — long, multi-clause, or carrying several question
    # marks — needs more distinct query routes than a single focused question.
    # The pool of fifteen papers still bounds the result set; this only gives
    # the planner room to use its facets instead of the first three.
    query_round_limit = MAX_BROAD_QUERY_ROUTES if broad_evidence_request else MAX_QUERY_ROUTES
    # P5: keep the whole plan for the multi-source ladder. Truncating to the
    # first three routes here made later, more specific facets (e.g.
    # "quadratic complexity") unreachable once the pool filled: pool
    # refinement then cycled the same three routes instead of consuming the
    # plan's unconsumed exact queries. The round cap and the candidate-pool
    # cap still bound the ladder; the single-source path below truncates to
    # the same per-question route budget it always had.
    queries = list(dict.fromkeys(
        str(item).strip() for item in queries if str(item).strip()
    ))
    candidates_by_id: dict[str, dict] = {}
    round_stats = []
    stop_reason = "max_rounds_exhausted"
    semantic_filter_diagnostics = {"status": "not_run", "reason": "insufficient_lexical_candidates"}
    for cached_item in cached_candidates:
        paper_id = str(cached_item.get("paper_id", "") or cached_item.get("id", "")).strip()
        if paper_id:
            cached_source = str(cached_item.get("source") or source).lower()
            base_id = paper_id.lower().split("v", 1)[0]
            candidate_key = f"{cached_source}:{base_id}"
            previous = candidates_by_id.get(candidate_key)
            if previous is None or cached_item["relevance"]["score"] > previous["relevance"]["score"]:
                candidates_by_id[candidate_key] = cached_item

    def perform_search_round(search_query: str, score_query: str, round_index: int, source_name: str | None = None) -> int:
        effective_source = source_name or source
        source_status = None
        # The arXiv adapter accepts fielded Boolean syntax, while Zenodo/HAL
        # expose ordinary free-text APIs. Reusing the arXiv expression for
        # every source silently produces empty result sets. Derive a compact
        # language-level query for non-arXiv adapters without any topic map.
        adapter_query = search_query
        if effective_source not in {"arxiv", "pubmed"}:
            terms = []
            for quoted, bare in re.findall(r'"([^"]+)"|([A-Za-z][A-Za-z0-9-]{2,})', str(search_query)):
                term = (quoted or bare).strip()
                if term.lower() in {"all", "ti", "abs", "and", "or", "not", "method", "analysis", "evaluation", "benchmark", "experiment", "comparison"}:
                    continue
                if term and term.lower() not in {item.lower() for item in terms}:
                    terms.append(term)
            adapter_query = " ".join(terms[:10]) or str(retrieval_query).strip()
        # P3: a source in cooldown must not burn a round with a guaranteed 0ms
        # failure. Skip it, record why, and let the other sources use this
        # round. The cooldown state is cross-process, so this also protects
        # sibling workers from hammering the same endpoint.
        if effective_source == "arxiv" and not explicit_arxiv_ids:
            _cooldown_probe = getattr(tools, "arxiv_cooldown_remaining", None)
            _cooldown_remaining = 0.0
            if callable(_cooldown_probe):
                try:
                    _cooldown_remaining = max(0.0, float(_cooldown_probe() or 0.0))
                except Exception:
                    _cooldown_remaining = 0.0
            if _cooldown_remaining > 0:
                round_stats.append({
                    "round": round_index, "source": effective_source, "query": search_query,
                    "adapter_query": adapter_query, "returned": 0, "max_score": 0.0,
                    "accepted_total": sum(1 for item in candidates_by_id.values() if item["relevance"]["accepted"]),
                    "skip_reason": (
                        f"arXiv temporary request cooldown active "
                        f"({_cooldown_remaining:.1f}s remaining); source skipped for this round"
                    ),
                    "source_status": "cooling_skip",
                })
                return sum(1 for item in candidates_by_id.values() if item["relevance"]["accepted"])
        # Reject relation-only routes before any source adapter is called.
        # This prevents the same malformed planner output from reaching HAL
        # or Zenodo as broad, unrelated free-text searches. The check ignores
        # field prefixes and Boolean operators: counting "all"/"ti"/"abs" as
        # entity terms used to let a purely generic route slip through.
        if not has_topic_anchor(adapter_query):
            round_stats.append({
                "round": round_index, "source": effective_source, "query": search_query,
                "adapter_query": adapter_query, "returned": 0, "max_score": 0.0,
                "accepted_total": sum(1 for item in candidates_by_id.values() if item["relevance"]["accepted"]),
                "search_error": "query_rejected: missing_english_entity",
                "source_status": "invalid_query",
            })
            return sum(1 for item in candidates_by_id.values() if item["relevance"]["accepted"])
        # A rotation-skipped source must not burn a round with a fake 0ms
        # "completed" and then a "failed" event: it never touched the network.
        # Record one honest skipped event and let the other sources use this
        # round. source_skip_reason mirrors search_source's cooldown_skip
        # branches exactly (disabled + cooldown not expired, or a sibling
        # worker holds the probe); a source whose cooldown has expired still
        # really queries here (half-open recovery probe), so it keeps the
        # stage events. The check runs before the stage so a skip emits no
        # started/completed pair at all.
        if effective_source not in {"arxiv", "pubmed"}:
            skip_note = source_skip_reason(effective_source)
            if not skip_note and re.fullmatch(
                r"id:\s*[0-9]{4}\.[0-9]{4,5}(?:v[0-9]+)?\s*",
                str(search_query or "").strip(), re.I,
            ):
                # An exact arXiv paper-ID route only makes sense for the arXiv
                # adapter; sending "id:xxxx" to Zenodo/HAL/TechRxiv free-text
                # search would burn a round on noise. One honest skipped event
                # keeps the round available for the other sources.
                skip_note = "exact paper-ID lookup only targets arXiv; skipped for this source"
            if not skip_note:
                # A deterministic network failure (DNS name resolution) will
                # repeat identically on every retry within this task: each
                # attempt only burns the source's timeout budget and holds up
                # the other sources. After one such failure, skip the source
                # for the remaining rounds instead of retrying it.
                _prev_stat = next(
                    (item for item in reversed(round_stats)
                     if item.get("source") == effective_source
                     and item.get("source_status") != "skipped"),
                    None,
                )
                _prev_error = str((_prev_stat or {}).get("search_error") or "")
                if (_prev_stat or {}).get("source_status") == "source_unreachable" and any(
                    marker in _prev_error
                    for marker in ("NameResolutionError", "getaddrinfo", "Failed to resolve")
                ):
                    # DNS may be a transient hiccup (network switch, DNS blip).
                    # Skip at most 2 consecutive rounds, then allow a retry.
                    _consec_dns = sum(
                        1 for item in reversed(round_stats)
                        if item.get("source") == effective_source
                        and "DNS/name-resolution" in str(item.get("source_skip_reason", ""))
                    )
                    if _consec_dns < 2:
                        skip_note = (
                            "DNS/name-resolution failure; source skipped for this round, will retry shortly"
                        )
            if skip_note:
                round_stats.append({
                    "round": round_index, "source": effective_source,
                    "query": search_query, "adapter_query": adapter_query,
                    "returned": 0, "max_score": 0.0,
                    "accepted_total": sum(
                        1 for item in candidates_by_id.values()
                        if item["relevance"]["accepted"]
                    ),
                    "search_error": skip_note,
                    "source_status": "skipped",
                })
                record_diagnostic(
                    "literature_search_round", "skipped", reason=skip_note,
                    source=effective_source, round=round_index, returned=0,
                    source_status="skipped",
                )
                return sum(
                    1 for item in candidates_by_id.values()
                    if item["relevance"]["accepted"]
                )
        with diagnostic_stage("literature_search_round", source=effective_source, round=round_index):
            if effective_source == "pubmed":
                search = tools.search_pubmed_key_words(search_query, max_results=MAX_RESULTS_PER_SOURCE_CALL)
                raw = search.data if search.success and isinstance(search.data, list) else []
                papers = [
                    {"title": item.get("Title", ""), "paper_id": item.get("PMID", ""),
                     "abstract": item.get("Abstract", ""),
                     "url": f"https://pubmed.ncbi.nlm.nih.gov/{item.get('PMID', '')}/", "source": "pubmed"}
                    for item in raw if isinstance(item, dict)
                ]
            elif effective_source == "arxiv":
                # Critical synthesis needs a broader candidate pool because
                # arXiv metadata is not a curated survey index. The direct
                # architecture-limitation gate below remains strict.
                # Each official API call is capped at five papers. The task
                # level ladder may aggregate up to fifteen distinct papers.
                max_results = MAX_RESULTS_PER_SOURCE_CALL
                search = tools.arxiv_search(search_query, max_results=max_results)
                papers = search.data.get("papers", []) if search.success and isinstance(search.data, dict) else []
                if not search.success and "no English entity condition" in str(search.error or ""):
                    # P1/P8: the adapter refused our own query, not the
                    # source. The source is healthy, so this is a query-side
                    # outcome (invalid_query) rather than a source failure.
                    # That keeps the aggregated search_failed / failure_type
                    # diagnostics honest when a planner produced an
                    # entity-less route.
                    source_status = "invalid_query"
            else:
                alternate = search_source(effective_source, adapter_query, limit=3)
                papers = alternate.get("papers", []) if alternate.get("status") == "ok" else []
                source_status = alternate.get("status")
                search = type("SourceSearch", (), {
                    "success": alternate.get("status") == "ok",
                    "error": alternate.get("error"),
                    "metadata": {"warnings": []},
                })()
        search_error = None
        if not search.success:
            search_error = search.error or "literature search failed"
            warnings = getattr(search, "metadata", {}) or {}
            if isinstance(warnings, dict) and warnings.get("warnings"):
                search_error += " " + "; ".join(str(item) for item in warnings["warnings"][:2])
        # P2: per-candidate telemetry must be written even when a source
        # returns hits that all fail the relevance gate. Without it a
        # "returned N / accepted 0" source is indistinguishable from a dead
        # source, and the adapter_query itself never reaches diagnostics.
        candidate_scores = []
        max_score = 0.0
        for paper in papers:
            if not isinstance(paper, dict):
                continue
            paper_id = str(paper.get("paper_id", "") or paper.get("id", ""))
            if not paper_id:
                continue
            item = dict(paper)
            # Include the generated route in the scoring input. This keeps
            # LLM-produced English terms effective for Chinese questions,
            # while still retaining the user's original wording.
            scoring_query = " ".join(
                part for part in (score_query, search_query) if str(part).strip()
            )
            item["relevance"] = score_literature_relevance(scoring_query, item)
            # Group-based override
            gv = _score_by_groups(item)
            if gv:
                item["relevance"]["group_score"] = gv["score"]
                item["relevance"]["group_accepted"] = gv["accepted"]
                item["relevance"]["group_details"] = {
                    "group_scores": gv["group_scores"],
                    "core_hits": gv["core_hits"],
                    "title_core_hits": gv["title_core_hits"],
                    "passed_groups": gv["passed_groups"],
                    "total_groups": gv["total_groups"],
                }
                # Always use group-based verdict when groups exist
                item["relevance"]["accepted"] = gv["accepted"]
                item["relevance"]["score"] = gv["score"]
                if gv["accepted"]:
                    item["relevance"]["rejection_reason"] = None
                    item["relevance"]["rejection_stage"] = None
                else:
                    item["relevance"]["rejection_reason"] = "no_group_passed"
                    item["relevance"]["rejection_stage"] = "group_gate"
            # Freeze the gate's own verdict before any semantic post-processing
            # can overwrite ``accepted``; diagnostics need both stages apart.
            item["relevance"]["lexical_accepted"] = item["relevance"]["accepted"]
            normalized_id = paper_id.lower().split("v", 1)[0]
            inherited_bases = {
                str(value).lower().split("v", 1)[0] for value in inherited_paper_ids
            }
            if (followup_context_used
                    and followup_evidence_decision in {"reuse_only", "reuse_and_search"}
                    and normalized_id in inherited_bases):
                # Re-check candidates come from the prior verified evidence;
                # a terse follow-up may have no lexical overlap with the old
                # title, so defer the decision to semantic judging.
                item["relevance"].update({
                    "accepted": True,
                    "score": max(float(item["relevance"].get("score", 0.0) or 0.0), get_relevance_threshold()),
                    "inherited_candidate": True,
                })
            if normalized_id in {value.lower().split("v", 1)[0] for value in explicit_arxiv_ids}:
                item["relevance"].update({"accepted": True, "score": 1.0, "explicit_request": True})
            candidate_scores.append({
                "paper_id": paper_id,
                "title": str(paper.get("title", "") or "")[:160],
                "score": item["relevance"].get("score"),
                "accepted": item["relevance"].get("accepted"),
                "rejection_reason": item["relevance"].get("rejection_reason") or item["relevance"].get("reason"),
            })
            max_score = max(max_score, item["relevance"]["score"])
            candidate_key = f"{effective_source}:{paper_id}"
            previous = candidates_by_id.get(candidate_key)
            if previous is None or item["relevance"]["score"] > previous["relevance"]["score"]:
                candidates_by_id[candidate_key] = item
        accepted_total = sum(1 for item in candidates_by_id.values() if item["relevance"]["accepted"])
        stats = {
            "round": round_index, "source": effective_source, "query": search_query,
            "adapter_query": adapter_query, "returned": len(papers),
            "max_score": round(max_score, 4), "accepted_total": accepted_total,
            # Canonical search_source outcome for this call: distinguishes a
            # real network request (ok/rate_limited/access_blocked/...) from a
            # rotation skip (disabled) and a query-side refusal (invalid_query).
            "source_status": source_status if effective_source != "arxiv" else ("ok" if search.success else ("invalid_query" if source_status == "invalid_query" else "error")),
            # P2: per-candidate gate verdicts so a source that returns hits
            # but passes none through the relevance gate is auditable.
            "candidate_scores": candidate_scores,
        }
        if search_error:
            stats["search_error"] = search_error
            # The stage telemetry above only records started/completed because
            # search_source reports failures as return values instead of
            # raising. Without this event the JSONL audit trail shows a clean
            # run while the report's failure_type blames a source it never
            # names; the reason text closes that gap.
            record_diagnostic("literature_search_round", "failed",
                              reason=search_error, source=effective_source,
                              round=round_index, returned=len(papers),
                              search_query=str(search_query)[:200],
                              adapter_query=str(adapter_query)[:200])
        round_stats.append(stats)
        return accepted_total

    def infrastructure_retry_delay() -> float:
        """Return the server-requested cooldown after an infrastructure failure."""
        if not round_stats:
            return 0.0
        error = str(round_stats[-1].get("search_error") or "")
        if not error:
            return 0.0
        match = re.search(
            r"(?:cooling down for|cooldown active \()\s*([0-9]+(?:\.[0-9]+)?)s",
            error,
            re.IGNORECASE,
        )
        if match:
            return min(max(float(match.group(1)), 0.0), 60.0)
        if any(marker in error.lower() for marker in ("network unavailable", "rate limited")):
            return 10.0
        return 0.0

    require_limitation_breadth = source == "arxiv" and is_limitation_query(query)
    consecutive_infrastructure_failures = 0
    semantic_gate_cache_key = None
    semantic_gate_items = None
    semantic_gate_met = False

    def semantic_evidence_goal_met() -> bool:
        """Apply the semantic gate before allowing the search ladder to stop."""
        nonlocal semantic_filter_diagnostics, semantic_gate_cache_key
        nonlocal semantic_gate_items, semantic_gate_met
        lexical = [
            item for item in candidates_by_id.values()
            if item.get("relevance", {}).get("accepted")
        ]
        if not evidence_goal_met(lexical):
            semantic_gate_cache_key = None
            semantic_gate_items = None
            semantic_gate_met = False
            return False
        # Group coverage check: when query_groups exist, do not stop until
        # every group has at least one accepted paper. This prevents the
        # ladder from stopping after the first group's broad query fills
        # the minimum quota, leaving later groups (e.g. tool-calling when
        # the first group was chain-of-thought) completely unretrieved.
        if CURRENT_QUERY_GROUPS and len(CURRENT_QUERY_GROUPS) > 1:
            covered_groups = set()
            for item in lexical:
                gd = item.get("relevance", {}).get("group_details") or {}
                scores = gd.get("group_scores", []) or []
                hits = gd.get("core_hits", []) or []
                title_hits = gd.get("title_core_hits", []) or []
                for gi, gs in enumerate(scores):
                    # Require a TITLE core hit for that group: a core term in
                    # the title means the paper is primarily about that group's
                    # concept, whereas an abstract mention is often just a
                    # related-work survey. Fall back to abstract core hit only
                    # when no title-hit paper exists after full retrieval.
                    title_hit = bool(title_hits[gi]) if gi < len(title_hits) else False
                    core_hit = bool(hits[gi]) if gi < len(hits) else False
                    if title_hit and gs >= 0.7 and gi < len(CURRENT_QUERY_GROUPS):
                        covered_groups.add(gi)
            if len(covered_groups) < len(CURRENT_QUERY_GROUPS):
                semantic_gate_cache_key = None
                semantic_gate_items = None
                semantic_gate_met = False
                return False
        if explicit_arxiv_ids:
            semantic_gate_cache_key = tuple(sorted(
                str(item.get("paper_id") or item.get("id") or "") for item in lexical
            ))
            semantic_gate_items = lexical
            semantic_gate_met = True
            return True
        cache_key = tuple(sorted(
            (str(item.get("paper_id") or item.get("id") or ""),
             round(float(item.get("relevance", {}).get("score", 0.0) or 0.0), 6))
            for item in lexical
        ))
        if cache_key == semantic_gate_cache_key:
            return semantic_gate_met
        semantic, semantic_filter_diagnostics = _semantic_filter_literature_candidates(
            retrieval_query, lexical, config
        )
        semantic_gate_cache_key = cache_key
        semantic_gate_items = semantic
        semantic_gate_met = evidence_goal_met(semantic)
        return semantic_gate_met

    multi_source_rounds = []
    if source == "arxiv" and not explicit_arxiv_ids and followup_evidence_decision != "reuse_only":
        # Give every enabled public source equal recall in each round. Three
        # papers per source per round yields a maximum of 12 new records per
        # round; continue up to five rounds until a semantic goal is met or
        # the aggregate candidate pool reaches fifteen papers.
        source_queries = queries or [retrieval_query]
        # Rounds consume plan entries in order and only repeat them once every
        # entry has run: the planner's later, more specific facets used to be
        # discarded whenever broad first queries filled the pool early.
        pool_refinement_budget = max(0, int(os.getenv("LITERATURE_POOL_REFINEMENT_ROUNDS", "2")))
        pool_refinement_used = 0
        for round_index in range(1, MAX_RETRIEVAL_ROUNDS + 1):
            if round_index <= len(source_queries):
                query_for_round = source_queries[round_index - 1]
            else:
                query_for_round = source_queries[(round_index - 1) % len(source_queries)]
            before = len(candidates_by_id)
            for source_name in ("arxiv", "zenodo", "techrxiv", "hal"):
                perform_search_round(query_for_round, retrieval_query, round_index, source_name=source_name)
            added = len(candidates_by_id) - before
            multi_source_rounds.append({"round": round_index, "query": query_for_round, "new_candidates": added, "total_candidates": len(candidates_by_id)})
            if semantic_evidence_goal_met() and not require_limitation_breadth:
                stop_reason = "relevance_threshold_met"
                break
            if len(candidates_by_id) >= MAX_CANDIDATE_PAPERS:
                # A pool filled by broad queries must not silently discard the
                # plan's unconsumed specific facets: give the next plan entries
                # a bounded chance to meet the goal before stopping. The round
                # cap above keeps the extra cost at two rounds by default.
                if round_index >= len(source_queries) or pool_refinement_used >= pool_refinement_budget:
                    stop_reason = "candidate_pool_reached_15"
                    break
                pool_refinement_used += 1
                continue
            # Do not stop merely because one round returned no new records:
            # an API cooldown, a source-specific empty response, or a
            # transient block must not prevent later query variants from
            # reaching the fifteen-candidate target. The bounded five-round
            # limit remains the final guard.
    else:
        # Single-source path keeps the per-question route budget it always
        # had; only the multi-source ladder above consumes the full plan.
        for round_index, search_query in enumerate(queries[:query_round_limit], 1):
            perform_search_round(search_query, retrieval_query, round_index)
            retry_delay = infrastructure_retry_delay()
            if retry_delay:
                consecutive_infrastructure_failures += 1
                stop_reason = "infrastructure_failure"
                break
            consecutive_infrastructure_failures = 0
            if semantic_evidence_goal_met() and not require_limitation_breadth:
                stop_reason = "relevance_threshold_met"
                break

    # A follow-up is allowed to reuse prior evidence, but only if that
    # evidence passes the current-question gate. If the inherited paper cannot
    # support the new question, promote the decision and continue with fresh
    # retrieval instead of silently falling back to generic knowledge.
    if followup_evidence_decision == "reuse_only" and not semantic_evidence_goal_met():
        followup_evidence_decision = "search_required"
        followup_decision_diagnostics = {
            **followup_decision_diagnostics,
            "promoted": True,
            "promotion_reason": "prior_evidence_below_current_question_threshold",
        }

    adaptive_queries = []
    expansion_source = None
    # If every round was a query-rejection, the plan itself was broken. Retry once
    # with freshly expanded queries after a short pause so a one-off planner
    # degeneration does not end the task in seconds.
    _all_rejected = bool(round_stats) and all(
        item.get("source_status") in {"invalid_query", "skipped", "cooling_skip"}
        for item in round_stats
    )
    if (followup_evidence_decision != "reuse_only"
            and not semantic_evidence_goal_met()
            and (len(round_stats) < query_round_limit or _all_rejected)):
        adaptive_queries, expansion_source = _adaptive_literature_queries(
            query, source, config, [item["query"] for item in round_stats]
        )
        remaining_rounds = query_round_limit - len(round_stats)
        if _all_rejected:
            import time as _t; _t.sleep(3)
        for search_query in adaptive_queries[:remaining_rounds]:
            adaptive_score_query = f"{retrieval_query} {search_query}"
            perform_search_round(search_query, adaptive_score_query, len(round_stats) + 1)
            retry_delay = infrastructure_retry_delay()
            if retry_delay:
                consecutive_infrastructure_failures += 1
                stop_reason = "infrastructure_failure"
                break
            consecutive_infrastructure_failures = 0
            if semantic_evidence_goal_met() and not require_limitation_breadth:
                stop_reason = "adaptive_relevance_threshold_met"
                break
        else:
            stop_reason = "adaptive_expansion_exhausted" if adaptive_queries else "adaptive_expansion_unavailable"
        # If after all adaptive retries we still have no usable evidence, run
        # one more round with a fresh query variant after a short pause. This
        # catches the case where papers passed the relevance gate but all PDF
        # downloads/parses failed (transient network issue).
        if not semantic_evidence_goal_met() and round_stats:
            time.sleep(3)
            extra_queries, _ = _adaptive_literature_queries(query, source, config, [item["query"] for item in round_stats])
            for sq in extra_queries[:2]:
                perform_search_round(sq, f"{retrieval_query} {sq}", len(round_stats) + 1)
                if semantic_evidence_goal_met():
                    stop_reason = "adaptive_relevance_threshold_met"
                    break


    if round_stats and all(
        item.get("search_error")
        and item.get("source_status") not in {"disabled", "invalid_query", "cooling_skip", "skipped"}
        for item in round_stats
    ):
        # P8: search_failed must reflect source-level failures only. A
        # query-side refusal (invalid_query) or a cooldown skip
        # (cooling_skip) says nothing about source health, so a round that
        # merely produced entity-less queries on healthy sources is not
        # aggregated as a search failure.
        stop_reason = "search_failed"
    search_errors = " ".join(
        str(item.get("search_error") or "")
        for item in round_stats
        if item.get("source_status") not in {"disabled", "invalid_query", "cooling_skip", "skipped"}
    )
    if any(marker in search_errors.lower() for marker in ("rate limited", "rate limit", "429")):
        failure_type = "rate_limited"
    elif any(marker in search_errors.lower() for marker in ("network unavailable", "timeout", "connection")):
        failure_type = "network"
    elif search_errors:
        failure_type = "search_error"
    else:
        failure_type = None
    candidates = sorted(candidates_by_id.values(), key=lambda item: item["relevance"]["score"], reverse=True)
    relevant = [item for item in candidates if item["relevance"]["accepted"]]
    semantic_filter_diagnostics = (
        {"status": "not_run", "reason": "explicit_paper_request"}
        if explicit_arxiv_ids else semantic_filter_diagnostics
    )
    if relevant and not explicit_arxiv_ids and followup_evidence_decision != "reuse_only":
        final_key = tuple(sorted(
            (str(item.get("paper_id") or item.get("id") or ""),
             round(float(item.get("relevance", {}).get("score", 0.0) or 0.0), 6))
            for item in relevant
        ))
        if final_key == semantic_gate_cache_key and semantic_gate_items is not None:
            relevant = semantic_gate_items
        else:
            relevant, semantic_filter_diagnostics = _semantic_filter_literature_candidates(
                retrieval_query, relevant, config
            )
    # Post-processing. Candidates arrive keyed by ``source:paper_id``, so one
    # paper reached through arXiv, HAL and Zenodo is three separate records
    # here; dedupe collapses them, keeping the highest-preference source.
    relevant = deduplicate(relevant)
    # Reordering only: every candidate keeps the gate's accepted verdict, so
    # this decides which accepted papers are read first, never which are usable.
    relevant, rerank_diagnostics = rerank_papers(
        retrieval_query, relevant, concepts=requested_concepts(retrieval_query)
    )
    evidence_sufficiency = assess_evidence_sufficiency(relevant, minimum=minimum_evidence)
    alternate_source_diagnostics = [
        item for item in round_stats
        if item.get("source") in {"zenodo", "techrxiv", "hal"}
    ]
    # Cache candidates, not just the selected paper, so a repeat query avoids
    # external calls while still applying the same deterministic gate.
    if not followup_context_used:
        put_literature_cache(source, query, candidates[:cache_limit], cache_limit)
    diagnostics = {
        # ``search_rounds`` counts retrieval rounds (one multi-source sweep or
        # one query each); ``source_calls`` counts the individual source API
        # calls inside those rounds. The two are different units and both are
        # reported so neither can be misread as the other.
        "search_rounds": len(multi_source_rounds) or len(round_stats),
        "source_calls": len(round_stats),
        "queries_used": [item["query"] for item in round_stats],
        "query_plan": query_plan,
        "query_groups": CURRENT_QUERY_GROUPS,
        "query_plan_source": query_plan_source,
        "followup_context_used": followup_context_used,
        "parent_task_id": CONVERSATION_CONTEXT.get("parent_task_id") if followup_context_used else None,
        "inherited_paper_ids": inherited_paper_ids,
        "context_retrieval_queries": context_retrieval_queries,
        "context_reuse_decision": "rechecked_as_candidates" if context_retrieval_queries else "not_applicable",
        "followup_evidence_decision": followup_evidence_decision,
        "followup_decision_diagnostics": followup_decision_diagnostics,
        "problem_spec": build_problem_spec(query),
        "rounds": round_stats,
        "candidates_seen": len(candidates),
        "relevant_papers": len(relevant),
        "duplicate_sources_merged": sorted({
            source_name
            for item in relevant
            for source_name in (item.get("duplicate_sources") or [])
        }),
        "rerank": rerank_diagnostics,
        "evidence_sufficiency": evidence_sufficiency,
        "subquestions": [item.to_dict() for item in subquestions],
        "subquestion_plan_items": sum(
            1 for item in query_plan if item.get("subquestion")
        ),
        "anchor_paper": next((item.get("paper_id") for item in relevant if item["relevance"].get("anchor")), None),
        "relevance_threshold": get_relevance_threshold(),
        "min_concept_coverage": MIN_CONCEPT_COVERAGE,
        "stop_reason": stop_reason,
        "semantic_filter": semantic_filter_diagnostics,
        "search_failed": bool(round_stats) and all(
            item.get("search_error")
            and item.get("source_status") not in {"disabled", "invalid_query", "cooling_skip"}
            for item in round_stats
        ),
        "failure_type": failure_type,
        # P8: every real source-level failure, so failure_type and the
        # per-source statuses stay consistent and auditable.
        "source_failures": [
            {
                "source": item["source"],
                "status": item.get("source_status"),
                "error": item.get("search_error"),
            }
            for item in round_stats
            if item.get("source_status") not in {"disabled", "invalid_query", "cooling_skip", "skipped"}
            and item.get("search_error")
        ],
        "cache_empty_retried": cached is not None and not cached_relevant,
        "requested_concepts": sorted(required_concepts),
        "requested_paper_count": minimum_papers,
        "broad_evidence_request": broad_evidence_request,
        "covered_concepts": sorted({
            concept
            for item in relevant
            for concept in item.get("relevance", {}).get("matched_concepts", [])
        }),
        "adaptive_expansion_queries": adaptive_queries,
        "adaptive_expansion_source": expansion_source,
        "alternate_sources": alternate_source_diagnostics,
        "multi_source_rounds": multi_source_rounds,
        # Sources that actually issued at least one network request, in first
        # execution order; sources skipped by rotation state (disabled,
        # cooling_skip, skipped) or query-side refusal (invalid_query) never
        # hit the network and are listed separately instead.
        "sources_attempted": list(dict.fromkeys(
            item["source"] for item in round_stats
            if item.get("source_status") not in {"disabled", "invalid_query", "skipped", "cooling_skip"}
        )),
        "sources_skipped": list(dict.fromkeys(
            item["source"] for item in round_stats
            if item.get("source_status") in {"disabled", "invalid_query", "skipped", "cooling_skip"}
        )),
        "candidate_scores": [
            # Two distinct verdicts share one record: the lexical gate's own
            # decision (frozen before the semantic filter ran) and the final
            # admission after semantic post-processing. rejection_stage says
            # which stage rejected a paper; a paper that never reached the
            # semantic filter carries semantic_label null.
            {"paper_id": item.get("paper_id", ""), "title": item.get("title", ""),
             "score": item["relevance"]["score"],
             "lexical_accepted": item["relevance"].get("lexical_accepted", item["relevance"]["accepted"]),
             "semantic_label": item["relevance"].get("semantic_label"),
             "final_accepted": item["relevance"]["accepted"],
             "rejection_stage": (
                 None if item["relevance"]["accepted"]
                 else ("lexical" if not item["relevance"].get("lexical_accepted", False) else "semantic")
             ),
             "rejection_reason": item["relevance"].get("rejection_reason"),
             "scoring_status": item["relevance"].get("scoring_status"),
             "accepted_by": item["relevance"].get("accepted_by") or [],
             "matched_concepts": item["relevance"]["matched_concepts"]}
            for item in candidates
        ],
    }
    return relevant, diagnostics, False


def _run_unreferenced_general_answer(query: str, config, visualizer: DemoVisualizer, diagnostics: dict) -> AgentResponse:
    """Give a clearly labelled general explanation after literature failure."""
    start_time = time.time()
    model_config = config.get_custom_llm_config()
    model_url = os.getenv("MODEL_REQUEST_URL") or model_config.get("url", "")
    token = os.getenv("MODEL_REQUEST_TOKEN") or model_config.get("token", "")
    notice = (
        f"经过 {diagnostics.get('search_rounds', MAX_QUERY_ROUTES)} 轮官方文献检索，"
        f"未找到达到相关性阈值 {get_relevance_threshold()} 的论文。\n\n"
        "以下内容是通用知识解释，不是基于检索论文的结论；本回答不附加无关论文引用。"
    )
    if diagnostics.get("search_failed"):
        failure_type = diagnostics.get("failure_type")
        if failure_type == "rate_limited":
            failure_notice = "arXiv 官方 API 返回了限流（HTTP 429）"
        elif failure_type == "network":
            failure_notice = "无法连接 arXiv 官方 API 或请求超时"
        else:
            failure_notice = "arXiv 官方 API 请求发生错误"
        notice = (
            f"{failure_notice}；本次没有完成有效文献检索，不能据此判断没有相关论文。\n\n"
            "以下内容是通用知识解释，不是基于检索论文的结论；本回答不附加无关论文引用。"
        )
    if _has_followup_context():
        notice += (
            "\n\n本题是同一会话的追问；系统已使用上一轮主题线索辅助检索。"
            "本轮未获得足够的新论文证据，以下解释会保留这一证据边界。"
        )
    if not model_url:
        answer = notice + "\n\n当前未配置回答模型，因此无法生成通用解释。"
        response = AgentResponse(success=False, error="回答模型未配置", result={
            "task_name": "science_literature_answer", "completion_status": "partial",
            "final_answer": answer, "route": "science_literature",
            "evidence_mode": "no_relevant_paper_general_fallback", "search_diagnostics": diagnostics,
        }, iterations=1, execution_time=time.time() - start_time, agent_name="ScienceLiteratureAssistant")
        visualizer.show_final_result(response)
        return response
    headers = {"Content-Type": "application/json"}
    if token:
        headers.update({"Authorization": f"Bearer {token}", "csb-token": token})
    prompt = (
        "请直接回答用户的通用科研知识问题。不要声称查到了论文，不要添加任何论文编号、作者、页码或 [n] 引用。"
        "先说明这是通用知识解释，再给出准确、简洁的回答；不确定内容要明确标注。"
        "若提供了上一轮上下文，必须用它解析‘刚才’、代词和省略对象，绝不能说看不到上一轮对话。"
        "上一轮内容只用于理解问题，不能被写成当前检索到的新论文证据。\n"
        f"用户问题：{query}" + _followup_writer_context()
    )
    request_payload = {"model": config.model_name,
                       "messages": [{"role": "user", "content": prompt}],
                       "temperature": 0.2, "max_tokens": 2600,
                       "thinking": {"type": "disabled"}, "enable_thinking": False, "reasoning_effort": "none"}
    answer = ""
    last_error = None
    # Transient gateway resets are common after a long retrieval phase. Retry
    # only the final answer call; retrieval and PDF evidence are not repeated.
    for attempt in range(3):
        try:
            response_raw = post_model_request(
                model_url, headers=headers, json=request_payload,
                timeout=min(int(model_config.get("timeout", 60) or 60), 60),
            )
            response_raw.raise_for_status()
            data = response_raw.json()
            answer = _extract_llm_text(data)
            if not answer:
                choices = data.get("choices") or [] if isinstance(data, dict) else []
                if choices:
                    answer = str((choices[0].get("message") or {}).get("content") or "").strip()
            if answer:
                break
            last_error = "回答模型返回空正文"
        except Exception as exc:  # noqa: BLE001 - gateway-specific failures
            last_error = str(exc)
        if attempt < 2:
            time.sleep(1.5 * (attempt + 1))
    if answer:
        final_answer = notice + "\n\n" + answer
        response = AgentResponse(success=True, result={
            "task_name": "science_literature_answer", "completion_status": "partial",
            "final_answer": final_answer, "route": "science_literature",
            "evidence_mode": "no_relevant_paper_general_fallback", "search_diagnostics": diagnostics,
            "papers": [], "evidence_ledger": [], "citation_check": {"status": "not_applicable", "issues": []},
        }, iterations=1, execution_time=time.time() - start_time, agent_name="ScienceLiteratureAssistant")
    else:
        # Keep the task inspectable and honest when all answer attempts fail.
        # The caller can still show the search diagnostics and no-paper notice.
        error_text = f"通用回答失败（已重试 3 次）: {last_error or '未知模型错误'}"
        fallback_body = _build_empty_answer_fallback(query, [], last_error)
        response = AgentResponse(success=True, error=error_text, result={
            "task_name": "science_literature_answer", "completion_status": "partial",
            "final_answer": notice + "\n\n" + fallback_body,
            "route": "science_literature", "evidence_mode": "no_relevant_paper_general_fallback",
            "search_diagnostics": diagnostics, "papers": [], "evidence_ledger": [],
            "citation_check": {"status": "not_applicable", "issues": ["answer_model_unavailable"]},
        }, iterations=1, execution_time=time.time() - start_time, agent_name="ScienceLiteratureAssistant")
    visualizer.show_final_result(response)
    return response


def _extract_llm_text(data: dict) -> str:
    """Extract only user-facing text, never hidden chain-of-thought fields."""
    if not isinstance(data, dict):
        return ""
    direct = data.get("output_text") or data.get("text")
    if isinstance(direct, str) and direct.strip():
        return direct.strip()
    # Responses-style gateways may expose user-visible text under output
    # content blocks instead of Chat Completions choices.
    output = data.get("output")
    if isinstance(output, list):
        parts = []
        for item in output:
            if not isinstance(item, dict):
                continue
            content = item.get("content")
            if isinstance(content, str) and content.strip():
                parts.append(content)
            elif isinstance(content, list):
                for block in content:
                    if isinstance(block, str):
                        parts.append(block)
                    elif isinstance(block, dict):
                        block_type = str(block.get("type", "")).lower()
                        if block_type in {"output_text", "text"}:
                            value = block.get("text") or block.get("content")
                            if isinstance(value, str):
                                parts.append(value)
        if "".join(parts).strip():
            return "".join(parts).strip()
    choices = data.get("choices") or []
    if not isinstance(choices, list):
        return ""
    for choice in choices:
        if not isinstance(choice, dict):
            continue
        message = choice.get("message") or {}
        candidates = [
            message.get("content"), choice.get("text"), choice.get("content"),
        ]
        for value in candidates:
            if isinstance(value, str) and value.strip():
                return value.strip()
        # Reasoning models (deepseek-flash etc.) may put the final JSON
        # in reasoning_content while content stays empty.
        # Only extract a COMPLETE JSON object (balanced braces), not partial
        # thinking. If we can't parse it as valid JSON, skip it.
        reasoning = message.get("reasoning_content") or ""
        if isinstance(reasoning, str) and reasoning.strip():
            import re as _re
            import json as _json
            # Find the last complete JSON object in the reasoning text.
            # We look for the last { ... } pair that contains "groups" or "keywords".
            for key in ("groups", "keywords"):
                start = reasoning.find(f'"{key}"')
                if start == -1:
                    continue
                # Find the opening brace before this key
                open_pos = reasoning.rfind("{", 0, start)
                if open_pos == -1:
                    continue
                # Count braces to find the matching close
                depth = 0
                end_pos = -1
                for i in range(open_pos, len(reasoning)):
                    if reasoning[i] == "{":
                        depth += 1
                    elif reasoning[i] == "}":
                        depth -= 1
                        if depth == 0:
                            end_pos = i
                            break
                if end_pos == -1:
                    continue
                candidate_json = reasoning[open_pos:end_pos+1]
                # Verify it's valid JSON before returning
                try:
                    parsed = _json.loads(candidate_json)
                    if isinstance(parsed, dict) and (
                        "groups" in parsed or "keywords" in parsed
                    ):
                        return candidate_json
                except (ValueError, TypeError):
                    continue
    return ""


def _looks_like_reasoning_leak(text: str) -> bool:
    """Reject internal planning/meta text accidentally returned as the answer."""
    value = str(text or "").strip().lower()
    if not value:
        return True
    markers = (
        "we need answer", "let's parse", "need answer in", "need perhaps",
        "the user asks", "user asks", "let's craft", "we have evidence",
        "需要回答", "用户要求", "下面开始组织答案", "思考过程",
    )
    return any(marker in value for marker in markers)


def _is_explanatory_science_request(query: str) -> bool:
    """Whether a user expects an explanation rather than a one-line lookup."""
    lowered = str(query or "").lower()
    markers = (
        "解释", "介绍", "原理", "机制", "定义", "是什么", "什么是", "怎么", "如何",
        "explain", "introduction", "mechanism", "definition", "what is", "how does",
    )
    return any(marker in lowered for marker in markers)


def _science_answer_quality_issue(text: str, query: str, has_fulltext: bool = False) -> str | None:
    """Detect a superficially successful but visibly incomplete answer.

    Some gateways return ``finish_reason=stop`` after emitting only the first
    part of a long answer.  That is not an API error, so the normal empty-body
    guard cannot catch it.  Keep this check conservative and only apply the
    higher minimum to full-text explanatory requests where the UI promises a
    structured explanation. This is intentionally topic-independent: CoT,
    diffusion, attention, and later concepts must not receive a weaker answer
    merely because they lack a special-case branch.
    """
    value = str(text or "").strip()
    if not value:
        return "empty"
    explanatory = _is_explanatory_science_request(query)
    is_rag = "rag" in requested_concepts(query)
    # Abrupt-ending check applies to any answer with fulltext evidence: a
    # gateway may return finish_reason=stop after truncating mid-sentence,
    # and that is not caught by the empty-body guard. Length and section
    # checks stay scoped to RAG / explanatory requests where the UI
    # promises a structured long answer.
    if has_fulltext and value.rstrip().endswith(("---", "：", ":", "，", "、", "以及", "包括")):
        return "abrupt_ending"
    if not is_rag and not (has_fulltext and explanatory):
        return None
    if is_rag:
        required_markers = ("检索", "生成", "参数化", "非参数化")
        missing = [marker for marker in required_markers if marker not in value]
        if missing:
            return "missing_sections:" + ",".join(missing)
    # Do not count the application-added evidence notice; this runs before it
    # is appended. A full-text explanation shorter than this is normally an
    # abstract paraphrase rather than a useful answer.
    minimum_length = 2600 if is_rag else 1400
    if len(value) < minimum_length:
        return f"too_short:{len(value)}"
    return None


def _try_parse_json_answer(raw_text: str) -> dict | None:
    """Try to extract a JSON answer object from raw model output.

    The model may wrap the JSON in markdown code fences or add prose before/after
    it. This helper searches for the first balanced JSON object and parses it.
    Returns None if no valid JSON is found.
    """
    text = str(raw_text or "").strip()
    if not text:
        return None
    # Strip markdown code fences if present
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    # Find first { and last }
    start = text.find("{")
    end = text.rfind("}")
    if start < 0 or end <= start:
        return None
    candidate = text[start:end + 1]
    try:
        parsed = json.loads(candidate)
        if isinstance(parsed, dict):
            return parsed
    except (json.JSONDecodeError, ValueError):
        return None
    return None


def _try_recover_truncated_sections(raw_text: str) -> dict | None:
    """Recover complete section objects from a truncated ``{"sections": [...]}``.

    When the writer hits the token limit mid-JSON, strict parsing fails and the
    raw JSON would leak to the user. This scans the sections array with brace
    depth tracking, extracts every fully-closed section object, parses those,
    and rebuilds a valid object so the completed sections still render.
    """
    text = str(raw_text or "").strip()
    start = text.find("{")
    if start < 0:
        return None
    body = text[start:]
    # Locate the sections array opening.
    m = re.search(r'"sections"\s*:\s*\[', body)
    if not m:
        return None
    arr_start = m.end()
    sections = []
    i = arr_start
    n = len(body)
    while i < n:
        # Skip whitespace and commas.
        while i < n and body[i] in " \t\r\n,":
            i += 1
        if i >= n or body[i] != "{":
            break
        # Brace-depth scan, respecting strings and escapes.
        depth = 0
        j = i
        in_str = False
        escaped = False
        while j < n:
            ch = body[j]
            if in_str:
                if escaped:
                    escaped = False
                elif ch == "\\":
                    escaped = True
                elif ch == '"':
                    in_str = False
            else:
                if ch == '"':
                    in_str = True
                elif ch == "{":
                    depth += 1
                elif ch == "}":
                    depth -= 1
                    if depth == 0:
                        j += 1
                        break
            j += 1
        if depth != 0:
            # Truncated section: stop, keep everything complete so far.
            break
        chunk = body[i:j]
        try:
            obj = json.loads(chunk)
            if isinstance(obj, dict):
                sections.append(obj)
        except (json.JSONDecodeError, ValueError):
            pass
        i = j
    if not sections:
        return None
    return {"sections": sections}


def _format_section_body(body: str) -> str:
    """Post-process a section body for readability.

    Conservative reformatting that fixes common LLM output glitches:
      - Repair bold markers split across lines (**Mamba*\n* -> **Mamba**)
      - Auto-split long single paragraphs into 2-3 sentence chunks
      - Put genuine list items on their own lines (without misfiring on
        **bold** markers or in-sentence numbers like "Figure 1. shows")
      - Collapse 3+ newlines to 2
    """
    text = str(body or "").strip()
    if not text:
        return ""
    # Step 0: Repair bold markers broken across newlines.
    # Patterns: *\n* , **\n* , *\n**  -> all become **
    text = re.sub(r"\*\s*\n\s*\*", "**", text)
    # Step 0.5: Break before Chinese enumerative markers so paragraphs like
    # "第一，... 第二，... 第三，..." become separate lines instead of a wall.
    # Matches: 第一/第二/.../第十, 首先/其次/再次/最后, 一方面/另一方面
    # Only break when preceded by sentence-ending punctuation or start-of-text,
    # and the marker is followed by ，/：/、 or space (not mid-word like "第三者").
    cn_markers = (
        r"第[一二三四五六七八九十]+[,，:：、]?"
        r"|首先[,，:：、]?"
        r"|其次[,，:：、]?"
        r"|再次[,，:：、]?"
        r"|最后[,，:：、]?"
        r"|一方面[,，:：、]?"
        r"|另一方面[,，:：、]?"
    )
    # Break after sentence-ending punctuation, colon, or newline before a
    # Chinese marker. This handles both "。第一，" and "：第一，" patterns.
    text = re.sub(
        r"([。！？：:；\n])\s*(" + cn_markers + r")",
        r"\1\n\n\2",
        text,
    )
    # Also handle marker at very start of text
    text = re.sub(
        r"^(" + cn_markers + r")",
        r"\n\n\1",
        text,
    )
    # Step 1: Auto-split long paragraphs into 2-3 sentence chunks.
    # Process each paragraph separately (split by \n\n) so that one short
    # paragraph with a break doesn't prevent a long paragraph from being split.
    # Only split paragraphs >400 chars that have no internal newlines.
    def _split_long_paragraph(para: str) -> str:
        para = para.strip()
        if len(para) <= 400 or "\n" in para:
            return para
        parts = re.split(r"(?<=[。！？])(?=\s*[^\[\d])", para)
        if len(parts) <= 1:
            return para
        chunks = []
        current = ""
        for i, part in enumerate(parts):
            current += part
            if (i + 1) % 3 == 0 or i == len(parts) - 1:
                if current.strip():
                    chunks.append(current.strip())
                current = ""
        return "\n\n".join(chunks) if len(chunks) > 1 else para

    if "\n\n" in text:
        paragraphs = text.split("\n\n")
        paragraphs = [_split_long_paragraph(p) for p in paragraphs]
        text = "\n\n".join(paragraphs)
    else:
        text = _split_long_paragraph(text)
    # Step 2: Put genuine list items on their own lines.
    # Conservative: only break when the marker follows sentence-ending
    # punctuation or a newline, so we do NOT misfire on:
    #   - **bold** markers (the * is part of **, not a list bullet)
    #   - in-sentence numbers like "Figure 1. shows" or "step 2. then"
    # Unordered list: "- " after 。！？ or newline
    text = re.sub(r"(?<=[。！？\n])\s*(-\s+)", r"\n\n\1", text)
    # Ordered list: "1. " or "1、 " after 。！？ or newline
    text = re.sub(r"(?<=[。！？\n])\s*(\d+[\.、]\s+)", r"\n\n\1", text)
    # Step 3: Collapse 3+ newlines to 2
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _render_json_answer(parsed: dict) -> str | None:
    """Render a parsed JSON answer into unified Markdown.

    Expected JSON shape (flexible - extra keys are ignored):
    {
      "sections": [
        {"title": "直接结论", "content": "..."},
        {"title": "分项分析", "content": "..."},
        ...
      ]
    }
    Or flat: {"直接结论": "...", "分项分析": "..."}
    Returns None if the structure is not recognizable.
    """
    if not isinstance(parsed, dict):
        return None
    sections = parsed.get("sections")
    rendered = []
    if isinstance(sections, list) and sections:
        for sec in sections:
            if isinstance(sec, dict):
                title = str(sec.get("title") or sec.get("heading") or "").strip()
                body = str(sec.get("content") or sec.get("text") or sec.get("body") or "").strip()
                if title and body:
                    body = _format_section_body(body)
                    rendered.append(f"## {title}\n\n{body}")
            elif isinstance(sec, str):
                rendered.append(sec)
    else:
        # Flat dict: each key is a section title
        for key, value in parsed.items():
            if key in ("sections", "metadata", "meta"):
                continue
            title = str(key).strip()
            body = str(value or "").strip()
            if title and body:
                body = _format_section_body(body)
                rendered.append(f"## {title}\n\n{body}")
    if not rendered:
        return None
    return "\n\n".join(rendered)


def _complete_rag_answer(text: str) -> str:
    """Complete a short RAG definition response without inventing citations.

    The canonical paper supports the retriever/generator and external-memory
    explanation. The added paragraphs are explicitly labelled as general
    background so implementation details such as chunking or vector stores do
    not get misrepresented as claims from a fixed paper.
    """
    base = str(text or "").strip().rstrip("-— ")
    supplement = (
        "\n\n## 通俗流程示例\n"
        "假设知识库中有一份产品说明书，用户问‘设备 X 的保修期多长？’。系统先把问题交给检索器，"
        "从外部索引中找出与‘设备 X’和‘保修期’最相关的文本片段；然后把问题、这些片段和已生成的前缀"
        "一起交给生成器，生成只基于检索证据的回答。如果检索不到相关片段，系统应明确说明证据不足，"
        "而不是把模型记忆中的猜测当成资料结论。\n\n"
        "## 工程实现中的常见步骤（通用背景）\n"
        "实际系统通常先把文档清洗并切分成片段，再用 embedding 模型把片段写入向量索引；查询到来时，"
        "同一个 embedding 模型把问题编码后执行相似度检索，必要时再用 reranker 进行重排，最后把通过筛选的"
        "片段放入生成提示词。切分长度、top-K、索引类型和重排器属于具体系统设计，并不是 RAG 定义本身，"
        "也不能仅凭这篇论文确定某个项目必须使用哪一种配置。\n\n"
        "## 主要优势与局限\n"
        "优势是外部记忆可以独立更新，回答可以带着可追溯证据，且模型不必把所有知识都压进参数中。局限包括："
        "检索不到正确片段时生成器仍可能答错；检索片段过多会挤占上下文；索引质量、文档新旧程度和权限控制会直接影响结果。"
        "因此可靠的 RAG 系统还需要记录来源、检查证据覆盖，并在证据不足时返回不确定性提示。\n\n"
        "## 论文依据边界\n"
        "上面的定义、检索器/生成器组成、RAG-Sequence 与 RAG-Token 两种形式，以及非参数化记忆可替换等内容，"
        "由 [1] 的官方论文支持。文档切分、embedding、向量数据库和 reranker 是为帮助理解而给出的通用工程背景，"
        "不应被当作该论文逐字报告的实验设置。"
    )
    return base + supplement


def _build_empty_answer_fallback(query: str, evidence_ledger: list[dict], model_error: str | None = None) -> str:
    """Return a topic-correct, conservative answer when the gateway is empty.

    This path is intentionally deterministic.  It must never reuse a RAG
    answer for an unrelated scientific question just because the answer
    gateway returned only hidden reasoning or an empty content field.
    """
    lowered = str(query or "").lower()
    citation = "[1]" if evidence_ledger else ""
    prefix = (
        f"回答模型请求失败（{model_error}）。" if model_error else
        "回答模型未返回可显示的正文。"
    )
    if any(term in lowered for term in ("transformer", "self-attention", "self attention", "attention")):
        body = (
            "Transformer 是一种以注意力机制为核心的序列建模架构，最初由《Attention Is All You Need》提出。"
            f"在已取得的官方论文证据中{citation}，编码器和解码器都由重复堆叠的 Transformer 层组成。"
            "每层通常包含多头自注意力、逐位置前馈网络、残差连接和层归一化；解码器还包含对编码器输出的交叉注意力。\n\n"
            "自注意力的基本计算是：Attention(Q,K,V) = softmax(QK^T / sqrt(d_k))V。"
            "输入序列分别经过线性映射得到 Query、Key、Value；Q 与所有 K 的点积表示相关性，"
            "除以 sqrt(d_k) 防止维度增大导致 softmax 过度饱和，再用 softmax 得到权重并对 V 加权求和。"
            "多头注意力把表示拆成多个子空间并行计算，最后拼接并线性变换。\n\n"
            "与 RNN 相比，Transformer 不需要按时间步串行传递隐藏状态，因此训练时更容易并行化，"
            "并能通过注意力直接建立远距离 token 之间的依赖；代价是标准全局自注意力的计算和显存通常随序列长度平方增长。\n\n"
            "以上是基于已取得论文证据的保守说明；由于回答模型本次未返回完整正文，"
            "这里不扩展到未核验的实验数字、页码或图表细节。"
        )
    elif "rag" in requested_concepts(query):
        body = (
            "RAG（Retrieval-Augmented Generation）将生成模型的参数化记忆与从外部索引检索到的非参数化记忆结合，"
            f"再把相关文档片段作为上下文辅助生成回答{citation}。当前回答模型未返回完整正文，"
            "因此这里只保留可由已取得论文证据支持的简要说明。"
        )
    else:
        body = (
            "已取得官方科学文献证据，但回答模型未返回可显示的完整正文。"
            "为避免编造，当前只报告这一状态，不对未验证细节作扩展解释。"
        )
    return prefix + "\n\n" + body + "\n\n" + build_science_evidence_notice(evidence_ledger)


# --- Honest refusal text -----------------------------------------------------
# A refusal must let a user tell "the sources were unreachable" apart from
# "the sources answered but nothing was relevant". A blanket "检索到 0 篇"
# would hide a network outage on a well-studied topic behind a misleading
# "no literature found". These helpers build the per-source, three-case text
# and are pure over diagnostics so they can be unit-tested offline.

_SOURCE_STATUS_LABELS = {
    "ok": "正常",
    "error": "网络错误",
    "rate_limited": "限流",
    "source_unreachable": "不可用",
    "access_blocked": "访问被拒",
    "disabled": "已停用",
    "skipped": "本轮跳过",
    "cooling_skip": "本轮跳过（冷却）",
    "invalid_query": "查询被拒",
}
_FAILED_SOURCE_STATUSES = {"error", "rate_limited", "source_unreachable", "access_blocked"}
_REJECTION_REASON_LABELS = {
    "below_threshold": "相关性分数低于阈值",
    "named_object_missing": "未同时覆盖问题提到的对象（如对比双方）",
    "domain_mismatch": "领域不符",
    "missing_relation_evidence": "缺少关系证据",
    "no_specific_subject_coverage": "未覆盖问题中的具体对象",
    "no_direct_limitation_evidence": "缺少直接的局限/差异证据",
    "no_english_concept_bridge": "无英文概念锚点",
    "generic_relation_only": "仅关系词、无具体实体",
    "ambiguous_abbreviation_without_context": "高歧义缩写但缺少该领域限定词（疑似同名文献）",
}


def _trim_reason(text, limit: int = 140) -> str:
    text = str(text or "").strip()
    return text if len(text) <= limit else text[: limit - 1] + "…"


def _missing_evidence_summary(diagnostics: dict) -> str:
    """Aggregate why rejected candidates failed, so the user sees what was missing."""
    counts = {}
    for item in diagnostics.get("candidate_scores") or []:
        if item.get("final_accepted"):
            continue
        reason = str(item.get("rejection_reason") or "").strip()
        # The lexical abbreviation rule records "rule:token (detail)"; group
        # every collision token under one auditable Chinese label.
        if reason.startswith("ambiguous_abbreviation_without_context"):
            reason = "ambiguous_abbreviation_without_context"
        if reason:
            counts[reason] = counts.get(reason, 0) + 1
    if not counts:
        return ""
    detail = "、".join(
        f"{_REJECTION_REASON_LABELS.get(reason, reason)}（{count} 篇）"
        for reason, count in sorted(counts.items(), key=lambda pair: -pair[1])
    )
    return f"被拒候选的主要类型：{detail}。"


def _format_source_outcome(source: str, rec: dict) -> str:
    label = _SOURCE_STATUS_LABELS.get(rec["status"], rec["status"])
    detail = rec.get("skip_reason") or (
        (rec.get("error") or rec.get("search_error") or "") if rec["status"] in _FAILED_SOURCE_STATUSES else ""
    )
    if rec["returned"] > 0:
        base = f"- {source}：返回 {rec['returned']} 篇候选，{rec['accepted_total']} 篇通过相关性门控"
    else:
        base = f"- {source}：未返回候选"
    if label == "正常" and not detail:
        return base
    suffix = f"（{label}" + (f"：{_trim_reason(detail)}" if detail else "") + "）"
    return base + suffix


def _build_insufficient_evidence_answer(diagnostics: dict, sufficiency: dict) -> str:
    """Build an honest refusal that separates source failure from missing evidence.

    Three distinguishable cases:
      (a) sources were unreachable - the search could not complete, so the
          absence of papers proves nothing ("不能据此判断没有相关论文");
      (b) sources answered but nothing passed the relevance gate;
      (c) a few papers passed but fewer than the required minimum.
    Every case lists which sources were queried and what each returned.
    """
    rounds = diagnostics.get("rounds") or []
    per_source = {}
    for item in rounds:
        source = str(item.get("source") or "").strip()
        if not source:
            continue
        rec = per_source.setdefault(source, {
            "returned": 0, "accepted_total": 0, "max_score": 0.0,
            "status": str(item.get("source_status") or "unknown"),
            "error": "", "skip_reason": "",
        })
        rec["returned"] += int(item.get("returned") or 0)
        rec["accepted_total"] = max(rec["accepted_total"], int(item.get("accepted_total") or 0))
        rec["max_score"] = max(rec["max_score"], float(item.get("max_score") or 0.0))
        if item.get("search_error"):
            rec["error"] = str(item["search_error"])
        if item.get("skip_reason"):
            rec["skip_reason"] = str(item["skip_reason"])
        status = str(item.get("source_status") or "unknown")
        if status in _FAILED_SOURCE_STATUSES | {"ok"}:
            rec["status"] = status
        elif status == "invalid_query" and rec["status"] not in _FAILED_SOURCE_STATUSES | {"ok"}:
            rec["status"] = "invalid_query"
        elif status == "skipped" and rec["status"] not in _FAILED_SOURCE_STATUSES | {"ok"}:
            rec["status"] = "skipped"
        combined_note = str(rec.get("error") or "") + str(rec.get("skip_reason") or "")
        if "statically disabled" in combined_note:
            # A configuration-parked source must read as a stable "disabled"
            # state, not the generic temporary "skipped this round" wording.
            rec["status"] = "disabled"
            rec["skip_reason"] = (
                "该源在本部署中已配置停用，未发起查询"
                "（如需启用，请设置 LITERATURE_DISABLED_SOURCES 后重启）"
            )
        elif status == "cooling_skip" and rec["status"] not in _FAILED_SOURCE_STATUSES | {"ok"}:
            rec["status"] = "cooling_skip"

    failed_sources = [
        (source, rec) for source, rec in per_source.items()
        if rec["status"] in _FAILED_SOURCE_STATUSES
    ]
    any_returned = any(rec["returned"] > 0 for rec in per_source.values())
    accepted = int(sufficiency.get("paper_count") or 0)
    minimum = int(sufficiency.get("minimum_required") or 0)
    threshold = float(diagnostics.get("relevance_threshold") or get_relevance_threshold())

    source_lines = "\n".join(
        _format_source_outcome(source, rec) for source, rec in per_source.items()
    )
    close = "为避免基于不充分的材料得出结论，本次不生成综合分析。"
    if not per_source:
        return ("本次文献检索未返回任何来源结果。\n\n已查询来源：\n（无）\n\n" + close)

    if failed_sources and not any_returned:
        head = (
            "本次文献检索未能完成：以下来源当前不可用，不能据此判断没有相关论文。\n"
            + "\n".join(
                f"- {source}：{_trim_reason(rec['error'] or rec['status'])}"
                for source, rec in failed_sources
            )
        )
    elif not any_returned:
        head = "本次检索未返回任何候选文献，未找到足够相关文献。"
    else:
        missing = _missing_evidence_summary(diagnostics)
        total_returned = sum(rec["returned"] for rec in per_source.values())
        if accepted == 0:
            # The evidence-ledger count (after fulltext/semantic admission) may
            # be 0 while a source still passed the relevance gate. Do not tell
            # the user "均未通过相关性门控" in that case - it contradicts the
            # per-source breakdown right below it.
            gate_accepted = 0
            seen_gate = set()
            for item in diagnostics.get("candidate_scores") or []:
                pid = str(item.get("paper_id") or "").strip().lower()
                # Count the relevance-gate verdict (lexical_accepted) - the
                # same layer the per-source breakdown reports. final_accepted
                # may be False because the later semantic/fulltext stage
                # rejected the paper; that is exactly the case the wording
                # below ("账本构建后可用 0 篇") explains.
                gate_ok = item.get("lexical_accepted")
                if gate_ok is None:
                    gate_ok = item.get("final_accepted")
                if pid and gate_ok and pid not in seen_gate:
                    seen_gate.add(pid)
                    gate_accepted += 1
            if gate_accepted > 0:
                head = (
                    f"已完成检索：共检索到 {total_returned} 篇候选文献，其中 {gate_accepted} 篇通过相关性门控，"
                    "但在证据账本构建后可用 0 篇（全文解析或语义核验未通过），未找到足够相关文献。"
                )
            else:
                head = (
                    f"已完成检索：共检索到 {total_returned} 篇候选文献，"
                    f"均未通过相关性门控（阈值 {threshold}），未找到足够相关文献。"
                )
        else:
            head = (
                f"已完成检索：{accepted} 篇候选文献通过相关性门控（阈值 {threshold}），"
                f"少于回答所需的 {minimum} 篇。"
            )
        if missing:
            head += "\n" + missing
    return f"{head}\n\n已查询来源：\n{source_lines}\n\n{close}"


def _degraded_answer_prefix(search_diagnostics: dict, paper_count: int) -> str:
    """Caveat prefix for a partial-coverage answer.

    Two degraded cases are distinguished:
      (a) preferred_source_failed_partial_evidence - some source was down, so
          the answer is built on whatever the remaining sources returned.
      (b) insufficient_evidence_partial - all sources worked but fewer than
          the minimum papers passed the relevance gate.
    The wording must not blame a source outage when the sources were fine.
    Returns "" when this run did not take the degraded-answer path.
    """
    degraded = search_diagnostics.get("degraded_answer") or {}
    reason = degraded.get("reason")
    if reason not in ("preferred_source_failed_partial_evidence", "insufficient_evidence_partial"):
        return ""
    if reason == "preferred_source_failed_partial_evidence":
        failed_names = "、".join(dict.fromkeys(
            str(item.get("source") or "").strip()
            for item in degraded.get("source_failures") or []
            if str(item.get("source") or "").strip()
        ))
        failed_names = failed_names or "部分文献源"
        return (
            f"【降级回答】文献源（{failed_names}）本次检索不可用，以下结论仅基于其余可用来源提供的 "
            f"{paper_count} 篇经完整证据核验后可用的论文，证据覆盖低于正常要求，结论置信度受限，"
            "建议稍后重试以获取完整检索。"
        )
    # insufficient_evidence_partial: sources worked, but too few papers passed.
    minimum = degraded.get("minimum_required") or 2
    return (
        f"【降级回答】本次检索仅找到 {paper_count} 篇通过相关性门控的论文"
        f"（正常要求至少 {minimum} 篇），以下结论基于有限证据，覆盖范围和置信度受限，"
        "建议换用更具体的关键词或稍后重试以获取更完整的文献覆盖。"
    )


def _record_search_diagnostics_snapshot(search_diagnostics: dict) -> None:
    """Persist a condensed, query-side audit of a literature search.

    The per-task JSONL normally only sees stage events, and the follow-up JSON
    snapshot is skipped on failed rounds - so a failed round leaves no record
    of what each source actually queried or how candidates scored. This
    snapshot is written on every terminal path (success, refusal, degraded)
    so every round stays attributable: per-source adapter_query, candidate
    scores, and the query plan.
    """
    if not search_diagnostics:
        return
    rounds = []
    for item in search_diagnostics.get("rounds") or []:
        rounds.append({
            "round": item.get("round"), "source": item.get("source"),
            "adapter_query": item.get("adapter_query"),
            "returned": item.get("returned"), "accepted_total": item.get("accepted_total"),
            "max_score": item.get("max_score"), "source_status": item.get("source_status"),
            "search_error": item.get("search_error"),
        })
    candidates = []
    for item in (search_diagnostics.get("candidate_scores") or [])[:60]:
        candidates.append({
            "paper_id": item.get("paper_id"), "title": str(item.get("title") or "")[:120],
            "score": item.get("score"), "final_accepted": item.get("final_accepted"),
            "rejection_reason": item.get("rejection_reason"),
            "rejection_stage": item.get("rejection_stage"),
        })
    record_diagnostic(
        "search_diagnostics_snapshot", "completed", source="run_demo",
        query_plan=search_diagnostics.get("query_plan"),
        query_groups=search_diagnostics.get("query_groups"),
        requested_concepts=search_diagnostics.get("requested_concepts"),
        rounds=rounds, candidate_scores=candidates,
    )


def _search_rounds_of(response) -> int | None:
    """Retrieval rounds from a response's diagnostics, if present."""
    if response.result and isinstance(response.result, dict):
        value = (response.result.get("search_diagnostics") or {}).get("search_rounds")
        if isinstance(value, int):
            return value
    return None


# Relaxed lexical-gate thresholds for degraded-search recovery.
# Pass 1 is the normal bar (relevance threshold default 0.35, minimum 2).
# Pass 2 is an automatic broader sweep at 0.28 with a 1-paper minimum.
# Pass 3 is a user-requested lower-standard sweep (CLI flag) at 0.22.
# These are starting values to tune from real traffic; they never bypass
# the semantic judge, which still runs unchanged on every admitted paper.
BROADEN_RELEVANCE_THRESHOLD = float(os.getenv("LITERATURE_BROADEN_THRESHOLD", "0.28"))
RELAXED_RELEVANCE_THRESHOLD = float(os.getenv("LITERATURE_RELAXED_THRESHOLD", "0.22"))

# Process-wide gate state for a user-requested lower-standard (third) pass.
# When relaxed, the automatic in-task broaden sweep is skipped because this run
# already IS the lowest-standard pass.
_ACTIVE_MIN_EVIDENCE: "int | None" = None
_GATE_RELAXED = False


def configure_gate(threshold: "float | None" = None, minimum_evidence: "int | None" = None) -> bool:
    """Apply a process-wide relaxed relevance gate; returns whether the gate is relaxed."""
    global _ACTIVE_MIN_EVIDENCE, _GATE_RELAXED
    if threshold is not None:
        set_relevance_threshold(float(threshold))
        _GATE_RELAXED = True
    if minimum_evidence is not None:
        _ACTIVE_MIN_EVIDENCE = max(1, int(minimum_evidence))
    return _GATE_RELAXED


def run_science_literature_query(query: str, config, visualizer: DemoVisualizer) -> AgentResponse:
    """Answer a general scientific question using arXiv metadata and one PDF."""
    start_time = time.time()
    phase_started = time.monotonic()
    timings = {"search_seconds": 0.0, "evidence_seconds": 0.0, "model_seconds": 0.0}
    try:
        tools = MCPTools()
        explicit_arxiv_ids = extract_explicit_arxiv_ids(query)
        source = "arxiv" if explicit_arxiv_ids else preferred_literature_source(query)
        prefetch_path = Path(os.getenv("SCIASSISTANT_PREFETCH_PATH", ""))
        prefetched = None
        if prefetch_path.is_file():
            try:
                candidate = json.loads(prefetch_path.read_text(encoding="utf-8"))
                if candidate.get("query") == query and candidate.get("source") == source:
                    prefetched = candidate
            except (OSError, ValueError, TypeError):
                pass
        if prefetched:
            papers = list(prefetched.get("papers") or [])
            search_diagnostics = dict(prefetched.get("diagnostics") or {})
            search_cache_hit = False
            record_diagnostic("literature_presearch_reuse", "completed", source=source,
                              papers=len(papers), reason="web pre-search result reused")
        else:
            with diagnostic_stage("literature_search", source=source):
                try:
                    papers, search_diagnostics, search_cache_hit = _search_relevant_literature(
                        query, source, tools, config, minimum_evidence=_ACTIVE_MIN_EVIDENCE
                    )
                except Exception as _exc:
                    import traceback as _tb
                    logging.getLogger(__name__).error(
                        "literature_search failed with %s: %s\n%s",
                        type(_exc).__name__, _exc, _tb.format_exc()
                    )
                    raise
        evidence_cache_hit = False
        timings["search_seconds"] = round(time.monotonic() - phase_started, 3)
        # Too few accepted papers is a different outcome from a failed search:
        # the sources answered, but there is not enough material to answer from.
        # Saying so is honest; generating a report from one weak paper is not.
        # The count may be zero: "below the threshold" includes finding nothing,
        # and answering a literature question from no literature at all is the
        # case this refusal most needs to cover.
        # Automatic broader second pass. When the normal gate yields too
        # little evidence (0 papers, or a degraded 1-paper result), re-run the
        # bounded ladder once at a relaxed lexical threshold with a 1-paper
        # minimum, before falling back to a refusal / degraded answer. The
        # semantic judge still runs unchanged. Explicit arXiv-ID requests are
        # user-selected papers and must not be broadened.
        if (
            not explicit_arxiv_ids
            and not _GATE_RELAXED
            and (search_diagnostics.get("evidence_sufficiency") or {}).get("status")
            == "insufficient_evidence"
            and not search_diagnostics.get("broadened_pass")
        ):
            record_diagnostic(
                "literature_broaden_pass", "started", source=source,
                reason="automatic broader second pass at relaxed threshold",
                threshold=BROADEN_RELEVANCE_THRESHOLD,
            )
            _prev_threshold = get_relevance_threshold()
            set_relevance_threshold(BROADEN_RELEVANCE_THRESHOLD)
            # Broaden pass gets more retrieval rounds so later, more specific
            # query facets (especially underrepresented groups) get a chance
            # to run before the pool cap stops the ladder.
            from deepdiver_v2.src import query_router as _qr
            _prev_rounds = _qr.MAX_RETRIEVAL_ROUNDS
            _qr.MAX_RETRIEVAL_ROUNDS = max(_prev_rounds, 8)
            try:
                broad_papers, broad_diag, _ = _search_relevant_literature(
                    query, source, tools, config, minimum_evidence=1
                )
            finally:
                set_relevance_threshold(_prev_threshold)
                _qr.MAX_RETRIEVAL_ROUNDS = _prev_rounds
            broad_diag = dict(broad_diag)
            broad_diag["broadened_pass"] = {
                "trigger": "insufficient_evidence_after_normal_pass",
                "threshold": BROADEN_RELEVANCE_THRESHOLD,
                "minimum_evidence": 1,
                "normal_papers": len(papers),
                "broadened_papers": len(broad_papers),
            }
            record_diagnostic(
                "literature_broaden_pass", "completed", source=source,
                normal_papers=len(papers), broadened_papers=len(broad_papers),
                reason="broader second pass finished",
            )
            # Adopt the broader result when it recovered at least as much
            # evidence; otherwise keep the original paper set while still
            # recording that the broaden pass ran and found nothing new.
            if len(broad_papers) >= len(papers):
                papers, search_diagnostics = broad_papers, broad_diag
            else:
                search_diagnostics = broad_diag
        if (search_diagnostics.get("evidence_sufficiency") or {}).get("status") == "insufficient_evidence":
            sufficiency = search_diagnostics["evidence_sufficiency"]
            # P7: a preferred-source failure that still left at least one
            # high-quality paper through the gate should not be flattened into
            # a refusal. Degrade visibly: continue with the available paper(s)
            # and attach a coverage caveat, instead of hiding the material.
            source_failures = [
                item for item in (search_diagnostics.get("rounds") or [])
                if item.get("source_status") not in {"disabled", "invalid_query", "cooling_skip"}
                and item.get("search_error")
            ]
            degraded = int(sufficiency.get("paper_count") or 0) >= 1
            if not degraded:
                response = AgentResponse(
                    success=False,
                    result={
                        "task_name": "science_literature_answer",
                        "completion_status": "insufficient_evidence",
                        # Search diagnostics stay out of the user-facing answer:
                        # they remain in result.search_diagnostics and in the
                        # per-task JSONL (web_task_*.diagnostics.jsonl), which the
                        # conversation export attaches verbatim.
                        "final_answer": _build_insufficient_evidence_answer(search_diagnostics, sufficiency),
                        "evidence_ledger": [],
                        "evidence_sufficiency": sufficiency,
                        "search_diagnostics": search_diagnostics,
                        "papers": [],
                    },
                    iterations=1, execution_time=time.time() - start_time,
                    agent_name="ScienceLiteratureAssistant",
                )
                _record_search_diagnostics_snapshot(search_diagnostics)
                visualizer.show_final_result(response)
                return response
            # Degraded path: record why and continue with the available
            # evidence; the coverage caveat is attached to the final answer.
            # Two distinct cases: (a) some source failed, (b) sources all
            # worked but too few papers passed the gate. Both deserve a
            # visible caveat, but the wording must not blame a source outage
            # when the sources were fine.
            search_diagnostics = dict(search_diagnostics)
            if source_failures:
                _degraded_reason = "preferred_source_failed_partial_evidence"
            else:
                _degraded_reason = "insufficient_evidence_partial"
            search_diagnostics["degraded_answer"] = {
                "reason": _degraded_reason,
                "paper_count": int(sufficiency.get("paper_count") or 0),
                "minimum_required": int(sufficiency.get("minimum_required") or 0),
                "source_failures": [
                    {"source": item["source"], "status": item.get("source_status"), "error": item.get("search_error")}
                    for item in source_failures
                ],
            }
        if not papers:
            return _run_unreferenced_general_answer(query, config, visualizer, search_diagnostics)

        # Only relevance-approved papers can enter the evidence ledger or be
        # read in full. Search candidates below the gate remain diagnostics.
        if not papers:
            response = AgentResponse(
                success=False,
                error="未检索到可用的官方科学文献；为避免无来源编造，未生成科研结论。",
                result={
                    "task_name": "science_literature_answer",
                    "completion_status": "partial",
                    "final_answer": "未检索到可用的官方文献证据，因此无法可靠回答该科研问题。请缩小关键词或稍后重试。",
                    "route": "science_literature",
                    "evidence_mode": f"{source}_no_results",
                    "search_cache_hit": search_cache_hit,
                    "evidence_cache_hit": evidence_cache_hit,
                    "timings": {**timings, "total_seconds": round(time.time() - start_time, 3)},
                    "papers": [], "search_diagnostics": search_diagnostics,
                },
                iterations=1, execution_time=time.time() - start_time,
                agent_name="ScienceLiteratureAssistant",
            )
            visualizer.show_final_result(response)
            return response

        # Read evidence in batches.  A first batch of five is normally enough,
        # but weak/failed evidence triggers another distinct batch.  Never
        # exceed fifteen papers in one task, and de-duplicate versioned IDs.
        unique_papers = []
        seen_paper_ids = set()
        for paper in papers:
            current_id = str(paper.get("paper_id", "") or paper.get("id", "")).strip()
            base_id = current_id.lower().split("v", 1)[0]
            paper_source = str(paper.get("source") or source).lower()
            # Version de-duplication is scoped to a source.  A HAL/Zenodo
            # record may legitimately have the same local-looking ID as an
            # arXiv record, and must not erase the other source's evidence.
            paper_key = f"{paper_source}:{base_id}"
            if current_id and paper_key not in seen_paper_ids:
                seen_paper_ids.add(paper_key)
                unique_papers.append(paper)
        evidence_papers = unique_papers[:15]
        broad_evidence_request = bool(search_diagnostics.get("broad_evidence_request"))
        batch_size = 5
        selected = evidence_papers[0]
        paper_id = selected.get("paper_id")
        evidence_started = time.monotonic()
        evidence_cache_hit = False
        evidence_by_id = {}
        with diagnostic_stage("fulltext_download_and_parse", source=source,
                              paper_limit=len(evidence_papers), batch_size=batch_size,
                              pdf_parse_mode=get_config().pdf_parse_mode):
            for batch_start in range(0, len(evidence_papers), batch_size):
                batch = evidence_papers[batch_start:batch_start + batch_size]
                batch_index = batch_start // batch_size + 1
                batch_fulltext = 0
                batch_text = []
                for evidence_paper in batch:
                    current_id = evidence_paper.get("paper_id")
                    evidence_source = str(evidence_paper.get("source") or source)
                    if not current_id:
                        continue
                    cached_evidence = get_paper_evidence_cache(
                        evidence_source, current_id, get_config().pdf_parse_mode
                    )
                    if cached_evidence is not None:
                        evidence_cache_hit = True
                        item_evidence = cached_evidence
                        record_diagnostic("fulltext_paper", "completed", source=source,
                                          paper_id=current_id, batch=batch_index, reason="cache_hit")
                    else:
                        parsed_item = {}
                        fulltext_item = {}
                        record_diagnostic("fulltext_paper", "started", source=source,
                                          paper_id=current_id, batch=batch_index)
                        paper_read = (
                            tools.arxiv_read_paper(
                                current_id,
                                pdf_parse_mode=get_config().pdf_parse_mode,
                            )
                            if evidence_source == "arxiv" else None
                        )
                        if paper_read and paper_read.success and isinstance(paper_read.data, dict):
                            parsed_item = paper_read.data
                        if evidence_source in {"zenodo", "techrxiv", "hal"}:
                            try:
                                public = download_public_pdf(evidence_paper, Path(os.getenv("SCIASSISTANT_WORKSPACE", str(repo_root / "workspace"))) / "literature")
                                if public.get("download_status") == "downloaded":
                                    from pdf_pipeline import parse_pdf, build_parse_metadata
                                    parsed_pdf = parse_pdf(public["pdf_path"])
                                    if parsed_pdf.get("success"):
                                        parsed_item = {**parsed_pdf, "paper": parsed_pdf.get("text", ""), "parse_metadata": build_parse_metadata(parsed_pdf, preview_chars=300), "pdf_path": public["pdf_path"]}
                            except Exception as exc:
                                fulltext_item = {"error": str(exc)}
                        if evidence_source == "pubmed":
                            article_result = tools.get_pubmed_article(current_id)
                            if article_result and article_result.success and isinstance(article_result.data, dict):
                                fulltext_item = article_result.data
                        item_evidence = {"parsed": parsed_item, "fulltext": fulltext_item}
                        if parsed_item or fulltext_item.get("content"):
                            put_paper_evidence_cache(
                                evidence_source, current_id, item_evidence, get_config().pdf_parse_mode,
                            )
                        record_diagnostic(
                            "fulltext_paper", "completed", source=source, paper_id=current_id,
                            batch=batch_index,
                            reason=("parsed" if parsed_item or fulltext_item.get("content") else
                                    (getattr(paper_read, "error", "fulltext_unavailable") or "fulltext_unavailable")),
                        )
                    evidence_by_id[f"{evidence_source}:{str(current_id).lower().split('v', 1)[0]}"] = item_evidence
                    if item_evidence.get("parsed") or (item_evidence.get("fulltext") or {}).get("content"):
                        batch_fulltext += 1
                        parsed_text = (item_evidence.get("parsed") or {}).get("paper", "")
                        fulltext_text = (item_evidence.get("fulltext") or {}).get("content", "")
                        batch_text.append(f"{parsed_text} {fulltext_text}")
                # Stop only when this batch provides usable, concept-bearing
                # evidence. Otherwise continue with five new papers.
                # Use English retrieval terms for fulltext matching: the raw
                # user query may be Chinese (e.g. "ai生图检测") and would
                # never match English PDF text, making matched_terms always 0.
                _plan_terms = []
                for _plan_item in (search_diagnostics.get("query_plan") or []):
                    _pq = str(_plan_item.get("query") or "")
                    if re.search(r"[A-Za-z]{3,}", _pq):
                        _plan_terms.append(_pq)
                _match_source = " ".join(_plan_terms) if _plan_terms else query
                query_terms = [
                    token.lower() for token in re.findall(r"[A-Za-z][A-Za-z0-9-]{2,}|[\u4e00-\u9fff]{2,}", _match_source)
                ]
                # Prefer core terms from query_groups for matching: generic
                # words like "limitations", "model", "learning" appear in
                # nearly every paper and would make the stop trigger fire too
                # early on weak evidence. Core terms are the concrete entities
                # the user actually asked about.
                _groups = search_diagnostics.get("query_groups") or CURRENT_QUERY_GROUPS or []
                _core_terms = []
                for _g in _groups:
                    _c = str(_g.get("core") or "").strip().lower()
                    if _c and re.search(r"[a-z]{3,}", _c):
                        _core_terms.append(_c)
                combined_batch_text = " ".join(batch_text).lower()
                if _core_terms:
                    matched_terms = sum(1 for token in set(_core_terms) if token in combined_batch_text)
                    required_terms = min(1, len(set(_core_terms)))
                else:
                    matched_terms = sum(1 for token in set(query_terms) if token in combined_batch_text)
                    required_terms = min(2, len(set(query_terms))) if query_terms else 1
                # Treat a batch as answerable only when it has several usable
                # full texts and covers at least one core entity (or two
                # generic terms when no groups exist).
                # A one-paper result is the only deliberate exception.
                required_fulltext = 1 if len(batch) == 1 else min(3, len(batch))
                batch_answerable = bool(
                    batch_fulltext >= required_fulltext
                    and matched_terms >= required_terms
                )
                record_diagnostic(
                    "fulltext_batch", "completed", source=source, batch=batch_index,
                    papers=len(batch), fulltext_papers=batch_fulltext,
                    matched_query_terms=matched_terms, answerable=batch_answerable,
                    reason="evidence_sufficient" if batch_answerable else "evidence_insufficient_continue",
                )
                if batch_answerable and not broad_evidence_request:
                    break
        # Keep these names for downstream answer-quality checks: they refer to
        # the primary paper, while the prompt and ledger include all five.
        primary_source = str(selected.get("source") or source).lower()
        primary_evidence = evidence_by_id.get(f"{primary_source}:{str(paper_id).lower().split('v', 1)[0]}", {})
        parsed = primary_evidence.get("parsed", {})
        fulltext = primary_evidence.get("fulltext", {})
        has_any_fulltext = any(
            item.get("parsed") or (item.get("fulltext") or {}).get("content")
            for item in evidence_by_id.values()
        )
        timings["evidence_seconds"] = round(time.monotonic() - evidence_started, 3)
        # Build English query string for excerpt matching (Chinese query never matches English PDF text)
        _english_plan_terms = []
        for _plan_item in (search_diagnostics.get("query_plan") or []):
            _pq = str(_plan_item.get("query") or "")
            if re.search(r"[A-Za-z]{3,}", _pq):
                _english_plan_terms.append(_pq)
        _excerpt_query = " ".join(_english_plan_terms) if _english_plan_terms else query
        # Extract all query keywords from groups for per-paper matching disclosure.
        _all_query_keywords = []
        _groups_for_match = search_diagnostics.get("query_groups") or CURRENT_QUERY_GROUPS or []
        for _g in _groups_for_match:
            _c = str(_g.get("core") or "").strip().lower()
            if _c and re.search(r"[a-z]{3,}", _c):
                _all_query_keywords.append(_c)
            for _s in (_g.get("support") or []):
                _s = str(_s).strip().lower()
                if _s and re.search(r"[a-z]{3,}", _s) and _s not in _all_query_keywords:
                    _all_query_keywords.append(_s)
        # Also add plan queries as fallback keywords
        for _plan_item in (search_diagnostics.get("query_plan") or []):
            _pq = str(_plan_item.get("query") or "").strip().lower()
            if _pq and re.search(r"[a-z]{3,}", _pq) and _pq not in _all_query_keywords:
                _all_query_keywords.append(_pq)

        evidence_ledger = []
        context = []
        for index, paper in enumerate(evidence_papers, 1):
            current_id = str(paper.get("paper_id", ""))
            paper_source = str(paper.get("source") or source).lower()
            item_evidence = evidence_by_id.get(f"{paper_source}:{current_id.lower().split('v', 1)[0]}", {})
            parsed_item = item_evidence.get("parsed", {})
            fulltext_item = item_evidence.get("fulltext", {})
            # Compute which query keywords this paper actually matches,
            # checking title + abstract + available fulltext.
            _paper_text = " ".join([
                str(paper.get("title", "")),
                str(paper.get("abstract", "")),
                str(parsed_item.get("paper", "")),
                str(fulltext_item.get("content", "")),
            ]).lower()
            _matched = [kw for kw in _all_query_keywords if kw in _paper_text]
            evidence_ledger.append({
                # A positional marker keeps the existing [n] verification
                # working; the citable label is the verifiable one, so every
                # claim can be traced to a specific record rather than a
                # position that shifts between runs.
                "citation": f"[{index}]",
                "label": citation_label({"source": paper.get("source") or source,
                                         "paper_id": paper.get("paper_id", "")}),
                    "source": paper.get("source") or source,
                "paper_id": paper.get("paper_id", ""),
                "title": paper.get("title", ""),
                "access": "abstract_only",
                "official_url": paper.get("url", ""),
                "matched_keywords": _matched,
            })
            context.append(
                f"Paper [{index}] {paper.get('title', '')} ({paper.get('source') or source}:{current_id})\n"
                f"Abstract: {paper.get('abstract', '')[:1800]}"
            )
            if parsed_item:
                excerpt_limit = 6000 if len(evidence_papers) > 1 else (8000 if "rag" in requested_concepts(query) else (24000 if _is_explanatory_science_request(query) else 14000))
                parsed_excerpt = select_relevant_excerpt(parsed_item.get('paper') or '', _excerpt_query, excerpt_limit)
                context.append(
                    f"Paper [{index}] PDF extraction ({paper.get('source') or source}:{current_id})\n"
                    f"Parser status: {json.dumps(parsed_item.get('parse_metadata') or {}, ensure_ascii=False)[:4000]}\n"
                    f"Evidence excerpt metadata: {json.dumps({k: parsed_excerpt.get(k) for k in ('selected', 'truncated', 'matched_terms', 'character_count')}, ensure_ascii=False)}\n"
                    f"Text excerpt: {parsed_excerpt.get('text', '')}"
                )
                evidence_ledger[-1].update({
                    "access": "official_pdf_fulltext",
                    "parser_status": parsed_item.get("parse_metadata") or {},
                    "unreliable_content": (parsed_item.get("parse_metadata") or {}).get("risk_summary", {}),
                })
            if fulltext_item.get("content"):
                fulltext_excerpt = select_relevant_excerpt(fulltext_item.get('content') or '', _excerpt_query, 6000)
                context.append(
                    f"Paper [{index}] official full-text extraction ({source}:{current_id})\n"
                    f"Source URL: {fulltext_item.get('source_url', '')}\n"
                    f"Text excerpt: {fulltext_excerpt.get('text', '')}"
                )
                evidence_ledger[-1].update({
                    "access": "official_pmc_fulltext",
                    "pmc_id": fulltext_item.get("pmc_id", ""),
                    "official_url": fulltext_item.get("source_url", "") or evidence_ledger[-1]["official_url"],
                })
            if not parsed_item and not fulltext_item.get("content"):
                evidence_ledger[-1]["degradation_reason"] = "未取得可用全文，仅使用官方摘要和元数据。"
        model_config = config.get_custom_llm_config()
        model_url = os.getenv("MODEL_REQUEST_URL") or model_config.get("url", "")
        token = os.getenv("MODEL_REQUEST_TOKEN") or model_config.get("token", "")
        if not model_url:
            response = AgentResponse(
                success=False,
                error="MODEL_REQUEST_URL is not configured; scientific evidence was collected but no answer model is available.",
                result={
                    "task_name": "science_literature_answer",
                    "completion_status": "partial",
                    "final_answer": "已获得文献证据，但当前未配置回答模型，因此暂不能生成综合分析。\n\n" + build_science_evidence_notice(evidence_ledger),
                    "route": "science_literature",
                    "evidence_mode": f"{source}_evidence_collected_no_model",
                    "paper_id": paper_id,
                    "search_cache_hit": search_cache_hit,
                    "evidence_cache_hit": evidence_cache_hit,
                    "timings": {**timings, "total_seconds": round(time.time() - start_time, 3)},
                    "evidence_ledger": evidence_ledger,
                    "papers": papers,
                },
                iterations=1, execution_time=time.time() - start_time,
                agent_name="ScienceLiteratureAssistant",
            )
            visualizer.show_final_result(response)
            return response
        headers = {"Content-Type": "application/json"}
        if token:
            headers.update({"Authorization": f"Bearer {token}", "csb-token": token})
        fulltext_explanation_requirement = (
            "本次已有论文全文。对于解释、介绍、原理或机制类问题，正文必须是完整的研究笔记，不得只改写摘要："
            "至少依次说明定义与问题背景、论文提出的方法或推理过程、关键设计/实验设置、主要发现、适用范围与局限。"
            "在不把表格单元格和公式碎片当成精确证据的前提下，使用多个有内容的小节和段落展开；"
            "将‘部分解析失败说明’放在正文之后，不能用风险说明替代正文。"
            if has_any_fulltext and _is_explanatory_science_request(query) else ""
        )
        # Multi-part detection: be conservative. Two question marks reliably
        # indicate multiple sub-questions. Listing markers (、,，;；) alone
        # often just enumerate objects in a single question (e.g.
        # "Transformer、Mamba、RWKV 的区别"), so require either 3+ markers
        # or 2+ markers combined with a comparison signal word.
        _q = str(query or "")
        _listing_markers = len(re.findall(r"[、,，;；]", _q))
        _question_marks = _q.count("?") + _q.count("？")
        _comparison_words = any(w in _q for w in ("分别", "各自", "对比", "比较", "区别", "差异", "优缺点", "优劣"))
        multi_part_format = bool(
            _question_marks >= 2
            or _listing_markers >= 3
            or (_listing_markers >= 2 and _comparison_words)
        )
        followup_context = ""
        if CONVERSATION_CONTEXT.get("status") == "ready":
            followup_context = (
                "\n\n这是同一科研会话中的后续问题。以下内容只能作为上一轮上下文，不能视为本轮已验证证据：\n"
                f"上一轮问题：{CONVERSATION_CONTEXT.get('previous_query', '')}\n"
                f"上一轮意图：{json.dumps(CONVERSATION_CONTEXT.get('previous_intent') or {}, ensure_ascii=False)}\n"
                f"上一轮可识别论文 ID：{', '.join(CONVERSATION_CONTEXT.get('paper_ids') or []) or '未识别'}\n"
                f"上一轮回答摘录：{CONVERSATION_CONTEXT.get('previous_answer', '')}\n"
                "后续问题若只是追问，可复核并复用相关论文；若改变对象或范围，必须重新检索。"
            )
        prompt = (
            f"请用中文回答用户的科研问题。仅依据下面的 {source} 官方元数据和可用全文解析内容；"
            "【输出格式】必须输出一个 JSON 对象，不要输出任何 Markdown、代码围栏或解释文字。"
            "JSON 格式为 {\"sections\": [{\"title\": \"小节标题\", \"content\": \"小节内容\"}, ...]}。"
            "【内容排版要求】每个小节的 content 必须排版友好，禁止写成一大团："
            "(1) 段落之间用两个换行符分隔，每段不超过 4 句话；"
            "(2) 列举多个方法、对象、结论时，用 '- ' 开头的无序列表，每项一行；"
            "(3) 关键术语、方法名称、核心结论用 **加粗** 标注；"
            "(4) 有步骤或顺序时用 1. 2. 3. 有序列表；"
            "(5) 不同子主题之间用空行分隔，不要全部连在一起。"
            "第一个小节必须是'直接结论'，用 2-3 段实质性文字直接回答用户问题，给出明确结论和核心判断。"
            "所有论文相关事实用 [1]、[2]、[3] 标注。正文必须先解决问题，再说明证据边界；不要用'无法直接回答'作为开头。"
            + ("这是一个多子问题请求，JSON 的 sections 必须严格包含'直接结论'、'问题拆解'、'分项分析'、'综合判断'、'证据边界'这几个小节；"
               "在'分项分析'小节的 content 中按用户提出的每个对象或比较点分别回答，不能只按论文顺序罗列。"
               "'直接结论'的 content 必须有 2-3 段完整回答，不能空泛；'综合判断'的 content 必须总结各子问题的共性结论和差异，不能只重复前文。"
               if multi_part_format else "")
            + ("这是同一会话的追问。先用一两句话自然点明本轮承接的对象和直接答案；"
               "仅在有助于阅读时使用‘承接上一轮’、‘直接回答’或‘深入解释’小节，不要机械套用标题，"
               "不要重复上一轮完整报告，也不要再次罗列与本轮无关的证据账本。"
               if CONVERSATION_CONTEXT.get("status") == "ready" else "")
            + "PDF 解析存在双栏、公式、表格或 OCR 风险时，在 JSON 中加一个'部分解析失败说明'小节，不要补猜。"
            "JSON 的最后一个小节必须是'证据可用性'，content 中逐条说明每篇论文的全文/摘要状态、命中了哪些查询关键词（从证据账本的 matched_keywords 字段读取，用顿号分隔），以及无法可靠判断的内容。"
            "不要把通用背景知识伪装成论文结论；不要使用证据账本之外的论文。"
            "如果论文没有逐字回答用户原句，但其方法、实验、局限或讨论能够支持方向性判断，不能只输出‘无法直接回答’。"
            "此时必须在 JSON 中加一个'证据边界与模型推断'小节，content 按以下顺序组织："
            "(1) 先写'模型推断（基于上述证据）'，用 2-4 段把多个证据连接成有条件的回答，这是分析的主体；"
            "(2) 再用紧凑列表列出支撑该推断的关键论文证据（每条带 [n] 出处，不要大量空行）；(3) 最后列出仍不能由这些论文确认的部分。模型推断不得伪装成论文原文结论，必须使用'提示/表明/更可能/不能证明'等限定语。"
            "只有在证据账本完全没有相关方法、实验、讨论或全文内容时，才可以说明无法回答。"
            + fulltext_explanation_requirement +
            "不得因为主题名称常见就注入预设论文、作者或论文 ID；只能使用本轮证据账本中实际检索到的来源。"
            "若用户询问标准定义，而当前论文只涉及变体或应用，必须明确区分标准背景与论文证据，不能把预设经典论文当成本轮检索结果。"
            f"\n用户问题：{query}{followup_context}\n\n检索诊断：{json.dumps(search_diagnostics, ensure_ascii=False)[:7000]}"
            f"\n\n证据账本：{json.dumps(evidence_ledger, ensure_ascii=False)[:9000]}\n\n证据：\n" + "\n\n".join(context)
        )
        model_started = time.monotonic()
        # Keep enough room for long architecture explanations and their
        # evidence/diagnostic sections. The config caps this at 8192 by
        # default, while the completeness marker still reports hard limits.
        answer_limit = 8192
        request_payload = {"model": config.model_name, "messages": [{"role": "user", "content": prompt}], "temperature": 0.25, "max_tokens": min(int(model_config.get("max_tokens", 8192) or 8192), answer_limit), "thinking": {"type": "disabled"}, "enable_thinking": False, "reasoning_effort": "none"}
        answer = ""
        finish_reason = None
        model_error = None
        request_timeout = min(int(model_config.get("timeout", 60) or 60), 60)
        try:
            with diagnostic_stage("writer_model", source="answer_model", attempt=1):
                response = post_model_request(model_url, headers=headers, json=request_payload, timeout=request_timeout)
            response.raise_for_status()
            data = response.json()
            choice = (data.get("choices") or [{}])[0] if isinstance(data, dict) else {}
            answer = _extract_llm_text(data)
            if _looks_like_reasoning_leak(answer):
                answer = ""
            finish_reason = choice.get("finish_reason") if isinstance(choice, dict) else None
        except Exception as exc:
            # Gateways are not consistent: malformed JSON, missing choices,
            # and non-Chat-Completions payloads must be treated like an empty
            # answer so the evidence-backed fallback can run.
            model_error = str(exc)
        # Some DeepSeek-compatible gateways ignore ``thinking`` and spend the
        # whole completion budget on reasoning_content. Retry with both common
        # disable-thinking spellings and a smaller output budget so the model
        # has a clear incentive to emit the answer body.
        if not answer and model_error is None:
            retry_payload = dict(request_payload)
            retry_payload["thinking"] = {"type": "disabled"}
            retry_payload["enable_thinking"] = False
            retry_payload["reasoning_effort"] = "none"
            retry_payload["max_tokens"] = min(int(request_payload.get("max_tokens", 8192)), 3600)
            retry_payload["messages"] = [{"role": "system", "content": "只输出最终中文答案，不要输出思考过程、草稿或 reasoning_content。"}, {"role": "user", "content": prompt}]
            try:
                with diagnostic_stage("writer_model", source="answer_model", attempt=2):
                    retry_response = post_model_request(model_url, headers=headers, json=retry_payload, timeout=request_timeout)
                retry_response.raise_for_status()
                data = retry_response.json()
                choice = (data.get("choices") or [{}])[0]
                answer = _extract_llm_text(data)
                if _looks_like_reasoning_leak(answer):
                    answer = ""
                finish_reason = choice.get("finish_reason")
            except Exception as exc:
                model_error = str(exc)
        # Try to parse JSON answer and render to unified Markdown. If parsing
        # fails, fall back to the raw text (legacy Markdown path preserved).
        _json_parsed = _try_parse_json_answer(answer)
        if not _json_parsed:
            _json_parsed = _try_recover_truncated_sections(answer)
        _json_rendered = _render_json_answer(_json_parsed) if _json_parsed else None
        if _json_rendered:
            answer = _json_rendered
            answer_format = "json_structured"
        else:
            answer_format = "markdown_legacy"
        # A gateway may report ``stop`` even when it emits only a short first
        # section. For the canonical RAG definition request, make one focused
        # completion attempt before accepting that partial body.
        has_fulltext = has_any_fulltext
        quality_issue = _science_answer_quality_issue(answer, query, has_fulltext=has_fulltext)
        if answer and quality_issue and model_error is None and ("rag" in requested_concepts(query) or (has_fulltext and _is_explanatory_science_request(query))):
            supplement_payload = dict(request_payload)
            supplement_payload["max_tokens"] = min(int(request_payload.get("max_tokens", 5000)), 4200)
            supplement_payload["temperature"] = 0.05
            supplement_payload["enable_thinking"] = False
            supplement_payload["thinking"] = {"type": "disabled"}
            supplement_payload["reasoning_effort"] = "none"
            supplement_payload["messages"] = [
                {"role": "system", "content": (
                    "只输出完整的最终中文答案，不要输出思考过程。只使用给定论文证据，不能编造引用。"
                    + ("必须覆盖：RAG定义、参数化/非参数化记忆、索引、检索、生成、RAG-Sequence与RAG-Token、"
                       "训练方式、优势、局限和一个简短流程示例；正文至少分成 7 个清晰小节。" if "rag" in requested_concepts(query) else
                       "这是基于已解析全文的解释请求。必须覆盖：定义与研究问题、方法或核心机制、论文中的关键设计或论证、"
                       "实验/证据能够支持的主要结论、适用范围和局限；正文至少分成 5 个清晰小节，不能只复述摘要。"
                       "把 PDF 解析风险放到最后单独说明。")
                )},
                {"role": "user", "content": prompt},
            ]
            try:
                supplement_response = post_model_request(model_url, headers=headers, json=supplement_payload, timeout=request_timeout)
                supplement_response.raise_for_status()
                supplement_data = supplement_response.json()
                supplement_answer = _extract_llm_text(supplement_data)
                if not _looks_like_reasoning_leak(supplement_answer) and not _science_answer_quality_issue(supplement_answer, query, has_fulltext=has_fulltext):
                    answer = supplement_answer
                    choice = (supplement_data.get("choices") or [{}])[0]
                    finish_reason = choice.get("finish_reason")
                    quality_issue = None
            except requests.RequestException as exc:
                logger.warning("RAG completeness retry failed: %s", exc)
        if answer and quality_issue and "rag" in requested_concepts(query):
            # Do not expose a visibly cut-off draft. Add only deterministic,
            # clearly labelled material whose evidence boundary is explicit.
            answer = _complete_rag_answer(answer)
            quality_issue = None
            answer_completeness_override = {
                "finish_reason": finish_reason,
                "complete": False,
                "warning": "模型初稿偏短或异常结束，已追加保守的结构化说明；论文结论仍仅限于 [1] 支持范围",
                "quality_issue": quality_issue or "completed_with_conservative_supplement",
            }
        else:
            answer_completeness_override = None
        if not answer:
            # Keep a deterministic evidence-backed answer instead of turning a
            # transient gateway timeout/formatting issue into an empty report.
            if model_error and ("402" in model_error or "Payment Required" in model_error):
                timeout_note = (
                    "回答模型 API 返回 402（付费要求/额度不足）：通常是模型 API Key 余额耗尽或本月额度用完。"
                    "文献检索已正常完成，但生成正文所需的模型服务暂不可用，请联系管理员充值或更换 API Key 后重试。"
                )
            else:
                timeout_note = (
                    f"回答模型请求失败（{model_error}）。" if model_error else
                    "回答模型未返回可显示的正文。"
                )
            answer = _build_empty_answer_fallback(query, evidence_ledger, model_error)
            answer_completeness = {
                "finish_reason": finish_reason,
                "complete": False,
                "warning": "回答模型未能返回完整正文，已保留论文证据并标记为部分完成",
                "quality_issue": quality_issue,
            }
            citation_check = {"status": "unverified", "issues": ["answer_model_empty"]}
            result = AgentResponse(
                success=True,
                error="回答模型未返回正文（已保留证据）",
                result={"task_name": "science_literature_answer", "completion_status": "partial",
                        "final_answer": answer, "route": "science_literature",
                        "evidence_mode": f"{source}_evidence_collected_no_answer",
                        "paper_id": paper_id, "search_diagnostics": search_diagnostics,
                        "answer_completeness": answer_completeness, "evidence_ledger": evidence_ledger,
                        "citation_check": citation_check, "papers": papers,
                        "timings": {**timings, "total_seconds": round(time.time() - start_time, 3)}},
                iterations=1, execution_time=time.time() - start_time,
                agent_name="ScienceLiteratureAssistant",
            )
            _record_search_diagnostics_snapshot(search_diagnostics)
            visualizer.show_final_result(result)
            return result
        if answer_completeness_override is not None:
            answer_completeness = answer_completeness_override
        elif quality_issue:
            # Preserve the answer, but make the incompleteness explicit rather
            # than silently presenting a short body as a complete report.
            answer_completeness = {
                "finish_reason": finish_reason,
                "complete": False,
                "warning": "回答模型返回了正文，但结构或长度显示可能不完整",
                "quality_issue": quality_issue,
            }
        else:
            answer_completeness = None
        timings["model_seconds"] = round(time.monotonic() - model_started, 3)
        evidence_notice = build_science_evidence_notice(evidence_ledger)
        if "证据可用性" not in answer:
            answer += "\n\n" + evidence_notice
        citation_check = verify_science_citations(answer, evidence_ledger)
        citation_report = build_science_citation_report(citation_check)
        if citation_report:
            answer += "\n\n" + citation_report
        if answer_completeness is None:
            answer_completeness = {
                "finish_reason": finish_reason,
                "complete": finish_reason != "length",
                "warning": "回答可能因模型输出长度上限而不完整" if finish_reason == "length" else None,
            }
        # P7: attach the degradation caveat so a partial-coverage answer is
        # never presented as a full retrieval. The prefix names the sources
        # that actually failed (see _degraded_answer_prefix).
        degraded_prefix = _degraded_answer_prefix(search_diagnostics, len(papers))
        if degraded_prefix:
            answer = degraded_prefix + "\n\n" + answer
        answer += "\n\n## 文献来源\n" + "\n".join(
            f"[{i}] {paper.get('title', '')}. {source}:{paper.get('paper_id', '')}. {paper.get('url', '')}"
            for i, paper in enumerate(papers, 1)
        )
        # Build a single human-readable completeness section instead of
        # dumping raw JSON and then adding a duplicate heading on length cutoff.
        _completeness_lines = []
        if answer_completeness:
            _finish = answer_completeness.get("finish_reason") or "unknown"
            _complete = answer_completeness.get("complete")
            _warning = answer_completeness.get("warning")
            _quality = answer_completeness.get("quality_issue")
            _completeness_lines.append(f"- 模型结束原因：{_finish}")
            _completeness_lines.append(f"- 回答完整：{'是' if _complete else '否'}")
            if _warning:
                _completeness_lines.append(f"- 提示：{_warning}")
            if _quality:
                _completeness_lines.append(f"- 质量检查：{_quality}")
        if finish_reason == "length":
            _completeness_lines.append("- 模型达到输出长度上限，以上内容可能不完整，关键结论可能被截断。")
        answer += "\n\n## 回答完整性说明\n" + "\n".join(_completeness_lines)
        result = AgentResponse(
            success=True,
            result={"task_name": "science_literature_answer", "completion_status": "partial" if citation_check.get("status") == "unverified" else "completed", "final_answer": answer,
                    "route": "science_literature", "evidence_mode": f"{source}_metadata_and_fulltext" if has_any_fulltext else f"{source}_metadata_or_abstract", "paper_id": paper_id,
                    "search_cache_hit": search_cache_hit, "evidence_cache_hit": evidence_cache_hit,
                    "search_diagnostics": search_diagnostics, "answer_completeness": answer_completeness,
                    "answer_format": answer_format,
                    "timings": {**timings, "total_seconds": round(time.time() - start_time, 3)}, "evidence_ledger": evidence_ledger,
                    "citation_check": citation_check,
                    "parser_status": parsed.get("parse_metadata") if parsed else {}, "papers": papers},
            iterations=1, execution_time=time.time() - start_time, agent_name="ScienceLiteratureAssistant",
        )
        _record_search_diagnostics_snapshot(search_diagnostics)
        visualizer.show_final_result(result)
        return result
    except Exception as exc:
        response = AgentResponse(success=False, error=f"Science literature query failed: {exc}", iterations=1,
                                 execution_time=time.time() - start_time, agent_name="ScienceLiteratureAssistant")
        visualizer.show_final_result(response)
        return response

def is_bad_agent_answer(text: str) -> bool:
    if not text:
        return True
    if len(text) > 800 and text.count('"') > 80:
        return True
    bad_phrases = [
        "download_files",
        "document_qa",
        "工具成功",
        "ItThe tasks assigned",
        "or or or",
        "Please provide a clear description",
    ]
    return any(phrase in text for phrase in bad_phrases)


def load_environment_config(quiet: bool = False):
    """Load configuration from .env file"""
    try:
        # Private env files are optional. Container/process environment is
        # authoritative, and config.py already loads local fallback values.
        config_dir = Path(__file__).parent.parent / "config"
        env_file = config_dir / ".env"
        
        if not env_file.exists():
            if not quiet:
                console.print(f"[yellow]⚠️ No .env file found at {env_file}[/yellow]")
                console.print("[yellow]Using process environment and configuration defaults.[/yellow]")
        
        # Reload configuration to pick up .env file
        reload_config()
        config = get_config()
        
        if not quiet:
            console.print("[green]✅ Configuration loaded successfully[/green]")
        return config
        
    except Exception as e:
        if not quiet:
            console.print(f"[red]❌ Failed to load configuration: {e}[/red]")
        return None


def create_sample_env_file():
    """Create a sample .env file for demo purposes"""
    config_dir = Path(__file__).parent.parent / "config"
    env_file = config_dir / ".env"
    
    if env_file.exists():
        return
    
    # Copy from template
    template_file = Path(__file__).parent.parent / "env.template"
    if template_file.exists():
        import shutil
        shutil.copy2(template_file, env_file)
        console.print(f"[green]✅ Created .env file from template at {env_file}[/green]")
        console.print("[yellow]⚠️ Please edit the .env file with your actual configuration values[/yellow]")
    else:
        console.print(f"[red]❌ Could not find env.template to copy[/red]")


def create_demo_planner(config, quiet: bool = False):
    """Create the full PlannerAgent only when a query actually needs it."""
    if not quiet:
        console.print("[blue]🔄 Initializing PlannerAgent...[/blue]")

    sub_agent_configs = {
        "information_seeker": {
            "model": config.model_name,
            "max_iterations": config.information_seeker_max_iterations or 30,
        },
        "writer": {
            "model": config.model_name,
            "max_iterations": config.writer_max_iterations or 30,
            "temperature": config.model_temperature,
            "max_tokens": config.model_max_tokens,
        },
    }

    planner = create_planner_agent(
        model=config.model_name,
        max_iterations=config.planner_max_iterations or 40,
        sub_agent_configs=sub_agent_configs,
    )

    if not quiet:
        console.print("[green]✅ PlannerAgent initialized successfully[/green]")
    return planner


def get_or_create_planner(planner_holder: dict, config, quiet: bool = False):
    planner = planner_holder.get("planner")
    if planner is None:
        planner = create_demo_planner(config, quiet=quiet)
        planner_holder["planner"] = planner
    return planner


def _export_demo_response(response: Optional[AgentResponse], query: str, visualizer: DemoVisualizer):
    """Optionally export a completed response without changing Rich output."""
    export_mode = getattr(visualizer, "export_mode", "none")
    if not response or export_mode in (None, "none"):
        return response
    if not response.success or not isinstance(response.result, dict):
        return response

    final_answer = str(response.result.get("final_answer") or response.result.get("task_summary") or "").strip()
    if not final_answer:
        return response

    paper_match = re.search(r"(?:arxiv\s*[:：]\s*|arxiv\.org/(?:abs|pdf)/)(\d{4}\.\d{4,5})", query, re.IGNORECASE)
    prefix = f"arxiv_{paper_match.group(1)}" if paper_match else "report"
    basename = f"{prefix}_{time.strftime('%Y%m%d_%H%M%S')}"
    output_dir = Path(getattr(visualizer, "export_dir", Path("report"))).expanduser()
    try:
        exported = export_report_files(final_answer, output_dir, basename=basename, formats=export_mode)
        response.result["exported_files"] = exported
        if visualizer.quiet_mode:
            print("Exported report files:")
            for format_name, path in exported.items():
                print(f"{format_name}: {path}")
        else:
            lines = [f"{format_name}: {path}" for format_name, path in exported.items()]
            console.print(Panel("\n".join(lines), title="[bold green]Report Export", border_style="green"))
    except Exception as exc:
        response.result["export_error"] = str(exc)
        console.print(f"[red]Report export failed: {exc}[/red]")
    return response


def _resolve_cli_clarification(query: str, visualizer: DemoVisualizer) -> Optional[str]:
    """Resolve one clarification choice or show choices for non-interactive CLI use."""
    if getattr(visualizer, "clarification_mode", "auto") == "never":
        return query
    request = build_clarification_request(query)
    if not request:
        return query

    choice = getattr(visualizer, "clarification_choice", None)
    options = request["options"]
    if not choice and getattr(visualizer, "interactive_mode", False):
        console.print(Panel(
            request["question"] + "\n" + "\n".join(
                f"{index}. {option['label']} ({option['id']})"
                for index, option in enumerate(options, 1)
            ),
            title="[bold yellow]Research Scope Clarification",
            border_style="yellow",
        ))
        choice = console.input("选择编号或选项 ID（默认 comprehensive）: ").strip() or "comprehensive"
    if not choice:
        console.print(Panel(
            request["question"] + "\n" + "\n".join(
                f"{index}. {option['label']} ({option['id']})"
                for index, option in enumerate(options, 1)
            ) + "\n\n非交互模式请添加 --clarification-choice comprehensive，或使用 --clarification never 自动扩展。",
            title="[bold yellow]Research Scope Clarification Required",
            border_style="yellow",
        ))
        return None
    if str(choice).isdigit() and 1 <= int(choice) <= len(options):
        choice = options[int(choice) - 1]["id"]
    valid_ids = {option["id"] for option in options}
    if choice not in valid_ids:
        console.print(f"[yellow]Unknown clarification choice '{choice}'; using comprehensive.[/yellow]")
        choice = "comprehensive"
    return apply_clarification_choice(query, choice)


def run_demo_query(
    planner_holder,
    query: str,
    visualizer: DemoVisualizer,
    config,
    pdf_parse_mode: Optional[str] = None,
    query_mode: Optional[str] = None,
) -> Optional[AgentResponse]:
    """Run one query with a request-local PDF parsing strategy."""
    with temporary_pdf_parse_mode(pdf_parse_mode):
        effective_config = get_config()
        if not visualizer.quiet_mode:
            console.print(f"[cyan]PDF 解析链路: {effective_config.pdf_parse_mode}[/cyan]")
        return _run_demo_query(planner_holder, query, visualizer, effective_config, query_mode=query_mode)


def _run_demo_query(planner_holder, query: str, visualizer: DemoVisualizer, config,
                    query_mode: Optional[str] = None) -> Optional[AgentResponse]:
    """Run a demo query through the planner with preprocessing"""
    
    # Step 1: Show query information
    visualizer.show_planner_start(query)

    clarified_query = _resolve_cli_clarification(query, visualizer)
    if clarified_query is None:
        return None
    query = clarified_query

    # Explicit local paper requests never enter autonomous agents or a
    # general-knowledge fallback, including when the bounded workflow fails.
    from src.bounded_paper import uses_bounded_paper, run_bounded_paper
    if uses_bounded_paper(query, query_mode, config.pdf_parse_mode):
        response = AgentResponse(**run_bounded_paper(query, config))
        visualizer.show_final_result(response)
        return _export_demo_response(response, query, visualizer)
    
    # Explicit paper requests have a deterministic evidence route and should
    # not spend an extra classifier round-trip before PDF prefetch. Obvious
    # short queries also skip classification; complex/general questions keep
    # the conservative classifier and normal Planner route.
    if query_mode in {"paper_evidence", "science_literature", "multi_agent_literature", "direct_llm"}:
        classification_result = {"category": "NORMAL", "reasoning": "Route selected by the caller."}
        route = {"route": query_mode, "reason": "caller-selected route"}
    elif is_explicit_paper_request(query):
        classification_result = {"category": "NORMAL", "reasoning": "Explicit paper request routed directly to PDF evidence mode."}
    elif is_obvious_short_query(query):
        classification_result = {"category": "NON_KNOWLEDGE", "reasoning": "Obvious short query routed directly."}
    else:
        classification_result = classify_query(query, config, quiet=visualizer.quiet_mode)
    
    # Step 3: Branch processing based on the selected or deterministic route.
    if query_mode not in {"paper_evidence", "science_literature", "multi_agent_literature", "direct_llm"}:
        route = route_query(query, classification_result.get("category"))
    if route["route"] == "blocked":
        # Show fixed response for unsupported queries
        visualizer.show_unsupported_response()
        return None

    if looks_like_daily_arxiv_query(query):
        return _export_demo_response(run_daily_arxiv_query(query, config, visualizer), query, visualizer)

    if route["route"] == "science_literature":
        with diagnostic_stage("science_literature_workflow", source="run_demo"):
            return _export_demo_response(run_science_literature_query(query, config, visualizer), query, visualizer)

    if route["route"] == "multi_agent_literature":
        from multi_agent_demo_runner import run_multi_agent_literature_query
        with diagnostic_stage("multi_agent_literature_workflow", source="run_demo"):
            result = run_multi_agent_literature_query(
                query, config, workflow_run_id=MULTI_AGENT_WORKFLOW_RUN_ID,
            )
        workflow = result.get("workflow_summary") or {}
        record_diagnostic(
            "multi_agent_workflow",
            "completed" if result.get("success") else "failed",
            source="multi_agent_literature",
            model_calls=int(workflow.get("model_calls_used") or 0),
            model_call_limit=int(workflow.get("model_call_limit") or 10),
            workflow_status=str(workflow.get("workflow_status") or "failed"),
            failure_code=str(workflow.get("failure_code") or ""),
        )
        response = AgentResponse(
            success=bool(result.get("success")),
            error=None if result.get("success") else "多 Agent 文献协作未获得足够可审查证据",
            result={
                "task_name": "multi_agent_literature_answer",
                "completion_status": result.get("completion_status", "failed"),
                "final_answer": result.get("final_answer", ""),
                "route": "multi_agent_literature",
                "evidence_mode": "bounded_multi_agent_literature",
                "evidence_ledger": result.get("evidence_ledger", []),
                "citation_check": result.get("citation_check", {}),
                "workflow_summary": workflow,
                "evidence_review": result.get("evidence_review", {}),
            },
            iterations=1,
            execution_time=0.0,
            agent_name="BoundedLiteratureWorkflow",
        )
        visualizer.show_final_result(response)
        return _export_demo_response(response, query, visualizer)

    if route["route"] == "direct_llm" or should_answer_directly(query, classification_result["category"]):
        return _export_demo_response(run_direct_llm_query(query, config, visualizer), query, visualizer)
    
    # Step 4: Process normal query (original flow)
    try:
        planner = get_or_create_planner(planner_holder, config, quiet=visualizer.quiet_mode)

        # Execute the query
        with console.status("[bold green]Executing planner task...", spinner="dots"):
            with diagnostic_stage("planner_and_agents", source=route["route"]):
                response = planner.execute_task(query)

        # A requested paper may be temporarily unavailable at both the PDF
        # and agent layers. Do not fabricate a paper-grounded answer; make a
        # clearly labelled general-knowledge fallback instead.
        if (not response.success) and route["route"] == "paper_evidence":
            fallback_query = (
                "回答下面的问题，但必须先明确说明：指定论文当前未能取得可用本地 PDF 或解析证据，"
                "因此以下只能是通用知识解释，不代表该论文结论，也不要添加论文引用。\n"
                f"用户问题：{query}"
            )
            return _export_demo_response(run_direct_llm_query(fallback_query, config, visualizer), query, visualizer)
        
        # Show final results
        final_answer = ""
        if response.success and isinstance(response.result, dict):
            final_answer = str(response.result.get("final_answer") or response.result.get("task_summary") or "")
        if response.success and is_bad_agent_answer(final_answer):
            if any(marker in query.lower() for marker in ("arxiv", "??", "paper", "pdf", "??")):
                # DirectLLM has no parser/MCP access and would turn a real PDF task into a simulated answer.
                console.print("[yellow]Agent output looked unstable; preserving the tool-backed result instead of falling back to DirectLLM.[/yellow]")
            else:
                if not visualizer.quiet_mode:
                    console.print("[yellow]Agent output looked unstable; falling back to direct LLM answer.[/yellow]")
                return _export_demo_response(run_direct_llm_query(query, config, visualizer), query, visualizer)

        if response.success and isinstance(response.result, dict):
            response.result.setdefault("route", route["route"])
            response.result.setdefault("route_reason", route["reason"])
            response.result.setdefault("evidence_mode", "paper" if route["route"] == "paper_evidence" else "research")
        visualizer.show_final_result(response)
        
        # Show detailed trace if available
        if hasattr(response, 'reasoning_trace') and response.reasoning_trace:
            visualizer.show_reasoning_trace(response.reasoning_trace)
        
        return _export_demo_response(response, query, visualizer)
        
    except Exception as e:
        console.print(f"[red]❌ Error during execution: {e}[/red]")
        return None


def read_clipboard_text() -> str:
    """Read clipboard text on Windows without exposing it in command arguments."""
    try:
        import tkinter as tk
        root = tk.Tk()
        root.withdraw()
        try:
            return root.clipboard_get()
        finally:
            root.destroy()
    except Exception as exc:
        raise RuntimeError(f"??????????? --query-file?{exc}") from exc


def main():
    """Main CLI demo function"""
    parser = argparse.ArgumentParser(description="DeepDiver Multi-Agent System Demo")
    parser.add_argument("--query", "-q", type=str, help="Query to execute (interactive mode if not provided)")
    parser.add_argument("--multiline", "-m", action="store_true", help="Read a multi-line query from the clipboard; press Enter after pasting.")
    parser.add_argument("--stdin-multiline", action="store_true", help="Read multi-line input from stdin until a line containing :end.")
    parser.add_argument("--query-file", type=str, help="Read a UTF-8 query from a text file.")
    parser.add_argument("--diagnostics-file", type=str,
                        help="Write sanitised JSONL stage diagnostics for a non-interactive caller.")
    parser.add_argument("--prefetch-file", type=str,
                        help="Reuse a request-local literature pre-search result when it matches the query.")
    parser.add_argument("--conversation-context-file", type=str,
                        help="Read a request-local JSON context packet for a follow-up question.")
    parser.add_argument("--config-only", "-c", action="store_true", help="Only show configuration and exit")
    parser.add_argument("--create-env", "-e", action="store_true", help="Create sample .env file from template")
    parser.add_argument("--debug", "-d", action="store_true", help="Enable debug mode with verbose logging")
    parser.add_argument("--quiet", nargs="?", const="true", default=None, help="Suppress all non-essential output")
    parser.add_argument(
        "--pdf-parse-mode",
        choices=("local", "llama_full", "hybrid"),
        default=None,
        help="PDF parsing strategy for this run: local, llama_full, or hybrid (default: config/.env).",
    )
    parser.add_argument(
        "--query-mode",
        choices=("auto", "paper_evidence", "science_literature", "multi_agent_literature", "direct_llm"),
        default="auto",
        help="Route for a non-uploaded question; auto preserves the deterministic router.",
    )
    parser.add_argument(
        "--workflow-run-id",
        type=str,
        help="Opaque task ID for the bounded multi-agent workflow state; web callers supply their task ID.",
    )
    parser.add_argument(
        "--relevance-threshold",
        type=float,
        default=None,
        help="Relax the lexical relevance gate for this run (user-requested lower-standard pass).",
    )
    parser.add_argument(
        "--minimum-evidence",
        type=int,
        default=None,
        help="Override the minimum number of accepted papers required to answer.",
    )
    parser.add_argument(
        "--clarification",
        choices=("auto", "never"),
        default="auto",
        help="Clarify broad research scope before searching, or bypass the gate (default: auto).",
    )
    parser.add_argument(
        "--clarification-choice",
        type=str,
        help="Choice ID or number for non-interactive clarification (for example: comprehensive).",
    )
    parser.add_argument(
        "--export",
        choices=("none", "md", "pdf", "both"),
        default="none",
        help="Optionally export the final answer as Markdown, PDF, or both (default: none).",
    )
    parser.add_argument(
        "--export-dir",
        type=str,
        default="report",
        help="Directory for optional report exports (default: ./report).",
    )
    
    args = parser.parse_args()
    if args.diagnostics_file:
        os.environ["SCIASSISTANT_DIAGNOSTICS_PATH"] = str(Path(args.diagnostics_file).resolve())
    if args.prefetch_file:
        os.environ["SCIASSISTANT_PREFETCH_PATH"] = str(Path(args.prefetch_file).resolve())
    global CONVERSATION_CONTEXT, MULTI_AGENT_WORKFLOW_RUN_ID
    MULTI_AGENT_WORKFLOW_RUN_ID = args.workflow_run_id or None
    if args.conversation_context_file:
        try:
            context_path = Path(args.conversation_context_file).expanduser()
            CONVERSATION_CONTEXT = json.loads(context_path.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError) as exc:
            logging.getLogger(__name__).warning("Unable to load conversation context: %s", exc)
            CONVERSATION_CONTEXT = {"status": "rejected", "reason": "context_file_error"}
    args.quiet = str(args.quiet).lower() in {"1", "true", "yes", "on"}
    # User-requested lower-standard (third) pass: relax the gate process-wide.
    if args.relevance_threshold is not None or args.minimum_evidence is not None:
        configure_gate(args.relevance_threshold, args.minimum_evidence)

    # Setup logging based on arguments (re-configure if debug mode is requested)
    if args.debug:
        setup_clean_logging(debug_mode=True)
    elif args.quiet:
        logging.getLogger().setLevel(logging.ERROR)
    
    # Initialize visualizer
    visualizer = DemoVisualizer(quiet_mode=args.quiet)
    visualizer.export_mode = args.export
    visualizer.export_dir = Path(args.export_dir).expanduser()
    visualizer.clarification_mode = args.clarification
    visualizer.clarification_choice = args.clarification_choice
    visualizer.interactive_mode = not bool(args.query or args.query_file or args.multiline or args.stdin_multiline)
    if not args.quiet:
        visualizer.show_welcome()
    
    # Create sample .env file if requested
    if args.create_env:
        create_sample_env_file()
        return 0
    
    # Load configuration
    config = load_environment_config(quiet=args.quiet)
    if not config:
        if not args.quiet:
            console.print("[red]❌ Cannot proceed without valid configuration[/red]")
            console.print("[yellow]💡 Use --create-env to create a sample configuration file[/yellow]")
        return 1
    
    # Show configuration
    visualizer.show_config(config)
    
    if args.config_only:
        return 0

    # PlannerAgent depends on the MCP tool server, so keep it lazy. This lets
    # direct Q&A and arXiv checks run quickly even when MCP is not started yet.
    planner_holder = {"planner": None}
    
    # Handle query execution
    if args.multiline:
        try:
            query = read_clipboard_text().strip()
        except Exception as exc:
            console.print(f"[red]? {exc}[/red]")
            return 1
        if not query:
            console.print("[yellow]?? ???????[/yellow]")
            return 1
        run_demo_query(planner_holder, query, visualizer, config, args.pdf_parse_mode,
                       None if args.query_mode == "auto" else args.query_mode)
    elif args.query_file:
        query_path = Path(args.query_file).expanduser()
        try:
            query = query_path.read_text(encoding="utf-8").strip()
        except Exception as exc:
            console.print(f"[red]? Cannot read query file: {exc}[/red]")
            return 1
        if not query:
            console.print("[yellow]?? Query file is empty[/yellow]")
            return 1
        run_demo_query(planner_holder, query, visualizer, config, args.pdf_parse_mode,
                       None if args.query_mode == "auto" else args.query_mode)
    elif args.query:
        # Single query mode; embedded newlines are preserved.
        run_demo_query(planner_holder, args.query, visualizer, config, args.pdf_parse_mode,
                       None if args.query_mode == "auto" else args.query_mode)
    else:
        # Interactive mode
        if not args.quiet:
            console.print("\n[bold blue]?? Interactive Mode[/bold blue]")
            console.print("Enter your queries below. Type 'quit' or 'exit' to leave.")
            if args.stdin_multiline:
                console.print("Multi-line mode: finish each query with a line containing :end; cancel with :cancel.")

        while True:
            try:
                if args.stdin_multiline:
                    prompt_text = "\n[bold cyan]Enter query (finish with :end):[/bold cyan] " if not args.quiet else "Query line: "
                    lines = []
                    while True:
                        line = console.input(prompt_text if not lines else "... ")
                        if line.strip().lower() in {':end', ':submit'}:
                            break
                        if line.strip().lower() == ':cancel':
                            lines = []
                            break
                        lines.append(line)
                    query = "\n".join(lines).strip()
                    if not query:
                        continue
                else:
                    prompt_text = "\n[bold cyan]Enter your query:[/bold cyan] " if not args.quiet else "Query: "
                    query = console.input(prompt_text).strip()

                if query.lower() in ['quit', 'exit', 'q']:
                    if not args.quiet:
                        console.print("[green]?? Goodbye![/green]")
                    break

                if not query:
                    continue

                if not args.quiet:
                    console.print("\n" + "="*80 + "\n")
                run_demo_query(planner_holder, query, visualizer, config, args.pdf_parse_mode,
                               None if args.query_mode == "auto" else args.query_mode)
                if not args.quiet:
                    console.print("\n" + "="*80 + "\n")

            except KeyboardInterrupt:
                if not args.quiet:
                    console.print("\n[yellow]?? Interrupted by user[/yellow]")
                break
            except EOFError:
                if not args.quiet:
                    console.print("\n[green]?? Goodbye![/green]")
                break

    return 0


if __name__ == "__main__":
    sys.exit(main())












