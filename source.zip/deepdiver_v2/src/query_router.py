﻿"""Deterministic query routing helpers shared by CLI integrations.

The router is deliberately conservative: paper/source requests always keep
the evidence-backed Planner path, while short general questions can use the
single-call LLM path to avoid unnecessary agent orchestration.
"""

from __future__ import annotations

import os
import re
import time
import json
import sqlite3
from pathlib import Path
from typing import Dict

# Chinese function-word filtering and the shared stopword tables live in
# query_terms so the term extractor, the problem spec and the plan builder all
# consult one list. Re-exported here for existing importers.
from .query_terms import (  # noqa: E402
    CHINESE_STOPWORDS,
    ENGLISH_STOPWORDS,
    chinese_content_phrase,
    chinese_content_pieces,
    extract_query_terms,
)
from .query_bridge import augment_scoring_query  # noqa: E402


PAPER_MARKERS = (
    "arxiv:", "arxiv.org/", "指定论文", "论文全文", "pdf全文", "paper full text",
)
RESEARCH_MARKERS = (
    "arxiv", "论文", "paper", "pdf", "引用", "参考文献", "citation", "source",
    "检索", "实验表格", "公式", "图表", "最新", "recent", "today", "数据集",
)
BIOMEDICAL_MARKERS = ("pubmed", "pmid", "医学", "临床", "疾病", "癌症", "药物", "biomedical", "clinical", "protein", "gene")
CURRENT_MARKERS = ("最新", "最近", "今天", "当前", "latest", "recent", "today", "实时")
TECHNICAL_MARKERS = (
    "transformer", "self-attention", "self attention", "attention", "query", "key", "value",
    "rnn", "lstm", "gru", "neural network", "深度学习", "机器学习", "神经网络", "注意力", "模型结构",
    "rag", "retrieval-augmented generation", "retrieval augmented generation", "检索增强生成", "检索增强",
    "neural network", "cnn", "gnn", "diffusion model", "large language model",
    "llm", "graph neural network", "convolutional neural network", "reinforcement learning",
    "pretraining", "pre-training", "fine-tuning", "finetuning", "parameter-efficient fine-tuning",
    "神经网络", "卷积神经网络", "循环神经网络", "图神经网络", "扩散模型", "大语言模型",
    "机器学习", "深度学习", "强化学习", "计算机视觉", "自然语言处理", "目标检测", "图像分割",
)
_DIRECT_CACHE: dict[tuple[str, str], tuple[float, str]] = {}
DIRECT_CACHE_TTL = 300.0
_LITERATURE_CACHE: dict[tuple[str, str, int], tuple[float, object]] = {}
LITERATURE_CACHE_TTL = 86400.0
_PAPER_EVIDENCE_CACHE: dict[tuple[str, str], tuple[float, object]] = {}
PAPER_EVIDENCE_CACHE_TTL = 1800.0

# Literature search is deliberately bounded. A single answer may use at most
# three API batches, with five papers per batch (15 distinct papers total).
# Keeping this limit global prevents an intent classifier from accidentally
# turning an ordinary question into 20-25 external requests.
MAX_QUERY_ROUTES = int(os.environ.get("LITERATURE_MAX_QUERIES", "3"))
# A broad question (long, multi-clause, or several question marks) may use more
# distinct query routes. Env-overridable so an operator can widen recall without
# editing code, matching how the other thresholds in this module are configured.
MAX_BROAD_QUERY_ROUTES = int(os.environ.get("LITERATURE_BROAD_MAX_QUERIES", "15"))

# The multi-source search runs one round per distinct query route, and each
# round queries every enabled source. Two separate limits bound it, and they
# used to be a bare ``range(1, 6)`` and a bare ``15`` in the caller:
#
#   LITERATURE_MAX_ROUNDS          how many rounds may run at all
#   LITERATURE_MAX_CANDIDATE_PAPERS  stop once this many distinct papers exist
#
# They are named and configurable because the paper cap — not the query budget —
# is what actually ends a multi-source search early: four sources returning three
# papers each reach fifteen within two rounds.
MAX_RETRIEVAL_ROUNDS = int(os.environ.get("LITERATURE_MAX_ROUNDS", "5"))
MAX_CANDIDATE_PAPERS = int(os.environ.get("LITERATURE_MAX_CANDIDATE_PAPERS", "15"))
MAX_RESULTS_PER_SOURCE_CALL = 5

# Backward-compatible aliases for scripts and tests written before the naming
# cleanup. New production code should use the names above, which distinguish
# query-route budgets, retrieval rounds, candidate caps, and per-source batch
# sizes.
MAX_SEARCH_ROUNDS = MAX_QUERY_ROUTES
LITERATURE_BROAD_MAX_QUERIES = MAX_BROAD_QUERY_ROUTES
LITERATURE_MAX_ROUNDS = MAX_RETRIEVAL_ROUNDS
LITERATURE_MAX_CANDIDATE_PAPERS = MAX_CANDIDATE_PAPERS
MAX_RESULTS_PER_ROUND = MAX_RESULTS_PER_SOURCE_CALL
# Relevance gate threshold. The default is the normal first-pass bar; the
# value is runtime-adjustable so the degraded-search recovery path (an
# automatic broader second pass, and a user-requested lower-standard third
# pass) can relax the gate without editing code.
RELEVANCE_THRESHOLD = float(os.getenv("LITERATURE_RELEVANCE_THRESHOLD", "0.35"))


def set_relevance_threshold(value: float) -> float:
    """Override the lexical relevance threshold at runtime; return the active value."""
    global RELEVANCE_THRESHOLD
    try:
        RELEVANCE_THRESHOLD = max(0.0, min(1.0, float(value)))
    except (TypeError, ValueError):
        pass
    return RELEVANCE_THRESHOLD


def get_relevance_threshold() -> float:
    return RELEVANCE_THRESHOLD


MIN_CONCEPT_COVERAGE = 2
LITERATURE_CACHE_VERSION = "v12-structured-query-generic-recall"
_LITERATURE_CACHE_DB = Path(__file__).resolve().parents[2] / "logs" / "literature_search_cache.sqlite3"


def _unicode_chars(*codepoints: int) -> str:
    """Build Unicode markers without relying on the active Windows code page."""
    return "".join(chr(codepoint) for codepoint in codepoints)


# Words that ask about a topic's weaknesses. They fall into two tiers, and the
# distinction is load-bearing:
#
#   * STRONG terms name a weakness explicitly ("limitations", "drawbacks").
#     A question phrased this way is asking for critical evidence, so a paper
#     that only happens to mention the topic is not enough: the strict
#     same-sentence architecture-limitation gate applies.
#   * WEAK terms are survey vocabulary ("challenges", "issues", "problems").
#     "What are the key challenges of X?" asks for an overview of an area, and
#     a survey or review paper answers it directly. Treating these as strong
#     made every field-survey question demand a specific architecture defect
#     from its own sources, which rejected the surveys that answer best.
#
# Both tiers still mark the question as limitation-related for recall
# (``build_literature_query_plan`` uses LIMITATION_QUERY_TERMS for that); only
# the strict evidence gate is narrowed to the strong tier.
STRONG_LIMITATION_TERMS = (
    "limitation", "limitations", "weakness", "weaknesses",
    "drawback", "drawbacks", "shortcoming", "shortcomings",
    _unicode_chars(0x5c40, 0x9650),      # 局限
    _unicode_chars(0x5f31, 0x70b9),      # 弱点
    _unicode_chars(0x4e0d, 0x8db3),      # 不足
    _unicode_chars(0x7f3a, 0x9677),      # 缺陷
    _unicode_chars(0x5c40, 0x9650, 0x6027),  # 局限性
)

WEAK_LIMITATION_TERMS = (
    "challenge", "challenges", "issue", "issues", "problem", "problems",
    "inadequate", "unable", "cannot", "bottleneck",
    "disadvantage", "disadvantages",
    _unicode_chars(0x6311, 0x6218),      # 挑战
)

LIMITATION_QUERY_TERMS = STRONG_LIMITATION_TERMS + WEAK_LIMITATION_TERMS

# Search may use broad vocabulary such as "challenge", but a challenge in an
# application domain is not automatically an architecture weakness. These
# stronger terms are required before a paper may support a critical synthesis.
DIRECT_LIMITATION_EVIDENCE_TERMS = (
    "limitation", "limitations", "weakness", "weaknesses", "drawback",
    "drawbacks", "shortcoming", "shortcomings", "inadequate", "unable",
    "cannot", "bottleneck", "disadvantage", "disadvantages",
)


_CONCEPT_ALIASES = {
    "ssm": ("ssm", "state space model", "state-space model"),
    "moe": ("moe", "mixture of experts", "mixture-of-experts"),
    "agent": ("agent", "agents"),
    "tool_calling": ("tool calling", "function calling", "tool use"),
    "multimodal_3d": ("3d", "point cloud", "point-cloud"),
    "video": ("video",),
    "alignment": ("alignment",),
    "quantization": ("quantization", "quantized", "quantisation"),
    "world_model": ("world model", "world models", "sim-to-real"),
    "dpo": ("dpo", "direct preference optimization", "direct preference"),
    "speculative": ("speculative decoding", "speculative"),
    "embodied": ("embodied", "robot", "robotics"),
    "continual_learning": ("continual learning", "continual pretraining"),
    "synthetic_data": ("synthetic data",),
    "multi_agent": ("multi-agent", "multi agent"),
    "memory": ("long-term memory", "memory"),
    "cot": (
        "cot", "chain-of-thought", "chain of thought",
    ),
    "rag": ("rag", "retrieval-augmented generation", "retrieval augmented generation", "retrieval augmented"),
    "transformer": ("transformer", "transformers"),
    "attention": ("attention", "self-attention", "self attention", "multi-head", "multihead"),
    "qkv": ("query", "key", "value", "q/k/v", "qkv"),
    "scaled_attention": ("scaled dot-product", "scaled dot product", "dot-product attention", "dot product attention"),
    "rnn": ("rnn", "recurrent neural network", "recurrent neural", "lstm", "gru"),
    "sequence": ("sequence transduction", "sequence-to-sequence", "seq2seq", "sequence modeling"),
    "cnn": ("cnn", "convolutional neural network", "convolution network"),
    "gnn": ("gnn", "graph neural network", "graph convolutional network"),
    "diffusion": ("diffusion model", "diffusion models"),
    "llm": ("large language model", "large language models", "llm"),
    "reinforcement": ("reinforcement learning",),
    "fine_tuning": (
        "fine-tuning", "fine tuning", "finetuning", "parameter-efficient fine-tuning", "peft",
    ),
    # P2: LoRA/QLoRA are standard named methods (same class as dpo/cot/rag
    # entries). Without them a LoRA/QLoRA question resolves to zero requested
    # concepts, core coverage is always 0 and every candidate - including a
    # perfectly relevant paper from a fallback source - fails the gate with
    # "0 papers accepted". Lower-case abbreviations in a Chinese sentence
    # ("lora 与 qlora") are matched by the same tolerant alias matcher.
    "lora": (
        "lora", "low-rank adaptation", "low rank adaptation", "low-rank",
    ),
    "qlora": (
        "qlora", "quantized lora", "quantized low-rank adaptation",
    ),
    "rlvr": ("rlvr", "reinforcement learning with verifiable rewards", "verifiable reward"),
    "multimodal": ("multimodal", "vision-language model", "visual language model", "vlm", "multimodal large language model"),
    "graph_rag": ("graphrag", "graph rag", "graph retrieval augmented generation", "knowledge graph retrieval"),
    "image_generation": (
        "image generation", "text-to-image", "text to image", "image synthesis",
        "generated image", "generative image", "visual generation",
    ),
    "video_generation": (
        "video generation", "text-to-video", "text to video", "video synthesis",
        "generated video", "ai-generated video", "generative video",
    ),
    "generative_ai": (
        "generative ai", "generative artificial intelligence",
    ),
}

_CORE_CONCEPTS = {
    "cot", "rag", "transformer", "attention", "rnn", "sequence", "cnn", "gnn", "diffusion", "llm",
    "reinforcement", "fine_tuning", "rlvr", "multimodal", "graph_rag", "image_generation", "video_generation", "generative_ai",
    "ssm", "moe", "agent", "tool_calling", "multimodal_3d", "video", "alignment", "quantization", "world_model", "dpo",
    "speculative", "embodied", "continual_learning", "synthetic_data", "multi_agent", "memory",
    "lora", "qlora",
}

# Generic domain evidence used to reject lexical namesakes. These are broad
# language-level signals, not model/topic-to-paper mappings: a query about an
# AI architecture must have at least one AI signal in the candidate metadata.
_AI_DOMAIN_SIGNALS = (
    "machine learning", "deep learning", "neural", "attention", "language model",
    "large language", "computer vision", "image", "vision", "segmentation",
    "embedding", "token", "dataset", "training", "fine-tuning", "fine tuning",
    "domain adaptation", "transfer learning", "reinforcement learning", "robotics",
    "artificial intelligence", "generative", "diffusion", "cnn", "rnn", "hmm",
    "clip", "multimodal", "transformer architecture", "retrieval augmented",
    "retrieval-augmented", "rag", "natural language", "nlp",
    "expressivity",
)
_AI_QUERY_SIGNALS = (
    "transformer", "attention", "language model", "llm", "neural", "deep learning",
    "machine learning", "fine-tuning", "fine tuning", "peft", "domain adaptation",
    "retrieval augmented", "retrieval-augmented", "rag", "reinforcement learning", "robotics", "multimodal",
    "diffusion", "embedding", "computer vision", "cnn", "rnn", "moe",
)
_ARCHITECTURE_LIMITATION_SIGNALS = (
    "complexity", "quadratic", "scalability", "generalization", "expressivity",
    "sequence length", "long context", "memory", "compute", "computational",
    "data efficiency", "inductive bias", "robustness", "arithmetic", "formal language",
    "context window", "latency", "cost", "bottleneck",
    "limited data", "data scarcity", "limited supervision", "limitation", "limitations",
)


def _requires_ai_domain(query: str) -> bool:
    lowered = str(query or "").lower()
    return any(term in lowered for term in _AI_QUERY_SIGNALS)


def _has_ai_domain_signal(text: str) -> bool:
    lowered = str(text or "").lower()
    return any(term in lowered for term in _AI_DOMAIN_SIGNALS)


def _has_relation_evidence(query: str, haystack: str) -> bool:
    """Require generic relation evidence for adaptation/comparison questions."""
    query_lower = str(query or "").lower()
    text = str(haystack or "").lower()
    if "domain adaptation" in query_lower:
        return any(term in text for term in (
            "domain adaptation", "domain shift", "transfer learning", "cross-domain",
            "domain generalization", "adaptation",
        ))
    if is_comparison_query(query_lower):
        if any(term in text for term in (
            "comparison", "compared", "versus", "trade-off", "tradeoff", "difference",
        )):
            return True
        # P2: a comparison between two named objects is evidenced when the
        # paper jointly covers BOTH objects (e.g. LoRA and QLoRA), even if the
        # abstract never spells out "difference"/"versus". The upstream
        # explicit-term gate already requires both names in the metadata, so
        # this widens the wording requirement, never the evidence itself.
        # Lower-case abbreviations inside a Chinese sentence are caught by
        # resolving the question's concepts (lora/qlora) and matching them
        # against the paper through the same tolerant alias matcher.
        named_objects = {
            token.lower()
            for token in re.findall(r"\b[A-Z][A-Za-z0-9-]{1,}\b", str(query or ""))
            if token.lower() not in {"ai", "pdf", "vlm", "rag", "rlhf", "ssm", "kv"}
            and token.lower() not in _ALIAS_FUNCTION_WORDS
        }
        resolved_concepts = requested_concepts(query_lower)
        named_objects.update(resolved_concepts)
        if len(named_objects) >= 2:
            covered = []
            for token in named_objects:
                if token in resolved_concepts:
                    if _concept_matches(text, token):
                        covered.append(token)
                elif token in text:
                    covered.append(token)
            return len(covered) >= 2
        return False
    return True


# Function words inside a multi-word alias (``mixture OF experts``). They are
# dropped when free-text query phrases are built, so requiring them verbatim
# would report ``degraded`` for a question that does name the concept. They are
# ignored on both sides: "Mixture Experts" then resolves to the ``moe`` concept
# exactly like "Mixture of Experts".
_ALIAS_FUNCTION_WORDS = frozenset({
    "of", "in", "to", "the", "a", "an", "for", "on", "at", "by", "with",
    "from", "and", "or", "into", "within", "via", "over", "under",
})


def _significant_words(text: str) -> list[str]:
    """Lower-cased English tokens of a phrase, without function words."""
    return [
        token for token in re.findall(r"[a-z0-9]+", str(text or "").lower())
        if token not in _ALIAS_FUNCTION_WORDS
    ]


def _alias_words_in_order(text: str, alias: str) -> bool:
    """Match a multi-word alias tolerating function words and plurals.

    ``mixture of experts`` must also match the stripped query "Mixture
    Experts" (``of`` is dropped when free-text search phrases are built) and
    plural titles such as "Mixtures of Experts Models". Each alias word
    matches its text counterpart with an optional plural ``s``/``es``, in the
    same relative order; no other reordering or stemming is attempted.
    """
    alias_words = _significant_words(alias)
    if not alias_words:
        return alias in str(text or "").lower()
    remaining = iter(_significant_words(text))
    for alias_word in alias_words:
        for text_word in remaining:
            if (
                text_word == alias_word
                or text_word == alias_word + "s"
                or text_word == alias_word + "es"
            ):
                break
        else:
            return False
    return True


def _contains_alias(text: str, alias: str) -> bool:
    """Match technical aliases without treating ordinary words as concepts."""
    value = str(text or "").lower()
    alias = alias.lower()
    if alias in {"query", "key", "value"}:
        # Q/K/V is meaningful only as a grouped phrase, not as a generic word
        # appearing in an unrelated title such as "From Values to Benchmarks".
        return bool(re.search(r"\bquery\s*[,/]?\s*key\s*[,/]?\s*value\b", value))
    if re.fullmatch(r"[a-z0-9]+", alias):
        # Chinese text may be adjacent to an English term (e.g.
        # ``Transformer架构``), so Python's ``\b`` is too strict here.
        return bool(re.search(rf"(?<![a-z0-9]){re.escape(alias)}(?![a-z0-9])", value))
    return _alias_words_in_order(value, alias)


def _concept_matches(text: str, concept: str) -> bool:
    aliases = _CONCEPT_ALIASES[concept]
    if concept == "qkv":
        return any(_contains_alias(text, alias) for alias in ("q/k/v", "qkv", "query") )
    return any(_contains_alias(text, alias) for alias in aliases)


def is_limitation_query(query: str) -> bool:
    """Recognize evidence requests about a topic's weaknesses or limits.

    Covers both tiers, so recall treats "challenges" questions as
    limitation-related. Use :func:`requires_direct_limitation_evidence` to
    decide whether the strict same-sentence evidence gate may be applied.
    """
    lowered = str(query or "").lower()
    return bool(requested_concepts(lowered)) and any(term in lowered for term in LIMITATION_QUERY_TERMS)


def requires_direct_limitation_evidence(query: str) -> bool:
    """Report whether the question names a weakness explicitly.

    Only the strong tier may demand direct architecture-limitation evidence.
    Weak survey vocabulary such as "challenges" asks for an overview, which a
    survey answers without documenting a specific defect.
    """
    lowered = str(query or "").lower()
    if not requested_concepts(lowered):
        return False
    return any(term in lowered for term in STRONG_LIMITATION_TERMS)


# Language-level markers for "compare these two named things". These name
# grammar, not subject matter: no entry selects a research field or a paper.
COMPARISON_MARKERS = (
    "versus", "differ", "difference", "different", "compare", "comparison",
    "compared", "contrast",
    _unicode_chars(0x533a, 0x522b),  # 区别
    _unicode_chars(0x5dee, 0x5f02),  # 差异
    _unicode_chars(0x5bf9, 0x6bd4),  # 对比
    _unicode_chars(0x6bd4, 0x8f83),  # 比较
)

# "vs" is two letters and must be matched as a whole word, otherwise it would
# match inside unrelated tokens.
_VS_MARKER = re.compile(r"(?<![a-z])vs\.?(?![a-z])")


def is_comparison_query(query: str) -> bool:
    """Report whether the question asks to compare two named objects.

    A comparison constrains evidence on *both* sides: a paper documenting only
    one of the two names cannot support the answer, so the named-object gate
    must require every name rather than any one of them.

    Rule-based on purpose. The decision is offline-verifiable by the regression
    suite and costs no model call, which keeps the gate reproducible.
    """
    lowered = str(query or "").lower()
    if any(marker in lowered for marker in COMPARISON_MARKERS):
        return True
    return bool(_VS_MARKER.search(lowered))


def _arxiv_topic_phrase(concepts: set[str]) -> str:
    """Return only terms explicitly present in the user's query.

    Topic-to-English catalogs are intentionally not used here. The LLM query
    spec and generic token extraction own cross-lingual expansion.
    """
    return " ".join(dict.fromkeys(
        alias for concept in concepts for alias in _CONCEPT_ALIASES.get(concept, ())
        if alias.isascii()
    ))


def _arxiv_topic_filter(concepts: set[str], fallback: str) -> str:
    """Build a filter from query-visible terms, without a topic catalog."""
    labels = [alias for concept in concepts for alias in _CONCEPT_ALIASES.get(concept, ()) if alias.isascii()]
    if labels:
        # Multiple entities in one question are alternatives/related facets,
        # not a requirement that every paper literally names every entity.
        # Keep the relation/evidence terms selective while allowing papers
        # focused on either side of a fusion or comparison question.
        unique = list(dict.fromkeys(labels))
        if len(unique) > 1:
            return "(" + " OR ".join(f'all:"{label}"' for label in unique) + ")"
        return f'all:"{unique[0]}"'
    return f'all:"{fallback}"'


def _has_direct_architecture_limitation(text: str, concepts: list[str]) -> bool:
    """Reject application problems that are not claimed limitations of a model."""
    topic_aliases = []
    for concept in concepts:
        topic_aliases.extend(_CONCEPT_ALIASES.get(concept, ()))
    topic = "|".join(re.escape(alias) for alias in topic_aliases if len(alias) >= 3)
    limitation = "|".join(re.escape(term) for term in DIRECT_LIMITATION_EVIDENCE_TERMS)
    if not topic or not limitation:
        return False
    # The topic and limitation must occur in the same local statement, rather
    # than merely somewhere in the same application paper's abstract.
    return bool(re.search(rf"(?:{topic}).{{0,140}}(?:{limitation})|(?:{limitation}).{{0,140}}(?:{topic})", text, re.I | re.S))


def _expanded_query_terms(query: str) -> list[str]:
    value = str(query or "")
    language_stopwords = {
        "a", "an", "and", "are", "as", "at", "be", "by", "called", "can",
        "does", "for", "from", "how", "in", "is", "it", "of", "on", "or",
        "that", "the", "these", "this", "those", "to", "use", "using", "what",
        "when", "where", "which", "why", "with", "about", "explain", "explanation",
        "describe", "discuss", "tell", "please", "new", "method", "model", "models",
    }
    terms = []
    raw_tokens = re.findall(r"[A-Za-z][A-Za-z0-9]*(?:[-/][A-Za-z0-9]+)*", value)
    terms.extend(token for token in raw_tokens if token.lower() not in language_stopwords)
    # Keep previously unseen method identifiers without maintaining a name
    # catalog. Acronyms, CamelCase, digits, hyphenated names and non-sentence
    # TitleCase tokens are all valid research anchors.
    sentence_words = {"The", "This", "That", "These", "Those", "What", "Why", "How", "Which", "When", "Where", "Using", "Based", "Compared", "Practical", "Output", "Same", "Long", "Cross", "New", "Real", "Formal", "Overall"}
    for token in raw_tokens:
        if token in sentence_words or token.lower() in language_stopwords or len(token) < 4:
            continue
        if token.isupper() or "-" in token or any(char.isdigit() for char in token) or any(char.isupper() for char in token[1:]) or (token[0].isupper() and token[1:].islower()):
            terms.append(token)
    return list(dict.fromkeys(terms))


def infer_literature_relation(query: str) -> str:
    """Classify the research relation, independently from the topic name."""
    value = str(query or "").lower()
    groups = {
        "comparison": ("compare", "comparison", "compared with", "compared to", "than", "versus", " vs ", "对比", "相比", "比较", "区别", "差异"),
        "advantages": ("advantage", "advantages", "benefit", "benefits", "strength", "优势", "优点", "好处"),
        "limitations": LIMITATION_QUERY_TERMS,
        "training": (
            "pretraining", "pre-training", "fine-tuning", "finetuning", "instruction tuning",
            "process supervision", "process reward", _unicode_chars(0x8fc7, 0x7a0b, 0x76d1, 0x7763),
            _unicode_chars(0x9884, 0x8bad, 0x7ec3), _unicode_chars(0x5fae, 0x8c03),
            _unicode_chars(0x6307, 0x4ee4, 0x5fae, 0x8c03),
        ),
        "deployment": ("latency", "memory", "throughput", "runtime", "workload", "deployment", "显存", "延迟", "吞吐", "工作负载"),
        "retrieval": ("retrieval", "recall", "ranking", "reranking", "search", "corpus", "检索", "召回", "排序"),
        "memory": ("memory", "retention", "forgetting", "history", "storage", "eviction", "记忆", "保留", "遗忘"),
        "mechanism": ("mechanism", "architecture", "how does", "how do", "why", "原理", "机制", "架构", "如何工作", "如何解决", "技术难点"),
        "evidence": ("experiment", "benchmark", "result", "evaluation", "实验", "结果", "指标", "性能"),
        "survey": ("survey", "review", "overview", "progress", "trend", "综述", "进展", "现状", "趋势"),
        "definition": ("what is", "define", "definition", "explain", "是什么", "定义", "解释", "讲解"),
    }
    for relation, markers in groups.items():
        if any(marker in value for marker in markers):
            return relation
    return "focused"


def build_problem_spec(query: str) -> dict:
    """Represent a research question independently from its search words.

    This is deliberately topic-agnostic: clauses become aspects, detected
    technical concepts become entities, and the request form becomes a
    relation.  The model planner may enrich the spec, but retrieval never
    depends on a hand-written keyword branch.
    """
    value = " ".join(str(query or "").split()).strip()
    clauses = [part.strip(" ，,；;。!?！？、") for part in re.split(r"[，,；;。!?！？、]", value) if part.strip(" ，,；;。!?！？、")]
    entities = sorted(requested_concepts(value))
    # Preserve new/unlisted Chinese technical nouns as entities. This keeps
    # retrieval topic-agnostic and prevents unrelated fallback subjects.
    ignored_phrases = {"讲解", "解释", "一下", "是什么", "有哪些", "为什么", "如何", "论文", "文章", "优势", "劣势", "优点", "缺点", "好处"}
    # Split Chinese prose on generic function words; this is not a topic or
    # paper dictionary, just a language-level noun-phrase extractor.
    chinese_chunks = re.split(r"[，,；;。！？?：:\s、]|的|和|与|及|一下|请|讲解|解释|有哪些|为什么|如何|什么", value)
    for chunk in chinese_chunks:
        chunk = chunk.strip()
        if not chunk:
            continue
        # The spec carries terminology, never clause fragments: split each
        # chunk into content pieces so prose made only of function words
        # ("关于", "如果是前者", "是否还需要") is dropped before it can reach
        # the answer model or a search query.
        if re.search(r"[\u3400-\u9fff]", chunk):
            pieces = chinese_content_pieces(chunk)
        else:
            pieces = [chunk]
        for phrase in pieces:
            if (2 <= len(phrase) <= 16 and phrase not in ignored_phrases
                    and phrase.lower() not in {"of", "the", "and", "or", "to", "in", "for", "with", "from"}
                    and phrase.lower() not in {str(item).lower() for item in entities}):
                entities.append(phrase)
    language_stopwords = {
        "A", "An", "And", "Are", "As", "At", "Be", "By", "Called", "Can", "Does",
        "For", "From", "How", "In", "Is", "It", "Of", "On", "Or", "That", "The",
        "These", "This", "Those", "To", "Using", "What", "When", "Where", "Which",
        "Why", "With", "About", "Explain", "Describe", "Discuss", "Tell", "Please",
        "New", "Method", "Model", "Models",
    }
    explicit_entities = [
        entity for entity in re.findall(r"\b[A-Z][A-Za-z0-9]*(?:[-/][A-Za-z0-9]+)*\b", value)
        if entity not in language_stopwords
    ]
    for entity in explicit_entities:
        if entity.lower() not in {item.lower() for item in entities} and entity.lower() not in {item.lower() for item in language_stopwords}:
            entities.append(entity)
    evidence_types = []
    lower = value.lower()
    for marker, label in (("arxiv", "paper"), ("论文", "paper"), ("实验", "empirical"), ("数据", "empirical"), ("综述", "survey"), ("原理", "mechanism")):
        if marker in lower and label not in evidence_types:
            evidence_types.append(label)
    return {
        "entities": entities,
        "relation": infer_literature_relation(value),
        "aspects": clauses[:8],
        "evidence_types": evidence_types or ["paper"],
        "constraints": ["arXiv"] if "arxiv" in lower or "论文" in lower else [],
    }


def build_followup_retrieval_query(
    current_query: str,
    previous_query: str = "",
    previous_intent: dict | None = None,
) -> str:
    """Compose a compact, non-evidentiary query for a conversational turn.

    A prior answer may contain many generic words, citations, and formatting
    boilerplate. It is useful to the writer for resolving references, but it
    is too noisy to send through lexical retrieval. This helper keeps only the
    current request, the parent question, and bounded structured intent.
    """
    parts = []
    for value in (current_query, previous_query):
        normalized = " ".join(str(value or "").split()).strip()
        if normalized:
            parts.append(normalized[:1600])
    intent = previous_intent or {}
    for key in ("target",):
        value = intent.get(key)
        if isinstance(value, str) and value.strip():
            parts.append(value.strip()[:300])
    for key in ("aspects", "entities"):
        values = intent.get(key)
        if isinstance(values, (list, tuple)):
            parts.extend(str(value).strip()[:240] for value in values[:8] if str(value).strip())
    return "\n".join(dict.fromkeys(parts))


def build_literature_query_plan(
    query: str,
    *,
    include_topicless_routes: bool = True,
) -> list[dict]:
    """Create a relation-aware, bounded search plan before hitting arXiv.

    The plan uses generic research relations, not topic-specific hard-coded
    branches. Each item is a distinct evidence dimension that can be reported
    in diagnostics and checked for coverage after retrieval.

    When ``include_topicless_routes`` is false, a question that yields no
    topic and no salient term produces no route at all instead of a set of
    generic word-only queries. Callers that feed retrieval should pass false;
    the default keeps the raw relation plan available for inspection.
    """
    concepts = requested_concepts(query)
    problem_spec = build_problem_spec(query)
    # arXiv's legacy search index is overwhelmingly English.  The problem
    # spec may retain Chinese noun phrases for the answer model, but sending
    # interrogative prose ("核心差异是什么", "如何解决") as title/abstract
    # clauses creates zero-result AND queries.  Keep only compact searchable
    # identifiers/phrases here; this is language filtering, not a topic or
    # paper mapping.
    entities = []
    for item in problem_spec.get("entities", []):
        value = " ".join(str(item or "").split()).strip()
        if not value or len(value) > 48:
            continue
        ascii_tokens = re.findall(r"[A-Za-z][A-Za-z0-9]*(?:[-/][A-Za-z0-9]+)*", value)
        has_cjk = bool(re.search(r"[\u3400-\u9fff]", value))
        is_question_fragment = bool(re.search(r"(?:什么|为什么|如何|哪些|是否|怎样|怎么|是什么|差异|区别|体现|解决|问题|方面|优势|劣势|短板|不足|核心|具体|讲解|解释|刚才|当前|论文|文章)", value))
        if ascii_tokens and not (has_cjk and is_question_fragment):
            # Strip adjacent Chinese grammatical suffixes (e.g.
            # ``Transformer架构``) before building an arXiv query.
            entities.append(" ".join(ascii_tokens) if has_cjk else value)
        elif not has_cjk and not is_question_fragment and len(value) >= 3:
            entities.append(value)
    entities = list(dict.fromkeys(entities))
    topic = _arxiv_topic_phrase(concepts)
    if not topic:
        # Unknown/new method names must still drive recall. Use the entities
        # extracted from the user's wording, not a topic-to-paper catalog or
        # the entire natural-language sentence as one hard phrase.
        topic = " ".join(entities[:4])
    base_topic_filter = _arxiv_topic_filter(concepts, topic)
    if entities:
        entity_routes = []
        for entity in entities[:4]:
            entity_routes.append(f'(ti:"{entity}" OR abs:"{entity}")')
        entity_filter = "(" + " OR ".join(entity_routes) + ")"
        # Known concept expansion and newly mentioned identifiers are
        # complementary. Keep both in the recall gate so a question such as
        # "Transformer + an unseen method" does not discard the unseen method.
        topic_filter = entity_filter if not concepts else f"({base_topic_filter} OR {entity_filter})"
    else:
        # With no English entity available, use the concept filter if one was
        # explicitly present. Otherwise leave the topic unconstrained and let
        # relation/aspect routes recall papers instead of querying Chinese
        # prose literally.
        topic_filter = base_topic_filter if concepts else ""
    relation = infer_literature_relation(query)
    signal_terms = []
    # Preserve salient English phrases extracted from Chinese questions. This
    # is intentionally generic: it applies to any topic, not a keyword list
    # for one model family.
    for term in _expanded_query_terms(query):
        if len(term) >= 3 and term.lower() not in {"what", "with", "from", "into", "how", "does", "large", "model"}:
            signal_terms.append(term)
    signal_terms = list(dict.fromkeys(signal_terms))[:16]
    dimensions = {
        "limitations": (
            ("direct limitations", "limitation OR limitations OR drawback OR shortcoming"),
            ("failure and robustness", "failure OR robustness OR generalization"),
            ("theory and efficiency", "expressivity OR complexity OR scalability"),
        ),
        "advantages": (
            ("direct benefits", "advantage OR advantages OR benefit OR benefits"),
            ("inductive and efficiency properties", "efficiency OR parameter OR equivariance OR generalization"),
            ("comparative evidence", "comparison OR compared OR benchmark OR evaluation"),
        ),
        "comparison": (
            ("direct comparison", "comparison OR compared OR versus"),
            ("empirical evaluation", "benchmark OR evaluation OR performance"),
            ("trade-offs", "efficiency OR robustness OR generalization OR scalability"),
        ),
        "training": (
            ("training objectives", "pretraining OR fine-tuning OR instruction tuning"),
            ("adaptation methods", "alignment OR adaptation OR transfer learning"),
            ("empirical training evidence", "ablation OR evaluation OR benchmark"),
        ),
        "deployment": (
            ("runtime behavior", "latency OR memory OR throughput OR runtime"),
            ("serving constraints", "deployment OR hardware OR efficiency"),
            ("empirical deployment evidence", "benchmark OR evaluation OR performance"),
        ),
        "retrieval": (
            ("retrieval behavior", "retrieval OR recall OR ranking OR reranking"),
            ("corpus and indexing", "corpus OR index OR candidate OR document"),
            ("empirical retrieval evidence", "benchmark OR evaluation OR precision"),
        ),
        "memory": (
            ("memory behavior", "memory OR retention OR history OR storage"),
            ("forgetting and eviction", "forgetting OR eviction OR compression"),
            ("empirical memory evidence", "benchmark OR evaluation OR ablation"),
        ),
        "mechanism": (
            ("architecture", "architecture OR mechanism OR framework"),
            ("method", "method OR algorithm OR representation"),
            ("evaluation", "evaluation OR benchmark OR analysis"),
        ),
        "evidence": (
            ("experimental results", "experiment OR benchmark OR evaluation"),
            ("metrics and comparison", "performance OR comparison OR ablation"),
            ("reproducibility", "dataset OR implementation OR analysis"),
        ),
        "survey": (
            ("survey", "survey OR review OR overview"),
            ("recent evidence", "benchmark OR evaluation OR analysis"),
            ("open problems", "challenge OR limitation OR future"),
        ),
        "definition": (
            ("foundational paper", "architecture OR framework OR method"),
            ("mechanism", "mechanism OR representation OR algorithm"),
            ("evaluation", "evaluation OR benchmark OR analysis"),
        ),
        "focused": (
            ("core topic", "method OR analysis OR evaluation"),
            ("evidence", "benchmark OR experiment OR comparison"),
            ("context", "survey OR review OR overview"),
        ),
    }
    plan = []
    for dimension, terms in dimensions[relation]:
        relation_terms = terms.split(" OR ")
        # Preserve sub-question vocabulary (process supervision, alignment,
        # multi-hop, etc.) across all facets so a comparison query cannot lose
        # the actual phenomenon being compared.
        relation_terms.extend(signal_terms)
        expression = " OR ".join(f"all:{term}" for term in dict.fromkeys(relation_terms))
        query_expression = f'{topic_filter} AND ({expression})' if topic_filter else f'({expression})'
        # A route built only from generic research vocabulary cannot describe
        # any question, so it is noise in diagnostics and, when the model
        # planner is unavailable, becomes the entire retrieval basis. Without
        # a topic filter or query-visible signal terms the expression is pure
        # relation vocabulary regardless of the individual words used.
        if not include_topicless_routes and (
            not topic_filter and not signal_terms or not has_topic_anchor(query_expression)
        ):
            continue
        plan.append({
            "dimension": dimension,
            "relation": relation,
            "query": query_expression,
        })
    # Add a small generic entity-pair/single-entity ladder for open-domain
    # names. This prevents a multi-method question from becoming an impossible
    # all-terms AND query while retaining the relation-aware plans above.
    if entities:
        for index, entity in enumerate(entities[:4]):
            for other in entities[index + 1:4]:
                plan.append({
                    "dimension": "entity relation",
                    "relation": relation,
                    "query": f'(ti:"{entity}" OR abs:"{entity}") AND (ti:"{other}" OR abs:"{other}")',
                })
        for entity in entities[:4]:
            plan.append({
                "dimension": "entity recall",
                "relation": relation,
                "query": f'(ti:"{entity}" OR abs:"{entity}")',
            })
    return plan


def build_literature_queries(query: str) -> list[str]:
    """Create a deterministic fallback ladder from the current question only.

    This path deliberately has no topic-specific expansions or paper anchors.
    When the LLM planner is unavailable, the user's own terms and generic
    aliases already present in the query are the only source of recall.
    """
    original = " ".join((query or "").split()).strip()
    if infer_literature_relation(original) != "focused":
        return [item["query"] for item in build_literature_query_plan(original)]
    terms = _expanded_query_terms(original)
    concepts = requested_concepts(original)
    for concept in concepts:
        terms.extend(
            alias for alias in _CONCEPT_ALIASES.get(concept, ())
            if alias.isascii()
        )
    terms = list(dict.fromkeys(term for term in terms if len(term) >= 3))
    return list(dict.fromkeys([original, *terms]))[:MAX_SEARCH_ROUNDS]


def build_adaptive_literature_queries(query: str, source: str = "arxiv") -> list[str]:
    """Build generic fallback routes from query-local language only."""
    phrases = [
        token for token in _expanded_query_terms(query)
        if len(token) >= 3 and token.lower() not in {"please", "tell", "latest"}
    ]
    phrases = list(dict.fromkeys(" ".join(item.split()) for item in phrases))
    if not phrases:
        return []
    if source == "arxiv":
        return [" OR ".join(f'ti:"{phrase}" OR abs:"{phrase}"' for phrase in phrases[:8])]
    return [" ".join(phrases[:8])]


# Vocabulary that names a research generic rather than a subject. Both the
# plan builder and the search round consult this one list so a route cannot be
# considered topic-bearing in one place and topicless in the other.
GENERIC_QUERY_TERMS = frozenset({
    "method", "methods", "analysis", "evaluation", "experiment", "experiments",
    "benchmark", "comparison", "performance", "architecture", "framework",
    "model", "models", "approach", "approaches", "research", "study",
    "survey", "surveys", "review", "reviews", "overview", "overviews",
})

# arXiv field prefixes and Boolean operators. They are syntax, not subject
# matter, so counting them as entity terms would let a purely generic route
# pass a topic check.
_QUERY_SYNTAX_TERMS = frozenset({"all", "ti", "abs", "and", "or", "not"})


def has_topic_anchor(query_expression: str) -> bool:
    """Report whether a search route names anything beyond generic vocabulary.

    Returns False for a route such as ``(all:method OR all:analysis)``, which
    describes no research question and must not be sent to a source adapter.
    """
    terms = re.findall(r"[A-Za-z][A-Za-z0-9-]*", str(query_expression or ""))
    return any(
        term.lower() not in GENERIC_QUERY_TERMS
        and term.lower() not in _QUERY_SYNTAX_TERMS
        for term in terms
    )


def requested_concepts(query: str) -> set[str]:
    lowered = str(query or "").lower()
    return {
        key for key, aliases in _CONCEPT_ALIASES.items()
        if any(_contains_alias(lowered, alias) for alias in aliases)
    }


# High-precision lexical disambiguation for abbreviations that collide with
# unrelated fields. This is a generic, data-driven co-occurrence rule, not a
# topic-to-paper map: when a question names one of these abbreviations as a
# standalone token, a candidate must also carry at least one expansion or field
# context term in its own title/abstract, otherwise the lexical match is almost
# certainly a namesake (VLA = vision-language-action in robotics, but also the
# VLA-4 antigen, the Very Large Array radio telescope, and vented lead-acid).
# Add another row here when an abbreviation shows the same collision. The
# semantic judge still runs after this lexical gate.
AMBIGUOUS_ABBREVIATIONS = {
    "vla": {
        "expansions": ("vision language action",),
        "context_terms": (
            "robot", "robotic", "robotics", "manipulation", "embodied",
            "visuomotor", "visuo motor", "robot policy", "policy learning",
            "action model", "language conditioned", "manipulation policy",
            "rt-2", "rt 2", "libero",
        ),
    },
}


def _normalize_lexical_text(text: str) -> str:
    """Lower-case and fold any non-alphanumeric run to a single space."""
    return re.sub(r"[^a-z0-9]+", " ", str(text or "").lower())


def _ambiguous_abbreviation_block(
    query_lower: str, title: str, abstract: str
) -> tuple[bool, str | None]:
    """Reject a namesake candidate for a collision-prone abbreviation.

    Returns ``(True, reason)`` only when the query names the abbreviation, the
    candidate contains it, and the candidate carries none of that field's
    disambiguating terms despite having a usable abstract. A candidate with a
    missing or truncated abstract is left to the semantic judge instead of being
    killed on incomplete metadata.
    """
    normalized_query = _normalize_lexical_text(query_lower)
    normalized_haystack = _normalize_lexical_text(f"{title} {abstract}")
    for abbr, spec in AMBIGUOUS_ABBREVIATIONS.items():
        token = _normalize_lexical_text(abbr).strip()
        pattern = rf"(?<![a-z0-9]){re.escape(token)}(?![a-z0-9])"
        # Only intervene when the question actually names the abbreviation and
        # the candidate matched it; otherwise ordinary coverage gates decide.
        if not re.search(pattern, normalized_query):
            continue
        if not re.search(pattern, normalized_haystack):
            continue
        disambiguators = tuple(spec.get("expansions", ())) + tuple(spec.get("context_terms", ()))
        if any(_normalize_lexical_text(term).strip() in normalized_haystack for term in disambiguators):
            continue
        if len(str(abstract or "").strip()) >= 40:
            return True, (
                f"ambiguous_abbreviation_without_context:{token} "
                "(collision-prone abbreviation without its field's disambiguating terms)"
            )
    return False, None


def score_literature_relevance(query: str, paper: dict) -> dict:
    """Score whether a paper can support a scientific answer.

    This is a conservative lexical gate.  It is intentionally independent of
    the answer model so unrelated search results cannot become citations.
    """
    paper_id = str(paper.get("paper_id", "") or paper.get("id", "")).lower().replace("v1", "")
    title = str(paper.get("title", "") or "").lower()
    abstract = str(paper.get("abstract", "") or "").lower()
    haystack = f"{title} {abstract}"
    query_lower = str(query or "").lower()
    # NOTE: ``haystack`` must contain the candidate paper's own text only.
    # Appending the question to it makes every evidence gate self-satisfying:
    # a query such as "What are the limitations of X?" would supply the very
    # "limitation + X" co-occurrence that _has_direct_architecture_limitation
    # exists to look for in the paper. Cross-lingual matching is applied to
    # the query side of concept matching only, never to this haystack.
    # A capitalised token is the only available signal for "this is a named
    # object", and sentence position corrupts it: an English question that
    # starts with "What ..." or "How ..." capitalises a function word by
    # grammar, which then became a hard evidence lock requiring the candidate
    # to contain the literal word "what". Capitalised function words are
    # therefore never treated as named objects; the reviewer vocabulary in
    # ``query_terms`` supplies the list rather than a second one here.
    explicit_terms = [
        token.lower()
        for token in re.findall(r"\b[A-Z][A-Za-z0-9-]{1,}\b", str(query or ""))
        if token.lower() not in {"ai", "pdf", "vlm", "rag", "rlhf", "ssm", "kv"}
        and token.lower() not in ENGLISH_STOPWORDS
    ]
    # Names introduced as examples broaden recall; they are not mandatory
    # evidence targets. Treating every capitalized example as a hard lock
    # rejects topic surveys while admitting unrelated namesakes.
    example_spans = re.findall(
        r"(?:如|例如|e\.g\.|such as)\s*([^?？;；。]{1,160})",
        str(query or ""),
        flags=re.IGNORECASE,
    )
    example_terms = {
        token.lower()
        for span in example_spans
        for token in re.findall(r"\b[A-Z][A-Za-z0-9-]{1,}\b", span)
    }
    hard_explicit_terms = [term for term in explicit_terms if term not in example_terms]
    explicit_hits = [token for token in explicit_terms if token in haystack]
    limitation_query = is_limitation_query(query_lower)
    # Only an explicit weakness question ("limitations", "drawbacks") demands
    # direct architecture-limitation evidence. A survey question such as
    # "What are the key challenges of X?" is answered by a survey of X, so the
    # strict same-sentence gate must not be applied to it.
    strict_limitation_gate = requires_direct_limitation_evidence(query_lower)
    comparison_query = is_comparison_query(query_lower)
    # Diagnostics only. These fields record which gate decided the outcome so a
    # rejection can be attributed without re-deriving it; they never change
    # ``accepted``, ``score`` or any branch taken below.
    rejection_reason = None
    accepted_by = []
    # Cross-lingual bridge. ``augment_scoring_query`` adds the English
    # terminology resolvable for this question. It is applied to the QUERY side
    # only: ``matching_query`` feeds concept resolution, while ``haystack``
    # above stays the candidate paper's own text. Feeding bridge terms into
    # ``haystack`` would make every evidence gate self-satisfying, because the
    # question would then supply the very words the gate looks for in the
    # paper.
    matching_query, bridge = augment_scoring_query(query)
    matching_lower = matching_query.lower()
    # Concept resolution must use the same tolerant matcher as everywhere else
    # (``requested_concepts``): a free-text query phrase with function words
    # stripped ("Mixture Experts") names the same concept as "Mixture of
    # Experts", and reporting ``degraded`` for it would mislabel the gate.
    requested = sorted(requested_concepts(matching_query))
    # Degraded means the gate is running without English terminology it can
    # match, so a 0.0 score means "unmatchable question", not "no relevant
    # paper". It is reported rather than silently rejecting everything.
    unresolved_terms = [
        term for term in (bridge.get("chinese_terms") or [])
        if not str(term).isascii()
    ]
    if not requested and unresolved_terms:
        scoring_status = "degraded"
        rejection_reason = "no_english_concept_bridge"
    else:
        scoring_status = "ok"
    if not requested:
        # Generic scientific topics still need a lexical gate. Do not use
        # unrelated papers merely because the query contains words such as
        # "method" or "model".
        terms = [token.lower() for token in _expanded_query_terms(query)
                 if len(token) >= 3 and token.lower() not in {
                     "please", "explain", "describe", "analyze", "method", "model",
                     "architecture", "algorithm", "what", "the", "and",
                 }]
        if relation := infer_literature_relation(query_lower):
            if relation == "advantages":
                terms.extend(("efficiency", "deployment", "latency", "memory", "cost", "performance"))
            elif relation == "limitations":
                terms.extend(("limitation", "challenge", "scalability", "generalization", "capacity"))
        terms = list(dict.fromkeys(terms))
        title_hits = [term for term in terms if term in title]
        abstract_hits = [term for term in terms if term in abstract]
        score = min(1.0, (0.5 if title_hits else 0) + 0.35 * min(len(abstract_hits), 3) / 3)
        accepted = score >= get_relevance_threshold() and bool(title_hits or len(set(abstract_hits)) >= 2)
        # This branch has no requested concept to anchor on, so a question about
        # named objects reaches here rather than the concept branch below. A
        # comparison constrains evidence on both sides: "How does DoRA differ
        # from LoRA?" cannot be answered by a paper documenting only LoRA, so
        # every named object is required. Non-comparison questions keep the
        # permissive behaviour this branch has always had.
        if comparison_query and hard_explicit_terms:
            # A comparison answer is assembled from several papers, each covering
            # one side; requiring a single paper to mention every named object
            # rejected entire comparison questions (e.g. RAG vs long-context vs
            # CAG). Require at least one named object here; the ledger layer
            # still enforces that every compared side has evidence.
            accepted = accepted and any(term in haystack for term in hard_explicit_terms)
            if not accepted:
                rejection_reason = "named_object_missing"
        if _requires_ai_domain(matching_query) and not _has_ai_domain_signal(haystack):
            accepted = False
            rejection_reason = "domain_mismatch"
        if not _has_relation_evidence(matching_query, haystack):
            accepted = False
            rejection_reason = "missing_relation_evidence"
        _abbr_blocked, _abbr_reason = _ambiguous_abbreviation_block(matching_lower, title, abstract)
        if _abbr_blocked:
            accepted = False
            rejection_reason = _abbr_reason
        return {
            "score": round(score, 4), "accepted": accepted,
            "scoring_status": scoring_status,
            "unresolved_terms": unresolved_terms if scoring_status == "degraded" else [],
            "accepted_by": ["generic_term_coverage"] if accepted else [],
            "rejection_reason": None if accepted else (
                rejection_reason
                or ("no_english_concept_bridge" if scoring_status == "degraded"
                    else "below_threshold" if score < get_relevance_threshold()
                    else "no_generic_term_coverage")
            ),
            "matched_concepts": [], "title_matched": title_hits,
            "abstract_matched": abstract_hits, "concept_coverage": len(set(abstract_hits)),
            "core_concept_coverage": 0, "explicit_terms": explicit_terms,
            "explicit_hits": explicit_hits, "hard_explicit_terms": hard_explicit_terms,
            "anchor": None,
        }
    matched = [key for key in requested if _concept_matches(haystack, key)]
    title_matched = [key for key in matched
                     if _concept_matches(title, key)]
    abstract_matched = [key for key in matched
                        if _concept_matches(abstract, key)]
    coverage = len(set(matched))
    score = min(1.0, 0.45 * min(len(title_matched), 2) / 2
                + 0.25 * min(len(abstract_matched), 3) / 3
                + 0.30 * min(coverage, 3) / 3)
    # A title-level exact technical hit is strong evidence even when an
    # abstract is truncated by the search API.
    if title_matched:
        score = max(score, 0.40)
    core_coverage = len(set(matched) & _CORE_CONCEPTS)
    core_title_match = bool(set(title_matched) & _CORE_CONCEPTS)
    intent_hits = []
    intent_groups = {
        "definition": ("definition", "architecture", "framework", "introduce", "propose"),
        "mechanism": ("mechanism", "method", "attention", "retrieval", "algorithm"),
        "comparison": ("comparison", "compare", "advantage", "limitation"),
        "experiment": ("experiment", "benchmark", "evaluation", "result"),
    }
    for name, terms in intent_groups.items():
        if any(term in query_lower for term in terms) and any(term in haystack for term in terms):
            intent_hits.append(name)
    score = min(1.0, score + 0.08 * min(len(intent_hits), 2))
    # A relevant paper often mentions one target concept in its abstract but
    # does not repeat a second alias. Requiring two concept hits made common
    # single-topic questions (e.g. a model's advantages) fail after valid
    # recall. The score and semantic judge still gate acceptance; concept
    # coverage is used for ranking/diagnostics rather than an artificial
    # two-hit minimum.
    accepted = score >= get_relevance_threshold() and (
        core_title_match or core_coverage >= 1
    )
    if core_title_match:
        accepted_by.append("core_concept_in_title")
    if core_coverage >= 1:
        accepted_by.append("core_concept_coverage")
    if not accepted and get_relevance_threshold() > score:
        rejection_reason = "below_threshold"
    # A named method/model in the question is a hard evidence constraint. A
    # paper about generic fine-tuning, for example, cannot answer a DoRA or
    # SALA question unless that named object appears in its metadata.
    #
    # A comparison question constrains evidence on both sides, so every named
    # object is required; otherwise "How does DoRA differ from LoRA?" is
    # satisfied by a paper documenting only LoRA, which cannot describe the
    # comparison at all. Non-comparison questions keep the any-of semantics.
    if hard_explicit_terms:
        accepted = accepted and any(term in haystack for term in hard_explicit_terms)
        if not accepted and rejection_reason is None:
            rejection_reason = "named_object_missing"
    # Generic relation concepts are too ambiguous to establish the paper's
    # domain by themselves. If the question also contains a more specific
    # subject, require the candidate to cover at least one such subject.
    generic_relation_concepts = {"alignment", "video", "sequence", "memory"}
    specific_requested = set(requested) - generic_relation_concepts
    if specific_requested:
        accepted = accepted and bool(set(matched) & specific_requested)
        if not accepted and rejection_reason is None:
            rejection_reason = "no_specific_subject_coverage"
    # For a limitation request, a paper that merely mentions Transformer is
    # insufficient.  Require at least one explicit limitation theme in its
    # title/abstract (complexity, sequence length, formal languages, arithmetic,
    # expressivity, etc.). This prevents latest-but-unrelated Transformer
    # papers from becoming citations.
    limitation_hits = [term for term in DIRECT_LIMITATION_EVIDENCE_TERMS
                       if term.isascii() and term in haystack]
    if strict_limitation_gate:
        arch_hit = any(term in haystack for term in _ARCHITECTURE_LIMITATION_SIGNALS)
        if limitation_hits or arch_hit:
            score = min(1.0, score + 0.12)
        # Relaxed: a paper counts as direct limitation evidence if it either
        # uses limitation vocabulary, or shows concrete architecture-limitation
        # signals (complexity/memory/latency/etc.). The old AND gate rejected
        # original-method papers whose flaws live in the body rather than the
        # title/abstract.
        accepted = accepted and (bool(limitation_hits) or arch_hit or _has_direct_architecture_limitation(haystack, requested))
        if not accepted and rejection_reason is None:
            rejection_reason = "no_direct_limitation_evidence"
    if _requires_ai_domain(matching_query) and not _has_ai_domain_signal(haystack):
        accepted = False
        if rejection_reason is None:
            rejection_reason = "domain_mismatch"
    if not _has_relation_evidence(matching_query, haystack):
        accepted = False
        if rejection_reason is None:
            rejection_reason = "missing_relation_evidence"
    _abbr_blocked, _abbr_reason = _ambiguous_abbreviation_block(matching_lower, title, abstract)
    if _abbr_blocked:
        accepted = False
        rejection_reason = _abbr_reason
    return {
        "score": round(score, 4),
        "accepted": accepted,
        "scoring_status": scoring_status,
        "unresolved_terms": unresolved_terms if scoring_status == "degraded" else [],
        "accepted_by": accepted_by,
        "rejection_reason": rejection_reason,
        "matched_concepts": matched,
        "title_matched": title_matched,
        "abstract_matched": abstract_matched,
        "concept_coverage": coverage,
        "core_concept_coverage": core_coverage,
        "intent_matches": intent_hits,
        "limitation_topics": limitation_hits,
        "explicit_terms": explicit_terms,
        "explicit_hits": explicit_hits,
        "hard_explicit_terms": hard_explicit_terms,
        "anchor": None,
    }


def is_explicit_paper_request(query: str) -> bool:
    lowered = (query or "").lower()
    return bool(re.search(r"(?:arxiv\s*:\s*)?\d{4}\.\d{4,5}(?:v\d+)?", lowered)) or any(
        marker in lowered for marker in PAPER_MARKERS
    )


def _marker_present(text: str, marker: str) -> bool:
    """Match a routing marker without matching inside a longer English word.

    Plain substring matching put ``hi`` inside "arc**hi**tecture", so a
    research question such as "Explain the limitations of the Transformer
    architecture" was classified as a greeting and routed to the no-tool
    answer path, bypassing literature retrieval. ASCII markers are matched on
    word boundaries; non-ASCII markers keep substring matching, because
    Chinese has no word delimiters and those markers do not occur inside
    longer terms.
    """
    if any(ord(char) > 127 for char in marker):
        return marker in text
    return bool(re.search(rf"(?<![a-z0-9]){re.escape(marker)}(?![a-z0-9])", text))


def is_obvious_short_query(query: str) -> bool:
    lowered = (query or "").lower().strip()
    if len(lowered) > 100:
        return False
    return any(_marker_present(lowered, marker) for marker in (
        "你好", "您好", "hi", "hello", "help", "帮助", "你能做什么", "等于多少", "怎么用", "退出",
    ))


def needs_research_tools(query: str) -> bool:
    lowered = (query or "").lower()
    if is_explicit_paper_request(lowered):
        return True
    # Source requests are research requests even when the user phrases the
    # task as "讲解" rather than one of the method/explanation keywords below.
    # Without this guard, e.g. "引用几篇 arXiv 论文" could be sent to the
    # no-tool direct model, which has to admit that it did not retrieve them.
    if any(marker in lowered for marker in RESEARCH_MARKERS):
        return True
    if any(marker in lowered for marker in CURRENT_MARKERS):
        return True
    has_scientific_intent = any(marker in lowered for marker in (
        "解释", "说明", "分析", "原理", "架构", "方法", "模型", "算法", "公式",
        "explain", "describe", "analyze", "architecture", "method", "model", "algorithm",
    ))
    # A non-explicit scientific question should search arXiv first. The
    # relevance gate decides whether any returned paper is usable; if not,
    # the caller produces the clearly labelled generic fallback.
    generic_nonresearch = ("数据库索引", "数据库查询", "data structure", "database index")
    if any(marker in lowered for marker in generic_nonresearch):
        return False
    return has_scientific_intent or any(marker in lowered for marker in TECHNICAL_MARKERS)


def preferred_literature_source(query: str) -> str:
    # TEMP: only arXiv source is enabled. Restore below when re-enabling other sources.
    return "arxiv"

    lowered = (query or "").lower()
    # Explicit arXiv requests must not be redirected by substring matches in
    # unrelated words such as ``generation`` containing ``gene``.
    if re.search(r"\barxiv\b|arxiv\.org", lowered):
        return "arxiv"

    def matches_marker(marker: str) -> bool:
        if any(ord(char) > 127 for char in marker):
            return marker in lowered
        return bool(re.search(rf"(?<![a-z0-9]){re.escape(marker)}(?![a-z0-9])", lowered))

    return "pubmed" if any(matches_marker(marker) for marker in BIOMEDICAL_MARKERS) else "arxiv"


def route_query(query: str, classifier_category: str | None = None) -> Dict[str, str]:
    """Return a stable route name and reason for observability."""
    if is_explicit_paper_request(query):
        return {"route": "paper_evidence", "reason": "explicit arXiv/PDF request"}
    if is_obvious_short_query(query):
        return {"route": "direct_llm", "reason": "obvious short query"}
    if needs_research_tools(query):
        return {"route": "science_literature", "reason": "scientific literature evidence requested"}
    if classifier_category == "SAFE_SENSITIVE":
        return {"route": "blocked", "reason": "safety classifier"}
    # General explanatory questions are faster and more reliable through one
    # bounded call; source-backed questions were handled above.
    return {"route": "direct_llm", "reason": "general knowledge question"}


def direct_query_profile(query: str) -> Dict[str, object]:
    """Choose a compact response profile without another model call."""
    lowered = (query or "").lower()
    if any(marker in lowered for marker in ("步骤", "怎么", "如何", "how", "step")):
        return {"style": "step_by_step", "max_tokens": 1200}
    if any(marker in lowered for marker in ("比较", "区别", "优缺点", "compare", "difference")):
        return {"style": "comparison", "max_tokens": 1400}
    if any(marker in lowered for marker in ("解释", "什么是", "原理", "why", "what is")):
        return {"style": "explanation", "max_tokens": 1200}
    return {"style": "concise_answer", "max_tokens": 1000}


def is_usable_answer(text: str) -> bool:
    """Reject empty/API-fragment responses before marking a direct answer complete."""
    value = str(text or '').strip()
    if len(value) < 2:
        return False
    lowered = value.lower()
    return not any(marker in lowered for marker in (
        'tool_calls', 'function_call', 'download_files', 'document_qa',
        'model_request_url', 'internal server error',
    ))


def get_direct_cache(query: str, model: str) -> str | None:
    key = ((query or "").strip().lower(), model or "")
    cached = _DIRECT_CACHE.get(key)
    if not cached:
        return None
    timestamp, answer = cached
    if time.monotonic() - timestamp > DIRECT_CACHE_TTL:
        _DIRECT_CACHE.pop(key, None)
        return None
    return answer


def put_direct_cache(query: str, model: str, answer: str) -> None:
    if not answer:
        return
    key = ((query or "").strip().lower(), model or "")
    _DIRECT_CACHE[key] = (time.monotonic(), answer)
    if len(_DIRECT_CACHE) > 64:
        oldest = min(_DIRECT_CACHE, key=lambda item: _DIRECT_CACHE[item][0])
        _DIRECT_CACHE.pop(oldest, None)


def _literature_key(source: str, query: str, limit: int) -> tuple[str, str, int]:
    return ((source or "").strip().lower(), f"{LITERATURE_CACHE_VERSION}:" + " ".join((query or "").lower().split()), int(limit))


def get_literature_cache(source: str, query: str, limit: int = 3):
    """Return a recent search result without re-hitting external literature APIs."""
    key = _literature_key(source, query, limit)
    cached = _LITERATURE_CACHE.get(key)
    if cached:
        timestamp, value = cached
        if time.monotonic() - timestamp <= LITERATURE_CACHE_TTL:
            return value
        _LITERATURE_CACHE.pop(key, None)
    try:
        _LITERATURE_CACHE_DB.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(str(_LITERATURE_CACHE_DB), timeout=10)
        try:
            connection.execute(
                "CREATE TABLE IF NOT EXISTS literature_cache ("
                "cache_key TEXT PRIMARY KEY, created_at REAL NOT NULL, payload TEXT NOT NULL)"
            )
            disk_key = json.dumps(key, ensure_ascii=False, separators=(",", ":"))
            row = connection.execute(
                "SELECT created_at, payload FROM literature_cache WHERE cache_key = ?", (disk_key,)
            ).fetchone()
            if not row:
                return None
            if time.time() - float(row[0]) > LITERATURE_CACHE_TTL:
                connection.execute("DELETE FROM literature_cache WHERE cache_key = ?", (disk_key,))
                connection.commit()
                return None
            value = json.loads(row[1])
            _LITERATURE_CACHE[key] = (time.monotonic(), value)
            return value
        finally:
            connection.close()
    except (OSError, sqlite3.Error, TypeError, ValueError):
        return None


def put_literature_cache(source: str, query: str, value, limit: int = 3) -> None:
    if not value:
        return
    key = _literature_key(source, query, limit)
    _LITERATURE_CACHE[key] = (time.monotonic(), value)
    if len(_LITERATURE_CACHE) > 32:
        oldest = min(_LITERATURE_CACHE, key=lambda item: _LITERATURE_CACHE[item][0])
        _LITERATURE_CACHE.pop(oldest, None)
    try:
        _LITERATURE_CACHE_DB.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(str(_LITERATURE_CACHE_DB), timeout=10)
        try:
            connection.execute(
                "CREATE TABLE IF NOT EXISTS literature_cache ("
                "cache_key TEXT PRIMARY KEY, created_at REAL NOT NULL, payload TEXT NOT NULL)"
            )
            connection.execute(
                "INSERT OR REPLACE INTO literature_cache(cache_key, created_at, payload) VALUES (?, ?, ?)",
                (json.dumps(key, ensure_ascii=False, separators=(",", ":")), time.time(),
                 json.dumps(value, ensure_ascii=False, default=str)),
            )
            connection.execute(
                "DELETE FROM literature_cache WHERE created_at < ?", (time.time() - LITERATURE_CACHE_TTL,)
            )
            connection.commit()
        finally:
            connection.close()
    except (OSError, sqlite3.Error, TypeError, ValueError):
        # Cache failure must never make literature retrieval fail.
        pass


def get_paper_evidence_cache(source: str, paper_id: str, pdf_parse_mode: str = "local"):
    """Return cached official full-text/parser data for a paper."""
    key = ((source or '').strip().lower(), (paper_id or '').strip(), (pdf_parse_mode or 'local').strip().lower())
    cached = _PAPER_EVIDENCE_CACHE.get(key)
    if not cached:
        return None
    timestamp, value = cached
    if time.monotonic() - timestamp > PAPER_EVIDENCE_CACHE_TTL:
        _PAPER_EVIDENCE_CACHE.pop(key, None)
        return None
    return value


def put_paper_evidence_cache(source: str, paper_id: str, value, pdf_parse_mode: str = "local") -> None:
    if not value or not paper_id:
        return
    key = ((source or '').strip().lower(), (paper_id or '').strip(), (pdf_parse_mode or 'local').strip().lower())
    _PAPER_EVIDENCE_CACHE[key] = (time.monotonic(), value)
    if len(_PAPER_EVIDENCE_CACHE) > 16:
        oldest = min(_PAPER_EVIDENCE_CACHE, key=lambda item: _PAPER_EVIDENCE_CACHE[item][0])
        _PAPER_EVIDENCE_CACHE.pop(oldest, None)


def build_science_evidence_notice(ledger: list[dict]) -> str:
    """Build a deterministic disclosure for a literature-backed answer."""
    lines = ["## 证据可用性"]
    if not ledger:
        return "\n".join(lines + ["- 未获得可用的官方文献记录；本回答不应视为文献结论。"])
    for item in ledger:
        citation = item.get("citation", "")
        title = item.get("title", "") or item.get("paper_id", "")
        access = item.get("access", "abstract_only")
        if access in {"official_pdf_fulltext", "official_pmc_fulltext"}:
            detail = "已读取官方全文或 PMC 全文；仍受解析风险和选段范围限制。"
        else:
            detail = "仅有官方摘要/元数据，不能据此确认全文中的公式、表格或图结构。"
        if item.get("degradation_reason"):
            detail += f" {item['degradation_reason']}"
        # Show which query keywords this paper actually matched
        matched = item.get("matched_keywords") or []
        if matched:
            kw_str = "、".join(matched[:8])
            if len(matched) > 8:
                kw_str += f" 等{len(matched)}个"
            detail += f" 命中关键词：{kw_str}。"
        else:
            detail += " 未命中显式查询关键词（可能通过语义相关性入选）。"
        lines.append(f"- {citation} {title}：{detail}")
    return "\n".join(lines)


def verify_science_citations(answer: str, ledger: list[dict]) -> dict:
    """Check inline citation markers against the literature evidence ledger.

    Accepts both forms the chain may emit: the positional ``[n]`` marker and
    the verifiable ``[Source:id]`` marker produced by
    ``literature_sources.citation_label``. A source marker is validated against
    the ledger's own labels, so an invented identifier is reported rather than
    silently accepted.
    """
    text = str(answer or '')
    numbers = sorted({int(value) for value in re.findall(r'(?<!\w)\[(\d+)\]', text)})
    labels = list(dict.fromkeys(
        match.strip() for match in re.findall(r'\[([A-Za-z][A-Za-z0-9-]*:[^\]\s]+)\]', text)
    ))
    source_count = len(ledger or [])
    known_labels = {
        # Compare without brackets: the capture group excludes them, while the
        # ledger stores the full marker.
        str(item.get("label") or "").strip().strip("[]")
        for item in (ledger or [])
        if str(item.get("label") or "").strip()
    }
    issues = []
    for number in numbers:
        if number < 1 or number > source_count:
            issues.append(f"引用编号 [{number}] 超出可用文献范围 (1..{source_count})")
    for label in labels:
        if label not in known_labels:
            issues.append(f"引用来源 [{label}] 不在本轮证据账本中，可能是编造的来源")
    if not numbers and not labels:
        issues.append("正文没有文献引用标记，无法确认科研结论对应的来源")
    return {
        "status": "verified" if not issues else "unverified",
        "citation_numbers": numbers,
        "citation_labels": labels,
        "source_count": source_count,
        "issues": issues,
    }


def build_science_citation_report(check: dict) -> str:
    if not check:
        return ''
    issues = check.get('issues') or []
    if issues:
        return "## 引用核验\n\n" + "\n".join(f"- {issue}" for issue in issues)
    return (
        "## 引用核验\n\n"
        f"已通过确定性核验：正文引用 {len(check.get('citation_numbers') or [])} 个，"
        f"可用文献 {check.get('source_count', 0)} 个，未发现越界编号。"
    )


def select_relevant_excerpt(text: str, query: str, max_chars: int = 14000) -> dict:
    """Select bounded, query-relevant evidence without inventing text.

    The selector is deterministic: it scores source lines by literal query
    terms, keeps surrounding windows, and always includes document boundaries.
    It returns the excerpt plus enough metadata for the caller to disclose
    that the model saw a bounded selection rather than the entire source.
    """
    source = str(text or '').strip()
    limit = max(1, int(max_chars))
    if not source:
        return {'text': '', 'selected': False, 'truncated': False, 'matched_terms': [], 'character_count': 0}
    if len(source) <= limit:
        return {'text': source, 'selected': False, 'truncated': False, 'matched_terms': [], 'character_count': len(source)}

    terms = []
    for token in re.findall(r'[A-Za-z0-9][A-Za-z0-9_+.-]{1,}|[\u4e00-\u9fff]{2,}', (query or '').lower()):
        if token not in terms:
            terms.append(token)
    lines = [line.strip() for line in source.splitlines() if line.strip()]
    scored = []
    for index, line in enumerate(lines):
        lowered = line.lower()
        score = sum((2 if token in lowered else 0) for token in terms)
        if score:
            scored.append((score, index))
    scored.sort(key=lambda item: (-item[0], item[1]))
    selected_indices = set()
    # Preserve the strongest local matches, but do not let a term repeated in
    # an introduction monopolize the entire evidence window. Scientific PDFs
    # often repeat the paper's central name (for example "chain of thought")
    # on every page; sampling its document-wide positions gives the answer
    # model method, experiment, and conclusion evidence as well as the abstract.
    priority_indices = [index for _, index in scored[:8]]
    matched_indices = sorted({index for _, index in scored})
    distributed_indices: list[int] = []
    if len(matched_indices) > 1:
        sample_count = min(10, len(matched_indices))
        for sample in range(sample_count):
            position = round(sample * (len(matched_indices) - 1) / max(1, sample_count - 1))
            distributed_indices.append(matched_indices[position])
    for index in dict.fromkeys(priority_indices + distributed_indices):
        selected_indices.update(range(max(0, index - 3), min(len(lines), index + 4)))
    if lines:
        selected_indices.update(range(min(3, len(lines))))
        selected_indices.update(range(max(0, len(lines) - 3), len(lines)))

    chunks = []
    current = []
    for index, line in enumerate(lines):
        if index in selected_indices:
            current.append(line)
        elif current:
            chunks.append('\n'.join(current))
            current = []
    if current:
        chunks.append('\n'.join(current))
    excerpt = '\n\n[... bounded evidence gap ...]\n\n'.join(chunks)
    if len(excerpt) > limit:
        excerpt = excerpt[:limit].rstrip() + '\n[... excerpt limit reached ...]'
    return {
        'text': excerpt,
        'selected': bool(scored),
        'truncated': True,
        'matched_terms': [terms for terms in terms if any(terms in line.lower() for line in lines)],
        'character_count': len(excerpt),
    }
