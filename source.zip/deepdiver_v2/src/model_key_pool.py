"""SQLite-coordinated API-key rotation for OpenAI-compatible model requests."""

from __future__ import annotations

import os
import hashlib
import json
import logging
import math
import sqlite3
import threading
import time
from contextlib import contextmanager
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Any

import requests


_POOL_LOCK = threading.Lock()
_NEXT_KEY_INDEX = 0
_COOLDOWN_UNTIL: dict[str, float] = {}
_ROTATE_STATUS_CODES = {401, 402, 429}
_LOGGER = logging.getLogger(__name__)


def _key_fingerprint(token: str) -> str:
    """Return a non-reversible identifier; raw credentials never enter state storage."""
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _state_path() -> Path:
    configured = os.getenv("MODEL_KEY_POOL_STATE_PATH", "logs/model_key_pool.sqlite3").strip()
    from user_credentials import current_capability
    cap = current_capability()
    # A worker's child_environment already supplies an owner-specific DB path.
    base = Path(configured or "logs/model_key_pool.sqlite3")
    return base if not cap or os.getenv('SCIASSISTANT_PROVIDER_OWNER') else base.parent / 'users' / cap.owner / base.name


def _connect_state() -> sqlite3.Connection:
    path = _state_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(str(path), timeout=5.0)
    connection.execute("PRAGMA busy_timeout = 5000")
    connection.execute(
        "CREATE TABLE IF NOT EXISTS model_key_cooldowns ("
        "key_fingerprint TEXT PRIMARY KEY, cooldown_until REAL NOT NULL, updated_at REAL NOT NULL)"
    )
    connection.execute(
        "CREATE TABLE IF NOT EXISTS model_key_pool_meta (name TEXT PRIMARY KEY, value INTEGER NOT NULL)"
    )
    if os.name == "posix":
        try:
            os.chmod(path, 0o600)
        except OSError:
            connection.close()
            raise
    return connection


@contextmanager
def _state_connection():
    connection = _connect_state()
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def _record_cooldown(fingerprint: str, cooldown_until: float) -> None:
    with _state_connection() as connection:
        connection.execute(
            "INSERT INTO model_key_cooldowns (key_fingerprint, cooldown_until, updated_at) "
            "VALUES (?, ?, ?) ON CONFLICT(key_fingerprint) DO UPDATE SET "
            "cooldown_until = MAX(model_key_cooldowns.cooldown_until, excluded.cooldown_until), "
            "updated_at = excluded.updated_at",
            (fingerprint, cooldown_until, time.time()),
        )


def _memory_ordered_tokens(tokens: list[str]) -> list[str]:
    global _NEXT_KEY_INDEX
    now = time.time()
    with _POOL_LOCK:
        start = _NEXT_KEY_INDEX % len(tokens)
        _NEXT_KEY_INDEX = (start + 1) % len(tokens)
        ordered = [tokens[(start + offset) % len(tokens)] for offset in range(len(tokens))]
        return [token for token in ordered if _COOLDOWN_UNTIL.get(_key_fingerprint(token), 0.0) <= now]


def _split_tokens(value: Any) -> list[str]:
    if not isinstance(value, str):
        return []
    result = []
    for item in value.replace("\r", "\n").replace(";", "\n").replace(",", "\n").splitlines():
        token = item.strip()
        if token and token not in result:
            result.append(token)
    return result


def configured_model_tokens(headers: dict[str, str] | None = None) -> list[str]:
    """Read model tokens without exposing them to logs or user-facing data."""
    from user_credentials import current_capability, provider_value
    tokens = _split_tokens(provider_value("MODEL_REQUEST_TOKENS"))
    tokens.extend(_split_tokens(provider_value("MODEL_REQUEST_TOKEN")))
    if not tokens and headers and current_capability() is None:
        for name in ("Authorization", "authorization", "csb-token"):
            value = str(headers.get(name) or "")
            if name.lower() == "authorization" and value.lower().startswith("bearer "):
                value = value[7:]
            tokens.extend(_split_tokens(value))
    return list(dict.fromkeys(tokens))


def reset_model_key_pool() -> None:
    """Clear rotation and cooldown state for tests and explicit reconfiguration."""
    global _NEXT_KEY_INDEX
    with _POOL_LOCK:
        _NEXT_KEY_INDEX = 0
        _COOLDOWN_UNTIL.clear()
    try:
        with _state_connection() as connection:
            connection.execute("DELETE FROM model_key_cooldowns")
            connection.execute("DELETE FROM model_key_pool_meta")
    except (OSError, sqlite3.Error):
        # Reset is best-effort when the optional runtime state volume is absent.
        pass


def _retry_after_seconds(response: requests.Response, default: float) -> float:
    value = str(response.headers.get("Retry-After", "") or "").strip()
    if value:
        try:
            return max(0.0, min(float(value), 3600.0))
        except ValueError:
            try:
                parsed = parsedate_to_datetime(value)
                return max(0.0, min(parsed.timestamp() - time.time(), 3600.0))
            except (TypeError, ValueError, OverflowError):
                pass
    return default


def _cooldown_seconds(response: requests.Response) -> float:
    if response.status_code == 429:
        return _retry_after_seconds(response, _configured_cooldown("MODEL_KEY_429_COOLDOWN_SECONDS", 30.0))
    if response.status_code == 402:
        return _configured_cooldown("MODEL_KEY_402_COOLDOWN_SECONDS", 300.0, minimum=1.0)
    return _configured_cooldown("MODEL_KEY_AUTH_COOLDOWN_SECONDS", 300.0, minimum=1.0)


def _configured_cooldown(name: str, default: float, *, minimum: float = 0.0) -> float:
    try:
        value = float(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        value = default
    return max(minimum, min(value, 3600.0))


def _ordered_tokens(tokens: list[str]) -> list[str]:
    global _NEXT_KEY_INDEX
    if not tokens:
        return []
    fingerprints = [_key_fingerprint(token) for token in tokens]
    now = time.time()
    try:
        with _state_connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            # Remove expired fingerprints so old credentials do not accumulate.
            connection.execute("DELETE FROM model_key_cooldowns WHERE cooldown_until <= ?", (now,))
            row = connection.execute(
                "SELECT value FROM model_key_pool_meta WHERE name = 'next_key_index'"
            ).fetchone()
            start = (int(row[0]) if row else 0) % len(tokens)
            connection.execute(
                "INSERT INTO model_key_pool_meta (name, value) VALUES ('next_key_index', ?) "
                "ON CONFLICT(name) DO UPDATE SET value = excluded.value",
                ((start + 1) % len(tokens),),
            )
            cooldown_rows = connection.execute(
                "SELECT key_fingerprint, cooldown_until FROM model_key_cooldowns "
                "WHERE cooldown_until > ? AND key_fingerprint IN ("
                + ",".join("?" for _ in fingerprints)
                + ")",
                (now, *fingerprints),
            ).fetchall()
        cooldowns = {fingerprint: until for fingerprint, until in cooldown_rows}
        ordered = [tokens[(start + offset) % len(tokens)] for offset in range(len(tokens))]
        return [token for token in ordered if cooldowns.get(_key_fingerprint(token), 0.0) <= now]
    except (OSError, sqlite3.Error) as exc:
        # Model availability must not depend on writable local state. If SQLite
        # is unavailable, retain safe per-process rotation and cooldown only.
        _LOGGER.warning("Model key shared state unavailable; using process-local rotation (%s)", type(exc).__name__)
        return _memory_ordered_tokens(tokens)


def _mark_cooldown(token: str, seconds: float) -> None:
    fingerprint = _key_fingerprint(token)
    cooldown_until = time.time() + max(0.0, seconds)
    with _POOL_LOCK:
        _COOLDOWN_UNTIL[fingerprint] = max(_COOLDOWN_UNTIL.get(fingerprint, 0.0), cooldown_until)
    try:
        _record_cooldown(fingerprint, cooldown_until)
    except (OSError, sqlite3.Error) as exc:
        _LOGGER.warning("Model key cooldown could not be persisted (%s)", type(exc).__name__)


def _next_cooldown_seconds(tokens: list[str]) -> float:
    fingerprints = [_key_fingerprint(token) for token in tokens]
    now = time.time()
    try:
        with _state_connection() as connection:
            row = connection.execute(
                "SELECT MIN(cooldown_until) FROM model_key_cooldowns WHERE cooldown_until > ? AND key_fingerprint IN ("
                + ",".join("?" for _ in fingerprints)
                + ")",
                (now, *fingerprints),
            ).fetchone()
        if row and row[0] is not None:
            return max(1.0, float(row[0]) - now)
    except (OSError, sqlite3.Error):
        pass
    with _POOL_LOCK:
        remaining = [
            until - now for fingerprint, until in _COOLDOWN_UNTIL.items()
            if fingerprint in fingerprints and until > now
        ]
    return max(1.0, min(remaining)) if remaining else 1.0


def _cooldown_response(url: str, retry_after: float) -> requests.Response:
    response = requests.Response()
    response.status_code = 429
    response.reason = "All configured model keys are cooling down"
    response.url = url
    response.headers["Retry-After"] = str(max(1, math.ceil(retry_after)))
    response.headers["Content-Type"] = "application/json"
    response._content = json.dumps({
        "error": {
            "message": "All configured model keys are temporarily unavailable; retry after the cooldown.",
            "type": "rate_limit_error",
        }
    }).encode("utf-8")
    return response


def _budgeted_request_options(kwargs: dict, deadline: float | None) -> dict:
    if deadline is None:
        return kwargs
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise requests.Timeout("Model request budget exhausted")
    options = dict(kwargs)
    timeout = options.get("timeout")
    if isinstance(timeout, tuple):
        options["timeout"] = tuple(min(float(value), remaining) if value is not None else remaining for value in timeout)
    else:
        options["timeout"] = min(float(timeout), remaining) if timeout is not None else remaining
    return options


def post_model_request(url: str, *, headers: dict[str, str] | None = None,
                       max_key_attempts: int | None = None, deadline: float | None = None, **kwargs):
    """POST to a model endpoint, rotating through configured keys on quota/auth errors.

    The function intentionally returns a normal ``requests.Response`` (or raises
    the final transport exception), so existing callers keep their current
    ``raise_for_status`` and JSON/error handling behavior.
    """
    original_headers = dict(headers or {})
    if max_key_attempts is not None and (type(max_key_attempts) is not int or max_key_attempts < 1):
        raise ValueError("max_key_attempts must be a positive integer")
    _budgeted_request_options(kwargs, deadline)
    tokens = configured_model_tokens(original_headers)
    if not tokens:
        from user_credentials import current_capability
        if current_capability() is not None:
            raise ValueError('USER_PROVIDER_KEY_REQUIRED')
        return requests.post(url, headers=original_headers or None, **_budgeted_request_options(kwargs, deadline))

    ordered_tokens = _ordered_tokens(tokens)
    if not ordered_tokens:
        return _cooldown_response(url, _next_cooldown_seconds(tokens))

    last_response = None
    last_exception = None
    for token in ordered_tokens[:max_key_attempts]:
        # An expired budget must not cool an unattempted key or walk the pool.
        request_options = _budgeted_request_options(kwargs, deadline)
        request_headers = dict(original_headers)
        request_headers["Authorization"] = f"Bearer {token}"
        request_headers["csb-token"] = token
        try:
            response = requests.post(url, headers=request_headers, **request_options)
        except (requests.Timeout, requests.ConnectionError) as exc:
            last_exception = exc
            # Record the category only: exception text may contain URLs,
            # provider responses or credentials. Do not label transport loss
            # as a confirmed upstream rate-limit event.
            _LOGGER.warning("Model request transport failure (%s)", type(exc).__name__)
            _mark_cooldown(token, _configured_cooldown("MODEL_KEY_NETWORK_COOLDOWN_SECONDS", 5.0, minimum=0.1))
            continue
        if response.status_code in _ROTATE_STATUS_CODES and len(tokens) > 1:
            last_response = response
            _mark_cooldown(token, _cooldown_seconds(response))
            continue
        return response
    if last_response is not None:
        return last_response
    if last_exception is not None:
        raise last_exception
    raise requests.Timeout("No model key attempt available")
