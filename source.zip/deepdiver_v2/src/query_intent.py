"""Deterministic question-intent analysis for the Web task layer.

This is deliberately separate from processing-mode selection.  The user
chooses the PDF/retrieval route; this module only describes what the answer
must do within that route.
"""

from __future__ import annotations

import re


def _has(text: str, *patterns: str) -> bool:
    value = str(text or "").lower()
    for pattern in patterns:
        needle = pattern.lower()
        if re.fullmatch(r"[a-z0-9_ -]+", needle):
            if re.search(r"(?<![a-z0-9_])" + re.escape(needle) + r"(?![a-z0-9_])", value):
                return True
        elif needle in value:
            return True
    return False


def _is_general_chat(text: str, lowered: str) -> bool:
    """Detect non-academic requests that need no literature retrieval.

    Covers greetings, small talk, creative writing (poems/stories/songs),
    weather, jokes and simple identity questions. Deliberately conservative:
    only clear non-research patterns match, so academic questions are never
    diverted.
    """
    if not text:
        return False
    # Greetings / identity / courtesy (short messages)
    if re.fullmatch(
        r"(hi|hello|hey|你好|您好|哈喽|嗨|早上好|晚上好|下午好|晚安|谢谢|感谢|多谢|再见|拜拜|在吗|在么|"
        r"你是谁|你叫什么|你是什么|你会什么|你能做什么|who are you|thanks|thank you|goodbye|bye)[呀啊吗呢哦啦嘛哎耶~!?。.！？\s]*",
        lowered,
    ):
        return True
    # Broad life/creative keywords must not steal mixed requests or research
    # about those domains (weather prediction, joke generation, etc.).
    if re.search(r'论文|文献|科研|研究|算法|模型|实验|数据集|基准|评测|引用|原文|公式|推导|机制|原理|预测方法|气象预测|'
                 r'气象|气候|预测.{0,10}天气|天气.{0,8}(?:预测|算法|方法)|'
                 r'\b(?:arxiv|paper|research|algorithm|model|dataset|benchmark|transformer|forecasting|citation)\b', lowered):
        return False
    if re.fullmatch(r'(?:请|帮我|麻烦你|能否|可以)?\s*(?:写|起草|润色|修改).{0,30}'
                    r'(?:请假条|请假邮件|请假信|邀请函|邀请信|生日祝福|道歉信|感谢信)[。.!！?？\s]*', text):
        return True
    if re.fullmatch(r'(?:请)?(?:计算|算一下|算算)?\s*-?\d+(?:\.\d+)?\s*'
                    r'(?:加|减|乘以?|除以?|[+*/×÷−-])\s*-?\d+(?:\.\d+)?\s*'
                    r'(?:等于(?:多少|几)?|是多少|等于几|等于多少|[=＝]\s*[?？]?)?[。.!！?？\s]*', text):
        return True
    # Creative writing: poems, stories, songs, couplets
    if re.search(
        r"(写|作|来|给我).{0,20}(一首|一篇|一段|一句)?\s*(诗|诗歌|绝句|律诗|古诗|现代诗|词|歌词|曲子|故事|小说|散文|童话|段子|笑话)|"
        r"(绝句|律诗|古诗|现代诗|藏头诗|诗歌|歌词)|"
        r"\b(poem|haiku|sonnet|song lyrics|short story|fairy tale|joke)\b|讲个?笑话|讲个?故事",
        lowered,
    ):
        return True
    # Weather / time / other life small talk
    if re.search(r"天气|气温|下雨|weather|forecast|几点了|现在几点|what time", lowered):
        return True
    return False


def request_route(query: str, *, has_upload=False) -> dict:
    """Conservative zero-model routing; uncertain/contextual followups stay RAG."""
    intent = analyze_query_intent(query, has_upload=has_upload)
    direct = not has_upload and intent.get('is_general_chat') is True
    return {'schema_version': 'sciassistant.request-route/v1',
        'policy': 'clear-nonresearch-only-no-pdf-bypass/v1',
        'route': 'direct_answer' if direct else 'research',
        'reason_code': 'CLEAR_GENERAL_REQUEST' if direct else 'PDF_OR_RESEARCH_OR_UNCERTAIN',
        'classifier_model_calls': 0, 'query_intent': intent}


def analyze_query_intent(query: str, *, has_upload: bool = False) -> dict:
    """Return a conservative, UI-safe intent contract for one question."""
    text = " ".join(str(query or "").split()).strip()
    lowered = text.lower()
    # Non-academic request: answer directly via the base model, no retrieval.
    if not has_upload and _is_general_chat(text, lowered):
        return {
            "task_type": "general_chat",
            "task_label": "通用对话",
            "scope": "general_chat",
            "target": None,
            "evidence_requirements": [],
            "response_structure": ["direct_answer"],
            "requires_exact_values": False,
            "requires_citation": False,
            "is_general_chat": True,
        }
    section = bool(re.search(
        r"(section|章节|部分|小节|段落|subsection|中的.+主要讲|主要讲了什么|这一节)",
        lowered,
    ))
    comparison = _has(lowered, "compare", "comparison", "对比", "比较", "区别", "差异")
    experiment = _has(lowered, "experiment", "result", "benchmark", "table", "实验", "结果", "指标", "表格", "数据")
    formula = _has(lowered, "formula", "equation", "derive", "公式", "推导", "方程")
    citation = _has(lowered, "quote", "citation", "cite", "原文", "引用", "页码", "证据", "依据")
    critique = _has(lowered, "limitation", "weakness", "critique", "局限", "缺点", "批判", "问题")
    definition = _has(lowered, "what is", "define", "definition", "explain", "解释", "定义", "讲解", "原理", "是什么")

    if section:
        task_type = "section_summary"
        label = "指定章节总结"
    elif comparison:
        task_type = "comparison"
        label = "方法或论文对比"
    elif experiment:
        task_type = "experimental_evidence"
        label = "实验结果与数据解读"
    elif formula:
        task_type = "formula_explanation"
        label = "公式或推导解释"
    elif critique:
        task_type = "critical_analysis"
        label = "局限与批判性分析"
    elif definition or _has(lowered, "什么是", "何为", "概念"):
        task_type = "concept_explanation"
        label = "概念或方法解释"
    elif _has(lowered, "整体总结", "全文总结", "总体总结", "整体概括", "全文概括"):
        task_type = "general_summary"
        label = "文档整体总结"
    else:
        task_type = "focused_answer" if text else "general_summary"
        label = "聚焦问题回答" if text else "文档整体总结"

    scope = "uploaded_pdf" if has_upload else ("arxiv_or_literature" if _has(lowered, "arxiv", "论文", "文献") else "general_knowledge")
    target_match = re.search(r"(?:中|里的|中的|in|from)\s*[“\"']?(.{2,80}?)[”\"']?\s*(?=(?:主要|讲|讨论|describe|discuss))", text, re.I)
    target = target_match.group(1).strip(" ，,。.") if target_match else None
    evidence = ["relevant_text"]
    if section or comparison:
        evidence.append("section_context")
    if experiment or formula:
        evidence.extend(["page_reference", "layout_review"])
    if citation:
        evidence.append("verbatim_or_located_quote")
    structure = ["direct_answer", "supporting_evidence"]
    if comparison:
        structure.append("comparison_dimensions")
    if experiment:
        structure.append("data_and_scope_limits")
    if critique:
        structure.append("limitations")
    return {
        "task_type": task_type,
        "task_label": label,
        "scope": scope,
        "target": target,
        "evidence_requirements": list(dict.fromkeys(evidence)),
        "response_structure": structure,
        "requires_exact_values": bool(experiment or formula),
        "requires_citation": bool(citation or experiment or formula),
        "confidence": "high" if text else "low",
        "signals": {
            "section": section,
            "comparison": comparison,
            "experiment": experiment,
            "formula": formula,
            "citation": citation,
            "critique": critique,
        },
    }


def intent_instruction(intent: dict) -> str:
    """Render a compact instruction safe to include in an answer prompt."""
    if not isinstance(intent, dict):
        return ""
    return (
        "\n问题意图约束（必须服从）："
        f"任务类型={intent.get('task_label', '聚焦问题回答')}；"
        f"范围={intent.get('scope', 'general_knowledge')}；"
        f"目标={intent.get('target') or '用户问题本身'}；"
        f"回答结构={','.join(intent.get('response_structure') or ['direct_answer'])}。"
        "先直接回答目标，不要用整篇论文概览替代指定问题；"
        "需要精确数字、公式或引用时，只能使用可定位证据，无法确认就明确说明。"
    )
