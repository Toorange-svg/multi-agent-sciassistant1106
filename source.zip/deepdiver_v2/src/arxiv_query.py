"""Small, dependency-free arXiv query validator and conservative cleaner."""
from __future__ import annotations

import re


_OPERATORS = {"AND", "OR", "ANDNOT"}
_GENERIC = {
    "method", "methods", "analysis", "evaluation", "experiment", "experiments",
    "benchmark", "comparison", "performance", "architecture", "framework", "model",
    "models", "approach", "approaches", "research", "study", "studies",
}


def validate_arxiv_query(query: str) -> tuple[bool, str]:
    """Validate syntax and require a title/abstract entity condition."""
    value = " ".join(str(query or "").split()).strip()
    if not value:
        return False, "empty_query"
    if value.count('"') % 2 or value.count("'") % 2:
        return False, "unmatched_quote"
    depth = 0
    for char in value:
        if char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
            if depth < 0:
                return False, "unmatched_parenthesis"
    if depth:
        return False, "unmatched_parenthesis"
    for quoted in re.findall(r'"([^"\\]*(?:\\.[^"\\]*)*)"', value):
        # Ordinary conjunctions belong to titles, not the outer query grammar.
        # A nested fielded expression is still refused, as before.
        if re.search(r"\b(?:all|ti|abs)\s*:", quoted, re.I):
            return False, "boolean_expression_inside_quote"
        # Chinese full-width brackets/parens leaked into a quoted phrase make
        # the arXiv match useless (e.g. ti:"attention）"). Reject so repair runs.
        if re.search(r"[^\x00-\x7F]", quoted):
            return False, "non_ascii_in_quoted_phrase"
    outside_quotes = re.sub(r'"[^"\\]*(?:\\.[^"\\]*)*"', ' ', value)
    for operator in re.findall(r"(?<![A-Za-z])(?:andnot|and|or)(?![A-Za-z])", outside_quotes, re.I):
        if operator != operator.upper() or operator not in _OPERATORS:
            return False, "lowercase_boolean_operator"
    if not re.search(r"\b(?:ti|abs)\s*:\s*\"?[A-Za-z][A-Za-z0-9+./-]*(?:[ -][A-Za-z][A-Za-z0-9+./-]*)*\"?", value, re.I):
        return False, "missing_title_abstract_entity"
    return True, "ok"


def repair_arxiv_query(query: str) -> str | None:
    """Build a legal title/abstract query from an invalid candidate."""
    value = " ".join(str(query or "").split())
    candidates = []
    # Prefer explicit fields and quoted phrases, then inspect plain tokens.
    for _field, quoted, bare in re.findall(r"\b(ti|abs)\s*:\s*(?:\"([^\"]+)\"|([^\s()]+))", value, re.I):
        candidates.append(quoted or bare)
    for phrase in re.findall(r'"([^"\n]+)"', value):
        if not re.search(r"\b(?:AND|OR|ANDNOT|all\s*:|ti\s*:|abs\s*:)", phrase, re.I):
            candidates.append(phrase)
    if not candidates:
        candidates = [" ".join(re.findall(r"[A-Za-z][A-Za-z0-9+./-]*", value))]
    tokens = []
    for candidate in candidates:
        candidate_tokens = re.findall(r"[A-Za-z][A-Za-z0-9+./-]*", candidate)
        useful = [token for token in candidate_tokens if token.lower() not in _GENERIC and token.lower() not in {"and", "or", "andnot", "all", "ti", "abs"}]
        # Keep generic words when they are part of a phrase that also has a
        # non-generic entity (``world model``), but reject relation-only text.
        selected = candidate_tokens if useful else []
        for token in selected:
            if token.lower() not in {"and", "or", "andnot", "all", "ti", "abs"}:
                if token.lower() not in {item.lower() for item in tokens}:
                    tokens.append(token)
    if not tokens:
        return None
    phrase = " ".join(tokens[:6])
    repaired = f'(ti:"{phrase}" OR abs:"{phrase}")'
    return repaired if validate_arxiv_query(repaired)[0] else None


def simplify_arxiv_query(query: str) -> str | None:
    """Reduce a repaired query to its first concrete entity for last retry."""
    value = str(query or "")
    match = re.search(r"\b(?:ti|abs)\s*:\s*\"?([A-Za-z][A-Za-z0-9+./-]*)", value, re.I)
    if not match:
        match = re.search(r"\b([A-Za-z][A-Za-z0-9+./-]{2,})\b", value)
    if not match or match.group(1).lower() in _GENERIC:
        return None
    candidate = f'(ti:"{match.group(1)}" OR abs:"{match.group(1)}")'
    return candidate if validate_arxiv_query(candidate)[0] else None
