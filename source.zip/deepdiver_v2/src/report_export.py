"""Shared Markdown and PDF report export helpers for CLI and Web paths."""

from __future__ import annotations

import html
import re
from pathlib import Path
from typing import Iterable


def _safe_basename(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", str(value or "report"))
    return value.strip("._") or "report"


def _inline_markup(value: str) -> str:
    text = html.escape(str(value or ""), quote=False)
    text = re.sub(r"\*\*([^*]+)\*\*", r"<b>\1</b>", text)
    text = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"<i>\1</i>", text)
    text = re.sub(r"`([^`]+)`", r'<font name="Courier">\1</font>', text)
    return text


def _table_cells(line: str) -> list[str]:
    value = line.strip()
    if value.startswith("|"):
        value = value[1:]
    if value.endswith("|"):
        value = value[:-1]
    return [cell.strip() for cell in value.split("|")]


def _is_table_separator(line: str) -> bool:
    cells = _table_cells(line)
    return bool(cells) and all(re.fullmatch(r":?-{3,}:?", cell) for cell in cells)


def _build_pdf_story(markdown_content: str, reportlab: dict) -> list:
    Paragraph = reportlab["Paragraph"]
    ParagraphStyle = reportlab["ParagraphStyle"]
    Spacer = reportlab["Spacer"]
    Table = reportlab["Table"]
    TableStyle = reportlab["TableStyle"]
    Preformatted = reportlab["Preformatted"]
    colors = reportlab["colors"]
    cm = reportlab["cm"]
    base_font = reportlab["base_font"]
    bold_font = reportlab["bold_font"]

    styles = reportlab["styles"]
    normal = ParagraphStyle(
        "SciAssistantBody", parent=styles["BodyText"], fontName=base_font,
        fontSize=10.5, leading=16, alignment=reportlab["TA_JUSTIFY"], spaceAfter=7,
    )
    heading_1 = ParagraphStyle(
        "SciAssistantHeading1", parent=styles["Heading1"], fontName=bold_font,
        fontSize=18, leading=23, spaceBefore=10, spaceAfter=10,
    )
    heading_2 = ParagraphStyle(
        "SciAssistantHeading2", parent=styles["Heading2"], fontName=bold_font,
        fontSize=15, leading=20, spaceBefore=8, spaceAfter=8,
    )
    heading_3 = ParagraphStyle(
        "SciAssistantHeading3", parent=styles["Heading3"], fontName=bold_font,
        fontSize=12.5, leading=17, spaceBefore=6, spaceAfter=6,
    )
    table_cell = ParagraphStyle(
        "SciAssistantTableCell", parent=normal, fontName=base_font,
        fontSize=8.5, leading=11, alignment=reportlab["TA_LEFT"], spaceAfter=0,
    )
    table_header = ParagraphStyle(
        "SciAssistantTableHeader", parent=table_cell, fontName=bold_font,
    )
    code_style = ParagraphStyle(
        "SciAssistantCode", parent=styles["Code"], fontName="Courier",
        fontSize=8, leading=10, leftIndent=8, rightIndent=8,
    )

    lines = str(markdown_content or "").splitlines()
    story = []
    index = 0
    while index < len(lines):
        raw = lines[index]
        line = raw.strip()
        if not line:
            story.append(Spacer(1, 0.16 * cm))
            index += 1
            continue

        if line.startswith("```"):
            code_lines = []
            index += 1
            while index < len(lines) and not lines[index].strip().startswith("```"):
                code_lines.append(lines[index])
                index += 1
            story.append(Preformatted("\n".join(code_lines), code_style))
            index += 1 if index < len(lines) else 0
            continue

        if (
            line.startswith("|") and index + 1 < len(lines)
            and lines[index + 1].strip().startswith("|")
            and _is_table_separator(lines[index + 1])
        ):
            rows = [_table_cells(line)]
            index += 2
            while index < len(lines) and lines[index].strip().startswith("|"):
                rows.append(_table_cells(lines[index]))
                index += 1
            width = max(len(row) for row in rows)
            normalized_rows = [row + [""] * (width - len(row)) for row in rows]
            table_data = [
                [Paragraph(_inline_markup(cell), table_header if row_index == 0 else table_cell)
                 for cell in row]
                for row_index, row in enumerate(normalized_rows)
            ]
            table = Table(table_data, repeatRows=1, hAlign="LEFT")
            table.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e8eef7")),
                ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#9aa8b8")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 5),
                ("RIGHTPADDING", (0, 0), (-1, -1), 5),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]))
            story.append(table)
            story.append(Spacer(1, 0.2 * cm))
            continue

        if line.startswith("### "):
            story.append(Paragraph(_inline_markup(line[4:]), heading_3))
        elif line.startswith("## "):
            story.append(Paragraph(_inline_markup(line[3:]), heading_2))
        elif line.startswith("# "):
            story.append(Paragraph(_inline_markup(line[2:]), heading_1))
        elif line in {"---", "***", "___"}:
            story.append(reportlab["HRFlowable"](
                width="100%", thickness=0.6, color=colors.HexColor("#9aa8b8"),
                spaceBefore=5, spaceAfter=8,
            ))
        elif line.startswith(("- ", "* ")):
            story.append(Paragraph("&#8226; " + _inline_markup(line[2:]), normal))
        elif line.startswith("> "):
            story.append(Paragraph("&#8220;" + _inline_markup(line[2:]) + "&#8221;", normal))
        else:
            story.append(Paragraph(_inline_markup(line), normal))
        index += 1

    return story or [Paragraph("No content", normal)]


def generate_pdf_report(markdown_content: str, output_path: Path) -> Path:
    """Render a Markdown report to PDF and return the created path."""
    try:
        from reportlab.lib import colors
        from reportlab.lib.enums import TA_JUSTIFY, TA_LEFT
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
        from reportlab.lib.units import cm
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.cidfonts import UnicodeCIDFont
        from reportlab.platypus import (
            HRFlowable, Paragraph, Preformatted, SimpleDocTemplate, Spacer, Table, TableStyle,
        )
    except ImportError as exc:
        raise RuntimeError("PDF export requires ReportLab. Install reportlab first.") from exc

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    base_font = "Helvetica"
    bold_font = "Helvetica-Bold"
    try:
        pdfmetrics.registerFont(UnicodeCIDFont("STSong-Light"))
        base_font = bold_font = "STSong-Light"
    except Exception:
        # A PDF can still be created for English-only reports when CID fonts are
        # unavailable. The caller receives the path and can inspect the result.
        pass

    doc = SimpleDocTemplate(
        str(output_path), pagesize=A4,
        rightMargin=2 * cm, leftMargin=2 * cm,
        topMargin=2 * cm, bottomMargin=2 * cm,
        title="SciAssistant Report",
    )
    story = _build_pdf_story(markdown_content, {
        "Paragraph": Paragraph, "ParagraphStyle": ParagraphStyle,
        "Spacer": Spacer, "Table": Table, "TableStyle": TableStyle,
        "Preformatted": Preformatted, "HRFlowable": HRFlowable,
        "colors": colors, "cm": cm, "styles": getSampleStyleSheet(),
        "base_font": base_font, "bold_font": bold_font,
        "TA_JUSTIFY": TA_JUSTIFY, "TA_LEFT": TA_LEFT,
    })
    doc.build(story)
    if not output_path.is_file() or output_path.stat().st_size == 0:
        raise RuntimeError(f"PDF export did not create a usable file: {output_path}")
    return output_path


def export_report_files(
    markdown_content: str,
    output_dir: Path,
    basename: str = "report",
    formats: str | Iterable[str] = "both",
) -> dict[str, str]:
    """Export a report as Markdown, PDF, or both formats."""
    if isinstance(formats, str):
        requested = {item.strip().lower() for item in formats.split(",") if item.strip()}
    else:
        requested = {str(item).strip().lower() for item in formats}
    if requested == {"none"} or not requested:
        return {}
    if "both" in requested:
        requested.update({"md", "pdf"})
        requested.discard("both")
    unknown = requested - {"md", "pdf"}
    if unknown:
        raise ValueError(f"Unsupported report export format(s): {sorted(unknown)}")

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    safe_name = _safe_basename(basename)
    exported: dict[str, str] = {}
    if "md" in requested:
        markdown_path = output_dir / f"{safe_name}.md"
        markdown_path.write_text(str(markdown_content or ""), encoding="utf-8")
        exported["markdown"] = str(markdown_path)
    if "pdf" in requested:
        pdf_path = generate_pdf_report(markdown_content, output_dir / f"{safe_name}.pdf")
        exported["pdf"] = str(pdf_path)
    return exported
