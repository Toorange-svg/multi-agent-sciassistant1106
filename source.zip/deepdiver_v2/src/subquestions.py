"""Decompose a compound research question into independently answerable parts.

A single question often carries several requests: enumerated sub-questions,
conditional branches ("if A then B; if C then D"), or a comparison. Treating
the whole string as one query mixes their evidence together and hides which
part is unanswered.

This module is rule-based and offline. Decomposition decides *where to cut*,
which is a property of the question's grammar; keyword generation for each
resulting part stays with the existing model planner, so no extra model call
is introduced here.

Nothing in this module selects a research field, a paper or a category.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List

# Sentence boundaries that separate independent requests. A comma is not one:
# it usually continues a single request.
_SENTENCE_SPLIT = re.compile(r"[?？!！;；。\n]+|\u3002")

# Enumerations the user may have written: "1. ", "2、", "(3)", "3)".
_NUMBERED_SPLIT = re.compile(r"(?:^|(?<=\s))[(（]?\d{1,2}[)）.、:：]\s*")

# "如果 X，则 Y" / "若 X，就 Y" / "if X, then Y". The antecedent is kept so the
# branch can be reported and cited separately from the main question.
_CONDITIONAL = re.compile(
    r"^\s*(?:如果|若|假如|倘若|要是|if)\s*(?P<condition>.+?)"
    r"\s*(?:[,，]|\bthen\b)\s*(?:那么|则|就|便|则需|then)?\s*(?P<consequent>.+)$",
    re.I | re.S,
)

# A branch that only points back at an earlier alternative ("如果是前者").
_REFERENTIAL = re.compile(
    r"(?:如果|若|假如)?\s*(?:是)?\s*(?:前者|后者|这样|那样|上述|该情况|这一种|其中一种|前者呢|后者呢)",
)

# Fragments too short or too generic to retrieve on their own.
_MIN_LENGTH = 4
_FRAGMENT_ONLY = {
    "如果是前者", "如果是后者", "前者", "后者", "为什么", "怎么", "如何", "那么",
    "还有呢", "然后呢", "如果是这样", "if so", "why", "how",
}


@dataclass
class SubQuestion:
    """One independently retrievable part of a question."""

    index: int
    text: str
    kind: str = "main"          # main | numbered | conditional
    condition: str = ""         # antecedent, for conditional branches
    referential: bool = False   # points back at an earlier alternative
    note: str = ""

    def to_dict(self) -> dict:
        return {
            "index": self.index,
            "text": self.text,
            "kind": self.kind,
            "condition": self.condition,
            "referential": self.referential,
            "note": self.note,
        }


def _clean(value: str) -> str:
    return " ".join(str(value or "").split()).strip(" \t,，、:：;；")


def _is_usable(value: str) -> bool:
    text = _clean(value)
    if len(text) < _MIN_LENGTH:
        return False
    return text.lower() not in _FRAGMENT_ONLY


def _split_numbered(text: str) -> List[str]:
    """Split an enumerated run while keeping each numbered item whole."""
    parts = [part for part in _NUMBERED_SPLIT.split(text) if _clean(part)]
    return parts if len(parts) > 1 else [text]


def decompose(query: str) -> List[SubQuestion]:
    """Split a question into independently retrievable parts.

    Returns at least one entry: a question that needs no splitting yields a
    single ``main`` sub-question carrying the original text, so callers can
    treat the decomposed list uniformly without a special case.
    """
    original = _clean(query)
    if not original:
        return []

    # 1. Sentence level: question marks, semicolons and full stops each end a
    #    request, while commas do not.
    sentences = [part for part in _SENTENCE_SPLIT.split(original) if _clean(part)]

    # 2. Enumeration level: "1. ... 2. ..." inside one sentence.
    chunks: List[str] = []
    for sentence in sentences:
        chunks.extend(_split_numbered(sentence))

    items: List[SubQuestion] = []
    for chunk in chunks:
        text = _clean(chunk)
        if not _is_usable(text):
            continue
        conditional = _CONDITIONAL.match(text)
        if conditional:
            condition = _clean(conditional.group("condition"))
            consequent = _clean(conditional.group("consequent"))
            if _is_usable(consequent):
                # A branch whose antecedent only points back at an earlier
                # alternative ("如果是前者") is referential as well as
                # conditional: it inherits its subject from another part, so a
                # caller must not retrieve for it as if it were self-contained.
                items.append(SubQuestion(
                    index=0,
                    text=consequent,
                    kind="conditional",
                    condition=condition,
                    referential=bool(_REFERENTIAL.search(condition)),
                    note=f"仅在该条件成立时适用：{condition}",
                ))
                continue
        numbered = bool(re.match(r"^\d{1,2}[).、:：]?\s", text))
        items.append(SubQuestion(
            index=0,
            text=text,
            kind="numbered" if numbered else "main",
            referential=bool(_REFERENTIAL.search(text)),
        ))

    if not items:
        # Everything looked like a fragment; keep the original so the caller
        # still has something to retrieve with.
        items = [SubQuestion(index=0, text=original)]

    for position, item in enumerate(items, 1):
        item.index = position
    return items


def merge_grouped_results(
    subquestions: List[SubQuestion],
    *,
    per_subquestion: List[dict],
    minimum: int = 1,
) -> dict:
    """Group retrieved evidence per sub-question and flag unanswered parts.

    A part with too little evidence is reported as
    ``insufficient_evidence_for_subquestion`` while the remaining parts keep
    their evidence, so one unanswered branch never discards the others.
    """
    groups = []
    unanswered = []
    for item, result in zip(subquestions, per_subquestion):
        papers = list((result or {}).get("papers") or [])
        sufficient = len(papers) >= max(1, int(minimum))
        group = {
            "index": item.index,
            "text": item.text,
            "kind": item.kind,
            "condition": item.condition,
            "paper_count": len(papers),
            "papers": papers,
            "status": "sufficient" if sufficient else "insufficient_evidence_for_subquestion",
        }
        if not sufficient:
            group["note"] = "该子问题没有获得足够证据，其他子问题不受影响。"
            unanswered.append(item.index)
        groups.append(group)
    return {
        "groups": groups,
        "unanswered_subquestions": unanswered,
        "status": (
            "insufficient_evidence_for_subquestion" if unanswered
            else "sufficient"
        ),
    }
