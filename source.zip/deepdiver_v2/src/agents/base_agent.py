﻿# Copyright (c) 2025 Huawei Technologies Co., Ltd. All rights reserved.
# Copyright (c) 2026 South China Sea Institute of Oceanology, Chinese Academy of Sciences (SCSIO, CAS). All rights reserved.
import json
import re

# ==== Global JSON Interceptor ====
_old_loads = json.loads
def _safe_loads(s, *args, **kwargs):
    try:
        return _old_loads(s, *args, **kwargs)
    except Exception as e:
        logger = logging.getLogger(__name__)
        logger.debug("JSON parse failed for raw LLM output: %r", s)
        raise e
json.loads = _safe_loads
# =================================
import logging
import time
import os
import sys
import uuid
import requests
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Dict, Any, List, Optional, Union
from dataclasses import dataclass, field
from pathlib import Path
import litellm
from ..model_key_pool import post_model_request

logger = logging.getLogger(__name__)

# Import MCP client instead of direct tools
try:
    from ..tools import mcp_client as _mcp_client_module  # noqa: F401
    MCP_CLIENT_AVAILABLE = True
except ImportError:
    MCP_CLIENT_AVAILABLE = False


@dataclass
class AgentConfig:
    """Configuration for agents - session management handled entirely by MCP server"""
    agent_name: str = "base_agent"
    planner_mode: str = "auto"
    model: Optional[str] = None
    max_iterations: int = 10
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    # Paths used by writer and other agents
    trajectory_storage_path: Optional[str] = None
    report_output_path: Optional[str] = None
    document_analysis_path: Optional[str] = None
    # Optional named tool-set override ("paper_evidence" / "strict_pdf_evidence").
    allowed_tool_set: Optional[str] = None


@dataclass
class AgentResponse:
    """Standardized response format for all agents"""
    success: bool
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    iterations: int = 0
    reasoning_trace: List[Dict[str, Any]] = field(default_factory=list)
    agent_name: str = ""
    execution_time: float = 0.0


@dataclass
class TaskInput:
    """Standardized task input format for all agents"""
    task_content: str                                    # The specific task content
    task_steps_for_reference: Optional[str] = None       # Reference steps for execution
    deliverable_contents: Optional[str] = None           # Format of final deliverable
    current_task_status: Optional[str] = None            # Description of current task status
    task_executor: str = "info_seeker"                  # Name of task executor (info_seeker, writer)
    workspace_id: Optional[str] = None                   # Workspace ID for stored files and memory
    acceptance_checking_criteria: Optional[str] = None   # Criteria for determining task completion and quality
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert TaskInput to dictionary format"""
        return {
            "task_content": self.task_content,
            "task_steps_for_reference": self.task_steps_for_reference,
            "deliverable_contents": self.deliverable_contents,
            "current_task_status": self.current_task_status,
            "task_executor": self.task_executor,
            "workspace_id": self.workspace_id,
            "acceptance_checking_criteria": self.acceptance_checking_criteria
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TaskInput':
        """Create TaskInput from dictionary"""
        return cls(
            task_content=data.get("task_content", ""),
            task_steps_for_reference=data.get("task_steps_for_reference"),
            deliverable_contents=data.get("deliverable_contents"),
            current_task_status=data.get("current_task_status"),
            task_executor=data.get("task_executor", "info_seeker"),
            workspace_id=data.get("workspace_id"),
            acceptance_checking_criteria=data.get("acceptance_checking_criteria")
        )
    
    def format_for_prompt(self) -> str:
        """Format the task input for use in prompts"""
        prompt = f"Task Content:\n{self.task_content}\n\n"
        
        if self.task_steps_for_reference:
            prompt += f"Task Steps for Reference:\n{self.task_steps_for_reference}\n\n"
        
        if self.deliverable_contents:
            prompt += f"Deliverable Contents:\n{self.deliverable_contents}\n\n"
        
        if self.current_task_status:
            prompt += f"Current Task Status:\n{self.current_task_status}\n\n"
        
        if self.acceptance_checking_criteria:
            prompt += f"Acceptance Checking Criteria:\n{self.acceptance_checking_criteria}\n\n"
        
        prompt += f"Task Executor: {self.task_executor}\n"
        
        if self.workspace_id:
            prompt += f"Workspace ID: {self.workspace_id}\n"
        
        return prompt


class SectionWriterTaskInput(TaskInput):
    """
    Specialized TaskInput for section writing tasks

    Only stores the essential parameters. The section_writer agent
    will handle prompt assembly internally.
    """

    def __init__(
        self,
        task_content: str,
        user_query: str,
        write_file_path: str,
        overall_outline: str,
        current_chapter_outline: str,
        key_files: List[Dict[str, Any]],
        written_chapters: str = "",
        workspace_id: Optional[str] = None
    ):
        # Store the section writer specific parameters
        self.write_file_path = write_file_path
        self.user_query = user_query
        self.current_chapter_outline = current_chapter_outline
        self.key_files = key_files
        self.written_chapters = written_chapters
        self.overall_outline = overall_outline

        # Initialize parent TaskInput with minimal required fields
        super().__init__(
            task_content=task_content,
            task_executor="section_writer",
            workspace_id=workspace_id,
        )


class WriterAgentTaskInput(TaskInput):
    """
    Specialized TaskInput for section writing tasks

    Only stores the 4 essential parameters. The section_writer agent
    will handle prompt assembly internally.
    """

    def __init__(
        self,
        task_content: str,
        user_query: str,
        key_files: List[Dict[str, Any]],
        workspace_id: Optional[str] = None
    ):
        # Store the section writer specific parameters
        self.user_query = user_query
        self.key_files = key_files

        # Initialize parent TaskInput with minimal required fields
        super().__init__(
            task_content=task_content,
            task_executor="writer_agent",
            workspace_id=workspace_id,
        )

    def format_for_prompt(self) -> str:
        prompt = f"Task Content:\n{self.task_content}\n\n"
        prompt += f"Original User Query And Collected Materials:\n{self.user_query}\n\n"
        if self.key_files:
            prompt += f"Key Files Or Materials:\n{json.dumps(self.key_files, ensure_ascii=False, indent=2)}\n\n"
        else:
            prompt += "Key Files Or Materials: None\n\n"
        if self.workspace_id:
            prompt += f"Workspace ID: {self.workspace_id}\n"
        return prompt


class BaseAgent(ABC):
    """
    Base class for all agents with MCP server-managed sessions.
    
    Session management is now entirely handled by the MCP server:
    - Server assigns session IDs on connection
    - Server creates workspace folders with UUID names
    - All tool operations are performed in server-managed workspaces
    """
    
    def __init__(self, config: AgentConfig, shared_mcp_client=None):
        self.execution_stats = None
        self.reasoning_trace = None
        self.config = config
        self.logger = logging.getLogger(f"{__name__}.{config.agent_name}")
        
        # Session info is populated by the MCP server
        self.session_info = None
        
        # Tool management
        self.mcp_tools = None
        self.available_tools = {}

        self.reset_trace()
        
        # Initialize MCP tools (server will handle session creation or use shared client)
        self._initialize(shared_mcp_client)
    
    def _initialize(self, shared_mcp_client=None):
        """Initialize agent with MCP server connection or shared client"""
        try:
            self.logger.info(f"Initializing agent {self.config.agent_name}")
            
            if shared_mcp_client:
                # Use shared MCP client with agent-specific tool filtering
                agent_type = self._get_agent_type()
                self.mcp_tools = self._create_filtered_mcp_tools(shared_mcp_client, agent_type)
                self.logger.info(f"Agent {self.config.agent_name} using shared MCP client with {agent_type} tools")
            else:
                # Create MCP tools with agent-specific filtering (no more unfiltered access)
                self.mcp_tools = self._create_filtered_mcp_tools_standalone()
            
            # Discover available tools
            self.available_tools = self._discover_mcp_tools()
            
            # Build tool schemas for function calling
            self.tool_schemas = self._build_tool_schemas()
            
            self.logger.info(f"Agent {self.config.agent_name} initialized successfully")
            self.logger.info(f"Available tools: {list(self.available_tools.keys())}")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize agent {self.config.agent_name}: {e}")
            raise

    def _discover_mcp_tools(self) -> Dict[str, Any]:
        """Discover available tools from MCP server or fallback tools"""
        available_tools = {}
        
        # Try to get tools from MCP client first
        if hasattr(self.mcp_tools, 'get_available_tools'):
            try:
                mcp_tools_dict = self.mcp_tools.get_available_tools()
                for tool_name, tool_info in mcp_tools_dict.items():
                    # For proper MCP architecture, store tool info for direct client calls
                    # instead of creating wrapper lambda functions
                    available_tools[tool_name] = tool_info
                
                if available_tools:
                    self.logger.info(f"Discovered {len(available_tools)} tools from MCP server")
                    return available_tools
            except Exception as e:
                self.logger.warning(f"Failed to discover MCP tools: {e}")
        
        # Fallback: if MCP client not available, use direct method access
        # This should rarely be needed with proper MCP setup
        if hasattr(self.mcp_tools, '__dict__'):
            for attr_name in dir(self.mcp_tools):
                if not attr_name.startswith('_') and callable(getattr(self.mcp_tools, attr_name)):
                    available_tools[attr_name] = getattr(self.mcp_tools, attr_name)
        
        return available_tools
    
    def _get_agent_type(self) -> str:
        """Get agent type for tool filtering"""
        agent_name = self.config.agent_name.lower()
        if "planner" in agent_name:
            return "planner"
        elif "information" in agent_name or "seeker" in agent_name:
            return "information_seeker"
        elif "writer" in agent_name:
            return "writer"
        else:
            # Default to planner tools for unknown agent types
            return "planner"
    
    def _create_filtered_mcp_tools(self, shared_client, agent_type: str):
        """Create filtered MCP tools adapter using shared client"""
        try:
            from src.tools.mcp_client import create_filtered_mcp_tools_adapter
            return create_filtered_mcp_tools_adapter(
                shared_client,
                agent_type,
                tool_override=getattr(self.config, 'allowed_tool_set', None),
            )
        except ImportError:
            # Fallback if FilteredMCPToolsAdapter not available
            self.logger.warning("FilteredMCPToolsAdapter not available, using regular adapter")
            from src.tools.mcp_client import MCPToolsAdapter
            adapter = MCPToolsAdapter.__new__(MCPToolsAdapter)
            adapter.client = shared_client
            return adapter
    
    def _create_filtered_mcp_tools_standalone(self):
        """Create filtered MCP tools adapter with its own client connection"""
        try:
            # Get agent type for filtering
            agent_type = self._get_agent_type()
            
            # Create a new MCP client
            client = self._create_new_mcp_client()
            
            # Apply filtering based on agent type
            from src.tools.mcp_client import create_filtered_mcp_tools_adapter
            filtered_adapter = create_filtered_mcp_tools_adapter(
                client,
                agent_type,
                tool_override=getattr(self.config, 'allowed_tool_set', None),
            )
            
            self.logger.info(f"Agent {self.config.agent_name} created filtered MCP adapter with {agent_type} tools")
            return filtered_adapter
            
        except Exception as e:
            self.logger.error(f"Failed to create filtered MCP tools: {e}")
            raise RuntimeError(f"Failed to create filtered MCP client for {self.config.agent_name}: {e}")
    
    def _create_new_mcp_client(self):
        """Create a new MCP client connection"""
        try:
            # Get MCP configuration
            from config.config import get_mcp_config
            mcp_config = get_mcp_config()
            
            # Create MCP client
            from src.tools.mcp_client import MCPClient
            
            if mcp_config.get("server_url") and not mcp_config.get("use_stdio", True):
                # HTTP-based MCP server
                client = MCPClient(server_url=mcp_config["server_url"])
                self.logger.info(
                    f"Agent {self.config.agent_name} connected to HTTP MCP server: {mcp_config['server_url']}")
            else:
                # Default to the expected HTTP MCP server on port 6274
                client = MCPClient(server_url="http://localhost:6274/mcp")
                self.logger.info(
                    f"Agent {self.config.agent_name} connected to default HTTP MCP server: http://localhost:6274/mcp")
                
            return client
                
        except Exception as e:
            self.logger.error(f"Failed to create MCP client: {e}")
            raise RuntimeError(f"MCP client creation failed for {self.config.agent_name}: {e}")
        
    # NOTE: _create_mcp_tools() method removed to prevent unfiltered tool access.
    # All agents now use _create_filtered_mcp_tools_standalone() or _create_filtered_mcp_tools() 
    # to ensure proper tool isolation and security.
    
    def get_session_info(self) -> Optional[Dict[str, Any]]:
        """Get information about the current server-managed session"""
        try:
            # First check environment variables (set by cli/a.py)
            env_session_id = os.environ.get('AGENT_SESSION_ID')
            env_workspace_path = os.environ.get('AGENT_WORKSPACE_PATH')
            
            if env_session_id and env_workspace_path:
                return {
                    "session_id": env_session_id,
                    "workspace_path": env_workspace_path,
                    "server_managed": True,
                    "agent_name": self.config.agent_name,
                    "source": "environment"
                }
            
            # Then try the adapter's get_session_info method if available
            if hasattr(self.mcp_tools, 'get_session_info'):
                session_info = self.mcp_tools.get_session_info()
                if session_info:
                    # Add agent-specific information
                    session_info.update({
                        "server_managed": True,
                        "agent_name": self.config.agent_name
                    })
                    return session_info
            
            # Fallback: Check if we have an MCP tools adapter with a client
            if hasattr(self.mcp_tools, 'client'):
                client = self.mcp_tools.client
                
                # Check if client has session ID and connection status
                if hasattr(client, '_session_id') and hasattr(client, 'is_connected'):
                    return {
                        "session_id": client._session_id,
                        "server_managed": True,
                        "agent_name": self.config.agent_name,
                        "connected": client.is_connected()
                    }
            
            # Fallback: check if mcp_tools has session info directly
            if hasattr(self.mcp_tools, '_session_id'):
                return {
                    "session_id": self.mcp_tools._session_id,
                    "server_managed": True,
                    "agent_name": self.config.agent_name,
                    "connected": getattr(self.mcp_tools, 'is_connected', lambda: True)()
                }
            
            # If no session info available, return basic info
            return {
                "session_id": None,
                "server_managed": True,
                "agent_name": self.config.agent_name,
                "connected": hasattr(self.mcp_tools, 'client') and getattr(self.mcp_tools.client, 'is_connected',
                                                                           lambda: False)()
            }
            
        except Exception as e:
            self.logger.warning(f"Failed to get session info: {e}")
            return {
                "session_id": None,
                "server_managed": True,
                "agent_name": self.config.agent_name,
                "connected": False,
                "error": str(e)
            }
    
    def _build_tool_schemas(self) -> List[Dict[str, Any]]:
        """Build tool schemas for function calling"""
        schemas = []
        
        # Get agent-specific tool schemas
        agent_schemas = self._build_agent_specific_tool_schemas()
        schemas.extend(agent_schemas)
        
        return [self._normalize_openai_tool_schema(schema) for schema in schemas]
    
    @staticmethod
    def _normalize_openai_tool_schema(schema: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize MCP-style tool schemas to OpenAI-compatible function schemas."""
        if not isinstance(schema, dict):
            return schema

        normalized = dict(schema)
        function = dict(normalized.get("function") or {})
        if not function:
            return normalized

        if "parameters" not in function and "inputSchema" in function:
            function["parameters"] = function.pop("inputSchema")
        elif "inputSchema" in function:
            function.pop("inputSchema", None)

        parameters = function.get("parameters")
        if not isinstance(parameters, dict):
            function["parameters"] = {"type": "object", "properties": {}, "required": []}
        else:
            function["parameters"].setdefault("type", "object")
            function["parameters"].setdefault("properties", {})
            function["parameters"].setdefault("required", [])

        normalized["function"] = function
        return normalized
    
    def _build_agent_specific_tool_schemas(self) -> List[Dict[str, Any]]:
        """
        Build agent-specific tool schemas using proper MCP architecture.
        Schemas come from MCP server via client, not direct imports.
        """
        schemas = []
        
        # Proper MCP way: Get schemas from MCP client (which got them from server)
        try:
            if hasattr(self.mcp_tools, 'get_tool_schemas'):
                # Use the MCP client to get schemas (proper MCP architecture)
                schemas = self.mcp_tools.get_tool_schemas()
                self.logger.info(f"Retrieved {len(schemas)} tool schemas from MCP server")
            else:
                # Fallback for adapters that don't have the new method yet
                self.logger.warning("MCP adapter doesn't support get_tool_schemas, using fallback")
                schemas = self._build_fallback_schemas()
        except Exception as e:
            self.logger.warning(f"Failed to get schemas from MCP client: {e}, using fallback")
            schemas = self._build_fallback_schemas()
        
        return schemas
    
    def _build_fallback_schemas(self) -> List[Dict[str, Any]]:
        """Fallback schema building if MCP client method fails"""
        schemas = []
        
        # Try to get tool info from MCP client
        if hasattr(self.mcp_tools, 'get_available_tools'):
            try:
                available_tools = self.mcp_tools.get_available_tools()
                for tool_name, tool_info in available_tools.items():
                    schema = {
                        "type": "function",
                        "function": {
                            "name": tool_name,
                            "description": getattr(tool_info, 'description', f"Tool: {tool_name}"),
                            "parameters": getattr(tool_info, 'input_schema', {"type": "object", "properties": {}, "required": []})
                        }
                    }
                    schemas.append(schema)
                self.logger.info(f"Built {len(schemas)} schemas using fallback method")
            except Exception as e:
                self.logger.warning(f"Fallback schema building failed: {e}")
        
        return schemas
    
    def execute_tool_call(self, tool_call) -> Dict[str, Any]:
        """Execute a tool call and return results using proper MCP architecture"""
        tool_name = tool_call["name"]
        
        try:
            # Parse arguments
            arguments = tool_call["arguments"]
            # The MCP server runs out of process, so ContextVar-based request
            # configuration does not cross the HTTP boundary on its own.
            # Inject the selected PDF strategy for every arXiv PDF read.
            if tool_name == "arxiv_read_paper":
                from config.config import get_config
                arguments = dict(arguments or {})
                arguments.setdefault("pdf_parse_mode", get_config().pdf_parse_mode)
                tool_call["arguments"] = arguments
            
            # Check if tool is available
            if tool_name not in self.available_tools:
                return {
                    "success": False,
                    "error": f"Tool '{tool_name}' not available for this agent"
                }
            
            # Route tool execution based on tool type
            # Built-in tools (like assign_task_to_*) are callable methods, not MCP server tools
            if callable(self.available_tools[tool_name]):
                # Built-in tool: execute locally
                tool_function = self.available_tools[tool_name]
                result = tool_function(**arguments)
                
                # Convert result to standard format
                if hasattr(result, 'to_dict'):
                    return result.to_dict()
                elif isinstance(result, dict):
                    return result
                else:
                    return {
                        "success": True,
                        "data": result,
                        "error": None,
                        "metadata": {}
                    }
                    
            elif hasattr(self.mcp_tools, 'client') and hasattr(self.mcp_tools.client, 'call_tool'):
                # MCP server tool: execute via client
                result = self.mcp_tools.client.call_tool(tool_name, arguments)
                
                # Convert MCPClientResult to standard format
                if hasattr(result, 'success'):
                    return {
                        "success": result.success,
                        "data": result.data,
                        "error": result.error,
                        "metadata": getattr(result, 'metadata', {})
                    }
                else:
                    return result
            else:
                return {
                    "success": False,
                    "error": f"Tool '{tool_name}' is not executable (neither built-in nor MCP)"
                }
            
        except Exception as e:
            self.logger.error(f"Error executing tool {tool_name}: {e}")
            return {
                "success": False,
                "error": f"Tool execution failed: {str(e)}"
            }
    
    def log_reasoning(self, iteration: int, reasoning: str):
        """Log reasoning step in the trace"""
        self.reasoning_trace.append({
            "type": "reasoning",
            "iteration": iteration,
            "content": reasoning,
            "timestamp": time.time()
        })
        self.execution_stats["reasoning_steps"] += 1
        self.execution_stats["total_steps"] += 1
        self.logger.info(f"Reasoning (Iter {iteration}): {reasoning[:100]}...")
    
    def log_action(self, iteration: int, tool: str, arguments: Dict[str, Any], result: Dict[str, Any]):
        """Log action step in the trace"""
        self.reasoning_trace.append({
            "type": "action", 
            "iteration": iteration,
            "tool": tool,
            "arguments": arguments,
            "result": result,
            "timestamp": time.time()
        })
        self.execution_stats["action_steps"] += 1
        self.execution_stats["total_steps"] += 1
        
        # Log success/failure
        success = result.get("success", True)
        status = "Success" if success else "Failed"
        self.logger.info(f"Action (Iter {iteration}): {tool} -> {status} -> {str(arguments)[:400]}...")
    
    def log_error(self, iteration: int, error: str):
        """Log error in the trace"""
        self.reasoning_trace.append({
            "type": "error",
            "iteration": iteration,
            "error": error,
            "timestamp": time.time()
        })
        self.execution_stats["error_steps"] += 1
        self.execution_stats["total_steps"] += 1
        self.logger.error(f"Error (Iter {iteration}): {error}")
    
    def reset_trace(self):
        """Reset the reasoning trace for a new task"""
        self.reasoning_trace = []
        self.execution_stats = {
            "total_steps": 0,
            "reasoning_steps": 0,
            "action_steps": 0, 
            "error_steps": 0,
            "tool_usage": {},
            "success_rate": 1.0
        }
    
    def get_execution_stats(self) -> Dict[str, Any]:
        """Get execution statistics"""
        # Calculate success rate
        if self.execution_stats["action_steps"] > 0:
            failed_actions = sum(1 for step in self.reasoning_trace 
                               if step.get("type") == "action" 
                               and not step.get("result", {}).get("success", True))
            self.execution_stats["success_rate"] = (
                (self.execution_stats["action_steps"] - failed_actions) / 
                self.execution_stats["action_steps"]
            )
        
        return self.execution_stats.copy()
    
    def create_response(self, success: bool, result: Dict[str, Any] = None, 
                       error: str = None, iterations: int = 0, 
                       execution_time: float = 0.0) -> AgentResponse:
        """Create a standardized agent response"""
        return AgentResponse(
            success=success,
            result=result,
            error=error,
            iterations=iterations,
            reasoning_trace=self.reasoning_trace.copy(),
            agent_name=self.config.agent_name,
            execution_time=execution_time
        )
    
    def validate_config(self) -> bool:
        """Validate agent configuration"""
        try:
            # Check required fields
            if not self.config.agent_name:
                return False
            if not self.config.model:
                return False
            if self.config.max_iterations <= 0:
                return False
            if not (0.0 <= self.config.temperature <= 2.0):
                return False
            if self.config.max_tokens <= 0:
                return False
            
            return True
        except Exception:
            return False

    def call_plain_llm(self, messages: List[Dict[str, str]], temperature: float = 0.2,
                       max_tokens: Optional[int] = None,
                       disable_thinking: bool = False) -> str:
        """Call the configured OpenAI-compatible chat endpoint and return content.

        Thinking-style models can spend the whole output budget on reasoning and
        then return an empty ``content``. When ``disable_thinking`` is True the
        request asks the gateway to turn reasoning off
        (``thinking: {"type": "disabled"}``) so the output budget is reserved for
        the final answer. If a normal call returns empty content, the raw response
        is saved for diagnosis and the call is retried once with thinking disabled
        before giving up.
        """
        from config.config import get_config

        api_cfg = get_config()
        model_config = api_cfg.get_custom_llm_config()
        model_url = model_config.get("url") or os.getenv("MODEL_REQUEST_URL", "")
        model_token = model_config.get("token") or os.getenv("MODEL_REQUEST_TOKEN", "")
        model_name = self.config.model or model_config.get("model") or os.getenv("MODEL_NAME", "")
        if not model_url:
            raise RuntimeError("MODEL_REQUEST_URL is not configured")

        if self.config.agent_name == "WriterAgent":
            disable_thinking = os.getenv("WRITER_DISABLE_THINKING", "true").lower() in (
                "1", "true", "yes"
            )

        headers = {"Content-Type": "application/json"}
        if model_token:
            headers["Authorization"] = f"Bearer {model_token}"
            headers["csb-token"] = model_token

        payload = {
            "model": model_name,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens or self.config.max_tokens or model_config.get("max_tokens", 2048),
        }
        if disable_thinking:
            payload["thinking"] = {"type": "disabled"}
            payload["enable_thinking"] = False
            payload["reasoning_effort"] = "none"

        response = post_model_request(
            model_url,
            headers=headers,
            json=payload,
            timeout=model_config.get("timeout", 180),
        )
        response.raise_for_status()
        data = response.json()
        if isinstance(data, str):
            data = json.loads(data)

        content = self._extract_llm_content(data)
        if content:
            return content

        diag_path = self._save_empty_llm_response(data, suffix="initial")
        choice = (data.get("choices") or [{}])[0]
        message = choice.get("message") or {}
        self.logger.warning(
            "call_plain_llm got empty content: finish_reason=%s content_len=%s "
            "reasoning_len=%s usage=%s diag=%s",
            choice.get("finish_reason"),
            len(str(message.get("content") or "")),
            len(str(message.get("reasoning_content") or "")),
            data.get("usage"),
            diag_path,
        )

        if not disable_thinking:
            self.logger.warning(
                "call_plain_llm retrying with thinking disabled to recover the answer body."
            )
            retry_content = self.call_plain_llm(
                messages,
                temperature=temperature,
                max_tokens=max_tokens,
                disable_thinking=True,
            )
            if retry_content:
                return retry_content
            self.logger.error(
                "call_plain_llm still empty after thinking-disabled retry."
            )
        return ""

    @staticmethod
    def _extract_llm_content(data: Dict[str, Any]) -> str:
        choices = data.get("choices") or []
        if not choices:
            raise RuntimeError(f"LLM response has no choices: {list(data.keys())}")
        message = choices[0].get("message") or {}
        content = message.get("content")
        if content is None:
            content = ""
        return str(content).strip()

    def _save_empty_llm_response(self, data: Dict[str, Any], suffix: str = "initial") -> Optional[str]:
        try:
            log_dir = os.path.join(os.getcwd(), "logs")
            os.makedirs(log_dir, exist_ok=True)
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            path = os.path.join(log_dir, f"llm_empty_response_{ts}_{suffix}.json")
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            return path
        except Exception as exc:
            self.logger.warning("Failed to save empty LLM response diagnostics: %s", exc)
            return None

    def stable_task_response(self, task_input: TaskInput, role_prompt: str,
                             task_name: str = "stable_task",
                             disable_thinking: bool = False) -> AgentResponse:
        """Fallback path for models that do not reliably emit tool-call JSON."""
        start_time = time.time()
        self.reset_trace()
        user_content = task_input.format_for_prompt() if hasattr(task_input, "format_for_prompt") else str(task_input)
        messages = [
            {"role": "system", "content": role_prompt},
            {"role": "user", "content": user_content},
        ]
        try:
            answer = self.call_plain_llm(
                messages,
                temperature=self.config.temperature or 0.2,
                disable_thinking=disable_thinking,
            )
            if not answer.strip():
                raise RuntimeError("LLM returned an empty answer body")
            answer = self._repair_citations_if_needed(
                answer, task_input, user_content, disable_thinking=disable_thinking
            )
            if not answer.strip():
                raise RuntimeError("LLM returned an empty answer body after citation repair")
            self.log_reasoning(1, answer)
            return self.create_response(
                success=True,
                result={
                    "task_summary": answer,
                    "task_name": task_name,
                    "key_files": getattr(task_input, "key_files", []) or [],
                    "completion_status": "completed",
                    "final_answer": answer,
                },
                iterations=1,
                execution_time=time.time() - start_time,
            )
        except Exception as exc:
            self.log_error(1, str(exc))
            return self.create_response(
                success=False,
                error=f"Stable task response failed: {exc}",
                iterations=1,
                execution_time=time.time() - start_time,
            )

    def _has_citable_sources(self, task_input: TaskInput) -> bool:
        key_files = getattr(task_input, "key_files", None)
        return bool(key_files)

    def _has_inline_citations(self, text: str) -> bool:
        return bool(text and re.search(r"\[\d+\]", text))

    def _has_reference_section(self, text: str) -> bool:
        return bool(text and re.search(r"(?im)^\s*(#{1,6}\s*)?(references|参考文献)\b", text))

    def _build_reference_block(self, task_input: TaskInput) -> str:
        key_files = getattr(task_input, "key_files", None) or []
        if not key_files:
            return ""

        lines = ["## References"]
        for index, file_info in enumerate(key_files, 1):
            if isinstance(file_info, dict):
                label = file_info.get("title") or file_info.get("desc") or file_info.get("file_path") or "source"
                path = file_info.get("file_path") or file_info.get("path") or ""
                extra = file_info.get("url") or file_info.get("paper_id") or ""
                entry = f"[{index}] {label}"
                if path:
                    entry += f" - {path}"
                if extra and extra not in entry:
                    entry += f" - {extra}"
                lines.append(entry)
            else:
                lines.append(f"[{index}] {str(file_info)}")
        return "\n".join(lines)

    def _repair_citations_if_needed(self, answer: str, task_input: TaskInput,
                                    user_content: str,
                                    disable_thinking: bool = False) -> str:
        if not answer or not self._has_citable_sources(task_input):
            return answer

        if self._has_inline_citations(answer) and self._has_reference_section(answer):
            return answer

        if self._has_inline_citations(answer) and not self._has_reference_section(answer):
            reference_block = self._build_reference_block(task_input)
            if reference_block:
                return answer.rstrip() + "\n\n" + reference_block
            return answer

        source_lines = []
        for index, file_info in enumerate(getattr(task_input, "key_files", []) or [], 1):
            if isinstance(file_info, dict):
                source_lines.append(
                    f"[{index}] {file_info.get('title') or file_info.get('desc') or file_info.get('file_path') or 'source'}"
                    f"{' - ' + file_info.get('file_path') if file_info.get('file_path') else ''}"
                )
            else:
                source_lines.append(f"[{index}] {str(file_info)}")

        repair_prompt = (
            "You are a citation formatter for a research report.\n"
            "Rewrite the answer so that it keeps the same substance, same language, and similar length,\n"
            "but every factual paragraph must carry inline citations like [1], [2].\n"
            "Use only the numbered sources listed below. Do not invent new facts or sources.\n"
            "If a sentence is a synthesis rather than a direct source claim, keep it but do not add unsupported source numbers.\n"
            "Finish with a References section that lists the numbered sources.\n\n"
            f"Original task:\n{user_content}\n\n"
            f"Draft answer:\n{answer}\n\n"
            "Sources:\n" + "\n".join(source_lines)
        )

        try:
            repaired = self.call_plain_llm(
                [
                    {
                        "role": "system",
                        "content": "You repair research reports so citations are explicit, consistent, and source-bound.",
                    },
                    {"role": "user", "content": repair_prompt},
                ],
                temperature=min(self.config.temperature or 0.2, 0.2),
                disable_thinking=disable_thinking,
            ).strip()
            if repaired and self._has_inline_citations(repaired):
                if self._has_inline_citations(repaired) and not self._has_reference_section(repaired):
                    reference_block = self._build_reference_block(task_input)
                    if reference_block:
                        repaired = repaired.rstrip() + "\n\n" + reference_block
                return repaired
            if repaired:
                self.logger.warning("Citation repair returned text without inline citations; keeping safer fallback.")
        except Exception as exc:
            self.logger.warning("Citation repair failed: %s", exc)

        reference_block = self._build_reference_block(task_input)
        if reference_block:
            return answer.rstrip() + "\n\n" + reference_block
        return answer
    
    @abstractmethod
    def execute_task(self, task_input: TaskInput) -> AgentResponse:
        """
        Execute a task using the standardized TaskInput format
        
        Args:
            task_input: TaskInput object with standardized task information
            
        Returns:
            AgentResponse with results and process trace
        """
        pass
    
    @abstractmethod
    def _build_system_prompt(self) -> str:
        """Build the system prompt for this agent"""
        pass


# Simple factory function for creating agent configurations

def create_agent_config(
    agent_name: str,
    model: Optional[str] = None,
    max_iterations: Optional[int] = None,
    temperature: Optional[float] = None,
    max_tokens: Optional[int] = None
) -> AgentConfig:
    """
    Create an AgentConfig instance for server-managed sessions.
    
    Args:
        agent_name: Name of the agent
        model: LLM model to use
        max_iterations: Maximum number of iterations
        temperature: LLM temperature setting
        max_tokens: Maximum tokens for LLM response
        
    Returns:
        Configured AgentConfig instance
    """
    # Load env-backed defaults
    try:
        from config.config import get_config
        api_cfg = get_config()
    except Exception as e:
        raise ValueError(f"Failed to load global configuration: {e}")
    
    planner_mode = getattr(api_cfg, "planner_mode", "auto")

    resolved_model = model if model is not None else getattr(api_cfg, "model_name", None)
    if not resolved_model:
        raise ValueError("Model is not specified and MODEL_NAME is not set in environment")

    resolved_temperature = temperature if temperature is not None else getattr(api_cfg, "model_temperature", None)
    if resolved_temperature is None:
        raise ValueError("Temperature is not specified and MODEL_TEMPERATURE is not set in environment")

    resolved_max_tokens = max_tokens if max_tokens is not None else getattr(api_cfg, "model_max_tokens", None)
    if resolved_max_tokens is None:
        raise ValueError("Max tokens is not specified and MODEL_MAX_TOKENS is not set in environment")

    # Optional paths used by writer and others
    trajectory_storage_path = getattr(api_cfg, "trajectory_storage_path", None)
    report_output_path = getattr(api_cfg, "report_output_path", None)
    document_analysis_path = getattr(api_cfg, "document_analysis_path", None)

    # Resolve max_iterations per agent type
    if max_iterations is None:
        agent_lower = (agent_name or "").lower()
        resolved_max_iterations = None
        if "planner" in agent_lower:
            resolved_max_iterations = getattr(api_cfg, "planner_max_iterations", None)
        elif "writer" in agent_lower:
            resolved_max_iterations = getattr(api_cfg, "writer_max_iterations", None)
        elif "information" in agent_lower or "seeker" in agent_lower:
            resolved_max_iterations = getattr(api_cfg, "information_seeker_max_iterations", None)
        # if not found in env, raise
        if resolved_max_iterations is None:
            raise ValueError("Max iterations not specified and no env override (PLANNER_MAX_ITERATION/WRITER_MAX_ITERATION/INFORMATION_SEEKER_MAX_ITERATION)")
        max_iterations = resolved_max_iterations

    return AgentConfig(
        agent_name=agent_name,
        planner_mode=planner_mode,
        model=resolved_model,
        max_iterations=int(max_iterations),
        temperature=resolved_temperature,
        max_tokens=resolved_max_tokens,
        trajectory_storage_path=trajectory_storage_path,
        report_output_path=report_output_path,
        document_analysis_path=document_analysis_path
    )

