# Copyright (c) 2025 Huawei Technologies Co., Ltd. All rights reserved.
# Copyright (c) 2026 South China Sea Institute of Oceanology, Chinese Academy of Sciences (SCSIO, CAS). All rights reserved.
"""
Planner Agent for Multi-Agent Task Coordination

This agent serves as a coordinator for complex tasks that require multiple agents
working together. It implements the ReAct pattern for reasoning and action.
"""
import time
import logging
import json
import requests
import os
import re
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
try:
    import litellm
except ImportError:
    litellm = None
from concurrent.futures import ThreadPoolExecutor, as_completed

# Base imports
from .base_agent import BaseAgent, AgentConfig, AgentResponse, WriterAgentTaskInput
from ..pdf_reliability import (
    attach_pdf_parse_sources, extract_explicit_arxiv_ids, pdf_source_from_tool_result,
    build_pdf_parser_status_report, build_pdf_partial_failure_notice, build_pdf_evidence_ledger,
    build_citation_check_report, verify_writer_citations,
    normalize_reference_heading,
    normalize_section_numbering,
    collect_paper_related_seeker_files, has_paper_related_seeker_file,
    filter_to_pdf_parse_sources, filter_to_paper_evidence_sources,
    is_pdf_parser_status_only_request,
    is_pdf_layout_boundary_test_request, build_pdf_layout_boundary_test_report,
    is_strict_pdf_evidence_request,
    verify_answer_numeric_claims, build_numeric_unverified_notice,
)
# Import agent creators for built-in task assignment
from .writer_agent import create_writer_agent


def _compact_key_files_for_writer(key_files: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    '''Trim heavy parser metadata before embedding key_files in the Writer prompt.

    The writer only needs identities, paths, confidence, page counts and a compact
    structured digest of reconstructed tables/formulas; full layout blocks/pages
    previews are parser diagnostics that bloat the prompt and make models more
    likely to truncate or return empty output. The digest keeps table captions,
    page spans, row counts and short merged previews so WriterAgent can cite
    cell rows without inventing values.
    '''
    compact = []
    for item in key_files or []:
        if not isinstance(item, dict):
            compact.append(item)
            continue
        quality = item.get('parse_quality') or {}
        status = item.get('parser_status') or {}
        parse_metadata = item.get('parse_metadata')
        compact_item = {
            'title': item.get('title'),
            'desc': item.get('desc'),
            'file_path': item.get('file_path'),
            'paper_id': item.get('paper_id'),
            'pdf_path': item.get('pdf_path'),
            'source_type': item.get('source_type'),
            'parse_quality': {
                'overall_confidence': quality.get('overall_confidence'),
                'failure_modes': quality.get('failure_modes') or [],
            },
            'parser_status': {
                'page_count': status.get('page_count'),
                'text_page_count': status.get('text_page_count'),
            },
        }
        structured_pages = parse_metadata.get('pages') if isinstance(parse_metadata, dict) else []
        if structured_pages:
            compact_item['layout_evidence'] = {
                'two_column_pages': [p.get('page') for p in structured_pages if p.get('layout') == 'two_column'],
                'reading_order_low_confidence_pages': [
                    p.get('page') for p in structured_pages
                    if p.get('reading_order_confidence') is not None and float(p.get('reading_order_confidence') or 0) < 0.75
                ],
                'visual_risk_pages': [
                    p.get('page') for p in structured_pages
                    if (p.get('visuals') or {}).get('figure_structure_risk')
                ],
            }
        # Structured reconstruction digest: keep compact table/formula previews so the
        # Writer can cite cell rows and page spans without the heavy metadata.
        structured = item.get('structured_evidence')
        if not isinstance(structured, dict):
            structured = parse_metadata if isinstance(parse_metadata, dict) else {}
        table_digest = []
        for table in (structured.get('tables') or []):
            if not isinstance(table, dict):
                continue
            verified = bool(table.get('cell_structure_verified'))
            cell_matrix = None
            if verified:
                cell_matrix = [
                    [str(cell)[:40] for cell in (row or [])[:12]]
                    for row in (table.get('cell_matrix') or [])[:20]
                ]
            table_digest.append({
                'table_id': table.get('table_id'),
                'page_span': table.get('page_span'),
                'pages': table.get('pages'),
                'caption': table.get('caption'),
                'row_count': table.get('row_count'),
                'continuation': bool(table.get('continuation')),
                'continuation_group_id': table.get('continuation_group_id'),
                'header_repeated': bool(table.get('header_repeated')),
                'cell_structure_verified': verified,
                'confidence': table.get('confidence'),
                'cell_matrix': cell_matrix,
                'merged_preview': (table.get('merged_text') or table.get('merged_preview') or '')[:300],
            })
        formula_digest = []
        for formula in (structured.get('formulas') or []):
            if not isinstance(formula, dict):
                continue
            formula_digest.append({
                'formula_id': formula.get('formula_id'),
                'page': formula.get('page'),
                'glyph_confidence': formula.get('glyph_confidence'),
                'strong_formula': bool(formula.get('strong_formula')),
                'latex_guess': formula.get('latex_guess'),
                'structure_uncertain': bool(formula.get('structure_uncertain')),
            })
        if table_digest or formula_digest:
            compact_item['structured_evidence'] = {'tables': table_digest, 'formulas': formula_digest}
        full_pdf_parser = item.get('full_pdf_parser_enhancement')
        if isinstance(full_pdf_parser, dict):
            compact_item['full_pdf_parser_enhancement'] = {
                'provider': full_pdf_parser.get('provider', 'llamaparse'),
                'status': full_pdf_parser.get('status'),
                'text_path': full_pdf_parser.get('text_path'),
                'tier': full_pdf_parser.get('tier'),
                'markdown_chars': full_pdf_parser.get('markdown_chars', 0),
                'requires_local_pdf_verification': True,
            }
        hybrid_evidence = item.get('hybrid_evidence')
        if isinstance(hybrid_evidence, dict):
            entries = [entry for entry in (hybrid_evidence.get('entries') or []) if isinstance(entry, dict)]
            compact_item['hybrid_evidence'] = {
                'path': item.get('hybrid_evidence_path'),
                'mode': hybrid_evidence.get('mode'),
                'usable_visual_entries': sum(1 for entry in entries if entry.get('citation_allowed')),
                'total_visual_entries': len(entries),
            }
        compact.append({key: value for key, value in compact_item.items() if value not in (None, '', [])})
    return compact


class PlannerAgent(BaseAgent):
    """
    PlannerAgent coordinates multiple agents to handle complex user queries.
    
    The agent uses the ReAct pattern (Reasoning + Acting) to analyze user requests,
    break them down into manageable tasks, and coordinate the appropriate agents
    to complete the work.
    """

    def __init__(self, config: AgentConfig = None, shared_mcp_client=None, task_id: Optional[str] = None):
        # Set default agent name if not specified
        if config and not config.agent_name:
            config.agent_name = "PlannerAgent"
        elif not config:
            config = AgentConfig(agent_name="PlannerAgent")

        super().__init__(config, shared_mcp_client)

        # Planner-specific state
        self.execution_plan = []
        self.task_queue = []
		
		# Task management for cancellation support
        self.task_id = task_id
        self._cancellation_token = None
		
        # Add built-in task assignment methods to available tools
        self._add_builtin_assignment_tools()

        # Regenerate tool schemas with built-in assignment tools
        self.tool_schemas = self._build_tool_schemas()

        self.sub_agent_configs = {}

    def _add_builtin_assignment_tools(self):
        """Add built-in task assignment methods as available tools"""
        # Add assignment methods that share the MCP client connection
        self.available_tools.update({
            "assign_subjective_task_to_writer": self.assign_subjective_task_to_writer, # assign_subjective_task_to_writer
            "assign_multi_objective_tasks_to_info_seeker": self.assign_multi_objective_tasks_to_info_seeker,
            "assign_multi_subjective_tasks_to_info_seeker": self.assign_multi_subjective_tasks_to_info_seeker
        })
    def _build_system_prompt(self) -> str:
        """Build the system prompt for the planner agent"""
        tool_schemas_str = json.dumps(self.tool_schemas, ensure_ascii=False)

        auto_system_prompt_template = """# PlannerAgent: Multi-Agent Task Coordinator
**Role:** Analyze complex queries, first distinguish query type (long-form writing type/objective question type), then create structured plans, and coordinate specialized agents to deliver comprehensive solutions—call corresponding tools based on query type, and only invoke writer for long-form writing type queries.

#### Available Sub-Agents:  
- **`information_seeker`**: Research, data gathering, web search (supports single/parallel multi-task; long-form writing type uses assign_multi_subjective_tasks_to_info_seeker, other types use assign_multi_objective_tasks_to_info_seeker)
- **`writer`**: Only invoke this sub-agent when long-form writing is required. 

---

## Optimized Workflow
### 1. Query Type Judgment & Analysis & Planning Phase
**Goal:** Use the `think` tool to analyze the problem and determine whether it is a simple task (refers to tasks that do not require calling the information search agent or tool) or a complex task (requires calling info seeker). If it is a complex task, it is necessary to further analyze whether it is a objective question（do not require calling the writer agent）or a long-form writing question (requires long-form expression and need to call the writer agent later).
- **Simple Tasks:** For simple tasks that do not require info seeker invocation, you can directly call the `planner_objective_task_done` tool and write the answer in `final_answer` field without creating a todo.md file.
- **Complex Tasks:**  
  - For objective tasks, must use `assign_multi_objective_tasks_to_info_seeker`
  - For long-form writing tasks, must use `assign_multi_subjective_tasks_to_info_seeker`, and call the writer agent to integrate the collected information to generate a very long text
  - **Task Decomposition Rules:** 
    - Construct a task tree with a tree-like structure, where the root node represents the user's input query. Each subtask is marked with its depth in the task tree, and the entire task tree is executed from shallow to deep. Tasks at the same depth in the task tree must be independent and can be executed in parallel (via `assign_multi_xxx_tasks_to_info_seeker`) without mutual dependencies.
    - At the first level of the task tree, it is essential to thoroughly design subtasks that can be executed in parallel to explore various potential background information, thereby providing more specific clues for the next step of planning.
    - Competitive Redundancy Mechanism:
      - For key subtasks that have a significant impact on subsequent reasoning and planning, a redundancy mechanism should be established. This involves duplicating the task at the same depth level in the task tree, enabling the parallel execution of nearly identical tasks to enhance the completion rate and robustness of the task execution.
  - **Task Parallel Sending Requirements:**
    - When using `assign_multi_xxx_tasks_to_info_seeker`, all parallel-sent subtasks must be independent of each other; the description of each subtask must not contain any mutual references or dependency requirements for other subtasks.
    - There is no sequential execution relationship among all parallel-sent subtasks.

  - **Mandatory Documentation:** Create and write `todo.md` (e.g., `todo_v1.md`) with fields:  
    ```markdown
    # Task Planning Document
    ## task_name: [Clear identifier]
    ## task_desc: [Detailed requirements - focus on WHAT not HOW]
    ## deliverable_contents: [Exact output format specs]
    ## success_criteria: [Measurable 100% completion metrics]
    ## context: [Background, constraints, prior results]
    ## task_steps_for_reference: [Tree-structured preliminary execution plan, tag tasks with the depth in task tree `[DEPTH:xx]`]
    ```  

### 2. Execution & Iteration Phase
#### A. Unified Iteration Triggers (Shared by Both Types)
- Based on upper-layer task results, refine the next layer of planning and document it in a new version of `todo.md` (e.g., `todo_v2.md`).  
- If upper-layer tasks fail/encounter challenges: Invoke the `reflect` tool for introspection (no new information acquired, only saves thoughts), adjust the plan, and re-invoke the corresponding `information_seeker` method (objective: `assign_multi_objective_tasks_to_info_seeker`; long-form writing: `assign_multi_subjective_tasks_to_info_seeker`).  
- If current tasks require prior round information: Clearly specify the context of each task and referenced files (e.g., `./data/agent_output_v1.json`) when calling `information_seeker`.  
- Decompose and refine clues from upper-layer results, then execute verification in parallel.  

#### B. Query-Type-Specific Operations
- **Objective tasks**: No additional operations (strictly no writer invocation). Continue iterating until information meets `success_criteria`.  
- **Long-form writing tasks**: Add **information sufficiency check before writer invocation**:  
  1. Evaluate collected information from two dimensions: quantity (e.g., "Enough case studies for 3 chapters") and comprehensiveness (e.g., "Covers both positive and negative impacts of AI on education").  
  2. If information is insufficient: Adjust subtask directions (e.g., "Supplement AI education failure cases") and re-invoke `assign_multi_subjective_tasks_to_info_seeker` for targeted collection.  
  3. If information is sufficient: Invoke the writer via `assign_subjective_task_to_writer` (provide all collected materials and `todo.md` as context).  
  4. If the writer returns an incomplete result: Do not assist in completing it; only feed back the current completion status to the user.  

### 3. Completion & Synthesis Phase
#### A. Unified Validation & Integration (Shared by Both Types)
- **Validation**: Cross-check multi-source `information_seeker` outputs for consistency (e.g., "NBS and World Bank GDP data differ by ≤1%").  
- **Integration**: Combine parallel outputs into a unified deliverable (e.g., "Merge two GDP data sources into a single table" or "Integrate writer’s report with supplementary case studies").  
- **Delivery**: Output language must match the user’s query language (e.g., Chinese query → Chinese deliverable).  

#### B. Query-Type-Specific Task Completion (Critical)
- **Objective tasks**: Call the `planner_objective_task_done` tool **only when** all planned tasks are completed and the final deliverable (e.g., verified data, clear answers) is ready for user delivery.  
- **Long-form writing tasks**: Call the `planner_subjective_task_done` tool **only when** the writer has finished executing and the final long-form content meets the `success_criteria` in `todo.md`.  

---

## Critical Protocols
1. **Dependency Management:**  
    - Prohibit parallel dispatch for sequential dependent tasks unless using competitive redundancy mechanism
    - Convert sequential chains to parallel where possible (e.g., Hypothesis_A vs Hypothesis_B testing)  
2. **File Traceability:**  
    - All output references use relative paths (`./data/agent_output_1.json`)  
    - Version `todo.md` after each iteration (e.g., `todo_v2.md`)
3. **Local File Reading Recommendations:**
    - For files crawled natively, it is not recommended to directly use the `file_read` tool to read the entire content (maybe too long). Instead, the `document_qa` tool should be used to extract and verify the required information.
    - For task deliverables and summary documents from sub-agents, the `file_read` tool can be used to read them.
4. The final deliverable presented to the user should be consistent with the language used in the user's question.
5. **Writer invocation**: Strictly prohibit calling the writer for objective tasks; for long-form writing tasks, **never directly answer based on collected information**—must invoke the writer to generate the final long-form content.

Below, within the <tools></tools> tags, are the descriptions of each tool and the required fields for invocation:
<tools>
$tool_schemas
</tools>
For each function call, return a JSON object placed within the [unused11][unused12] tags, which includes the function name and the corresponding function arguments:
[unused11][{\"name\": <function name>, \"arguments\": <args json object>}][unused12]"""

        writing_system_prompt_template = """### PlannerAgent: Multi-Agent Task Coordinator  
**Role:** Analyze complex queries, create structured plans, and coordinate specialized agents to deliver comprehensive solutions.  

#### Available Sub-Agents:  
- **`information_seeker`**: Research, data gathering, web search (supports single/parallel multi-task)  
- **`writer`**: Creates content (e.g., reports, analysis, etc.), and synthesizes from existing materials

---

### Optimized Workflow  
#### 1. Analysis & Planning Phase  
**Goal:** Analyze the problem and determine whether it is a simple task or a complex task. If it is a complex task, it is necessary to further analyze whether it is a subject-driven question or an objective-driven question, so as to decompose the problem into multiple clear and executable subtasks according to the specific problem type. The main characteristic of objective-driven questions is that their answers are clear and verifiable entities, otherwise they are subject-driven questions. 
- **Simple Tasks:** For simple tasks that do not require sub-agent invocation, you can directly answer without creating a todo.md file
- **Complex Tasks:**  
  - For Objective-driven tasks, Adopt *diverge-converge* strategy:  
    1. Use `assign_multi_subjective_tasks_to_info_seeker` call for divergent background research  
    2. Converge findings to define specific sub-problems  
  - For Subject-driven tasks, Adopt *multi-perspective* strategy:
    1. Use assign_multi_subjective_tasks_to_info_seeker call for divergent multi-source exploration (each task targets independent dimensions)
    2. Converge findings to define focused sub-problems addressing distinct knowledge gaps
    3. When the information seeker collects information, start to call the writer agent to integrate the collected information to generate a very long text
  - **Task Decomposition Rules:**  
    - Construct a task tree with a tree-like structure, where the root node represents the user's input query. Each subtask is marked with its depth in the task tree, and the entire task tree is executed from shallow to deep. Tasks at the same depth in the task tree must be independent and can be executed in parallel (via `assign_multi_subjective_tasks_to_info_seeker`) without mutual dependencies.
    - At the first level of the task tree, it is essential to thoroughly design subtasks that can be executed in parallel to explore various potential background information, thereby providing more specific clues for the next step of planning.
    - Competitive Redundancy Mechanism:
      - For key subtasks that have a significant impact on subsequent reasoning and planning, a redundancy mechanism should be established. This involves duplicating the task at the same depth level in the task tree, enabling the parallel execution of nearly identical tasks to enhance the completion rate and robustness of the task execution.
  - **Task Parallel Sending Requirements:**
    - When using `assign_multi_subjective_tasks_to_info_seeker`, all parallel-sent subtasks must be independent of each other; the description of each subtask must not contain any mutual references or dependency requirements for other subtasks.
    - There is no sequential execution relationship among all parallel-sent subtasks.

  - **Mandatory Documentation:** Create and write `todo.md` (e.g., `todo_v1.md`) with fields:  
    ```markdown
    # Task Planning Document
    ## task_name: [Clear identifier]
    ## task_desc: [Detailed requirements - focus on WHAT not HOW]
    ## deliverable_contents: [Exact output format specs]
    ## success_criteria: [Measurable 100% completion metrics]
    ## context: [Background, constraints, prior results]
    ## task_steps_for_reference: [Tree-structured preliminary execution plan, tag tasks with the depth in task tree `[DEPTH:xx]`]
    ```  

#### 2. Execution & Iteration Phase
- **Iteration Triggers:**
  - Based on the execution results of the upper layer of the task tree, specify and refine the next layer and subsequent task planning, and document them in a new `todo.md` file (e.g., `todo_v2.md`).
  - If there are tasks in the previous layer that have failed or encountered challenges, it is necessary to invoke `reflect` for introspection, consider more possibilities, and make new task planning and invoke `assign_multi_subjective_tasks_to_info_seeker` again. 
  - If the tasks sent in the current round require reference to task information from previous rounds, it is essential to clearly specify the context of each task and the files that may need to be used or referenced when calling `assign_multi_subjective_tasks_to_info_seeker`.
  - For the multiple clues of the execution results from the previous layer, they should be decomposed and refined, and executed in parallel for verification.
- **Information check required before calling writer:**  
  - Before invoking writer, analyze collected information for sufficiency: evaluate both quantity and comprehensiveness to ensure adequate material for long article generation
  - If information is insufficient, adjust subtask direction and initiate additional targeted information collection
- **When information is sufficient, invoke writer agent** via `assign_subjective_task_to_writer`

#### 3. Completion & Synthesis Phase  
- **Validation:** Cross-check multi-source outputs for consistency, and Check whether the information source is sufficient
- **Integration:** Combine parallel outputs into unified deliverable  
- **Delivery:** Output language must match user's query language  
- When the writer agent is finished executing, planner_subjective_task_done tool needs to be called to end the current task

---

### Critical Protocols  
1. **Dependency Management:**  
   - Prohibit parallel dispatch for sequential dependent tasks unless using competitive redundancy mechanism
   - Convert sequential chains to parallel where possible (e.g., Hypothesis_A vs Hypothesis_B testing)
2. **File Traceability:**  
   - All output references use relative paths (`./data/agent_output_1.json`)  
   - Version `todo.md` after each iteration (e.g., `todo_v2.md`)  
3. **Iteration Discipline:**  
   - Minimum 2 parallel agents for critical hypothesis-validation tasks  
   - Terminate only when ALL success criteria are met at 100%  
5. **Usage of Think Tool:**
   - `think` is a systematic tool. After receiving the response from the complex tool or before invoking any other tools, you must **first invoke the `think` tool**: to deeply reflect on the results of previous tool invocations (if any), and to thoroughly consider and plan the user's task. The `think` tool does not acquire new information; it only saves your thoughts into memory.
6. **Usage of Reflect Tool:**
    `reflect` is a systematic tool. When encountering a failure in tool execution, it is necessary to invoke the reflect tool to conduct a review and revise the task plan. It does not acquire new information; it only saves your thoughts into memory.
7. Always prioritize complete solutions over partial delivery. Use parallel redundancy for critical path tasks, and convert agent disagreements into new parallel investigation branches.
8. **CRITICAL:** When you determine that the information_seeker has gathered sufficient information, you must invoke the writer agent to draft the final article in response to the user's query. You are not allowed to reply directly based on the collected information!
9.Also note that when the writing agent returns a result that shows it is not completed, you do not need to help it complete it further. You only need to feedback the current completion status to the user.

Below, within the <tools></tools> tags, are the descriptions of each tool and the required fields for invocation:
<tools>
$tool_schemas
</tools>
For each function call, return a JSON object placed within the [unused11][unused12] tags, which includes the function name and the corresponding function arguments:
[unused11][{\"name\": <function name>, \"arguments\": <args json object>}][unused12]"""

        qa_system_prompt_template = """### PlannerAgent: Multi-Agent Task Coordinator  
**Role:** Analyze complex queries, create structured plans, and coordinate specialized agents to deliver comprehensive solutions.  

#### Available Sub-Agents:  
- **`information_seeker`**: Research, data gathering, web search (supports single/parallel multi-task)  

---

### Optimized Workflow  
#### 1. Analysis & Planning Phase  
**Goal:** Decompose problems into executable units with clear dependencies  
- **Simple Tasks:** For simple tasks that do not require sub-agent invocation, you can directly answer and call `planner_objective_task_done` without creating a todo.md file
- **Complex Tasks:**
  - **Task Decomposition Rules:**  
    - Construct a task tree with a tree-like structure, where the root node represents the user\'s input query. Each subtask is marked with its depth in the task tree, and the entire task tree is executed from shallow to deep. Tasks at the same depth in the task tree must be independent and can be executed in parallel (via `assign_multi_objective_tasks_to_info_seeker`) without mutual dependencies.
    - At the first level of the task tree, it is essential to thoroughly design subtasks that can be executed in parallel to explore various potential background information, thereby providing more specific clues for the next step of planning.
    - Competitive Redundancy Mechanism:
      - For key subtasks that have a significant impact on subsequent reasoning and planning, a redundancy mechanism should be established. This involves duplicating the task at the same depth level in the task tree, enabling the parallel execution of nearly identical tasks to enhance the completion rate and robustness of the task execution.
  - **Task Parallel Sending Requirements:**
    - When using `assign_multi_objective_tasks_to_info_seeker`, all parallel-sent subtasks must be independent of each other; the description of each subtask must not contain any mutual references or dependency requirements for other subtasks.
    - There is no sequential execution relationship among all parallel-sent subtasks.

  - **Mandatory Documentation:** Create and write `todo.md` (e.g., `todo_v1.md`) with fields:  
    ```markdown
    # Task Planning Document
    ## task_name: [Clear identifier]
    ## task_desc: [Detailed requirements - focus on WHAT not HOW]
    ## deliverable_contents: [Exact output format specs]
    ## success_criteria: [Measurable 100% completion metrics]
    ## context: [Background, constraints, prior results]
    ## task_steps_for_reference: [Tree-structured preliminary execution plan, tag tasks with the depth in task tree `[DEPTH:xx]`]
    ```  

#### 2. Execution & Iteration Phase
- **Iteration Triggers:**
  - Based on the execution results of the upper layer of the task tree, specify and refine the next layer and subsequent task planning, and document them in a new `todo.md` file (e.g., `todo_v2.md`).
  - If there are tasks in the previous layer that have failed or encountered challenges, it is necessary to invoke `reflect` for introspection, consider more possibilities, and make new task planning and invoke `assign_multi_objective_tasks_to_info_seeker` again. 
  - If the tasks sent in the current round require reference to task information from previous rounds, it is essential to clearly specify the context of each task and the files that may need to be used or referenced when calling `assign_multi_objective_tasks_to_info_seeker`.
  - For the multiple clues of the execution results from the previous layer, they should be decomposed and refined, and executed in parallel for verification.

#### 3. Completion & Synthesis Phase  
- **Validation:** Cross-check multi-source outputs for consistency
- **Integration:** Combine parallel outputs into unified deliverable  
- **Delivery:** Output language must match user\'s query language  
- **Task Completed:** The `planner_objective_task_done` can only be called when all planned tasks have been completed and the final results are ready to be delivered to the user.

---

### Critical Protocols  
1. **Dependency Management:**  
   - Prohibit parallel dispatch for sequential dependent tasks unless using competitive redundancy mechanism
   - Convert sequential chains to parallel where possible (e.g., Hypothesis_A vs Hypothesis_B testing)  
2. **File Traceability:**  
   - All output references use relative paths (`./data/agent_output_1.json`)  
   - Version `todo.md` after each iteration (e.g., `todo_v2.md`)
3. **Local File Reading Recommendations:**
    - For files crawled natively, it is not recommended to directly use the `file_read` tool to read the entire content (maybe too long). Instead, the `document_qa` tool should be used to extract and verify the required information.
    - For task deliverables and summary documents from sub-agents, the `file_read` tool can be used to read them.
4. The final deliverable presented to the user should be consistent with the language used in the user\'s question.

Below, within the <tools></tools> tags, are the descriptions of each tool and the required fields for invocation:
<tools>
$tool_schemas
</tools>
For each function call, return a JSON object placed within the [unused11][unused12] tags, which includes the function name and the corresponding function arguments:
[unused11][{\"name\": <function name>, \"arguments\": <args json object>}][unused12]"""

        planner_mode_system_prompt_map = {
            "auto": auto_system_prompt_template,
            "writing": writing_system_prompt_template,
            "qa": qa_system_prompt_template
        }

        system_prompt = planner_mode_system_prompt_map[self.config.planner_mode].replace("$tool_schemas", tool_schemas_str)

        return system_prompt

    def assign_multi_objective_tasks_to_info_seeker(
            self,
            tasks: List[Dict[str, str]],
            max_workers: int = 5,
            paper_evidence_mode: Optional[str] = None
        ) -> Dict[str, Any]:
        """
        Creates multiple TaskInput objects and routes them to info_seeker agents for concurrent execution.
        This tool enables the PlannerAgent to assign multiple research tasks through the MCP tool interface.
        
        Args:
            tasks: List of task dictionaries with the following keys:
                - task_content (required): The specific task content
                - task_steps_for_reference: Optional reference steps for execution
                - deliverable_contents: Format of expected deliverable
                - acceptance_checking_criteria: Criteria for task completion and quality
                - workspace_id: Workspace ID for stored files and memory
                - current_task_status: Description of current task status
                
            max_workers: Maximum concurrent threads (default=4)
            
        Returns:
            MCPToolResult with execution results for all tasks
        """
        try:
            # Validate task count (1-4 tasks)
            if not (1 <= len(tasks) <= 5):
                return {
                    "success": False,
                    "error": f"Invalid task count ({len(tasks)}). Must assign 1~5 tasks. Please re-plan the task execution schedule or re-decompose the task."
                }
            
            # Import here to avoid circular imports
            try:
                from agents import TaskInput, create_objective_information_seeker
            except ImportError:
                from ..agents import TaskInput, create_objective_information_seeker
            
            results = []
            import threading
            lock = threading.Lock()
            
            def process_task(task: Dict[str, str]):
                """Process a single task with thread-safe result collection"""
                try:
                    
                    
                    # Create TaskInput object
                    task_input = TaskInput(
                        task_content=task["task_content"],
                        task_steps_for_reference=task.get("task_steps_for_reference"),
                        deliverable_contents=task.get("deliverable_contents"),
                        current_task_status=task.get("current_task_status"),
                        workspace_id=None,  # Session/workspace is managed by the server; no need to set explicitly
                        acceptance_checking_criteria=task.get("acceptance_checking_criteria")
                    )
                    
                    # Create and execute with info seeker agent - use shared MCP client for session consistency
                    info_seeker_config = getattr(self, 'sub_agent_configs', {}).get('information_seeker', {})
                    info_seeker = create_objective_information_seeker(
                        model=info_seeker_config.get('model', self.config.model),
                        max_iterations=info_seeker_config.get('max_iterations', 30),
                        shared_mcp_client=self.mcp_tools.client if hasattr(self.mcp_tools, 'client') else self.mcp_tools,
                        paper_evidence_mode=paper_evidence_mode
                    )

                    self.logger.info(f"Assigning task to InformationSeekerAgent: {task['task_content'][:8000]}...")

                    
                    # Execute the task, then retry once serially if the first run fails.
                    response = info_seeker.execute_task(task_input)
                    if not response.success:
                        self.logger.warning(
                            "InformationSeekerAgent failed once for task '%s'. Retrying once.",
                            task.get("task_content", "")[:200]
                        )
                        response = info_seeker.execute_task(task_input)

                    if response.success:
                        response_data = {
                            "task_content": task.get("task_content", "Unknown task"),
                            "success": True,
                            "data": response.result,
                            "agent_name": response.agent_name,
                            "iterations": response.iterations,
                            "execution_time": response.execution_time,
                            # "reasoning_trace": response.reasoning_trace
                        }
                    else:
                        response_data = {
                            "task_content": task.get("task_content", "Unknown task"),
                            "success": False,
                            "error": response.error,
                            "agent_name": response.agent_name
                        }                    
                    
                    # Thread-safe result collection
                    with lock:
                        results.append(response_data)
                    
                    return response_data
                    
                except Exception as e:
                    error_msg = f"Task processing failed: {str(e)}"
                    self.logger.error(error_msg)
                    with lock:
                        results.append({
                            "task_content": task.get("task_content", "Unknown task"),
                            "success": False,
                            "error": error_msg
                        })
                    return None
            
            # Execute tasks in parallel with thread pool
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = [executor.submit(process_task, task) for task in tasks]
                # Wait for all tasks to complete
                for future in futures:
                    future.result()  # Raise exceptions if any
            
            # Check overall success
            all_success = all(task_result.get("success", False) for task_result in results)
            
            return {
                "success": all_success,
                "data": {"tasks": results},
                "error": None if all_success else "Some tasks failed",
                "metadata": {
                    "tool_name": "assign_multi_objective_tasks_to_info_seeker",
                    "task_count": len(tasks),
                    "success_count": sum(1 for r in results if r.get("success")),
                    "failure_count": sum(1 for r in results if not r.get("success"))
                }
            }
                
        except Exception as e:
            self.logger.error(f"Multi-task assignment failed: {e}")
            return {
                "success": False,
                "error": f"Multi-task assignment failed: {str(e)}"
            }
    

    def assign_multi_subjective_tasks_to_info_seeker(
            self,
            tasks: List[Dict[str, str]],
            max_workers: int = 5,
            paper_evidence_mode: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Creates multiple TaskInput objects and routes them to info_seeker agents for concurrent execution.
        This tool enables the PlannerAgent to assign multiple research tasks through the MCP tool interface.
        
        Args:
            tasks: List of task dictionaries with the following keys:
                - task_content (required): The specific task content
                - task_steps_for_reference: Optional reference steps for execution
                - deliverable_contents: Format of expected deliverable
                - acceptance_checking_criteria: Criteria for task completion and quality
                - workspace_id: Workspace ID for stored files and memory
                - current_task_status: Description of current task status
                
            max_workers: Maximum concurrent threads (default=4)
            
        Returns:
            MCPToolResult with execution results for all tasks
        """
        try:
            # Validate task count (1-4 tasks)
            if not (1 <= len(tasks) <= 6):
                return {
                    "success": False,
                    "error": f"Invalid task count ({len(tasks)}). Must assign 1-6 tasks."
                }

            # Import here to avoid circular imports
            try:
                from agents import TaskInput, create_subjective_information_seeker
            except ImportError:
                from ..agents import TaskInput, create_subjective_information_seeker

            results = []
            import threading
            lock = threading.Lock()

            def process_task(task: Dict[str, str]):
                """Process a single task with thread-safe result collection"""
                try:
                    # Create TaskInput object
                    task_input = TaskInput(
                        task_content=task["task_content"],
                        task_steps_for_reference=task.get("task_steps_for_reference"),
                        deliverable_contents=task.get("deliverable_contents"),
                        current_task_status=task.get("current_task_status"),
                        workspace_id=self.get_session_info()["session_id"],  # Session/workspace is managed by the server; no need to set explicitly
                        acceptance_checking_criteria=task.get("acceptance_checking_criteria")
                    )

                    # Create and execute with info seeker agent - use shared MCP client for session consistency
                    info_seeker_config = getattr(self, 'sub_agent_configs', {}).get('information_seeker', {})
                    configured_iterations = info_seeker_config.get('max_iterations', 30)
                    # An explicit arXiv paper already has a canonical local PDF.
                    # Keep the evidence boundary, but avoid spending 20+ turns
                    # on generic search/planning branches.
                    if paper_evidence_mode:
                        configured_iterations = min(configured_iterations, 8)
                    info_seeker = create_subjective_information_seeker(
                        model=info_seeker_config.get('model', self.config.model),
                        max_iterations=configured_iterations,
                        shared_mcp_client=self.mcp_tools.client if hasattr(self.mcp_tools, 'client') else self.mcp_tools,
                        paper_evidence_mode=paper_evidence_mode
                    )

                    self.logger.info(f"Assigning task to InformationSeekerAgent: {task['task_content'][:8000]}...")

                    # Execute the task
                    response = info_seeker.execute_task(task_input)

                    if response.success:
                        response_data = {
                            "task_content": task.get("task_content", "Unknown task"),
                            "success": True,
                            "data": response.result,
                            "agent_name": response.agent_name,
                            "iterations": response.iterations,
                            "execution_time": response.execution_time,
                            # "reasoning_trace": response.reasoning_trace
                        }
                    else:
                        response_data = {
                            "task_content": task.get("task_content", "Unknown task"),
                            "success": False,
                            "error": response.error,
                            "agent_name": response.agent_name
                        }

                        # Thread-safe result collection
                    with lock:
                        results.append(response_data)

                    return response_data

                except Exception as e:
                    error_msg = f"Task processing failed: {str(e)}"
                    self.logger.error(error_msg)
                    with lock:
                        results.append({
                            "task_content": task.get("task_content", "Unknown task"),
                            "success": False,
                            "error": error_msg
                        })
                    return None

            # Execute tasks in parallel with thread pool
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = [executor.submit(process_task, task) for task in tasks]
                # Wait for all tasks to complete
                for future in futures:
                    future.result()  # Raise exceptions if any

            # Continue as long as at least one branch produced usable material.
            success_count = sum(1 for r in results if r.get("success"))
            all_success = success_count > 0

            return {
                "success": all_success,
                "data": {"tasks": results},
                "error": None if all_success else "All information seeker tasks failed",
                "metadata": {
                    "tool_name": "assign_multi_subjective_tasks_to_info_seeker",
                    "task_count": len(tasks),
                    "success_count": success_count,
                    "failure_count": sum(1 for r in results if not r.get("success"))
                }
            }

        except Exception as e:
            self.logger.error(f"Multi-task assignment failed: {e}")
            return {
                "success": False,
                "error": f"Multi-task assignment failed: {str(e)}"
            }

    def assign_subjective_task_to_writer(
            self,
            task_content: str,
            user_query: str,
            key_files: List[Dict[str, str]]
    ) -> Dict[str, Any]:
        """
        Assign a writing or content creation task to the WriterAgent

        Args:
            task_content: Detailed description of the writing task to be performed
            user_query: List storing previous information seeker subtask summaries intact to preserve information from each completed research task
            key_files: Curated list of relevant files with file_path and desc for each file

        Returns:
            Dictionary with task assignment results
        """
        try:

            self.logger.info("Assigning task to WriterAgent")

            # Create task input
            task_input = WriterAgentTaskInput(
                task_content=task_content,
                user_query=user_query,
                key_files=key_files,
                workspace_id=self.get_session_info()["session_id"],
            )

            # Create writer agent with shared MCP client and sub-agent configuration
            writer_config = getattr(self, 'sub_agent_configs', {}).get('writer', {})
            writer = create_writer_agent(
                shared_mcp_client=self.mcp_tools.client,
                model=writer_config.get('model', self.config.model),
                max_iterations=writer_config.get('max_iterations', 20),
                temperature=writer_config.get('temperature', 0.3),
                max_tokens=writer_config.get('max_tokens', 16384)
            )

            self.logger.info(f"Assigning task to WriterAgent: {task_content[:800]}...")

            # Execute the task with shared connection
            response = writer.execute_task(task_input)

            if response.success:
                return {
                    "success": True,
                    "data": response.result,
                    "agent_name": response.agent_name,
                    "iterations": response.iterations,
                    "execution_time": response.execution_time,
                    # "reasoning_trace": response.reasoning_trace
                }
            else:
                return {
                    "success": False,
                    "error": response.error,
                    "agent_name": response.agent_name
                }

        except Exception as e:
            self.logger.error(f"Failed to assign task to WriterAgent: {e}")
            return {
                "success": False,
                "error": f"Task assignment failed: {str(e)}"
            }

    def _execute_stable_writing_chain(self, user_query: str, start_time: float) -> Dict[str, Any]:
        """
        Reliable fallback chain for chat models that answer in prose instead of
        emitting the custom [unused11]/[unused12] tool-call envelope.
        """
        self.reset_trace()
        self.logger.info("Running stable Planner -> InformationSeeker -> Writer chain")

        # A literal arXiv ID is an instruction to use that paper, not merely a
        # search hint. Fetch it before sub-agents begin so PDF quality metadata
        # cannot be replaced by search snippets or discarded by an LLM summary.
        prefetched_key_files = []
        paper_source_instruction = ''
        prefetch_errors = {}
        requested_paper_ids = extract_explicit_arxiv_ids(user_query)
        strict_pdf_request = is_strict_pdf_evidence_request(user_query)
        paper_mode = bool(requested_paper_ids) or strict_pdf_request
        paper_evidence_mode = (
            "strict_pdf_evidence" if strict_pdf_request
            else "paper_evidence" if requested_paper_ids
            else None
        )
        for paper_id in requested_paper_ids:
            tool_call = {
                'name': 'arxiv_read_paper',
                'arguments': {'paper_id': paper_id},
            }
            tool_result = self.execute_tool_call(tool_call)
            self.log_action(0, 'arxiv_read_paper', tool_call['arguments'], tool_result)
            if not tool_result.get('success'):
                # arXiv downloads are frequently flaky; retry once before giving up.
                self.logger.warning(
                    "arXiv prefetch failed for %s: %s; retrying once.",
                    paper_id,
                    tool_result.get('error'),
                )
                time.sleep(1.0)
                tool_result = self.execute_tool_call(tool_call)
                self.log_action(0, 'arxiv_read_paper', tool_call['arguments'], tool_result)
            if not tool_result.get('success'):
                prefetch_errors[paper_id] = str(
                    tool_result.get('error') or 'arxiv_read_paper returned an unsuccessful result'
                )
                continue
            # Keep the exact MCP envelope here.  In strict PDF mode we never
            # rely on a sub-agent trace/completion to reconstruct parser facts.
            canonical_source = pdf_source_from_tool_result(tool_result, tool_call['arguments'])
            self.logger.info(
                "Strict PDF prefetch audit: result_type=%s success=%s canonical=%s canonical_keys=%s",
                type(tool_result).__name__,
                tool_result.get('success') if isinstance(tool_result, dict) else getattr(tool_result, 'success', None),
                bool(canonical_source),
                list(canonical_source.keys()) if canonical_source else [],
            )
            if canonical_source:
                prefetched_key_files.append(canonical_source)
            else:
                # Non-strict requests may still use the trace compatibility path.
                source_record = attach_pdf_parse_sources(
                    {'key_files': []},
                    [{'tool': 'arxiv_read_paper', 'arguments': tool_call['arguments'], 'result': tool_result}],
                )
                prefetched_key_files.extend(source_record['key_files'])
            source_data = tool_result.get('data') if isinstance(tool_result.get('data'), dict) else {}
            text_path = source_data.get('text_path') or source_data.get('pdf_path')
            full_llama = source_data.get('llama_full_pdf') if isinstance(source_data.get('llama_full_pdf'), dict) else {}
            full_llama_path = source_data.get('llama_full_pdf_text_path') or full_llama.get('text_path')
            if text_path:
                local_role = "the mandatory page-level verification source" if full_llama.get('status') == 'completed' and full_llama_path else "the primary evidence source"
                paper_source_instruction += (
                    f"\nMandatory local source: arXiv:{paper_id} has already been downloaded and parsed at "
                    f"{text_path}. Read this local extraction as {local_role}; do not substitute web "
                    "search snippets for claims about its formulas, figures, or tables."
                    + (" This is a strict PDF-only task: do not use HTML conversions, web sources, or prior research notes as evidence." if strict_pdf_request else "")
                )
            if full_llama.get('status') == 'completed' and full_llama_path:
                paper_source_instruction += (
                    f"\nMandatory content source: LlamaParse processed the entire official PDF at {full_llama_path}. "
                    "Use this whole-document transcription as the main source for the paper's narrative, formulas, "
                    "tables, and figure captions. The local PDF extraction remains the mandatory verification source "
                    "for page references, bounding boxes, exact table cells, formula glyphs, chart values, and diagram "
                    "edges. Do not cite LlamaParse as a separate paper."
                )
            hybrid_evidence = source_data.get('hybrid_evidence') if isinstance(source_data.get('hybrid_evidence'), dict) else {}
            hybrid_evidence_path = source_data.get('hybrid_evidence_path')
            if hybrid_evidence_path and hybrid_evidence.get('entries'):
                paper_source_instruction += (
                    f"\nMandatory visual supplement: the hybrid LlamaParse evidence ledger is at {hybrid_evidence_path}. "
                    "Use only entries where citation_allowed is true. Insert a visual explanation into the paper's "
                    "prose only when its page, bbox, and nearest figure caption identify the same object; otherwise "
                    "describe it as a page-level visual supplement rather than attaching it to a paragraph. Preserve "
                    "the entry's diagnostic_flags and uncertainties in any qualification."
                )

        # Pure parser-boundary diagnostics are not an LLM writing task. Return
        # directly from the tool-observed source so no InformationSeeker report
        # can replace 12/46/21/4 with invented counts.
        if strict_pdf_request and requested_paper_ids and is_pdf_parser_status_only_request(user_query):
            canonical_sources = filter_to_pdf_parse_sources(prefetched_key_files)
            if not canonical_sources:
                return {
                    "success": False,
                    "error": "Strict PDF evidence requested, but arxiv_read_paper did not expose usable parser metadata.",
                    "reasoning_trace": self.reasoning_trace,
                    "iterations": 1,
                    "execution_time": time.time() - start_time,
                }
            final_answer = build_pdf_parser_status_report(canonical_sources)
            ledger = build_pdf_evidence_ledger(canonical_sources)
            if ledger:
                final_answer = f"{final_answer}\n\n{ledger}"
            failure_notice = build_pdf_partial_failure_notice(canonical_sources)
            if failure_notice:
                final_answer = f"{final_answer}\n\n{failure_notice}"
            completion = {
                "task_summary": "Completed directly from canonical arxiv_read_paper parser metadata.",
                "task_name": "strict_pdf_parser_boundary_report",
                "key_files": canonical_sources,
                "completion_status": "completed",
                "agent_chain": ["PlannerAgent", "arxiv_read_paper"],
                "agent_outputs": [],
                "final_answer": final_answer,
            }
            self.log_action(1, "planner_strict_pdf_parser_report", {}, completion)
            return {
                "success": True,
                "data": completion,
                "reasoning_trace": self.reasoning_trace,
                "iterations": 1,
                "execution_time": time.time() - start_time,
            }

        source_policy = ""
        if paper_evidence_mode == "strict_pdf_evidence":
            source_policy = (
                "\nSTRICT PDF-ONLY SOURCE POLICY: admissible evidence is only the parsed local PDF "
                "text for the requested arXiv paper (arxiv_read_paper / file_read / document_qa / "
                "document_extract). Do not call batch_web_search, url_crawler, arxiv_search, or use "
                "prior research notes."
            )
        elif paper_evidence_mode == "paper_evidence":
            source_policy = (
                "\nPAPER-SOURCE MODE: admissible evidence is only arXiv:"
                + ", ".join(requested_paper_ids)
                + " PDF extraction and official affiliated resources linked inside the paper "
                "(official project page, code repository, supplementary material). Do not use "
                "third-party blogs, articles, or other papers."
            )

        if paper_mode:
            research_tasks = [{
                "task_content": (
                    "Analyze the already downloaded and parsed arXiv paper as one bounded task. "
                    "Read the local PDF extraction and parser metadata once, then collect the title, motivation, "
                    "core method, formulas, architecture/figures, experiments, tables, limitations, and explicit "
                    "uncertainties needed for the final answer. Do not call arxiv_search, web search, URL crawlers, "
                    "file editing tools, or arxiv_read_paper again. "
                    "Return evidence in these fixed sections: (1) core method, (2) formula interpretation, "
                    "(3) model/figure structure, (4) experimental setup and results, (5) table values, "
                    "(6) limitations and unresolved extraction risks. For every exact number, formula symbol, "
                    "table cell, or figure connection, distinguish directly extracted evidence from interpretation; "
                    "if the parser is incomplete or layout is ambiguous, write '无法可靠提取' and do not infer it. "
                    f"{user_query}{paper_source_instruction}{source_policy}"
                ),
                    "task_steps_for_reference": "When supplied, read the whole-PDF LlamaParse transcription as the main content source, then use the canonical local PDF extraction and page metadata to verify exact evidence; batch questions where possible and avoid repeated reads.",
                "deliverable_contents": "One concise, evidence-linked paper analysis with parser risks and unresolved cells/formulas/figure topology.",
                "acceptance_checking_criteria": "Covers the requested paper directly and clearly marks unsupported details.",
            }]
        else:
            research_tasks = [
                {
                    "task_content": (
                        "Research the background, motivation, core concepts, and representative methods needed for: "
                        f"{user_query}{paper_source_instruction}{source_policy}"
                    ),
                    "task_steps_for_reference": "Summarize reliable technical context and avoid unsupported claims.",
                    "deliverable_contents": "Concise research notes with key points, terminology, and verifiable clues.",
                    "acceptance_checking_criteria": "Covers background and methods clearly enough for a writer agent.",
                },
                {
                    "task_content": (
                        "Research current challenges, limitations, applications, and future directions related to: "
                        f"{user_query}{paper_source_instruction}{source_policy}"
                    ),
                    "task_steps_for_reference": "Focus on analysis dimensions that make the final report useful.",
                    "deliverable_contents": "Concise notes on challenges, applications, and future research directions.",
                    "acceptance_checking_criteria": "Provides enough material for a final structured report.",
                },
            ]

        info_result = self.assign_multi_subjective_tasks_to_info_seeker(
            research_tasks, max_workers=1 if paper_mode else 2, paper_evidence_mode=paper_evidence_mode
        )
        self.log_action(
            1,
            "assign_multi_subjective_tasks_to_info_seeker",
            {"tasks": research_tasks, "max_workers": 2},
            info_result,
        )
        if not info_result.get("success"):
            local_sources = filter_to_paper_evidence_sources(prefetched_key_files)
            if paper_mode and local_sources:
                # The PDF was fetched and parsed successfully, so an
                # InformationSeeker transport/planning failure must not erase
                # the evidence. Continue directly with the bounded local PDF.
                degrade_notice = (
                    "## 论文检索降级说明\n\n"
                    "InformationSeekerAgent 未能完成检索代理任务；系统已改用已获取的官方 arXiv PDF 本地解析结果。"
                    "以下内容仅依据该 PDF 及其解析风险生成，未使用其他论文或网页来源。"
                )
                task_results = []
                materials = "LOCAL PDF FALLBACK: use only the prefetched canonical PDF source."
            else:
                return {
                    "success": False,
                    "error": info_result.get("error") or "InformationSeekerAgent failed",
                    "reasoning_trace": self.reasoning_trace,
                    "iterations": 1,
                    "execution_time": time.time() - start_time,
                }

        if info_result.get("success"):
            task_results = info_result.get("data", {}).get("tasks", [])
        material_chunks = []
        writer_key_files = list(prefetched_key_files)
        for index, task_result in enumerate(task_results, 1):
            data = task_result.get("data", {})
            if isinstance(data, dict):
                material_chunks.append(
                    f"InformationSeeker result {index}:\n"
                    f"{data.get('final_answer') or data.get('task_summary') or json.dumps(data, ensure_ascii=False)}"
                )
                data_key_files = data.get("key_files") or []
                if paper_mode:
                    # InformationSeeker may create HTML conversions or old research notes. They
                    # are not admissible evidence for paper-bound answers.
                    data_key_files = filter_to_paper_evidence_sources(data_key_files)
                if isinstance(data_key_files, list) and data_key_files:
                    writer_key_files.extend(data_key_files)
                else:
                    writer_key_files.append({
                        "title": f"InformationSeeker result {index}",
                        "desc": "Collected research note produced by InformationSeekerAgent",
                        "file_path": "",
                    })
            else:
                material_chunks.append(f"InformationSeeker result {index}:\n{data}")
                writer_key_files.append({
                    "title": f"InformationSeeker result {index}",
                    "desc": "Collected research note produced by InformationSeekerAgent",
                    "file_path": "",
                })
        materials = "\n\n".join(material_chunks)
        if not materials and paper_mode and filter_to_paper_evidence_sources(prefetched_key_files):
            materials = "LOCAL PDF FALLBACK: use only the prefetched canonical PDF source."
        degrade_notice = locals().get("degrade_notice", "")
        if paper_mode and requested_paper_ids and not filter_to_paper_evidence_sources(prefetched_key_files):
            # Better to surface a transport/data-contract failure than invent a
            # parser report from an InformationSeeker note.
            if strict_pdf_request or not has_paper_related_seeker_file(task_results, requested_paper_ids):
                error = (
                    "Strict PDF evidence requested, but arxiv_read_paper did not produce a usable parsed PDF source."
                    if strict_pdf_request
                    else "arXiv paper prefetch failed, and no paper local text was collected by InformationSeeker."
                )
                if prefetch_errors:
                    error += " Failure detail: " + "; ".join(
                        f"arXiv:{paper_id} - {reason}" for paper_id, reason in prefetch_errors.items()
                    )
                return {
                    "success": False,
                    "error": error,
                    "reasoning_trace": self.reasoning_trace,
                    "iterations": 1,
                    "execution_time": time.time() - start_time,
                }
            degrade_notice = (
                '## \u9884\u53d6\u5931\u8d25\u8bf4\u660e\n\n'
                'Planner \u9884\u53d6 arXiv \u8bba\u6587 PDF \u5931\u8d25\uff0c'
                '\u672c\u6b21\u5df2\u6539\u7528 InformationSeeker \u5728\u53d7\u9650\u5de5\u5177\u4e0b\u6536\u96c6\u7684\u8bba\u6587\u672c\u5730\u6587\u672c\u3002'
                '\u8bc1\u636e\u4ecd\u4ec5\u9650\u8be5\u8bba\u6587\u53ca\u5176\u5b98\u65b9\u9644\u5c5e\u8d44\u6e90\uff0c'
                '\u4f46\u89e3\u6790\u5668\u7ea7\u9875\u6570/\u7f6e\u4fe1\u5ea6\u5143\u6570\u636e\u672a\u7ecf Planner \u6821\u9a8c\u3002\n'
                + '\n'.join(
                    f'- arXiv:{paper_id}: {reason}' for paper_id, reason in prefetch_errors.items()
                )
            )

        if paper_mode:
            # InformationSeeker can generate a prose parse report from a partial file read.
            # Do not pass that prose to WriterAgent: parser counts must originate only from
            # the prefetch result retained in this planner trace.
            writer_key_files = filter_to_paper_evidence_sources(prefetched_key_files)
            seeker_paper_sources = []
            for task_result in task_results:
                data = task_result.get("data", {})
                if isinstance(data, dict):
                    seeker_paper_sources.extend(
                        filter_to_paper_evidence_sources(data.get("key_files") or [])
                    )
            if prefetch_errors:
                seeker_paper_sources.extend(
                    collect_paper_related_seeker_files(task_results, requested_paper_ids)
                )
            for source in seeker_paper_sources:
                if source not in writer_key_files:
                    writer_key_files.append(source)
            if not writer_key_files:
                writer_key_files = filter_to_paper_evidence_sources(
                    attach_pdf_parse_sources({'key_files': []}, self.reasoning_trace).get('key_files')
                )
            if strict_pdf_request:
                materials = (
                    "STRICT PDF-ONLY EVIDENCE MODE. Do not use InformationSeeker prose, HTML, web snippets, or "
                    "previous research reports as evidence. A deterministic parser-status block is supplied separately. "
                    "For the remainder, only make claims that are supported by the parsed local PDF source; do not repeat "
                    "parser counts, infer table cells, repair formulas, or assert that an LLM received the full PDF text."
                )

        writer_result = self.assign_subjective_task_to_writer(
            task_content=(
                "Write the final answer for the user. Use the InformationSeeker notes as source material. "
                "Keep the output clear, structured, and directly useful."
            ),
            user_query=f"Original user query:\n{user_query}\n\nCollected research notes:\n{materials}",
            key_files=_compact_key_files_for_writer(writer_key_files),
        )
        self.log_action(
            2,
            "assign_subjective_task_to_writer",
            {
                "task_content": "Write final answer from collected InformationSeeker notes.",
                "user_query": user_query,
                "key_files": writer_key_files,
            },
            writer_result,
        )
        if not writer_result.get("success"):
            return {
                "success": False,
                "error": writer_result.get("error") or "WriterAgent failed",
                "reasoning_trace": self.reasoning_trace,
                "iterations": 2,
                "execution_time": time.time() - start_time,
            }

        writer_data = writer_result.get("data", {})
        final_answer = ""
        if isinstance(writer_data, dict):
            final_answer = writer_data.get("final_answer") or writer_data.get("task_summary") or ""
        else:
            final_answer = str(writer_data)

        if not final_answer.strip():
            return {
                "success": False,
                "error": "WriterAgent returned an empty answer; no report body was generated.",
                "reasoning_trace": self.reasoning_trace,
                "iterations": 2,
                "execution_time": time.time() - start_time,
            }

        # Re-attach from the planner trace rather than trusting the LLM-shaped
        # InformationSeeker/Writer hand-off. This is also what the CLI renders as
        # top-level ``key_files`` for auditability.
        completion_sources = attach_pdf_parse_sources(
            {'key_files': writer_key_files}, self.reasoning_trace
        ).get('key_files', [])
        numeric_check = None
        if paper_mode:
            # Any explicit-paper analysis gets the deterministic reliability
            # assembly, not only hard PDF-only requests: exactly one canonical
            # parser-status report with real counts, and numeric claims that
            # cannot be found in the extracted text are flagged instead of
            # being silently asserted as verified facts.
            if strict_pdf_request:
                # Prefer the source captured immediately after Planner's own
                # prefetch; it is independent of the InformationSeeker completion
                # schema and is the audit source for counts.
                canonical_sources = filter_to_pdf_parse_sources(prefetched_key_files)
                completion_sources = canonical_sources or filter_to_pdf_parse_sources(completion_sources)
            canonical_report = build_pdf_parser_status_report(completion_sources)
            evidence_ledger = build_pdf_evidence_ledger(completion_sources)
            if canonical_report:
                # WriterAgent may already have prepended a parser-status block
                # built from compacted key_files that lack layout metadata (P1-2:
                # all-zero placeholders). Strip every legacy block so the final
                # answer contains exactly one canonical report with real counts.
                final_answer = re.sub(
                    r'(?m)^##\s*PDF\s*\u89e3\u6790\u72b6\u6001\u62a5\u544a\uff08\u89e3\u6790\u5668\u5b9e\u6d4b\uff09[^\n]*(?:\n- [^\n]*)*\n?',
                    '',
                    final_answer,
                )
                final_answer = re.sub(r'\n{3,}', '\n\n', final_answer).strip()
            if not is_pdf_layout_boundary_test_request(user_query):
                # P1-1: deterministically flag precise numeric claims that the
                # Writer emitted but that do not appear in the parser-extracted
                # text. The notice tells the user to verify against the original
                # PDF instead of treating the value as verified fact.
                numeric_check = verify_answer_numeric_claims(final_answer, completion_sources)
                numeric_notice = build_numeric_unverified_notice(numeric_check)
                if numeric_notice:
                    final_answer = f"{final_answer}\n\n{numeric_notice}".strip()
            if canonical_report:
                final_answer = f"{canonical_report}\n\n{final_answer}".strip()
            if evidence_ledger and 'PDF EVIDENCE LEDGER' not in final_answer:
                final_answer = f"{final_answer}\n\n{evidence_ledger}".strip()
            # Explicit boundary tests are safety evaluations, not an invitation
            # for free-form Writer prose to repair low-confidence formulas/tables.
            # Replace it with a deterministic evidence-use verdict after Writer has
            # run, ensuring the final user-visible result cannot contain invented
            # table cells, exact values, rankings, or figure topology.
            if strict_pdf_request and is_pdf_layout_boundary_test_request(user_query):
                boundary_report = build_pdf_layout_boundary_test_report(completion_sources)
                if boundary_report:
                    final_answer = f"{canonical_report}\n\n{boundary_report}".strip() if canonical_report else boundary_report

            failure_notice = build_pdf_partial_failure_notice(completion_sources)
            if failure_notice and '## \u90e8\u5206\u89e3\u6790\u5931\u8d25\u8bf4\u660e' not in final_answer:
                final_answer = f"{final_answer}\n\n{failure_notice}".strip()
            if degrade_notice and '## \u9884\u53d6\u5931\u8d25\u8bf4\u660e' not in final_answer:
                final_answer = f"{final_answer}\n\n{degrade_notice}".strip()
            # Verify against the exact source list the Writer saw (its [n]
            # numbering), not the re-attached parse-only list (P1-3).
            citation_check = verify_writer_citations(final_answer, writer_key_files)
            citation_report = build_citation_check_report(citation_check)
            if citation_report and '## \u5f15\u7528\u6838\u9a8c' not in final_answer:
                final_answer = f"{final_answer}\n\n{citation_report}".strip()
            # P2-5: downstream parsers should see one canonical reference heading.
            # P2-8: numbered section headings should use one canonical dot notation.
            final_answer = normalize_section_numbering(normalize_reference_heading(final_answer))
        else:
            citation_check = None
        completion_status = "partial" if (
            (citation_check or {}).get("status") == "unverified"
            or (numeric_check or {}).get("status") == "unverified"
        ) else "completed"

        completion = {
            "task_summary": "Completed through PlannerAgent, InformationSeekerAgent, and WriterAgent.",
            "task_name": "stable_multi_agent_writing",
            "key_files": completion_sources,
            "completion_status": completion_status,
            "citation_check": citation_check,
            "numeric_check": numeric_check,
            "route": "paper_evidence" if paper_mode else "planner_research",
            "evidence_mode": paper_evidence_mode or "research",
            "parser_cache_hits": sum(
                1 for source in completion_sources
                if isinstance(source, dict) and source.get("cache_hit") is True
            ),
            "agent_chain": [
                "PlannerAgent",
                "SubjectiveInformationSeekerAgent",
                "WriterAgent",
            ],
            "agent_outputs": [
                {
                    "agent_name": task_result.get("agent_name", "InformationSeekerAgent"),
                    "success": task_result.get("success", False),
                    "task_content": task_result.get("task_content", "")[:200],
                    "execution_time": task_result.get("execution_time", 0),
                }
                for task_result in task_results
            ],
            "final_answer": final_answer,
        }
        self.log_action(3, "planner_subjective_task_done", completion, completion)
        return {
            "success": True,
            "data": completion,
            "reasoning_trace": self.reasoning_trace,
            "iterations": 3,
            "execution_time": time.time() - start_time,
        }

    def _build_agent_specific_tool_schemas(self) -> List[Dict[str, Any]]:
        """
        Build tool schemas for PlannerAgent using proper MCP architecture.
        Schemas come from MCP server via client, not direct imports.
        """

        # Get MCP tool schemas from server via client (proper MCP architecture)
        schemas = super()._build_agent_specific_tool_schemas()

        # Add schemas for built-in task assignment tools
        planner_mode_builtin_tools_map = {
            "auto": ["think", "reflect", "assign_multi_subjective_tasks_to_info_seeker", "assign_multi_objective_tasks_to_info_seeker", "assign_subjective_task_to_writer", "writer_subjective_task_done", "planner_subjective_task_done", "planner_objective_task_done"],
            "writing": ["think", "reflect", "assign_multi_subjective_tasks_to_info_seeker", "assign_subjective_task_to_writer", "writer_subjective_task_done", "planner_subjective_task_done"],
            "qa": ["think", "reflect", "assign_multi_objective_tasks_to_info_seeker", "planner_objective_task_done"],
        }
        builtin_assignment_schemas = [
            {
                "type": "function",
                "function": {
                    "name": "think",
                    "description": "Use the tool to think about something. It will not obtain new information or make any changes to the repository, but just log the thought. Use it when complex reasoning or brainstorming is needed.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "thought": {
                                "type": "string",
                                "description": "Your thoughts."
                            }
                        },
                        "required": ["thought"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "reflect",
                    "description": "When multiple attempts yield no progress, use this tool to reflect on previous reasoning and planning, considering possible overlooked clues and exploring more possibilities. It will not obtain new information or make any changes to the repository.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "reflect": {
                                "type": "string",
                                "description": "The specific content of your reflection"
                            }
                        },
                        "required": ["reflect"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "assign_multi_subjective_tasks_to_info_seeker",
                    "description": "Assign 1~6 research or information gathering tasks to different InformationSeekerAgents for parallel execution, each task descriptions must be semantically complete and clearly provide contextual information and potentially important reference documents.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "tasks": {
                                "type": "array",
                                "description": "List of tasks to be assigned to multiple InformationSeekerAgents",
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "task_content": {
                                            "type": "string",
                                            "description": "Detailed description of the task to be performed"
                                        },
                                        "task_steps_for_reference": {
                                            "type": "string",
                                            "description": "Optional reference steps for task execution"
                                        },
                                        "deliverable_contents": {
                                            "type": "string",
                                            "description": "Expected format and content of deliverables"
                                        },
                                        "current_task_status": {
                                            "type": "string",
                                            "description": "Current status and context of the task, important documents that may be used and referenced"
                                        },
                                        "acceptance_checking_criteria": {
                                            "type": "string",
                                            "description": "Criteria for determining task completion and quality"
                                        },
                                    },
                                    "required": ["task_content"]
                                }
                            }
                        },
                        "required": ["tasks"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "assign_multi_objective_tasks_to_info_seeker",
                    "description": "Assign 1~5 research or information gathering tasks to different InformationSeekerAgents for parallel execution, each task descriptions must be semantically complete and clearly provide contextual information and potentially important reference documents.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "tasks": {
                                "type": "array",
                                "description": "List of tasks to be assigned to multiple InformationSeekerAgents",
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "task_content": {
                                            "type": "string",
                                            "description": "Detailed description of the task to be performed, the task description must be semantically complete"
                                        },
                                        "task_steps_for_reference": {
                                            "type": "string",
                                            "description": "Optional reference steps for task execution"
                                        },
                                        "deliverable_contents": {
                                            "type": "string",
                                            "description": "Expected format and content of deliverables"
                                        },
                                        "current_task_status": {
                                            "type": "string",
                                            "description": "Current status and context of the task, important documents that may be used and referenced"
                                        },
                                        "acceptance_checking_criteria": {
                                            "type": "string",
                                            "description": "Criteria for determining task completion and quality, and the requirements in the event of task completion failure"
                                        },
                                    },
                                    "required": ["task_content"]
                                }
                            }
                        },
                        "required": ["tasks"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "assign_subjective_task_to_writer",
                    "description": "Assign a writing or content creation task to the WriterAgent",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "user_query": {
                                "type": "string",
                                "description": "Pass in the original user question."
                            },
                            "task_content": {
                                "type": "string",
                                "description": "Integrate and synthesize provided materials to generate comprehensive long-form content exceeding 10,000 words, especially careful not to give specific details, such as an outline plan, you are only providing the writer with a general description of the task."
                            },
                            "key_files": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "file_path": {
                                            "type": "string",
                                            "description": "Relative path to the file containing research content"
                                        }
                                    },
                                    "required": ["file_path"]
                                },
                                "description": "Collect all key_files returned by the information seeker for long-form content creation."
                            }
                        },
                        "required": ["user_query", "task_content", "key_files"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "writer_subjective_task_done",
                    "description": "Writer Agent task completion reporting for complete long-form content. Called after all chapters/sections are written to provide a summary of the complete long article, final completion status and analysis, and the storage path of the final consolidated article.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "final_article_path": {
                                "type": "string",
                                "description": "The file path where the final article is saved."
                            },
                            "article_summary": {
                                "type": "string",
                                "description": "Comprehensive summary of the complete long-form article, including main themes, key points covered, and overall narrative structure.",
                                "format": "markdown"
                            },
                            "completion_status": {
                                "type": "string",
                                "enum": ["completed", "partial", "failed"],
                                "description": "Final status of the complete long-form writing task"
                            },
                            "completion_analysis": {
                                "type": "string",
                                "description": "Analysis of the overall writing project completion including: assessment of article coherence and quality, evaluation of content organization and flow, identification of any challenges in the writing process, and overall evaluation of the long-form content creation success."
                            }
                        },
                        "required": ["final_article_path", "article_summary", "completion_status", "completion_analysis"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "planner_subjective_task_done",
                    "description": "When the writer agent is executed, the task done tool is called to end the planner's task.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "final_article_path": {
                                "type": "string",
                                "description": "The file path where the final article is saved."
                            },
                            "task_summary": {
                                "type": "string",
                                "description": "This field is mainly used to describe the main content of the article in a detailed way, summarize the main arguments and evidence, and finally indicate the path where the final article is saved.",
                                "format": "markdown"
                            },
                            "task_name": {
                                "type": "string",
                                "description": "The name of the task currently assigned to the agent, usually with underscores (e.g., 'web_research_ai_trends')"
                            },
                            "completion_status": {
                                "type": "string",
                                "enum": ["completed", "partial", "failed"],
                                "description": "Final task status"
                            }
                        },
                        "required": ["final_article_path", "task_summary", "task_name", "completion_status"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "planner_objective_task_done",
                    "description": "Structured reporting of task completion details including summary, decisions, and final answer",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "task_summary": {
                                "type": "string",
                                "description": "Comprehensive markdown covering what the agent was asked to do, steps taken, tools used, key findings, files created, challenges",
                                "format": "markdown"
                            },
                            "task_name": {
                                "type": "string",
                                "description": "The name of the task currently assigned to the agent, usually with underscores (e.g., 'web_research_ai_trends')"
                            },
                            "key_files": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "file_path": {
                                            "type": "string",
                                            "description": "Relative path to created/modified file"
                                        },
                                        "desc": {
                                            "type": "string",
                                            "description": "File contents and creation purpose"
                                        },
                                        "is_final_output_file": {
                                            "type": "boolean",
                                            "description": "Whether file is primary deliverable"
                                        }
                                    },
                                    "required": ["file_path", "desc", "is_final_output_file"]
                                },
                                "description": "List of key files generated or modified during the task, with their details."
                            },
                            "completion_status": {
                                "type": "string",
                                "enum": ["completed", "partial", "failed"],
                                "description": "Final task status"
                            },
                            "final_answer": {
                                "type": "string",
                                "description": "The final response displayed to the user",
                            }
                        },
                        "required": ["task_summary", "task_name", "key_files", "completion_status", "final_answer"]
                    }
                }
            },
        ]

        used_builtin_schemas = [schema for schema in builtin_assignment_schemas if schema["function"]["name"] in planner_mode_builtin_tools_map[self.config.planner_mode]]
        schemas.extend(used_builtin_schemas)

        return schemas

    def set_cancellation_token(self, cancellation_token):
        """
        Set the cancellation token for this agent
        设置此代理的取消令牌

        Args:
            cancellation_token: threading.Event object that will be set when task should be cancelled
        """
        self._cancellation_token = cancellation_token

    def _check_cancellation(self) -> bool:
        """
        Check if task has been cancelled
        检查任务是否已被取消

        Returns:
            True if task should be cancelled, False otherwise
        """
        if self._cancellation_token and self._cancellation_token.is_set():
            self.logger.info(f"Task {self.task_id} cancellation detected")
            return True
        return False

    def _execute_react_loop(self, initial_message: str, max_iterations: int = 20) -> Dict[str, Any]:
        """
        Execute the ReAct loop for planning tasks

        Args:
            initial_message: Initial message to start the planning process
            max_iterations: Maximum number of iterations to perform

        Returns:
            Dictionary with execution results and trace
        """
        start_time = time.time()
        try:
            # Reset trace for new task
            self.reset_trace()
            # Initialize conversation history
            conversation_history = []

            # Build system prompt for planning
            system_prompt = self._build_system_prompt()
            # Add to conversation
            conversation_history.append({"role": "system", "content": system_prompt})
            conversation_history.append({"role": "user", "content": initial_message + " /no_think"})

            iteration = 0
            task_completed = False
            fallback_completion = None

            # Get model endpoint configuration from env-backed config
            from config.config import get_config
            config = get_config()
            model_config = config.get_custom_llm_config()
            
            pangu_url = model_config.get('url') or os.getenv('MODEL_REQUEST_URL', '')
            model_token = model_config.get('token') or os.getenv('MODEL_REQUEST_TOKEN', '')
            headers = {'Content-Type': 'application/json', 'csb-token': model_token}
            if model_token:
                headers['Authorization'] = f'Bearer {model_token}'
            # ReAct Loop: Reasoning -> Acting -> Reasoning -> Acting...
            while iteration < self.config.max_iterations and not task_completed:
                iteration += 1
                self.logger.info(f"Planning iteration {iteration}")

                try:
                    # Get LLM response (reasoning + potential tool calls)
                    retry_num = 1
                    max_retry_num = 10
                    while retry_num < max_retry_num:
                        try:
                            response = requests.post(
                                url=pangu_url,
                                headers=headers,
                                json={
                                    "model": self.config.model,
                                    #"chat_template": "{% for message in messages %}{% if loop.first and messages[0]['role'] != 'system' %}{{ '<s>[unused9]系统：[unused10]' }}{% endif %}{% if message['role'] == 'system' %}{{'<s>[unused9]系统：' + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'assistant' %}{{'[unused9]助手：' + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'tool' %}{{'[unused9]工具：' + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'function' %}{{'[unused9]方法：' + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'user' %}{{'[unused9]用户：' + message['content'] + '[unused10]'}}{% endif %}{% endfor %}{% if add_generation_prompt %}{{ '[unused9]助手：' }}{% endif %}",
                                    #"spaces_between_special_tokens": False,
                                    "messages": conversation_history,
                                    "temperature": self.config.temperature,
                                    "max_tokens": self.config.max_tokens,
                                },
                                timeout=model_config.get("timeout", 180)
                            )
                            response = response.json()
                            if isinstance(response, str):
                                response = json.loads(response)
                            if not isinstance(response, dict) or "choices" not in response:
                                raise ValueError(f"Model response missing choices: {str(response)[:1000]}")
                            self.logger.debug(f"API response received")
                            break
                        except Exception as e:
                            time.sleep(3)
                            retry_num += 1
                            if retry_num == max_retry_num:
                                raise ValueError(str(e))
                            continue
                    choices = response.get("choices") or []
                    if not choices:
                        raise ValueError(f"Model response has empty choices: {str(response)[:1000]}")
                    assistant_message = choices[0].get("message", {})
                    if not isinstance(assistant_message, dict):
                        raise ValueError(f"Model message has invalid format: {str(assistant_message)[:1000]}")
                    assistant_content = assistant_message.get("content") or ""

                    # Log the reasoning
                    try:
                        if assistant_content:
                            reasoning_content = assistant_content.split("[unused16]")[-1].split("[unused17]")[0]
                            if len(reasoning_content) > 0:
                                self.log_reasoning(iteration, reasoning_content)
                    except Exception as e:
                        self.logger.warning(f"Tool call parsing error: {e}")
                        # Parse error, rerun
                        followup_prompt = f"There is a problem with the format of model generation: {e}. Please try again."
                        conversation_history.append({"role": "user", "content": followup_prompt + " /no_think"})
                        continue

                    def extract_tool_calls(content):
                        import re
                        if not content:
                            return []
                        tool_call_str = re.findall(r"\[unused11\]([\s\S]*?)\[unused12\]", content)
                        if len(tool_call_str) > 0:
                            try:
                                tool_calls = json.loads(tool_call_str[0].strip())
                            except:
                                return []
                        else:
                            return []
                        if isinstance(tool_calls, dict):
                            tool_calls = [tool_calls]
                        if not isinstance(tool_calls, list):
                            return []
                        normalized_calls = []
                        for call in tool_calls:
                            if not isinstance(call, dict):
                                continue
                            arguments = call.get("arguments", {})
                            if isinstance(arguments, str):
                                try:
                                    arguments = json.loads(arguments)
                                except Exception:
                                    arguments = {"value": arguments}
                            call["arguments"] = arguments
                            normalized_calls.append(call)
                        tool_calls = normalized_calls
                        return tool_calls

                    # Add assistant message to conversation
                    conversation_history.append({
                        "role": "assistant",
                        "content": assistant_content
                    })

                    tool_calls = extract_tool_calls(assistant_content)

                    # Execute tool calls if any (Acting phase)

                    for tool_call in tool_calls:
                        arguments = tool_call["arguments"]
                        self.logger.debug(f"Arguments is string: {isinstance(arguments, str)}")

                        # Check if planning is complete
                        if tool_call["name"] in ["planner_subjective_task_done", "planner_objective_task_done", "writer_subjective_task_done"]:
                            task_completed = True
                            self.log_action(iteration, tool_call["name"], arguments, arguments)
                            break
                        if tool_call["name"] in ["think", "reflect"]:
                            tool_result = {"tool_results": "You can proceed to invoke other tools if needed. "}
                        else:
                            tool_result = self.execute_tool_call(tool_call)

                        # Log the action using base class method
                        self.log_action(iteration, tool_call["name"], arguments, tool_result)

                        # Add tool result to conversation
                        conversation_history.append({
                            "role": "tool",
                            "content": json.dumps(tool_result, ensure_ascii=False, indent=2) + " /no_think"
                        })

                    # If no tool calls, encourage continued planning
                    if len(tool_calls) == 0:
                        if assistant_content.strip():
                            fallback_completion = {
                                "task_summary": "The model returned a direct natural-language answer without a tool-call envelope.",
                                "task_name": "direct_answer",
                                "key_files": [],
                                "completion_status": "completed",
                                "final_answer": assistant_content.strip()
                            }
                            task_completed = True
                            self.log_action(
                                iteration,
                                "planner_objective_task_done",
                                fallback_completion,
                                fallback_completion
                            )
                            break
                        # Add follow-up prompt to encourage action or completion
                        followup_prompt = (
                            "Continue your planning process. Use available tools to assign tasks to agents, "
                            "search for information, or coordinate work. When you have a complete answer, "
                            "call planner_subjective_task_done or planner_objective_task_done. /no_think"
                        )
                        conversation_history.append({"role": "user", "content": followup_prompt})

                except Exception as e:
                    error_msg = f"Error in planning iteration {iteration}: {e}"
                    self.logger.exception(error_msg)
                    self.log_error(iteration, error_msg)
                    break

            execution_time = time.time() - start_time

            # Extract final result
            if task_completed:
                # Find the completion result in the trace
                completion_result = fallback_completion
                for step in reversed(self.reasoning_trace):
                    if step.get("type") == "action" and step.get("tool") in ["planner_subjective_task_done",
                                                                             "planner_objective_task_done"]:
                        completion_result = step.get("result")
                        break

                return {
                    "success": True,
                    "data": completion_result,
                    "reasoning_trace": self.reasoning_trace,
                    "iterations": iteration,
                    "execution_time": execution_time
                }
            else:
                return {
                    "success": False,
                    "error": f"Planning task not completed within {max_iterations} iterations",
                    "reasoning_trace": self.reasoning_trace,
                    "iterations": iteration,
                    "execution_time": execution_time
                }
        except Exception as e:
            execution_time = time.time() - start_time if 'start_time' in locals() else 0
            self.logger.error(f"Error in execute_react_loop: {e}")
            return {
                "success": False,
                "error": str(e),
                "reasoning_trace": self.reasoning_trace,
                "iterations": iteration if 'iteration' in locals() else 0,
                "execution_time": execution_time
            }


    def execute_task(self, user_query: str) -> AgentResponse:
        """
        Execute a planning task for the given user query

        Args:
            user_query: The user's query or request

        Returns:
            AgentResponse with planning results and process trace
        """
        start_time = time.time()

        try:
            self.logger.info(f"Starting planner task: {user_query}")

            if os.getenv("PLANNER_STABLE_CHAIN", "true").lower() == "true":
                result = self._execute_stable_writing_chain(user_query, start_time)
                return AgentResponse(
                    success=result.get("success", False),
                    result=result.get("data"),
                    error=result.get("error"),
                    reasoning_trace=result.get("reasoning_trace", []),
                    iterations=result.get("iterations", 0),
                    execution_time=time.time() - start_time,
                    agent_name=self.config.agent_name
                )

            # Execute the planning task using ReAct pattern
            result = self._execute_react_loop(
                initial_message=user_query,
                max_iterations=self.config.max_iterations  # Reasonable limit for planning tasks
            )

            execution_time = time.time() - start_time

            return AgentResponse(
                success=result.get("success", False),
                result=result.get("data"),
                error=result.get("error"),
                reasoning_trace=result.get("reasoning_trace", []),
                iterations=result.get("iterations", 0),
                execution_time=execution_time,
                agent_name=self.config.agent_name
            )

        except Exception as e:
            execution_time = time.time() - start_time
            self.logger.error(f"Planner execution failed: {e}")

            return AgentResponse(
                success=False,
                error=f"Planner execution failed: {str(e)}",
                reasoning_trace=[],
                iterations=0,
                execution_time=execution_time,
                agent_name=self.config.agent_name
            )


def create_planner_agent(
        model: Any = None,
        sub_agent_configs: Dict[str, Dict[str, Any]] = None,
        shared_mcp_client=None,
        **kwargs
) -> PlannerAgent:
    """
    Create a PlannerAgent instance with server-managed sessions.
    
    Args:
        model: The LLM model to use
        sub_agent_configs: Configuration for sub-agents (information_seeker, writer)
        shared_mcp_client: Optional shared MCP client to prevent duplicate connections
        **kwargs: Additional configuration options
        
    Returns:
        Configured PlannerAgent instance
    """
    # Import the enhanced config function
    from .base_agent import create_agent_config

    # Handle agent_name if provided in kwargs
    agent_name = kwargs.pop("agent_name", "PlannerAgent")
    
    # Handle task_id if provided in kwargs
    task_id = kwargs.pop("task_id", None)

    # Create agent configuration (session managed by MCP server)
    config = create_agent_config(
        agent_name=agent_name,
        model=model,
        **kwargs
    )

    # Create planner agent with optional shared MCP client
    planner = PlannerAgent(config=config, shared_mcp_client=shared_mcp_client, task_id=task_id)

    # Store sub-agent configurations for use when creating sub-agents
    planner.sub_agent_configs = sub_agent_configs or {
        "information_seeker": {},
        "writer": {}
    }

    return planner
