﻿# Copyright (c) 2025 Huawei Technologies Co., Ltd. All rights reserved.
# Copyright (c) 2026 South China Sea Institute of Oceanology, Chinese Academy of Sciences (SCSIO, CAS). All rights reserved.
import json
from typing import Dict, Any, List
import time
import requests
import os
from .base_agent import BaseAgent, AgentConfig, AgentResponse, WriterAgentTaskInput
from ..pdf_reliability import (
    build_pdf_partial_failure_notice,
    build_pdf_reliability_guidance,
    build_pdf_parser_facts,
    build_pdf_parser_status_report,
    build_long_document_page_requirement,
    is_strict_pdf_evidence_request,
)



class WriterAgent(BaseAgent):
    """
    Writer Agent that follows ReAct pattern for content synthesis and generation
    
    This agent takes writing tasks from parent agents, searches through existing
    files and knowledge base, and creates long-form content through iterative
    reasoning and refinement. It does NOT access internet resources, only
    local files and memories.
    """

    def __init__(self, config: AgentConfig = None, shared_mcp_client=None):
        # Set default agent name if not specified
        if config is None:
            config = AgentConfig(agent_name="WriterAgent")
        elif config.agent_name == "base_agent":
            config.agent_name = "WriterAgent"

        super().__init__(config, shared_mcp_client)

        # Rebuild tool schemas with writer-specific tools only
        self.tool_schemas = self._build_tool_schemas()
        # Cancellation support
        self._cancellation_token = None

    def set_cancellation_token(self, cancellation_token):
        """
        Set the cancellation token for this agent
        璁剧疆姝や唬鐞嗙殑鍙栨秷浠ょ墝

        Args:
            cancellation_token: threading.Event object that will be set when task should be cancelled
        """
        self._cancellation_token = cancellation_token

    def _check_cancellation(self) -> bool:
        """
        Check if task has been cancelled
        妫€鏌ヤ换鍔℃槸鍚﹀凡琚彇娑?
        Returns:
            True if task should be cancelled, False otherwise
        """
        if self._cancellation_token and self._cancellation_token.is_set():
            self.logger.info("WriterAgent task cancellation detected")
            return True
        return False

    def _build_agent_specific_tool_schemas(self) -> List[Dict[str, Any]]:
        """
        Build tool schemas for WriterAgent using proper MCP architecture.
        Schemas come from MCP server via client, not direct imports.
        """
        # Get MCP tool schemas from server via client (proper MCP architecture)
        schemas = super()._build_agent_specific_tool_schemas()

        # Add schemas for built-in task assignment tools
        builtin_assignment_schemas = [
            {
                "type": "function",
                "function": {
                    "name": "think",
                    "description": "Use the tool to think about something. It will not obtain new information or make any changes to the repository, but just log the thought. Use it when complex reasoning or brainstorming is needed.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "thought": {
                                "type": "string",
                                "description": "Your thoughts."
                            }
                        },
                        "required": ["thought"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "reflect",
                    "description": "When multiple attempts yield no progress, use this tool to reflect on previous reasoning and planning, considering possible overlooked clues and exploring more possibilities. It will not obtain new information or make any changes to the repository.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "reflect": {
                                "type": "string",
                                "description": "The specific content of your reflection"
                            }
                        },
                        "required": ["reflect"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "writer_subjective_task_done",
                    "description": "Writer Agent task completion reporting for complete long-form content. Called after all chapters/sections are written to provide a summary of the complete long article, final completion status and analysis, and the storage path of the final consolidated article.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "final_article_path": {
                                "type": "string",
                                "description": "The file path where the final article is saved."
                            },
                            "article_summary": {
                                "type": "string",
                                "description": "Comprehensive summary of the complete long-form article, including main themes, key points covered, and overall narrative structure.",
                                "format": "markdown"
                            },
                            "completion_status": {
                                "type": "string",
                                "enum": ["completed", "partial", "failed"],
                                "description": "Final status of the complete long-form writing task"
                            },
                            "completion_analysis": {
                                "type": "string",
                                "description": "Analysis of the overall writing project completion including: assessment of article coherence and quality, evaluation of content organization and flow, identification of any challenges in the writing process, and overall evaluation of the long-form content creation success."
                            }
                        },
                        "required": ["final_article_path", "article_summary", "completion_status",
                                     "completion_analysis"]
                    }
                }
            },
        ]

        schemas.extend(builtin_assignment_schemas)

        return schemas

    def _build_system_prompt(self) -> str:
        """Build the system prompt for the writer agent"""
        tool_schemas_str = json.dumps(self.tool_schemas, ensure_ascii=False)
        system_prompt_template = """You are a professional writing master. You will receive key files and user problems. Your task is to generate an outline highly consistent with the user problem, classify files into sections, and iteratively call section_writer tool to create comprehensive content. Then you strictly follow the steps given below:
        
        MANDATORY WORKFLOW:
        
        1. OUTLINE GENERATION
        Based on the core content of the provided key files collection(file_core_content), generate a high-quality outline suitable for long-form writing. Strictly adhere to the following requirements during generation:  
        - Before generating the outline, carefully review the provided **file_core_content**, prioritizing sections with:  
            1.**Higher authority** (credible sources)
            2.**Greater information richness** (substantive, detailed content)
            3.**Stronger relevance** (direct alignment with user query)
            4.**Timeliness** (if user鈥檚 query is time-sensitive, prioritize recent/updated content)
        Select these segments as the basis for outline generation. Note that we only focus on relevance to the question, so when generating the outline, do not add unrelated sections just for the sake of length. Additionally, the sections should flow logically and not be too disjointed, as this would harm the readability of the final output.  
        - The overall structure must be **logically clear**, with **no repetition or redundancy** between chapters.  
        - **Note1:** The generated outline must not only have chapter-level headings (Level 1) highly relevant to the user鈥檚 question, but the subheadings (Level 2) must also be highly relevant to the user鈥檚 question. It is not permitted to generate chapter titles with weak relevance, whether Level 1 or Level 2.
        - **Note2:** The number of chapters must not exceed 7, dynamic evaluation can be performed based on the collected content. For example, if there is a lot of content, more chapters can be generated, and vice versa. But each chapter should only include Level 1 and Level 2 headings. Also, be careful not to generate too many Level 2 headings, limit them to 4. However, if the first chapter is an abstract or introduction, do not generate subheadings (level-2 headings)鈥攐nly include the main heading (level-1). Additionally, tailor the outline style based on the type of document. For example, in a research report, the first chapter should preferably be titled \"Abstract\" or \"Introduction.\"  
        
        2. FILE CLASSIFICATION  
        - Use the search_result_classifier tool to reasonably split the outline generated above and accurately assign key files to each chapter of the outline.
        - Ensure optimal distribution of reference materials across chapters based on content relevance.
        
        3. ITERATIVE SECTION WRITING
        - Call section_writer tool sequentially for each chapter
        - CRITICAL: Must wait for previous chapter completion before starting the next chapter
        - Pass only the specific chapter outline , target file path and corresponding classified files to each section writer
        - When using extracted PDF evidence, preserve page-level evidence from `[[page=N]]` markers. Cite each PDF-backed claim as `[n] (p. N)`; never invent a page number. Keep `[n]` intact so bibliography linking continues to work.
        - Generate save path for each chapter using \"./report/part_X.md\" format (e.g., \"./report/part_1.md\" for first chapter)
        - Each chapter should be substantive rather than compressed: aim for at least 3-5 paragraphs or roughly 600-1000 Chinese characters unless the source material is genuinely sparse.
        - Avoid skeleton-style output. Every chapter should include evidence, interpretation, and at least one concrete example or implication when available.
        - Citation discipline is mandatory: factual claims derived from provided files must carry inline citations such as [1], [2]. If a chapter has no citeable source, explicitly state that the paragraph is analytical synthesis rather than sourced evidence.
        - The final article must end with a markdown section exactly named "## References" listing the cited source numbers and available titles/URLs/paths.
        - Check section writer results after completion; retry up to 2 times per chapter if quality is insufficient based on returned fields (do not read saved files)
        - When you call the section_writer tool, pay special attention to the fact that the parameter value of written_chapters_summary is a summary of the content returned by all previously completed chapters. Be careful not to make any changes to the summary content, including compressing the content.
        
        4. TASK COMPLETION
        - After all chapters are written, you must first call the concat_section_files tool to merge the saved chapter files into one file, then call writer_subjective_task_done to finalize and return.
        
        CRITICAL REQUIREMENTS:
        - The creation of the outline is crucial! Therefore, you must strictly adhere to the above requirements for generating the outline.
        - No parallel writing - strictly sequential chapter execution
        - Wait for each section writer completion before proceeding to next chapter
        - Classify files appropriately to support each chapter's content needs
        - Note again that to merge all the written chapter files, you must use the concat_section_files tool!!! You are not allowed to call any other tools for merging!!!
        
        FORBIDDEN CONTENT PATTERNS:
        - NEVER generate meta-structural chapters that describe how the article is organized
        - AVOID introductory sections that outline \"Chapter 1 will cover..., Chapter 2 will discuss...\"
        - DO NOT create chapters that explain the report structure or methodology
        - Each chapter must contain SUBSTANTIVE CONTENT, not descriptions of what other chapters contain
        - When generating an outline, if it is not a professional term, the language should remain consistent with the user's question.\"
        
        Usage of TOOLS:
        - search_result_classifier: Classify key files into outline sections
        - section_writer: Write individual chapters sequentially  
        - writer_subjective_task_done: Complete the writing task
        - concat_section_files: Concatenate the content of the saved section files into a single file
        - think tool: \"Think\" is a systematic tool requiring its use during key steps. Before executing actions like generating an outline, you must first call this tool to deeply consider the given content and key requirements, ensuring the output meets specifications. Similarly, during iterative chapter generation, after receiving feedback and before writing the next chapter, call \"think\" to reflect on the current chapter. This provides guidance to avoid content repetition and ensure smooth transitions between chapters.
        
        Execute workflow systematically to produce high-quality, coherent long-form content with substantive chapters.

Below, within the <tools></tools> tags, are the descriptions of each tool and the required fields for invocation:
<tools>
$tool_schemas
</tools>
For each function call, return a JSON object placed within the [unused11][unused12] tags, which includes the function name and the corresponding function arguments:
[unused11][{\"name\": <function name>, \"arguments\": <args json object>}][unused12]
"""
        return system_prompt_template.replace("$tool_schemas", tool_schemas_str)

    def _build_initial_message_from_task_input(self, task_input: WriterAgentTaskInput) -> str:
        """Build the initial user message from TaskInput"""
        message = ""

        # Add key files information with reliability dimensions
        def load_json_from_server(file_path):
            """Load JSONL file from MCP server using unlimited internal tool"""
            res = []
            try:
                # Use json read tool directly through raw MCP client
                raw_result = self.mcp_tools.client.call_tool("load_json", {"file_path": file_path})
                
                if not raw_result.success:
                    self.logger.error(f"Failed to read file from server: {raw_result.error}")
                    return res
                
                res = json.loads(raw_result.data["content"][0]["text"])["data"]
                                            
            except Exception as e:
                self.logger.error(f"Error loading file {file_path} from MCP server: {e}")
                import traceback
                self.logger.debug(f"Full traceback: {traceback.format_exc()}")
                
            return res

        key_files_dict = {}

        server_analysis_path = f"doc_analysis/file_analysis.jsonl"
        self.logger.debug(f"Loading analysis from MCP server: {server_analysis_path}")
        file_analysis_list = load_json_from_server(server_analysis_path)

        for file_info in file_analysis_list:
            if file_info.get('file_path'):
                key_files_dict[file_info.get('file_path')] = file_info

        file_core_content = ""
        if hasattr(task_input, 'key_files') and task_input.key_files:
            message += "Key Files:\n"
            for i, file_ in enumerate(task_input.key_files, 1):
                file_path = file_.get('file_path')
                if file_path in key_files_dict:
                    file_info = key_files_dict[file_path]
                    doc_time = file_info.get('doc_time', 'Not specified')
                    source_authority = file_info.get('source_authority', 'Not assessed')
                    task_relevance = file_info.get('task_relevance', 'Not assessed')
                    information_richness = file_info.get('information_richness', 'Not assessed')
                    message += f"{i}. File: {file_path}\n"

                    file_core_content += f"[{str(i)}]doc_time:{doc_time}|||source_authority:{source_authority}|||task_relevance:{task_relevance}|||information_richness:{information_richness}|||summary_content:{file_info.get('core_content', '')}\n"
            message += "\n"
            message += f"file_core_content: {file_core_content}\n"
        else:
            message += "Key Files: None provided\n"

        message += "\n"
        # Add user query
        if hasattr(task_input, 'user_query') and task_input.user_query:
            message += f"User Query: {task_input.user_query}\n"
        else:
            message += "User Query: Not provided\n"

        return message

    def execute_task(self, task_input: WriterAgentTaskInput) -> AgentResponse:
        """
        Execute a writing task using ReAct pattern

        Args:
            task_input: TaskInput object with standardized task information

        Returns:
            AgentResponse with writing results and process trace
        """
        if os.getenv("AGENT_STABLE_MODE", "true").lower() == "true":
            pdf_reliability_guidance = build_pdf_reliability_guidance(task_input.key_files)
            strict_pdf_request = is_strict_pdf_evidence_request(task_input.user_query)
            pdf_parser_facts = build_pdf_parser_facts(task_input.key_files)
            stable_writer_prompt = (
                "You are WriterAgent, a research writing assistant. "
                "Use the original user query and the collected InformationSeeker materials in the prompt. "
                "Write the final answer directly, with clear structure and expanded content. "
                "The answer should be noticeably longer than a short summary: use several substantive paragraphs and cover background, evidence, interpretation, limitations, and next steps. "
                "Prefer a full research-note style answer rather than a brief digest. "
                + (("\nPAPER ANALYSIS COMPLETENESS: cover the core method, formulas, architecture, and every experiment "
                    "table present in the collected materials. If a table's cell values could not be extracted or verified, "
                    "state that explicitly instead of omitting the table. A complete paper analysis is typically 1200+ Chinese "
                    "characters; do not end early with a partial digest. ") if pdf_parser_facts else "")
                + "When collected materials are present, every factual paragraph must include inline citations in numeric form such as [1] or [2]. "
                "If PDF page markers are available, cite page-specific claims as [1] (p. 3). "
                + build_long_document_page_requirement(task_input.key_files)
                + "End the answer with a markdown section exactly named '## References' that lists the cited source numbers, titles/paths/URLs when available. "
                "If no retrieved source is available, explicitly say that the answer is unsourced background synthesis and should not be treated as a cited research note. "
                "Do not say that materials are missing when collected notes are present. "
                "Do not claim tool calls or file reads that did not happen. "
                "Use the same language as the user's request unless the user asks otherwise."
                + pdf_reliability_guidance
                + pdf_parser_facts
                + ("\nSTRUCTURED PDF EVIDENCE RULES: logical tables are heuristic reconstructions; only tables flagged "
                   "cell_structure_verified have column alignment confirmed from PDF coordinates, but exact cell citation additionally requires cell_quote_allowed=true; all others must be treated as "
                   "row-lists whose cell boundaries are NOT verified. A table with a cell_matrix provides its verified rows as "
                   "row-major cell lists: you may quote those cells individually and refer to their row/column positions; a table "
                   "without cell_matrix or with cell_quote_allowed=false must never be quoted cell-by-cell. Cite table captions, page spans (e.g. [1] (p. 11-12) "
                   "for a cross-page table), and values that appear in the provided structured table previews or in the extracted "
                   "text you actually read; never invent cells, rankings, or method comparisons. Tables flagged ocr_cross_checked "
                   "were cross-checked against OCR of the rendered region; tables flagged ocr_discrepancy failed that cross-check "
                   "and their cells must not be quoted as verified. Formulas flagged strong carry a best-effort latex_guess; "
                   "formulas flagged low-confidence are raw fragments and must not be quoted as verified equations. If formula "
                   "symbols or table cells are garbled or missing, say so explicitly instead of reconstructing them. "
                   "For cross-page tables, preserve the parser-provided page span and continuation group; treat all cross-page cells as non-quotable unless the parser explicitly sets cell_quote_allowed=true; mention repeated headers only when header_repeated=true. "
                   "For two-column pages, treat reading_order_low_confidence_pages as non-adjacent evidence: summarize claims but do not assert paragraph-to-paragraph adjacency or cross-column ordering. "
                    "For figures, figure_kind and extracted_label_block_count describe parser observations only; topology_verified=0 means nodes, arrows, module connections, and visual comparisons must not be stated as confirmed. "
                   "Organize PDF findings into three explicit evidence tiers when relevant: (A) VERIFIED: quote only cell_matrix table cells, strong formulas, and page-supported text; (B) SUMMARY-ONLY: describe row-level tables, low-confidence two-column ordering, and extracted labels without asserting exact cell positions or visual relationships; (C) UNVERIFIED: list blocked tables, fragment formulas, OCR discrepancies, missing symbols, and figure topology as unresolved. Put unresolved items in the visible partial-parse section and never fill them with likely values." if pdf_parser_facts else "")
                + "\nA precise numeric value (table cell, metric, formula parameter) that does not appear in the extracted local PDF text you received must not be stated as verified fact; write that it could not be verified in the parsed text instead. "
                + ("\nSTRICT PDF-ONLY MODE: Treat CANONICAL PDF PARSER FACTS as the only authority for parser counts/status. "
                   "Ignore HTML conversions, web snippets, prior research notes, and any untracked summaries as evidence. "
                   "Do not output a second parser-status report or repeat parser counts: the application prepends the "
                   "canonical deterministic report. Do not output a simulated parser report. Do not contradict the canonical facts. "
                   "Never interpret source_integrity.agent_context_truncation=false as proof that WriterAgent or an LLM "
                   "received the entire PDF text; only per-call file_read returned_char_count/truncated metadata can establish that." if strict_pdf_request else "")
            )
            disable_writer_thinking = os.getenv("WRITER_DISABLE_THINKING", "false").lower() in ("1", "true", "yes")
            response = self.stable_task_response(
                task_input,
                role_prompt=stable_writer_prompt,
                task_name="research_writing",
                disable_thinking=disable_writer_thinking,
            )
            partial_failure_notice = build_pdf_partial_failure_notice(task_input.key_files)
            if response.success and isinstance(response.result, dict):
                answer_key = 'final_answer' if response.result.get('final_answer') else 'task_summary'
                answer = str(response.result.get(answer_key) or '').rstrip()
                paper_task = bool(pdf_parser_facts) or strict_pdf_request
                short_paper_answer = paper_task and len(answer.strip()) < 1500
                if not answer.strip() or short_paper_answer:
                    # Reasoning models can burn the whole output budget before
                    # emitting content or stop early with a partial digest.
                    # Retry once before declaring failure.
                    if not answer.strip():
                        self.logger.warning("WriterAgent LLM returned an empty answer; retrying once.")
                    else:
                        self.logger.warning(
                            "WriterAgent LLM returned a short paper answer (chars=%s); retrying once with a completeness reminder.",
                            len(answer),
                        )
                    retry_prompt = stable_writer_prompt
                    if short_paper_answer:
                        retry_prompt += ("\nYour previous answer was too short and ended before covering the experimental tables. "
                                         "Produce a complete structured report: background, core method, formulas, architecture, "
                                         "and experiment table analysis. If a table's cell values cannot be verified from the "
                                         "extracted text, state that explicitly instead of omitting the table.")
                    retry_response = self.stable_task_response(
                        task_input,
                        role_prompt=retry_prompt,
                        task_name="research_writing",
                        disable_thinking=disable_writer_thinking,
                    )
                    if retry_response.success and isinstance(retry_response.result, dict):
                        response = retry_response
                        answer_key = 'final_answer' if retry_response.result.get('final_answer') else 'task_summary'
                        answer = str(retry_response.result.get(answer_key) or '').rstrip()
                if not answer.strip():
                    return self.create_response(
                        success=False,
                        error="WriterAgent returned an empty answer after retry; the report body was not generated.",
                        iterations=1,
                    )
                self.logger.info("WriterAgent answer chars: %s", len(answer))
                # Parser status fields are deterministic facts, not an LLM synthesis task.
                if strict_pdf_request:
                    status_report = build_pdf_parser_status_report(task_input.key_files)
                    if status_report and '## PDF \u89e3\u6790\u72b6\u6001\u62a5\u544a\uff08\u89e3\u6790\u5668\u5b9e\u6d4b\uff09' not in answer:
                        answer = f'{status_report}\n\n{answer}'.strip()
                if partial_failure_notice and '## \u90e8\u5206\u89e3\u6790\u5931\u8d25\u8bf4\u660e' not in answer:
                    answer = f'{answer}\n\n{partial_failure_notice}'.strip()
                response.result[answer_key] = answer
            return response


        start_time = time.time()

        try:
            self.logger.info(f"Starting writing task: {task_input.task_content}")

            # Reset trace for new task
            self.reset_trace()

            # Initialize conversation history
            conversation_history = []

            # Build system prompt for writing
            system_prompt = self._build_system_prompt()

            # Build initial user message from TaskInput
            user_message = self._build_initial_message_from_task_input(task_input)

            # Add to conversation
            conversation_history.append({"role": "system", "content": system_prompt})
            conversation_history.append({"role": "user", "content": user_message + " /no_think"})

            iteration = 0
            task_completed = False

            self.logger.debug("Checking conversation history before model call")
            self.logger.debug(f"Conversation history: {conversation_history}")
            # ReAct Loop for Writing: Research 鈫?Plan 鈫?Write 鈫?Refine 鈫?Complete
            # Get model configuration from config
            from config.config import get_config
            config = get_config()
            model_config = config.get_custom_llm_config()
            
            pangu_url = model_config.get('url') or os.getenv('MODEL_REQUEST_URL', '')
            model_token = model_config.get('token') or os.getenv('MODEL_REQUEST_TOKEN', '')
            headers = {'Content-Type': 'application/json', 'csb-token': model_token}
            if model_token:
                headers['Authorization'] = f'Bearer {model_token}'

            while iteration < self.config.max_iterations and not task_completed:
                # Check for cancellation at the start of each iteration
                if self._check_cancellation():
                    self.logger.info(f"WriterAgent task cancelled at iteration {iteration}")
                    execution_time = time.time() - start_time
                    return self.create_response(
                        success=False,
                        result="Task was cancelled by user",
                        iterations=iteration,
                        execution_time=execution_time
                    )

                iteration += 1
                self.logger.info(f"Writing iteration {iteration}")

                try:
                    # Get LLM response (reasoning + potential tool calls) with retry

                    max_retries = 10
                    response = None

                    for attempt in range(max_retries):
                        try:

                            response = requests.post(
                                url=pangu_url,
                                headers=headers,
                                json={
                                    "model": self.config.model,
                                    "chat_template":"{% for message in messages %}{% if loop.first and messages[0]['role'] != 'system' %}{{ '<s>[unused9]绯荤粺锛歔unused10]' }}{% endif %}{% if message['role'] == 'system' %}{{'<s>[unused9]绯荤粺锛? + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'assistant' %}{{'[unused9]鍔╂墜锛? + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'tool' %}{{'[unused9]宸ュ叿锛? + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'function' %}{{'[unused9]鏂规硶锛? + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'user' %}{{'[unused9]鐢ㄦ埛锛? + message['content'] + '[unused10]'}}{% endif %}{% endfor %}{% if add_generation_prompt %}{{ '[unused9]鍔╂墜锛? }}{% endif %}",
                                    "messages": conversation_history,
                                    "temperature": self.config.temperature,
                                    "max_tokens": self.config.max_tokens,
                                    "spaces_between_special_tokens": False,
                                },
                                timeout=model_config.get("timeout", 180)
                            )
                            response = response.json()

                            self.logger.debug(f"API response received")
                            break  # Success, exit retry loop

                        except Exception as e:
                            self.logger.warning(f"LLM API call attempt {attempt + 1} failed: {e}")
                            if attempt == max_retries - 1:
                                raise e  # Last attempt, re-raise the exception
                            time.sleep(6)  # Simple 1 second delay between retries

                    if response is None:
                        raise Exception("Failed to get response after all retries")

                    assistant_message = response["choices"][0]["message"]

                    try:
                        if assistant_message["content"]:
                            reasoning_content = assistant_message["content"].split("[unused16]")[-1].split("[unused17]")[0]
                            if len(reasoning_content) > 0:
                                self.log_reasoning(iteration, reasoning_content)
                    except Exception as e:
                        self.logger.warning(f"Tool call parsing error: {e}")
                        # Parse error, rerun
                        followup_prompt = f"There is a problem with the format of model generation: {e}. Please try again."
                        conversation_history.append({"role": "user", "content": followup_prompt + " /no_think"})
                        continue

                    def extract_tool_calls(content):
                        import re
                        tool_call_str = re.findall(r"\[unused11\]([\s\S]*?)\[unused12\]", content)
                        if len(tool_call_str) > 0:
                            try:
                                tool_calls = json.loads(tool_call_str[0])
                            except:
                                return []
                        else:
                            return []
                        return tool_calls

                    # Add assistant message to conversation
                    conversation_history.append({
                        "role": "assistant",
                        "content": assistant_message["content"]
                    })

                    tool_calls = extract_tool_calls(assistant_message["content"])

                    # Execute tool calls if any (Acting phase)
                    for tool_call in tool_calls:
                        # Str
                        arguments = tool_call["arguments"]
                        self.logger.debug(f"Arguments is string: {isinstance(arguments, str)}")

                        # Check if planning is complete
                        if tool_call["name"] in ["writer_subjective_task_done"]:
                            task_completed = True
                            self.log_action(iteration, tool_call["name"], arguments, arguments)
                            break
                        if tool_call["name"] in ["think"]:
                            tool_result = {
                                "tool_results": "You can proceed to invoke other tools if needed. But the next step cannot call the reflect tool"}
                        else:
                            tool_result = self.execute_tool_call(tool_call)

                        # Log the action using base class method
                        self.log_action(iteration, tool_call["name"], arguments, tool_result)

                        # Add tool result to conversation
                        conversation_history.append({
                            "role": "tool",
                            "content": json.dumps(tool_result, ensure_ascii=False, indent=2) + " /no_think"
                        })

                    # If no tool calls, encourage continued writing
                    if len(tool_calls) == 0:
                        # Add follow-up prompt to encourage action or completion
                        followup_prompt = (
                            "Continue your writing process. If you need to research more, use available tools. "
                            "If you need to write or edit content, use file operations. "
                            "If your writing is complete and meets requirements, call writer_subjective_task_done. /no_think"
                        )
                        conversation_history.append({"role": "user", "content": followup_prompt})

                except Exception as e:
                    error_msg = f"Error in writing iteration {iteration}: {e}"
                    self.log_error(iteration, error_msg)
                    break

            execution_time = time.time() - start_time
            # Extract final result
            if task_completed:
                # Find the completion result in the trace
                completion_result = None
                for step in reversed(self.reasoning_trace):
                    if step.get("type") == "action" and step.get("tool") in ["writer_subjective_task_done"]:
                        completion_result = step.get("result")
                        break
                return self.create_response(
                    success=True,
                    result=completion_result,
                    iterations=iteration,
                    execution_time=execution_time
                )
            else:

                return self.create_response(
                    success=False,
                    error=f"Writing task not completed within {self.config.max_iterations} iterations",
                    iterations=iteration,
                    execution_time=execution_time
                )

        except Exception as e:
            execution_time = time.time() - start_time if 'start_time' in locals() else 0
            self.logger.error(f"Error in execute_react_loop: {e}")

            return self.create_response(
                success=False,
                error=str(e),
                iterations=iteration if 'iteration' in locals() else 0,
                execution_time=execution_time
            )


# Factory function for creating the writer agent
def create_writer_agent(
        model: Any = None,
        max_iterations: int = 15,  # More iterations for writing tasks
        temperature: Any = None,  # Resolved from env if not provided
        max_tokens: Any = None,
        shared_mcp_client=None
) -> WriterAgent:
    """
    Create a WriterAgent instance with server-managed sessions.
    
    Args:
        model: The LLM model to use
        max_iterations: Maximum number of iterations for writing tasks
        temperature: Temperature setting for creativity
        max_tokens: Maximum tokens for the AI response
        shared_mcp_client: Optional shared MCP client from parent agent (prevents extra sessions)

    Returns:
        Configured WriterAgent instance with writing-focused tools
    """
    # Import the enhanced config function
    from .base_agent import create_agent_config

    # Create agent configuration (session managed by MCP server)
    config = create_agent_config(
        agent_name="WriterAgent",
        model=model,
        max_iterations=max_iterations,
        temperature=temperature,
        max_tokens=max_tokens,
    )

    # Create agent instance with shared MCP client (filtered tools for writing)
    agent = WriterAgent(config=config, shared_mcp_client=shared_mcp_client)

    return agent
