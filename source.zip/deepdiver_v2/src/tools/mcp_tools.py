# Copyright (c) 2025 Huawei Technologies Co., Ltd. All rights reserved.
# Copyright (c) 2026 South China Sea Institute of Oceanology, Chinese Academy of Sciences (SCSIO, CAS). All rights reserved.
import os
import json
import random
import subprocess
import requests
import re
import shutil
from typing import Dict, Any, List, Optional, Union
from pathlib import Path
import logging
from dataclasses import dataclass
from urllib.parse import urlparse
import tempfile
import time
import asyncio
import aiohttp
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
from datetime import datetime, timedelta
import dateutil.parser
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlparse
from bs4 import BeautifulSoup
import xml.etree.ElementTree as ET
from urllib.parse import quote
from collections import Counter
import inspect
import sys
import sqlite3
from functools import wraps
from contextlib import contextmanager
from typing import Optional

from .paper import Paper
from .normalizer import Area, CompanyStatus, DateRange, normalize_company_name
from .task_diagnostics import timed as diagnostic_timed
from ..arxiv_atom import parse_arxiv_atom, read_bounded_arxiv_response
from ..arxiv_query import validate_arxiv_query, repair_arxiv_query, simplify_arxiv_query
from ..arxiv_pdf_download import download_arxiv_pdf
from ..arxiv_read_control import ReadTrace

# arXiv's public Atom API asks clients to stay well below one request every
# three seconds. Literature tasks can run concurrently from the web UI, so
# this state must be process-wide instead of living on one MCPTools instance.
# This SQLite file is shared by the 5000, 5050, CLI, and MCP processes.  A
# process-local mutex alone cannot enforce arXiv's single-connection rule.
_ARXIV_STATE_DB = Path(__file__).resolve().parents[3] / "logs" / "arxiv_request_state.sqlite3"
_ARXIV_CONNECTION_LOCK = _ARXIV_STATE_DB.with_suffix(".lock")


def _arxiv_datetime(value, fallback=None):
    if not value:
        return fallback
    try:
        parsed = dateutil.parser.isoparse(value)
        return parsed.replace(tzinfo=None) if parsed.tzinfo else parsed
    except (TypeError, ValueError, OverflowError):
        return fallback


def _papers_from_arxiv_atom(content):
    papers = []
    for entry in parse_arxiv_atom(content):
        try:
            paper_id = entry["paper_id"]
            title = entry["title"]
            if not paper_id or not title:
                continue
            published = _arxiv_datetime(entry["published"])
            updated = _arxiv_datetime(entry["updated"], published)
            papers.append(Paper(
                paper_id=paper_id,
                title=title,
                authors=entry["authors"],
                abstract=entry["summary"],
                url=f"https://arxiv.org/abs/{paper_id}",
                pdf_url=f"https://arxiv.org/pdf/{paper_id}",
                published_date=published,
                updated_date=updated,
                source="arxiv",
                categories=entry["categories"],
                keywords=[],
                doi=entry["doi"],
            ).to_dict())
        except (KeyError, TypeError, ValueError) as entry_error:
            logger.warning("Skipping malformed arXiv entry: %s", type(entry_error).__name__)
    return papers


def _papers_from_arxiv_response(response):
    try:
        return _papers_from_arxiv_atom(read_bounded_arxiv_response(response))
    finally:
        close = getattr(response, "close", None)
        if callable(close):
            close()


def _reject_arxiv_redirect(response):
    """Do not follow an official metadata request to an unknown target."""
    if 300 <= int(getattr(response, "status_code", 0) or 0) < 400:
        raise requests.HTTPError("arXiv redirect refused", response=response)


@contextmanager
def _arxiv_cross_process_lock(timeout: float = 60.0):
    """Allow only one arXiv API connection across all local processes."""
    _ARXIV_CONNECTION_LOCK.parent.mkdir(parents=True, exist_ok=True)
    lock_file = _ARXIV_CONNECTION_LOCK.open("a+b")
    lock_file.seek(0)
    if lock_file.tell() == 0 and lock_file.read(1) == b"":
        lock_file.write(b"0")
        lock_file.flush()
    started = time.monotonic()
    acquired = False
    try:
        while not acquired:
            try:
                lock_file.seek(0)
                if os.name == "nt":
                    import msvcrt
                    msvcrt.locking(lock_file.fileno(), msvcrt.LK_NBLCK, 1)
                else:  # pragma: no cover - exercised on Linux deployments
                    import fcntl
                    fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                acquired = True
            except (OSError, BlockingIOError):
                if time.monotonic() - started >= timeout:
                    raise TimeoutError("timed out waiting for the shared arXiv connection lock")
                time.sleep(0.1)
        yield
    finally:
        if acquired:
            lock_file.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(lock_file.fileno(), msvcrt.LK_UNLCK, 1)
            else:  # pragma: no cover - exercised on Linux deployments
                import fcntl
                fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)
        lock_file.close()


def _arxiv_state_update(callback, timeout: float = 30.0):
    """Run one atomic read/update against the cross-process throttle state."""
    _ARXIV_STATE_DB.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(str(_ARXIV_STATE_DB), timeout=timeout)
    try:
        connection.execute(
            "CREATE TABLE IF NOT EXISTS arxiv_state ("
            "id INTEGER PRIMARY KEY CHECK (id = 1), "
            "next_request_at REAL NOT NULL DEFAULT 0, "
            "cooldown_until REAL NOT NULL DEFAULT 0)"
        )
        connection.execute("INSERT OR IGNORE INTO arxiv_state(id) VALUES (1)")
        connection.commit()
        connection.execute("BEGIN IMMEDIATE")
        row = connection.execute(
            "SELECT next_request_at, cooldown_until FROM arxiv_state WHERE id = 1"
        ).fetchone()
        result, next_request_at, cooldown_until = callback(row)
        connection.execute(
            "UPDATE arxiv_state SET next_request_at = ?, cooldown_until = ? WHERE id = 1",
            (next_request_at, cooldown_until),
        )
        connection.commit()
        return result
    finally:
        connection.close()

# from markdown_pdf import MarkdownPdf, Section  # 閺€鍦暏 ReportLab

# ReportLab imports for PDF generation
try:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle, Preformatted, \
        Image as RLImage, HRFlowable
    from reportlab.lib import colors
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY, TA_RIGHT

    REPORTLAB_AVAILABLE = True
except ImportError:
    REPORTLAB_AVAILABLE = False
    logger.warning("鐠€锕€鎲? ReportLab 閺堫亜鐣ㄧ憗鍜冪礉鐠囩柉绻嶇悰? pip install reportlab")

# 鐏忔繆鐦€电厧鍙唌atplotlib閻劋绨〒鍙夌厠閺佹澘顒熼崗顒€绱?
try:
    import matplotlib

    matplotlib.use('Agg')  # 娴ｈ法鏁ら棃婵璘I閸氬海顏?
    import matplotlib.pyplot as plt
    from matplotlib import mathtext

    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False
    logger.warning("鐠€锕€鎲? matplotlib 閺堫亜鐣ㄧ憗鍜冪礉閺佹澘顒熼崗顒€绱＄亸鍡曚簰閺傚洦婀拌ぐ銏犵础閺勫墽銇氶妴鍌氱暔鐟? pip install matplotlib")

try:
    from config.config import get_config, temporary_pdf_parse_mode
except ImportError:
    import sys

    sys.path.append(str(Path(__file__).parent.parent.parent))
    from config.config import get_config, temporary_pdf_parse_mode

from .llama_vision_client import LlamaVisionClient, LlamaVisionConfig
from .llama_evidence_fusion import (
    build_hybrid_evidence_ledger, crop_page, fuse_region,
    select_low_confidence_regions, pdf_sha256,
)


def run_llama_vision_enhancement(pdf_path, parsed, config, cache_dir, *, visual_only=False):
    """Review PDF regions without blocking the main parser.

    Hybrid mode passes ``visual_only=True`` so formulas and tables are handled
    by the whole-document transcription and this costly path focuses on
    figures, charts, and flowcharts.
    """
    result = {"enabled": bool(config.llama_vision_enabled), "status": "disabled", "regions": [],
              "selected_count": 0, "attempted_count": 0, "skipped_count": 0,
              "success_count": 0, "failure_count": 0, "override_count": 0}
    if not config.llama_vision_enabled:
        return result
    result["status"] = "running"
    try:
        regions = select_low_confidence_regions(
            parsed,
            config.llama_vision_max_regions,
            config.llama_vision_min_confidence,
            str(pdf_path),
        )
        if visual_only:
            regions = [
                region for region in regions
                if region.get("content_type") in {"figure", "image", "figure_caption"}
            ]
        result["selected_count"] = len(regions)
        if not regions:
            result["status"] = "skipped"
            result["reason"] = "no low-confidence regions selected"
            logger.info("Llama vision review skipped: no low-confidence PDF regions selected")
            return result
        client = LlamaVisionClient(LlamaVisionConfig(
            enabled=True, api_key=config.llama_cloud_api_key,
            tier=config.llama_parse_tier, endpoint=config.llama_parse_endpoint,
            poll_interval=config.llama_parse_poll_interval,
            timeout=config.llama_vision_timeout,
            max_retries=config.llama_vision_max_retries,
            max_tokens=config.llama_vision_max_tokens))
        result["pdf_sha256"] = pdf_sha256(str(pdf_path))
        logger.info(
            "LlamaParse region review started: tier=%s selected_regions=%s",
            config.llama_parse_tier,
            len(regions),
        )
        for index, region in enumerate(regions):
            result["attempted_count"] += 1
            try:
                image = crop_page(str(pdf_path), int(region["page"]), region.get("expanded_bbox", region["bbox"]))
                review = client.review(image, region["content_type"], region.get("text", ""))
                fused = fuse_region(region, review, config.llama_vision_allow_override, config.llama_vision_min_confidence)
                result["regions"].append(fused)
                if review.get("status") == "ok":
                    result["success_count"] += 1
                else:
                    result["failure_count"] += 1
                    reason = str(review.get("reason") or "")
                    if reason.startswith(("HTTP 401", "HTTP 403", "LLAMA_CLOUD_API_KEY")):
                        result["status"] = "failed"
                        result["error"] = reason
                        result["skipped_count"] += len(regions) - index - 1
                        logger.error(
                            "LlamaParse authentication failed; stopping remaining regions: %s",
                            reason,
                        )
                        break
                if fused.get("review_status") == "accepted":
                    result["override_count"] += 1
            except Exception as exc:
                result["failure_count"] += 1
                result["regions"].append({**region, "source": "local_pdf", "review_status": "failed", "error": str(exc)})
        if result["status"] != "failed":
            if result["failure_count"] == 0:
                result["status"] = "completed"
            elif result["success_count"]:
                result["status"] = "partial"
            else:
                result["status"] = "failed"
                result["error"] = "all Llama vision region reviews failed"
        logger.info(
            "LlamaParse region review finished: status=%s selected=%s attempted=%s "
            "succeeded=%s failed=%s skipped=%s overrides=%s",
            result["status"], result["selected_count"], result["attempted_count"],
            result["success_count"], result["failure_count"], result["skipped_count"],
            result["override_count"],
        )
    except Exception as exc:
        result["status"] = "failed"
        result["error"] = str(exc)
    return result


def run_llama_full_pdf_enhancement(pdf_path, config, output_path):
    """Create an optional full-PDF LlamaParse transcription without blocking PDF use.

    Only a compact status object is returned to MCP. The potentially large
    Markdown stays in the per-run arXiv directory and is read explicitly by
    the research agent when configured as an auxiliary source.
    """
    result = {
        "enabled": bool(getattr(config, "llama_full_pdf_enabled", False)),
        "status": "disabled",
        "text_path": "",
        "requires_local_pdf_verification": True,
    }
    if not result["enabled"]:
        return result
    try:
        client = LlamaVisionClient(LlamaVisionConfig(
            enabled=True, api_key=config.llama_cloud_api_key,
            tier=config.llama_parse_tier, endpoint=config.llama_parse_endpoint,
            poll_interval=config.llama_parse_poll_interval,
            timeout=config.llama_full_pdf_timeout,
            max_retries=config.llama_full_pdf_max_retries,
        ))
        logger.info("LlamaParse full-PDF parse started: tier=%s pdf=%s", config.llama_parse_tier, pdf_path)
        response = client.parse_full_pdf(
            str(pdf_path), timeout=config.llama_full_pdf_timeout,
            max_retries=config.llama_full_pdf_max_retries,
        )
        result.update({key: value for key, value in response.items() if key not in {"markdown", "page_markdown"}})
        if response.get("status") == "completed":
            destination = Path(output_path)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_text(
                "<!-- Auxiliary full-PDF transcription from LlamaParse. "
                "Use the original local PDF/page metadata to verify exact table cells, "
                "formula glyphs, chart values, and diagram topology. -->\n\n"
                + str(response.get("markdown") or ""),
                encoding="utf-8",
            )
            result["text_path"] = str(destination)
            result["markdown_chars"] = len(str(response.get("markdown") or ""))
            page_markdown = response.get("page_markdown") or []
            if page_markdown:
                pages_destination = destination.with_suffix(".pages.json")
                pages_destination.write_text(json.dumps(page_markdown, ensure_ascii=False), encoding="utf-8")
                result["pages_path"] = str(pages_destination)
                result["page_count"] = len(page_markdown)
        logger.info(
            "LlamaParse full-PDF parse finished: status=%s chars=%s elapsed_ms=%s",
            result.get("status"), result.get("markdown_chars", 0), result.get("elapsed_ms"),
        )
    except Exception as exc:
        result.update({"status": "failed", "reason": str(exc)})
        logger.exception("LlamaParse full-PDF parse failed")
    return result

# Import the optimized Faiss-based manager (fallback to JSON if Faiss not available)
try:
    from knowledge.vector_store import auto_index_task_completion_optimized, get_optimized_knowledge_manager

    FAISS_AVAILABLE = True
except ImportError:
    try:
        from ..knowledge.vector_store import auto_index_task_completion_optimized, get_optimized_knowledge_manager

        FAISS_AVAILABLE = True
    except ImportError:
        # Knowledge module not available, provide stub implementations
        FAISS_AVAILABLE = False


        def auto_index_task_completion_optimized(config, task_summary):
            """Stub implementation - knowledge module not available"""
            logging.getLogger(__name__).debug("Knowledge indexing skipped - module not available")
            return True


        def auto_index_task_completion(config, task_summary):
            """Stub implementation - knowledge module not available"""
            logging.getLogger(__name__).debug("Knowledge indexing skipped - module not available")
            return True


        get_optimized_knowledge_manager = None

logger = logging.getLogger(__name__)

# ``None`` makes it explicit that requests should merge the process'
# HTTP(S)_PROXY/NO_PROXY settings. A shared mutable dict is easy to mistake
# for an explicit proxy policy and makes VPN troubleshooting ambiguous.
# Callers that need a per-request proxy can still pass one explicitly.
proxy = None


@dataclass
class MCPToolResult:
    """Standard result format for MCP tools"""
    success: bool
    data: Any = None
    error: str = None
    metadata: Dict[str, Any] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "data": self.data,
            "error": self.error,
            "metadata": self.metadata or {}
        }


def _render_latex_to_image(latex_text: str, output_path: Path = None, fontsize: int = 12) -> Path:
    """
    娴ｈ法鏁atplotlib鐏忓搩aTeX閸忣剙绱″〒鍙夌厠娑撳搫娴橀悧?

    Args:
        latex_text: LaTeX閺嶇厧绱￠惃鍕殶鐎涳箑鍙曞?
        output_path: 鏉堟挸鍤崶鍓у鐠侯垰绶?婵″倹鐏夋稉绡榦ne閸掓瑨鍤滈崝銊ф晸閹?
        fontsize: 鐎涙ぞ缍嬫径褍鐨?

    Returns:
        閸ュ墽澧栭弬鍥︽鐠侯垰绶?
    """
    if not MATPLOTLIB_AVAILABLE:
        return None

    try:
        # 閸掓稑缂撴稉瀛樻閺傚洣娆㈢捄顖氱窞
        if output_path is None:
            import hashlib
            hash_name = hashlib.md5(latex_text.encode()).hexdigest()
            output_path = Path(tempfile.gettempdir()) / f"latex_{hash_name}.png"

        # 婵″倹鐏夐崶鍓у瀹告彃鐡ㄩ崷?閻╁瓨甯存潻鏂挎礀
        if output_path.exists():
            return output_path

        # 绾喕绻歀aTeX閺傚洦婀扮悮?閸栧懓锛?
        if not latex_text.startswith('$'):
            latex_text = f'${latex_text}$'

        # 閸掓稑缂撻崶鎯ц埌
        fig = plt.figure(figsize=(8, 1))
        fig.patch.set_facecolor('white')

        # 濞撳弶鐓婰aTeX
        text = fig.text(0.5, 0.5, latex_text,
                        fontsize=fontsize,
                        ha='center',
                        va='center',
                        usetex=False)  # 娴ｈ法鏁atplotlib閻ㄥ埓athtext閼板奔绗夐弰顖滄埂濮濓絿娈慙aTeX

        # 鐠嬪啯鏆ｆ潏鍦櫕
        fig.tight_layout(pad=0.1)

        # 娣囨繂鐡ㄦ稉绡淣G
        plt.savefig(output_path,
                    dpi=150,
                    bbox_inches='tight',
                    pad_inches=0.05,
                    facecolor='white',
                    edgecolor='none')
        plt.close(fig)

        return output_path

    except Exception as e:
        logger.error(f"鐠€锕€鎲? LaTeX濞撳弶鐓嬫径杈Е: {e}")
        return None


def _wrap_special_symbol(symbol: str, fallback: str = None) -> str:
    """娑撹櫣澹掑▓濠勵儊閸欓攱鍧婇崝鐘茬摟娴ｆ挸娲栭柅鈧弨顖涘瘮"""
    if fallback:
        return f'<font name="Arial">{symbol}</font>'
    return symbol


def _simplify_latex(latex_text: str) -> str:
    """
    缁犫偓閸栨湙aTeX閺佹澘顒熼崗顒€绱℃稉鍝勫讲鐠囩粯鏋冮張?
    鐏忓棗鐖剁憴浣烘畱LaTeX閸涙垝鎶ゆ潪顒佸床娑撶nicode閺佹澘顒熺粭锕€褰?

    Args:
        latex_text: LaTeX閺嶇厧绱￠惃鍕殶鐎涳箑鍙曞?

    Returns:
        缁犫偓閸栨牕鎮楅惃鍕瀮閺?
    """
    # 鐢瓕顫哃aTeX閸涙垝鎶ら弰鐘茬殸 - 娴ｈ法鏁ら張澶婄碍鐎涙鍚€绾喕绻氭径鍕倞妞ゅ搫绨?
    # 闁插秷顩﹂敍姘箑妞よ鍘涙径鍕倞闂€鍨嚒娴犮倧绱濋崘宥咁槱閻炲棛鐓崨鎴掓姢閿涘矂浼╅崗宥夊劥閸掑棗灏柊?
    replacements = [
        (r'\\alpha', '\u03b1'), (r'\\beta', '\u03b2'),
        (r'\\gamma', '\u03b3'), (r'\\Gamma', '\u0393'),
        (r'\\delta', '\u03b4'), (r'\\Delta', '\u0394'),
        (r'\\epsilon', '\u03b5'), (r'\\varepsilon', '\u03b5'),
        (r'\\zeta', '\u03b6'), (r'\\eta', '\u03b7'),
        (r'\\theta', '\u03b8'), (r'\\Theta', '\u0398'),
        (r'\\iota', '\u03b9'), (r'\\kappa', '\u03ba'),
        (r'\\lambda', '\u03bb'), (r'\\Lambda', '\u039b'),
        (r'\\mu', '\u03bc'), (r'\\nu', '\u03bd'),
        (r'\\xi', '\u03be'), (r'\\Xi', '\u039e'),
        (r'\\pi', '\u03c0'), (r'\\Pi', '\u03a0'),
        (r'\\rho', '\u03c1'), (r'\\sigma', '\u03c3'),
        (r'\\Sigma', '\u03a3'), (r'\\tau', '\u03c4'),
        (r'\\upsilon', '\u03c5'), (r'\\Upsilon', '\u03a5'),
        (r'\\varphi', '\u03c6'), (r'\\phi', '\u03c6'),
        (r'\\Phi', '\u03a6'), (r'\\chi', '\u03c7'),
        (r'\\psi', '\u03c8'), (r'\\Psi', '\u03a8'),
        (r'\\omega', '\u03c9'), (r'\\Omega', '\u03a9'),
        (r'\\nabla', '\u2207'), (r'\\partial', '\u2202'),
        (r'\\infty', '\u221e'), (r'\\leq', '\u2264'),
        (r'\\le', '\u2264'), (r'\\geq', '\u2265'),
        (r'\\ge', '\u2265'), (r'\\neq', '\u2260'),
        (r'\\ne', '\u2260'), (r'\\approx', '\u2248'),
        (r'\\equiv', '\u2261'), (r'\\sim', '\u223c'),
        (r'\\propto', '\u221d'), (r'\\times', '\u00d7'),
        (r'\\cdot', '\u00b7'), (r'\\div', '\u00f7'),
        (r'\\pm', '\u00b1'), (r'\\mp', '\u2213'),
        (r'\\oplus', '\u2295'), (r'\\otimes', '\u2297'),
        (r'\\notin', '\u2209'), (r'\\in', '\u2208'),
        (r'\\subseteq', '\u2286'), (r'\\supseteq', '\u2287'),
        (r'\\subset', '\u2282'), (r'\\supset', '\u2283'),
        (r'\\cup', '\u222a'), (r'\\cap', '\u2229'),
        (r'\\emptyset', '\u2205'), (r'\\forall', '\u2200'),
        (r'\\exists', '\u2203'), (r'\\neg', '\u00ac'),
        (r'\\land', '\u2227'), (r'\\lor', '\u2228'),
        (r'\\iiint', '\u222d'), (r'\\iint', '\u222c'),
        (r'\\oint', '\u222e'), (r'\\int', '\u222b'),
        (r'\\sum', '\u2211'), (r'\\prod', '\u220f'),
        (r'\\leftrightarrow', '\u2194'), (r'\\rightarrow', '\u2192'),
        (r'\\leftarrow', '\u2190'), (r'\\Rightarrow', '\u21d2'),
        (r'\\Leftarrow', '\u21d0'), (r'\\Leftrightarrow', '\u21d4'),
        (r'\\gets', '\u2190'), (r'\\to', '\u2192'),
        (r'\\sqrt', '\u221a'), (r'\\angle', '\u2220'),
        (r'\\perp', '\u22a5'), (r'\\parallel', '\u2225'),
        (r'\^2', '\u00b2'), (r'\^3', '\u00b3'),
        (r'\\text\{([^}]+)\}', r'\1'),
        (r'\\mathrm\{([^}]+)\}', r'\1'),
        (r'\\mathbf\{([^}]+)\}', r'\1'),
        (r'\\mathit\{([^}]+)\}', r'\1'),
        (r'\\frac\{([^}]+)\}\{([^}]+)\}', r'(\1)/(\2)'),
        (r'\\hat\{([^}]+)\}', r'\1^'), (r'\\hat ([a-zA-Z])', r'\1^'),
        (r'\\bar\{([^}]+)\}', r'\1-'), (r'\\tilde\{([^}]+)\}', r'\1~'),
        (r'\\vec\{([^}]+)\}', r'<b>\1</b>'),
        (r'\\left\(', '('), (r'\\right\)', ')'),
        (r'\\left\[', '['), (r'\\right\]', ']'),
        (r'\\left\{', '{'), (r'\\right\}', '}'),
        (r'\\left', ''), (r'\\right', ''), (r'\\big', ''),
        (r'\\Big', ''), (r'\\bigg', ''), (r'\\Bigg', ''),
        (r'\\\\', ' '), (r'\\,', ' '), (r'\\;', ' '),
        (r'\\quad', '  '), (r'\\qquad', '    '),
    ]
    result = latex_text

    # 閹稿銆庢惔蹇撶安閻劍澧嶉張澶嬫禌閹?
    for pattern, replacement in replacements:
        result = re.sub(pattern, replacement, result)

    # 婢跺嫮鎮婇柅姘辨暏閻ㄥ嫪绗傞弽?^{...} 鏉烆剚宕叉稉绡怲ML
    def convert_superscript(match):
        content = match.group(1)
        return f'<sup>{content}</sup>'

    result = re.sub(r'\^\{([^}]+)\}', convert_superscript, result)
    result = re.sub(r'\^([0-9a-zA-Z])', r'<sup>\1</sup>', result)

    # 婢跺嫮鎮婇柅姘辨暏閻ㄥ嫪绗呴弽?_{...} 鏉烆剚宕叉稉绡怲ML
    def convert_subscript(match):
        content = match.group(1)
        return f'<sub>{content}</sub>'

    result = re.sub(r'\_\{([^}]+)\}', convert_subscript, result)
    result = re.sub(r'\_([0-9a-zA-Z])', r'<sub>\1</sub>', result)

    # 濞撳懐鎮婇崜鈺€缍戦惃鍕冀閺傛粍娼崪宀冨С閹奉剙褰?
    # 濞夈劍鍓伴敍姘崇箹闁插矁顩︾亸蹇撶妇閿涘奔绗夌憰浣圭閻炲棙甯€瀹歌尙绮℃潪顒佸床婵傜晫娈慤nicode缁楋箑褰?
    result = result.replace('\\', '')
    result = re.sub(r'\{([^}]*)\}', r'\1', result)

    # 閸氬骸顦╅悶鍡窗娑撳搫褰查懗鑺ユ￥濞夋洘妯夌粈铏规畱缁楋箑褰垮ǎ璇插鐎涙ぞ缍嬮弽鍥唶閹存牗娴涢幑?
    # 鏉╂瑤绨虹粭锕€褰块崷銊ョ暙娴ｆ挷鑵戦崣顖濆厴缂傚搫銇戦敍宀勬付鐟曚胶澹掑▓濠傤槱閻?
    problematic_symbols = {}

    # 濡偓閺屻儱鑻熼弽鍥唶閻楄鐣╃粭锕€褰?
    for symbol, (replacement, name) in problematic_symbols.items():
        if symbol in result and replacement is not None:
            # 婵″倹鐏夐張澶嬫禌娴狅絿顑侀崣鍑ょ礉閻╁瓨甯撮弴鎸庡床
            result = result.replace(symbol, replacement)

    return result


def _process_inline_formatting(text: str) -> str:
    """Normalize inline Markdown and math notation for ReportLab paragraphs."""
    if not text:
        return ''

    text = re.sub(r'<a\s+id="([^"]+)"', r'<a name="\1"', text)
    text = re.sub(r'<a\s+href="([^"]+)"\s+style="[^"]*">', r'<a href="\1" color="#04B5BB">', text)
    text = re.sub(r'<a\s+href="([^"]+)"(?!\s+color)>', r'<a href="\1" color="#04B5BB">', text)

    superscripts = {
        '\u2070': '0', '\u00b9': '1', '\u00b2': '2', '\u00b3': '3', '\u2074': '4',
        '\u2075': '5', '\u2076': '6', '\u2077': '7', '\u2078': '8', '\u2079': '9',
        '\u207a': '+', '\u207b': '-', '\u207c': '=', '\u207d': '(', '\u207e': ')',
        '\u207f': 'n',
    }
    subscripts = {
        '\u2080': '0', '\u2081': '1', '\u2082': '2', '\u2083': '3', '\u2084': '4',
        '\u2085': '5', '\u2086': '6', '\u2087': '7', '\u2088': '8', '\u2089': '9',
        '\u208a': '+', '\u208b': '-', '\u208c': '=', '\u208d': '(', '\u208e': ')',
        '\u2090': 'a', '\u2091': 'e', '\u2092': 'o', '\u2093': 'x', '\u2095': 'h',
        '\u2096': 'k', '\u2097': 'l', '\u2098': 'm', '\u2099': 'n', '\u209a': 'p',
        '\u209b': 's', '\u209c': 't',
    }
    for character, replacement in superscripts.items():
        text = text.replace(character, f'<sup>{replacement}</sup>')
    for character, replacement in subscripts.items():
        text = text.replace(character, f'<sub>{replacement}</sub>')

    text = re.sub(r'\*\*([^*]+)\*\*', r'<b>\1</b>', text)
    text = re.sub(r'(?<!\*)\*([^*]+)\*(?!\*)', r'<i>\1</i>', text)
    text = re.sub(r'`([^`]+)`', r'<font name="Courier">\1</font>', text)
    return text

def _apply_english_font_markup(text: str, font_name: str = "Arial") -> str:
    parts = re.split(r'(<[^>]+>)', text)
    font_stack: List[bool] = []

    def in_locked_font() -> bool:
        return any(font_stack)

    def wrap_tokens(s: str) -> str:
        return _EN_TOKEN_RE.sub(lambda m: f'<font name="{font_name}">{m.group(0)}</font>', s)

    out: List[str] = []
    for part in parts:
        if not part:
            continue
        if part.startswith('<') and part.endswith('>'):
            if re.match(r'<\s*font\b', part, flags=re.IGNORECASE) and not part.rstrip().endswith('/>'):
                locked = bool(re.search(r'\b(name|face)\s*=', part, flags=re.IGNORECASE))
                font_stack.append(locked)
            elif re.match(r'</\s*font\s*>', part, flags=re.IGNORECASE):
                if font_stack:
                    font_stack.pop()
            out.append(part)
            continue

        out.append(part if in_locked_font() else wrap_tokens(part))

    return ''.join(out)


def generate_pdf_with_reportlab(markdown_content: str, output_path: Path) -> bool:
    """Generate a PDF report from Markdown-ish text with ReportLab."""
    if not REPORTLAB_AVAILABLE:
        logger.error("ReportLab is not available; cannot generate PDF.")
        return False

    try:
        from xml.sax.saxutils import escape

        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        base_font = "Helvetica"
        bold_font = "Helvetica-Bold"
        try:
            pdfmetrics.registerFont(UnicodeCIDFont("STSong-Light"))
            base_font = "STSong-Light"
            bold_font = "STSong-Light"
        except Exception:
            logger.debug("CID font registration failed; using Helvetica fallback.", exc_info=True)

        doc = SimpleDocTemplate(
            str(output_path),
            pagesize=A4,
            rightMargin=2 * cm,
            leftMargin=2 * cm,
            topMargin=2 * cm,
            bottomMargin=2 * cm,
        )

        styles = getSampleStyleSheet()
        style_normal = ParagraphStyle(
            "SciAssistantBody",
            parent=styles["BodyText"],
            fontName=base_font,
            fontSize=10.5,
            leading=16,
            alignment=TA_JUSTIFY,
            spaceAfter=7,
        )
        style_h1 = ParagraphStyle(
            "SciAssistantHeading1",
            parent=styles["Heading1"],
            fontName=bold_font,
            fontSize=18,
            leading=23,
            spaceBefore=10,
            spaceAfter=10,
        )
        style_h2 = ParagraphStyle(
            "SciAssistantHeading2",
            parent=styles["Heading2"],
            fontName=bold_font,
            fontSize=15,
            leading=20,
            spaceBefore=8,
            spaceAfter=8,
        )
        style_h3 = ParagraphStyle(
            "SciAssistantHeading3",
            parent=styles["Heading3"],
            fontName=bold_font,
            fontSize=12.5,
            leading=17,
            spaceBefore=6,
            spaceAfter=6,
        )

        story = []
        for raw_line in str(markdown_content or "").splitlines():
            line = raw_line.strip()
            if not line:
                story.append(Spacer(1, 0.16 * cm))
                continue

            style = style_normal
            content = line
            if line.startswith("### "):
                style = style_h3
                content = line[4:].strip()
            elif line.startswith("## "):
                style = style_h2
                content = line[3:].strip()
            elif line.startswith("# "):
                style = style_h1
                content = line[2:].strip()
            elif line.startswith(("- ", "* ")):
                content = "\u2022 " + line[2:].strip()

            content = escape(content)
            content = _process_inline_formatting(content)
            story.append(Paragraph(content or "&nbsp;", style))

        if not story:
            story.append(Paragraph("No content", style_normal))

        doc.build(story)
        return output_path.exists() and output_path.stat().st_size > 0
    except Exception as exc:
        logger.exception("Failed to generate PDF with ReportLab: %s", exc)
        return False

class MCPTools:
    """Multi Agent System MCP Tools Implementation"""

    def __init__(self, workspace_path: str = None):
        self.config = get_config()
        self.workspace_path = Path(workspace_path) if workspace_path else Path.cwd()
        self.workspace_path.mkdir(exist_ok=True, parents=True)

        # Session context for workspace-aware operations
        self.session_id = None
        self.session_workspace_path = None
        self.full_workspace_path = os.path.realpath(self.workspace_path)
        if not self.full_workspace_path.endswith(os.sep):
            self.full_workspace_path += os.sep

        # 閸掓繂顫愰崠?username閿涘苯鐨剧拠鏇氱矤 workspace 闁板秶鐤嗛弬鍥︽鐠囪褰囬敍灞芥儊閸掓瑤濞囬悽銊╃帛鐠併倕鈧?
        self.username = self._get_username_from_workspace()

        # 閸氼垰濮╅弮鑸靛ⅵ閸楁澘鐤勯梽鍛邦嚢閸欐牕鍩岄惃?LLM 闁板秶鐤嗛敍宀€鏁ゆ禍搴㈠笓閺屻儵鍘ょ純顔煎鏉炰粙妫舵０?
        model_config = self.config.get_custom_llm_config()
        self.timeout = int(model_config.get('timeout') or os.getenv('MODEL_REQUEST_TIMEOUT', 180))
        self.max_retries = int(os.getenv('MCP_DOWNLOAD_MAX_RETRIES', 3))
        self.session = requests.Session()
        debug_url = model_config.get('url') or os.getenv('MODEL_REQUEST_URL', '')
        debug_token = model_config.get('token') or os.getenv('MODEL_REQUEST_TOKEN', '')
        debug_model = model_config.get('model') or os.getenv('MODEL_NAME', '')
        logger.info("=" * 50)
        logger.info("MCP LLM configuration")
        logger.info(f"  endpoint: {debug_url}")
        logger.info(f"  token: {'configured' if debug_token else 'not configured'}")
        logger.info(f"  model: {debug_model}")
        logger.info("=" * 50)

    def _get_username_from_workspace(self) -> str:
        """
        娴?workspace 闁板秶鐤嗛弬鍥︽娑擃叀顕伴崣鏍暏閹村嘲鎮?
        
        Returns:
            閻劍鍩涢崥宥忕礉婵″倹鐏夌拠璇插絿婢惰精瑙﹂崚娆掔箲閸ョ偤绮拋銈呪偓?"閻劍鍩?
        """
        try:
            username_file = self.workspace_path / '.username'
            if username_file.exists():
                with open(username_file, 'r', encoding='utf-8') as f:
                    username = f.read().strip()
                    if username:
                        return username
        except Exception as e:
            logger.debug(f"鐠囪褰囬悽銊﹀煕閸氬秴銇戠拹? {e}")

        return "default"

    def set_session_context(self, session_id: str, session_workspace_path: str):
        """Set session context for workspace-aware operations"""
        self.session_id = session_id
        self.session_workspace_path = Path(session_workspace_path)
        # Update workspace path to session-specific path
        self.workspace_path = self.session_workspace_path
        self.full_workspace_path = os.path.realpath(self.workspace_path)
        if not self.full_workspace_path.endswith(os.sep):
            self.full_workspace_path += os.sep
        # 閺囧瓨鏌?username
        self.username = self._get_username_from_workspace()
        logger.info(
            f"Set session context - ID: {session_id}, Workspace: {session_workspace_path}, Username: {self.username}")

    def get_session_context(self) -> Dict[str, Any]:
        """Get current session context"""
        return {
            "session_id": self.session_id,
            "session_workspace_path": str(self.session_workspace_path) if self.session_workspace_path else None,
            "workspace_path": str(self.workspace_path)
        }

    def _safe_join(self, path: str) -> Path:
        if os.path.isabs(path):
            raise Exception(f"Path '{path}' is absolute. Only relative paths are allowed.")
        workspace_root = os.path.realpath(str(self.workspace_path))
        full_joined_path = os.path.realpath(os.path.join(workspace_root, path))
        # A string-prefix test rejects the workspace root itself because the
        # stored root has a trailing separator. It is also unsafe for sibling
        # paths such as "workspace-other". commonpath handles both cases.
        try:
            shared_path = os.path.commonpath((
                os.path.normcase(workspace_root),
                os.path.normcase(full_joined_path),
            ))
        except ValueError:
            shared_path = ""
        if shared_path != os.path.normcase(workspace_root):
            raise Exception(f"Path '{path}' is outside workspace directory.")
        return Path(full_joined_path)

    # ================ WEB SEARCH TOOLS ================

    def batch_web_search(
            self,
            queries: List[str],
            max_results_per_query: int = 15,
            max_workers: int = 5
    ) -> MCPToolResult:
        """
        Batch web search using configurable search provider with concurrent processing.
        
        Users need to implement their own search provider. Below is an example available:
        [
            {
                "query": "search query",
                "search_results": [
                    {
                        "title": "Page title",
                        "link": "https://example.com",
                        "snippet": "Description snippet",
                        "date": "Feb 8, 2022",
                    },
                    ...
                ]
            },
            ...
        ]
        
        Args:
            queries: List of search queries
            max_results_per_query: Maximum search results per query
            max_workers: Maximum number of concurrent search requests
        """
        try:
            from config.config import get_search_engine_config
            search_config = get_search_engine_config()

            if not search_config:
                return MCPToolResult(
                    success=False,
                    error="Search engine not configured"
                )

            # Ensure we never return more than 15 results per query
            actual_max_results = min(max_results_per_query, 15)

            def search_single_query(query: str) -> Dict[str, Any]:
                """Search a single query"""
                try:
                    search_results = self._generic_search(query, actual_max_results, search_config)

                    if not search_results.success:
                        return {
                            'query': query,
                            'success': False,
                            'error': search_results.error,
                            'results': []
                        }

                    # Process search results
                    search_data = search_results.data
                    search_data["organic"] = search_data["organic"][:actual_max_results]

                    return {
                        'query': query,
                        'success': True,
                        'results': search_data,
                        'timestamp': time.time()
                    }

                except Exception as e:
                    logger.error(f"Error searching query '{query}': {e}")
                    return {
                        'query': query,
                        'success': False,
                        'error': str(e),
                        'results': []
                    }

            # Execute searches concurrently
            all_results = []
            with ThreadPoolExecutor(max_workers=min(max_workers, len(queries))) as executor:
                # Submit all search tasks
                future_to_query = {executor.submit(search_single_query, query): query for query in queries}

                # Collect results as they complete
                for future in as_completed(future_to_query):
                    try:
                        result = future.result()
                        all_results.append(result)
                    except Exception as e:
                        query = future_to_query[future]
                        logger.error(f"Error processing search for '{query}': {e}")
                        all_results.append({
                            'query': query,
                            'success': False,
                            'error': str(e),
                            'results': []
                        })

            # Sort results to maintain original query order
            query_order = {query: i for i, query in enumerate(queries)}
            all_results.sort(key=lambda x: query_order.get(x['query'], float('inf')))

            return MCPToolResult(
                success=True,
                data=all_results,
                metadata={
                    'total_queries': len(queries),
                    'successful_queries': len([r for r in all_results if r.get('success', False)]),
                    'concurrent_workers': min(max_workers, len(queries))
                }
            )

        except Exception as e:
            logger.error(f"Batch web search failed: {e}")
            return MCPToolResult(success=False, error=str(e))

    def _generic_search(self, query: str, max_results: int, config: Dict[str, Any]) -> MCPToolResult:
        """
        Generic search function that users need to implement.
        
        This function should return results in the standard format and be wrapped in MCPToolResult:
        
        search_res = {
            "organic": [
                {
                    "title": "Page title",
                    "link": "https://example.com",
                    "snippet": "Description snippet",
                    "date": "Feb 8, 2022"
                }
            ]
        }

        return MCPToolResult(success=True, data=search_res)
        
        Users should implement their own search logic here based on their preferred search service.
        
        Notes:
        1. It is recommended to use search engine APIs that comply with relevant safety and regulatory requirements.
        The user assumes full responsibility for any safety issues, legal consequences, or policy violations
        arising from the use of the search engine results.
        
        2. User requests may be indirectly transmitted to the search engine API in the form of search queries.
        It is the user's responsibility to implement appropriate measures to protect personal privacy and
        sensitive information. We assume no liability for privacy-related issues arising from such transmission.
        """
        try:
            # This is a placeholder - users should implement their own search logic
            # raise NotImplementedError(
            #     "Generic search provider not implemented. Please implement your own search logic in _generic_search method. "
            #     "The return format should match the standard format with 'organic' results containing title, link, snippet, and date fields."
            # )

            # Example implementation for serper (commented out):
            url = config['base_url']

            payload = json.dumps({
                "q": query,
                "num": 10
            })

            headers = {
                'X-API-KEY': config["api_keys"][0],
                'Content-Type': 'application/json'
            }

            response = requests.request("POST", url, headers=headers, data=payload, timeout=config["timeout"],
                                        proxies=proxy)
            response.raise_for_status()

            return MCPToolResult(success=True, data=response.json())
        except Exception as e:
            return MCPToolResult(success=False, error=f"Generic search failed: {e}")

    def _extract_google_search_date(self, search_item: Dict[str, Any]) -> Optional[str]:
        """Extract publication date from Google Search result"""
        try:
            # Check pagemap metatags for various date formats
            pagemap = search_item.get('pagemap', {})
            metatags = pagemap.get('metatags', [{}])

            if metatags:
                meta = metatags[0]
                # Common date meta tags
                date_fields = [
                    'article:published_time',
                    'article:modified_time',
                    'date',
                    'pubdate',
                    'published',
                    'datePublished',
                    'dateModified',
                    'dc.date',
                    'dc.date.created',
                    'creation_date'
                ]

                for field in date_fields:
                    if field in meta and meta[field]:
                        return meta[field]

            # Check for news articles with publish date
            newsarticle = pagemap.get('newsarticle', [{}])
            if newsarticle and newsarticle[0].get('datepublished'):
                return newsarticle[0]['datepublished']

            # Check article schema
            article = pagemap.get('article', [{}])
            if article and article[0].get('datepublished'):
                return article[0]['datepublished']

            return None

        except Exception as e:
            logger.info(f"Error extracting date from search result: {e}")
            return None

    @staticmethod
    def _extract_publication_date_from_html(url: str) -> Optional[str]:
        """Extract publication date directly from webpage HTML"""
        try:
            # Fetch HTML content
            response = requests.get(url, timeout=10, headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            })
            response.raise_for_status()

            soup = BeautifulSoup(response.content, 'html.parser')

            # Common meta tags for publication date
            meta_selectors = [
                'meta[property="article:published_time"]',
                'meta[property="article:modified_time"]',
                'meta[name="date"]',
                'meta[name="pubdate"]',
                'meta[name="published"]',
                'meta[name="datePublished"]',
                'meta[name="publication-date"]',
                'meta[property="og:published_time"]',
                'meta[name="DC.date"]',
                'meta[name="DC.date.created"]',
                'meta[itemprop="datePublished"]',
                'meta[itemprop="dateModified"]'
            ]

            for selector in meta_selectors:
                meta_tag = soup.select_one(selector)
                if meta_tag:
                    content = meta_tag.get('content') or meta_tag.get('datetime')
                    if content:
                        try:
                            # Parse and standardize the date
                            parsed_date = dateutil.parser.parse(content)
                            return parsed_date.isoformat()
                        except ValueError:
                            continue

            # Check for time tags with datetime attribute
            time_tags = soup.find_all('time', {'datetime': True})
            for time_tag in time_tags:
                try:
                    parsed_date = dateutil.parser.parse(time_tag['datetime'])
                    return parsed_date.isoformat()
                except ValueError:
                    continue

            # JSON-LD structured data
            json_ld_scripts = soup.find_all('script', {'type': 'application/ld+json'})
            for script in json_ld_scripts:
                try:
                    data = json.loads(script.string)
                    if isinstance(data, dict):
                        date_fields = ['datePublished', 'dateCreated', 'dateModified']
                        for field in date_fields:
                            if field in data:
                                parsed_date = dateutil.parser.parse(data[field])
                                return parsed_date.isoformat()
                    elif isinstance(data, list):
                        for item in data:
                            if isinstance(item, dict):
                                for field in date_fields:
                                    if field in item:
                                        parsed_date = dateutil.parser.parse(item[field])
                                        return parsed_date.isoformat()
                except ValueError:
                    continue

            return None

        except Exception as e:
            logger.debug(f"Error extracting publication date from {url}: {e}")
            return None

    def _content_extractor(self, url: str, max_tokens: int, config: Dict[str, Any]) -> MCPToolResult:
        """Get content using URL content extractor"""
        max_retry_num = 5
        sleep_time = 5
        retry_num = 0
        while True:
            retry_num += 1
            try:
                api_keys = config.get('api_keys', [])
                headers = {'Content-Type': 'application/json'}
                if api_keys:
                    headers['Authorization'] = f'Bearer {random.choice(api_keys)}'

                # Users need to implement this - placeholder for custom URL crawler
                # raise NotImplementedError(
                #     "URL crawler not implemented. Please implement your own URL crawling logic. "
                #     "The function should extract text content from URLs and return it in a structured format "
                #     "with metadata like title, publication date, and word count."
                # )

                # Example implementation for content extractor (commented out):
                crawler_url = f"{config.get('base_url', 'https://api.content-extractor.com')}/{url}"
                response = requests.get(crawler_url, headers=headers, timeout=config.get('timeout', 30))
                response.raise_for_status()

                content = response.text

                # Truncate if needed
                if max_tokens and len(content.split()) > max_tokens:
                    words = content.split()[:max_tokens]
                    content = ' '.join(words) + '...'

                return MCPToolResult(success=True, data=content)

            except Exception as e:
                if retry_num == max_retry_num:
                    return MCPToolResult(success=False, error=f"Content extractor failed: {e}")
                else:
                    time.sleep(sleep_time)

    def url_crawler(
            self,
            documents: List[Dict],
            max_tokens_per_url: int = 100000,
            include_metadata: bool = True,
            max_workers: int = 10
    ) -> MCPToolResult:
        """
        Extract LLM-friendly content from URLs using configurable crawler service.
        Content is saved to specified file paths.

        Users need to implement their own URL crawler. The return format should include:
        - Extracted text content from the URL
        - Metadata like title, publication date, word count
        - Success/error status for each URL

        Args:
            documents: List of document dictionaries containing:
                - url: Web page URL to extract
                - file_path: Local path to save extracted content
                - title: (Optional) Web page title
                - time: (Optional) Web page publication time
            max_tokens_per_url: Maximum tokens per URL result
            include_metadata: Whether to include metadata about extraction
            max_workers: Maximum number of concurrent extraction requests
        """
        try:
            from config.config import get_url_crawler_config
            crawler_config = get_url_crawler_config()

            if not crawler_config:
                return MCPToolResult(
                    success=False,
                    error="URL crawler not configured"
                )

            def process_single_document(doc: Dict) -> Dict[str, Any]:
                """Process a single document: extract content and save to file"""
                url = doc['url']
                file_path = doc['file_path']
                title = doc.get('title')
                doc_time = doc.get('time')

                result_base = {
                    'url': url,
                    'file_path': file_path,
                    'title': title,
                    'time': doc_time,
                    'success': False,
                    'error': None,
                    'content_length': 0,
                    'word_count': 0,
                    'publication_date': None,
                    'extraction_timestamp': time.time(),
                    'write_success': False
                }

                try:
                    # Extract publication date from the webpage
                    publication_date = self._extract_publication_date_from_html(url)
                    result_base["publication_date"] = publication_date

                    # Extract content using content extractor
                    content_result = self._content_extractor(url, max_tokens_per_url, crawler_config)

                    if not content_result.success:
                        result_base['error'] = content_result.error
                        return result_base

                    content = content_result.data
                    if not content:
                        result_base['error'] = "Extracted content is empty"
                        return result_base

                    # Save content to file
                    write_result = self.file_write(
                        file_path=file_path,
                        content=content,
                        create_dirs=True
                    )

                    if not write_result.success:
                        result_base['error'] = f"File write failed: {write_result.error}"
                        return result_base

                    # Build success result
                    result = {
                        **result_base,
                        'success': True,
                        'content_length': len(content),
                        'word_count': len(content.split()),
                        'publication_date': publication_date,
                        'write_success': True
                    }

                    if include_metadata:
                        result['metadata'] = {
                            'truncated': len(content.split()) >= max_tokens_per_url,
                            'has_publication_date': publication_date is not None,
                            'date_extraction_method': 'html_parsing' if publication_date else None,
                            'file_size': len(content.encode('utf-8'))
                        }

                    return result

                except Exception as e:
                    logger.error(f"Error processing document {url}: {e}")
                    # Try to extract publication date even if processing failed
                    try:
                        publication_date = self._extract_publication_date_from_html(url)
                    except:
                        publication_date = None

                    return {
                        **result_base,
                        'error': str(e),
                        'publication_date': publication_date
                    }

            # Execute processing concurrently
            results = []
            with ThreadPoolExecutor(max_workers=min(max_workers, len(documents))) as executor:
                # Submit all processing tasks
                future_to_doc = {executor.submit(process_single_document, doc): doc for doc in documents}

                # Collect results as they complete
                for future in as_completed(future_to_doc):
                    doc = future_to_doc[future]
                    try:
                        result = future.result()
                        results.append(result)
                    except Exception as e:
                        url = doc['url']
                        logger.error(f"Error processing extraction for '{url}': {e}")

                        # Try to extract publication date even if processing failed
                        try:
                            publication_date = self._extract_publication_date_from_html(url)
                        except:
                            publication_date = None

                        results.append({
                            'url': url,
                            'file_path': doc['file_path'],
                            'title': doc.get('title'),
                            'time': doc.get('time'),
                            'success': False,
                            'error': str(e),
                            'publication_date': publication_date,
                            'extraction_timestamp': time.time(),
                            'write_success': False
                        })

            # Sort results to maintain original document order
            url_order = {doc['url']: i for i, doc in enumerate(documents)}
            results.sort(key=lambda x: url_order.get(x['url'], float('inf')))

            successful_extractions = len([r for r in results if r.get('success', False)])
            successful_writes = len([r for r in results if r.get('write_success', False)])

            return MCPToolResult(
                success=True,
                data=results,
                metadata={
                    'total_documents': len(documents),
                    'successful_extractions': successful_extractions,
                    'successful_writes': successful_writes,
                    'failed_processing': len(documents) - successful_extractions,
                    'concurrent_workers': min(max_workers, len(documents))
                }
            )

        except Exception as e:
            logger.error(f"URL crawler batch processing failed: {e}")
            return MCPToolResult(success=False, error=str(e))

    def _extract_original_filename(self, filename: str) -> str:
        """
        娴犲孩鏋冩禒璺烘倳娑擃厽褰侀崣鏍у斧婵鏋冩禒璺烘倳閿涘牆骞撻幒濉甶le_id閸撳秶绱戦敍?

        Args:
            filename: 閸欘垵鍏橀崠鍛儓file_id閸撳秶绱戦惃鍕瀮娴犺泛鎮曢敍灞剧壐瀵繐顩?'file_id_filename.ext' 閹?'filename.ext'

        Returns:
            閸樼喎顫愰弬鍥︽閸氬稄绱欓崢缁樺竴file_id閸撳秶绱戦敍?
        """
        if '_' in filename:
            parts = filename.split('_', 1)
            # 婵″倹鐏夌粭顑跨闁劌鍨庨弰鐥渋le_id閿?娴ｅ秳浜掓稉濠傚磩閸忣叀绻橀崚璁圭礆閿涘苯鍨担璺ㄦ暏缁楊兛绨╅柈銊ュ瀻
            if len(parts) > 1 and len(parts[0]) >= 8 and re.match(r'^[a-f0-9]{8,}', parts[0].lower()):
                return parts[1]
        return filename

    def _extract_title_from_filename(self, filename: str) -> str:
        """
        娴犲孩鏋冩禒璺烘倳娑擃厽褰侀崣鏍ㄧ垼妫版﹫绱欓崢缁樺竴file_id閸撳秶绱戦敍灞肩箽閻ｆ瑦鏋冩禒鑸靛⒖鐏炴洖鎮曟俊?pdf/.txt/.doc閿?

        Args:
            filename: 閸欘垵鍏橀崠鍛儓file_id閸撳秶绱戦惃鍕瀮娴犺泛鎮?

        Returns:
            閺嶅洭顣介敍鍫滅箽閻ｆ瑥甯慨瀣瀮娴犺埖澧跨仦鏇炴倳閿涘苯褰ч崢缁樺竴缂傛挸鐡ㄩ弬鍥︽閻?txt閸氬海绱戦敍?
        """
        # 閸忓牊褰侀崣鏍у斧婵鏋冩禒璺烘倳閿涘牆骞撻幒濉甶le_id閸撳秶绱戦敍?
        original_filename = self._extract_original_filename(filename)
        # 閸欘亜骞撻幒澶岀处鐎涙ɑ鏋冩禒鍓佹畱.txt閸氬海绱戦敍鍫濐洤 .doc.txt, .docx.txt, .pdf.txt閿?
        # 娴ｅ棔绻氶悾娆忓斧閻?txt閺傚洣娆㈤惃鍕⒖鐏炴洖鎮?
        if (original_filename.endswith('.doc.txt') or
                original_filename.endswith('.docx.txt') or
                original_filename.endswith('.pdf.txt')):
            original_filename = original_filename[:-4]
        return original_filename

    def _extract_title_from_file_content(self, file_path: Path) -> tuple:
        """
        娴犲孩鏋冩禒璺哄敶鐎归€涜厬閹绘劕褰囬弽鍥暯閸滃RL

        Args:
            file_path: 閺傚洣娆㈢捄顖氱窞

        Returns:
            (title, url_source) 閸忓啰绮?
        """
        title = "Unknown Title"
        url_source = "Unknown URL"

        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()

                # 閺€纭呯箻閺嶅洭顣介幓鎰絿闁槒绶?
                for i, line in enumerate(lines[:30]):  # 濡偓閺屻儲娲挎径姘愁攽
                    line = line.strip()
                    if line and 10 <= len(line) <= 200:  # 閺囨潙鎮庨悶鍡欐畱閺嶅洭顣介梹鍨閼煎啫娲?
                        if 'http' not in line and not line.startswith('['):
                            title = line.strip()[:200]
                            # 閸樼粯甯€"Title: "閸撳秶绱戦敍鍫濐洤閺嬫粌鐡ㄩ崷顭掔礆
                            if title.startswith('Title: '):
                                title = title[7:]  # 閸樼粯甯€"Title: "
                            logger.info(f"Detected title at line {i + 1}: {title[:50]}...")
                            break
                    # 婢跺嫮鎮妋arkdown閺嶅洭顣介弽鐓庣础
                    if line.startswith('#'):
                        title = line.strip('# ').strip()[:200]
                        logger.info(f"Detected title at line {i + 1}: {title[:50]}...")
                        break

                # 閺€纭呯箻URL閹绘劕褰囬柅鏄忕帆閿涙碍甯撻梽銈勮厬閺傚洦鐖ｉ悙鍦儊閸欏嚖绱濈涵顔荤箽URL娑撳秴瀵橀崥顐ｆ）閺?
                for line in lines[:20]:
                    # 閸栧綊鍘RL閿涘奔绲鹃幒鎺楁珟娑擃厽鏋冮弽鍥╁仯缁楋箑褰块敍鍫礉閵嗗偊绱遍敍姘剧磼閿涚噦绱氶崪灞藉礁閺傝瀚崣绌?
                    url_match = re.search(r'https?://[^\s\]閿涘被鈧偊绱遍敍姘剧磼閿涚剢+', line)
                    if url_match:
                        url_source = url_match.group(0)
                        logger.info(f"閹绘劕褰囬崚鐧燫L: {url_source[:50]}...")
                        break
        except Exception as e:
            logger.warning(f"鐠€锕€鎲? 閺冪姵纭剁拠璇插絿閻梻鈹掗弬鍥︽ {file_path} - {str(e)}")

        return title, url_source

    def _extract_title_from_research_filename(self, file_path: str) -> str:
        """
        娴犲窎esearch閺傚洣娆㈤崥宥勮厬閹绘劕褰囬弽鍥暯閿涘牆顦悽銊︽煙濡楀牞绱?

        Args:
            file_path: 閺傚洣娆㈢捄顖氱窞

        Returns:
            閺嶅洭顣介敍鍫濐洤閺嬫粍鏋冩禒璺烘倳閺堝鏅ラ敍?
        """
        filename = os.path.basename(file_path)
        if filename and filename != file_path:
            title_candidate = os.path.splitext(filename)[0]
            # 婵″倹鐏夐弬鍥︽閸氬秶婀呯挧閿嬫降閺堝鍓版稊澶涚礄娑撳秵妲搁梾蹇旀簚鐎涙顑佹稉璇х礆閿涘奔濞囬悽銊ョ暊
            if len(title_candidate) > 3 and not re.match(r'^[a-f0-9]{32}', title_candidate):
                logger.info(f"娴犲孩鏋冩禒璺烘倳閹绘劕褰囬弽鍥暯: {title_candidate}")
                return title_candidate
        return "Unknown Title"

    # new
    def generate_abstract_and_keywords(self, article_content: str, user_query: str = "") -> Dict[str, str]:
        """
        娴ｈ法鏁LM閻㈢喐鍨氶弬鍥╃彿閻ㄥ嫭鐖ｆ０妯糕偓浣规喅鐟曚礁鎷伴崗鎶芥暛鐠?

        Args:
            article_content: 鐎瑰本鏆ｉ惃鍕瀮缁旂姴鍞寸€?
            user_query: 閻劍鍩涢惃鍕斧婵鐓＄拠顫礄閸欘垶鈧绱濋悽銊ょ艾閻㈢喐鍨氶弴纾嬪垱閸掑洨娈戦幗妯款洣閿?

        Returns:
            閸栧懎鎯?'title', 'abstract' 閸?'keywords' 閻ㄥ嫬鐡ч崗?
        """
        try:
            import requests
            config = get_config()
            model_config = config.get_custom_llm_config()
            # PANGU 濡€崇€烽柊宥囩枂
            PANGU_URL = model_config.get('url') or os.getenv('MODEL_REQUEST_URL', '')
            model_name = model_config.get('model') or os.getenv("MODEL_NAME", "")
            # 鐠囶叀鈻堝Λ鈧ù瀣剁窗閸愬啿鐣鹃悽鐔稿灇鐠囶叀鈻?
            sample_text = article_content[:5000]
            zh_count = len(re.findall(r'[\u4e00-\u9fff]', sample_text))
            en_count = len(re.findall(r'[a-zA-Z]', sample_text))

            is_english_content = False
            if zh_count < 50 and en_count > 200:
                is_english_content = True
            elif en_count > 0 and (zh_count / en_count) < 0.05:
                is_english_content = True

            # 閺嶈宓侀崘鍛啇鐠囶叀鈻堢€规艾鍩?Prompt
            if is_english_content:
                lang_instruction = "The article is in English. Generate the title, abstract, and keywords in English."
                format_instruction = """
Title:
[Write title here]

Abstract:
[Write abstract here]

Keywords:
[Keyword1; Keyword2; Keyword3]
"""
            else:
                lang_instruction = "The article is in Chinese or mixed language. Generate the title, abstract, and keywords in Chinese."
                format_instruction = """
标题：
[在这里写标题]

摘要：
[在这里写摘要]

关键词：
[关键词1；关键词2；关键词3]
"""

            prompt = f"""Please read the following article and generate a clear title, a detailed abstract of about 300-500 words, and 3-8 keywords.

Article:
{article_content}

Instructions:
1. {lang_instruction}
            2. The title should be specific and no longer than 30 Chinese characters or 20 English words.
            3. The abstract should be richer than a short summary and include the main topic, approach, results, and limitations when available.
3. The abstract should summarize the research question, method, evidence, and conclusion.
4. Keywords should be separated by semicolons.
5. Do not include extra commentary outside the required format.

{format_instruction}
"""
            # 鐠嬪啰鏁?PANGU 濡€崇€烽悽鐔稿灇
            headers = {'Content-Type': 'application/json'}

            logger.info("濮濓絽婀拫鍐暏 PANGU 濡€崇€烽悽鐔稿灇閺嶅洭顣介妴浣规喅鐟曚礁鎷伴崗鎶芥暛鐠?..")
            response = requests.post(
                url=PANGU_URL,
                headers=headers,
                json={
                    "model": model_name,
                    "messages": [
                        {"role": "system", "content": "You are a research assistant. Return only the requested title, abstract, and keywords."},
                        {"role": "user", "content": prompt}
                    ],
                    "temperature": 0.3
                },
                verify=False,
                timeout=300
            )

            # 鐟欙絾鐎介崫宥呯安
            response.raise_for_status()
            result_data = response.json()
            result_text = result_data['choices'][0]['message']['content']

            logger.info("\n" + "=" * 60)
            logger.info(f"{model_name} response received")
            logger.info(result_text)
            logger.info("=" * 60 + "\n")

            def clean_value(value: str) -> str:
                value = re.sub(r"\s+", " ", value or "").strip()
                return re.sub(r"^[：:;；\-\s]+", "", value).strip()

            def extract_section(labels, stop_labels):
                label_pattern = "|".join(re.escape(label) for label in labels)
                stop_pattern = "|".join(re.escape(label) for label in stop_labels)
                pattern = rf"(?:{label_pattern})\s*[：:]?\s*(.*?)(?=\n\s*(?:{stop_pattern})\s*[：:]?|$)"
                match = re.search(pattern, result_text, re.IGNORECASE | re.DOTALL)
                return clean_value(match.group(1)) if match else ""

            title = extract_section(["Title", "标题"], ["Abstract", "摘要", "Keywords", "关键词"])
            abstract = extract_section(["Abstract", "摘要"], ["Keywords", "关键词"])
            keywords = extract_section(["Keywords", "关键词"], [])

            if not title:
                title_from_content = re.search(r"^#\s+(.+)$", article_content, re.MULTILINE)
                title = clean_value(title_from_content.group(1)) if title_from_content else "Untitled"
            if not abstract:
                abstract = clean_value(result_text[:300]) if len(result_text) > 50 else "No abstract generated."
            if not keywords:
                keywords = "No keywords generated."

            logger.info(f"Parsed metadata: title={bool(title)}, abstract_len={len(abstract)}, keywords={bool(keywords)}")
            return {
                "title": title,
                "abstract": abstract,
                "keywords": keywords,
            }

        except Exception as e:
            import traceback
            logger.error(f"Failed to generate abstract and keywords: {e}")
            logger.debug(traceback.format_exc())
            return {
                "title": "Untitled",
                "abstract": "Failed to generate abstract.",
                "keywords": "Failed to generate keywords.",
            }
    def file_read_dq(self, file_path: str, encoding: str = 'utf-8') -> MCPToolResult:
        """Read file content with multi-encoding fallback"""
        try:
            full_path = self._safe_join(file_path)

            if not full_path.exists():
                return MCPToolResult(
                    success=False,
                    error=f"File does not exist: {file_path}"
                )

            # Try multiple encodings in fallback order
            encodings_to_try = [encoding] if encoding != 'utf-8' else []
            encodings_to_try.extend(['utf-8', 'utf-8-sig', 'gbk', 'gb2312', 'latin-1'])
            content = None
            used_encoding = None
            for enc in encodings_to_try:
                try:
                    content = full_path.read_text(encoding=enc)
                    used_encoding = enc
                    break
                except (UnicodeDecodeError, UnicodeError):
                    continue
            if content is None:
                return MCPToolResult(
                    success=False,
                    error=f"File cannot be decoded with any known encoding: {file_path}"
                )

            if len(content) > 40000:
                content = (
                    "Due to the content being too long, only the first 30,000 and last 10,000 characters are returned.\n"
                    "Below is the returned portion of the file content:\n\n"
                    f"First 30,000 characters:\n\n{content[:30000]}\n\n"
                    f"Last 10,000 characters:\n\n{content[-10000:]}"
                )

            return MCPToolResult(
                success=True,
                data=content,
                metadata={
                    'file_size': len(content),
                    'line_count': len(content.splitlines()),
                    'encoding': used_encoding
                }
            )

        except Exception as e:
            logger.error(f"File read failed: {e}")
            return MCPToolResult(success=False, error=str(e))

    def load_json(self, file_path: str, encoding: str = 'utf-8') -> MCPToolResult:
        """
        Read JSON format file 
        """
        try:
            full_path = self._safe_join(file_path)

            if not full_path.exists():
                return MCPToolResult(
                    success=False,
                    error=f"File does not exist: {file_path}"
                )

            res = []

            with open(full_path, "r", encoding=encoding, errors='ignore') as f:
                for idx, line in enumerate(f):
                    try:
                        ele = json.loads(line.strip())
                        res.append(ele)
                    except Exception as e:
                        logger.warning(f"Failed to process file: {e}")
                        continue

            return MCPToolResult(
                success=True,
                data=res,
                metadata={
                    'line_count': len(res),
                    'encoding': encoding
                }
            )

        except Exception as e:
            logger.error(f"File read failed: {e}")
            return MCPToolResult(success=False, error=str(e))

    def extract_author_and_title_for_reference(self, article_content: str, source_info: str = "") -> Dict[str, str]:
        """Extract author, title, and source metadata for references."""
        try:
            import requests
            model_config = get_config().get_custom_llm_config()
            pangu_url = model_config.get("url") or os.getenv("MODEL_REQUEST_URL", "")
            model_name = model_config.get("model") or os.getenv("MODEL_NAME", "")
            content_excerpt = article_content[:500] if len(article_content) > 500 else article_content

            prompt = f"""Extract reference metadata from the following article excerpt.

Source information:
{source_info or "Unknown source"}

Article excerpt:
{content_excerpt}

Return exactly this format:
Author:
[author or Unknown]

Title:
[title or Unknown]

Source:
[source or Unknown]
"""
            headers = {"Content-Type": "application/json"}
            response = requests.post(
                url=pangu_url,
                headers=headers,
                json={
                    "model": model_name,
                    "messages": [
                        {"role": "system", "content": "You extract bibliographic metadata. Return only Author, Title, and Source."},
                        {"role": "user", "content": prompt},
                    ],
                    "temperature": 0.2,
                },
                verify=False,
                timeout=300,
            )
            response.raise_for_status()
            result_data = response.json()
            result_text = result_data["choices"][0]["message"]["content"]
            logger.info(f"{model_name} metadata response received")

            def clean_value(value: str) -> str:
                value = re.sub(r"\s+", " ", value or "").strip()
                return re.sub(r"^[：:;；\-\s]+", "", value).strip()

            def extract_section(labels, stop_labels):
                label_pattern = "|".join(re.escape(label) for label in labels)
                stop_pattern = "|".join(re.escape(label) for label in stop_labels)
                pattern = rf"(?:{label_pattern})\s*[：:]?\s*(.*?)(?=\n\s*(?:{stop_pattern})\s*[：:]?|$)"
                match = re.search(pattern, result_text, re.IGNORECASE | re.DOTALL)
                return clean_value(match.group(1)) if match else ""

            author = extract_section(["Author", "作者"], ["Title", "标题", "Source", "来源"])
            title = extract_section(["Title", "标题"], ["Source", "来源"])
            source = extract_section(["Source", "来源"], [])

            if not title:
                heading = re.search(r"^#\s+(.+)$", article_content, re.MULTILINE)
                title = clean_value(heading.group(1)) if heading else "Unknown"
            if not author:
                author = "Unknown"
            if not source:
                source = source_info or "Unknown"

            return {"author": author, "title": title, "source": source}
        except Exception as e:
            logger.error(f"Failed to extract reference metadata: {e}")
            return {
                "author": "Unknown",
                "title": "Unknown",
                "source": source_info or "Unknown",
            }
    def insert_abstract_and_keywords_to_file(self, file_path: str, title: str = "", abstract: str = "",
                                             keywords: str = "", username: str = "default"):
        """Insert title, abstract, and keywords at the top of a Markdown/text file."""
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                original_content = f.read()

            content = original_content.lstrip()
            if title:
                lines = content.splitlines()
                if lines and re.match(r"^\s*#\s+", lines[0]):
                    existing_title = re.sub(r"^\s*#\s+", "", lines[0]).strip()
                    if existing_title == title or title in existing_title or existing_title in title:
                        content = "\n".join(lines[1:]).lstrip()

            chinese_chars = re.findall(r"[\u4e00-\u9fff]", (title or "") + (abstract or ""))
            is_english = len(chinese_chars) < 5
            abstract_label = "Abstract" if is_english else "摘要"
            keywords_label = "Keywords" if is_english else "关键词"

            header_parts = []
            if title:
                header_parts.append(f"# {title}")
            if abstract:
                header_parts.append(f"**{abstract_label}:** {abstract}")
            if keywords:
                header_parts.append(f"**{keywords_label}:** {keywords}")

            new_content = "\n\n".join(header_parts)
            if new_content and content:
                new_content = new_content + "\n\n" + content
            elif content:
                new_content = content

            with open(file_path, "w", encoding="utf-8") as f:
                f.write(new_content)

            logger.info(f"Inserted metadata into file: {file_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to insert abstract and keywords: {e}")
            return False
    def _normalize_heading_levels(self, content: str) -> str:
        """
        鐟欏嫯瀵栭崠鏈歛rkdown閺嶅洭顣界仦鍌滈獓閿涘瞼鈥樻穱婵堢彿閼哄倹鐖ｆ０妯硅礋娴滃瞼楠囬弽鍥暯閿涘瞼鐝烽懞鍌氬敶閺嶅洭顣芥笟婵囶偧闁帒顤?

        婢х偛宸遍崝鐔诲厴閿?
        - 濡偓濞村鑻熸潪顒佸床闂堟康arkdown閺嶇厧绱￠惃鍕彿閼哄倹鐖ｆ０?
        - 绾喕绻氱粭顑跨娑擃亪娼粚楦款攽閺勵垯绨╃痪褎鐖ｆ０姗堢礄缁旂姾濡弽鍥暯閿?
        - 鐟欏嫯瀵栭崠鏍ㄥ閺堝鐡欓弽鍥暯鐏炲倻楠?

        Args:
            content: 缁旂姾濡崘鍛啇

        Returns:
            鐟欏嫯瀵栭崠鏍ф倵閻ㄥ嫬鍞寸€?
        """
        lines = content.split('\n')
        normalized_lines = []
        first_heading_found = False
        current_chapter_level = 0
        first_content_line = True

        for line in lines:
            stripped_line = line.strip()

            # 鐠哄疇绻冪粚楦款攽閿涘瞼娲块崚鐗堝閸掓壆顑囨稉鈧稉顏勫敶鐎圭顢?
            if first_content_line and not stripped_line:
                normalized_lines.append(line)
                continue

            # 濡偓濞村妲搁崥锔芥ЦMarkdown閺嶅洭顣介敍鍫滀簰#瀵偓婢惰揪绱?
            heading_match = re.match(r'^(#+)\s+(.+)$', stripped_line)

            # 濡偓濞村妲搁崥锔芥Ц缁ぞ缍嬮弽鍥暯閿?*xxx**閺嶇厧绱￠敍灞藉讲閼崇晫鏁ゆ担婊勭垼妫版﹫绱?
            bold_match = re.match(r'^\*\*(.+?)\*\*\s*$', stripped_line)

            if heading_match:
                hash_symbols = heading_match.group(1)
                heading_text = heading_match.group(2)
                current_level = len(hash_symbols)

                # 婵″倹鐏夐弰顖滎儑娑撯偓娑擃亝鐖ｆ０姗堢礉鐏忓棗鍙剧拋鍙ヨ礋娴滃瞼楠囬弽鍥暯閿涘牏鐝烽懞鍌涚垼妫版﹫绱?
                if not first_heading_found:
                    first_heading_found = True
                    first_content_line = False
                    current_chapter_level = current_level
                    # 绾喕绻氱粩鐘哄Ν閺嶅洭顣芥稉杞扮癌缁狙勭垼妫版﹫绱濋崢濠氭珟閸欘垵鍏橀惃鍕煐娴ｆ挻鐖ｇ拋?
                    heading_text_clean = re.sub(r'^\*\*(.+?)\*\*$', r'\1', heading_text)
                    normalized_lines.append(f"## {heading_text_clean}")
                else:
                    # 鐠侊紕鐣婚惄绋款嚠娴滃海鐝烽懞鍌涚垼妫版娈戠仦鍌滈獓瀹?
                    level_diff = current_level - current_chapter_level
                    # 閺傛壆娈戦弽鍥暯鐏炲倻楠?= 3閿涘牆娲滄稉铏圭彿閼哄倹妲?缁狙嶇礆+ 鐏炲倻楠囧?
                    new_level = max(3, 3 + level_diff)
                    # 闂勬劕鍩楅張鈧径褎鐖ｆ０妯虹湴缁狙傝礋6
                    new_level = min(new_level, 6)
                    # 閸樺娅庨弽鍥暯娑擃厾娈戠划妞剧秼閺嶅洩顔?
                    heading_text_clean = re.sub(r'^\*\*(.+?)\*\*$', r'\1', heading_text)
                    normalized_lines.append(f"{'#' * new_level} {heading_text_clean}")
            elif bold_match and not first_heading_found:
                # 婵″倹鐏夌粭顑跨娑擃亜鍞寸€硅妲哥划妞剧秼閺傚洦婀版稉鏃囩箷濞屸剝婀侀幍鎯у煂閺嶅洭顣介敍灞界殺閸忔儼娴嗛幑顫礋娴滃瞼楠囬弽鍥暯
                first_heading_found = True
                first_content_line = False
                current_chapter_level = 2
                heading_text = bold_match.group(1)
                normalized_lines.append(f"## {heading_text}")
            elif first_content_line and stripped_line and not first_heading_found:
                # 婵″倹鐏夌粭顑跨娑擃亪娼粚楦款攽娑撳秵妲搁弽鍥暯閺嶇厧绱￠敍灞肩瘍娑撳秵妲哥划妞剧秼閿涘奔绲鹃惇瀣崳閺夈儱鍎氶弽鍥暯閿涘牏鐓弬鍥ㄦ拱閿涘奔绗夋禒銉︾垼閻愬湱绮ㄧ亸鎾呯礆
                # 濡偓閺屻儲妲搁崥锕€鍎氶弽鍥暯閿涙岸鏆辨惔锕傗偓鍌欒厬閿?100鐎涙顑侀敍澶夌瑬娑撳秳浜掗崣銉ュ娇閵嗕線妫堕崣椋庣搼缂佹挸鐔?
                if len(stripped_line) < 100 and not re.search(r'[閵嗗偊绱甸敍??!]$', stripped_line):
                    first_heading_found = True
                    first_content_line = False
                    current_chapter_level = 2
                    # 閸樺娅庨崣顖濆厴閻ㄥ嫮鐭栨担鎾寸垼鐠?
                    heading_text = re.sub(r'^\*\*(.+?)\*\*$', r'\1', stripped_line)
                    normalized_lines.append(f"## {heading_text}")
                else:
                    # 娑撳秴鍎氶弽鍥暯閿涘奔绻氶幐浣稿斧閺嶅嚖绱濇担鍡樼垼鐠佹澘鍑＄紒蹇斿閸掓壆顑囨稉鈧稉顏勫敶鐎?
                    first_content_line = False
                    normalized_lines.append(line)
            else:
                # 闂堢偞鐖ｆ０妯款攽娣囨繃瀵旀稉宥呭綁
                first_content_line = False
                normalized_lines.append(line)

        return '\n'.join(normalized_lines)

    def merge_reports(self, section_contents, output_file, unique_id=None):
        """Merge report section files into one Markdown file."""
        try:
            output_path = Path(output_file)
            if not output_path.is_absolute():
                output_path = self.workspace_path / output_path
            output_path.parent.mkdir(parents=True, exist_ok=True)

            report_files = []
            for item in section_contents or []:
                if isinstance(item, dict):
                    candidate = item.get("file_path") or item.get("path") or item.get("output_file")
                else:
                    candidate = item
                if not candidate:
                    continue
                path = Path(candidate)
                if not path.is_absolute():
                    path = self.workspace_path / path
                if path.exists():
                    report_files.append(path)

            if not report_files:
                search_root = output_path.parent if output_path.parent.exists() else self.workspace_path
                report_files = sorted(search_root.glob("part_*.md"), key=lambda p: p.name)

            def extract_index(path: Path):
                match = re.search(r"part_(\d+)\.md", path.name)
                return int(match.group(1)) if match else 10**9

            report_files = sorted(report_files, key=extract_index)
            if not report_files:
                logger.warning("No report section files found for merge.")
                output_path.write_text("", encoding="utf-8")
                return

            merged_parts = []
            for path in report_files:
                try:
                    content = path.read_text(encoding="utf-8", errors="ignore").strip()
                    if content:
                        merged_parts.append(self._normalize_heading_levels(content))
                except Exception as exc:
                    logger.warning(f"Failed to read report section {path}: {exc}")

            output_path.write_text("\n\n".join(merged_parts).strip() + "\n", encoding="utf-8")
            logger.info(f"Merged {len(merged_parts)} report sections into {output_path}")
        except Exception as exc:
            logger.error(f"Failed to merge reports: {exc}")
    def concat_section_files(
            self,
            section_files: List[Dict],
            final_file_path: str
    ) -> MCPToolResult:
        """
        Concatenate the content of the saved section files into a single file
        """
        try:
            logger.info(f"concat_section_files: {len(section_files) if section_files else 0} files -> {final_file_path}")

            # Ensure output directory exists
            import os
            output_dir = os.path.dirname(final_file_path)
            if output_dir:
                os.makedirs(output_dir, exist_ok=True)

            # Convert relative path to absolute if needed
            if not os.path.isabs(final_file_path):
                final_file_path = self.workspace_path / final_file_path

            # 鐠囪褰噑ection_files娑擃厾娈戦弬鍥︽閸愬懎顔愰敍灞借嫙閼惧嘲褰囬幗妯款洣閸滃苯鍙ч柨顔跨槤
            # 閻㈢喐鍨氶崺杞扮艾閺冨爼妫块幋宕囨畱閸烆垯绔碔D閿涘矂浼╅崗宥咁樋鏉烆喖顕拠婵呰厬閻ㄥ嫰鏁嬮悙鐟板暱缁?
            import time
            unique_id = f"msg_{int(time.time() * 1000)}"
            abstract_keywords = self.merge_reports(section_files, final_file_path, unique_id)

            # 婵″倹鐏夊▽鈩冩箒鏉╂柨娲栭幗妯款洣閸滃苯鍙ч柨顔跨槤閿涘矁顔曠純顕€绮拋銈呪偓?
            if abstract_keywords is None:
                abstract_keywords = {"abstract": "", "keywords": ""}

            return MCPToolResult(
                success=True,
                data={
                    "merged_files": len(section_files),
                    "output_path": str(final_file_path),
                    "abstract": abstract_keywords.get("abstract", ""),
                    "keywords": abstract_keywords.get("keywords", "")
                },
                metadata={
                    'final_file_path': str(final_file_path),
                    'section_count': len(section_files),
                    'abstract': abstract_keywords.get("abstract", ""),
                    'keywords': abstract_keywords.get("keywords", "")
                }
            )
        except Exception as e:
            logger.error(f"Concatenate section files failed: {e}")
            return MCPToolResult(success=False, error=str(e))

    def _validate_file_allocation(
            self,
            classification_result: str,
            user_file_count: int,
            research_file_count: int,
            has_user_files: bool
    ) -> Dict:
        """Validate whether file allocation output matches the available file sets."""
        try:
            # 缂佺喕顓搁崚鍡涘帳閻ㄥ嫭鏋冩禒鑸垫殶闁?
            user_files_assigned = classification_result.count('user_uploads')
            research_files_assigned = classification_result.count('research/')

            # 鐠侊紕鐣绘０鍕埂閸?
            if has_user_files and research_file_count > 0:
                # 濞ｅ嘲鎮庨崷鐑樻珯
                expected_user = user_file_count  # 100%
                if user_file_count >= 8:
                    expected_research_pct = 70
                elif user_file_count >= 5:
                    expected_research_pct = 80
                else:
                    expected_research_pct = 90
                expected_research_min = int(research_file_count * expected_research_pct / 100)

                # 妤犲矁鐦?
                user_valid = user_files_assigned >= expected_user * 0.8  # 閸忎浇顔?0%鐎圭懓妯?
                research_valid = research_files_assigned >= expected_research_min * 0.5  # 閸忎浇顔?0%鐎圭懓妯?

                if not user_valid or not research_valid:
                    return {
                        "valid": False,
                        "message": f"Mixed scenario: User files {user_files_assigned}/{expected_user}, Research files {research_files_assigned}/{expected_research_min}",
                        "expected": f"User: {expected_user} (100%), Research: {expected_research_min} ({expected_research_pct}%)",
                        "actual": f"User: {user_files_assigned}, Research: {research_files_assigned}"
                    }

            elif research_file_count > 0:
                # 閸欘亝婀乺esearch閺傚洣娆㈤崷鐑樻珯
                if research_file_count >= 30:
                    expected_research_pct = 85
                elif research_file_count >= 20:
                    expected_research_pct = 90
                elif research_file_count >= 10:
                    expected_research_pct = 95
                else:
                    expected_research_pct = 100

                expected_research_min = int(research_file_count * expected_research_pct / 100)
                research_valid = research_files_assigned >= expected_research_min * 0.7  # 閸忎浇顔?0%鐎圭懓妯?

                if not research_valid:
                    return {
                        "valid": False,
                        "message": f"Research-only scenario: {research_files_assigned}/{expected_research_min} files assigned",
                        "expected": f"Research: {expected_research_min} ({expected_research_pct}%)",
                        "actual": f"Research: {research_files_assigned}"
                    }

            return {
                "valid": True,
                "message": "File allocation meets requirements",
                "expected": "N/A",
                "actual": f"User: {user_files_assigned}, Research: {research_files_assigned}"
            }

        except Exception as e:
            logger.error(f"Validation error: {e}")
            return {
                "valid": True,  # 妤犲矁鐦夋径杈Е閺冩湹绗夐梼缁橆剾濞翠胶鈻?
                "message": f"Validation error: {e}",
                "expected": "N/A",
                "actual": "N/A"
            }

    def search_result_classifier(
            self,
            outline: str,
            key_files: List[Dict],
            model: str = "gpt-4o",
            temperature: float = 0.3,
            max_tokens: int = 4000
    ) -> MCPToolResult:
        """
        Classify and organize search result files according to a structured outline for comprehensive long-form content generation.

        Args:
            outline: Structured outline defining the sections and subsections for organizing the long-form content
            key_files: List of key files to classify
            model: AI model to use for classification and organization
            temperature: Creativity level for the AI classification (0-1)
            max_tokens: Maximum tokens for the AI response
        """
        try:
            logger.info(f"search_result_classifier: outline_len={len(outline) if outline else 0}, files={len(key_files) if key_files else 0}")
            # 婢跺嫮鎮婃潏鎾冲弳閻ㄥ埍ey_files - 娴ｈ法鏁ら崶娑楅嚋閸掑棙鐎界紒鏉戝
            # 閼惧嘲褰囬張顒€婀撮惃鍕瀮娴犳儼绻樼悰灞藉瀻閺?

            import os
            import json
            def load_json(file_path):
                res = []
                error_lines = 0
                with open(file_path, 'rb') as file:
                    for line in file:
                        try:
                            line.decode('utf-8')
                        except UnicodeDecodeError:
                            error_lines = error_lines + 1
                with open(file_path, "r", encoding="utf-8", errors='ignore') as f:
                    for idx, line in enumerate(f):
                        try:
                            ele = json.loads(line.strip())
                            res.append(ele)
                        except Exception as e:
                            logger.info(e)
                            continue
                return res

            key_files_dict = {}
            # Create full path relative to workspace
            full_analysis_path = self.workspace_path / "doc_analysis/file_analysis.jsonl"
            file_analysis_list = load_json(full_analysis_path)

            for file_info in file_analysis_list:
                if file_info.get('file_path'):
                    key_files_dict[file_info.get('file_path')] = file_info

            # 缂佸嫯顥妅ey_files
            prompt_files = ""
            if key_files:
                prompt_files += f"Key Files with Multi-Dimensional Analysis:\n"
                for i, file_info in enumerate(key_files, 1):
                    if file_info.get('file_path') in key_files_dict:
                        file_info = key_files_dict[file_info.get('file_path')]
                        prompt_files += f"\n{i}. File: {file_info.get('file_path', 'Unknown')}\n"
                        prompt_files += f"   Document Time: {file_info.get('doc_time', 'Not specified')}\n"
                        prompt_files += f"   Source Authority: {file_info.get('source_authority', 'Not specified')}\n"
                        prompt_files += f"   Core Content: {file_info.get('core_content', 'Not specified')}\n"
                        prompt_files += f"   Task Relevance: {file_info.get('task_relevance', 'Not specified')}\n"
                        prompt_files += f"   Information Richness: {file_info.get('information_richness', 'Not specified')}\n"
                        prompt_files += "\n"

                prompt_files += "\n"

            # 濡偓閺屻儲妲搁崥锔芥箒閻劍鍩涙稉濠佺炊閻ㄥ嫭鏋冩禒璺烘嫲research閺傚洣娆?
            has_user_files = any('user_uploads' in f.get('file_path', '') for f in key_files)
            user_file_count = sum(1 for f in key_files if 'user_uploads' in f.get('file_path', ''))
            research_file_count = sum(1 for f in key_files if 'research' in f.get('file_path', ''))

            user_file_priority_note = ""
            if has_user_files and research_file_count > 0:
                # 閸斻劍鈧浇顓哥粻妤佺槨缁旂姾濡惃鍕瀮娴犺泛鍨庨柊宥囨窗閺?
                # 缁涙牜鏆愰敍姘躬娣囨繆鐦夐悽銊﹀煕閺傚洣娆㈡导妯哄帥閻ㄥ嫬澧犻幓鎰瑓閿涘本娓舵径褍瀵查幀璇茬穿閻劍鏋冮悮顔芥殶闁?

                # 閻劍鍩涢弬鍥︽閻╊喗鐖ｉ敍姘繁閸掓湹濞囬悽銊﹀閺堝鏋冩禒璁圭礉绾喕绻?00%鐟曞棛娲?
                if user_file_count >= 8:
                    user_target_per_section = "ALL user files distributed across sections"
                    user_min_per_section = min(6, user_file_count)  # 閹绘劙鐝張鈧担搴ゎ洣濮?
                    user_coverage_goal = f"Use ALL {user_file_count} user files (100% MANDATORY)"
                elif user_file_count >= 5:
                    user_target_per_section = f"ALL {user_file_count} user files"
                    user_min_per_section = min(5, user_file_count)  # 閹绘劙鐝張鈧亸鎴ｎ洣濮?
                    user_coverage_goal = f"Use ALL {user_file_count} user files (100% MANDATORY)"
                elif user_file_count >= 3:
                    user_target_per_section = f"ALL {user_file_count} user files (distribute across sections)"
                    user_min_per_section = min(3, user_file_count)
                    user_coverage_goal = f"Use ALL {user_file_count} files (100% MANDATORY), assign to MULTIPLE sections"
                else:  # 1-2娑擃亞鏁ら幋閿嬫瀮娴?
                    user_target_per_section = f"ALL {user_file_count} user file(s)"
                    user_min_per_section = user_file_count
                    user_coverage_goal = f"Use ALL {user_file_count} file(s) (100% MANDATORY), assign to MULTIPLE sections"

                # Research閺傚洣娆㈤惄顔界垼閿涙碍娓舵径褍瀵叉担璺ㄦ暏閿涘瞼鈥樻穱婵囨纯婢舵碍鏋冮悮顔款潶瀵洜鏁?
                # 閺嶈宓侀悽銊﹀煕閺傚洣娆㈤弫浼村櫤閸斻劍鈧浇鐨熼弫纾杄search閺傚洣娆㈤惃鍕▏閻劍鐦笟?
                if user_file_count >= 8:
                    # 閻劍鍩涢弬鍥︽閸忓懓鍐婚弮璁圭礉闁倸瀹虫担璺ㄦ暏research閺傚洣娆?
                    research_min_per_section = min(4, research_file_count)  # 閹绘劙鐝張鈧亸鎴ｎ洣濮瑰倷绮?閸?
                    research_target_per_section = min(6, max(5, research_file_count // 3))  # 閹绘劙鐝惄顔界垼
                    research_coverage_pct = 80  # 閹绘劙鐝憰鍡欐磰閻滃洣绮?0%閸?0%
                elif user_file_count >= 5:
                    # 閻劍鍩涢弬鍥︽娑擃厾鐡戦弮璁圭礉婢х偛濮瀝esearch閺傚洣娆㈡担璺ㄦ暏
                    research_min_per_section = min(4, research_file_count)  # 閹绘劙鐝張鈧亸鎴ｎ洣濮?
                    research_target_per_section = min(7, max(5, research_file_count // 2))  # 閹绘劙鐝惄顔界垼
                    research_coverage_pct = 85  # 85%鐟曞棛娲婇悳?
                else:
                    # 閻劍鍩涢弬鍥︽鐏忔垶妞傞敍灞姐亣闁插繋濞囬悽鈺甧search閺傚洣娆?
                    research_min_per_section = min(5, research_file_count)  # 閺堚偓鐏?娑?
                    research_target_per_section = min(8, max(6, research_file_count // 2))  # 閹绘劙鐝惄顔界垼
                    research_coverage_pct = 90  # 90%鐟曞棛娲婇悳?

                user_file_priority_note = f"""
RESEARCH FILES ONLY SCENARIO
- Research files available: {research_file_count}.
- Assign at least {int(research_file_count * research_coverage_pct / 100)} files ({research_coverage_pct}%).
- Each section should include at least {research_min_per_section} research files when possible.
- Target per section: {research_target_per_section}.
- Maximize citations while keeping section relevance.
"""
            elif research_file_count > 0:
                # PRIMARY SCENARIO: Only research files, no user files
                # This is the MAIN use case - MAXIMIZE research file citations

                # 閸斻劍鈧浇顓哥粻妤冩窗閺嶅浄绱濋弽瑙勫祦research閺傚洣娆㈤弫浼村櫤娴兼ê瀵查崚鍡涘帳
                if research_file_count >= 30:
                    # 婢堆囧櫤research閺傚洣娆㈤敍?0+閿?
                    research_target_per_section = "10-11 research files"
                    research_min_per_section = 8
                    research_coverage_pct = 85  # 閻╊喗鐖ｆ担璺ㄦ暏85%
                elif research_file_count >= 20:
                    # 娑擃厾鐡戦弫浼村櫤research閺傚洣娆㈤敍?0-29閿?
                    research_target_per_section = "9-11 research files"
                    research_min_per_section = 7
                    research_coverage_pct = 90  # 閻╊喗鐖ｆ担璺ㄦ暏90%
                elif research_file_count >= 10:
                    # 鏉堝啫鐨痳esearch閺傚洣娆㈤敍?0-19閿?
                    research_target_per_section = "8-10 research files"
                    research_min_per_section = 6
                    research_coverage_pct = 95  # 閻╊喗鐖ｆ担璺ㄦ暏95%
                else:
                    # 瀵板牆鐨痳esearch閺傚洣娆㈤敍?10閿?
                    research_target_per_section = f"ALL {research_file_count} research files"
                    research_min_per_section = min(research_file_count, 5)
                    research_coverage_pct = 100  # 閻╊喗鐖ｆ担璺ㄦ暏100%

                user_file_priority_note = f"""
RESEARCH FILES ONLY SCENARIO
- Research files available: {research_file_count}.
- Assign at least {int(research_file_count * research_coverage_pct / 100)} files ({research_coverage_pct}%).
- Each section should include at least {research_min_per_section} research files when possible.
- Target per section: {research_target_per_section}.
- Maximize citations while keeping section relevance.
"""

            system_prompt = f"""
You are an expert content organizer. Classify the available files against the outline.

Rules:
- Preserve the outline text and heading structure exactly.
- Assign relevant files to each first-level section.
- Use multiple files per section when useful, but do not exceed 11 files per section.
- If both user-uploaded and research files are available, include both types when possible.
- Prefer direct relevance, then supporting context, then background evidence.

{user_file_priority_note}

Output format:
paragraph 1: ...
file_path_list: file_path1, file_path2, ...

paragraph 2: ...
file_path_list: file_path3, file_path4, ...
"""
            # 閺嬪嫬缂撻悽銊﹀煕閹绘劗銇?- 娴犲懎瀵橀崥顐ョ翻閸忋儲鏆熼幑?
            user_prompt = f"""
OUTLINE TO ORGANIZE CONTENT:
{outline}

{prompt_files}
"""

            model_config = get_config().get_custom_llm_config()
            # PANGU 濡€崇€烽柊宥囩枂
            PANGU_URL = model_config.get('url') or os.getenv('MODEL_REQUEST_URL', '')
            model_name = model_config.get('model') or os.getenv("MODEL_NAME", "")
        
            headers = {'Content-Type': 'application/json'}

            import requests
            import litellm
            try:
                # Add retry logic for AI model call
                max_retries = 5
                response = None

                for attempt in range(max_retries):
                    try:
                        response = requests.post(
                            url=PANGU_URL,
                            headers=headers,
                            json={
                                "model": model_name,
                                "chat_template": "{% for message in messages %}{% if loop.first and messages[0]['role'] != 'system' %}{{ '[unused9]缁崵绮洪敍姝攗nused10]' }}{% endif %}{% if message['role'] == 'system' %}{{ message['content'] }}{% endif %}{% if message['role'] == 'assistant' %}{{'[unused9]閸斺晜澧滈敍? + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'tool' %}{{'[unused9]瀹搞儱鍙块敍? + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'function' %}{{'[unused9]閺傝纭堕敍? + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'user' %}{{'[unused9]閻劍鍩涢敍? + message['content'] + '[unused10]'}}{% endif %}{% endfor %}{% if add_generation_prompt %}{{ '[unused9]閸斺晜澧滈敍? }}{% endif %}",
                                "messages": [
                                    {"role": "system", "content": "You are a research assistant. Return only the requested title, abstract, and keywords."},
                                    {"role": "system", "content": system_prompt},
                                    {"role": "user", "content": user_prompt}
                                ],
                                "max_tokens": max_tokens,
                            },
                            verify=False
                        )
                        response = response.json()
                        logger.info(response)

                        break  # Success, exit retry loop
                    except Exception as e:
                        logger.warning(f"LLM API call attempt {attempt + 1} failed: {e}")
                        if attempt == max_retries - 1:
                            raise e  # Last attempt, re-raise the exception
                        time.sleep(5)  # Simple 1 second delay between retries

                if response is None:
                    raise Exception("Failed to get response after all retries")

                # ai_response = response.choices[0].message.content.strip()
                # 濞ｈ濮為梼鎻掑敖閹勵梾閺屻儻绱濋柆鍨帳NoneType闁挎瑨顕?
                # 閸忕厧顔?PANGU 濡€崇€烽敍姘喘閸忓牅濞囬悽?content閿涘苯顩ч弸婊€璐?None 閸掓瑤濞囬悽?reasoning_content
                message = response.get("choices", [{}])[0].get("message", {})
                content = message.get("content")

                # 婵″倹鐏?content 娑?None閿涘苯鐨剧拠鏇氬▏閻?reasoning_content
                if content is None:
                    content = message.get("reasoning_content")
                    if content is not None:
                        logger.info("Using reasoning_content as content is None")

                if content is None:
                    raise Exception(f"AI model returned None content and reasoning_content. Response: {response}")
                ai_response = content.strip()

                import os
                import json
                log_dir = "./data_pangu"
                log_file = os.path.join(log_dir, "search_result_classifier_claude_cold_start.log")
                os.makedirs(log_dir, exist_ok=True)

                # 閸掑洦宕叉穱婵嗙摠閻ㄥ嫭鏌熷?
                conversation_history = [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                    {"role": "assistant", "content": "[unused16][unused17]" + ai_response}
                ]
                with open(log_file, "a", encoding="utf-8") as f:
                    f.write(json.dumps({"messages": conversation_history}, ensure_ascii=False) + "\n")

                # 妤犲矁鐦夐弬鍥︽閸掑棝鍘ら弰顖氭儊缁楋箑鎮庣憰浣圭湴
                classification_result = ai_response.split('think>')[-1].strip()
                validation_result = self._validate_file_allocation(
                    classification_result,
                    user_file_count,
                    research_file_count,
                    has_user_files
                )

                if not validation_result["valid"]:
                    logger.warning(f"File allocation validation failed: {validation_result['message']}")
                    logger.warning(f"Expected: {validation_result['expected']}, Got: {validation_result['actual']}")

                return MCPToolResult(
                    success=True,
                    data=classification_result,
                )

            except Exception as e:
                logger.error(f"AI model call failed: {e}")
                return MCPToolResult(
                    success=False,
                    error=f"AI classification failed: {str(e)}"
                )

        except Exception as e:
            logger.error(f"Search result classifier failed: {e}")
            return MCPToolResult(success=False, error=str(e))

    @staticmethod
    def _correct_title_format(content: str, overall_outline: str) -> str:
        """
        Correct title formats in content to match those in overall_outline.

        Args:
            content: The generated chapter content
            overall_outline: The overall outline containing correct title formats

        Returns:
            Content with corrected title formats
        """
        # Extract titles from overall_outline
        outline_titles = {}

        for line in overall_outline.split('\n'):
            line = line.strip()
            if line:
                # Extract core title content by removing various formatting symbols
                core_content = line

                # Remove leading symbols like **, -, etc.
                core_content = re.sub(r'^[\*\-\s]+', '', core_content)
                # Remove trailing symbols like **
                core_content = re.sub(r'[\*\s]+$', '', core_content)
                core_content = core_content.strip()

                if core_content:
                    # Store mapping from core content to the formatted line from outline
                    outline_titles[core_content.lower()] = line

        # Process content line by line
        content_lines = content.split('\n')
        corrected_lines = []

        for line in content_lines:
            original_line = line
            line_stripped = line.strip()

            # Check if this line is a title (starts with # and typically has ** formatting)
            if line_stripped and re.match(r'^#+\s*[\*]*.*', line_stripped):
                # Extract core content from the title
                core_content = line_stripped

                # Remove markdown headers (#)
                core_content = re.sub(r'^#+\s*', '', core_content)
                # Remove ** formatting
                core_content = re.sub(r'^\*\*', '', core_content)
                core_content = re.sub(r'\*\*$', '', core_content)
                core_content = core_content.strip()

                # Look for exact matching title in outline_titles
                found_match = False
                core_content_lower = core_content.lower()

                for outline_core, outline_format in outline_titles.items():
                    if outline_core == core_content_lower:
                        # Replace with the correct format from overall_outline
                        corrected_lines.append(outline_format)
                        found_match = True
                        break

                if not found_match:
                    # If no exact match found, keep original line
                    corrected_lines.append(original_line)
            else:
                corrected_lines.append(original_line)

        return '\n'.join(corrected_lines)

    def section_writer(
            self,
            written_chapters_summary: str,
            task_content: str,
            user_query: str,
            current_chapter_outline: str,
            overall_outline: str,
            target_file_path: str,
            key_files: List[Dict],
            model: str = "pangu_auto",
            temperature: Optional[float] = None,
            max_tokens: Optional[int] = None
    ) -> MCPToolResult:
        """Write one report section from outline and source files."""
        try:
            # Get configuration
            from config.config import get_model_config, get_storage_config
            model_config = get_model_config()
            storage_config = get_storage_config()

            # Use config values or defaults
            if temperature is None:
                temperature = model_config.get('temperature', 0.3)
            if max_tokens is None:
                max_tokens = model_config.get('max_tokens', 8192)

            key_files_dict = {}
            # Create full path relative to workspace using config
            analysis_path = storage_config.get('document_analysis_path', './doc_analysis')
            file_analysis_list = self.load_json(f"{analysis_path}/file_analysis.jsonl").data
            logger.debug("File analysis loaded successfully")

            for i, file_info in enumerate(file_analysis_list, 1):
                file_info['index'] = i  # 閸︺劏绻栭柌宀€绮扮純鎴︺€夋潻娑滎攽缂傛牕褰块敍?娴?瀵偓婵?
                if file_info.get('file_path'):
                    key_files_dict[file_info.get('file_path')] = file_info

            prompt_files = ""
            if key_files:
                prompt_files += f"Web Information Source(s) As Follows::\n"
                for i, file_info in enumerate(key_files, 1):
                    if file_info.get('file_path') in key_files_dict:
                        file_info = key_files_dict[file_info.get('file_path')]
                        index = file_info.get('index')
                        # 闁俺绻僨ile_path閼惧嘲褰囬崢鐔奉潗缂冩垿銆夋穱鈩冧紖
                        file_path = file_info.get('file_path')

                        def get_file_head_content(file_path, max_length=10000):
                            try:
                                full_path = self._safe_join(file_path)
                                if not full_path.exists():
                                    return f"[Error: File does not exist: {file_path}]"
                                with open(full_path, 'r', encoding='utf-8', errors='ignore') as f:
                                    content = f.read(max_length)
                                return content
                            except Exception as e:
                                return f"[Error reading file {file_path}: {str(e)}]"

                        file_content = get_file_head_content(file_path)
                        doc_time = file_info.get('doc_time', 'Not specified')
                        source_authority = file_info.get('source_authority', 'Not specified')
                        task_relevance = file_info.get('task_relevance', 'Not specified')
                        # 瀵偓婵绮嶇憗鍛扮箹娴滄稑鐡у▓鐢垫畱閸?
                        prompt_files += f"\n[webpage{index} begin]\nDocument time: {doc_time}\nSource authority: {source_authority}\nTask relevance: {task_relevance}\nContent:\n{file_content}\n[webpage{index} end]"

            # 鐠佹崘顓竤ystem prompt
            # 濡偓閺屻儲妲搁崥锔芥箒閻劍鍩涙稉濠佺炊閻ㄥ嫭鏋冩禒?
            has_user_files = any('user_uploads' in f.get('file_path', '') for f in key_files)
            user_file_priority_note = ""
            if has_user_files:
                # 缂佺喕顓搁悽銊﹀煕閺傚洣娆㈤弫浼村櫤
                user_file_count = sum(1 for f in key_files if 'user_uploads' in f.get('file_path', ''))
                user_file_priority_note = f"""
USER-UPLOADED FILE PRIORITY
- User-uploaded files are highest priority when relevant.
- Cite assigned user-uploaded files with [X] whenever their content supports the chapter.
- If a user file is assigned to this chapter, review it carefully before deciding not to cite it.
- When sources conflict, prefer user-uploaded files unless they are clearly incorrect.
"""

            system_prompt = f"""
You are a research report writer.
{user_file_priority_note}
Rules:
        - Write only within the CURRENT CHAPTER OUTLINE and preserve all heading text and Markdown symbols.
        - Use only the provided source information. Do not invent facts.
        - Cite evidence inline with [X]. Cite every provided source at least once when it is relevant.
        - Do not write generic overview paragraphs without source-grounded evidence.
        - Every factual paragraph should contain citations tied to the specific supporting source.
        - If a source contains PDF page markers like [[page=N]], cite the PDF-backed claim as [X] (p. N).
        - Never invent page numbers. Use only page numbers present in the provided source text.
        - The chapter must be substantive, not compressed: aim for 3-5 paragraphs or roughly 600-1000 Chinese characters unless the source material is truly sparse.
        - Prefer explanation, comparison, synthesis, and implication over one-line recap.
        - Keep the output language consistent with the user query.
        - Return only <chapter_content>...</chapter_content>.
"""

            user_prompt = f"""TASK CONTENT: {task_content}
    WEB PAGE INFORMATION: {prompt_files}
    OVERALL OUTLINE: {overall_outline}
    CURRENT CHAPTER OUTLINE: {current_chapter_outline}
    PREVIOUSLY WRITTEN CHAPTERS SUMMARY: {written_chapters_summary}
    USER QUERY: {user_query}"""

            # 鐠嬪啰鏁I濡€崇€锋潻娑滎攽閸掑棛琚?
            # Get model URL and token from config
            config = get_config()
            model_config = config.get_custom_llm_config()

            model_url = model_config.get('url') or os.getenv('MODEL_REQUEST_URL', '')
            model_token = model_config.get('token') or os.getenv('MODEL_REQUEST_TOKEN', '')
            headers = {'Content-Type': 'application/json', 'csb-token': model_token}
            try:
                max_retries = 5
                response = None
                for attempt in range(max_retries):
                    try:
                        response = requests.post(
                            url=model_url,
                            headers=headers,
                            json={
                                "model": model_config.get('model', 'pangu_auto'),
                                "chat_template": "{% for message in messages %}{% if loop.first and messages[0]['role'] != 'system' %}{{ '<s>[unused9]缁崵绮洪敍姝攗nused10]' }}{% endif %}{% if message['role'] == 'system' %}{{'<s>[unused9]缁崵绮洪敍? + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'assistant' %}{{'[unused9]閸斺晜澧滈敍? + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'tool' %}{{'[unused9]瀹搞儱鍙块敍? + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'function' %}{{'[unused9]閺傝纭堕敍? + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'user' %}{{'[unused9]閻劍鍩涢敍? + message['content'] + '[unused10]'}}{% endif %}{% endfor %}{% if add_generation_prompt %}{{ '[unused9]閸斺晜澧滈敍? }}{% endif %}",
                                "messages": [
                                    {"role": "system", "content": system_prompt},
                                    {"role": "user", "content": user_prompt + " /no_think"}
                                ],
                                "spaces_between_special_tokens": False,
                                "max_tokens": max_tokens,
                                "temperature": temperature,
                            },
                            timeout=model_config.get("timeout", 180)
                        )
                        response = response.json()
                        logger.debug(f"API response received")

                        break  # Success, exit retry loop
                    except Exception as e:
                        logger.warning(f"LLM API call attempt {attempt + 1} failed: {e}")
                        if attempt == max_retries - 1:
                            raise e  # Last attempt, re-raise the exception
                        time.sleep(5)  # Simple 1 second delay between retries

                if response is None:
                    raise Exception("Failed to get response after all retries")

                # ai_response = response.choices[0].message.content.strip()
                ai_response = response["choices"][0]["message"]["content"].strip()

                # Extract content from first response
                content = ""
                if "<chapter_content>" in ai_response:
                    content = ai_response.split("<chapter_content>")[1].split("</chapter_content>")[0].strip()
                else:
                    content = ai_response

                logger.debug(f"Content before correction: {content[:200]}...")
                logger.debug(f"Overall outline: {overall_outline[:200]}...")
                content = self._correct_title_format(content, overall_outline)
                content = self._repair_section_citations_if_needed(
                    content=content,
                    key_files=key_files,
                    source_context=prompt_files,
                    user_query=user_query,
                    current_chapter_outline=current_chapter_outline,
                    model_url=model_url,
                    model_config=model_config,
                    headers=headers,
                    temperature=temperature,
                    max_tokens=max_tokens,
                )
                logger.debug(f"Content after correction: {content[:200]}...")
                # Second round: Request summary
                summary_prompt = "Please give a detailed summary of the output chapter content. The summary should preserve the main argument, important evidence, concrete examples, and implications, and should be clearly longer than a short abstract. Be sure to ensure that the language of the summary is consistent with the language of the output chapter content. For example, if the chapter content is in Chinese, your summary should also be in Chinese."

                summary_response = None
                max_retries = 5
                for attempt in range(max_retries):
                    try:
                        summary_response = requests.post(
                            url=model_url,
                            headers=headers,
                            json={
                                "model": model_config.get('model', 'pangu_auto'),
                                "chat_template": "{% for message in messages %}{% if loop.first and messages[0]['role'] != 'system' %}{{ '<s>[unused9]缁崵绮洪敍姝攗nused10]' }}{% endif %}{% if message['role'] == 'system' %}{{'<s>[unused9]缁崵绮洪敍? + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'assistant' %}{{'[unused9]閸斺晜澧滈敍? + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'tool' %}{{'[unused9]瀹搞儱鍙块敍? + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'function' %}{{'[unused9]閺傝纭堕敍? + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'user' %}{{'[unused9]閻劍鍩涢敍? + message['content'] + '[unused10]'}}{% endif %}{% endfor %}{% if add_generation_prompt %}{{ '[unused9]閸斺晜澧滈敍? }}{% endif %}",
                                "messages": [
                                    {"role": "system", "content": system_prompt},
                                    {"role": "user", "content": user_prompt + " /no_think"},
                                    {"role": "assistant", "content": ai_response},
                                    {"role": "user", "content": summary_prompt + " /no_think"}
                                ],
                                "max_tokens": max_tokens,
                                "spaces_between_special_tokens": False,
                                "temperature": temperature,
                            },
                            timeout=model_config.get("timeout", 180)
                        )
                        summary_response = summary_response.json()
                        logger.debug(f"Summary API response received")

                        break  # Success, exit retry loop
                    except Exception as e:
                        logger.warning(f"Summary LLM API call attempt {attempt + 1} failed: {e}")
                        if attempt == max_retries - 1:
                            raise e  # Last attempt, re-raise the exception
                        time.sleep(5)  # Simple delay between retries

                if summary_response is None:
                    raise Exception("Failed to get summary response after all retries")

                # summary_ai_response = summary_response.choices[0].message.content.strip()
                summary_ai_response = summary_response["choices"][0]["message"]["content"].strip()
                summary = summary_ai_response

                session_context = self.get_session_context()
                session_id = session_context.get("session_id")

                # Save multi-round conversation history
                conversation_history = [
                    # {"role": "system", "content": "You are a research assistant. Return only the requested title, abstract, and keywords."},
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt + " /no_think"},
                    {"role": "assistant", "content": ai_response},
                    {"role": "user", "content": summary_prompt + " /no_think"},
                    {"role": "assistant", "content": summary_ai_response}
                ]

                # 閹跺﹤缍嬮崜宥呭敶鐎圭懓鍟撻崗銉ュ煂target_file_path娑?
                write_result = self.file_write(file_path=target_file_path,
                                               content=content,
                                               create_dirs=True)
                if not write_result.success:
                    raise Exception(f"File write failed: {write_result.error}")

                results = []
                return MCPToolResult(
                    success=True,
                    data=results.append({
                        "chapter_summary": summary,
                    }),
                    metadata={
                        'content_length': len(content),
                        'summary_length': len(summary)
                    }
                )

            except Exception as e:
                logger.error(f"AI model call failed: {e}")
                return MCPToolResult(
                    success=False,
                    error=f"section writer failed: {str(e)}"
                )

        except Exception as e:
            logger.error(f"section writer failed: {e}")
            return MCPToolResult(success=False, error=str(e))

    def document_extract(
            self,
            # save_analysis_file_path: str,
            tasks: List[Dict],
            model: str = "pangu_auto",
            temperature: Optional[float] = None,
            max_tokens: Optional[int] = None,
            max_workers: int = 5
    ) -> MCPToolResult:
        """
        Multi-dimensional analysis of locally stored files using AI models.
        Evaluates each file across four key dimensions: source authority, core content extraction,
        information richness, and query relevance scoring.

        Args:
            tasks: List of task dictionaries containing:
                - file_path: Relative path to the file (relative to workspace root) to read
                - task: task for relevance assessment
            model: AI model to use for multi-dimensional analysis
            temperature: Creativity level for the AI response (0-1)
            max_tokens: Maximum tokens for the AI response
            max_workers: Maximum number of concurrent model API requests
        """
        try:
            # Get configuration
            from config.config import get_model_config, get_storage_config
            model_config = get_model_config()
            storage_config = get_storage_config()

            # Use config values or defaults
            if temperature is None:
                temperature = model_config.get('temperature', 0.3)
            if max_tokens is None:
                max_tokens = model_config.get('max_tokens', 8192)
            logger.debug(f"Starting document extraction: tasks={tasks}")

            # 妤犲矁鐦夐獮鎯板殰閸斻劏藟閸忣煉绱版禒鍛秼娴犺濮熼崠鍛儓 library_refs 閹?user_uploads 閺傚洣娆㈤弮鑸靛鏉╂稖顢戠悰銉ュ弿
            task_files = [t.get('file_path', '') for t in tasks]

            # 鐟欏嫯瀵栭崠鏍熅瀵板嫸绱扮粔濠氭珟 ./ 閸撳秶绱戞禒銉ょ┒缂佺喍绔村В鏃囩窛
            def normalize_path(path: str) -> str:
                return path[2:] if path.startswith('./') else path

            normalized_task_files = [normalize_path(f) for f in task_files]

            # 濡偓閺屻儰鎹㈤崝鈥茶厬閺勵垰鎯侀崠鍛儓 library_refs 閹?user_uploads 閺傚洣娆?
            has_library_files = any(f.startswith('library_refs/') for f in normalized_task_files)
            has_upload_files = any(f.startswith('user_uploads/') for f in normalized_task_files)

            # 閸欘亝婀佽ぐ鎾叉崲閸斺剝绉归崣濠呯箹娴滄稓娲拌ぐ鏇熸閿涘本澧犳潻娑滎攽鐞涖儱鍙忔宀冪槈
            if has_library_files or has_upload_files:
                library_refs_dir = self.workspace_path / "library_refs"
                user_uploads_dir = self.workspace_path / "user_uploads"

                expected_files = []
                # 閸欘亣顩︽潻娑樺弳鐞涖儱鍙忛柅鏄忕帆閿涘苯姘ㄩ幍顐ｅ伎娑撱倓閲滈惄顔肩秿閿涘牅绗夌粻鈥叉崲閸斺€茶厬閺勵垰鎯侀崠鍛儓鐠囥儳娲拌ぐ鏇犳畱閺傚洣娆㈤敍?
                if library_refs_dir.exists():
                    # 閹殿偅寮块幍鈧張澶婂讲閼崇晫娈戦弬鍥︽閹碘晛鐫嶉崥?
                    for ext in ['*.txt', '*.pdf', '*.doc', '*.docx']:
                        expected_files.extend([f"library_refs/{f.name}" for f in library_refs_dir.glob(ext)])
                if user_uploads_dir.exists():
                    # 閹殿偅寮块幍鈧張澶婂讲閼崇晫娈戦弬鍥︽閹碘晛鐫嶉崥?
                    for ext in ['*.txt', '*.pdf', '*.doc', '*.docx']:
                        expected_files.extend([f"user_uploads/{f.name}" for f in user_uploads_dir.glob(ext)])

                # 閺呴缚鍏橀崠褰掑帳閿涙艾鐔€娴滃孩鏋冩禒鏈靛瘜娴ｆ挸鎮曠粔甯礄娣囨繄鏆€閸樼喎顫愰幍鈺佺潔閸氬稄绱濈粔濠氭珟 .txt 閸氬海绱戦敍?
                def get_core_name(path: str) -> str:
                    """Return the base filename used to match extracted text files to originals."""
                    import os
                    name = os.path.basename(path)
                    # 婵″倹鐏夋禒?.txt 缂佹挸鐔敍宀€些闂勩倕鐣?
                    if name.endswith('.txt'):
                        name = name[:-4]
                    return name

                # 閺嬪嫬缂撻弽绋跨妇閸氬秶袨閸掔増鏋冩禒鎯扮熅瀵板嫮娈戦弰鐘茬殸閿涘牊鏁幐浣风鐎电懓顦块敍?
                from collections import defaultdict
                expected_core_map = defaultdict(list)
                for f in expected_files:
                    expected_core_map[get_core_name(f)].append(f)

                task_core_names = {get_core_name(f) for f in normalized_task_files}

                # 閹垫儳鍤惇鐔割劀缂傚搫銇戦惃鍕瀮娴犺绱欓弽绋跨妇閸氬秶袨娑撳秴婀导鐘插弳閸掓銆冩稉顓ㄧ礆
                missing_core_names = set(expected_core_map.keys()) - task_core_names
                # 鐎甸€涚艾缂傚搫銇戦惃鍕壋韫囧啫鎮曠粔甯礉闁瀚ㄧ粭顑跨娑擃亜灏柊宥囨畱閺傚洣娆㈤敍鍫モ偓姘埗閺?.txt 閻楀牊婀伴敍?
                missing_files = set()
                for core_name in missing_core_names:
                    missing_files.add(expected_core_map[core_name][0])

                # 妤犲矁鐦夌紒鎾寸亯閺冦儱绻?
                if missing_files:
                    # 閸掑棛琚紒鐔活吀缂傚搫銇戦弬鍥︽
                    missing_library = [f for f in missing_files if f.startswith('library_refs/')]
                    missing_uploads = [f for f in missing_files if f.startswith('user_uploads/')]

                    # 缂佺喍绔存潏鎾冲毉鐠€锕€鎲℃穱鈩冧紖
                    missing_info = []
                    if missing_library:
                        missing_info.append(f"library files: {len(missing_library)}")
                    if missing_uploads:
                        missing_info.append(f"user uploads: {len(missing_uploads)}")

                    logger.warning(f"閳跨媴绗?濡偓濞村鍩?{len(missing_files)} 娑擃亝鏋冩禒鑸垫弓閸栧懎鎯堥崷銊ュ瀻閺嬫劒鎹㈤崝鈥茶厬 ({', '.join(missing_info)})")
                    logger.warning(f"妫板嫭婀? {len(expected_files)} 娑擃亷绱濈€圭偤妾? {len(tasks)} 娑?| 棣冩暋 閼奉亜濮╃悰銉ュ弿娑?..")

                    # 閼惧嘲褰囩粭顑跨娑擃亙鎹㈤崝锛勬畱task閸愬懎顔愭担婊€璐熸妯款吇娴犺濮熼幓蹇氬牚
                    default_task = tasks[0].get("task", "Extract relevant content") if tasks else "Extract relevant content"

                    for missing_file in sorted(missing_files):
                        tasks.append({
                            'file_path': missing_file,
                            'task': default_task
                        })

                    logger.info(f"閴?瀹歌尪藟閸忣煉绱濋幀璁虫崲閸斺剝鏆? {len(tasks)}")
                else:
                    logger.info("No missing library_refs/user_uploads files detected.")

            else:
                # 娴犺濮熼崣顏呯Ч閸?research 缁涘鍙炬禒鏍窗瑜版洩绱濇稉宥堢箻鐞涘矁藟閸?
                logger.info("Skipping library_refs/user_uploads completeness check.")

            # 閵嗘劕鍙ч柨顔绘叏婢跺秲鈧垼绻冨銈嗗竴閺傚洦銆傛潪顒佸床閸氬海娈?.txt 閺傚洣娆㈤敍宀勪缉閸忓秹鍣告径宥呭瀻閺?
            # 婵″倹鐏夐崥灞炬鐎涙ê婀?xxx.pdf 閸?xxx.pdf.txt閿涘苯褰ф穱婵堟殌 .pdf
            # 婵″倹鐏夐崥灞炬鐎涙ê婀?xxx.docx 閸?xxx.docx.txt閿涘苯褰ф穱婵堟殌 .docx
            # 婵″倹鐏夐崥灞炬鐎涙ê婀?xxx.doc 閸?xxx.doc.txt閿涘苯褰ф穱婵堟殌 .doc
            # 娴ｅ棔绻氶悾娆忓斧閺堫剙姘ㄩ弰?.txt 閻ㄥ嫭鏋冩禒璁圭礄婵?research/xxx.txt閿?
            filtered_tasks = []
            source_files = set()  # 鐎涙ê鍋嶉幍鈧張澶嬬爱閺傚洣娆㈤敍鍧f, docx, doc閿?

            # 鐎规矮绠熼棁鈧憰浣诡梾閺屻儳娈戝┃鎰瀮娴犺埖澧跨仦鏇炴倳
            source_extensions = ['.pdf', '.docx', '.doc']

            # 缁楊兛绔撮柆宥忕窗閺€鍫曟肠閹碘偓閺堝绨弬鍥︽
            for task in tasks:
                file_path = task.get('file_path', '')
                normalized_path = file_path.lstrip('./')

                # 濡偓閺屻儲妲搁崥锔芥Ц濠ф劖鏋冩禒?
                for ext in source_extensions:
                    if normalized_path.endswith(ext):
                        source_files.add(normalized_path)
                        break

            # 缁楊兛绨╅柆宥忕窗鏉╁洦鎶ゆ禒璇插
            for task in tasks:
                file_path = task.get('file_path', '')
                normalized_path = file_path.lstrip('./')

                # 濡偓閺屻儲妲搁崥锔芥Ц鏉烆剚宕查崥搴ｆ畱 .txt 閺傚洣娆㈤敍鍧竫x.pdf.txt, xxx.docx.txt, xxx.doc.txt閿?
                should_skip = False
                if normalized_path.endswith('.txt'):
                    # 濡偓閺屻儲妲搁崥锔芥Ц娴犲孩绨弬鍥︽鏉烆剚宕查懓灞炬降閻?.txt
                    for ext in source_extensions:
                        potential_source = normalized_path[:-4]  # 閸樼粯甯€ .txt
                        if potential_source.endswith(ext) and potential_source in source_files:
                            # 閹垫儳鍩岀€电懓绨查惃鍕爱閺傚洣娆㈤敍宀冪儲鏉╁洩绻栨稉?.txt
                            logger.info(f"閳搭叏绗?鐠哄疇绻?{file_path}閿涘牆顕惔鏃傛畱濠ф劖鏋冩禒?{potential_source.split('/')[-1]} 瀹告彃鐡ㄩ崷顭掔礆")
                            should_skip = True
                            break

                if not should_skip:
                    filtered_tasks.append(task)

            if len(filtered_tasks) < len(tasks):
                logger.info(f"閴?鏉╁洦鎶ら崥搴濇崲閸斺剝鏆? {len(filtered_tasks)} (閸樼喎顫? {len(tasks)})")
                tasks = filtered_tasks

            def process_single_task(task: Dict) -> Dict:
                file_path = task['file_path']
                task_content = task['task']

                # 1. 鐠囪褰囬弬鍥︽閸愬懎顔?
                read_result = self.file_read(file_path)
                if not read_result.success:
                    return {
                        'file_path': file_path,
                        'task': task_content,
                        'success': False,
                        'error': f"File read error: {read_result.error}",
                        'answer': None
                    }

                content = read_result.data
                system_prompt = (
                    "You are a text expert. Next, you will be given a document and task content. You need to analyze this document carefully and then provide multiple dimensional information for this document.\n\n"

                    "The following are some dimensional information extracted:\n"
                    "1. Web page time: According to the content of the document, extract the web page time of the document content. If it cannot be judged, it is expressed as \"unable to determine the web page time\"; otherwise, the time of the web page is output, accurate to the month, in the format of \"YYYY year MM month\", such as \"2023 June\";\n"
                    "2. Authority: According to the information of the document, judge the source of the web page to confirm the credibility of the web page.\n"
                    "3. Relevance: According to the current task (task_content) and the given document, judge whether the current document is related to the current task.\n"
                    "4. Core content: Based on this document, you make a core content summary to ensure the richness of information, with a word count of about 400-500 words.\n"
                    "Information richness: Estimate the total word count of substantive content in the document. Less than 200 words indicates scarcity; over 800 words suggests high richness; between these thresholds denotes moderate richness. Be careful not to just give the word count results, but also give a corresponding text description of how informative the content is.\n"

                    "Note:\n1. Ensure the document's language aligns with the extracted dimensions (e.g., Chinese content requires Chinese extraction).\n2. For **source_authority** and **task_relevance**, first provide a brief description before concluding.  \n"
                    "- **Authority**: Briefly assess the source's credibility (e.g., expertise, reputation). *Conclusion*: [High/Medium/Low].  \n"
                    "- **Relevance**: Summarize content alignment with the topic. *Conclusion*: [High/Medium/Low].\n"

                    "The final output format must be a valid JSON object:\n"
                    "{\n"
                    "  \"doc_time\": \"xxx\",\n"
                    "  \"source_authority\": \"xxx\",\n"
                    "  \"task_relevance\": \"xxx\",\n"
                    "  \"core_content\": \"xxx\",\n"
                    "  \"information_richness\": \"xxx\"\n"
                    "}\n\n"
                    "Important: Return ONLY the JSON object, no additional text or formatting."
                )

                # 閺嬪嫬缂撻悽銊﹀煕閹绘劗銇?
                user_prompt = (
                    f"DOCUMENT CONTENT:\n{content}\n"
                    # f"DOCUMENT LEN: The length of the file content is{len(content)}\n"
                    f"TASK FOR RELEVANCE ASSESSMENT: {task_content}"
                )

                # Get model URL and token from config
                config = get_config()
                model_config = config.get_custom_llm_config()

                model_url = model_config.get('url') or os.getenv('MODEL_REQUEST_URL', '')
                model_token = model_config.get('token') or os.getenv('MODEL_REQUEST_TOKEN', '')
                headers = {'Content-Type': 'application/json', 'csb-token': model_token}
                if model_token:
                    headers['Authorization'] = f'Bearer {model_token}'

                try:
                    # Add retry logic for AI model call
                    max_retries = 3
                    response = None

                    for attempt in range(max_retries):
                        try:
                            response = requests.post(
                                url=model_url,
                                headers=headers,
                                json={
                                    "model": model_config.get('model', 'pangu_auto'),
                                    "chat_template": "{% for message in messages %}{% if loop.first and messages[0]['role'] != 'system' %}{{ '<s>[unused9]缁崵绮洪敍姝攗nused10]' }}{% endif %}{% if message['role'] == 'system' %}{{'<s>[unused9]缁崵绮洪敍? + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'assistant' %}{{'[unused9]閸斺晜澧滈敍? + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'tool' %}{{'[unused9]瀹搞儱鍙块敍? + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'function' %}{{'[unused9]閺傝纭堕敍? + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'user' %}{{'[unused9]閻劍鍩涢敍? + message['content'] + '[unused10]'}}{% endif %}{% endfor %}{% if add_generation_prompt %}{{ '[unused9]閸斺晜澧滈敍? }}{% endif %}",
                                    "messages": [
                                        {"role": "system", "content": system_prompt},
                                        {"role": "user", "content": user_prompt + " /no_think"}
                                    ],
                                    "max_tokens": max_tokens,
                                    "spaces_between_special_tokens": False,
                                    "temperature": temperature,
                                },
                                timeout=model_config.get("timeout", 180)
                            )
                            # 閳ユ柡鈧柡鈧?闂冩彃灏介幀褎鐗庢宀嬬窗HTTP 閻樿埖鈧胶鐖?/ 缁屽搫鎼锋惔?/ 闂堢偞纭?JSON 閳ユ柡鈧柡鈧?
                            if response.status_code != 200:
                                raise ValueError(
                                    f"LLM API HTTP error: status={response.status_code}; body={response.text[:300]}"
                                )
                            resp_raw = response.text.strip()
                            if not resp_raw:
                                raise ValueError(
                                    "LLM API 鏉╂柨娲栫粚鍝勬惙鎼存棑绱欓崣顖濆厴鐟欙箑褰傞梽鎰ウ閵嗕椒绗傛稉瀣瀮鐡掑懘妾洪幋鏍秹缂佹粈鑵戦弬顓ㄧ礆"
                                )
                            response = response.json()
                            logger.info(f"LLM API response: {response}")

                            break  # Success, exit retry loop
                        except ValueError:
                            raise  # 瀹稿弶妲戠涵顔煎瀻缁崵娈戦柨娆掝嚖閻╁瓨甯撮幎娑樺毉
                        except json.JSONDecodeError as e:
                            raise ValueError(
                                f"LLM API returned invalid JSON: {e}; body={resp_raw[:200]}"
                            )
                        except Exception as e:
                            logger.warning(f"LLM API call attempt {attempt + 1} failed: {e}")
                            if attempt == max_retries - 1:
                                raise e  # Last attempt, re-raise the exception
                            time.sleep(2)  # 2 second delay between retries

                    if response is None:
                        raise Exception("Failed to get response after all retries")

                    # answer = response.choices[0].message.content
                    answer = response["choices"][0]["message"]["content"]

                    session_context = self.get_session_context()
                    session_id = session_context.get("session_id")
                    # 閸掑洦宕叉穱婵嗙摠閻ㄥ嫭鏌熷?
                    conversation_history = [
                        # {"role": "system", "content": "You are a research assistant. Return only the requested title, abstract, and keywords."},
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt + " /no_think"},
                        {"role": "assistant", "content": answer}
                    ]

                    return {
                        'file_path': file_path,
                        'task': task_content,
                        'success': True,
                        'answer': answer,
                        'metadata': {
                            'file_size': len(content),
                            'line_count': len(content.splitlines())
                        }
                    }

                except Exception as e:
                    logger.error(f"Model API call failed for file '{file_path}': {e}")
                    return {
                        'file_path': file_path,
                        'task': task_content,
                        'success': False,
                        'error': f"Model API error: {str(e)}"
                    }

            # 4. 楠炶泛褰傛径鍕倞閹碘偓閺堝鎹㈤崝?
            results = []
            with ThreadPoolExecutor(max_workers=min(max_workers, len(tasks))) as executor:
                future_to_task = {executor.submit(process_single_task, task): task for task in tasks}

                for future in as_completed(future_to_task):
                    try:
                        result = future.result()
                        results.append(result)
                    except Exception as e:
                        task = future_to_task[future]
                        logger.error(f"Task processing failed for file '{task['file_path']}': {e}")
                        results.append({
                            'file_path': task['file_path'],
                            'task': task['task'],
                            'success': False,
                            'error': f"Task processing exception: {str(e)}"
                        })

            # 5. 娣囨繃瀵旈崢鐔奉潗娴犺濮熸い鍝勭碍
            task_order = {task['file_path']: i for i, task in enumerate(tasks)}
            results.sort(key=lambda x: task_order.get(x['file_path'], float('inf')))

            # 娣囨繂鐡ㄧ紒鎾寸亯閸掔増鏋冩禒?
            def parse_answer_to_structured_data(answer_text: str, file_path: str) -> Dict[str, str]:
                """Parse the AI JSON response into structured data"""
                # Default structure
                structured_data = {
                    "file_path": file_path,
                    "doc_time": "Unknown",
                    "source_authority": "Unknown",
                    "task_relevance": "Unknown",
                    "information_richness": "Unknown",
                    "core_content": "Unknown"
                }

                if not answer_text:
                    return structured_data

                try:
                    # Try to parse as JSON
                    answer_text = answer_text.strip()

                    # Remove any markdown code blocks if present
                    if answer_text.startswith('```'):
                        lines = answer_text.split('\n')
                        # Find the start and end of JSON content
                        start_idx = 0
                        end_idx = len(lines)
                        for i, line in enumerate(lines):
                            if line.strip().startswith('{'):
                                start_idx = i
                                break
                        for i in range(len(lines) - 1, -1, -1):
                            if lines[i].strip().endswith('}'):
                                end_idx = i + 1
                                break
                        answer_text = '\n'.join(lines[start_idx:end_idx])

                    # Parse JSON
                    parsed_data = json.loads(answer_text)

                    # Update structured_data with parsed values
                    if isinstance(parsed_data, dict):
                        structured_data.update({
                            "file_path": file_path,
                            "doc_time": parsed_data.get("doc_time", "Unknown"),
                            "source_authority": parsed_data.get("source_authority", "Unknown"),
                            "task_relevance": parsed_data.get("task_relevance", "Unknown"),
                            "core_content": parsed_data.get("core_content", "Unknown"),
                            "information_richness": parsed_data.get("information_richness", "Unknown")
                        })

                    return structured_data

                except json.JSONDecodeError as e:
                    # If JSON parsing fails, return default with error info
                    structured_data[
                        "core_content"] = f"JSON parsing error: {str(e)}. Raw response: {answer_text[:200]}..."
                    return structured_data
                except Exception as e:
                    # Handle any other parsing errors
                    structured_data["core_content"] = f"Parsing error: {str(e)}"
                    return structured_data

            # Transform results into the desired format
            structured_results = []
            for result in results:
                if result.get('success', False) and result.get('answer'):
                    structured_data = parse_answer_to_structured_data(
                        result['answer'],
                        result['file_path']
                    )
                    structured_results.append(structured_data)
                else:
                    # For failed results, still include basic info
                    structured_results.append({
                        "file_path": result.get('file_path', 'Unknown'),
                        "doc_time": "Processing failed",
                        "source_authority": "Processing failed",
                        "task_relevance": "Processing failed",
                        "information_richness": "Unknown",
                        "core_content": f"Error: {result.get('error', 'Unknown error')}"
                    })

            # Save structured results to JSON file
            # Create full path relative to workspace
            analysis_path = storage_config.get('document_analysis_path', './doc_analysis')
            full_save_path = self.workspace_path / analysis_path / "file_analysis.jsonl"
            full_save_path.parent.mkdir(parents=True, exist_ok=True)

            # Read existing data to avoid duplicates
            existing_data = {}
            if full_save_path.exists():
                try:
                    with open(full_save_path, "r", encoding='utf-8', errors='ignore') as f:
                        for line in f:
                            try:
                                data = json.loads(line.strip())
                                if data.get('file_path'):
                                    existing_data[data['file_path']] = data
                            except json.JSONDecodeError:
                                continue  # Skip malformed lines
                except Exception as e:
                    logger.error(f"Warning: Failed to read existing analysis file: {e}")

            # Merge new results (new data overwrites old data for same file_path)
            for result in structured_results:
                if result.get('file_path'):
                    existing_data[result['file_path']] = result

            # Write back all data (overwrite mode to ensure no duplicates)
            # 閵嗘劕鍙ч柨顔绘叏婢跺秲鈧垹鏁ら幋铚傜瑐娴肩姵鏋冩禒鏈电喘閸忓牊甯撴惔蹇ョ礉閺傚洦銆傛惔鎾虫嫲缂冩垹绮跺Λ鈧槐銏㈡暠LLM閼奉亣顢戦崚銈嗘焽
            # 鏉╂瑦鐗辩涵顔荤箽閻劍鍩涙稉濠佺炊閺傚洣娆㈤崷鈺le_analysis.jsonl娑擃厽甯撻崷銊︽付閸撳秹娼伴敍瀛竢iter娴兼艾宸遍崚鏈电喘閸忓牆绱╅悽?
            user_uploaded_files = []
            other_files = []

            for file_data in existing_data.values():
                file_path = file_data.get('file_path', '')
                if 'user_uploads' in file_path or file_path.startswith('./user_uploads/'):
                    user_uploaded_files.append(file_data)
                else:
                    # 閺傚洦銆傛惔鎾虫嫲缂冩垹绮跺Λ鈧槐顫瑝閸嬫矮绱崗鍫㈤獓閸栧搫鍨庨敍灞肩箽閹镐礁甯張澶愩€庢惔?
                    other_files.append(file_data)

            # 閻劍鍩涙稉濠佺炊閺傚洣娆㈤崷銊ュ閿涘苯鍙炬禒鏍ㄦ瀮娴犺泛婀崥搴礄娣囨繃瀵旈崢鐔告箒妞ゅ搫绨敍?
            sorted_data = user_uploaded_files + other_files

            with open(full_save_path, mode="w", encoding='utf-8') as f:
                for data in sorted_data:
                    f.write(json.dumps(data, ensure_ascii=False) + "\n")

            # 缂佺喕顓搁崥鍕閺傚洣娆㈤弫浼村櫤
            library_count = sum(1 for d in other_files if 'library_refs' in d.get('file_path', ''))
            research_count = sum(1 for d in other_files if 'research' in d.get('file_path', ''))
            if user_uploaded_files:
                logger.info(
                    f"閴?閺傚洣娆㈤崚鍡樼€界紒鎾寸亯瀹歌弓绻氱€? 閻劍鍩涙稉濠佺炊({len(user_uploaded_files)}娑?瀵搫鍩楁导妯哄帥) + 閺傚洦銆傛惔?{library_count}娑? + 缂冩垹绮跺Λ鈧槐?{research_count}娑?閻㈢洜LM閸掋倖鏌?")

            # 6. 缂佺喕顓哥紒鎾寸亯
            successful_tasks = len([r for r in results if r.get('success', False)])

            return MCPToolResult(
                success=True,
                data=results,
                metadata={
                    'total_tasks': len(tasks),
                    'successful_tasks': successful_tasks,
                    'failed_tasks': len(tasks) - successful_tasks,
                    'model': model,
                    'concurrent_workers': min(max_workers, len(tasks))
                }
            )

        except Exception as e:
            logger.error(f"Context-based document extraction failed: {e}")
            return MCPToolResult(success=False, error=str(e))

    def document_qa(
            self,
            tasks: List[Dict],
            model: str = "pangu_auto",
            temperature: float = 0.3,
            max_tokens: int = 8192,
            max_workers: int = 5
    ) -> MCPToolResult:
        """Answer questions using local file content."""
        try:
            logger.info(f"document_qa: tasks={len(tasks) if tasks else 0}")

            # 婢跺嫮鎮婇崡鏇氶嚋娴犺濮?
            def process_single_task(task: Dict) -> Dict:
                file_path = task['file_path']
                question = task['question']

                # 1. 鐠囪褰囬弬鍥︽閸愬懎顔?
                read_result = self.file_read(file_path)
                if not read_result.success:
                    return {
                        'file_path': file_path,
                        'question': question,
                        'success': False,
                        'error': f"File read error: {read_result.error}",
                        'answer': None
                    }

                content = read_result.data

                # 2. 閺嬪嫬缂撶化鑽ょ埠閹绘劗銇?
                system_prompt = (
                    "You are an expert document analyst. Answer the user's question "
                    "based ONLY on the provided context. If the answer cannot be found "
                    "in the context, say 'I don't know'.\n\n"
                    "CONTEXT:\n{context}"
                ).format(context=content)

                # 3. 鐠嬪啰鏁ゆ径褎膩閸ㄥPI閿涘牅濞囬悽銊х埠娑撯偓濡€崇€烽柊宥囩枂閿涘奔绗岀€电鐦藉Ο鈥崇€锋穱婵囧瘮娑撯偓閼疯揪绱?
                config = get_config()
                model_config = config.get_custom_llm_config()

                model_url = model_config.get('url') or os.getenv('MODEL_REQUEST_URL', '')
                model_token = model_config.get('token') or os.getenv('MODEL_REQUEST_TOKEN', '')
                headers = {'Content-Type': 'application/json', 'csb-token': model_token}
                if model_token:
                    headers['Authorization'] = f'Bearer {model_token}'

                try:
                    # Add retry logic for AI model call
                    max_retries = 5
                    response = None

                    for attempt in range(max_retries):
                        try:
                            response = requests.post(
                                url=model_url,
                                headers=headers,
                                json={
                                    "model": model_config.get('model', 'pangu_auto'),
                                    "chat_template": "{% for message in messages %}{% if loop.first and messages[0]['role'] != 'system' %}{{ '<s>[unused9]缁崵绮洪敍姝攗nused10]' }}{% endif %}{% if message['role'] == 'system' %}{{'<s>[unused9]缁崵绮洪敍? + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'assistant' %}{{'[unused9]閸斺晜澧滈敍? + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'tool' %}{{'[unused9]瀹搞儱鍙块敍? + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'function' %}{{'[unused9]閺傝纭堕敍? + message['content'] + '[unused10]'}}{% endif %}{% if message['role'] == 'user' %}{{'[unused9]閻劍鍩涢敍? + message['content'] + '[unused10]'}}{% endif %}{% endfor %}{% if add_generation_prompt %}{{ '[unused9]閸斺晜澧滈敍? }}{% endif %}",
                                    "messages": [
                                        {"role": "system", "content": system_prompt},
                                        {"role": "user", "content": question + " /no_think"}
                                    ],
                                    "max_tokens": max_tokens,
                                    "spaces_between_special_tokens": False,
                                    "temperature": temperature,
                                },
                                timeout=model_config.get("timeout", 180)
                            )
                            # 閳ユ柡鈧柡鈧?闂冩彃灏介幀褎鐗庢宀嬬窗HTTP 閻樿埖鈧胶鐖?/ 缁屽搫鎼锋惔?/ 闂堢偞纭?JSON 閳ユ柡鈧柡鈧?
                            if response.status_code != 200:
                                raise ValueError(
                                    f"LLM API HTTP error: status={response.status_code}; body={response.text[:300]}"
                                )
                            resp_raw = response.text.strip()
                            if not resp_raw:
                                raise ValueError(
                                    "LLM API 鏉╂柨娲栫粚鍝勬惙鎼存棑绱欓崣顖濆厴鐟欙箑褰傞梽鎰ウ閵嗕椒绗傛稉瀣瀮鐡掑懘妾洪幋鏍秹缂佹粈鑵戦弬顓ㄧ礆"
                                )
                            response = response.json()
                            break  # Success, exit retry loop
                        except ValueError:
                            raise  # 瀹稿弶妲戠涵顔煎瀻缁崵娈戦柨娆掝嚖閻╁瓨甯撮幎娑樺毉
                        except json.JSONDecodeError as e:
                            raise ValueError(
                                f"LLM API returned invalid JSON: {e}; body={resp_raw[:200]}"
                            )
                        except Exception as e:
                            logger.warning(f"LLM API call attempt {attempt + 1} failed: {e}")
                            if attempt == max_retries - 1:
                                raise e  # Last attempt, re-raise the exception
                            time.sleep(2)  # 2 second delay between retries

                    if response is None:
                        raise Exception("Failed to get response after all retries")

                    answer = response["choices"][0]["message"]["content"]
                    return {
                        'file_path': file_path,
                        'question': question,
                        'success': True,
                        'answer': answer,
                        'metadata': {
                            'file_size': len(content),
                            'line_count': len(content.splitlines())
                        }
                    }

                except ValueError as e:
                    logger.error(f"Model API call failed for file '{file_path}' - {e}")
                    return {
                        'file_path': file_path,
                        'question': question,
                        'success': False,
                        'error': f"Model API error: {str(e)}"
                    }
                except Exception as e:
                    logger.error(f"Model API call failed for file '{file_path}': {e}")
                    return {
                        'file_path': file_path,
                        'question': question,
                        'success': False,
                        'error': f"Model API error: {str(e)}"
                    }

            # 4. 楠炶泛褰傛径鍕倞閹碘偓閺堝鎹㈤崝?
            results = []
            with ThreadPoolExecutor(max_workers=min(max_workers, len(tasks))) as executor:
                future_to_task = {executor.submit(process_single_task, task): task for task in tasks}

                for future in as_completed(future_to_task):
                    try:
                        result = future.result()
                        results.append(result)
                    except Exception as e:
                        task = future_to_task[future]
                        logger.error(f"Task processing failed for file '{task['file_path']}': {e}")
                        results.append({
                            'file_path': task['file_path'],
                            'question': task['question'],
                            'success': False,
                            'error': f"Task processing exception: {str(e)}"
                        })

            # 5. 娣囨繃瀵旈崢鐔奉潗娴犺濮熸い鍝勭碍
            task_order = {task['file_path']: i for i, task in enumerate(tasks)}
            results.sort(key=lambda x: task_order.get(x['file_path'], float('inf')))

            # 6. 缂佺喕顓哥紒鎾寸亯
            successful_tasks = len([r for r in results if r.get('success', False)])

            return MCPToolResult(
                success=True,
                data=results,
                metadata={
                    'total_tasks': len(tasks),
                    'successful_tasks': successful_tasks,
                    'failed_tasks': len(tasks) - successful_tasks,
                    'model': model,
                    'concurrent_workers': min(max_workers, len(tasks))
                }
            )

        except Exception as e:
            logger.error(f"Context-based QA batch processing failed: {e}")
            logger.error(f"document qa error: '{task['file_path']}': {e}")
            return MCPToolResult(success=False, error=str(e))

    # ================ FILE DOWNLOAD TOOLS ================

    def download_files(
            self,
            urls: List[str],
            target_directory: str = None,
            overwrite: bool = False,
            max_file_size_mb: int = 100
    ) -> MCPToolResult:
        """
        Download human-readable research files such as PDFs, documents, and data files.
        
        Use this tool for downloading research papers, documentation, reports, data files (CSV, JSON, XML),
        academic publications, and other human-readable content that you can analyze.
        
        WARNING: Do NOT use this tool for downloading web pages (HTML/HTM files) or other non-readable formats.
        For web page content extraction, use the url_crawler tool instead.
        
        Args:
            urls: List of URLs to download (PDFs, DOCs, research papers, data files, etc.)
            target_directory: Directory to save files (relative to session workspace)
            overwrite: Whether to overwrite existing files
            max_file_size_mb: Maximum file size in MB
        """
        try:
            if target_directory:
                # Ensure target_directory is relative to session workspace for security
                download_dir = self._safe_join(target_directory)
            else:
                download_dir = self.workspace_path / "downloads"

            download_dir.mkdir(parents=True, exist_ok=True)

            def download_single_file(url: str) -> Dict[str, Any]:
                """Download a single file"""
                try:
                    # Parse URL to get filename
                    parsed_url = urlparse(url)
                    filename = os.path.basename(parsed_url.path) or 'downloaded_file'

                    # Ensure filename has extension
                    if '.' not in filename:
                        filename += '.html'  # Default extension

                    if os.path.isabs(filename):
                        raise Exception(f"Path '{filename}' is absolute. Only relative paths are allowed.")
                    # 濡偓濞村妲搁崥锔胯礋PDF閺傚洣娆㈤敍鍫㈢秹妞ゅ吀绗呮潪鏂ょ礆
                    is_pdf_from_web = filename.lower().endswith('.pdf')
                    # 婵″倹鐏夐弰鐤―F閺傚洣娆㈤敍灞兼叏閺€瑙勫⒖鐏炴洖鎮曟稉?txt娴犮儵浼╅崗宄咲F閺嶇厧绱￠梻顕€顣?
                    if is_pdf_from_web:
                        filename = filename[:-4] + '.txt'
                        logger.info(f"缂冩垿銆夋稉瀣祰閻ㄥ嚤DF閺傚洣娆㈢亸鍡氭祮閹诡澀璐熼弬鍥ㄦ拱閺嶇厧绱? {filename}")

                    file_path = download_dir / filename
                    if not os.path.realpath(file_path).startswith(self.full_workspace_path):
                        raise Exception(f"Path '{filename}' is outside workspace directory.")

                    # Check if file exists
                    if file_path.exists() and not overwrite:
                        return {
                            'url': url,
                            'success': False,
                            'error': 'File already exists',
                            'file_path': str(file_path)
                        }

                    # Download file
                    response = requests.get(url, stream=True, timeout=30)
                    response.raise_for_status()

                    # Check file size
                    content_length = response.headers.get('content-length')
                    if content_length and int(content_length) > max_file_size_mb * 1024 * 1024:
                        return {
                            'url': url,
                            'success': False,
                            'error': f'File too large (>{max_file_size_mb}MB)',
                            'file_path': None
                        }

                    # Save file
                    with open(file_path, 'wb') as f:
                        for chunk in response.iter_content(chunk_size=8192):
                            f.write(chunk)

                    return {
                        'url': url,
                        'success': True,
                        'file_path': str(file_path),
                        'file_size': file_path.stat().st_size
                    }

                except Exception as e:
                    return {
                        'url': url,
                        'success': False,
                        'error': str(e),
                        'file_path': None
                    }

            # Process downloads concurrently
            results = []
            max_concurrent_downloads = min(5, len(urls))  # Limit concurrent downloads to avoid overwhelming servers
            with ThreadPoolExecutor(max_workers=max_concurrent_downloads) as executor:
                # Submit all download tasks
                future_to_url = {executor.submit(download_single_file, url): url for url in urls}

                # Collect results as they complete
                for future in as_completed(future_to_url):
                    try:
                        result = future.result()
                        results.append(result)
                    except Exception as e:
                        url = future_to_url[future]
                        logger.error(f"Download task failed for '{url}': {e}")
                        results.append({
                            'url': url,
                            'success': False,
                            'error': f"Download task exception: {str(e)}",
                            'file_path': None
                        })

            # Sort results to maintain original URL order
            url_order = {urls[i]: i for i in range(len(urls))}
            results.sort(key=lambda x: url_order.get(x['url'], float('inf')))

            # Generate status message following context management philosophy
            successful_downloads = len([r for r in results if r.get('success', False)])
            failed_downloads = len(results) - successful_downloads

            status_msg = f"File download task completed. Processed {len(urls)} URLs with {successful_downloads} successful downloads and {failed_downloads} failures. Files saved to {download_dir.relative_to(self.workspace_path)}. Use file reading tools to examine the downloaded files."

            return MCPToolResult(
                success=True,
                data=status_msg,
                metadata={
                    'download_directory': str(download_dir),
                    'total_urls': len(urls),
                    'successful_downloads': successful_downloads,
                    'failed_downloads': failed_downloads
                }
            )

        except Exception as e:
            logger.error(f"Download files failed: {e}")
            return MCPToolResult(success=False, error=str(e))

    def process_user_uploaded_files(
            self,
            file_ids: List[str],
            backend_url: str = "http://localhost:5000",
            target_subdir: str = "user_uploads"
    ) -> MCPToolResult:
        """Download and parse uploaded user files from the backend into the workspace."""
        try:
            if not file_ids:
                return MCPToolResult(success=False, error="No file IDs provided")

            user_files_dir = self.workspace_path / target_subdir
            user_files_dir.mkdir(parents=True, exist_ok=True)

            # 鐠嬪啰鏁?Flask 閸氬海顏?API
            response = requests.post(
                f"{backend_url}/api/user_files/download_and_parse",
                json={"file_ids": file_ids, "full_content": True},
                timeout=60
            )

            if not response.ok:
                return MCPToolResult(success=False, error=f"HTTP {response.status_code}")

            result_data = response.json()
            processed_files = []
            # 閻劋绨捄鐔婚嚋閺傚洣娆㈤崥宥忕礉闁灝鍘ら柌宥咁槻閺傚洣娆㈤崥宥呭暱缁?
            used_filenames = set()

            for file_info in result_data.get('files', []):
                if not file_info.get('success'):
                    continue

                file_id = file_info.get('file_id', '')
                filename = file_info.get('filename', 'unknown.txt')

                # 鐎瑰鍙忛崠鏍ㄦ瀮娴犺泛鎮曢敍姘箽閻ｆ瑤鑵戦弬鍥ф嫲閻楄鐣╃€涙顑侀敍灞藉涧缁夊娅嶹indows娑撳秴鍘戠拋鍝ユ畱鐎涙顑?
                # Windows娣囨繄鏆€鐎涙顑侀崪宀冪熅瀵板嫬鍨庨梾鏃傤儊
                forbidden_chars = r'<>:"/\|?*'
                forbidden_chars += ''.join(chr(i) for i in range(32))  # 閹貉冨煑鐎涙顑?
                safe_filename = "".join(c for c in filename if c not in forbidden_chars)
                safe_filename = safe_filename.strip(' .')  # 缁夊娅庢＃鏍х啲缁岀儤鐗搁崪宀€鍋ｉ崣?
                if not safe_filename or safe_filename == '.':
                    safe_filename = f'file_{file_id[:8]}.pdf' if filename.endswith(
                        '.pdf') else f'file_{file_id[:8]}.txt'

                # 婢跺嫮鎮婇弬鍥︽閸氬秴鍟跨粣渚婄窗婵″倹鐏夐弬鍥︽閸氬秴鍑＄€涙ê婀敍灞惧潑閸?file_id 閸撳秶绱?
                if safe_filename in used_filenames:
                    # 閹绘劕褰囬弬鍥︽閹碘晛鐫嶉崥?
                    if '.' in safe_filename:
                        name_part, ext_part = safe_filename.rsplit('.', 1)
                        safe_filename = f"{file_id[:8]}_{name_part}.{ext_part}"
                    else:
                        safe_filename = f"{file_id[:8]}_{safe_filename}"

                # 婵″倹鐏夋潻妯绘Ц閸愯尙鐛婇敍鍫熺€純鏇☆潌閹懎鍠岄敍澶涚礉濞ｈ濮為弮鍫曟？閹?
                if safe_filename in used_filenames:
                    import time
                    timestamp = str(int(time.time() * 1000))[-6:]
                    if '.' in safe_filename:
                        name_part, ext_part = safe_filename.rsplit('.', 1)
                        safe_filename = f"{name_part}_{timestamp}.{ext_part}"
                    else:
                        safe_filename = f"{safe_filename}_{timestamp}"

                used_filenames.add(safe_filename)
                target_path = user_files_dir / safe_filename

                # 閺嶈宓侀弬鍥︽缁鐎烽崘鍐茬暰婵″倷缍嶆径鍕倞
                file_type = file_info.get('file_type', '').lower()
                source_path = file_info.get('source_path')  # 閸樼喎顫愰弬鍥︽鐠侯垰绶為敍鍫㈡暏娴滃骸顦查崚璁圭礆
                backend_content = file_info.get('content') or ''
                parse_metadata = file_info.get('parse_metadata') or {}

                # 娴滃矁绻橀崚鑸垫瀮娴犺绱橮DF閵嗕箘ord閵嗕笒xcel缁涘绱氶棁鈧憰浣烘纯閹恒儱顦查崚璺哄斧婵鏋冩禒?
                binary_extensions = {'.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.rtf', '.odt', '.epub'}
                is_binary = file_type in binary_extensions or any(
                    filename.lower().endswith(ext) for ext in binary_extensions)

                logger.info(
                    f"Processing file: {filename}, file_type={file_type}, is_binary={is_binary}, source_path={source_path}")

                if is_binary:
                    if not source_path:
                        logger.error(f"No source_path provided for binary file: {filename}")
                        continue

                    # 婢跺秴鍩楁禍宀冪箻閸掕埖鏋冩禒?
                    try:
                        source_file = Path(source_path)
                        if not source_file.exists():
                            logger.error(f"Source file not found: {source_path} (absolute: {source_file.absolute()})")
                            continue

                        # 閹笛嗩攽婢跺秴鍩?
                        shutil.copy2(source_file, target_path)
                        copied_size = target_path.stat().st_size
                        source_size = source_file.stat().st_size
                        logger.info(
                            f"Copied binary file: {source_file} ({source_size} bytes) -> {target_path} ({copied_size} bytes)")

                        # 妤犲矁鐦夋径宥呭煑閺勵垰鎯侀幋鎰
                        if copied_size != source_size:
                            logger.warning(f"File size mismatch: source={source_size}, target={copied_size}")

                        # 鐎甸€涚艾PDF閸滃瓕OCX閺傚洣娆㈤敍灞界毦鐠囨洘褰侀崣鏍ц嫙缂傛挸鐡ㄩ弬鍥ㄦ拱閻楀牊婀伴敍鍫濆讲闁绱崠鏍电礆
                        if file_type == '.pdf':
                            try:
                                # 閹绘劕褰嘝DF閺傚洦婀?
                                extracted_text = backend_content or self._read_pdf_text(target_path)
                                if extracted_text and len(extracted_text.strip()) > 100:
                                    # 娣囨繂鐡ㄩ弬鍥ㄦ拱缂傛挸鐡ㄩ敍鍫熸瀮娴犺泛鎮?pdf.txt閿?
                                    text_cache_path = target_path.with_suffix('.pdf.txt')
                                    with open(text_cache_path, 'w', encoding='utf-8') as f:
                                        f.write(extracted_text)
                                    logger.info(
                                        f"Created text cache for PDF: {text_cache_path} ({len(extracted_text)} chars)")
                                    if parse_metadata:
                                        pages_cache_path = target_path.with_suffix('.pdf.pages.json')
                                        with open(pages_cache_path, 'w', encoding='utf-8') as f:
                                            json.dump(parse_metadata, f, ensure_ascii=False, indent=2)
                                        logger.info(f"Created PDF page metadata cache: {pages_cache_path}")
                                    # 閺囧瓨鏌婃潻鏂挎礀鐠侯垰绶為敍灞肩喘閸忓牅濞囬悽銊︽瀮閺堫剛澧楅張顒婄礄Agent閸欘垯浜掗惄瀛樺复鐠囪褰囬弬鍥ㄦ拱閿?
                                    # 濞夈劍鍓伴敍姝匘F閸樼喐鏋冩禒宥囧姧娣囨繄鏆€閿涘本鏋冮張顒傜处鐎涙ɑ妲搁崣顖炩偓澶屾畱
                            except Exception as e:
                                logger.debug(f"Failed to create text cache for PDF {filename}: {e}")
                                # 缂傛挸鐡ㄦ径杈Е娑撳秴濂栭崫宥勫瘜濞翠胶鈻奸敍宀€鎴风紒顓濆▏閻⑩墥DF閸樼喐鏋?

                        elif file_type == '.docx':
                            try:
                                # 閹绘劕褰嘍OCX閺傚洦婀?
                                extracted_text = self._read_docx_text(target_path)
                                if extracted_text and len(extracted_text.strip()) > 100:
                                    # 娣囨繂鐡ㄩ弬鍥ㄦ拱缂傛挸鐡ㄩ敍鍫熸瀮娴犺泛鎮?docx.txt閿?
                                    text_cache_path = target_path.with_suffix('.docx.txt')
                                    with open(text_cache_path, 'w', encoding='utf-8') as f:
                                        f.write(extracted_text)
                                    logger.info(
                                        f"Created text cache for DOCX: {text_cache_path} ({len(extracted_text)} chars)")
                            except Exception as e:
                                logger.debug(f"Failed to create text cache for DOCX {filename}: {e}")
                                # 缂傛挸鐡ㄦ径杈Е娑撳秴濂栭崫宥勫瘜濞翠胶鈻奸敍宀€鎴风紒顓濆▏閻⑩€昈CX閸樼喐鏋?

                        elif file_type == '.doc':
                            try:
                                # 閹绘劕褰嘍OC閺傚洦婀?
                                extracted_text = self._read_doc_text(target_path)
                                if extracted_text and len(extracted_text.strip()) > 100:
                                    # 娣囨繂鐡ㄩ弬鍥ㄦ拱缂傛挸鐡ㄩ敍鍫熸瀮娴犺泛鎮?doc.txt閿?
                                    text_cache_path = target_path.with_suffix('.doc.txt')
                                    with open(text_cache_path, 'w', encoding='utf-8') as f:
                                        f.write(extracted_text)
                                    logger.info(
                                        f"Created text cache for DOC: {text_cache_path} ({len(extracted_text)} chars)")
                            except Exception as e:
                                logger.debug(f"Failed to create text cache for DOC {filename}: {e}")
                                # 缂傛挸鐡ㄦ径杈Е娑撳秴濂栭崫宥勫瘜濞翠胶鈻奸敍宀€鎴风紒顓濆▏閻⑩€昈C閸樼喐鏋?

                    except Exception as e:
                        logger.error(f"Error copying binary file {filename}: {e}", exc_info=True)
                        continue
                else:
                    # 閺傚洦婀伴弬鍥︽閿涙艾鍟撻崗銉︽瀮閺堫剙鍞寸€?
                    try:
                        content = file_info.get('content', '')
                        with open(target_path, 'w', encoding='utf-8') as f:
                            f.write(content)
                        logger.info(f"Written text file: {target_path} ({len(content)} chars)")
                    except Exception as e:
                        logger.error(f"Error writing text file {filename}: {e}", exc_info=True)
                        continue

                processed_files.append({
                    'file_id': file_id,
                    'filename': filename,
                    'local_path': f"./{target_subdir}/{safe_filename}",
                    'content_length': file_info.get('content_length', 0),
                    'parse_status': file_info.get('parse_status'),
                    'parse_metadata_path': f"./{target_subdir}/{Path(safe_filename).with_suffix('.pdf.pages.json').name}" if file_type == '.pdf' and parse_metadata else None,
                    'text_cache_path': f"./{target_subdir}/{Path(safe_filename).with_suffix('.pdf.txt').name}" if file_type == '.pdf' and file_info.get('parse_status') == 'parsed' else None,
                    'is_user_uploaded': True,
                    'priority': 'high',
                    'success': True
                })

            return MCPToolResult(
                success=True,
                data={
                    'files': processed_files,
                    'total_files': len(processed_files),
                    'user_files_directory': str(user_files_dir)
                }
            )

        except Exception as e:
            logger.error(f"Error processing user files: {e}")
            return MCPToolResult(success=False, error=str(e))

    def process_library_files(
            self,
            file_ids: List[str],
            backend_url: str = "http://localhost:5000",
            target_subdir: str = "library_refs"
    ) -> MCPToolResult:
        """Download and parse selected library files into the workspace."""
        try:
            if not file_ids:
                return MCPToolResult(success=False, error="No file IDs provided")

            library_files_dir = self.workspace_path / target_subdir
            library_files_dir.mkdir(parents=True, exist_ok=True)

            # 鐠嬪啰鏁?Flask 閸氬海顏?API閿涘牅绗?user_uploads 娴ｈ法鏁ら惄绋挎倱閻?API閿?
            response = requests.post(
                f"{backend_url}/api/user_files/download_and_parse",
                json={"file_ids": file_ids, "full_content": True},
                timeout=60
            )

            if not response.ok:
                return MCPToolResult(success=False, error=f"HTTP {response.status_code}")

            result_data = response.json()
            processed_files = []
            used_filenames = set()

            for file_info in result_data.get('files', []):
                if not file_info.get('success'):
                    continue

                file_id = file_info.get('file_id', '')
                filename = file_info.get('filename', 'unknown.txt')

                # 鐎瑰鍙忛崠鏍ㄦ瀮娴犺泛鎮?
                forbidden_chars = r'<>:"/\|?*'
                forbidden_chars += ''.join(chr(i) for i in range(32))
                safe_filename = "".join(c for c in filename if c not in forbidden_chars)
                safe_filename = safe_filename.strip(' .')
                if not safe_filename or safe_filename == '.':
                    safe_filename = f'file_{file_id[:8]}.pdf' if filename.endswith(
                        '.pdf') else f'file_{file_id[:8]}.txt'

                # 婢跺嫮鎮婇弬鍥︽閸氬秴鍟跨粣?
                if safe_filename in used_filenames:
                    if '.' in safe_filename:
                        name_part, ext_part = safe_filename.rsplit('.', 1)
                        safe_filename = f"{file_id[:8]}_{name_part}.{ext_part}"
                    else:
                        safe_filename = f"{file_id[:8]}_{safe_filename}"

                if safe_filename in used_filenames:
                    import time
                    timestamp = str(int(time.time() * 1000))[-6:]
                    if '.' in safe_filename:
                        name_part, ext_part = safe_filename.rsplit('.', 1)
                        safe_filename = f"{name_part}_{timestamp}.{ext_part}"
                    else:
                        safe_filename = f"{safe_filename}_{timestamp}"

                used_filenames.add(safe_filename)
                target_path = library_files_dir / safe_filename

                # 閺嶈宓侀弬鍥︽缁鐎烽崘鍐茬暰婵″倷缍嶆径鍕倞
                file_type = file_info.get('file_type', '').lower()
                source_path = file_info.get('source_path')
                backend_content = file_info.get('content') or ''
                parse_metadata = file_info.get('parse_metadata') or {}

                binary_extensions = {'.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.rtf', '.odt', '.epub'}
                is_binary = file_type in binary_extensions or any(
                    filename.lower().endswith(ext) for ext in binary_extensions)

                if is_binary and source_path:
                    # 婢跺秴鍩楁禍宀冪箻閸掕埖鏋冩禒?
                    try:
                        source_file = Path(source_path)
                        if source_file.exists():
                            shutil.copy2(source_file, target_path)

                            # 閸掓稑缂撻弬鍥ㄦ拱缂傛挸鐡ㄩ敍鍫滅瑢 user_uploads 閻╃鎮撻敍?
                            if file_type == '.pdf':
                                try:
                                    extracted_text = backend_content or self._read_pdf_text(target_path)
                                    if extracted_text and len(extracted_text.strip()) > 100:
                                        text_cache_path = target_path.with_suffix('.pdf.txt')
                                        with open(text_cache_path, 'w', encoding='utf-8') as f:
                                            f.write(extracted_text)
                                        logger.info(f"Created text cache for library PDF: {text_cache_path}")
                                        if parse_metadata:
                                            pages_cache_path = target_path.with_suffix('.pdf.pages.json')
                                            with open(pages_cache_path, 'w', encoding='utf-8') as f:
                                                json.dump(parse_metadata, f, ensure_ascii=False, indent=2)
                                            logger.info(f"Created PDF page metadata cache: {pages_cache_path}")
                                except Exception as e:
                                    logger.debug(f"Failed to create text cache for PDF {filename}: {e}")

                            elif file_type == '.docx':
                                try:
                                    extracted_text = self._read_docx_text(target_path)
                                    if extracted_text and len(extracted_text.strip()) > 100:
                                        text_cache_path = target_path.with_suffix('.docx.txt')
                                        with open(text_cache_path, 'w', encoding='utf-8') as f:
                                            f.write(extracted_text)
                                        logger.info(f"Created text cache for library DOCX: {text_cache_path}")
                                except Exception as e:
                                    logger.debug(f"Failed to create text cache for DOCX {filename}: {e}")
                    except Exception as e:
                        logger.error(f"Failed to copy library file {filename}: {e}")
                        continue
                else:
                    # 閺傚洦婀伴弬鍥︽閻╁瓨甯撮崘娆忓弳
                    content = file_info.get('content', '')
                    with open(target_path, 'w', encoding='utf-8') as f:
                        f.write(content)

                processed_files.append({
                    'file_id': file_id,
                    'filename': safe_filename,
                    'file_path': str(target_path.relative_to(self.workspace_path)),
                    'file_type': file_type,
                    'parse_status': file_info.get('parse_status'),
                    'parse_metadata_path': f"./{target_subdir}/{Path(safe_filename).with_suffix('.pdf.pages.json').name}" if file_type == '.pdf' and parse_metadata else None,
                    'text_cache_path': f"./{target_subdir}/{Path(safe_filename).with_suffix('.pdf.txt').name}" if file_type == '.pdf' and file_info.get('parse_status') == 'parsed' else None,
                    'is_library_file': True,
                    'priority': 'normal',  # 閸忔娊鏁敍姘瑝閺嶅洩顔囨稉娲彯娴兼ê鍘涚痪?
                    'success': True
                })

            logger.info(f"閴?閺傚洦銆傛惔鎾存瀮娴犺泛顦╅悶鍡楃暚閹? {len(processed_files)} 娑擃亝鏋冩禒璺哄嚒娣囨繂鐡ㄩ崚?{target_subdir}/")

            return MCPToolResult(
                success=True,
                data={
                    'files': processed_files,
                    'total_files': len(processed_files),
                    'library_files_directory': str(library_files_dir)
                }
            )

        except Exception as e:
            logger.error(f"Error processing library files: {e}")
            return MCPToolResult(success=False, error=str(e))

    # ================ WORKSPACE TOOLS ================

    def list_workspace(
            self,
            path: str = None,
            recursive: bool = False,
            include_hidden: bool = False,
            max_depth: int = 3
    ) -> MCPToolResult:
        """
        List files and directories in workspace with tree structure visualization
        
        Args:
            path: Specific path to list (relative to session workspace)
            recursive: Whether to list recursively
            include_hidden: Whether to include hidden files
            max_depth: Maximum recursion depth
        """
        try:
            if path:
                # Ensure path is relative to session workspace for security
                target_path = self._safe_join(path)
            else:
                target_path = self.workspace_path

            if not target_path.exists():
                return MCPToolResult(
                    success=False,
                    error=f"Path does not exist: {target_path}"
                )

            if not target_path.is_dir():
                return MCPToolResult(
                    success=False,
                    error=f"Path is not a directory: {target_path}"
                )

            # On Windows the workspace can be expressed through either a
            # long path or an 8.3 alias (for example ``tomatoorange`` versus
            # ``TOMATO~1``).  pathlib.relative_to treats those as unrelated
            # strings, while relpath correctly computes the display path.
            workspace_root_path = Path(os.path.realpath(str(self.workspace_path)))
            items = []
            tree_structure = []

            def _list_items(current_path: Path, current_depth: int = 0):
                if current_depth > max_depth:
                    return

                try:
                    # Get all items and sort them (directories first, then files, both alphabetically)
                    all_items = list(current_path.iterdir())
                    if not include_hidden:
                        all_items = [item for item in all_items if not item.name.startswith('.')]

                    # Sort: directories first, then files, both alphabetically
                    all_items.sort(key=lambda x: (not x.is_dir(), x.name.lower()))

                    for item in all_items:
                        item_info = {
                            'name': item.name,
                            'path': os.path.relpath(str(item), str(workspace_root_path)),
                            'type': 'directory' if item.is_dir() else 'file',
                            'size': item.stat().st_size if item.is_file() else None,
                            'modified': item.stat().st_mtime,
                            'depth': current_depth
                        }

                        items.append(item_info)

                        # Recurse into directories
                        if recursive and item.is_dir():
                            _list_items(item, current_depth + 1)

                except PermissionError:
                    pass  # Skip directories we can't read

            def _generate_tree_structure(current_path: Path, prefix: str = "", is_last: bool = True,
                                         current_depth: int = 0):
                """Generate ASCII tree structure recursively"""
                if current_depth > max_depth:
                    return

                try:
                    # Get all items and sort them (directories first, then files, both alphabetically)
                    all_items = list(current_path.iterdir())
                    if not include_hidden:
                        all_items = [item for item in all_items if not item.name.startswith('.')]

                    # Sort: directories first, then files, both alphabetically
                    all_items.sort(key=lambda x: (not x.is_dir(), x.name.lower()))

                    for i, item in enumerate(all_items):
                        is_last_item = i == len(all_items) - 1

                        # Choose the appropriate tree symbols
                        if is_last_item:
                            current_symbol = "閳规柡鏀㈤埞鈧?"
                            extension = "    "
                        else:
                            current_symbol = "閳规壕鏀㈤埞鈧?"
                            extension = "閳?  "

                        # Add file/directory indicator
                        if item.is_dir():
                            name_with_indicator = f"棣冩惂 {item.name}/"
                        else:
                            # Add file size for files
                            try:
                                size = item.stat().st_size
                                if size < 1024:
                                    size_str = f"{size}B"
                                elif size < 1024 * 1024:
                                    size_str = f"{size / 1024:.1f}KB"
                                else:
                                    size_str = f"{size / (1024 * 1024):.1f}MB"
                                name_with_indicator = f"棣冩惈 {item.name} ({size_str})"
                            except:
                                name_with_indicator = f"棣冩惈 {item.name}"

                        tree_line = prefix + current_symbol + name_with_indicator
                        tree_structure.append(tree_line)

                        # Recurse into directories
                        if recursive and item.is_dir():
                            _generate_tree_structure(
                                item,
                                prefix + extension,
                                is_last_item,
                                current_depth + 1
                            )

                except PermissionError:
                    tree_structure.append(prefix + "閳规柡鏀㈤埞鈧?[Permission Denied]")

            # Generate both flat list and tree structure
            _list_items(target_path)

            # Generate tree structure
            root_name = target_path.name if target_path.name else "workspace"
            tree_structure.append(f"棣冩惂 {root_name}/")

            if recursive:
                _generate_tree_structure(target_path)
            else:
                # For non-recursive, just show immediate children
                try:
                    all_items = list(target_path.iterdir())
                    if not include_hidden:
                        all_items = [item for item in all_items if not item.name.startswith('.')]

                    all_items.sort(key=lambda x: (not x.is_dir(), x.name.lower()))

                    for i, item in enumerate(all_items):
                        is_last_item = i == len(all_items) - 1
                        symbol = "閳规柡鏀㈤埞鈧?" if is_last_item else "閳规壕鏀㈤埞鈧?"

                        if item.is_dir():
                            name_with_indicator = f"棣冩惂 {item.name}/"
                        else:
                            try:
                                size = item.stat().st_size
                                if size < 1024:
                                    size_str = f"{size}B"
                                elif size < 1024 * 1024:
                                    size_str = f"{size / 1024:.1f}KB"
                                else:
                                    size_str = f"{size / (1024 * 1024):.1f}MB"
                                name_with_indicator = f"棣冩惈 {item.name} ({size_str})"
                            except:
                                name_with_indicator = f"棣冩惈 {item.name}"

                        tree_structure.append(symbol + name_with_indicator)

                except PermissionError:
                    tree_structure.append("閳规柡鏀㈤埞鈧?[Permission Denied]")

            # Create the tree string
            tree_string = "\n".join(tree_structure)

            return MCPToolResult(
                success=True,
                data={
                    'items': items,
                    'tree_structure': tree_string,
                    'tree_lines': tree_structure
                },
                metadata={
                    'target_path': os.path.relpath(str(target_path), str(workspace_root_path)) if path else '.',
                    'total_items': len(items),
                    'recursive': recursive,
                    'max_depth': max_depth,
                    'include_hidden': include_hidden
                }
            )

        except Exception as e:
            logger.error(f"List workspace failed: {e}")
            return MCPToolResult(success=False, error=str(e))

    # ================ FILE EDITING TOOLS ================
    def str_replace_based_edit_tool(
            self,
            action: str,
            file_path: str,
            content: str = None,
            old_str: str = None,
            new_str: str = None,
            line_number: int = None,
            max_char_len: int = 10000,
    ) -> MCPToolResult:
        """
        Comprehensive file editing tool
        
        Args:
            action: 'create', 'view', 'str_replace', 'insert', 'append', 'delete'
            file_path: Path to the file
            content: Content for create action
            old_str: String to replace (for str_replace)
            new_str: Replacement string (for str_replace)
            line_number: Line number for insert action
        """
        try:
            full_path = self._safe_join(file_path)

            if action == 'create':
                if full_path.exists():
                    return MCPToolResult(
                        success=False,
                        error=f"File already exists: {file_path}"
                    )

                full_path.parent.mkdir(parents=True, exist_ok=True)
                full_path.write_text(content or '', encoding='utf-8')

                return MCPToolResult(
                    success=True,
                    data=f"File created: {file_path}",
                    metadata={'file_size': full_path.stat().st_size}
                )

            elif action == 'view':
                if not full_path.exists():
                    return MCPToolResult(
                        success=False,
                        error=f"File does not exist: {file_path}"
                    )

                content = full_path.read_text(encoding='utf-8')
                if len(content) > max_char_len:
                    content = ("Due to the content being too long, only the first 10,000 characters are returned. "
                               "It is recommended to use other tools such as `document_qa` to extract the required content from the file. "
                               "Below is the returned portion of the file content: \n\n") + content[:max_char_len]

                return MCPToolResult(
                    success=True,
                    data=content,
                    metadata={
                        'file_size': len(content),
                        'line_count': len(content.splitlines())
                    }
                )

            elif action == 'str_replace':
                if not full_path.exists():
                    return MCPToolResult(
                        success=False,
                        error=f"File does not exist: {file_path}"
                    )

                if not old_str or new_str is None:
                    return MCPToolResult(
                        success=False,
                        error="Both old_str and new_str are required for str_replace"
                    )

                original_content = full_path.read_text(encoding='utf-8')

                if old_str not in original_content:
                    return MCPToolResult(
                        success=False,
                        error=f"String not found: {old_str[:50]}..."
                    )

                new_content = original_content.replace(old_str, new_str)
                full_path.write_text(new_content, encoding='utf-8')

                return MCPToolResult(
                    success=True,
                    data=f"Replaced {original_content.count(old_str)} occurrence(s)",
                    metadata={
                        'old_size': len(original_content),
                        'new_size': len(new_content)
                    }
                )

            elif action == 'insert':
                if not full_path.exists():
                    return MCPToolResult(
                        success=False,
                        error=f"File does not exist: {file_path}"
                    )

                if line_number is None or content is None:
                    return MCPToolResult(
                        success=False,
                        error="Both line_number and content are required for insert"
                    )

                lines = full_path.read_text(encoding='utf-8').splitlines()

                if line_number < 0 or line_number > len(lines):
                    return MCPToolResult(
                        success=False,
                        error=f"Invalid line number: {line_number}"
                    )

                lines.insert(line_number, content)
                full_path.write_text('\n'.join(lines), encoding='utf-8')

                return MCPToolResult(
                    success=True,
                    data=f"Inserted content at line {line_number}",
                    metadata={'new_line_count': len(lines)}
                )

            elif action == 'append':
                if not full_path.exists():
                    full_path.touch()

                with open(full_path, 'a', encoding='utf-8') as f:
                    f.write(content or '')

                return MCPToolResult(
                    success=True,
                    data=f"Appended content to {file_path}",
                    metadata={'file_size': full_path.stat().st_size}
                )

            elif action == 'delete':
                if not full_path.exists():
                    return MCPToolResult(
                        success=False,
                        error=f"File does not exist: {file_path}"
                    )

                full_path.unlink()

                return MCPToolResult(
                    success=True,
                    data=f"Deleted file: {file_path}"
                )

            else:
                return MCPToolResult(
                    success=False,
                    error=f"Unknown action: {action}"
                )

        except Exception as e:
            logger.error(f"File edit failed: {e}")
            return MCPToolResult(success=False, error=str(e))

    # ================ BASIC FILE TOOLS ================

    def file_read(self, file_path: str, encoding: str = 'utf-8', max_char_len: int = 10000) -> MCPToolResult:
        """Read file content with multi-encoding fallback"""
        try:
            full_path = self._safe_join(file_path)

            if not full_path.exists():
                return MCPToolResult(
                    success=False,
                    error=f"File does not exist: {file_path}"
                )

            # Try multiple encodings in fallback order
            encodings_to_try = [encoding] if encoding != 'utf-8' else []
            encodings_to_try.extend(['utf-8', 'utf-8-sig', 'gbk', 'gb2312', 'latin-1'])
            content = None
            used_encoding = encoding
            for enc in encodings_to_try:
                try:
                    content = full_path.read_text(encoding=enc)
                    used_encoding = enc
                    break
                except (UnicodeDecodeError, UnicodeError):
                    continue
            if content is None:
                return MCPToolResult(
                    success=False,
                    error=f"File cannot be decoded with any known encoding: {file_path}"
                )
            # Differential quota based on file source for optimal context usage
            # Dynamic quota strategy:
            # - With user files: user=15K, research=8K (prioritize user files)
            # - Without user files: research=15K (no competition, larger quota)
            is_user_file = 'user_uploads' in str(full_path)
            user_uploads_dir = self.workspace_path / "user_uploads"

            # Safe check for user files existence
            has_user_files = False
            try:
                has_user_files = user_uploads_dir.exists() and any(user_uploads_dir.iterdir())
            except Exception:
                has_user_files = False

            if is_user_file:
                max_chars = 15000
            else:
                max_chars = 15000 if not has_user_files else 8000

            original_char_count = len(content)
            was_truncated = original_char_count > max_chars
            returned_char_count = original_char_count
            if was_truncated:
                file_type = "user-uploaded file" if is_user_file else "research file"
                content = (
                    f"Due to the {file_type} content being too long, only the first {max_chars} characters are returned. "
                    "It is recommended to use other tools such as `document_qa` to extract the required content. "
                    f"Below is the first {max_chars} characters:\n\n" + content[:max_chars]
                )
                returned_char_count = len(content)

            return MCPToolResult(
                success=True,
                data=content,
                metadata={
                    'file_size': original_char_count,
                    'returned_char_count': returned_char_count,
                    'line_count': len(content.splitlines()),
                    'encoding': used_encoding,
                    'truncated': was_truncated,
                    'content_limit': max_chars,
                    'source_path': str(full_path),
                    'context_status': 'agent_context_truncated' if was_truncated else 'complete',
                    'warning': (
                        'The file-read response was truncated; this does not mean the source PDF was incompletely parsed.'
                        if was_truncated else None
                    ),
                }
            )

        except Exception as e:
            logger.error(f"File read failed: {e}")
            return MCPToolResult(success=False, error=str(e))

    def _read_pdf_text(self, path: Path) -> str:
        """Read PDF text through the centralized resource-bounded parser."""
        try:
            from pdf_pipeline import parse_pdf
            parsed = parse_pdf(path)
        except Exception as exc:
            logger.error(
                "Central PDF parser failed: error_type=%s",
                type(exc).__name__,
            )
            return ''

        if parsed.get('success'):
            logger.info(
                "PDF extracted with bounded parser: parser=%s",
                parsed.get('parser'),
            )
            return parsed.get('text') or ''

        logger.warning(
            "PDF extraction rejected: status=%s error_code=%s",
            parsed.get('extraction_status'),
            parsed.get('error_code'),
        )
        return ''

    def _read_docx_text(self, path: Path) -> str:
        """Read text from a DOCX file."""
        try:
            from docx import Document
            doc = Document(str(path))

            # 閹绘劕褰囬幍鈧張澶嬵唽閽€鑺ユ瀮閺?
            paragraphs = [para.text for para in doc.paragraphs if para.text.strip()]

            # 閹绘劕褰囩悰銊︾壐娑擃厾娈戦弬鍥ㄦ拱
            tables_text = []
            for table in doc.tables:
                for row in table.rows:
                    row_text = [cell.text.strip() for cell in row.cells if cell.text.strip()]
                    if row_text:
                        tables_text.append(' | '.join(row_text))

            # 閸氬牆鑻熷▓浣冩儰閸滃矁銆冮弽鍏兼瀮閺?
            all_text = paragraphs + tables_text
            result = '\n'.join(all_text)

            if result.strip():
                logger.info(f"Successfully extracted text from DOCX: {path} ({len(result)} chars)")
                return result
            else:
                logger.warning(f"DOCX file appears to be empty: {path}")
                return ''

        except ImportError:
            logger.error(f"python-docx library not installed. Please install: pip install python-docx")
            return ''
        except Exception as e:
            logger.error(f"Failed to extract text from DOCX {path}: {e}")
            return ''

    def _read_doc_text(self, path: Path) -> str:
        """Read text from a legacy DOC file when possible."""
        try:
            import win32com.client
            word = win32com.client.Dispatch("Word.Application")
            word.Visible = False
            doc = word.Documents.Open(str(path.absolute()))
            text = doc.Content.Text
            doc.Close()
            word.Quit()

            if text.strip():
                logger.info(f"Successfully extracted text from DOC using win32com: {path} ({len(text)} chars)")
                return text.strip()
        except ImportError:
            logger.debug(f"win32com not installed (pip install pywin32)")
        except Exception as e:
            logger.debug(f"win32com failed for {path}: {e}")

        # 閺傝顢?: 娴ｈ法鏁ntiword閿涘牐娉曢獮鍐插酱閿涘inux閺堝秴濮熼崳銊﹀腹閼芥劧绱?
        try:
            result = subprocess.run(
                ['antiword', str(path)],
                capture_output=True,
                text=True,
                timeout=30,
                check=False  # 娑撳秵濮忛崙鍝勭磽鐢潻绱濋柅姘崇箖returncode閸掋倖鏌?
            )
            if result.returncode == 0 and result.stdout.strip():
                text = result.stdout.strip()
                logger.info(f"Successfully extracted text from DOC using antiword: {path} ({len(text)} chars)")
                return text
            else:
                logger.debug(f"antiword returned code {result.returncode}, stderr: {result.stderr}")
        except FileNotFoundError:
            logger.debug(
                f"antiword not found. Install: apt-get install antiword (Linux) or choco install antiword (Windows)")
        except Exception as e:
            logger.debug(f"antiword failed for {path}: {e}")

        # 閺傝顢?: 娴ｈ法鏁extract閿涘湧ython鎼存搫绱濈捄銊ラ挬閸欓绲炬笟婵婄鏉堝啫顦块敍?
        try:
            import textract
            text = textract.process(str(path)).decode('utf-8')
            if text.strip():
                logger.info(f"Successfully extracted text from DOC using textract: {path} ({len(text)} chars)")
                return text.strip()
        except ImportError:
            logger.debug(f"textract not installed (pip install textract)")
        except Exception as e:
            logger.debug(f"textract failed for {path}: {e}")

        # 閹碘偓閺堝鏌熷▔鏇㈠厴婢惰精瑙?
        logger.warning(f"All DOC extraction methods failed for {path}. Recommendations:")
        logger.warning(f"  1. Install antiword: apt-get install antiword (Linux) or choco install antiword (Windows)")
        logger.warning(f"  2. Install pywin32: pip install pywin32 (Windows with MS Word)")
        logger.warning(f"  3. Install textract: pip install textract (requires system dependencies)")
        logger.warning(f"  4. Or convert the file to .docx/.pdf format manually")
        return ''  # 鏉╂柨娲栫粚鍝勭摟缁楋缚瑕嗛敍宀冾唨鐠嬪啰鏁ら弬鐟邦槱閻?

    def _normalize_report_part_path(self, file_path: str) -> str:
        """Normalize misformatted report chapter filenames.

        This fixes occasional LLM-generated paths like:
        - ./report/part_2_1.md
        - ./report/part_2.1.md
        - ./report/part_2.1..md

        and rewrites them to the canonical chapter filename:
        - ./report/part_2.md
        """
        try:
            path_obj = Path(file_path)
            filename = path_obj.name
            parts = path_obj.parts
            # Only normalize files under a report directory to avoid
            # touching unrelated paths.
            if "report" not in parts and path_obj.parent.name != "report":
                return file_path

            match = re.match(r'^part_(\d+)[\._]\d+.*\.md$', filename)
            if not match:
                return file_path

            chapter_index = match.group(1)
            normalized = path_obj.with_name(f"part_{chapter_index}.md")
            return normalized.as_posix()
        except Exception:
            # On any error, fall back to the original path
            return file_path

    def _clean_report_artifacts(self, content: str) -> str:
        """Clean internal marker tokens from final report content.

        This removes control tokens like [unused17] that come from the
        Pangu chat template, and normalizes accidental leakage of
        [webpaeg22] / [webpage22] markers into standard numeric
        citations [22].
        """
        if not content:
            return content

        try:
            # Remove any [unusedXX] style control tokens
            content = re.sub(r"\[unused\d+\]", "", content)

            # Normalize [webpaeg22] or [webpage22] -> [22]
            content = re.sub(r"\[webp(?:aeg|age)(\d+)\]", r"[\1]", content)

            # Normalize leaked PDF page markers into human-readable page
            # citations. The writer is instructed to emit [n] (p. N), but
            # models sometimes copy the source marker as [[page=N]].
            content = re.sub(r"(\[\d+\])\s*\[\[page=(\d+)\]\]", r"\1 (p. \2)", content)
            content = re.sub(r"\[\[page=(\d+)\]\]\s*(\[\d+\])", r"\2 (p. \1)", content)
            content = re.sub(r"\[\[page=(\d+)\]\]", r"(p. \1)", content)
        except Exception:
            # On regex errors, return original content to be safe
            return content

        return content

    def _has_inline_citations(self, content: str) -> bool:
        return bool(content and re.search(r"\[\d+\]", content))

    def _build_source_list_for_prompt(self, key_files: List[Dict]) -> str:
        lines = []
        for index, file_info in enumerate(key_files or [], 1):
            if isinstance(file_info, dict):
                label = file_info.get("title") or file_info.get("desc") or file_info.get("file_path") or "source"
                path = file_info.get("file_path") or file_info.get("path") or ""
                line = f"[{index}] {label}"
                if path and path not in line:
                    line += f" - {path}"
                lines.append(line)
            else:
                lines.append(f"[{index}] {str(file_info)}")
        return "\n".join(lines)

    def _repair_section_citations_if_needed(
            self,
            content: str,
            key_files: List[Dict],
            source_context: str,
            user_query: str,
            current_chapter_outline: str,
            model_url: str,
            model_config: Dict[str, Any],
            headers: Dict[str, str],
            temperature: float,
            max_tokens: int
    ) -> str:
        if not content or not key_files or self._has_inline_citations(content):
            return content

        source_list = self._build_source_list_for_prompt(key_files)
        repair_prompt = f"""
Rewrite the chapter below so citation format is correct.

Rules:
- Keep the same language, structure, headings, and main content.
- Use only the provided numbered sources.
- Every factual paragraph must include inline citations such as [1], [2].
- If the source text contains [[page=N]], cite page-specific evidence as [1] (p. N).
- Do not invent facts, page numbers, URLs, or source numbers.
- Return only the repaired chapter content, no explanation.

User query:
{user_query}

Current chapter outline:
{current_chapter_outline}

Draft chapter:
{content}

Numbered sources:
{source_list}

Source excerpts:
{source_context[:12000]}
""".strip()

        try:
            response = requests.post(
                url=model_url,
                headers=headers,
                json={
                    "model": model_config.get('model', 'pangu_auto'),
                    "messages": [
                        {"role": "system", "content": "You are a strict citation editor for research report chapters."},
                        {"role": "user", "content": repair_prompt + " /no_think"},
                    ],
                    "max_tokens": max_tokens,
                    "temperature": min(temperature or 0.2, 0.2),
                },
                timeout=model_config.get("timeout", 180)
            )
            response.raise_for_status()
            data = response.json()
            if isinstance(data, str):
                data = json.loads(data)
            repaired = data["choices"][0]["message"]["content"].strip()
            if repaired and self._has_inline_citations(repaired):
                return repaired
        except Exception as exc:
            logger.warning("Section citation repair failed: %s", exc)

        return content

    # ================ ENHANCED FILE ANALYSIS TOOLS ================

    def file_stats(self, file_path: str) -> MCPToolResult:
        """
        Get comprehensive file statistics without reading full content.
        Perfect for deciding whether to read full file or use targeted extraction.
        
        Args:
            file_path: Path to the file (relative to workspace)
        """
        try:
            full_path = self._safe_join(file_path)

            if not full_path.exists():
                return MCPToolResult(
                    success=False,
                    error=f"File does not exist: {file_path}"
                )

            if not full_path.is_file():
                return MCPToolResult(
                    success=False,
                    error=f"Path is not a file: {file_path}"
                )

            # Get basic file stats
            stat_info = full_path.stat()
            file_size = stat_info.st_size

            # Quick content analysis without loading full file
            encoding = 'utf-8'
            line_count = 0
            word_count = 0
            char_count = 0
            first_lines = []
            last_lines = []

            try:
                with open(full_path, 'r', encoding=encoding, errors='ignore') as f:
                    # Read first few lines for preview
                    for i, line in enumerate(f):
                        line_count += 1
                        if i < 5:  # First 5 lines
                            first_lines.append(line.rstrip())

                        char_count += len(line)
                        word_count += len(line.split())

                        # For efficiency, stop detailed counting after reasonable limit
                        if line_count > 10000:
                            # Estimate remaining based on average
                            remaining_size = file_size - f.tell()
                            if remaining_size > 0:
                                avg_line_size = f.tell() / line_count
                                estimated_remaining_lines = int(remaining_size / avg_line_size)
                                line_count += estimated_remaining_lines

                                # Estimate words and chars
                                avg_chars_per_line = char_count / min(line_count, 10000)
                                avg_words_per_line = word_count / min(line_count, 10000)
                                char_count += int(remaining_size)
                                word_count += int(estimated_remaining_lines * avg_words_per_line)
                            break

                # Get last few lines if file is reasonable size
                if file_size < 1024 * 1024:  # Less than 1MB
                    with open(full_path, 'r', encoding=encoding, errors='ignore') as f:
                        lines = f.readlines()
                        last_lines = [line.rstrip() for line in lines[-5:]]
                        if line_count <= 10000:  # Recalculate if we estimated
                            line_count = len(lines)
                            char_count = sum(len(line) for line in lines)
                            word_count = sum(len(line.split()) for line in lines)

            except Exception as e:
                # Try binary mode to at least get size info
                encoding = 'binary'
                char_count = file_size

            # Determine file type
            file_extension = full_path.suffix.lower()
            file_type = self._detect_file_type(full_path, file_extension)

            # Reading recommendation
            reading_recommendation = self._get_reading_recommendation(
                file_size, line_count, word_count, file_type
            )

            stats = {
                'file_path': file_path,
                'file_size_bytes': file_size,
                'file_size_human': self._format_file_size(file_size),
                'line_count': line_count,
                'word_count': word_count,
                'character_count': char_count,
                'encoding': encoding,
                'file_type': file_type,
                'file_extension': file_extension,
                'modified_time': stat_info.st_mtime,
                'is_large_file': file_size > 1024 * 1024,  # > 1MB
                'is_very_large_file': file_size > 10 * 1024 * 1024,  # > 10MB
                'first_lines_preview': first_lines,
                'last_lines_preview': last_lines,
                'reading_recommendation': reading_recommendation
            }

            return MCPToolResult(
                success=True,
                data=stats,
                metadata={
                    'analysis_method': 'efficient_sampling' if line_count > 10000 else 'full_analysis'
                }
            )

        except Exception as e:
            logger.error(f"File stats failed: {e}")
            return MCPToolResult(success=False, error=str(e))

    @staticmethod
    def _detect_file_type(file_path: Path, extension: str) -> str:
        """Detect file type based on extension and content"""

        # Extension-based detection
        type_map = {
            '.py': 'python_code',
            '.js': 'javascript_code',
            '.ts': 'typescript_code',
            '.java': 'java_code',
            '.cpp': 'cpp_code',
            '.c': 'c_code',
            '.html': 'html_markup',
            '.css': 'css_stylesheet',
            '.json': 'json_data',
            '.xml': 'xml_data',
            '.yaml': 'yaml_config',
            '.yml': 'yaml_config',
            '.md': 'markdown_document',
            '.txt': 'plain_text',
            '.csv': 'csv_data',
            '.sql': 'sql_code',
            '.sh': 'shell_script',
            '.dockerfile': 'docker_config',
            '.env': 'environment_config'
        }

        if extension in type_map:
            return type_map[extension]

        # Content-based detection for unknown extensions
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                first_line = f.readline().strip()

                if first_line.startswith('#!'):
                    return 'executable_script'
                elif first_line.startswith('<?xml'):
                    return 'xml_data'
                elif first_line.startswith('{') or first_line.startswith('['):
                    return 'json_data'
                elif 'DOCTYPE html' in first_line or '<html' in first_line:
                    return 'html_markup'
        except:
            pass

        return 'unknown_text'

    def _format_file_size(self, size_bytes: int) -> str:
        """Format file size in human readable format"""
        if size_bytes < 1024:
            return f"{size_bytes} B"
        elif size_bytes < 1024 * 1024:
            return f"{size_bytes / 1024:.1f} KB"
        elif size_bytes < 1024 * 1024 * 1024:
            return f"{size_bytes / (1024 * 1024):.1f} MB"
        else:
            return f"{size_bytes / (1024 * 1024 * 1024):.1f} GB"

    def _get_reading_recommendation(self, file_size: int, line_count: int,
                                    word_count: int, file_type: str) -> Dict[str, Any]:
        """Provide intelligent recommendations for how to read the file"""

        recommendations = {
            'strategy': 'full_read',
            'reason': 'File is small enough for full reading',
            'alternatives': []
        }

        # Large file strategies
        if file_size > 1024 * 1024:  # > 1MB
            recommendations['strategy'] = 'selective_read'
            recommendations['reason'] = 'File is large, consider targeted approaches'
            recommendations['alternatives'] = [
                'Use file_grep_with_context to search for specific content',
                'Use content_preview to get overview before full read',
                'Use file_read_lines to read specific sections',
                'Content indexing has been disabled'
            ]

        elif line_count > 1000:
            recommendations['strategy'] = 'preview_first'
            recommendations['reason'] = 'Many lines, preview recommended before full read'
            recommendations['alternatives'] = [
                'Use content_preview for quick overview',
                'Use file_grep_with_context for specific searches'
            ]

        # File type specific recommendations
        if file_type in ['json_data', 'xml_data']:
            recommendations['alternatives'].append('Consider parsing structure instead of full text read')
        elif file_type.endswith('_code'):
            recommendations['alternatives'].append('Use grep to find specific functions/classes')
        elif file_type == 'csv_data':
            recommendations['alternatives'].append('Consider reading headers first with file_read_lines')

        return recommendations

    # ================ BASIC FILE TOOLS ================
    def file_write(
            self,
            file_path: str,
            content: str,
            encoding: str = 'utf-8',
            create_dirs: bool = True
    ) -> MCPToolResult:
        """Write content to file"""
        try:
            try:
                path_obj = Path(file_path)
                parts = [p for p in path_obj.parts if p not in ('.',)]
                if parts and parts[0] == 'research' and path_obj.suffix.lower() == '.pdf':
                    new_path_obj = path_obj.with_suffix('.txt')
                    logger.info(f"Rewrite research PDF path to TXT: {file_path} -> {new_path_obj.as_posix()}")
                    file_path = new_path_obj.as_posix()
            except Exception:
                pass

            # Normalize misformatted report chapter filenames such as
            # ./report/part_2_1.md or ./report/part_2.1..md to
            # the canonical ./report/part_2.md format.
            try:
                file_path = self._normalize_report_part_path(file_path)
            except Exception:
                pass

            # For report markdown files, strip internal control markers like
            # [unused17] and normalize leaked [webpaeg22]/[webpage22] tokens
            # to standard numeric citations [22].
            try:
                path_obj = Path(file_path)
                parts = [p for p in path_obj.parts if p not in ('.',)]
                if ("report" in parts or path_obj.parent.name == "report") and path_obj.suffix.lower() == ".md":
                    content = self._clean_report_artifacts(content)
            except Exception:
                pass

            full_path = self._safe_join(file_path)

            if create_dirs:
                full_path.parent.mkdir(parents=True, exist_ok=True)

            # full_path.write_text(content, encoding=encoding)
            with open(full_path, "a", encoding=encoding) as f:
                f.write(content)

            return MCPToolResult(
                success=True,
                data=f"Written {len(content)} characters to {file_path}",
                metadata={
                    'file_size': full_path.stat().st_size,
                    'encoding': encoding
                }
            )

        except Exception as e:
            logger.error(f"File write failed: {e}")
            return MCPToolResult(success=False, error=str(e))

    # ================ SEARCH TOOLS ================

    def file_grep_search(
            self,
            pattern: str,
            file_pattern: str = "*",
            recursive: bool = True,
            ignore_case: bool = False,
            max_matches: int = 100
    ) -> MCPToolResult:
        """Search for pattern in files using grep-like functionality"""
        try:
            import fnmatch

            flags = re.IGNORECASE if ignore_case else 0
            regex = re.compile(pattern, flags)

            matches = []
            search_path = self.workspace_path

            def _search_file(file_path: Path):
                try:
                    content = file_path.read_text(encoding='utf-8', errors='ignore')
                    lines = content.splitlines()

                    for line_num, line in enumerate(lines, 1):
                        if regex.search(line):
                            matches.append({
                                'file': str(file_path.relative_to(self.workspace_path)),
                                'line_number': line_num,
                                'line_content': line.strip(),
                                'match_start': regex.search(line).start() if regex.search(line) else 0
                            })

                            if len(matches) >= max_matches:
                                return False  # Stop searching

                    return True

                except Exception:
                    return True  # Continue searching other files

            # Search files
            if recursive:
                for file_path in search_path.rglob(file_pattern):
                    if file_path.is_file():
                        if not _search_file(file_path):
                            break
            else:
                for file_path in search_path.glob(file_pattern):
                    if file_path.is_file():
                        if not _search_file(file_path):
                            break

            return MCPToolResult(
                success=True,
                data=matches,
                metadata={
                    'pattern': pattern,
                    'total_matches': len(matches),
                    'truncated': len(matches) >= max_matches
                }
            )

        except Exception as e:
            logger.error(f"Grep search failed: {e}")
            return MCPToolResult(success=False, error=str(e))

    def file_find_by_name(
            self,
            name_pattern: str,
            recursive: bool = True,
            case_sensitive: bool = False,
            max_results: int = 100
    ) -> MCPToolResult:
        """Find files by name pattern"""
        try:
            import fnmatch

            if not case_sensitive:
                name_pattern = name_pattern.lower()

            matches = []
            search_path = self.workspace_path

            def _match_name(file_path: Path) -> bool:
                name = file_path.name
                if not case_sensitive:
                    name = name.lower()

                return fnmatch.fnmatch(name, name_pattern)

            # Search files
            if recursive:
                for file_path in search_path.rglob("*"):
                    if _match_name(file_path):
                        matches.append({
                            'name': file_path.name,
                            'path': str(file_path.relative_to(self.workspace_path)),
                            'type': 'directory' if file_path.is_dir() else 'file',
                            'size': file_path.stat().st_size if file_path.is_file() else None
                        })

                        if len(matches) >= max_results:
                            break
            else:
                for file_path in search_path.iterdir():
                    if _match_name(file_path):
                        matches.append({
                            'name': file_path.name,
                            'path': str(file_path.relative_to(self.workspace_path)),
                            'type': 'directory' if file_path.is_dir() else 'file',
                            'size': file_path.stat().st_size if file_path.is_file() else None
                        })

                        if len(matches) >= max_results:
                            break

            return MCPToolResult(
                success=True,
                data=matches,
                metadata={
                    'pattern': name_pattern,
                    'total_matches': len(matches),
                    'truncated': len(matches) >= max_results
                }
            )

        except Exception as e:
            logger.error(f"File find failed: {e}")
            return MCPToolResult(success=False, error=str(e))

    def file_read_lines(
            self,
            file_path: str,
            start_line: int = 1,
            end_line: int = None,
            max_lines: int = 1000
    ) -> MCPToolResult:
        """
        Read specific line ranges from a file without loading the entire file.
        Perfect for reading specific sections after grep or for large files.
        
        Args:
            file_path: Path to the file
            start_line: Starting line number (1-based)
            end_line: Ending line number (1-based, None for end of file)
            max_lines: Maximum number of lines to read (safety limit)
        """
        try:
            full_path = self._safe_join(file_path)

            if not full_path.exists():
                return MCPToolResult(
                    success=False,
                    error=f"File does not exist: {file_path}"
                )

            if start_line < 1:
                return MCPToolResult(
                    success=False,
                    error="start_line must be >= 1"
                )

            lines_read = []
            current_line = 0

            with open(full_path, 'r', encoding='utf-8', errors='ignore') as f:
                for line in f:
                    current_line += 1

                    # Skip lines before start_line
                    if current_line < start_line:
                        continue

                    # Stop if we've reached end_line
                    if end_line and current_line > end_line:
                        break

                    # Safety check for max_lines
                    if len(lines_read) >= max_lines:
                        break

                    lines_read.append({
                        'line_number': current_line,
                        'content': line.rstrip('\n\r')
                    })

            # Calculate actual end line
            actual_end_line = lines_read[-1]['line_number'] if lines_read else start_line - 1

            return MCPToolResult(
                success=True,
                data={
                    'file_path': file_path,
                    'start_line': start_line,
                    'end_line': actual_end_line,
                    'lines': lines_read,
                    'line_count': len(lines_read)
                },
                metadata={
                    'total_lines_read': len(lines_read),
                    'truncated_due_to_max_lines': len(lines_read) >= max_lines
                }
            )

        except Exception as e:
            logger.error(f"File read lines failed: {e}")
            return MCPToolResult(success=False, error=str(e))

    # ================ BASH TOOLS ================

    def bash(
            self,
            command: str,
            timeout: int = 30,
            capture_output: bool = True,
            working_directory: str = None
    ) -> MCPToolResult:
        """Execute bash command"""
        try:
            # Security check - prevent dangerous commands
            dangerous_patterns = [
                r'rm\s+-rf\s+/',
                r'sudo\s+rm',
                r'mkfs',
                r'dd\s+if=.*of=/dev/',
                r'>\s*/dev/sd[a-z]',
                r'cat\s+.*>\s*/dev/sd[a-z]'
            ]

            for pattern in dangerous_patterns:
                if re.search(pattern, command, re.IGNORECASE):
                    return MCPToolResult(
                        success=False,
                        error=f"Potentially dangerous command blocked: {command}"
                    )

            # Set working directory
            cwd = self.workspace_path
            if working_directory:
                cwd = Path(working_directory)
                if not cwd.exists():
                    return MCPToolResult(
                        success=False,
                        error=f"Working directory does not exist: {working_directory}"
                    )

            # Execute command
            result = subprocess.run(
                command,
                # 閺嶅洩顔? 閸樼喎顫愰敍姝磆ell=True,
                shell=True,
                cwd=str(cwd),
                capture_output=capture_output,
                text=True,
                timeout=timeout
            )

            return MCPToolResult(
                success=result.returncode == 0,
                data={
                    'stdout': result.stdout if capture_output else None,
                    'stderr': result.stderr if capture_output else None,
                    'returncode': result.returncode,
                    'command': command
                },
                metadata={
                    'execution_time': timeout,
                    'working_directory': str(cwd)
                }
            )

        except subprocess.TimeoutExpired:
            return MCPToolResult(
                success=False,
                error=f"Command timed out after {timeout} seconds"
            )
        except Exception as e:
            logger.error(f"Bash command failed: {e}")
            return MCPToolResult(success=False, error=str(e))

    def assign_multi_tasks_to_info_seeker(
            self,
            tasks: List[Dict[str, str]],
            max_workers: int = 4
    ) -> MCPToolResult:
        """
        MCP Tool: Assign multiple tasks to InformationSeekerAgents for parallel execution

        Creates multiple TaskInput objects and routes them to info_seeker agents for concurrent execution.
        This tool enables the PlannerAgent to assign multiple research tasks through the MCP tool interface.

        Args:
            tasks: List of task dictionaries with the following keys:
                - task_content (required): The specific task content
                - task_steps_for_reference: Optional reference steps for execution
                - deliverable_contents: Format of expected deliverable
                - acceptance_checking_criteria: Criteria for task completion and quality
                - workspace_id: Workspace ID for stored files and memory
                - current_task_status: Description of current task status

            max_workers: Maximum concurrent threads (default=4)

        Returns:
            MCPToolResult with execution results for all tasks
        """
        try:
            # Validate task count (1-4 tasks)
            if not (1 <= len(tasks) <= 4):
                return MCPToolResult(
                    success=False,
                    error=f"Invalid task count ({len(tasks)}). Must assign 1-4 tasks."
                )

            # Import here to avoid circular imports
            try:
                from agents import TaskInput, create_information_seeker
            except ImportError:
                from ..agents import TaskInput, create_information_seeker

            results = []
            lock = threading.Lock()

            def process_task(task: Dict[str, str]):
                """Process a single task with thread-safe result collection"""
                try:
                    # Get workspace_id from task or set default
                    task_workspace_id = task.get("workspace_id")
                    if not task_workspace_id:
                        task_workspace_id = f"info_seeker_task_{int(time.time())}"

                    # Get current_task_status from task or set default
                    task_status = task.get("current_task_status")
                    if not task_status:
                        task_status = "Task assigned to InformationSeekerAgent for execution"

                    # Create TaskInput object
                    task_input = TaskInput(
                        task_content=task["task_content"],
                        task_steps_for_reference=task.get("task_steps_for_reference"),
                        deliverable_contents=task.get("deliverable_contents"),
                        current_task_status=task_status,
                        workspace_id=task_workspace_id,
                        acceptance_checking_criteria=task.get("acceptance_checking_criteria")
                    )

                    # Create and execute with info seeker agent
                    info_seeker = create_information_seeker(
                        workspace_path=str(self.workspace_path),
                    )

                    logger.info(f"Assigning task to InformationSeekerAgent: {task['task_content'][:800]}...")

                    # Execute the task
                    result = info_seeker.execute_task(task_input)

                    # Prepare response data
                    response_data = {
                        "task_assignment": {
                            "task_content": task["task_content"],
                            "task_executor": "info_seeker",
                            "workspace_id": task_workspace_id,
                            "acceptance_criteria": task.get("acceptance_checking_criteria")
                        },
                        "execution_result": {
                            "success": result.success,
                            "iterations": result.iterations,
                            "execution_time": result.execution_time,
                            "agent_name": result.agent_name
                        }
                    }

                    # Include result data if successful
                    if result.success and result.result:
                        response_data["task_result"] = result.result

                    # Include error if failed
                    if not result.success and result.error:
                        response_data["execution_result"]["error"] = result.error

                    # Include reasoning trace summary
                    if result.reasoning_trace:
                        response_data["execution_result"]["reasoning_steps"] = len([
                            step for step in result.reasoning_trace if step.get("type") == "reasoning"
                        ])
                        response_data["execution_result"]["action_steps"] = len([
                            step for step in result.reasoning_trace if step.get("type") == "action"
                        ])

                    # Thread-safe result collection
                    with lock:
                        results.append(response_data)

                    return response_data

                except Exception as e:
                    error_msg = f"Task processing failed: {str(e)}"
                    logger.error(error_msg)
                    with lock:
                        results.append({
                            "task_content": task.get("task_content", "Unknown task"),
                            "success": False,
                            "error": error_msg
                        })
                    return None

            # Execute tasks in parallel with thread pool
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = [executor.submit(process_task, task) for task in tasks]
                # Wait for all tasks to complete
                for future in futures:
                    future.result()  # Raise exceptions if any

            # Check overall success
            all_success = all(task_result.get("success", False) for task_result in results)

            return MCPToolResult(
                success=all_success,
                data={"tasks": results},
                error=None if all_success else "Some tasks failed",
                metadata={
                    "tool_name": "assign_multi_tasks_to_info_seeker",
                    "task_count": len(tasks),
                    "success_count": sum(1 for r in results if r.get("success")),
                    "failure_count": sum(1 for r in results if not r.get("success"))
                }
            )

        except Exception as e:
            logger.error(f"Multi-task assignment failed: {e}")
            return MCPToolResult(
                success=False,
                error=f"Multi-task assignment failed: {str(e)}"
            )

    def assign_task_to_info_seeker(
            self,
            task_content: str,
            task_steps_for_reference: str = None,
            deliverable_contents: str = None,
            acceptance_checking_criteria: str = None,
            workspace_id: str = None,
            current_task_status: str = None
    ) -> MCPToolResult:
        """
        MCP Tool: Assign a task to the InformationSeekerAgent

        Creates a TaskInput object and routes it to the info_seeker agent for execution.
        This tool enables the PlannerAgent to assign research and information gathering tasks
        through the standard MCP tool interface.

        Args:
            task_content: The specific task content for the info seeker
            task_steps_for_reference: Optional reference steps for execution
            deliverable_contents: Format of expected deliverable
            acceptance_checking_criteria: Criteria for task completion and quality
            workspace_id: Workspace ID for stored files and memory
            current_task_status: Description of current task status

        Returns:
            MCPToolResult with task execution results
        """
        try:
            # Import here to avoid circular imports
            try:
                from agents import TaskInput, create_information_seeker
            except ImportError:
                from ..agents import TaskInput, create_information_seeker

            # Set default workspace if not provided
            if not workspace_id:
                workspace_id = f"info_seeker_task_{int(time.time())}"

            # Set default status if not provided
            if not current_task_status:
                current_task_status = "Task assigned to InformationSeekerAgent for execution"

            # Create TaskInput object
            task_input = TaskInput(
                task_content=task_content,
                task_steps_for_reference=task_steps_for_reference,
                deliverable_contents=deliverable_contents,
                current_task_status=current_task_status,
                task_executor="info_seeker",
                workspace_id=workspace_id,
                acceptance_checking_criteria=acceptance_checking_criteria
            )

            # Create and execute with info seeker agent
            info_seeker = create_information_seeker(workspace_path=str(self.workspace_path))

            logger.info(f"Assigning task to InformationSeekerAgent: {task_content[:100]}...")

            # Execute the task
            result = info_seeker.execute_task(task_input)

            # Prepare response data
            response_data = {
                "task_assignment": {
                    "task_content": task_content,
                    "task_executor": "info_seeker",
                    "workspace_id": workspace_id,
                    "acceptance_criteria": acceptance_checking_criteria
                },
                "execution_result": {
                    "success": result.success,
                    "iterations": result.iterations,
                    "execution_time": result.execution_time,
                    "agent_name": result.agent_name
                }
            }

            # Include result data if successful
            if result.success and result.result:
                response_data["task_result"] = result.result

            # Include error if failed
            if not result.success and result.error:
                response_data["execution_result"]["error"] = result.error

            # Include reasoning trace summary
            if result.reasoning_trace:
                response_data["execution_result"]["reasoning_steps"] = len([
                    step for step in result.reasoning_trace if step.get("type") == "reasoning"
                ])
                response_data["execution_result"]["action_steps"] = len([
                    step for step in result.reasoning_trace if step.get("type") == "action"
                ])

            return MCPToolResult(
                success=result.success,
                data=response_data,
                error=result.error if not result.success else None,
                metadata={
                    "tool_name": "assign_task_to_info_seeker",
                    "task_executor": "info_seeker",
                    "workspace_id": workspace_id,
                    "execution_time": result.execution_time
                }
            )

        except Exception as e:
            logger.error(f"Error assigning task to info seeker: {e}")
            return MCPToolResult(
                success=False,
                error=f"Failed to assign task to InformationSeekerAgent: {str(e)}"
            )

    def assign_task_to_writer(
            self,
            # save_analysis_file_path: str,
            task_content: str,
            user_query: str,
            key_files: List[Dict[str, str]]
    ) -> MCPToolResult:
        """
        MCP Tool: Assign a task to the WriterAgent

        Creates a WriterAgentTaskInput object and routes it to the writer agent for execution.
        This tool enables the PlannerAgent to assign content creation and writing tasks
        through the standard MCP tool interface.

        Args:
            task_content: Detailed description of the writing task to be performed
            summary: Consolidated summary from information seeker results to guide outline generation and content structure
            key_files: Curated list of relevant files with file_path and desc for each file

        Returns:
            MCPToolResult with task execution results
        """
        try:
            # Import here to avoid circular imports
            try:
                from agents.base_agent import WriterAgentTaskInput
                from agents import create_writer_agent
            except ImportError:
                from ..agents.base_agent import WriterAgentTaskInput
                from ..agents import create_writer_agent

            # Generate workspace ID using timestamp
            workspace_id = f"writer_task_{int(time.time())}"

            # Create WriterAgentTaskInput object
            task_input = WriterAgentTaskInput(
                # save_analysis_file_path=save_analysis_file_path,
                user_query=user_query,
                task_content=task_content,
                key_files=key_files,
                workspace_id=workspace_id,
            )

            # Create and execute with writer agent
            writer = create_writer_agent(workspace_path=str(self.workspace_path))

            logger.info(f"Assigning task to WriterAgent: {task_content[:800]}...")

            # Execute the task
            result = writer.execute_task(task_input)

            # Prepare response data
            response_data = {
                "task_assignment": {
                    "task_content": task_content,
                    "task_executor": "writer",
                    "workspace_id": workspace_id,
                    "user_query": user_query,
                    "key_files_count": len(key_files)
                },
                "execution_result": {
                    "success": result.success,
                    "iterations": result.iterations,
                    "execution_time": result.execution_time,
                    "agent_name": result.agent_name
                }
            }

            # Include result data if successful
            if result.success and result.result:
                response_data["task_result"] = result.result

            # Include error if failed
            if not result.success and result.error:
                response_data["execution_result"]["error"] = result.error

            # Include reasoning trace summary
            if result.reasoning_trace:
                response_data["execution_result"]["reasoning_steps"] = len([
                    step for step in result.reasoning_trace if step.get("type") == "reasoning"
                ])
                response_data["execution_result"]["action_steps"] = len([
                    step for step in result.reasoning_trace if step.get("type") == "action"
                ])

            return MCPToolResult(
                success=result.success,
                data=response_data,
                error=result.error if not result.success else None,
                metadata={
                    "tool_name": "assign_task_to_writer",
                    "task_executor": "writer",
                    "workspace_id": workspace_id,
                    "execution_time": result.execution_time
                }
            )

        except Exception as e:
            logger.error(f"Error assigning task to writer: {e}")
            return MCPToolResult(
                success=False,
                error=f"Failed to assign task to WriterAgent: {str(e)}"
            )

    def assign_task_to_section_writer(
            self,
            task_content: str,
            write_file_path: str,
            user_query: str,
            overall_outline: str,
            current_chapter_outline: str,
            key_files: List[Dict[str, str]]
    ) -> MCPToolResult:
        """
        MCP Tool: Assign a task to the SectionWriterAgent

        Creates a SectionWriterTaskInput object and routes it to the section writer agent for execution.
        This tool enables the PlannerAgent to assign specific section writing tasks
        through the standard MCP tool interface.

        Args:
            write_file_path: The path where the section content should be written
            current_chapter_outline: The outline for the current chapter/section to be written
            key_files: Curated list of relevant files with file_path and desc for each file

        Returns:
            MCPToolResult with task execution results
        """
        try:
            # Import here to avoid circular imports
            try:
                from agents.base_agent import SectionWriterTaskInput
                from agents.section_writer import create_section_writer
            except ImportError:
                from ..agents.base_agent import SectionWriterTaskInput
                from ..agents.section_writer import create_section_writer

            # Generate workspace ID using timestamp
            workspace_id = f"section_writer_task_{int(time.time())}"

            # Create SectionWriterTaskInput object
            task_input = SectionWriterTaskInput(
                task_content=task_content,
                write_file_path=write_file_path,
                current_chapter_outline=current_chapter_outline,
                overall_outline=overall_outline,
                user_query=user_query,
                key_files=key_files,
                workspace_id=workspace_id,
            )

            # Create and execute with section writer agent
            section_writer = create_section_writer(workspace_path=str(self.workspace_path))

            logger.info(f"Assigning task to SectionWriterAgent: {write_file_path}")

            # Execute the task
            result = section_writer.execute_task(task_input, write_file_path)

            # Prepare response data
            response_data = {
                "task_assignment": {
                    "write_file_path": write_file_path,
                    "current_chapter_outline": current_chapter_outline,
                    "task_executor": "section_writer",
                    "workspace_id": workspace_id,
                    "key_files_count": len(key_files)
                },
                "execution_result": {
                    "success": result.success,
                    "iterations": result.iterations,
                    "execution_time": result.execution_time,
                    "agent_name": result.agent_name
                }
            }

            # Include result data if successful
            if result.success and result.result:
                response_data["task_result"] = result.result

            # Include error if failed
            if not result.success and result.error:
                response_data["execution_result"]["error"] = result.error

            # Include reasoning trace summary
            if result.reasoning_trace:
                response_data["execution_result"]["reasoning_steps"] = len([
                    step for step in result.reasoning_trace if step.get("type") == "reasoning"
                ])
                response_data["execution_result"]["action_steps"] = len([
                    step for step in result.reasoning_trace if step.get("type") == "action"
                ])

            return MCPToolResult(
                success=result.success,
                data=response_data,
                error=result.error if not result.success else None,
                metadata={
                    "tool_name": "assign_task_to_section_writer",
                    "task_executor": "section_writer",
                    "workspace_id": workspace_id,
                    "execution_time": result.execution_time
                }
            )

        except Exception as e:
            logger.error(f"Error assigning task to section writer: {e}")
            return MCPToolResult(
                success=False,
                error=f"Failed to assign task to SectionWriterAgent: {str(e)}"
            )

    def assign_task_to_agent(
            self,
            task_content: str,
            task_executor: str,
            task_steps_for_reference: str = None,
            deliverable_contents: str = None,
            acceptance_checking_criteria: str = None,
            workspace_id: str = None,
            current_task_status: str = None
    ) -> MCPToolResult:
        """
        MCP Tool: Generic task assignment to any agent

        Routes a task to the specified agent (info_seeker or writer).
        This provides a unified interface for task assignment.

        Args:
            task_content: The specific task content
            task_executor: Which agent to route to ("info_seeker" or "writer")
            task_steps_for_reference: Optional reference steps for execution
            deliverable_contents: Format of expected deliverable
            acceptance_checking_criteria: Criteria for task completion and quality
            workspace_id: Workspace ID for stored files and memory
            current_task_status: Description of current task status

        Returns:
            MCPToolResult with task execution results
        """
        try:
            # Validate task_executor
            if task_executor not in ["info_seeker", "writer"]:
                return MCPToolResult(
                    success=False,
                    error=f"Invalid task_executor '{task_executor}'. Must be 'info_seeker' or 'writer'"
                )

            # Route to specific assignment method
            if task_executor == "info_seeker":
                return self.assign_task_to_info_seeker(
                    task_content=task_content,
                    task_steps_for_reference=task_steps_for_reference,
                    deliverable_contents=deliverable_contents,
                    acceptance_checking_criteria=acceptance_checking_criteria,
                    workspace_id=workspace_id,
                    current_task_status=current_task_status
                )
            else:  # writer
                return MCPToolResult(
                    success=False,
                    error="Writer agent assignment via assign_task_to_agent is no longer supported. Use assign_task_to_writer directly with summary and key_files parameters."
                )

        except Exception as e:
            logger.error(f"Error in generic task assignment: {e}")
            return MCPToolResult(
                success=False,
                error=f"Failed to assign task: {str(e)}"
            )

    def semantic_search(self, **kwargs) -> MCPToolResult:
        """
        Search semantically through system-maintained knowledge index.
        Uses high-performance Faiss when available, fallback to JSON-based search.
        """
        try:
            # Extract parameters
            query = kwargs.get('query', '')
            max_tokens = kwargs.get('max_tokens', 2000)
            max_results = kwargs.get('max_results', 5)
            similarity_threshold = kwargs.get('similarity_threshold', 0.7)
            filters = kwargs.get('filters', {})

            if not query:
                return MCPToolResult(
                    success=False,
                    error="query is required for semantic search"
                )

            # Use unified model config (same as chat model)
            model_config = self.config.get_custom_llm_config()
            model_url = model_config.get('url') or os.getenv('MODEL_REQUEST_URL', '')
            model_token = model_config.get('token') or os.getenv('MODEL_REQUEST_TOKEN', '')
            model_name = model_config.get('model') or os.getenv('MODEL_NAME', 'deepseek-v4-flash')

            # Build embedding API URL from chat URL
            embedding_url = model_url.rstrip('/chat/completions') + '/embeddings'
            embedding_headers = {'Content-Type': 'application/json'}
            if model_token:
                embedding_headers['Authorization'] = f'Bearer {model_token}'

            # Use Faiss-based system if available for high performance
            if FAISS_AVAILABLE and get_optimized_knowledge_manager:
                try:
                    manager = get_optimized_knowledge_manager(self.config)
                    search_result = manager.search(
                        query=query,
                        max_tokens=max_tokens,
                        max_results=max_results,
                        similarity_threshold=similarity_threshold,
                        filters=filters
                    )

                    if search_result['success']:
                        return MCPToolResult(
                            success=True,
                            data=search_result
                        )
                    else:
                        # Fallback to JSON-based search on error
                        logger.warning(
                            f"Faiss search failed: {search_result.get('error')}, falling back to JSON search")
                except Exception as e:
                    logger.warning(f"Faiss search error: {e}, falling back to JSON search")

            # Fallback to JSON-based search
            logger.info("Using JSON-based search (install faiss-cpu for better performance)")

            # Use system-managed index (session_knowledge.json)
            index_file = "session_knowledge.json"
            try:
                with open(index_file, 'r', encoding='utf-8') as f:
                    index_data = json.load(f)
            except FileNotFoundError:
                return MCPToolResult(
                    success=True,
                    data={
                        'query': query,
                        'results': [],
                        'total_matches': 0,
                        'message': 'No knowledge index found yet. System will build index as agents complete tasks.',
                        'search_metadata': {
                            'similarity_threshold': similarity_threshold,
                            'max_tokens_requested': max_tokens,
                        'embedding_model': model_name,
                            'vector_store': 'JSON-based (fallback)'
                        }
                    }
                )

            if not index_data:
                return MCPToolResult(
                    success=True,
                    data={
                        'query': query,
                        'results': [],
                        'total_matches': 0,
                        'message': 'Knowledge index is empty.',
                        'search_metadata': {
                            'similarity_threshold': similarity_threshold,
                            'max_tokens_requested': max_tokens,
                            'embedding_model': model_name
                        }
                    }
                )

            # Generate query embedding using unified model config (DeepSeek)
            try:
                embedding_response = requests.post(
                    url=embedding_url,
                    headers=embedding_headers,
                    json={
                        "model": model_name,
                        "input": query
                    },
                    timeout=model_config.get("timeout", 30)
                )
                embedding_response.raise_for_status()
                embedding_data = embedding_response.json()
                query_embedding = embedding_data["data"][0]["embedding"]
            except Exception as e:
                logger.warning(f"DeepSeek embedding API failed: {e}. Trying fallback...")
                return MCPToolResult(
                    success=False,
                    error=f"Embedding API call failed: {str(e)}. Please check MODEL_REQUEST_URL and token configuration."
                )

            # Calculate similarities and apply filters
            candidate_results = []
            for item in index_data:
                # Apply filters
                if filters.get('task_name') and item['task_name'] != filters['task_name']:
                    continue
                if filters.get('file_path') and filters['file_path'] not in item['file_path']:
                    continue
                if filters.get('is_final_output') is not None and item['is_final_output'] != filters['is_final_output']:
                    continue

                # Calculate cosine similarity
                import numpy as np
                item_embedding = np.array(item['embedding'])
                query_emb = np.array(query_embedding)

                similarity = np.dot(query_emb, item_embedding) / (
                        np.linalg.norm(query_emb) * np.linalg.norm(item_embedding)
                )

                if similarity >= similarity_threshold:
                    candidate_results.append({
                        'task_name': item['task_name'],
                        'file_path': item['file_path'],
                        'file_desc': item['file_desc'],
                        'is_final_output': item['is_final_output'],
                        'chunk_index': item['chunk_index'],
                        'content': item['chunk_content'],
                        'similarity_score': float(similarity),
                        'token_count': item.get('token_count', len(item['chunk_content'].split()))
                    })

            # Sort by similarity
            candidate_results.sort(key=lambda x: x['similarity_score'], reverse=True)

            # Apply token limit - intelligent selection
            selected_results = []
            total_tokens = 0

            for result in candidate_results:
                result_tokens = result['token_count']
                if total_tokens + result_tokens <= max_tokens and len(selected_results) < max_results:
                    selected_results.append(result)
                    total_tokens += result_tokens
                elif len(selected_results) < max_results:
                    # Try to fit a shorter excerpt if we have space
                    remaining_tokens = max_tokens - total_tokens
                    if remaining_tokens > 100:  # Minimum meaningful excerpt
                        words = result['content'].split()
                        excerpt_words = words[:remaining_tokens]
                        excerpt_content = ' '.join(excerpt_words) + '...' if len(words) > remaining_tokens else result[
                            'content']

                        result_copy = result.copy()
                        result_copy['content'] = excerpt_content
                        result_copy['token_count'] = len(excerpt_words)
                        result_copy['is_excerpt'] = True

                        selected_results.append(result_copy)
                        total_tokens += len(excerpt_words)
                        break

            return MCPToolResult(
                success=True,
                data={
                    'query': query,
                    'results': selected_results,
                    'total_matches': len(candidate_results),
                    'tokens_used': total_tokens,
                    'search_metadata': {
                        'similarity_threshold': similarity_threshold,
                        'max_tokens_requested': max_tokens,
                        'max_results_requested': max_results,
                        'filters_applied': filters,
                        'embedding_model': model_name,
                        'total_candidates_found': len(candidate_results)
                    }
                }
            )

        except Exception as e:
            return MCPToolResult(
                success=False,
                error=f"Semantic search failed: {str(e)}"
            )

    def _create_text_chunks(self, text: str, chunk_size: int, overlap: int) -> List[str]:
        """
        Split text into overlapping chunks for better search coverage.
        Uses word-based chunking to maintain readability.
        """
        words = text.split()
        chunks = []

        for i in range(0, len(words), chunk_size - overlap):
            chunk_words = words[i:i + chunk_size]
            chunk_text = ' '.join(chunk_words)
            chunks.append(chunk_text)

            # Stop if we've reached the end
            if i + chunk_size >= len(words):
                break

        return chunks

    def knowledge_status(self, **kwargs) -> MCPToolResult:
        """
        Get status and statistics about the system-managed knowledge index.
        Shows which vector store system is active (Faiss vs JSON).
        """
        try:
            # Try Faiss-based system first for optimal performance
            if FAISS_AVAILABLE and get_optimized_knowledge_manager:
                try:
                    manager = get_optimized_knowledge_manager(self.config)
                    stats = manager.get_stats()

                    # Add system information
                    stats['vector_store_system'] = 'Faiss (High Performance)'
                    stats['performance'] = 'O(log n) search complexity'
                    stats['recommendation'] = 'Using optimal vector storage system'

                    return MCPToolResult(
                        success=True,
                        data=stats
                    )
                except Exception as e:
                    logger.warning(f"Faiss status error: {e}, checking JSON fallback")

            # Fallback to JSON-based system
            try:
                from knowledge.knowledge_manager import get_knowledge_manager
            except ImportError:
                from ..knowledge.knowledge_manager import get_knowledge_manager

            manager = get_knowledge_manager(self.config)
            stats = manager.get_index_stats()

            # Add performance information
            stats['vector_store_system'] = 'JSON-based (Fallback)'
            stats['performance'] = 'O(n) linear search'
            stats['recommendation'] = 'Install faiss-cpu for better performance: pip install faiss-cpu'

            return MCPToolResult(
                success=True,
                data=stats
            )

        except Exception as e:
            return MCPToolResult(
                success=False,
                error=f"Failed to get knowledge status: {str(e)}"
            )

    def search_pubmed_key_words(self, keywords, max_results=10) -> MCPToolResult:
        # 閻㈢喐鍨氶幖婊呭偍 URL
        try:
            search_url = generate_pubmed_search_url(term=keywords, num_results=max_results)
            logger.info("Generated URL: %s", search_url)

            # 閼惧嘲褰囬獮鎯靶掗弸鎰偝缁便垻绮ㄩ弸?
            pmids = search_pubmed(search_url)

            articles = []
            for pmid in pmids:
                metadata = get_pubmed_metadata(pmid)
                if metadata:
                    articles.append(metadata)

            return MCPToolResult(success=True, data=articles)
        except Exception as e:
            logger.error(e)
            return MCPToolResult(success=False, error=f"閼惧嘲褰噋ubmed娣団剝浼呮径杈Е!{e}")

    def search_pubmed_advanced(self, term, title, author, journal, start_date, end_date, num_results) -> MCPToolResult:
        # 閻㈢喐鍨氶幖婊呭偍 URL
        try:
            search_url = generate_pubmed_search_url(term=term, title=title, author=author,
                                                    journal=journal, start_date=start_date,
                                                    end_date=end_date, num_results=num_results)
            logger.info("Generated URL: %s", search_url)

            # 閼惧嘲褰囬獮鎯靶掗弸鎰偝缁便垻绮ㄩ弸?
            pmids = search_pubmed(search_url)

            articles = []
            for pmid in pmids:
                metadata = get_pubmed_metadata(pmid)
                if metadata:
                    articles.append(metadata)

            return MCPToolResult(success=True, data=articles)
        except Exception as e:
            logger.error(e)
            return MCPToolResult(success=False, error=f"閼惧嘲褰噋ubmed娣団剝浼呮径杈Е!{e}")

    def get_pubmed_article(self, pmid) -> MCPToolResult:
        logger.info(f"Attempting to access full text for PMID: {pmid}")
        try:
            # 妫ｆ牕鍘涢敍灞惧灉娴狀剟娓剁憰浣诡梾閺屻儴绻栫弧鍥ㄦ瀮缁旂姵妲搁崥锔芥箒PMC ID
            efetch_url = f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id={pmid}&retmode=xml"
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
            response = requests.get(efetch_url, headers=headers, verify=True, proxies=proxy)

            if response.status_code != 200:
                return f"Error: Unable to fetch article data (status code: {response.status_code})"

            root = ET.fromstring(response.content)
            pmc_id = root.find(".//ArticleId[@IdType='pmc']")

            if pmc_id is None:
                logger.info(f"No PMC ID found for PMID: {pmid}")
                pubmed_url = f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/"
                logger.info(f"You can check the article availability at: {pubmed_url}")
                return f"No PMC ID found for PMID: {pmid}" + "\n" + f"You can check the article availability at: {pubmed_url}"

            pmc_id = pmc_id.text

            # 濡偓閺屻儲鏋冪粩鐘虫Ц閸氾缚璐熷鈧弨鎹愵問闂?
            pmc_url = f"https://pmc.ncbi.nlm.nih.gov/articles/{pmc_id}/"
            pmc_response = requests.get(pmc_url, headers=headers, verify=True, proxies=proxy)
            if pmc_response.status_code != 200:
                return MCPToolResult(success=False, error=f"Unable to access PMC full text (status code: {pmc_response.status_code})")
            soup = BeautifulSoup(pmc_response.text, "html.parser")
            article = soup.get_text("\n", strip=True)
            logger.info("get pubmed content success")
            '''
            if pmc_response.status_code != 200:
                logger.error(f"Error: Unable to access PMC article page (status code: {pmc_response.status_code})")
                logger.info(f"You can check the article availability at: {pmc_url}")
                return f"Error: Unable to access PMC article page (status code: {pmc_response.status_code})" + "\n" + f"You can check the article availability at: {pmc_url}"f"You can check the article availability at: {pmc_url}"
            
            if "This article is available under a" not in pmc_response.text:
                logger.info(f"The article doesn't seem to be fully open access.")
                logger.info(f"You can check the article availability at: {pmc_url}")
                return f"The article doesn't seem to be fully open access." + "\n" + f"You can check the article availability at: {pmc_url}"
            
            # 鐏忔繆鐦稉瀣祰PDF
            pdf_url = f"https://www.ncbi.nlm.nih.gov/pmc/articles/{pmc_id}/pdf"
            pdf_response = requests.get(pdf_url, headers=headers,verify=False)
            
            if pdf_response.status_code != 200:
                logger.error(f"Error: Unable to download PDF (status code: {pdf_response.status_code})")
                logger.info(f"You can try accessing the article directly at: {pmc_url}")
                return f"Error: Unable to download PDF (status code: {pdf_response.status_code})" + "\n" + f"You can try accessing the article directly at: {pmc_url}"
            
            # 娣囨繂鐡≒DF閺傚洣娆?
            # filename = f"PMID_{pmid}_PMC_{pmc_id}.pdf"
            # with open(filename, 'wb') as f:
            #     f.write(pdf_response.content)
            
            # print(f"PDF for PMID {pmid} has been downloaded as {filename}")
            '''
            return MCPToolResult(success=True, data={"content": article, "pmid": str(pmid), "pmc_id": str(pmc_id), "source_url": pmc_url})
        except Exception as e:
            logger.error(e)
            return MCPToolResult(success=False, error=f"閼惧嘲褰噋ubmed鐠佺儤鏋冮崘鍛啇婢惰精瑙?{e}")

    def _normalize_arxiv_query(self, query: str) -> List[str]:
        raw_query = (query or "").strip()
        if not raw_query:
            return ['(ti:"machine learning" OR abs:"machine learning")']

        normalized = " ".join(raw_query.split())
        # Do not rewrite user terms through a fixed keyword-to-keyword
        # dictionary. The upstream planner may provide aliases dynamically;
        # this adapter only formats the supplied query for arXiv.
        queries = []
        seen = set()
        generic_terms = {
            "method", "methods", "analysis", "evaluation", "experiment", "experiments",
            "benchmark", "comparison", "performance", "architecture", "framework",
            "model", "models", "approach", "approaches", "research", "study",
        }

        def has_english_entity(value: str) -> bool:
            return bool(re.search(r"\b(?:ti|abs|all)\s*:\s*[\"']?[A-Za-z][A-Za-z0-9]*(?:[ -][A-Za-z][A-Za-z0-9-]*)*", value, re.I))

        def add(candidate: str):
            candidate = (candidate or "").strip()
            if candidate and candidate not in seen:
                seen.add(candidate)
                queries.append(candidate)

        def looks_like_anchor(token: str) -> bool:
            value = str(token or "")
            if len(value) < 3:
                return False
            return bool(
                value.isupper()
                or "-" in value
                or any(char.isdigit() for char in value)
                or any(char.isupper() for char in value[1:])
                or (value[0].isupper() and value[1:].islower())
            )

        def add_anchor_routes(tokens: List[str]) -> None:
            """Split novel multi-method queries before the broad exact routes."""
            anchors = list(dict.fromkeys(token for token in tokens if looks_like_anchor(token)))[:4]
            if len(anchors) < 2:
                return
            for index, left in enumerate(anchors):
                for right in anchors[index + 1:]:
                    add(f'(ti:"{left}" OR abs:"{left}") AND (ti:"{right}" OR abs:"{right}")')
            for anchor in anchors:
                add(f'(ti:"{anchor}" OR abs:"{anchor}")')

        has_field = ":" in normalized
        has_quotes = '"' in normalized
        if has_field and not has_quotes:
            field, value = normalized.split(":", 1)
            value = value.strip()
            if field.lower() in {"ti", "abs"} and " " in value:
                add(f'{field}:"{value}"')
                add(f'ti:"{value}" OR abs:"{value}"')
            elif field.lower() in {"ti", "abs"} and value:
                add(normalized)
            elif field.lower() not in {"all", "cat"} and value:
                add(normalized)
        elif not has_field and " " in normalized:
            # A natural-language planner returns term bundles, not exact paper
            # titles. Try an AND query before phrase matching so arXiv can
            # retrieve papers whose title/abstract uses the same concepts in a
            # different order.
            tokens = re.findall(r"[A-Za-z][A-Za-z0-9-]*", normalized)
            add_anchor_routes(tokens)
            entity_tokens = [token for token in tokens if token.lower() not in generic_terms]
            if entity_tokens:
                # Preserve the surrounding phrase when it contains a real
                # entity (e.g. ``world model``); generic words may be part of
                # a meaningful multi-word concept.
                phrase = " ".join(tokens[:6])
                add(f'(ti:"{phrase}" OR abs:"{phrase}")')
                if 2 <= len(tokens) <= 8:
                    add(" AND ".join(f"all:{token}" for token in tokens))
                # Only build phrase routes when at least one non-generic
                # entity survived; otherwise a relation-only query can pass
                # the old field check and reach arXiv as HTTP 400.
                add(f'ti:"{normalized}" OR abs:"{normalized}"')
                add(normalized)
        elif not has_field:
            tokens = re.findall(r"[A-Za-z][A-Za-z0-9-]*", normalized)
            entity_tokens = [token for token in tokens if token.lower() not in generic_terms]
            if entity_tokens:
                phrase = " ".join(entity_tokens[:6])
                add(f'(ti:"{phrase}" OR abs:"{phrase}")')
        else:
            add(normalized)

        # Never send a relation-only expression to arXiv. Such queries are
        # syntactically valid but semantically unbounded and often produce
        # HTTP 400 when assembled from malformed planner output. Exact arXiv
        # paper-ID routes ("id:2305.14314v1") are the exception: they are
        # fetched via the id_list parameter, so the entity gate does not
        # apply to them here or in arxiv_search below.
        valid = []
        for candidate in queries:
            if re.fullmatch(r"id:\s*[0-9]{4}\.[0-9]{4,5}(?:v[0-9]+)?\s*", candidate, re.I):
                valid.append(candidate)
                continue
            if not has_english_entity(candidate):
                continue
            syntax_ok, _reason = validate_arxiv_query(candidate)
            if syntax_ok:
                valid.append(candidate)
                continue
            repaired = repair_arxiv_query(candidate)
            if repaired and validate_arxiv_query(repaired)[0]:
                valid.append(repaired)
        return list(dict.fromkeys(valid))

    @staticmethod
    def arxiv_cooldown_remaining() -> float:
        """Seconds left on the arXiv 429 cooldown (0.0 when none or unknown).

        Read-only probe used by the retrieval loop so an active cooldown skips
        arXiv rounds (cooling_skip) instead of re-entering the adapter and
        re-reporting the same "cooldown active" error every round.
        """
        def probe(row):
            next_at, cooldown_until = row
            return (max(0.0, float(cooldown_until or 0.0) - time.time()), next_at, cooldown_until)
        try:
            return float(_arxiv_state_update(probe))
        except Exception:
            return 0.0

    @staticmethod
    def _reserve_arxiv_request(max_wait_seconds: Optional[float] = None) -> tuple[bool, float]:
        """Reserve one paced arXiv request or report the active 429 cooldown."""
        deadline = None if max_wait_seconds is None else time.monotonic() + max_wait_seconds
        interval = max(0.0, float(os.getenv("ARXIV_MIN_REQUEST_INTERVAL", "3.0")))

        def reserve(row):
            now = time.time()
            next_request_at, cooldown_until = row
            if now < cooldown_until:
                return (False, cooldown_until - now), next_request_at, cooldown_until
            wait_seconds = max(0.0, next_request_at - now)
            if deadline is not None and wait_seconds >= deadline - time.monotonic():
                raise TimeoutError("arXiv request pacing exceeds PDF download time budget")
            return (True, wait_seconds), now + wait_seconds + interval, cooldown_until

        if max_wait_seconds is None:
            permitted, wait_seconds = _arxiv_state_update(reserve)
        else:
            permitted, wait_seconds = _arxiv_state_update(reserve, timeout=min(30.0, max_wait_seconds))
        if not permitted:
            return False, wait_seconds
        if wait_seconds:
            time.sleep(wait_seconds)
        return True, 0.0

    @staticmethod
    def _start_arxiv_cooldown(response) -> float:
        """Avoid hammering the same public API after a rate-limit response."""
        retry_after = getattr(response, "headers", {}).get("Retry-After", "")
        try:
            delay = float(retry_after)
        except (TypeError, ValueError):
            delay = float(os.getenv("ARXIV_RATE_LIMIT_COOLDOWN", "30"))
        delay = min(max(delay, 5.0), 60.0)

        def start(row):
            next_request_at, cooldown_until = row
            return delay, next_request_at, max(cooldown_until, time.time() + delay)

        _arxiv_state_update(start)
        return delay

    @staticmethod
    def _start_arxiv_network_cooldown() -> float:
        """Short-circuit repeated waits when the API route is unreachable."""
        delay = min(max(float(os.getenv("ARXIV_NETWORK_COOLDOWN", "10")), 3.0), 30.0)

        def start(row):
            next_request_at, cooldown_until = row
            return delay, next_request_at, max(cooldown_until, time.time() + delay)

        _arxiv_state_update(start)
        return delay

    def arxiv_search(self, query: str, max_results: int = 10) -> MCPToolResult:
        # arxiv.org/api/query redirects to export.arxiv.org/api/query. Treating
        # it as an independent fallback only duplicates traffic to the same
        # legacy service and makes 429s more likely.
        base_urls = ("https://export.arxiv.org/api/query",)
        headers = {
            "User-Agent": os.getenv(
                "ARXIV_USER_AGENT", "SciAssistant/1.0 (research assistant)"
            )
        }
        errors = []
        successful_responses = 0
        aggregated_papers = []
        aggregated_ids = set()

        # Each generated query is already one route in the outer literature
        # ladder.  Expanding it again here multiplies requests and is an easy
        # way to trigger arXiv's per-client quota during a multi-round task.
        variant_limit = max(1, int(os.getenv("ARXIV_MAX_QUERY_VARIANTS", "1")))
        normalized_queries = self._normalize_arxiv_query(query)[:variant_limit]
        invalid_queries = []
        checked_queries = []
        for candidate in normalized_queries:
            # Exact arXiv ID lookups ("id:2305.14314v1") come from explicit
            # paper references in the question and inherited follow-up papers.
            # arXiv fetches them via the id_list parameter, so they are not
            # keyword searches and must not pass through the ti:/abs: entity
            # gate (which would reject them as entity-less).
            if re.fullmatch(r"id:\s*[0-9]{4}\.[0-9]{4,5}(?:v[0-9]+)?\s*", candidate, re.I):
                checked_queries.append(candidate)
                continue
            valid, reason = validate_arxiv_query(candidate)
            if valid:
                checked_queries.append(candidate)
            else:
                repaired = repair_arxiv_query(candidate)
                if repaired and validate_arxiv_query(repaired)[0]:
                    checked_queries.append(repaired)
                else:
                    invalid_queries.append(f"{reason}: {candidate}")
        normalized_queries = list(dict.fromkeys(checked_queries))[:variant_limit]
        if not normalized_queries:
            return MCPToolResult(
                success=False,
                error="arXiv query rejected: no English entity condition (ti:/abs:) was found",
                metadata={"query_rejected": True, "reason": "missing_english_entity_or_invalid_syntax", "invalid_queries": invalid_queries},
            )
        for search_query in normalized_queries:
            # A route that survived validation as "id:xxxx" is an exact paper
            # lookup; arXiv's id_list parameter fetches it directly. Everything
            # else keeps the relevance-sorted keyword search.
            id_lookup = None
            id_match = re.fullmatch(r"id:\s*([0-9]{4}\.[0-9]{4,5}(?:v[0-9]+)?)\s*", search_query, re.I)
            if id_match:
                id_lookup = id_match.group(1)
            if id_lookup:
                params = {
                    'id_list': id_lookup,
                    'max_results': max_results,
                }
            else:
                params = {
                    'search_query': search_query,
                    'max_results': max_results,
                    # Relevance is essential for scientific question answering.
                    # Submitted-date ranking turns broad research questions into a
                    # sample of this week's applications rather than papers about
                    # the requested phenomenon. Set ARXIV_SEARCH_SORT_BY to
                    # submittedDate when a caller explicitly needs recency.
                    'sortBy': os.getenv('ARXIV_SEARCH_SORT_BY', 'relevance'),
                    'sortOrder': 'descending'
                }
            for endpoint_index, base_url in enumerate(base_urls):
                try:
                    permitted, cooldown_remaining = self._reserve_arxiv_request()
                    if not permitted:
                        errors.append(
                            f"arXiv temporary request cooldown active ({cooldown_remaining:.1f}s remaining)"
                        )
                        break
                    # Hold the shared lock for the complete HTTP exchange,
                    # not only for request scheduling. arXiv asks clients to
                    # keep a single connection active at a time.
                    with _arxiv_cross_process_lock():
                        response = self.session.get(
                            base_url,
                            params=params,
                            headers=headers,
                            # Keep bounded literature retries from holding the whole
                            # answer open for several minutes when arXiv is slow or
                            # temporarily unreachable. The normal default is long
                            # enough for the small metadata response; deployments
                            # can raise it explicitly when needed.
                            timeout=int(os.getenv("ARXIV_SEARCH_TIMEOUT", "20")),
                            verify=True,
                            proxies=proxy,
                            allow_redirects=False,
                            stream=True,
                        )
                    _reject_arxiv_redirect(response)
                    response.raise_for_status()
                    successful_responses += 1
                    papers = _papers_from_arxiv_response(response)

                    if papers:
                        # Do not stop at the first non-empty route. The caller
                        # may have supplied model-generated facets plus
                        # deterministic fallbacks; aggregate them so a later
                        # route can add the paper that the first route missed.
                        for paper in papers:
                            paper_id = str(paper.get("paper_id", "") or paper.get("id", "")).lower()
                            key = re.sub(r"v\d+$", "", paper_id)
                            if key and key not in aggregated_ids:
                                aggregated_ids.add(key)
                                paper["found_by_queries"] = list(dict.fromkeys([
                                    *(paper.get("found_by_queries") or []), search_query
                                ]))
                                aggregated_papers.append(paper)
                    else:
                        errors.append(f"{base_url} {search_query}: empty result")
                    # One official endpoint is enough for a successful query.
                    break
                except Exception as e:
                    # A 429 is an infrastructure state, not a reason to retry
                    # the same query or to continue through later rounds.
                    response = getattr(e, "response", None)
                    if getattr(response, "status_code", None) == 429:
                        delay = self._start_arxiv_cooldown(response)
                        errors.append(f"{base_url} {search_query}: rate limited; cooling down for {delay:.0f}s")
                        break
                    if isinstance(e, (requests.exceptions.Timeout, requests.exceptions.ConnectionError)):
                        delay = self._start_arxiv_network_cooldown()
                        errors.append(f"{base_url} {search_query}: network unavailable; cooling down for {delay:.0f}s")
                        break
                    status_code = getattr(response, "status_code", None)
                    if status_code == 400:
                        repaired = repair_arxiv_query(search_query)
                        if repaired and repaired != search_query and validate_arxiv_query(repaired)[0]:
                            # Retry once with a conservative legal query. The
                            # next loop iteration is intentionally local and
                            # does not expand the external request fan-out.
                            try:
                                permitted, cooldown_remaining = self._reserve_arxiv_request()
                                if permitted:
                                    with _arxiv_cross_process_lock():
                                        retry_response = self.session.get(
                                            base_url, params={**params, "search_query": repaired},
                                            headers=headers, timeout=int(os.getenv("ARXIV_SEARCH_TIMEOUT", "20")),
                                            verify=True, proxies=proxy, allow_redirects=False, stream=True,
                                        )
                                    _reject_arxiv_redirect(retry_response)
                                    retry_response.raise_for_status()
                                    for paper in _papers_from_arxiv_response(retry_response):
                                        key = re.sub(r"v\d+$", "", str(paper.get("paper_id", "")).lower())
                                        if key and key not in aggregated_ids:
                                            aggregated_ids.add(key)
                                            paper["found_by_queries"] = [repaired]
                                            aggregated_papers.append(paper)
                                    successful_responses += 1
                                    break
                            except Exception as retry_error:
                                logger.warning("arXiv repaired query failed: %s", type(retry_error).__name__)
                                errors.append(f"{base_url} repaired query failed")
                                fallback_query = simplify_arxiv_query(repaired)
                                if fallback_query and fallback_query != repaired:
                                    try:
                                        permitted, _ = self._reserve_arxiv_request()
                                        if permitted:
                                            with _arxiv_cross_process_lock():
                                                fallback_response = self.session.get(
                                                    base_url, params={**params, "search_query": fallback_query},
                                                    headers=headers, timeout=int(os.getenv("ARXIV_SEARCH_TIMEOUT", "20")),
                                                    verify=True, proxies=proxy, allow_redirects=False, stream=True,
                                                )
                                            _reject_arxiv_redirect(fallback_response)
                                            fallback_response.raise_for_status()
                                            for paper in _papers_from_arxiv_response(fallback_response):
                                                key = re.sub(r"v\d+$", "", str(paper.get("paper_id", "")).lower())
                                                if key and key not in aggregated_ids:
                                                    aggregated_ids.add(key)
                                                    paper["found_by_queries"] = [fallback_query]
                                                    aggregated_papers.append(paper)
                                            successful_responses += 1
                                            break
                                    except Exception as fallback_error:
                                        logger.warning("arXiv simplified query failed: %s", type(fallback_error).__name__)
                                        errors.append(f"{base_url} simplified query failed")
                        errors.append(f"{base_url} {search_query}: HTTP 400; query rejected or repair failed")
                    else:
                        logger.warning("arXiv query failed: %s", type(e).__name__)
                        errors.append(f"{base_url} {search_query}: request failed")

        if aggregated_papers:
            return MCPToolResult(
                success=True,
                data={"papers": aggregated_papers[:max_results],
                      "query_used": query,
                      "query_variants_used": normalized_queries},
                metadata={"warnings": errors},
            )

        # arXiv's Atom endpoint is occasionally much less reliable than its
        # paper detail page.  An exact ID is still a first-party, verifiable
        # metadata lookup, so use that page as a narrowly scoped fallback.
        # This deliberately does not apply to broad keyword searches.
        exact_id = re.fullmatch(r"\s*id:([0-9]{4}\.[0-9]{4,5}(?:v\d+)?)\s*", str(query or ""), re.I)
        if exact_id:
            paper_id = exact_id.group(1)
            try:
                # Keep exact-ID lookups serialized with API traffic. This
                # fallback is intentionally narrow and does not expand broad
                # keyword searches into another request route.
                with _arxiv_cross_process_lock():
                    response = requests.get(
                        f"https://arxiv.org/abs/{paper_id}",
                        headers=headers,
                        timeout=int(os.getenv("ARXIV_DETAIL_TIMEOUT", "30")),
                        verify=True,
                        proxies=proxy,
                        allow_redirects=False,
                    )
                _reject_arxiv_redirect(response)
                response.raise_for_status()
                soup = BeautifulSoup(response.content, "html.parser")
                title_node = soup.select_one("meta[name='citation_title']")
                abstract_node = soup.select_one("blockquote.abstract")
                title = title_node.get("content", "").strip() if title_node else ""
                abstract = abstract_node.get_text(" ", strip=True).removeprefix("Abstract:").strip() if abstract_node else ""
                if not title or not abstract:
                    raise ValueError("arXiv detail page did not contain citation title and abstract")
                authors = [
                    node.get("content", "").strip()
                    for node in soup.select("meta[name='citation_author']")
                    if node.get("content", "").strip()
                ]
                date_node = soup.select_one("meta[name='citation_date']")
                published = dateutil.parser.parse(date_node.get("content")) if date_node and date_node.get("content") else datetime.utcnow()
                category_node = soup.select_one("span.primary-subject")
                categories = [category_node.get_text(" ", strip=True)] if category_node else []
                paper = Paper(
                    paper_id=paper_id,
                    title=title,
                    authors=authors,
                    abstract=abstract,
                    url=f"https://arxiv.org/abs/{paper_id}",
                    pdf_url=f"https://arxiv.org/pdf/{paper_id}",
                    published_date=published,
                    updated_date=published,
                    source="arxiv",
                    categories=categories,
                    keywords=[],
                    doi="",
                ).to_dict()
                return MCPToolResult(
                    success=True,
                    data={"papers": [paper], "query_used": query, "fallback": "arxiv_abs_html"},
                    metadata={"warnings": errors},
                )
            except Exception as exc:
                logger.warning("arXiv detail fallback failed: %s", type(exc).__name__)
                errors.append(f"https://arxiv.org/abs/{paper_id}: request failed")

        if successful_responses == 0 and errors:
            rate_limited = any("rate limited" in error for error in errors)
            return MCPToolResult(
                success=False,
                error=("arXiv search paused because the official API rate limit is active."
                       if rate_limited else "arXiv search failed after trying the configured endpoints."),
                data={"papers": [], "query_used": query},
                metadata={"warnings": errors, "failure_type": "rate_limited" if rate_limited else "network"},
            )
        return MCPToolResult(
            success=True,
            data={"papers": [], "query_used": query},
            metadata={"warnings": errors}
        )

    def download_pdf(self, paper_id: str, save_path: str, total_timeout: float = 90.0, *, trace=None) -> str:
        """Download/reuse a complete PDF using one retry budget and an atomic cache."""
        output_dir = Path(save_path)
        if not output_dir.is_absolute():
            output_dir = self.workspace_path / output_dir
        return download_arxiv_pdf(
            paper_id, output_dir, total_timeout=total_timeout,
            reserve_request=self._reserve_arxiv_request,
            network_cooldown=self._start_arxiv_network_cooldown,
            rate_limit_cooldown=self._start_arxiv_cooldown,
            request_get=requests.get, proxies=proxy, trace=trace,
        )

    @diagnostic_timed("arxiv_fulltext_read", source="mcp_tools")
    def arxiv_read_paper(
        self,
        paper_id: str,
        save_path: str = "./arxiv",
        pdf_parse_mode: Optional[str] = None,
    ) -> MCPToolResult:
        """Download/read an arXiv PDF and extract page-aware full text."""
        trace = ReadTrace()
        try:
            from pdf_pipeline import build_parse_metadata, parse_pdf

            output_dir = Path(save_path)
            if not output_dir.is_absolute():
                output_dir = self.workspace_path / output_dir
            output_dir.mkdir(parents=True, exist_ok=True)

            safe_id = paper_id.replace('/', '_')
            pdf_path = output_dir / f"{safe_id}.pdf"
            txt_path = output_dir / f"{safe_id}.txt"
            pages_cache_path = output_dir / f"{safe_id}.pdf.pages.json"
            metadata_cache_path = output_dir / f"{safe_id}.pdf.parse.json"

            # Existing files also pass through the completeness/locking guard;
            # a stale partial cache must not be passed directly to the parser.
            with trace.phase("pdf_acquire"):
                pdf_path = Path(self.download_pdf(paper_id, str(output_dir), trace=trace))

            parsed = None
            cache_hit = False
            # Reuse a complete local parse only when all cache artifacts are
            # present and tied to the current PDF size/mtime. A partial or
            # stale cache falls through to the normal parser.
            if txt_path.exists() and pages_cache_path.exists() and metadata_cache_path.exists():
                try:
                    cached = json.loads(metadata_cache_path.read_text(encoding='utf-8'))
                    stat = pdf_path.stat()
                    if (
                        cached.get('cache_version') == 1
                        and cached.get('pdf_size') == stat.st_size
                        and abs(float(cached.get('pdf_mtime', 0)) - stat.st_mtime) < 1e-6
                        and cached.get('success') is True
                    ):
                        pages = json.loads(pages_cache_path.read_text(encoding='utf-8'))
                        text = txt_path.read_text(encoding='utf-8', errors='replace')
                        parsed = {
                            'success': True,
                            'text': text,
                            'pages': pages,
                            'page_count': cached.get('page_count', len(pages)),
                            'text_page_count': cached.get('text_page_count', len(pages)),
                            'empty_page_count': cached.get('empty_page_count', 0),
                            'content_length': len(text),
                            'parser': cached.get('parser'),
                            'parse_quality': cached.get('parse_quality') or {},
                            'extraction_status': cached.get('extraction_status'),
                            'layout_blocks': cached.get('layout_blocks') or [],
                            'cache_hit': True,
                        }
                        cache_hit = True
                        logger.info("Reusing cached arXiv PDF parse for %s", paper_id)
                except Exception as cache_error:
                    logger.warning("Ignoring invalid arXiv parse cache for %s: %s", paper_id, cache_error)
            if parsed is None:
                with trace.phase("pdf_parse"):
                    parsed = parse_pdf(pdf_path)
                if not parsed.get('success'):
                    trace.events[-1].update(status="failed", error_type="ParseResultFailure")
            if not parsed.get('success'):
                return MCPToolResult(
                    success=False,
                    error=parsed.get('error') or 'Failed to parse arXiv PDF',
                    metadata={
                        'read_diagnostics': trace.events,
                        'paper_id': paper_id,
                        'pdf_path': str(pdf_path),
                        'parse_status': parsed.get('extraction_status'),
                        'page_count': parsed.get('page_count', 0),
                    }
                )

            txt_path.write_text(parsed.get('text', ''), encoding='utf-8')
            pages_cache_path.write_text(json.dumps(parsed.get('pages', []), ensure_ascii=False, indent=2), encoding='utf-8')

            parse_quality = parsed.get('parse_quality') or {}
            parse_metadata = build_parse_metadata(parsed, preview_chars=300)
            # The MCP server is a separate process.  The caller therefore
            # sends the selected mode explicitly instead of relying on its
            # in-process configuration context.
            with temporary_pdf_parse_mode(pdf_parse_mode):
                runtime_config = get_config()
            parse_mode = str(getattr(runtime_config, 'pdf_parse_mode', 'local') or 'local')
            if parse_mode == 'hybrid':
                llama_full_pdf = run_llama_full_pdf_enhancement(
                    pdf_path, runtime_config,
                    output_dir / f"{safe_id}.llamaparse.full.md",
                )
                llama_vision = run_llama_vision_enhancement(
                    pdf_path, parsed, runtime_config,
                    self.workspace_path / '.cache' / 'llama_vision', visual_only=True,
                )
            elif parse_mode == 'llama_full':
                llama_vision = {"enabled": False, "status": "disabled", "reason": "PDF_PARSE_MODE=llama_full", "regions": []}
                llama_full_pdf = run_llama_full_pdf_enhancement(
                    pdf_path, runtime_config,
                    output_dir / f"{safe_id}.llamaparse.full.md",
                )
            else:
                llama_vision = {"enabled": False, "status": "disabled", "reason": "PDF_PARSE_MODE=local", "regions": []}
                llama_full_pdf = {"enabled": False, "status": "disabled", "reason": "PDF_PARSE_MODE=local"}

            hybrid_evidence = {}
            hybrid_evidence_path = ''
            if parse_mode == 'hybrid':
                try:
                    hybrid_evidence = build_hybrid_evidence_ledger(
                        str(pdf_path), llama_vision, runtime_config.llama_vision_min_confidence,
                    )
                    hybrid_evidence_path = str(output_dir / f"{safe_id}.hybrid.evidence.json")
                    Path(hybrid_evidence_path).write_text(
                        json.dumps(hybrid_evidence, ensure_ascii=False, indent=2), encoding='utf-8',
                    )
                except Exception as ledger_error:
                    logger.warning("Failed to write hybrid evidence ledger for %s: %s", paper_id, ledger_error)
            if llama_vision.get("regions"):
                parsed["llama_vision"] = llama_vision
            # The selected cloud strategy must change the evidence handed to
            # downstream agents. Keep local geometry and risk metadata, but
            # use the completed LlamaParse transcription as the primary text
            # for full-Llama and hybrid requests.
            evidence_text = parsed.get('text', '')
            llama_text_path = Path(str(llama_full_pdf.get('text_path') or ''))
            if (
                parse_mode in {'llama_full', 'hybrid'}
                and llama_full_pdf.get('status') == 'completed'
                and llama_text_path.is_file()
            ):
                evidence_text = llama_text_path.read_text(encoding='utf-8', errors='replace')
            try:
                stat = pdf_path.stat()
                metadata_cache_path.write_text(json.dumps({
                    'cache_version': 1,
                    'success': True,
                    'pdf_size': stat.st_size,
                    'pdf_mtime': stat.st_mtime,
                    'page_count': parsed.get('page_count', 0),
                    'text_page_count': parsed.get('text_page_count', 0),
                    'empty_page_count': parsed.get('empty_page_count', 0),
                    'parser': parsed.get('parser'),
                    'extraction_status': parsed.get('extraction_status'),
                    'parse_quality': parse_quality,
                    'layout_blocks': parsed.get('layout_blocks', []),
                }, ensure_ascii=False), encoding='utf-8')
            except Exception as cache_error:
                logger.warning("Failed to write arXiv parse cache for %s: %s", paper_id, cache_error)

            return MCPToolResult(
                success=True,
                data={
                    "paper": evidence_text,
                    "local_paper": parsed.get('text', ''),
                    "paper_id": paper_id,
                    "pdf_path": str(pdf_path),
                    "text_path": str(txt_path),
                    "parse_metadata_path": str(pages_cache_path),
                    "parse_metadata_cache_path": str(metadata_cache_path),
                    "citation_hint": "Use [n] (p. N) when citing page-specific PDF evidence.",
                    "parse_quality": parse_quality,
                    "risk_summary": parse_metadata.get('risk_summary', {}),
                    "parser_status": parse_metadata.get('parser_status', {}),
                    "layout_blocks": parsed.get('layout_blocks', []),
                     "parse_metadata": parse_metadata,
                     "llama_vision": llama_vision,
                    "llama_full_pdf": llama_full_pdf,
                    "llama_full_pdf_text_path": llama_full_pdf.get("text_path", ""),
                    "pdf_parse_mode": parse_mode,
                    "hybrid_evidence": hybrid_evidence,
                    "hybrid_evidence_path": hybrid_evidence_path,
                    "source_integrity": {
                        "parser_text_complete": bool(
                            parsed.get('page_count') is not None
                            and parsed.get('text_page_count') == parsed.get('page_count')
                        ),
                        "parser_content_length": parsed.get('content_length', 0),
                        "agent_context_truncation": False,
                        "note": (
                            "Parser status describes the full PDF extraction. Any later file/tool "
                            "reading limit must be reported separately as Agent context truncation."
                        ),
                    },
                    "cache": {
                        "hit": cache_hit,
                        "parse_cache_version": 1,
                    },
                },
                metadata={
                    'read_diagnostics': trace.events,
                    'parser': parsed.get('parser'),
                    'page_count': parsed.get('page_count', 0),
                    'text_page_count': parsed.get('text_page_count', 0),
                    'empty_page_count': parsed.get('empty_page_count', 0),
                    'extraction_status': parsed.get('extraction_status'),
                    'content_length': parsed.get('content_length', 0),
                    'parse_quality': parse_quality,
                    'risk_summary': parse_metadata.get('risk_summary', {}),
                    'parser_status': parse_metadata.get('parser_status', {}),
                    'source_integrity': {
                        'parser_text_complete': bool(
                            parsed.get('page_count') is not None
                            and parsed.get('text_page_count') == parsed.get('page_count')
                        ),
                        'parser_content_length': parsed.get('content_length', 0),
                        'agent_context_truncation': False,
                    },
                    'parse_metadata': parse_metadata,
                    'cache_hit': cache_hit,
                }
            )

        except Exception as e:
            return MCPToolResult(success=False, error="Failed to read arXiv PDF",
                                 metadata={'read_diagnostics': trace.events,
                                           'error_type': type(e).__name__})

    def medrxiv_search(self, query: str, max_results: int = 10, days: int = 30) -> List[Paper]:
        """
        Search for papers on medRxiv by category within the last N days.

        Args:
            query: Category name to search for (e.g., "cardiovascular medicine").
            max_results: Maximum number of papers to return.
            days: Number of days to look back for papers.

        Returns:
            List of Paper objects matching the category within the specified date range.
        """
        # Calculate date range: last N days
        try:
            end_date = datetime.now().strftime('%Y-%m-%d')
            start_date = (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d')

            # Format category: lowercase and replace spaces with underscores
            category = query.lower().replace(' ', '_')

            papers = []
            cursor = 0
            while len(papers) < max_results:
                url = f"{self.BASE_URL}/{start_date}/{end_date}/{cursor}"
                if category:
                    url += f"?category={category}"

                tries = 0
                while tries < self.max_retries:
                    try:
                        response = self.session.get(url, timeout=self.timeout, verify=True, proxies=proxy)
                        response.raise_for_status()
                        data = response.json()
                        collection = data.get('collection', [])
                        for item in collection:
                            date = datetime.strptime(item['date'], '%Y-%m-%d')
                            papers.append(Paper(
                                paper_id=item['doi'],
                                title=item['title'],
                                authors=item['authors'].split('; '),
                                abstract=item['abstract'],
                                url=f"https://www.medrxiv.org/content/{item['doi']}v{item.get('version', '1')}",
                                pdf_url=f"https://www.medrxiv.org/content/{item['doi']}v{item.get('version', '1')}.full.pdf",
                                published_date=date,
                                updated_date=date,
                                source="medrxiv",
                                categories=[item['category']],
                                keywords=[],
                                doi=item['doi']
                            ).to_dict())
                        if len(collection) < 100:
                            break  # No more results
                        cursor += 100
                        break  # Exit retry loop on success
                    except requests.exceptions.RequestException as e:
                        tries += 1
                        if tries == self.max_retries:
                            logger.error(f"Failed to connect to medRxiv API after {self.max_retries} attempts: {e}")
                            break
                        logger.error(f"Attempt {tries} failed, retrying...")
                else:
                    continue
                break
            return MCPToolResult(success=True, data={"paper": papers})
        except Exception as e:
            return MCPToolResult(success=False, error=f"閼惧嘲褰噈edrxiv鐠佺儤鏋冮崘鍛啇婢惰精瑙?{e}")

    def medrxiv_download_pdf(self, paper_id: str, save_path: str) -> str:
        """
        Download a PDF for a given paper ID from medRxiv.

        Args:
            paper_id: The DOI of the paper.
            save_path: Directory to save the PDF.

        Returns:
            Path to the downloaded PDF file.
        """
        if not paper_id:
            raise ValueError("Invalid paper_id: paper_id is empty")

        pdf_url = f"https://www.medrxiv.org/content/{paper_id}v1.full.pdf"
        tries = 0
        while tries < self.max_retries:
            try:
                # Add User-Agent to avoid potential 403 errors
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
                }
                response = self.session.get(pdf_url, timeout=30, headers=headers, verify=True, proxies=proxy)
                response.raise_for_status()
                os.makedirs(save_path, exist_ok=True)
                output_file = f"{save_path}/{paper_id.replace('/', '_')}.txt"
                with open(output_file, 'wb') as f:
                    f.write(response.content)
                logger.info(f"Downloaded medRxiv paper {paper_id} to text path.")
                return output_file
            except requests.exceptions.RequestException as e:
                tries += 1
                if tries == self.max_retries:
                    raise Exception(f"Failed to download PDF after {self.max_retries} attempts: {e}")
                logger.error(f"Attempt {tries} failed, retrying...")

    def medrxiv_read_paper(self, paper_id: str, save_path: str = "./medrxiv") -> MCPToolResult:
        """
        Read a paper and convert it to text format.

        Args:
            paper_id: medRxiv DOI
            save_path: Directory where the PDF is/will be saved

        Returns:
            MCPToolResult: The extracted text content of the paper
        """
        try:
            txt_path = f"{save_path}/{paper_id.replace('/', '_')}.txt"
            pdf_path = f"{save_path}/{paper_id.replace('/', '_')}.pdf"

            # 婵″倹鐏夊鑼病鐎涙ê婀弬鍥ㄦ拱閺傚洣娆㈤敍宀€娲块幒銉嚢閸?
            if os.path.exists(txt_path):
                with open(txt_path, 'rb') as f:
                    content = f.read()
                return MCPToolResult(success=True, data={"paper": content.decode('utf-8', errors='ignore')})

            # 婵″倹鐏夌€涙ê婀弮褏娈慞DF閺傚洣娆㈤敍宀勫櫢閸涜棄鎮曟稉?txt
            if os.path.exists(pdf_path):
                os.rename(pdf_path, txt_path)
                logger.info(f"Converted cached medRxiv PDF for {paper_id} to text path.")
                with open(txt_path, 'rb') as f:
                    content = f.read()
                return MCPToolResult(success=True, data={"paper": content.decode('utf-8', errors='ignore')})

            # 娑撳娴囬弬鍥︽閿涘潰edrxiv_download_pdf閻滄澘婀导姘辨纯閹恒儰绻氱€涙ü璐?txt閿?
            txt_path = self.medrxiv_download_pdf(paper_id, save_path)
            with open(txt_path, 'rb') as f:
                content = f.read()
            return MCPToolResult(success=True, data={"paper": content.decode('utf-8', errors='ignore')})

        except Exception as e:
            return MCPToolResult(success=False, error=f"閼惧嘲褰噈edrxiv鐠佺儤鏋冮崘鍛啇婢惰精瑙?{e}")


def normalize_company(param_name: str):
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            response = await func(*args, **kwargs)
            if response.get('statusCode') == 2:
                sig = inspect.signature(func)
                params = list(sig.parameters.keys())
                if param_name in params:
                    param_index = params.index(param_name)
                    if kwargs.get(param_name):
                        company_name = kwargs.get(param_name)
                    else:
                        args = list(args)
                        company_name = args[param_index]
                    n_company_name = await normalize_company_name(company_name)
                    if n_company_name and company_name != n_company_name:
                        if kwargs.get(param_name):
                            kwargs[param_name] = n_company_name
                        else:
                            args[param_index] = n_company_name
                            args = tuple(args)
                        return await func(*args, **kwargs)
            return response

        return wrapper

    return decorator


def generate_pubmed_search_url(term=None, title=None, author=None, journal=None,
                               start_date=None, end_date=None, num_results=10):
    """Build a PubMed ESearch URL."""
    base_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
    query_parts = []

    if term:
        query_parts.append(quote(term))
    if title:
        query_parts.append(f"{quote(title)}[Title]")
    if author:
        query_parts.append(f"{quote(author)}[Author]")
    if journal:
        query_parts.append(f"{quote(journal)}[Journal]")
    if start_date and end_date:
        query_parts.append(f"{start_date}:{end_date}[Date - Publication]")

    query = " AND ".join(query_parts)
    params = {
        "db": "pubmed",
        "term": query,
        "retmax": num_results,
        "retmode": "xml"
    }

    return f"{base_url}?{'&'.join([f'{k}={v}' for k, v in params.items()])}"


def search_pubmed(search_url):
    """娴?PubMed 閹兼粎鍌ㄧ紒鎾寸亯娑擃叀袙閺嬫劖鏋冪粩?ID"""

    response = requests.get(search_url, verify=True, proxies=proxy)

    if response.status_code == 200:
        root = ET.fromstring(response.content)
        id_list = root.find("IdList")
        if id_list is not None:
            return [id.text for id in id_list.findall("Id")]
        else:
            logger.info("No results found.")
            return []
    else:
        logger.error(f"Error: Unable to fetch data (status code: {response.status_code})")
        return []


def get_pubmed_metadata(pmid):
    """Fetch PubMed metadata for a PMID."""
    url = f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id={pmid}&retmode=xml"
    response = requests.get(url, verify=True, proxies=proxy)

    if response.status_code == 200:
        root = ET.fromstring(response.content)
        article = root.find(".//Article")
        if article is not None:
            title = article.find(".//ArticleTitle")
            title = title.text if title is not None else "No title available"

            abstract = article.find(".//Abstract/AbstractText")
            abstract = abstract.text if abstract is not None else "No abstract available"

            authors = []
            for author in article.findall(".//Author"):
                last_name = author.find(".//LastName")
                if last_name is not None and last_name.text:
                    authors.append(last_name.text)
            authors = ", ".join(authors) if authors else "No authors available"

            journal = article.find(".//Journal/Title")
            journal = journal.text if journal is not None else "No journal available"

            pub_date = article.find(".//PubDate/Year")
            pub_date = pub_date.text if pub_date is not None else "No publication date available"

            return {
                "PMID": pmid,
                "Title": title,
                "Authors": authors,
                "Journal": journal,
                "Publication Date": pub_date,
                "Abstract": abstract
            }
        else:
            logger.info(f"No article data found for PMID: {pmid}")
            return None
    else:
        logger.error(f"Error: Unable to fetch metadata (status code: {response.status_code})")
        return None


# ================ MCP TOOL SCHEMAS ================

MCP_TOOL_SCHEMAS = {
    "think": {
        "name": "think",
        "description": "Use the tool to think about something. It will not obtain new information or make any changes to the repository, but just log the thought. Use it when complex reasoning or brainstorming is needed.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "thought": {
                    "type": "string",
                    "description": "Your thoughts."
                }
            },
            "required": ["thought"]
        }
    },

    "reflect": {
        "name": "reflect",
        "description": "When multiple attempts yield no progress, use this tool to reflect on previous reasoning and planning, considering possible overlooked clues and exploring more possibilities. It will not obtain new information or make any changes to the repository.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "reflect": {
                    "type": "string",
                    "description": "The specific content of your reflection"
                }
            },
            "required": ["reflect"]
        }
    },

    "batch_web_search": {
        "name": "batch_web_search",
        "description": "Search multiple queries using configurable search API with concurrent processing (no more than 8 search queries)",
        "inputSchema": {
            "type": "object",
            "properties": {
                "queries": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of search queries"
                },
                "max_results_per_query": {
                    "type": "integer",
                    "default": 4,
                    "description": "Maximum search results per query (limited to 10)"
                },
                "max_workers": {
                    "type": "integer",
                    "default": 5,
                    "description": "Maximum number of concurrent search requests"
                }
            },
            "required": ["queries"]
        }
    },

    "url_crawler": {
        "name": "url_crawler",
        "description": "Extract content from web pages using configurable URL crawler API. Input is a list of documents with metadata including URL and local file path for saving extracted content.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "documents": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "url": {
                                "type": "string",
                                "description": "Web page URL to extract content from"
                            },
                            "file_path": {
                                "type": "string",
                                "description": "Local path to save extracted full text content"
                            },
                            "title": {
                                "type": "string",
                                "description": "Title of the web page"
                            },
                            "time": {
                                "type": "string",
                                "description": "Publication time of the web page"
                            }
                        },
                        "required": ["url", "file_path"]
                    },
                    "description": "List of documents with metadata including URL and save path"
                },
                "max_tokens_per_url": {
                    "type": "integer",
                    "default": 4000,
                    "description": "Maximum tokens per URL result"
                },
                "include_metadata": {
                    "type": "boolean",
                    "default": True,
                    "description": "Whether to include extraction metadata"
                },
                "max_workers": {
                    "type": "integer",
                    "default": 10,
                    "description": "Maximum number of concurrent extraction requests"
                }
            },
            "required": ["documents"]
        }
    },

    "concat_section_files": {
        "name": "concat_section_files",
        "description": "Concatenate the content of the saved section files into a single file",
        "inputSchema": {
            "type": "object",
            "properties": {
                "final_file_path": {
                    "type": "string",
                    "description": "The final file path to save the concatenated content, save the file in the workspace **under the relative path `./report/`**, and specify the final_file_path as `./report/final_report.md`"
                },
                "section_files": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "file_path": {
                                "type": "string",
                                "description": "Relative path to the saved section file"
                            }
                        },
                        "required": ["file_path"]
                    },
                    "description": "List of section files to concatenate"
                }
            },
            "required": ["section_files", "final_file_path"]
        }
    },

    # TODO 闂団偓鐟曚椒鎱ㄩ弨绠俢hame閻ㄥ嫭鐗稿蹇ョ礉鏉╂ɑ妲哥€涙ê婀柨娆掝嚖
    "search_result_classifier": {
        "name": "search_result_classifier",
        "description": "Intelligently classify and organize search result files according to a structured outline for comprehensive long-form content generation. Analyzes files across fouer key dimensions (document time, source authority, core content, and task relevance) and assigns relevant files to appropriate outline sections. Files may be assigned to multiple sections when their content spans different topics.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "outline": {
                    "type": "string",
                    "description": "The outline here must be consistent with the content and structure of the outline generated above"
                },
                "key_files": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "file_path": {
                                "type": "string",
                                "description": "Relative path to the file containing research content"
                            }
                        },
                        "required": ["file_path"]
                    },
                    "description": "List of research files to be classified according to the outline"
                },
                "model": {
                    "type": "string",
                    "default": "pangu_auto",
                    "description": "AI model to use for classification and organization"
                },
                "temperature": {
                    "type": "number",
                    "default": 0.3,
                    "description": "Creativity level for the AI classification (0-1)"
                },
                "max_tokens": {
                    "type": "integer",
                    "default": 2000,
                    "description": "Maximum tokens for the AI response"
                }
            },
            "required": ["key_files", "outline"]
        }
    },

    "document_qa": {
        "name": "document_qa",
        "description": "Answer questions based on content stored in local files. Each file has a corresponding question. Reads files and uses an AI model to answer each question using the respective file content as context.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tasks": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "file_path": {
                                "type": "string",
                                "description": "Relative path to the file (relative to workspace root)"
                            },
                            "question": {
                                "type": "string",
                                "description": "Question to ask about this file"
                            }
                        },
                        "required": ["file_path", "question"]
                    },
                    "description": "List of tasks, each containing a file path and a question"
                },
                "model": {
                    "type": "string",
                    "default": "deepseek-v4-flash",
                    "description": "AI model to use for generating answers"
                },
                "temperature": {
                    "type": "number",
                    "default": 0.3,
                    "description": "Creativity level for the AI response (0-1)"
                },
                "max_tokens": {
                    "type": "integer",
                    "default": 2000,
                    "description": "Maximum tokens for the AI response"
                },
                "max_workers": {
                    "type": "integer",
                    "default": 5,
                    "description": "Maximum number of concurrent model API requests"
                }
            },
            "required": ["tasks"]
        }
    },

    "document_extract": {
        "name": "document_extract",
        "description": "Multi-dimensional analysis of locally stored files using AI models. Evaluates each file across four key dimensions: web page time extraction, source authority assessment, task relevance evaluation, and core content summarization (~300 words). Provides structured document analysis for research and content evaluation purposes.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tasks": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "file_path": {
                                "type": "string",
                                "description": "Relative path to the file (relative to workspace root)"
                            },
                            "task": {
                                "type": "string",
                                "description": "The content of the currently executed subtask"
                            }
                        },
                        "required": ["file_path", "task"]
                    },
                    "description": "List of tasks, each containing a file path and the current task"
                },
                "model": {
                    "type": "string",
                    "default": "pangu_auto",
                    "description": "AI model to use for generating answers"
                },
                "temperature": {
                    "type": "number",
                    "default": 0.3,
                    "description": "Creativity level for the AI response (0-1)"
                },
                "max_tokens": {
                    "type": "integer",
                    "default": 2000,
                    "description": "Maximum tokens for the AI response"
                },
                "max_workers": {
                    "type": "integer",
                    "default": 5,
                    "description": "Maximum number of concurrent model API requests"
                }
            },
            "required": ["tasks"]
        }
    },

    "section_writer": {
        "name": "section_writer",
        "description": "Write the current chapter content based on given web information and chapter structure; also consider user questions, completed chapters, and overall outline to ensure content relevance while avoiding duplication or contradictions.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "written_chapters_summary": {
                    "type": "string",
                    "description": "The summary of the written chapters, including the content of the chapters and the reflections on the chapters. Note that this field should be concatenated with the summaries of all previously written chapters with '\\n', and do not modify the original summary. For example, if the current chapter is the third chapter, the value of this field is 'chapter 1 summary \\n chapter 2 summary'. If not, the value is set to 'No previous chapters written yet.'"
                },
                "task_content": {
                    "type": "string",
                    "description": "Detailed description of some requirements for writing the current chapter and avoidance prompts. If there are reflections from the `think` tool on previously written chapters, they can be added to this field."
                },
                "user_query": {
                    "type": "string",
                    "description": "The user query, ensure the drafted content is highly relevant to the user's inquiry."
                },
                "current_chapter_outline": {
                    "type": "string",
                    "description": "This field represents the current chapter structure to be drafted. When composing the chapter content, do not modify content and bold formatting symbols of the existing structure's titles!!!"
                },
                "overall_outline": {
                    "type": "string",
                    "description": "This field represents the overall outline of the article. When drafting the chapter content, you should consider the overall outline to ensure the chapter content is consistent with the overall outline."
                },
                "target_file_path": {
                    "type": "string",
                    "description": "The path to save the chapter content"
                },
                "key_files": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "file_path": {
                                "type": "string",
                                "description": "Relative path to the file containing research content"
                            }
                        },
                        "required": ["file_path"]
                    },
                    "description": "These files are the source materials required for drafting the current chapter."
                },
                "model": {
                    "type": "string",
                    "default": "pangu_auto",
                    "description": "AI model to use for classification and organization"
                },
                "temperature": {
                    "type": "number",
                    "default": 0.3,
                    "description": "Creativity level for the AI classification (0-1)"
                },
                "max_tokens": {
                    "type": "integer",
                    "default": 5000,
                    "description": "Maximum tokens for the AI response"
                },
            },
            "required": ["user_query", "current_chapter_outline", "overall_outline", "target_file_path", "key_files"]
        }
    },

    "download_files": {
        "name": "download_files",
        "description": "Download files from URLs to the workspace",
        "inputSchema": {
            "type": "object",
            "properties": {
                "urls": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of URLs to download"
                },
                "target_directory": {
                    "type": "string",
                    "description": "Directory to save files"
                },
                "overwrite": {
                    "type": "boolean",
                    "default": False,
                    "description": "Whether to overwrite existing files"
                },
                "max_file_size_mb": {
                    "type": "integer",
                    "default": 100,
                    "description": "Maximum file size in MB"
                }
            },
            "required": ["urls"]
        }
    },

    "process_user_uploaded_files": {
        "name": "process_user_uploaded_files",
        "description": "Process and download user-uploaded files from the Flask backend. This tool fetches files uploaded by users (e.g., PDFs, documents) and saves them to the workspace with high priority markers. Use this tool FIRST when user files are available to ensure they are analyzed before web search results.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "file_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of file IDs from user uploads"
                },
                "backend_url": {
                    "type": "string",
                    "default": "http://localhost:5000",
                    "description": "Flask backend URL"
                }
            },
            "required": ["file_ids"]
        }
    },

    "process_library_files": {
        "name": "process_library_files",
        "description": "Process and download user-selected files from the document library. This tool fetches files that users have selected from their document library and saves them to the workspace. These files are treated equally with web search results - the LLM will judge their relevance and decide whether to cite them based on task_relevance, source_authority, and information_richness dimensions. Use this tool when users have selected specific files from their document library.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "file_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of file IDs from document library"
                },
                "backend_url": {
                    "type": "string",
                    "default": "http://localhost:5000",
                    "description": "Flask backend URL"
                }
            },
            "required": ["file_ids"]
        }
    },

    "list_workspace": {
        "name": "list_workspace",
        "description": "List files and directories in the workspace",
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Specify the directory path to list, using a relative path"
                },
                "recursive": {
                    "type": "boolean",
                    "default": False,
                    "description": "Whether to list recursively"
                },
                "include_hidden": {
                    "type": "boolean",
                    "default": False,
                    "description": "Whether to include hidden files"
                },
                "max_depth": {
                    "type": "integer",
                    "default": 3,
                    "description": "Maximum recursion depth"
                }
            },
            "required": []
        }
    },

    "str_replace_based_edit_tool": {
        "name": "str_replace_based_edit_tool",
        "description": "Create, view, and edit files with various operations",
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["create", "view", "str_replace", "insert", "append", "delete"],
                    "description": "Action to perform"
                },
                "file_path": {
                    "type": "string",
                    "description": "Path to the file"
                },
                "content": {
                    "type": "string",
                    "description": "Content for create/insert/append actions"
                },
                "old_str": {
                    "type": "string",
                    "description": "String to replace (for str_replace)"
                },
                "new_str": {
                    "type": "string",
                    "description": "Replacement string (for str_replace)"
                },
                "line_number": {
                    "type": "integer",
                    "description": "Line number for insert action"
                }
            },
            "required": ["action", "file_path"]
        }
    },

    "file_read": {
        "name": "file_read",
        "description": "Read file content",
        "inputSchema": {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Relative path to the file (relative to workspace root)"
                },
                "encoding": {
                    "type": "string",
                    "default": "utf-8",
                    "description": "File encoding"
                }
            },
            "required": ["file_path"]
        }
    },

    "load_json": {
        "name": "load_json",
        "description": "Read json format file",
        "inputSchema": {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Relative path to the file (relative to workspace root)"
                },
                "encoding": {
                    "type": "string",
                    "default": "utf-8",
                    "description": "File encoding"
                }
            },
            "required": ["file_path"]
        }
    },

    "file_write": {
        "name": "file_write",
        "description": "Write content to file",
        "inputSchema": {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Relative path to the file (relative to workspace root)"
                },
                "content": {
                    "type": "string",
                    "description": "Content to write"
                },
                "encoding": {
                    "type": "string",
                    "default": "utf-8",
                    "description": "File encoding"
                },
                "create_dirs": {
                    "type": "boolean",
                    "default": True,
                    "description": "Create parent directories"
                }
            },
            "required": ["file_path", "content"]
        }
    },

    "file_grep_search": {
        "name": "file_grep_search",
        "description": "Search for pattern in files",
        "inputSchema": {
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "description": "Regex pattern to search for"
                },
                "file_pattern": {
                    "type": "string",
                    "default": "*",
                    "description": "File pattern to search in"
                },
                "recursive": {
                    "type": "boolean",
                    "default": True,
                    "description": "Search recursively"
                },
                "ignore_case": {
                    "type": "boolean",
                    "default": False,
                    "description": "Ignore case in search"
                },
                "max_matches": {
                    "type": "integer",
                    "default": 100,
                    "description": "Maximum number of matches"
                }
            },
            "required": ["pattern"]
        }
    },

    "file_find_by_name": {
        "name": "file_find_by_name",
        "description": "Find files by name pattern",
        "inputSchema": {
            "type": "object",
            "properties": {
                "name_pattern": {
                    "type": "string",
                    "description": "Name pattern to search for"
                },
                "recursive": {
                    "type": "boolean",
                    "default": True,
                    "description": "Search recursively"
                },
                "case_sensitive": {
                    "type": "boolean",
                    "default": False,
                    "description": "Case sensitive search"
                },
                "max_results": {
                    "type": "integer",
                    "default": 100,
                    "description": "Maximum number of results"
                }
            },
            "required": ["name_pattern"]
        }
    },

    "bash": {
        "name": "bash",
        "description": "Execute bash command in the workspace",
        "inputSchema": {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "Bash command to execute"
                },
                "timeout": {
                    "type": "integer",
                    "default": 30,
                    "description": "Command timeout in seconds"
                },
                "capture_output": {
                    "type": "boolean",
                    "default": True,
                    "description": "Whether to capture stdout/stderr"
                },
                "working_directory": {
                    "type": "string",
                    "description": "Working directory for command"
                }
            },
            "required": ["command"]
        }
    },

    "info_seeker_task_done": {
        "name": "info_seeker_task_done",
        "description": "Information Seeker Agent task completion reporting with information collection summary and related files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                # "save_analysis_file_path": {
                #     "type": "string",
                #     "description": "The path to save the analysis file, save the analysis file in the workspace **under the relative path `./doc_analysis/`**, and specify the file path as `/doc_analysis/file_analysis.jsonl`"
                # },
                "task_summary": {
                    "type": "string",
                    "description": "Simple summary of what information has been collected for the current task and what new discoveries have been made.",
                    "format": "markdown"
                },
                "key_files": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "file_path": {
                                "type": "string",
                                "description": "Relative path to the file with collected content"
                            },
                        },
                        "required": ["file_path"]
                    },
                    "description": "Collect files highly relevant to this task. "
                },
                "completion_status": {
                    "type": "string",
                    "enum": ["completed", "partial", "failed"],
                    "description": "Final status of the information gathering task"
                },
                "completion_analysis": {
                    "type": "string",
                    "description": "Brief analysis of task completion quality, information thoroughness, and any limitations or gaps."
                }
            },
            "required": ["task_summary", "key_files", "completion_status", "completion_analysis"]
        }
    },

    "section_writer_task_done": {
        "name": "section_writer_task_done",
        "description": "Section Writer Agent task completion reporting for chapter/section writing. Called when a chapter, section, or paragraph is completed to provide a detailed overview of the written content and completion status.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "chapter_summary": {
                    "type": "string",
                    "description": "Detailed summary of the content written in the current chapter/section, including main topics covered, key points addressed, supporting evidence, and implications.",
                    "format": "markdown"
                },
                "key_topics_covered": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of main topics or themes addressed in the written chapter/section"
                },
                "completion_status": {
                    "type": "string",
                    "enum": ["completed", "partial", "failed"],
                    "description": "Final status of the chapter/section writing task"
                },
                "completion_analysis": {
                    "type": "string",
                    "description": "Detailed analysis of the writing task completion including: assessment of content quality, evaluation of outline adherence, identification of any challenges encountered, and overall evaluation of the writing process success."
                }
            },
            "required": ["chapter_summary", "key_topics_covered", "completion_status", "completion_analysis"]
        }
    },

    "writer_task_done": {
        "name": "writer_task_done",
        "description": "Writer Agent task completion reporting for complete long-form content. Called after all chapters/sections are written to provide a summary of the complete long article, final completion status and analysis, and the storage path of the final consolidated article.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "final_article_path": {
                    "type": "string",
                    "description": "The file path where the final article is saved."
                },
                "article_summary": {
                    "type": "string",
                    "description": "Comprehensive summary of the complete long-form article, including main themes, key points covered, and overall narrative structure.",
                    "format": "markdown"
                },
                "completion_status": {
                    "type": "string",
                    "enum": ["completed", "partial", "failed"],
                    "description": "Final status of the complete long-form writing task"
                },
                "completion_analysis": {
                    "type": "string",
                    "description": "Analysis of the overall writing project completion including: assessment of article coherence and quality, evaluation of content organization and flow, identification of any challenges in the writing process, and overall evaluation of the long-form content creation success."
                }
            },
            "required": ["final_article_path", "article_summary", "completion_status", "completion_analysis"]
        }
    },

    "semantic_search": {
        "name": "semantic_search",
        "description": "Search semantically through system-maintained knowledge index using OpenAI embeddings",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query - can be natural language question or keywords"
                },
                "max_tokens": {
                    "type": "integer",
                    "default": 2000,
                    "description": "Maximum tokens to return in results (controls result size)"
                },
                "max_results": {
                    "type": "integer",
                    "default": 5,
                    "description": "Maximum number of results to return"
                },
                "similarity_threshold": {
                    "type": "number",
                    "default": 0.7,
                    "description": "Minimum similarity score (0-1) for results"
                },
                "filters": {
                    "type": "object",
                    "properties": {
                        "task_name": {
                            "type": "string",
                            "description": "Filter by specific task name"
                        },
                        "file_path": {
                            "type": "string",
                            "description": "Filter by files containing this path"
                        },
                        "is_final_output": {
                            "type": "boolean",
                            "description": "Filter by final output files only"
                        }
                    },
                    "description": "Optional filters to narrow search results"
                }
            },
            "required": ["query"]
        }
    },

    "knowledge_status": {
        "name": "knowledge_status",
        "description": "Get status and statistics about the system-managed knowledge index",
        "inputSchema": {
            "type": "object",
            "properties": {},
            "required": []
        }
    },

    "search_pubmed_key_words": {
        "name": "search_pubmed_key_words",
        "description": "Search for biological articles by keywords",
        "inputSchema": {
            "type": "object",
            "properties": {
                "keywords": {
                    "type": "string",
                    "description": "Search query string, only supports english"
                },
                "max_results": {
                    "type": "integer",
                    "description": "Number of results to return (default: 10)"
                }

            },
            "required": ["keywords"]
        }
    },

    "search_pubmed_advanced": {
        "name": "search_pubmed_advanced",
        "description": "Perform an advanced search for biological articles on PubMed.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "term": {
                    "type": "string",
                    "description": "General search term, only supports english"
                },
                "title": {
                    "type": "string",
                    "description": "Search in title, only supports english"
                },
                "author": {
                    "type": "string",
                    "description": "Author name, only supports english"
                },
                "journal": {
                    "type": "string",
                    "description": "Journal name, only supports english"
                },
                "start_date": {
                    "type": "string",
                    "description": "Start date for search range (format: YYYY/MM/DD)"
                },
                "end_date": {
                    "type": "string",
                    "description": "End date for search range (format: YYYY/MM/DD)"
                },
                "num_results": {
                    "type": "integer",
                    "description": "Number of results to return (default: 10)"
                }
            },
            "required": []
        }
    },
    "get_pubmed_article": {
        "name": "get_pubmed_article",
        "description": "Obtain articles of biology on PubMed via PMID. Before calling this function, first use search_key_words or search_advanced to obtain the article's PMID.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "pmid": {
                    "type": "string",
                    "description": "PMID"
                }
            },
            "required": ["pmid"]
        }
    },
    "arxiv_search": {
        "name": "arxiv_search",
        "description": "Searcher for arXiv papers, return the metadata of papers. You can get paper_id with this function and then use it for reading paper.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query string, only supports english"
                },
                "max_results": {
                    "type": "integer",
                    "description": "Max number of searched papers"
                },
            },
            "required": ["query"]
        }
    },
    "arxiv_read_paper": {
        "name": "arxiv_read_paper",
        "description": "Obtain Arxiv article content via paper_id. Before calling this function, first use arxiv_search to obtain the article's paper_id.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "paper_id": {
                    "type": "string",
                    "description": "arXiv paper ID"
                },
                "save_path": {
                    "type": "string",
                    "description": "Directory where the PDF is/will be saved"
                },
                "pdf_parse_mode": {
                    "type": "string",
                    "enum": ["local", "llama_full", "hybrid"],
                    "description": "PDF parsing strategy selected for this request."
                }

            },
            "required": ["paper_id"]
        }
    },
    "medrxiv_search": {
        "name": "medrxiv_search",
        "description": "Searcher for biologically relevant papers, return the metadata of papers. You can get paper_id with this function and then use it for medrxiv_read_paper.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Category name to search for (e.g., \"cardiovascular medicine\"), only supports english"
                },
                "max_results": {
                    "type": "integer",
                    "description": "Max number of searched papers"
                },
                "days": {
                    "type": "integer",
                    "description": "Number of days to look back for papers."
                }
            },
            "required": ["query"]
        }
    },
    "medrxiv_read_paper": {
        "name": "medrxiv_read_paper",
        "description": "Obtain medrxiv article content via paper_id. Before calling this function, first use medrxiv_search to obtain the article's paper_id.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "paper_id": {
                    "type": "string",
                    "description": "medrxiv paper ID"
                },
                "save_path": {
                    "type": "string",
                    "description": "Directory where the PDF is/will be saved"
                }

            },
            "required": ["paper_id"]
        }
    },
    "file_stats": {
        "name": "file_stats",
        "description": "Get comprehensive file statistics without reading full content - perfect for deciding reading strategy",
        "inputSchema": {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Path to the file (relative to workspace)"
                }
            },
            "required": ["file_path"]
        }
    },

    "file_read_lines": {
        "name": "file_read_lines",
        "description": "Read specific line ranges from a file without loading entire file - perfect for large files",
        "inputSchema": {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Path to the file"
                },
                "start_line": {
                    "type": "integer",
                    "default": 1,
                    "description": "Starting line number (1-based)"
                },
                "end_line": {
                    "type": "integer",
                    "description": "Ending line number (1-based, None for end of file)"
                },
                "max_lines": {
                    "type": "integer",
                    "default": 1000,
                    "description": "Maximum number of lines to read (safety limit)"
                }
            },
            "required": ["file_path"]
        }
    }

    # NOTE: Task assignment tool schemas removed - these are now built-in methods of PlannerAgent
    # to avoid circular dependency issues with sub-agents trying to create MCP client connections
}


# ================ MAIN INTERFACE ================

def create_mcp_tools(workspace_path: str = None) -> MCPTools:
    """Create and return MCP tools instance"""
    return MCPTools(workspace_path)


def get_tool_schemas() -> Dict[str, Any]:
    """Get all tool schemas for MCP registration"""
    return MCP_TOOL_SCHEMAS
























