# Copyright (c) 2025 Huawei Technologies Co., Ltd. All rights reserved.
"""
Model Context Protocol (MCP) Integration

This package contains MCP server implementations, tools, and integrations
for the DeepDiver multi-agent system.
"""

# Lightweight tools such as the PDF parser must not import the legacy Agent
# stack or construct an MCP server merely by importing a sibling module.
# Preserve the old package-level exports, loading them only when requested.
def __getattr__(name):
    if name == 'MCPTools':
        from .mcp_tools import MCPTools
        globals()[name] = MCPTools
        return MCPTools
    if name in {'create_standard_app', 'simple_app', 'standard_app',
                'MCP_AVAILABLE', 'MCP_STANDARD_AVAILABLE'}:
        try:
            from .mcp_server_standard import create_app
            from .mcp_server_simple import app
            exports = {'create_standard_app': create_app, 'simple_app': app,
                       'standard_app': app, 'MCP_AVAILABLE': True, 'MCP_STANDARD_AVAILABLE': True}
        except ImportError:
            exports = {'create_standard_app': None, 'simple_app': None,
                       'standard_app': None, 'MCP_AVAILABLE': False, 'MCP_STANDARD_AVAILABLE': False}
        globals().update(exports)
        return exports[name]
    raise AttributeError(name)

__all__ = [
    'MCPTools',
    'create_standard_app',
    'simple_app',
    'standard_app',  # Backward compatibility
    'MCP_AVAILABLE',
    'MCP_STANDARD_AVAILABLE'
]
