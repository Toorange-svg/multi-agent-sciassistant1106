"""Small JSONL telemetry helpers for Web/CLI task diagnostics.

The diagnostic file is request-local and intentionally contains stage metadata
only.  Callers must not include prompts, keys, headers, or document bodies.
"""
from __future__ import annotations

import json
import os
import threading
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from functools import wraps
from typing import Any, Callable, Iterator


def _path() -> Path | None:
    value = os.getenv("SCIASSISTANT_DIAGNOSTICS_PATH", "").strip()
    return Path(value) if value else None


def record(stage: str, status: str, *, reason: str = "", source: str = "", **details: Any) -> None:
    """Append a sanitised event; diagnostics must never affect a user task."""
    path = _path()
    if path is None:
        return
    event = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "stage": stage,
        "status": status,
        "reason": str(reason)[:500],
        "source": str(source)[:240],
        "details": {key: value for key, value in details.items() if value not in (None, "")},
    }
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(event, ensure_ascii=False, separators=(",", ":")) + "\n")
    except OSError:
        pass


@contextmanager
def stage(name: str, *, source: str = "", **details: Any) -> Iterator[None]:
    started = time.monotonic()
    record(name, "started", source=source, **details)
    try:
        yield
    except Exception as exc:
        record(name, "failed", reason=type(exc).__name__ + ": " + str(exc), source=source,
               elapsed_ms=round((time.monotonic() - started) * 1000), **details)
        raise
    else:
        record(name, "completed", source=source,
               elapsed_ms=round((time.monotonic() - started) * 1000), **details)


def timed(name: str, *, source: str = "") -> Callable:
    """Decorate a method without changing its normal return/error behaviour."""
    def decorate(func: Callable) -> Callable:
        @wraps(func)
        def wrapped(*args: Any, **kwargs: Any) -> Any:
            with stage(name, source=source or func.__module__):
                return func(*args, **kwargs)
        return wrapped
    return decorate
