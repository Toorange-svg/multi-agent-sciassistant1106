"""Optional LlamaParse review client for cropped PDF regions.

Public class names remain compatible with the existing PDF pipeline. The
provider is LlamaCloud/LlamaParse, not an OpenAI-compatible chat endpoint.
"""
from __future__ import annotations

import json
import os
import re
import time
from dataclasses import dataclass
from typing import Any, Dict, Optional

DEFAULT_ENDPOINT = "https://api.cloud.llamaindex.ai"
REVIEW_PROMPT = (
    "Inspect only this cropped region from a scientific PDF. Do not guess or "
    "complete unreadable symbols, cells, or diagram connections. Return only "
    "one JSON object with content_type, transcription, latex, table, "
    "description, uncertainties, model_confidence, and is_partial. "
    "model_confidence must be between 0 and 1."
)
FULL_PDF_PROMPT = (
    "Parse this complete scientific PDF into faithful Markdown. Preserve headings, "
    "reading order, displayed formulas, tables, figure captions, and page boundaries "
    "when they are available. Do not invent unreadable characters, table cells, chart "
    "values, or diagram connections. Mark uncertain or incomplete material explicitly "
    "instead of completing it. This is an auxiliary transcription for a reliability "
    "pipeline, not a request to infer missing content."
)


@dataclass
class LlamaVisionConfig:
    enabled: bool = False
    api_key: str = ""
    tier: str = "agentic"
    endpoint: str = DEFAULT_ENDPOINT
    timeout: int = 120
    poll_interval: float = 2.0
    max_retries: int = 2
    max_tokens: int = 2048  # Compatibility only; LlamaParse does not use it.
    model: str = "llamaparse-agentic"  # Compatibility label for reports.

    @classmethod
    def from_env(cls) -> "LlamaVisionConfig":
        from user_credentials import provider_value
        key = provider_value("LLAMA_CLOUD_API_KEY")
        legacy_key = provider_value("OPENROUTER_API_KEY")
        if not key and legacy_key.startswith("llx-"):
            key = legacy_key
        return cls(
            enabled=os.getenv("LLAMA_VISION_ENABLED", "false").lower() == "true",
            api_key=key,
            tier=os.getenv("LLAMA_PARSE_TIER", "agentic"),
            endpoint=os.getenv("LLAMA_PARSE_ENDPOINT", DEFAULT_ENDPOINT).rstrip("/"),
            timeout=int(os.getenv("LLAMA_VISION_TIMEOUT", "120")),
            poll_interval=float(os.getenv("LLAMA_PARSE_POLL_INTERVAL", "2")),
            max_retries=int(os.getenv("LLAMA_VISION_MAX_RETRIES", "2")),
        )


def validate_review(value: Any) -> Dict[str, Any]:
    if isinstance(value, str):
        value = json.loads(value)
    if not isinstance(value, dict):
        raise ValueError("review response must be a JSON object")
    content_type = str(value.get("content_type") or "text").lower()
    if content_type == "image":
        content_type = "figure"
    if content_type not in {"formula", "table", "figure", "text"}:
        raise ValueError(f"unsupported content_type: {content_type}")
    try:
        confidence = float(value.get("model_confidence", 0.0))
    except (TypeError, ValueError):
        confidence = 0.0
    uncertainties = value.get("uncertainties") or []
    if not isinstance(uncertainties, list):
        uncertainties = [str(uncertainties)]
    return {
        "content_type": content_type,
        "transcription": str(value.get("transcription") or ""),
        "latex": str(value.get("latex") or "") or None,
        "table": value.get("table") if isinstance(value.get("table"), dict) else None,
        "description": str(value.get("description") or ""),
        "uncertainties": [str(item) for item in uncertainties],
        "model_confidence": max(0.0, min(1.0, confidence)),
        "is_partial": bool(value.get("is_partial", False)),
    }


def _extract_markdown(body: Any) -> str:
    if isinstance(body, str):
        return body
    if isinstance(body, list):
        return "\n".join(filter(None, (_extract_markdown(item) for item in body)))
    if not isinstance(body, dict):
        return ""
    for key in ("markdown", "text", "content"):
        value = body.get(key)
        if isinstance(value, str) and value.strip():
            return value
        nested = _extract_markdown(value)
        if nested.strip():
            return nested
    for key in ("result", "output", "pages", "data"):
        value = _extract_markdown(body.get(key))
        if value.strip():
            return value
    return ""


def _extract_page_markdown(body: Any) -> list[str]:
    """Return provider page chunks only when the response exposes them plainly."""
    if not isinstance(body, dict):
        return []
    for container_key in ("markdown", "pages", "result", "output", "data"):
        container = body.get(container_key)
        if isinstance(container, dict):
            pages = container.get("pages")
        else:
            pages = container
        if not isinstance(pages, list) or not pages:
            continue
        values = []
        for position, page in enumerate(pages, 1):
            if isinstance(page, dict) and (page.get("success") is False
                    or ("page_number" in page and (type(page["page_number"]) is not int or page["page_number"] != position))):
                values = []
                break
            value = _extract_markdown(page)
            if not value.strip():
                values = []
                break
            values.append(value)
        if values:
            return values
    return []


def _parse_review(markdown: str, content_type: str) -> Dict[str, Any]:
    candidate = markdown.strip()
    # LlamaParse may serialize its own JSON-like answer inside an HTML table.
    # Treat this as unstructured evidence: regex extraction could otherwise turn
    # broken table markup into apparently valid LaTeX and incorrectly override PDF text.
    if re.search(r"<\s*(?:table|html|tbody|tr|td)\b", candidate, re.IGNORECASE):
        normalized_type = "figure" if content_type == "image" else content_type
        return validate_review({
            "content_type": normalized_type,
            "transcription": markdown,
            "uncertainties": ["LlamaParse returned HTML instead of the required structured review"],
            "model_confidence": 0.5,
            "is_partial": True,
        })
    fenced = re.search(r"```(?:json)?\s*(\{.*\})\s*```", candidate, re.DOTALL | re.IGNORECASE)
    if fenced:
        candidate = fenced.group(1)
    try:
        return validate_review(candidate)
    except (json.JSONDecodeError, ValueError):
        normalized_type = "figure" if content_type == "image" else content_type
        if normalized_type == "formula":
            latex_match = re.search(
                r"\$\$(.+?)\$\$|\\\[(.+?)\\\]|\\\((.+?)\\\)",
                markdown, re.DOTALL,
            )
            if latex_match:
                latex = next(group.strip() for group in latex_match.groups() if group is not None)
                return validate_review({
                    "content_type": "formula", "transcription": markdown,
                    "latex": latex, "uncertainties": [],
                    "model_confidence": 0.85, "is_partial": False,
                })
        if normalized_type == "table":
            rows = []
            for line in markdown.splitlines():
                if "|" not in line:
                    continue
                cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
                if len(cells) >= 2:
                    rows.append(cells)
            if len(rows) >= 3 and all(re.fullmatch(r":?-{3,}:?", cell) for cell in rows[1]):
                width = len(rows[0])
                data_rows = [row for row in rows[2:] if len(row) == width]
                if data_rows:
                    return validate_review({
                        "content_type": "table", "transcription": markdown,
                        "table": {"headers": rows[0], "rows": data_rows},
                        "uncertainties": [], "model_confidence": 0.85,
                        "is_partial": False,
                    })
        return validate_review({
            "content_type": normalized_type,
            "transcription": markdown,
            "uncertainties": ["LlamaParse returned unstructured output"],
            "model_confidence": 0.5,
            "is_partial": True,
        })


class LlamaVisionClient:
    def __init__(self, config: Optional[LlamaVisionConfig] = None, http_client: Any = None):
        self.config = config or LlamaVisionConfig.from_env()
        self.http_client = http_client

    def _request(self, method: str, url: str, **kwargs):
        if self.http_client is None:
            import requests
            return requests.request(method, url, **kwargs)
        return getattr(self.http_client, method.lower())(url, **kwargs)

    @staticmethod
    def _json(response) -> Dict[str, Any]:
        try:
            body = response.json()
        except Exception as exc:
            raise RuntimeError("LlamaParse returned a non-JSON response") from exc
        status = getattr(response, "status_code", 200)
        if status >= 400:
            detail = body.get("detail") or body.get("error") or body.get("message") if isinstance(body, dict) else ""
            raise RuntimeError(f"HTTP {status}" + (f": {detail}" if detail else ""))
        return body

    def _delete_uploaded_file(self, file_id: Optional[str], headers: Dict[str, str]) -> None:
        if not file_id:
            return
        try:
            self._request(
                "delete", f"{self.config.endpoint}/api/v1/beta/files/{file_id}",
                headers=headers, timeout=min(30, self.config.timeout),
            )
        except Exception:
            pass

    def review(self, image: bytes, content_type: str, context: str = "") -> Dict[str, Any]:
        if not self.config.enabled:
            return {"status": "disabled", "reason": "LLAMA_VISION_ENABLED is false"}
        if not self.config.api_key:
            return {"status": "skipped", "reason": "LLAMA_CLOUD_API_KEY is not configured"}
        if not self.config.api_key.startswith("llx-"):
            return {"status": "failed", "reason": "LLAMA_CLOUD_API_KEY is not a LlamaCloud key"}

        started = time.monotonic()
        headers = {"Authorization": f"Bearer {self.config.api_key}"}
        last_error = "unknown error"
        for attempt in range(self.config.max_retries + 1):
            file_id = None
            try:
                upload = self._request(
                    "post", f"{self.config.endpoint}/api/v1/beta/files", headers=headers,
                    files={"file": ("pdf-region.png", image, "image/png")},
                    data={"purpose": "parse"}, timeout=self.config.timeout,
                )
                file_id = self._json(upload).get("id")
                if not file_id:
                    raise RuntimeError("LlamaParse upload response did not include a file id")
                prompt = f"{REVIEW_PROMPT}\nExpected content_type: {content_type}.\nLocal context: {context[:1000]}"
                create = self._request(
                    "post", f"{self.config.endpoint}/api/v2/parse",
                    headers={**headers, "Content-Type": "application/json"},
                    json={"file_id": file_id, "tier": self.config.tier, "version": "latest",
                          "agentic_options": {"custom_prompt": prompt}}, timeout=self.config.timeout,
                )
                job_id = self._json(create).get("id")
                if not job_id:
                    raise RuntimeError("LlamaParse create response did not include a job id")
                deadline = time.monotonic() + self.config.timeout
                while time.monotonic() < deadline:
                    poll = self._request(
                        "get", f"{self.config.endpoint}/api/v2/parse/{job_id}", headers=headers,
                        params={"expand": "markdown"}, timeout=min(30, self.config.timeout),
                    )
                    body = self._json(poll)
                    job_body = body.get("job") if isinstance(body.get("job"), dict) else body
                    status = str(job_body.get("status") or "").upper()
                    if status == "COMPLETED":
                        markdown = _extract_markdown(body)
                        if not markdown.strip():
                            raise RuntimeError("LlamaParse completed without expanded markdown")
                        result = {"status": "ok", "review": _parse_review(markdown, content_type),
                                "provider": "llamaparse", "model": f"llamaparse-{self.config.tier}",
                                "job_id": job_id,
                                "elapsed_ms": round((time.monotonic() - started) * 1000)}
                        self._delete_uploaded_file(file_id, headers)
                        return result
                    if status in {"FAILED", "CANCELLED"}:
                        raise RuntimeError(str(job_body.get("error_message") or f"LlamaParse job {status.lower()}"))
                    time.sleep(max(0.2, self.config.poll_interval))
                raise TimeoutError("LlamaParse job polling timed out")
            except Exception as exc:
                last_error = str(exc)
                self._delete_uploaded_file(file_id, headers)
                if last_error.startswith(("HTTP 401", "HTTP 403")):
                    break
                if attempt < self.config.max_retries:
                    time.sleep(min(2 ** attempt, 4))
        return {"status": "failed", "reason": last_error, "provider": "llamaparse",
                "model": f"llamaparse-{self.config.tier}",
                "elapsed_ms": round((time.monotonic() - started) * 1000)}

    def parse_full_pdf(self, pdf_path: str, *, timeout: Optional[int] = None,
                       max_retries: Optional[int] = None) -> Dict[str, Any]:
        """Upload one official PDF and return its full LlamaParse Markdown.

        The caller owns persistence of the Markdown. Keeping it out of the MCP
        response prevents an entire paper from being duplicated into logs or an
        agent tool payload.
        """
        if not self.config.enabled:
            return {"status": "disabled", "reason": "LLAMA_FULL_PDF_ENABLED is false"}
        if not self.config.api_key:
            return {"status": "skipped", "reason": "LLAMA_CLOUD_API_KEY is not configured"}
        if not self.config.api_key.startswith("llx-"):
            return {"status": "failed", "reason": "LLAMA_CLOUD_API_KEY is not a LlamaCloud key"}

        from pathlib import Path
        import hashlib

        source = Path(pdf_path)
        if not source.is_file():
            return {"status": "failed", "reason": f"PDF not found: {source}"}
        request_timeout = max(30, int(timeout if timeout is not None else self.config.timeout))
        attempts = max(0, int(max_retries if max_retries is not None else self.config.max_retries))
        started = time.monotonic()
        headers = {"Authorization": f"Bearer {self.config.api_key}"}
        last_error = "unknown error"
        pdf_hash = hashlib.sha256(source.read_bytes()).hexdigest()
        for attempt in range(attempts + 1):
            file_id = None
            try:
                upload = self._request(
                    "post", f"{self.config.endpoint}/api/v1/beta/files", headers=headers,
                    files={"file": (source.name, source.read_bytes(), "application/pdf")},
                    data={"purpose": "parse"}, timeout=request_timeout,
                )
                file_id = self._json(upload).get("id")
                if not file_id:
                    raise RuntimeError("LlamaParse upload response did not include a file id")
                create = self._request(
                    "post", f"{self.config.endpoint}/api/v2/parse",
                    headers={**headers, "Content-Type": "application/json"},
                    json={"file_id": file_id, "tier": self.config.tier, "version": "latest",
                          "agentic_options": {"custom_prompt": FULL_PDF_PROMPT}},
                    timeout=request_timeout,
                )
                job_id = self._json(create).get("id")
                if not job_id:
                    raise RuntimeError("LlamaParse create response did not include a job id")
                deadline = time.monotonic() + request_timeout
                while time.monotonic() < deadline:
                    poll = self._request(
                        "get", f"{self.config.endpoint}/api/v2/parse/{job_id}", headers=headers,
                        params={"expand": "markdown"}, timeout=min(30, request_timeout),
                    )
                    body = self._json(poll)
                    job_body = body.get("job") if isinstance(body.get("job"), dict) else body
                    status = str(job_body.get("status") or "").upper()
                    if status == "COMPLETED":
                        markdown = _extract_markdown(body)
                        if not markdown.strip():
                            raise RuntimeError("LlamaParse completed without expanded markdown")
                        self._delete_uploaded_file(file_id, headers)
                        return {
                            "status": "completed", "provider": "llamaparse",
                            "model": f"llamaparse-{self.config.tier}", "tier": self.config.tier,
                            "job_id": job_id, "markdown": markdown,
                            "page_markdown": _extract_page_markdown(body),
                            "markdown_chars": len(markdown), "pdf_sha256": pdf_hash,
                            "elapsed_ms": round((time.monotonic() - started) * 1000),
                            "file_cleanup_attempted": True,
                        }
                    if status in {"FAILED", "CANCELLED"}:
                        raise RuntimeError(str(job_body.get("error_message") or f"LlamaParse job {status.lower()}"))
                    time.sleep(max(0.2, self.config.poll_interval))
                raise TimeoutError("LlamaParse full-PDF job polling timed out")
            except Exception as exc:
                last_error = str(exc)
                self._delete_uploaded_file(file_id, headers)
                if last_error.startswith(("HTTP 401", "HTTP 403")):
                    break
                if attempt < attempts:
                    time.sleep(min(2 ** attempt, 4))
        return {"status": "failed", "reason": last_error, "provider": "llamaparse",
                "model": f"llamaparse-{self.config.tier}", "tier": self.config.tier,
                "pdf_sha256": pdf_hash, "elapsed_ms": round((time.monotonic() - started) * 1000),
                "file_cleanup_attempted": True}
