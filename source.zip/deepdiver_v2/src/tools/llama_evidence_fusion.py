"""Low-confidence region selection, crop generation, and safe evidence fusion."""

from __future__ import annotations

import hashlib
import io
import re
from typing import Any, Dict, Iterable, List, Optional, Tuple


RISK_TYPES = {"formula_extraction_risk", "table_structure_risk", "figure_structure_risk", "text_encoding_corruption"}
FIGURE_CAPTION_RE = re.compile(r"^\s*(?:fig(?:ure)?\.?|图)\s*\d+", re.IGNORECASE)
TABLE_CAPTION_RE = re.compile(r"^\s*(?:table|表)\s*[A-Z\d]+", re.IGNORECASE)
MIN_TABLE_WIDTH = 96.0
MIN_TABLE_HEIGHT = 24.0


def _union_bbox(boxes: Iterable[Iterable[float]]) -> List[float]:
    values = [list(map(float, box)) for box in boxes]
    return [min(box[0] for box in values), min(box[1] for box in values),
            max(box[2] for box in values), max(box[3] for box in values)]


def _expand_bbox(bbox: Iterable[float], content_type: str) -> List[float]:
    """Add enough neighboring context for the region type without crossing pages."""
    left, top, right, bottom = map(float, bbox)
    margins = {
        "formula": (32.0, 28.0),
        "table": (24.0, 28.0),
        "figure": (36.0, 36.0),
        "image": (36.0, 36.0),
        "figure_caption": (36.0, 36.0),
    }
    horizontal, vertical = margins.get(content_type, (16.0, 20.0))
    return [max(0.0, left - horizontal), max(0.0, top - vertical),
            right + horizontal, bottom + vertical]


def _can_merge(first: Dict[str, Any], second: Dict[str, Any]) -> bool:
    """Merge blocks that belong to one same-page logical region."""
    if first["page"] != second["page"] or first["content_type"] != second["content_type"]:
        return False
    a, b = first["bbox"], second["bbox"]
    horizontal_overlap = min(a[2], b[2]) - max(a[0], b[0])
    vertical_gap = max(0.0, max(a[1], b[1]) - min(a[3], b[3]))
    if first["content_type"] in {"table", "figure", "image", "figure_caption"}:
        return horizontal_overlap > 0 and vertical_gap <= 28.0
    return horizontal_overlap > 0 and vertical_gap <= 36.0


def _rect_gap(first: Iterable[float], second: Iterable[float]) -> Tuple[float, float]:
    """Return horizontal and vertical whitespace between two rectangles."""
    a, b = list(map(float, first)), list(map(float, second))
    horizontal = max(0.0, max(a[0], b[0]) - min(a[2], b[2]))
    vertical = max(0.0, max(a[1], b[1]) - min(a[3], b[3]))
    return horizontal, vertical


def _intersects_or_near(first: Iterable[float], second: Iterable[float], distance: float) -> bool:
    horizontal, vertical = _rect_gap(first, second)
    return horizontal <= distance and vertical <= distance


def _bbox_iou(first: Iterable[float], second: Iterable[float]) -> float:
    a, b = list(map(float, first)), list(map(float, second))
    left, top, right, bottom = max(a[0], b[0]), max(a[1], b[1]), min(a[2], b[2]), min(a[3], b[3])
    intersection = max(0.0, right - left) * max(0.0, bottom - top)
    if not intersection:
        return 0.0
    area_a = max(0.0, a[2] - a[0]) * max(0.0, a[3] - a[1])
    area_b = max(0.0, b[2] - b[0]) * max(0.0, b[3] - b[1])
    return intersection / max(1.0, area_a + area_b - intersection)


def _page_visual_metadata(pdf_path: str, page_number: int) -> Dict[str, Any]:
    """Read native PDF geometry so visual crops are not driven by text blocks alone."""
    import fitz

    document = fitz.open(pdf_path)
    try:
        page = document.load_page(int(page_number) - 1)
        captions = []
        for block in page.get_text("blocks"):
            text = str(block[4] or "").strip().replace("\n", " ")
            if not text:
                continue
            kind = "figure" if FIGURE_CAPTION_RE.match(text) else "table" if TABLE_CAPTION_RE.match(text) else None
            if kind:
                captions.append({"bbox": list(map(float, block[:4])), "kind": kind, "text": text})

        graphics: List[List[float]] = []
        for drawing in page.get_drawings():
            rect = drawing.get("rect")
            # Axes and arrows are often zero-height/zero-width vector strokes.
            if rect and (rect.width >= 1.0 or rect.height >= 1.0):
                graphics.append([float(rect.x0) - 0.5, float(rect.y0) - 0.5,
                                 float(rect.x1) + 0.5, float(rect.y1) + 0.5])
        for image in page.get_images(full=True):
            try:
                for rect in page.get_image_rects(image[0]):
                    if rect.width >= 1.0 and rect.height >= 1.0:
                        graphics.append([float(rect.x0), float(rect.y0), float(rect.x1), float(rect.y1)])
            except Exception:
                continue
        return {"page_bbox": [0.0, 0.0, float(page.rect.width), float(page.rect.height)],
                "captions": captions, "graphics": graphics}
    finally:
        document.close()


def _nearest_caption(bbox: Iterable[float], captions: Iterable[Dict[str, Any]], max_distance: float = 150.0) -> Optional[Dict[str, Any]]:
    ranked = []
    for caption in captions:
        horizontal, vertical = _rect_gap(bbox, caption["bbox"])
        # A caption in a different column must overlap horizontally with the visual object.
        if horizontal > 36.0 or vertical > max_distance:
            continue
        ranked.append((vertical + horizontal * 2.0, caption))
    return min(ranked, key=lambda value: value[0])[1] if ranked else None


def _grow_visual_bbox(seed: Iterable[float], metadata: Dict[str, Any], caption: Optional[Dict[str, Any]]) -> Tuple[List[float], bool]:
    """Grow a seed across nearby vector/image components into one visual object."""
    grown = list(map(float, seed))
    if caption:
        grown = _union_bbox((grown, caption["bbox"]))
    matched = False
    # Charts can be assembled from many separate vector lines. Repeat until their
    # connected neighborhood is exhausted, but do not bridge normal column gaps.
    changed = True
    while changed:
        changed = False
        for graphic in metadata.get("graphics") or []:
            if _intersects_or_near(grown, graphic, 24.0):
                union = _union_bbox((grown, graphic))
                if union != grown:
                    grown, matched, changed = union, True, True
    page = metadata["page_bbox"]
    grown = [max(page[0], grown[0] - 12.0), max(page[1], grown[1] - 12.0),
             min(page[2], grown[2] + 12.0), min(page[3], grown[3] + 12.0)]
    # Touching a page edge is legitimate for a full-width figure but cannot prove
    # an object is complete without a caption or a graphic component.
    page_area = max(1.0, (page[2] - page[0]) * (page[3] - page[1]))
    crop_area = max(0.0, (grown[2] - grown[0]) * (grown[3] - grown[1]))
    # A near-full-page result generally means unrelated vector decorations were
    # connected. Do not pay for a review that cannot be attributed to one figure.
    complete = matched and (caption is not None or grown[2] - grown[0] >= 120.0) and crop_area / page_area < 0.75
    return grown, complete


def _is_plausible_table(candidate: Dict[str, Any], metadata: Optional[Dict[str, Any]]) -> bool:
    bbox = candidate["bbox"]
    width, height = bbox[2] - bbox[0], bbox[3] - bbox[1]
    caption = _nearest_caption(bbox, (metadata or {}).get("captions") or [])
    if caption and caption["kind"] == "figure":
        return False
    if caption and caption["kind"] == "table":
        return True
    # A narrow vertical imprint, a caption fragment, or a one-line formula must
    # not consume the strict table review path.
    if width < MIN_TABLE_WIDTH or height < MIN_TABLE_HEIGHT:
        return False
    text = candidate.get("text", "")
    return len([line for line in text.splitlines() if line.strip()]) >= 2


def pdf_sha256(path: str) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def select_low_confidence_regions(
    parsed: Dict[str, Any],
    max_regions: int = 50,
    threshold: float = 0.85,
    pdf_path: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Select review regions and promote visual fragments to whole visual objects.

    ``pdf_path`` is optional to keep unit-only callers lightweight. Production
    callers provide it so candidate selection can use PDF vector/image geometry.
    """
    candidates: List[Dict[str, Any]] = []
    quality = parsed.get("parse_quality") or {}
    page_conf = quality.get("page_confidence") or {}
    for block in parsed.get("blocks") or parsed.get("layout_blocks") or []:
        bbox = block.get("bbox")
        if not isinstance(bbox, (list, tuple)) or len(bbox) != 4:
            continue
        page = block.get("page", block.get("page_number"))
        confidence = float(block.get("confidence", page_conf.get(str(page), page_conf.get(page, quality.get("overall_confidence", 1.0)))))
        risks = set(block.get("failure_modes") or block.get("risks") or [])
        kind = str(block.get("type", "text")).lower()
        risky = bool(risks & RISK_TYPES) or kind in {"formula", "table", "figure", "image"}
        if confidence >= threshold and not risky:
            continue
        if kind in {"formula", "table", "figure", "image"}:
            risks.add(f"{kind}_region")
        candidates.append({"page": page, "bbox": list(map(float, bbox)), "content_type": kind,
                           "confidence": confidence, "risks": sorted(risks),
                           "text": str(block.get("text") or "")})
    candidates.sort(key=lambda item: (not bool(item["risks"]), item["confidence"], item["page"] or 0, item["bbox"][1]))

    merged: List[Dict[str, Any]] = []
    for candidate in candidates:
        target = next((item for item in merged if _can_merge(item, candidate)), None)
        if target is None:
            merged.append(dict(candidate))
            continue
        target["bbox"] = _union_bbox((target["bbox"], candidate["bbox"]))
        target["confidence"] = min(float(target["confidence"]), float(candidate["confidence"]))
        target["risks"] = sorted(set(target["risks"]) | set(candidate["risks"]))
        target["text"] = "\n".join(value for value in (target.get("text"), candidate.get("text")) if value)

    metadata_by_page: Dict[int, Dict[str, Any]] = {}
    if pdf_path:
        for page in {item.get("page") for item in merged if item.get("page") is not None}:
            try:
                metadata_by_page[int(page)] = _page_visual_metadata(pdf_path, int(page))
            except Exception:
                # The local PDF parse remains usable if native vector inspection
                # fails on a malformed page.
                continue

    selected: List[Dict[str, Any]] = []
    for item in merged:
        metadata = metadata_by_page.get(int(item["page"])) if item.get("page") is not None else None
        caption = _nearest_caption(item["bbox"], (metadata or {}).get("captions") or [])
        requested_type = item["content_type"]
        is_visual = requested_type in {"figure", "image", "figure_caption"} or bool(caption and caption["kind"] == "figure")
        if requested_type == "table" and not is_visual and metadata is not None:
            if not _is_plausible_table(item, metadata):
                continue
        if requested_type == "table" and caption and caption["kind"] == "figure":
            is_visual = True

        item["original_bbox"] = list(item["bbox"])
        if is_visual and metadata:
            expanded, complete = _grow_visual_bbox(item["bbox"], metadata, caption)
            item.update({
                "content_type": "figure",
                "expanded_bbox": expanded,
                "crop_strategy": "visual_object",
                "crop_complete": complete,
                "caption_text": caption.get("text") if caption else "",
                "review_eligible": complete,
            })
            if not complete:
                item["risks"] = sorted(set(item["risks"]) | {"incomplete_visual_context"})
        else:
            item["expanded_bbox"] = _expand_bbox(item["bbox"], item["content_type"])
            item["crop_strategy"] = "context_padding"
            item["crop_complete"] = True
            item["review_eligible"] = True
        if item["content_type"] == "figure":
            # One figure can produce many tiny local text/line blocks. Their
            # object-level crops are interchangeable and must not consume the
            # per-paper API budget repeatedly.
            duplicate = any(
                existing["page"] == item["page"]
                and existing["content_type"] == "figure"
                and _bbox_iou(existing["expanded_bbox"], item["expanded_bbox"]) >= 0.85
                for existing in selected
            )
            if duplicate:
                continue
        selected.append(item)
    return selected[:max(0, int(max_regions))]


def crop_page(pdf_path: str, page_number: int, bbox: Iterable[float], padding: float = 0.0, scale: float = 2.0) -> bytes:
    """Render one expanded PDF bbox to PNG bytes. Requires PyMuPDF only at call time."""
    import fitz
    rect = fitz.Rect(*map(float, bbox))
    document = fitz.open(pdf_path)
    try:
        page = document.load_page(int(page_number) - 1)
        clip = rect + (-padding, -padding, padding, padding)
        clip = clip & page.rect
        pixmap = page.get_pixmap(matrix=fitz.Matrix(scale, scale), clip=clip, alpha=False)
        return pixmap.tobytes("png")
    finally:
        document.close()


def fuse_region(original: Dict[str, Any], result: Dict[str, Any], allow_override: bool = True, min_confidence: float = 0.85) -> Dict[str, Any]:
    """Attach a review, with LlamaParse self-confidence as the quality signal.

    Local parser confidence and crop completeness remain diagnostics. They are
    deliberately not vetoes: their role in hybrid mode is locating a region,
    not judging LlamaParse's transcription.
    """
    fused = dict(original)
    fused["original_confidence"] = original.get("confidence")
    fused["review"] = result
    fused["review_status"] = result.get("status", "failed")
    review = result.get("review") if isinstance(result, dict) else None
    valid = bool(review and result.get("status") == "ok")
    valid = valid and review.get("content_type") == original.get("content_type", "text")
    valid = valid and float(review.get("model_confidence", 0)) >= min_confidence
    if allow_override and valid:
        fused.update({"text": review.get("transcription") or original.get("text", ""),
                      "latex": review.get("latex"), "table": review.get("table"),
                      "description": review.get("description"), "source": "llama_vision_review",
                      "confidence": review.get("model_confidence"), "review_status": "accepted"})
    else:
        fused["source"] = "local_pdf"
        fused["review_status"] = "suggestion" if result.get("status") == "ok" else "failed"
    return fused


def build_hybrid_evidence_ledger(pdf_path: str, vision_result: Dict[str, Any], min_confidence: float) -> Dict[str, Any]:
    """Normalize regional LlamaParse results into Writer-facing evidence.

    Each entry is independently addressable by the original PDF page and bbox.
    LlamaParse confidence determines whether its content is usable; local crop
    signals are preserved only as diagnostics for a later human audit.
    """
    entries: List[Dict[str, Any]] = []
    for index, region in enumerate((vision_result or {}).get("regions") or [], start=1):
        if not isinstance(region, dict):
            continue
        review_result = region.get("review") if isinstance(region.get("review"), dict) else {}
        review = review_result.get("review") if isinstance(review_result.get("review"), dict) else {}
        llama_confidence = review.get("model_confidence")
        try:
            usable = (
                region.get("source") == "llama_vision_review"
                and float(llama_confidence) >= float(min_confidence)
            )
        except (TypeError, ValueError):
            usable = False
        bbox = region.get("expanded_bbox") or region.get("bbox") or []
        diagnostics = list(region.get("risks") or [])
        if region.get("crop_complete") is False and "local_crop_may_be_incomplete" not in diagnostics:
            diagnostics.append("local_crop_may_be_incomplete")
        entries.append({
            "evidence_id": f"visual-{index}",
            "source": region.get("source", "local_pdf"),
            "page": region.get("page"),
            "bbox": bbox,
            "original_bbox": region.get("original_bbox") or region.get("bbox") or [],
            "content_type": region.get("content_type", "figure"),
            "transcription": region.get("text", ""),
            "caption_text": region.get("caption_text", ""),
            "local_text_anchor": str(region.get("text", ""))[:300],
            "latex": region.get("latex"),
            "table": region.get("table"),
            "description": region.get("description"),
            "local_confidence": region.get("original_confidence", region.get("confidence")),
            "llama_confidence": llama_confidence,
            "review_status": region.get("review_status", "failed"),
            "citation_allowed": usable,
            "diagnostic_flags": diagnostics,
            "uncertainties": review.get("uncertainties") or [],
        })
    return {
        "format": "sciassistant_hybrid_evidence/v1",
        "pdf_sha256": pdf_sha256(str(pdf_path)),
        "mode": "hybrid",
        "provider": "llamaparse",
        "region_summary": {
            "selected": int((vision_result or {}).get("selected_count", 0) or 0),
            "successful": int((vision_result or {}).get("success_count", 0) or 0),
            "usable": sum(1 for entry in entries if entry["citation_allowed"]),
        },
        "entries": entries,
    }
