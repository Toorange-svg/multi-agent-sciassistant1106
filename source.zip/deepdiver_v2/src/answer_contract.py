"""Answer structure contracts and conservative output checks."""

from __future__ import annotations


def build_answer_contract(intent: dict | None) -> dict:
    intent = intent or {}
    task_type = intent.get("task_type", "focused_answer")
    if len(intent.get("response_structure") or []) >= 3 and task_type not in {"section_summary", "formula_explanation"}:
        sections = ["直接结论", "问题拆解", "分项分析", "综合判断", "证据边界"]
    elif task_type == "section_summary":
        sections = ["直接回答", "本节内容与逻辑", "原文依据", "范围与限制"]
    elif task_type == "experimental_evidence":
        sections = ["直接回答", "实验设置与结果", "证据定位", "数值可靠性与限制"]
    elif task_type == "formula_explanation":
        sections = ["直接回答", "公式与符号", "推导或作用", "解析限制"]
    elif task_type == "comparison":
        sections = ["直接结论", "比较维度", "证据与差异", "适用范围与限制"]
    elif task_type == "critical_analysis":
        sections = ["直接结论", "依据", "局限与风险", "综合判断"]
    elif task_type == "general_summary":
        sections = ["核心结论", "主要内容", "证据与边界"]
    else:
        sections = ["直接回答", "依据与细节", "边界说明"]
    scope = intent.get("scope")
    requires_boundary = bool(
        scope is None
        or scope in {"uploaded_pdf", "arxiv_or_literature"}
        or intent.get("requires_citation")
        or intent.get("requires_exact_values")
    )
    return {
        "sections": sections,
        "require_direct_answer": True,
        "require_evidence_boundary": requires_boundary,
        "task_type": task_type,
        "target": intent.get("target"),
        "multi_part": len(intent.get("response_structure") or []) >= 3,
    }


def answer_contract_instruction(contract: dict) -> str:
    sections = "、".join(contract.get("sections") or ["直接回答", "依据与细节"])
    extra = (
        "用户问题包含多个子问题，必须逐项覆盖，不能只按论文顺序罗列证据；最后必须给出综合判断。"
        if contract.get("multi_part") else ""
    )
    return (f"\n回答结构契约：必须按‘{sections}’组织。首段先直接回答用户问题；"
            + extra + "关键事实后给出页码/bbox或原文证据；无法从证据确认的数字、公式、图表必须标为不确定，不能猜测。")


def validate_answer_structure(answer: str, contract: dict) -> dict:
    text = str(answer or "").strip()
    missing = []
    if contract.get("require_direct_answer") and len(text) < 40:
        missing.append("direct_answer")
    first_part = text[:600].lower()
    if contract.get("require_direct_answer") and not any(marker in first_part for marker in ("直接回答", "结论", "主要", "是指", "指的是", "讲的是", "介绍了", "the paper", "this section")):
        missing.append("direct_answer_marker")
    heading_text = text.replace("\r", "")
    required_sections = contract.get("sections") or []
    missing_sections = [section for section in required_sections if section not in heading_text]
    # A model may answer directly without Markdown headings, so only enforce
    # section labels strictly for multi-part reports where omission causes an
    # entire sub-question to disappear.
    if contract.get("multi_part"):
        missing.extend(f"section:{section}" for section in missing_sections)
    evidence_markers = ("页码", "第 ", "第", "原文摘录", "原文：", "限制", "无法确认", "bbox")
    has_negative_boundary = any(marker in text for marker in ("没有证据", "无证据", "缺少证据"))
    if contract.get("require_evidence_boundary") and (has_negative_boundary or not any(marker in text for marker in evidence_markers)):
        missing.append("evidence_boundary")
    if contract.get("task_type") == "section_summary":
        whole_paper_markers = ("论文概览", "整篇论文", "全文主要", "本文主要提出")
        if any(marker in first_part for marker in whole_paper_markers) and not any(marker in first_part for marker in ("本节", "该章节", "这一节")):
            missing.append("scope_drift")
    return {"status": "passed" if not missing else "needs_review", "missing": list(dict.fromkeys(missing)), "character_count": len(text),
            "required_sections": required_sections, "multi_part": bool(contract.get("multi_part"))}
