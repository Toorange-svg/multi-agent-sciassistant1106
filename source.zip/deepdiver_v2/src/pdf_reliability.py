"""Reliability policy and source hand-off helpers for parsed PDFs."""

from copy import deepcopy
import json
import re
from pathlib import Path
from typing import Any, Dict, Iterable, List


LOW_CONFIDENCE_THRESHOLD = 0.60
LONG_DOCUMENT_PAGE_THRESHOLD = 30
_EXPLICIT_ARXIV_ID_PATTERN = re.compile(
    r'(?:arxiv\s*:\s*|arxiv\.org/(?:abs|pdf)/)(\d{4}\.\d{4,5}(?:v\d+)?)',
    re.IGNORECASE,
)


def extract_explicit_arxiv_ids(text: str) -> List[str]:
    """Return de-duplicated arXiv IDs that a user explicitly requested."""
    seen = set()
    paper_ids = []
    for paper_id in _EXPLICIT_ARXIV_ID_PATTERN.findall(text or ''):
        normalized = paper_id.lower()
        if normalized not in seen:
            paper_ids.append(normalized)
            seen.add(normalized)
    return paper_ids




_STRICT_PDF_EVIDENCE_MARKERS = (
    '\u53ea\u57fa\u4e8e pdf', '\u53ea\u57fa\u4e8epdf', 'pdf-only', 'pdf only', '\u4e0d\u5f97\u4f7f\u7528 html',
    '\u4e0d\u8981\u4f7f\u7528 html', 'pdf parser', 'pdf\u89e3\u6790\u5668', 'pdf \u89e3\u6790\u5668', '\u89e3\u6790\u72b6\u6001',
    '\u516c\u5f0f\u5757\u6570\u91cf', '\u8868\u683c\u5757\u6570\u91cf', '\u53cc\u680f\u9875\u6570\u91cf', '\u90e8\u5206\u89e3\u6790\u5931\u8d25', 'pdf \u6587\u672c',
)


def is_strict_pdf_evidence_request(text: str) -> bool:
    """Whether the user explicitly asks for PDF parser evidence only."""
    lowered = (text or '').lower()
    if any(marker in lowered for marker in _STRICT_PDF_EVIDENCE_MARKERS):
        return True
    # The common Chinese paper-analysis prompt is intentionally conservative:
    # an explicit arXiv full-text request combined with a no-guessing clause
    # means the answer must stay within the parsed PDF evidence, even when the
    # user did not spell out "PDF-only".
    return bool(
        extract_explicit_arxiv_ids(text)
        and ('全文' in lowered or 'full text' in lowered or 'full-text' in lowered)
        and any(marker in lowered for marker in ('不要猜测', '不猜测', "don't guess", 'do not guess'))
    )


def is_pdf_parser_status_only_request(text: str) -> bool:
    """Whether a strict request asks only for parser-boundary diagnostics.

    Such requests are deterministic and must not be sent through research/writing
    agents, which otherwise can manufacture a second, conflicting parse report.
    Unicode escapes keep this classifier stable when source files are edited from
    a Windows console with a non-UTF-8 active code page.
    """
    lowered = (text or '').lower()
    status_markers = (
        "\u89e3\u6790\u72b6\u6001",       # ????
        "\u89e3\u6790\u5668\u5b9e\u6d4b",   # ?????
        "\u89e3\u6790\u5668\u5143\u6570\u636e", # ??????
        "\u89e3\u6790\u98ce\u9669",       # ????
        "\u516c\u5f0f\u5757\u6570\u91cf",   # ?????
        "\u8868\u683c\u5757\u6570\u91cf",   # ?????
        "\u56fe\u6807\u9898\u5757\u6570\u91cf", # ??????
        "\u53cc\u680f\u9875\u6570\u91cf",   # ?????
        "\u90e8\u5206\u89e3\u6790\u5931\u8d25", # ??????
        "pdf parser",
        "parser metadata",
    )
    synthesis_markers = (
        "\u7814\u7a76\u95ee\u9898",       # ????
        "\u4e3b\u8981\u65b9\u6cd5",       # ????
        "\u5b9e\u9a8c\u7ed3\u8bba",       # ????
        "\u5b9e\u9a8c\u7ed3\u679c",       # ????
        "\u8bba\u6587\u7ed3\u8bba",       # ????
        "\u6982\u62ec\u8bba\u6587",       # ????
        "\u603b\u7ed3\u8bba\u6587",       # ????
        "\u65b9\u6cd5\u4e0e\u7ed3\u8bba", # ?????
    )
    return (
        is_strict_pdf_evidence_request(text)
        and any(marker in lowered for marker in status_markers)
        and not any(marker in lowered for marker in synthesis_markers)
    )


def _layout_counts(metadata: Dict[str, Any]) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for page in metadata.get('pages') or []:
        if isinstance(page, dict):
            layout = str(page.get('layout') or 'unknown')
            counts[layout] = counts.get(layout, 0) + 1
    return counts


def _block_type_counts(metadata: Dict[str, Any]) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for block in metadata.get('layout_blocks') or []:
        if isinstance(block, dict):
            block_type = str(block.get('type') or 'unknown')
            counts[block_type] = counts.get(block_type, 0) + 1
    return counts


def _structured_evidence(file_info: Dict[str, Any]) -> Dict[str, Any]:
    """Return structured table/formula records from parse metadata or the Writer-compacted digest.

    The Writer receives compacted key_files (``structured_evidence``) instead of the full
    ``parse_metadata``, so facts/status/verification helpers must accept both shapes.
    """
    if not isinstance(file_info, dict):
        return {}
    metadata = file_info.get('parse_metadata')
    if isinstance(metadata, dict) and (metadata.get('tables') is not None or metadata.get('formulas') is not None):
        return metadata
    compact = file_info.get('structured_evidence')
    if isinstance(compact, dict) and (compact.get('tables') is not None or compact.get('formulas') is not None):
        return compact
    return metadata if isinstance(metadata, dict) else {}


def build_pdf_parser_facts(key_files: List[Dict[str, Any]]) -> str:
    """Build non-negotiable, tool-observed parser facts for WriterAgent."""
    facts = []
    for file_info in key_files or []:
        if not isinstance(file_info, dict):
            continue
        quality, metadata = _source_quality_and_metadata(file_info)
        status = _parser_status(file_info, metadata)
        layout_counts = _layout_counts(metadata)
        block_counts = _block_type_counts(metadata)
        if not (status or layout_counts or block_counts):
            continue
        risk_modes = [str(x) for x in (quality.get('failure_modes') or [])]
        structured = _structured_evidence(file_info)
        structured_pages = [p for p in (structured.get('pages') or []) if isinstance(p, dict)]
        low_order_pages = [p.get('page') for p in structured_pages if p.get('reading_order_confidence') is not None and float(p.get('reading_order_confidence') or 0) < 0.75]
        structured_tables = [t for t in (structured.get('tables') or []) if isinstance(t, dict)]
        structured_formulas = [f for f in (structured.get('formulas') or []) if isinstance(f, dict)]
        structured_text = ''
        if structured_tables or structured_formulas:
            cross_page_merged = sum(1 for t in structured_tables if t.get('continuation'))
            tables_verified = sum(1 for t in structured_tables if t.get('cell_structure_verified'))
            tables_with_matrix = sum(1 for t in structured_tables if t.get('cell_matrix'))
            strong_formulas = sum(1 for f in structured_formulas if f.get('strong_formula'))
            structured_text = (
                f'; structured={{logical_tables={len(structured_tables)}, cross_page_merged={cross_page_merged}, '
                f'tables_verified={tables_verified}, tables_with_cell_matrix={tables_with_matrix}, '
                f'formulas_strong={strong_formulas}, formulas_weak={max(0, len(structured_formulas) - strong_formulas)}}}'
            )
            if low_order_pages:
                structured_text += f'; reading_order_low_confidence_pages={low_order_pages}'
        recovery = metadata.get('recovery') if isinstance(metadata.get('recovery'), dict) else {}
        recovery_text = ''
        if any(recovery.get(key) for key in ('encoding_repaired_blocks', 'symbol_font_mapped_blocks', 'encoding_repaired_pages', 'pdfminer_fallback_pages')):
            recovery_text = (
                f'; recovery={{encoding_repaired_blocks={recovery.get("encoding_repaired_blocks", 0)}, '
                f'symbol_font_mapped_blocks={recovery.get("symbol_font_mapped_blocks", 0)}, '
                f'encoding_repaired_pages={recovery.get("encoding_repaired_pages") or []}, '
                f'pdfminer_fallback_pages={recovery.get("pdfminer_fallback_pages") or []}}}'
            )
        risk_pages: Dict[str, List[int]] = {}
        for block_type, label in (('formula', 'formula'), ('table', 'table'), ('figure_caption', 'figure')):
            pages = sorted({int(b.get('page')) for b in (metadata.get('layout_blocks') or [])
                            if isinstance(b, dict) and b.get('type') == block_type and b.get('page') is not None})
            if pages:
                risk_pages[label] = pages
        label = file_info.get('title') or file_info.get('paper_id') or file_info.get('file_path') or 'PDF source'
        facts.append(
            f"- {label}: parser_pages={status.get('page_count', metadata.get('page_count', '?'))}; "
            f"parser_text_pages={status.get('text_page_count', metadata.get('text_page_count', '?'))}; "
            f"empty_pages={status.get('empty_page_count', metadata.get('empty_page_count', '?'))}; "
            f"content_length={status.get('content_length', metadata.get('content_length', '?'))}; "
            f"overall_confidence={quality.get('overall_confidence', '?')}; "
            f"layout_counts={layout_counts}; block_type_counts={block_counts}; "
            f"risk_modes={risk_modes}; risk_block_pages={risk_pages}"
            f"{structured_text}{recovery_text}."
        )
    if not facts:
        return ''
    return (
        "\n\nCANONICAL PDF PARSER FACTS ? TOOL OBSERVED, NOT MODEL INFERRED:\n"
        + "\n".join(facts)
        + "\nTerminology rule: 'formula blocks' and 'table blocks' mean parser layout blocks. "
        "Do NOT substitute counts of numbered equations, Tables I?X, or figures. "
        "Do NOT say the report is simulated when these facts are present."
    )


def build_pdf_evidence_ledger(key_files: List[Dict[str, Any]]) -> str:
    """Build a compact, deterministic evidence-permission ledger.

    This is intentionally separate from parser counts: it states what a
    downstream Writer may quote as a fact and what must remain a caveat.
    """
    entries = []
    for file_info in _dedupe_pdf_sources(key_files, by_paper=True):
        if not isinstance(file_info, dict):
            continue
        label = file_info.get('title') or file_info.get('paper_id') or file_info.get('file_path') or 'PDF source'
        structured = _structured_evidence(file_info)
        tables = [t for t in (structured.get('tables') or []) if isinstance(t, dict)]
        formulas = [f for f in (structured.get('formulas') or []) if isinstance(f, dict)]
        figures = [b for b in (structured.get('layout_blocks') or [])
                   if isinstance(b, dict) and b.get('type') == 'figure_caption']
        pages = [p for p in (structured.get('pages') or []) if isinstance(p, dict)]
        two_column_pages = [p.get('page') for p in pages if p.get('layout') == 'two_column']
        low_order_pages = [p.get('page') for p in pages if p.get('reading_order_confidence') is not None and float(p.get('reading_order_confidence') or 0) < 0.75]
        cross_page_tables = [t for t in tables if t.get('continuation')]
        visual_pages = [p.get('visuals') or {} for p in pages if (p.get('visuals') or {}).get('figure_structure_risk')]
        visual_labels = sum(int(v.get('extracted_label_block_count') or 0) for v in visual_pages)
        visual_nodes = sum(int(v.get('candidate_node_count') or 0) for v in visual_pages)
        visual_edges = sum(int(v.get('candidate_edge_line_count') or 0) for v in visual_pages)
        visual_arrows = sum(int(v.get('candidate_arrow_count') or 0) for v in visual_pages)
        visual_kinds = sorted({str(v.get('figure_kind')) for v in visual_pages if v.get('figure_kind')})
        def cell_quote_allowed(table):
            # Older cached parser metadata predates the explicit permission
            # field; preserve its semantics for single-page verified tables.
            return bool(table.get('cell_quote_allowed', (
                table.get('cell_structure_verified') and table.get('cell_matrix') and not table.get('continuation')
            )))
        direct_cells = sum(1 for t in tables if cell_quote_allowed(t) and not t.get('ocr_discrepancy'))
        row_only = sum(1 for t in tables if (t.get('cell_structure_verified') or t.get('cell_matrix')) and not cell_quote_allowed(t) and not t.get('ocr_discrepancy'))
        blocked_tables = sum(1 for t in tables if not (t.get('cell_structure_verified') and not t.get('ocr_discrepancy')))
        strong_formulas = sum(1 for f in formulas if f.get('strong_formula') and float(f.get('glyph_confidence', 1) or 0) >= 0.7)
        weak_formulas = max(0, len(formulas) - strong_formulas)
        hybrid = file_info.get('hybrid_evidence') if isinstance(file_info.get('hybrid_evidence'), dict) else {}
        hybrid_entries = [entry for entry in (hybrid.get('entries') or []) if isinstance(entry, dict)]
        hybrid_usable = sum(1 for entry in hybrid_entries if entry.get('citation_allowed'))
        entries.append(
            f"- {label}: tables={{cell_level={direct_cells}, row_level_only={row_only}, caption_only_or_blocked={blocked_tables}}}; "
            f"formulas={{strong_candidate={strong_formulas}, fragment_only={weak_formulas}}}; "
            f"figures={{caption_only={len(figures)}, visual_pages={len(visual_pages)}, labels_extracted={visual_labels}, "
            f"kinds={visual_kinds or ['none']}, candidates={{nodes={visual_nodes}, lines={visual_edges}, arrows={visual_arrows}}}, topology_verified=0}}; "
            f"layout={{two_column_pages={len(two_column_pages)}, reading_order_low_confidence_pages={low_order_pages or []}, "
            f"cross_page_tables={len(cross_page_tables)}}}; "
            f"hybrid_visual={{usable={hybrid_usable}, total={len(hybrid_entries)}}}"
        )
    if not entries:
        return ''
    return (
        "\n\nPDF EVIDENCE LEDGER (deterministic permissions):\n"
        + "\n".join(entries)
        + "\nPermission rules: cell_level tables may be cited by row/column only when cell_quote_allowed=true and no OCR discrepancy is flagged; "
        "row_level_only tables may be summarized but must not be quoted cell-by-cell; cross-page tables must be cited with their parser page span and repeated-header status; "
        "two-column pages with low reading-order confidence may be summarized but paragraph adjacency must not be asserted; caption_only_or_blocked tables, fragment_only formulas, and all figure topology are not verified evidence."
    )


def _dedupe_pdf_sources(key_files: Any, by_paper: bool = False) -> List[Dict[str, Any]]:
    """Collapse key_files entries that refer to the same paper/resource.

    ``by_paper=True`` groups every entry of the same arXiv paper (PDF extraction,
    official HTML rendering, parser metadata JSON) into one item, so reports emit
    one block per paper. ``by_paper=False`` deduplicates only entries that point
    to the same actual file (e.g. the Planner prefetch source plus an
    InformationSeeker-attached copy), keeping distinct files as separate sources
    for citation counting.
    """
    seen = set()
    result = []
    for file_info in key_files or []:
        if not isinstance(file_info, dict):
            continue
        if by_paper:
            identity = (
                file_info.get('paper_id')
                or file_info.get('pdf_path')
                or file_info.get('text_path')
                or file_info.get('file_path')
            )
        else:
            identity = (
                file_info.get('pdf_path')
                or file_info.get('text_path')
                or file_info.get('file_path')
                or file_info.get('parse_metadata_path')
            )
        if identity is None:
            result.append(file_info)
            continue
        if identity in seen:
            continue
        seen.add(identity)
        result.append(file_info)
    return result


def build_pdf_parser_status_report(key_files: List[Dict[str, Any]]) -> str:
    """Return a deterministic Chinese status block for explicit parser reports."""
    reports = []
    for file_info in _dedupe_pdf_sources(key_files, by_paper=True):
        if not isinstance(file_info, dict):
            continue
        quality, metadata = _source_quality_and_metadata(file_info)
        status = _parser_status(file_info, metadata)
        layout_counts = _layout_counts(metadata)
        block_counts = _block_type_counts(metadata)
        if not (status or layout_counts or block_counts):
            continue
        def pages_of(block_type: str) -> List[int]:
            return sorted({int(b.get('page')) for b in (metadata.get('layout_blocks') or [])
                           if isinstance(b, dict) and b.get('type') == block_type and b.get('page') is not None})
        formula_pages, table_pages, figure_pages = pages_of('formula'), pages_of('table'), pages_of('figure_caption')
        risk_modes = '\u3001'.join(str(x) for x in (quality.get('failure_modes') or [])) or '\u65e0'
        has_layout_info = bool(metadata.get('layout_blocks') or metadata.get('pages'))
        unknown = '\u672a\u63d0\u4f9b'

        def pages_text(pages: List[int]) -> str:
            if not has_layout_info:
                return unknown
            return ', '.join(map(str, pages)) or '\u65e0'

        two_column_count = layout_counts.get('two_column', 0) if has_layout_info else unknown
        single_column_count = layout_counts.get('single_column', 0) if has_layout_info else unknown
        reading_order_low_pages = sorted({int(p.get('page')) for p in (metadata.get('pages') or [])
                                          if isinstance(p, dict) and p.get('reading_order_confidence') is not None
                                          and float(p.get('reading_order_confidence') or 0) < 0.75 and p.get('page') is not None})
        formula_block_count = block_counts.get('formula', 0) if has_layout_info else unknown
        table_block_count = block_counts.get('table', 0) if has_layout_info else unknown
        figure_caption_count = block_counts.get('figure_caption', 0) if has_layout_info else unknown
        structured = _structured_evidence(file_info)
        structured_tables = [t for t in (structured.get('tables') or []) if isinstance(t, dict)]
        structured_formulas = [f for f in (structured.get('formulas') or []) if isinstance(f, dict)]
        logical_tables = len(structured_tables)
        cross_page_merged = sum(1 for t in structured_tables if t.get('continuation'))
        tables_verified = sum(1 for t in structured_tables if t.get('cell_structure_verified'))
        strong_formulas = sum(1 for f in structured_formulas if f.get('strong_formula'))
        weak_formulas = max(0, len(structured_formulas) - strong_formulas)
        recovery = metadata.get('recovery') if isinstance(metadata.get('recovery'), dict) else {}
        recovery_parts = []
        if recovery.get('encoding_repaired_blocks') or recovery.get('encoding_repaired_pages'):
            recovery_parts.append(
                '\u7f16\u7801\u4fee\u590d %d \u5757 / %d \u9875\uff08%s\uff09'
                % (recovery.get('encoding_repaired_blocks', 0), len(recovery.get('encoding_repaired_pages') or []),
                   ', '.join(map(str, recovery.get('encoding_repaired_pages') or [])) or '-')
            )
        if recovery.get('pdfminer_fallback_pages'):
            recovery_parts.append(
                'pdfminer \u4e8c\u6b21\u63d0\u53d6 %d \u9875\uff08%s\uff09'
                % (len(recovery.get('pdfminer_fallback_pages') or []),
                   ', '.join(map(str, recovery.get('pdfminer_fallback_pages') or [])))
            )
        if recovery.get('symbol_font_mapped_blocks'):
            recovery_parts.append('Symbol \u5b57\u4f53\u6620\u5c04 %d \u5757' % recovery.get('symbol_font_mapped_blocks'))
        ocr_cross = metadata.get('ocr_cross_check') if isinstance(metadata.get('ocr_cross_check'), dict) else {}
        ocr_cross_parts = []
        ocr_status = str(ocr_cross.get('status') or '')
        if ocr_status == 'unavailable':
            ocr_cross_parts.append(
                '- \u8868\u683c OCR \u4ea4\u53c9\u6821\u9a8c\uff1a\u672a\u542f\u7528\uff08\u672a\u68c0\u6d4b\u5230 Tesseract OCR\uff0c\u8868\u683c\u6587\u672c\u4ec5\u6765\u81ea PDF \u5185\u5d4c\u6587\u672c\u5c42\uff09'
            )
        elif ocr_status == 'enabled':
            ocr_cross_parts.append(
                '- \u8868\u683c OCR \u4ea4\u53c9\u6821\u9a8c\uff1a\u5df2\u542f\u7528\uff08\u6838\u9a8c %d \u5f20\uff0c\u5e73\u5747\u5339\u914d\u7387 %s\uff1b\u4e0d\u4e00\u81f4 %d \u5f20\uff09'
                % (ocr_cross.get('tables_checked', 0), ocr_cross.get('mean_match_ratio', 0.0), ocr_cross.get('tables_with_discrepancy', 0))
            )
        reports.append(
            "## PDF \u89e3\u6790\u72b6\u6001\u62a5\u544a\uff08\u89e3\u6790\u5668\u5b9e\u6d4b\uff09\n"
            f"- PDF \u603b\u9875\u6570\uff1a{status.get('page_count', metadata.get('page_count', '?'))}\n"
            f"- \u6210\u529f\u63d0\u53d6\u6587\u672c\u9875\u6570\uff1a{status.get('text_page_count', metadata.get('text_page_count', '?'))}\n"
            f"- \u7a7a\u767d\u9875\u6570\uff1a{status.get('empty_page_count', metadata.get('empty_page_count', '?'))}\n"
            f"- \u6574\u4f53\u89e3\u6790\u7f6e\u4fe1\u5ea6\uff1a{quality.get('overall_confidence', '?')}\n"
            f"- \u53cc\u680f\u9875\u6570\u91cf\uff1a{two_column_count}\uff1b\u5355\u680f\u9875\u6570\u91cf\uff1a{single_column_count}\n"
            f"- \u53cc\u680f\u9605\u8bfb\u987a\u5e8f\u4f4e\u7f6e\u4fe1\u9875\uff1a{', '.join(map(str, reading_order_low_pages)) if reading_order_low_pages else '\u65e0'}\uff08\u4ec5\u5750\u6807\u91cd\u5efa\uff0c\u4e0d\u8bc1\u660e\u8de8\u680f\u90bb\u63a5\u5173\u7cfb\uff09\n"
            f"- \u516c\u5f0f\u5757\u6570\u91cf\uff1a{formula_block_count}\uff08parser \u7248\u5f0f\u5757\uff0c\u4e0d\u7b49\u540c\u4e8e\u7f16\u53f7\u516c\u5f0f\u6570\uff09\n"
            f"- \u8868\u683c\u5757\u6570\u91cf\uff1a{table_block_count}\uff08parser \u7248\u5f0f\u5757\uff0c\u4e0d\u7b49\u540c\u4e8e\u8bba\u6587\u4e2d Table I\u2013X \u7684\u5f20\u6570\uff09\n"
            f"- \u56fe\u6807\u9898\u5757\u6570\u91cf\uff1a{figure_caption_count}\n"
            f"- \u56fe\u7ed3\u6784\u8bc6\u522b\uff1a{sum(1 for p in (metadata.get('pages') or []) if isinstance(p, dict) and (p.get('visuals') or {}).get('figure_structure_risk'))}\u9875\u542b\u56fe\u98ce\u9669\uff1b\u56fe\u6807\u7b7e\u53ea\u505a\u6587\u5b57\u5757\u63d0\u53d6，\u8282\u70b9/\u8fde\u7ebf topology_verified=0\n"
            f"- \u903b\u8f91\u8868\u91cd\u5efa\u6570\uff1a{logical_tables}\uff08\u8de8\u9875\u5408\u5e76 {cross_page_merged} \u5f20\uff1b\u9010\u683c\u6821\u9a8c\u901a\u8fc7 {tables_verified} \u5f20\uff0c\u672a\u901a\u8fc7 {max(0, logical_tables - tables_verified)} \u5f20\uff09\n"
             + ('\n'.join(ocr_cross_parts) + '\n' if ocr_cross_parts else '')
            + f"- \u516c\u5f0f\u7ed3\u6784\u5316\u6570\uff1a{strong_formulas} \u6761\u5f3a\u516c\u5f0f\uff08\u542b latex_guess \u5019\u9009\uff09+ {weak_formulas} \u6761\u4f4e\u7f6e\u4fe1\u516c\u5f0f\uff08\u4ec5\u539f\u6587\u7247\u6bb5\uff0c\u7981\u6b62\u6309\u786e\u5b9a\u516c\u5f0f\u5f15\u7528\uff09\n"
            + (f"- \u4e71\u7801\u6062\u590d\uff1a{'; '.join(recovery_parts)}\n" if recovery_parts else "")
            + f"- \u98ce\u9669\u7c7b\u578b\uff1a{risk_modes}\n"
            f"- \u516c\u5f0f\u98ce\u9669\u76f8\u5173\u9875\uff1a{pages_text(formula_pages)}\n"
            f"- \u8868\u683c\u98ce\u9669\u76f8\u5173\u9875\uff1a{pages_text(table_pages)}\n"
            f"- \u56fe\u7ed3\u6784\u98ce\u9669\u76f8\u5173\u9875\uff1a{pages_text(figure_pages)}\n"
            "- \u622a\u65ad\u8bf4\u660e\uff1a\u4ee5\u4e0a\u7edf\u8ba1\u63cf\u8ff0\u7684\u662f arxiv_read_paper \u5df2\u5b8c\u6210\u7684 PDF parser \u7ed3\u679c\uff1b\u5de5\u5177\u6765\u6e90\u672a\u6807\u8bb0\u622a\u65ad\u5e76\u4e0d\u7b49\u540c\u4e8e WriterAgent/LLM \u5df2\u8bfb\u5165\u5168\u6587\u3002\u540e\u7eed\u82e5\u53d1\u751f file_read \u622a\u65ad\uff0c\u5fc5\u987b\u4ee5\u8be5\u8c03\u7528\u7684 returned_char_count\u3001content_limit \u4e0e truncated \u5b57\u6bb5\u5224\u65ad\uff1b\u8fd9\u7c7b\u4e0a\u4e0b\u6587\u622a\u65ad\u4e0d\u4ee3\u8868 PDF \u7f3a\u9875\u3002"
        )
    return '\n\n'.join(reports)



def is_pdf_layout_boundary_test_request(text: str) -> bool:
    """Identify requests that evaluate layout parsing and Writer evidence limits.

    This is deliberately narrower than strict PDF mode. It selects a deterministic
    final safety report only when the user asks to test parser boundaries / Writer
    handling of formulas, tables, columns, or cross-page structures.
    """
    lowered = (text or '').lower()
    boundary_markers = (
        "\u7248\u5f0f\u89e3\u6790\u8fb9\u754c\u6d4b\u8bd5",  # ????????
        "\u89e3\u6790\u8fb9\u754c\u6d4b\u8bd5",              # ??????
        "writeragent", "writer agent",
        "\u8de8\u9875\u8868\u683c",                          # ????
        "\u53cc\u680f\u903b\u8f91\u9605\u8bfb\u987a\u5e8f",  # ????????
    )
    return is_strict_pdf_evidence_request(text) and any(marker in lowered for marker in boundary_markers)


def build_pdf_layout_boundary_test_report(key_files: List[Dict[str, Any]]) -> str:
    """Build a deterministic, non-hallucinatory boundary-test verdict.

    This replaces free-form Writer prose for explicit boundary tests. The test is
    about whether dangerous evidence is withheld, not about generating a detailed
    paper summary from low-confidence formula/table/figure regions.
    """
    reports = []
    for file_info in key_files or []:
        if not isinstance(file_info, dict):
            continue
        quality, metadata = _source_quality_and_metadata(file_info)
        status = _parser_status(file_info, metadata)
        if not (quality or metadata or status):
            continue
        layout_counts = _layout_counts(metadata)
        block_counts = _block_type_counts(metadata)

        def pages_of(block_type: str) -> List[int]:
            return sorted({int(block.get('page')) for block in (metadata.get('layout_blocks') or [])
                           if isinstance(block, dict) and block.get('type') == block_type
                           and block.get('page') is not None})

        formula_pages = pages_of('formula')
        table_pages = pages_of('table')
        figure_pages = pages_of('figure_caption')
        cross_page_pages = sorted({int(page.get('page')) for page in (metadata.get('pages') or [])
                                   if isinstance(page, dict) and page.get('cross_page_table_risk')
                                   and page.get('page') is not None})
        label = file_info.get('title') or file_info.get('paper_id') or '\u8be5 PDF'
        confidence = quality.get('overall_confidence', '?')
        pages = status.get('page_count', metadata.get('page_count', '?'))
        text_pages = status.get('text_page_count', metadata.get('text_page_count', '?'))
        dual = layout_counts.get('two_column', 0)
        single = layout_counts.get('single_column', 0)
        formula_label = ', '.join(map(str, formula_pages)) or '\u65e0'
        table_label = ', '.join(map(str, table_pages)) or '\u65e0'
        figure_label = ', '.join(map(str, figure_pages)) or '\u65e0'
        cross_page_statement = (
            f"\u89e3\u6790\u5668\u6807\u8bb0\u7684\u8de8\u9875\u8868\u683c\u98ce\u9669\u9875\uff1a{', '.join(map(str, cross_page_pages))}\u3002"
            if cross_page_pages else
            "\u5143\u6570\u636e\u672a\u6807\u8bb0 cross_page_table_risk\uff1b\u8fd9\u53ea\u8868\u793a\u89e3\u6790\u5668\u672a\u68c0\u51fa\u8de8\u9875\u98ce\u9669\uff0c"
            "\u4e0d\u7b49\u540c\u4e8e\u5df2\u89c6\u89c9\u9a8c\u8bc1\u4e0d\u5b58\u5728\u8de8\u9875\u8868\u683c\u3002"
        )
        reports.append(
            "## PDF \u7248\u5f0f\u89e3\u6790\u8fb9\u754c\u6d4b\u8bd5\u7ed3\u8bba\n"
            f"\u6d4b\u8bd5\u5bf9\u8c61\uff1a{label}\uff1bPDF parser \u5df2\u63d0\u53d6 {text_pages}/{pages} \u9875\uff0c\u6574\u4f53\u7f6e\u4fe1\u5ea6 {confidence}\u3002\n\n"
            "### 1. \u53cc\u680f\u903b\u8f91\u9605\u8bfb\u987a\u5e8f\n"
            f"- \u89e3\u6790\u5668\u8bc6\u522b\u53cc\u680f\u9875 {dual} \u9875\u3001\u5355\u680f\u9875 {single} \u9875\u3002"
            "\u53cc\u680f\u9875\u7684\u9605\u8bfb\u987a\u5e8f\u662f\u6839\u636e\u5757\u5750\u6807\u91cd\u5efa\u7684\uff0c\u56e0\u6b64\u53ef\u4f5c\u4e3a\u9ad8\u5c42\u7eaf\u6587\u5b57\u9605\u8bfb\u7684\u8f85\u52a9\uff0c"
            "\u4f46\u4e0d\u53ef\u4f5c\u4e3a\u8de8\u680f\u903b\u8f91\u3001\u7d27\u90bb\u516c\u5f0f\u5f52\u5c5e\u6216\u56fe\u6587\u5bf9\u5e94\u5173\u7cfb\u7684\u786e\u5b9a\u8bc1\u636e\u3002\n\n"
            "### 2. \u590d\u6742\u6570\u5b66\u516c\u5f0f\n"
            f"- \u516c\u5f0f\u7248\u5f0f\u5757\u4e3a {block_counts.get('formula', 0)} \u4e2a\uff1b\u98ce\u9669\u9875\uff1a{formula_label}\u3002\n"
            "- **WriterAgent \u5f15\u7528\u5224\u5b9a\uff1a\u7981\u6b62\u81ea\u52a8\u5f15\u7528\u5177\u4f53\u516c\u5f0f\u7b26\u53f7\u3001\u516c\u5f0f\u7f16\u53f7\u5bf9\u5e94\u5173\u7cfb\u3001\u63a8\u5bfc\u8fc7\u7a0b\u6216\u516c\u5f0f\u8ba1\u7b97\u7ed3\u8bba\u3002**"
            "\u5982\u9700\u5f15\u7528\uff0c\u5fc5\u987b\u4eba\u5de5\u5bf9\u7167\u539f\u59cb PDF \u9875\u9762\u3002\n\n"
            "### 3. \u8868\u683c\u7ed3\u6784\u4e0e\u8de8\u9875\u8868\u683c\n"
            f"- \u8868\u683c\u7248\u5f0f\u5757\u4e3a {block_counts.get('table', 0)} \u4e2a\uff1b\u7ed3\u6784\u98ce\u9669\u9875\uff1a{table_label}\u3002\n"
            "- **WriterAgent \u5f15\u7528\u5224\u5b9a\uff1a\u7981\u6b62\u81ea\u52a8\u5f15\u7528\u8868\u683c\u884c/\u5217\u5bf9\u5e94\u5173\u7cfb\u3001\u5355\u5143\u683c\u6570\u503c\u3001\u6307\u6807\u6392\u540d\u3001\u65b9\u6cd5\u6bd4\u8f83\u7ed3\u8bba\u6216\u7cbe\u786e\u53c2\u6570\u91cf\u3002**\n"
            f"- {cross_page_statement}\n\n"
            "### 4. \u56fe\u7ed3\u6784\u4e0e\u5b9e\u9a8c\u53ef\u89c6\u5316\n"
            f"- \u56fe\u6807\u9898\u7248\u5f0f\u5757\u4e3a {block_counts.get('figure_caption', 0)} \u4e2a\uff1b\u56fe\u7ed3\u6784\u98ce\u9669\u9875\uff1a{figure_label}\u3002\n"
            "- **WriterAgent \u5f15\u7528\u5224\u5b9a\uff1a\u7981\u6b62\u5c06\u56fe\u4e2d\u8fde\u7ebf\u3001\u6a21\u5757\u8fde\u63a5\u3001\u89c6\u89c9\u6bd4\u8f83\u6548\u679c\u6216\u56fe\u4e2d\u6807\u6ce8\u5f53\u4f5c\u5df2\u6838\u9a8c\u4e8b\u5b9e\u3002**\n\n"
            "### 5. WriterAgent \u9632\u7f16\u9020\u5224\u5b9a\n"
            "- \u5bf9\u4e8e\u9ad8\u5c42\u7eaf\u6587\u5b57\u53d9\u8ff0\uff0cWriterAgent \u53ef\u5728\u660e\u786e\u6807\u6ce8 PDF \u9875\u7801\u4e14\u8bed\u4e49\u4e0e\u539f\u6587\u76f4\u63a5\u5bf9\u5e94\u65f6\u8c28\u614e\u8f6c\u8ff0\u3002\n"
            "- \u5bf9\u4e8e\u4e0a\u8ff0\u516c\u5f0f\u3001\u8868\u683c\u3001\u56fe\u7ed3\u6784\u3001\u8de8\u9875\u8868\u683c\u98ce\u9669\uff0c\u9632\u7f16\u9020\u95f8\u95e8\u5c06\u8f93\u51fa\u201c## \u90e8\u5206\u89e3\u6790\u5931\u8d25\u8bf4\u660e\u201d\uff0c"
            "\u800c\u4e0d\u662f\u8865\u5168\u7b26\u53f7\u3001\u8868\u683c\u5355\u5143\u683c\u3001\u7cbe\u786e\u6570\u503c\u3001\u6392\u540d\u6216\u56fe\u7ed3\u6784\u3002\n"
            "- `file_read` \u7684\u4e0a\u4e0b\u6587\u622a\u65ad\u4e0e PDF parser \u9875\u9762\u5b8c\u6574\u6027\u662f\u4e24\u4e2a\u4e0d\u540c\u6982\u5ff5\uff1b"
            "\u53ea\u80fd\u4ee5 `returned_char_count`\u3001`content_limit` \u548c `truncated` \u5224\u5b9a\u524d\u8005\uff0c\u4e0d\u80fd\u8ba4\u5b9a PDF \u7f3a\u9875\u3002\n\n"
            "### \u6d4b\u8bd5\u5224\u5b9a\n"
            "**\u53ef\u5b8c\u6210\uff0c\u4f46\u53ef\u9760\u8303\u56f4\u662f\u201c\u68c0\u6d4b + \u7ed3\u6784\u98ce\u9669\u63d0\u793a + \u62d2\u7edd\u4e0d\u53ef\u9760\u5f15\u7528\u201d\uff0c\u4e0d\u662f\u201c\u5bf9\u590d\u6742 PDF \u8fdb\u884c\u65e0\u635f\u91cd\u5efa\u201d\u3002**"
        )
    return '\n\n'.join(reports)


def filter_to_pdf_parse_sources(key_files: Any) -> List[Dict[str, Any]]:
    """For strict PDF-only tasks, retain only tool-tracked parsed PDF sources."""
    retained = []
    for file_info in key_files or []:
        if isinstance(file_info, dict):
            quality, metadata = _source_quality_and_metadata(file_info)
            if quality or metadata or isinstance(file_info.get('parser_status'), dict):
                retained.append(deepcopy(file_info))
    return retained

def filter_to_paper_evidence_sources(key_files: Any, strict: bool = False) -> List[Dict[str, Any]]:
    '''Keep only the target paper PDF and official affiliated resources.

    Strict mode admits only canonical PDF parse sources.  Normal paper mode
    additionally keeps tool-attached official resources (project page, code
    repository, supplementary material) and drops research notes/web summaries.
    '''
    if strict:
        return filter_to_pdf_parse_sources(key_files)
    retained = []
    for file_info in key_files or []:
        if not isinstance(file_info, dict):
            continue
        quality, metadata = _source_quality_and_metadata(file_info)
        source_type = str(file_info.get('source_type') or '')
        if quality or metadata or isinstance(file_info.get('parser_status'), dict):
            if file_info not in retained:
                retained.append(deepcopy(file_info))
        elif source_type in ('official_resource', 'arxiv_html', 'supplementary'):
            if file_info not in retained:
                retained.append(deepcopy(file_info))
    return retained


def collect_paper_related_seeker_files(
    task_results: Iterable[Dict[str, Any]], paper_ids: Iterable[str]
) -> List[Dict[str, Any]]:
    '''Return InformationSeeker key_files whose paths reference a requested paper ID.

    Used only as a degraded paper-mode fallback when Planner's own prefetch
    failed; these files carry no canonical parser metadata and are labelled as
    seeker-collected local extractions.
    '''
    ids = [str(pid).lower() for pid in paper_ids or []]
    collected = []
    for task_result in task_results or []:
        if not isinstance(task_result, dict):
            continue
        data = task_result.get('data', {})
        if not isinstance(data, dict):
            continue
        for item in data.get('key_files') or []:
            if not isinstance(item, dict):
                continue
            path_text = str(item.get('file_path') or '').lower()
            if ids and any(pid in path_text for pid in ids):
                item.setdefault('source_type', 'seeker_paper_text')
                collected.append(deepcopy(item))
    return collected


def has_paper_related_seeker_file(
    task_results: Iterable[Dict[str, Any]], paper_ids: Iterable[str]
) -> bool:
    '''Whether any seeker result reported a local file matching a paper ID.'''
    return bool(collect_paper_related_seeker_files(task_results, paper_ids))


def _quality_from_tool_result(result: Any) -> Dict[str, Any]:
    """Extract parse quality from the standard BaseAgent tool-result envelope."""
    if not isinstance(result, dict):
        return {}
    data = result.get('data') if isinstance(result.get('data'), dict) else {}
    metadata = result.get('metadata') if isinstance(result.get('metadata'), dict) else {}
    quality = data.get('parse_quality') or metadata.get('parse_quality')
    return quality if isinstance(quality, dict) else {}


def _as_mapping(value: Any) -> Dict[str, Any]:
    """Best-effort conversion for MCP payloads that arrive as JSON text/wrappers."""
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            decoded = json.loads(value)
        except (TypeError, ValueError):
            return {}
        return decoded if isinstance(decoded, dict) else {}
    if value is None:
        return {}
    to_dict = getattr(value, 'to_dict', None)
    if callable(to_dict):
        try:
            converted = to_dict()
        except Exception:
            converted = None
        if isinstance(converted, dict):
            return converted
    attributes = getattr(value, '__dict__', None)
    return attributes if isinstance(attributes, dict) else {}


def _unwrap_tool_result(result: Any) -> Dict[str, Any]:
    """Normalize direct dicts, JSON payloads, and MCPClientResult-like objects."""
    mapping = _as_mapping(result)
    if mapping:
        # Some MCP transports put the standard envelope under ``result`` or
        # ``output_result``. Unwrap it without losing a direct valid envelope.
        for nested_key in ('output_result', 'result'):
            nested = _as_mapping(mapping.get(nested_key))
            if nested and any(key in nested for key in ('success', 'data', 'metadata')):
                mapping = nested
                break
        # MCPClient._make_request wraps the server's tool envelope in its own
        # MCPClientResult. BaseAgent then makes that wrapper a dict again. The
        # resulting shape is {success: true, data: {success: true, data: ...}}.
        # Strict mode must unwrap this transport layer before checking parser
        # evidence, otherwise a genuine successful arxiv_read_paper response
        # looks like it has no parse_quality or parser_status.
        nested_data = _as_mapping(mapping.get('data'))
        if nested_data and 'success' in nested_data and any(
            key in nested_data for key in ('data', 'metadata', 'error')
        ):
            mapping = nested_data
        return {
            'success': bool(mapping.get('success', False)),
            'data': mapping.get('data'),
            'error': mapping.get('error'),
            'metadata': mapping.get('metadata') or {},
        }
    return {
        'success': bool(getattr(result, 'success', False)),
        'data': getattr(result, 'data', None),
        'error': getattr(result, 'error', None),
        'metadata': getattr(result, 'metadata', {}),
    }


def _canonical_parse_metadata(data: Dict[str, Any]) -> Dict[str, Any]:
    """Support both full metadata wrappers and the page-list JSON sidecar."""
    raw = data.get('parse_metadata')
    if isinstance(raw, dict):
        return deepcopy(raw)
    if isinstance(raw, list):
        return {'pages': deepcopy(raw), 'layout_blocks': deepcopy(data.get('layout_blocks') or [])}
    return {'pages': [], 'layout_blocks': deepcopy(data.get('layout_blocks') or [])}


def pdf_source_from_tool_result(result: Any, arguments: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Convert one ``arxiv_read_paper`` response into a canonical PDF source.

    ``BaseAgent.execute_tool_call`` normally receives ``MCPClientResult`` rather
    than a dict. Normalize it before extraction so strict PDF mode cannot reject
    a successful response merely because of its Python wrapper type.
    """
    envelope = _unwrap_tool_result(result)
    if not envelope.get('success', False):
        return {}
    data = _as_mapping(envelope.get('data'))
    metadata = _as_mapping(envelope.get('metadata'))
    # Normalize nested JSON before asking the legacy quality helper to inspect it.
    envelope = {**envelope, 'data': data, 'metadata': metadata}
    quality = _quality_from_tool_result(envelope)
    parse_metadata = _canonical_parse_metadata(data)
    parser_status = data.get('parser_status') if isinstance(data.get('parser_status'), dict) else {}
    if not parser_status:
        parser_status = {
            key: metadata[key] for key in ('page_count', 'text_page_count', 'empty_page_count', 'content_length', 'extraction_status', 'parser')
            if key in metadata
        }
    if not quality or not parser_status:
        return {}
    arguments = arguments if isinstance(arguments, dict) else {}
    paper_id = str(data.get('paper_id') or arguments.get('paper_id') or '')
    pdf_path = str(data.get('pdf_path') or '')
    text_path = str(data.get('text_path') or '')
    if not (paper_id or pdf_path or text_path):
        return {}
    warnings = quality.get('warnings') or []
    full_llama = data.get('llama_full_pdf') if isinstance(data.get('llama_full_pdf'), dict) else {}
    return {
        'title': f'arXiv:{paper_id}' if paper_id else 'Parsed arXiv PDF',
        'desc': 'PDF extracted through arxiv_read_paper. ' + (
            f"Layout warnings: {'; '.join(str(item) for item in warnings[:3])}" if warnings else 'No layout warnings reported.'
        ),
        'file_path': text_path or pdf_path,
        'paper_id': paper_id,
        'pdf_path': pdf_path,
        'parse_metadata_path': str(data.get('parse_metadata_path') or ''),
        'parse_quality': deepcopy(quality),
        'risk_summary': deepcopy(data.get('risk_summary') or metadata.get('risk_summary') or {}),
        'parser_status': deepcopy(parser_status),
        'source_integrity': deepcopy(data.get('source_integrity') or metadata.get('source_integrity') or {}),
        'cache_hit': bool(data.get('cache', {}).get('hit') if isinstance(data.get('cache'), dict) else metadata.get('cache_hit', False)),
        'parse_metadata': parse_metadata,
        'full_pdf_parser_enhancement': {
            'provider': full_llama.get('provider', 'llamaparse'),
            'status': full_llama.get('status', 'disabled'),
            'text_path': str(data.get('llama_full_pdf_text_path') or full_llama.get('text_path') or ''),
            'tier': full_llama.get('tier', ''),
            'elapsed_ms': full_llama.get('elapsed_ms'),
            'markdown_chars': full_llama.get('markdown_chars', 0),
            'requires_local_pdf_verification': True,
        },
        'pdf_parse_mode': str(data.get('pdf_parse_mode') or 'local'),
        'hybrid_evidence': deepcopy(data.get('hybrid_evidence') or {}),
        'hybrid_evidence_path': str(data.get('hybrid_evidence_path') or ''),
        'is_final_output_file': False,
    }


def collect_pdf_parse_sources(reasoning_trace: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Convert successful ``arxiv_read_paper`` trace entries to source records.

    The trace is the deterministic place where the original MCP result is
    retained. This avoids relying on the LLM completion payload to remember
    layout-risk metadata.
    """
    sources: List[Dict[str, Any]] = []
    seen = set()
    for step in reasoning_trace or []:
        if not isinstance(step, dict) or step.get('tool') != 'arxiv_read_paper':
            continue
        result = _unwrap_tool_result(step.get('result'))
        if not result.get('success', False):
            continue
        data = result.get('data') if isinstance(result.get('data'), dict) else {}
        quality = _quality_from_tool_result(result)
        if not quality:
            continue
        metadata = result.get('metadata') if isinstance(result.get('metadata'), dict) else {}
        parse_metadata = data.get('parse_metadata') if isinstance(data.get('parse_metadata'), dict) else {}
        risk_summary = data.get('risk_summary') if isinstance(data.get('risk_summary'), dict) else (
            metadata.get('risk_summary') if isinstance(metadata.get('risk_summary'), dict) else {}
        )
        parser_status = data.get('parser_status') if isinstance(data.get('parser_status'), dict) else (
            parse_metadata.get('parser_status') if isinstance(parse_metadata.get('parser_status'), dict) else {}
        )

        arguments = step.get('arguments') if isinstance(step.get('arguments'), dict) else {}
        paper_id = str(data.get('paper_id') or arguments.get('paper_id') or '')
        pdf_path = str(data.get('pdf_path') or '')
        text_path = str(data.get('text_path') or '')
        source_id = paper_id or pdf_path or text_path
        if not source_id or source_id in seen:
            continue
        seen.add(source_id)

        warnings = quality.get('warnings') or []
        warning_text = '; '.join(str(item) for item in warnings[:3])
        sources.append({
            'title': f'arXiv:{paper_id}' if paper_id else 'Parsed arXiv PDF',
            'desc': (
                'PDF extracted through arxiv_read_paper. '
                + (f'Layout warnings: {warning_text}' if warning_text else 'No layout warnings reported.')
            ),
            'file_path': text_path or pdf_path,
            'paper_id': paper_id,
            'pdf_path': pdf_path,
            'parse_metadata_path': str(data.get('parse_metadata_path') or ''),
            'parse_quality': deepcopy(quality),
            'risk_summary': deepcopy(risk_summary),
            'parser_status': deepcopy(parser_status),
            'source_integrity': deepcopy(data.get('source_integrity') or metadata.get('source_integrity') or {}),
            'cache_hit': bool(data.get('cache', {}).get('hit') if isinstance(data.get('cache'), dict) else metadata.get('cache_hit', False)),
            'full_pdf_parser_enhancement': {
                'provider': (data.get('llama_full_pdf') or {}).get('provider', 'llamaparse') if isinstance(data.get('llama_full_pdf'), dict) else 'llamaparse',
                'status': (data.get('llama_full_pdf') or {}).get('status', 'disabled') if isinstance(data.get('llama_full_pdf'), dict) else 'disabled',
                'text_path': str(data.get('llama_full_pdf_text_path') or ((data.get('llama_full_pdf') or {}).get('text_path', '') if isinstance(data.get('llama_full_pdf'), dict) else '')),
                'tier': (data.get('llama_full_pdf') or {}).get('tier', '') if isinstance(data.get('llama_full_pdf'), dict) else '',
                'elapsed_ms': (data.get('llama_full_pdf') or {}).get('elapsed_ms') if isinstance(data.get('llama_full_pdf'), dict) else None,
                'markdown_chars': (data.get('llama_full_pdf') or {}).get('markdown_chars', 0) if isinstance(data.get('llama_full_pdf'), dict) else 0,
                'requires_local_pdf_verification': True,
            },
            'pdf_parse_mode': str(data.get('pdf_parse_mode') or 'local'),
            'hybrid_evidence': deepcopy(data.get('hybrid_evidence') or {}),
            'hybrid_evidence_path': str(data.get('hybrid_evidence_path') or ''),
            'parse_metadata': deepcopy(parse_metadata) if parse_metadata else {
                'parse_quality': deepcopy(quality),
                'risk_summary': deepcopy(risk_summary),
                'parser_status': deepcopy(parser_status),
            },
            'is_final_output_file': False,
        })
    return sources


def merge_pdf_parse_sources(
    key_files: Any,
    reasoning_trace: Iterable[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Append tracked PDF sources unless the completion already names the file."""
    merged = [deepcopy(item) for item in (key_files or []) if isinstance(item, dict)]
    def identifiers(item: Dict[str, Any]) -> set:
        return {
            str(value) for value in (
                item.get('paper_id'), item.get('pdf_path'), item.get('file_path')
            ) if value
        }

    for source in collect_pdf_parse_sources(reasoning_trace):
        source_ids = identifiers(source)
        matching_item = next((item for item in merged if source_ids & identifiers(item)), None)
        if matching_item is None:
            merged.append(source)
            continue
        # Completion key_files is model-generated and may omit metadata. Preserve
        # its description/path while injecting the tool-observed parse quality.
        matching_item.setdefault('paper_id', source.get('paper_id'))
        matching_item.setdefault('pdf_path', source.get('pdf_path'))
        matching_item.setdefault('parse_metadata_path', source.get('parse_metadata_path'))
        matching_item['parse_quality'] = deepcopy(source['parse_quality'])
        matching_item['risk_summary'] = deepcopy(source.get('risk_summary') or {})
        matching_item['parser_status'] = deepcopy(source.get('parser_status') or {})
        matching_item['source_integrity'] = deepcopy(source.get('source_integrity') or {})
        matching_item['cache_hit'] = bool(source.get('cache_hit', False))
        matching_item['full_pdf_parser_enhancement'] = deepcopy(source.get('full_pdf_parser_enhancement') or {})
        matching_item['pdf_parse_mode'] = source.get('pdf_parse_mode', 'local')
        matching_item['hybrid_evidence'] = deepcopy(source.get('hybrid_evidence') or {})
        matching_item['hybrid_evidence_path'] = source.get('hybrid_evidence_path', '')
        matching_item['parse_metadata'] = deepcopy(source['parse_metadata'])
    return merged


def attach_pdf_parse_sources(task_done_result: Any, reasoning_trace: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    """Return completion data with parse-quality-bearing sources attached."""
    result = deepcopy(task_done_result) if isinstance(task_done_result, dict) else {}
    result['key_files'] = merge_pdf_parse_sources(result.get('key_files'), reasoning_trace)
    return result


def _source_quality_and_metadata(file_info: Dict[str, Any]):
    metadata = file_info.get('parse_metadata') if isinstance(file_info.get('parse_metadata'), dict) else {}
    quality = file_info.get('parse_quality')
    if not isinstance(quality, dict):
        quality = metadata.get('parse_quality') if isinstance(metadata.get('parse_quality'), dict) else {}
    return quality, metadata


def _parser_status(file_info: Dict[str, Any], metadata: Dict[str, Any]) -> Dict[str, Any]:
    status = file_info.get('parser_status')
    if isinstance(status, dict) and status:
        return status
    status = metadata.get('parser_status')
    return status if isinstance(status, dict) else {}


def _affected_page_labels(quality: Dict[str, Any], metadata: Dict[str, Any]) -> List[str]:
    labels = []
    page_map = quality.get('page_confidence') or {}
    for page, confidence in page_map.items():
        try:
            if float(confidence) < 0.85:
                labels.append(f'p. {page}')
        except (TypeError, ValueError):
            continue
    for page in metadata.get('pages') or []:
        if not isinstance(page, dict):
            continue
        page_number = page.get('page')
        if page.get('cross_page_table_risk') and page_number is not None:
            labels.append(f'p. {page_number}')
    return sorted(set(labels), key=lambda item: int(item.split()[-1]) if item.split()[-1].isdigit() else item)


def build_pdf_reliability_guidance(key_files: List[Dict[str, Any]]) -> str:
    """Return source-specific restrictions for unreliable PDF layout extraction.

    Parser status and Agent context status are intentionally separate. A short
    ``file_read`` response must never be interpreted as a short/incomplete PDF.
    """
    low_confidence_sources = []
    for index, file_info in enumerate(key_files or [], 1):
        if not isinstance(file_info, dict):
            continue
        quality, metadata = _source_quality_and_metadata(file_info)
        if not quality:
            continue
        try:
            confidence = float(quality.get('overall_confidence', 1.0))
        except (TypeError, ValueError):
            confidence = 0.0
        failure_modes = [str(mode) for mode in (quality.get('failure_modes') or [])]
        if confidence < LOW_CONFIDENCE_THRESHOLD or failure_modes:
            label = file_info.get('title') or file_info.get('filename') or file_info.get('file_path') or f'source {index}'
            status = _parser_status(file_info, metadata)
            pages = _affected_page_labels(quality, metadata)
            low_confidence_sources.append((
                str(label), confidence, failure_modes, pages,
                status.get('page_count'), status.get('text_page_count'),
                [str(warning) for warning in (quality.get('warnings') or [])[:3]],
            ))

    if not low_confidence_sources:
        return ''

    source_lines = []
    for label, confidence, modes, pages, page_count, text_page_count, warnings in low_confidence_sources:
        parser_part = ''
        if page_count is not None or text_page_count is not None:
            parser_part = f'; parser_pages={page_count}, parser_text_pages={text_page_count}'
        affected = ', '.join(pages) or ('; '.join(warnings) if warnings else 'unspecified')
        source_lines.append(
            f"- {label} (confidence={confidence:.2f}; risks={', '.join(modes) or 'low_parse_confidence'}; "
            f"affected={affected}{parser_part})"
        )
    return (
        "\n\nPDF RELIABILITY GUARD \u2014 PARTIAL_PARSE_FAILURE_NOTICE_REQUIRED:\n"
        "The following PDF sources have layout/extraction risks:\n"
        + "\n".join(source_lines)
        + "\nRules: Do not state exact table values, rankings, formulae, or formula-derived conclusions "
        "from these sources unless independently supported by a high-confidence source. Do not repair "
        "missing symbols or infer table cells. If any such source is material to the answer, include a "
        "section titled '## \u90e8\u5206\u89e3\u6790\u5931\u8d25\u8bf4\u660e' that identifies the affected pages/content type and uses "
        "cautious wording. Keep page-level citations only when a page number is present in the source. "
        "Do not infer PDF page loss from an Agent/file-read context truncation."
    )


def build_pdf_partial_failure_notice(key_files: List[Dict[str, Any]]) -> str:
    """Build a deterministic user-visible notice for unreliable PDF evidence."""
    affected = []
    for index, file_info in enumerate(_dedupe_pdf_sources(key_files, by_paper=True), 1):
        if not isinstance(file_info, dict):
            continue
        quality, metadata = _source_quality_and_metadata(file_info)
        if not quality:
            continue
        try:
            confidence = float(quality.get('overall_confidence', 1.0))
        except (TypeError, ValueError):
            confidence = 0.0
        modes = [str(mode) for mode in (quality.get('failure_modes') or [])]
        if confidence >= LOW_CONFIDENCE_THRESHOLD and not modes:
            continue
        label = file_info.get('title') or file_info.get('filename') or file_info.get('file_path') or f'\u6765\u6e90 {index}'
        warnings = [str(warning) for warning in (quality.get('warnings') or [])]
        pages = _affected_page_labels(quality, metadata)
        status = _parser_status(file_info, metadata)
        mode_keywords = {
            'table_structure_risk': 'table',
            'cross_page_table_risk': 'table',
            'formula_extraction_risk': 'mathematical formula',
            'figure_structure_risk': 'figure or flowchart',
            'layout_uncertain': 'layout',
            'text_encoding_corruption': 'replacement character',
        }
        selected_warnings = []
        for mode in modes:
            keyword = mode_keywords.get(mode)
            match = next((warning for warning in warnings if keyword and keyword in warning.lower()), None)
            if match and match not in selected_warnings:
                selected_warnings.append(match)
        details = selected_warnings or warnings[:3]
        if pages:
            details.append('\u53d7\u5f71\u54cd\u9875\u9762\uff1a' + '\u3001'.join(pages))
        if status.get('page_count') is not None:
            details.append(
                f"PDF parser \u72b6\u6001\uff1a{status.get('text_page_count', '?')}/{status.get('page_count', '?')} \u9875\u5df2\u63d0\u53d6\uff1b"
                "\u8fd9\u4e0d\u7b49\u540c\u4e8e Agent \u4e0a\u4e0b\u6587\u662f\u5426\u5b8c\u6574\u3002"
            )
        detail = '\uff1b'.join(details) or '\u7248\u5f0f\u6216\u6587\u5b57\u63d0\u53d6\u5b58\u5728\u4e0d\u786e\u5b9a\u6027'
        risks = '\u3001'.join(modes) or 'low_parse_confidence'
        affected.append(f'- {label}\uff08\u7f6e\u4fe1\u5ea6 {confidence:.2f}\uff1b\u98ce\u9669\uff1a{risks}\uff09\uff1a{detail}')

    if not affected:
        return ''
    return (
        '## \u90e8\u5206\u89e3\u6790\u5931\u8d25\u8bf4\u660e\n\n'
        '\u4ee5\u4e0b PDF \u7684\u7248\u5f0f\u89e3\u6790\u5b58\u5728\u98ce\u9669\u3002\u6d89\u53ca\u8868\u683c\u6570\u503c\u3001\u516c\u5f0f\u7b26\u53f7\u3001\u56fe\u002f\u6d41\u7a0b\u56fe\u8fde\u7ebf\u6216\u8de8\u9875\u8868\u683c\u65f6\uff0c'
        '\u56de\u7b54\u4e0d\u80fd\u5c06\u672a\u7ecf\u6838\u9a8c\u7684\u5185\u5bb9\u4f5c\u4e3a\u786e\u5b9a\u4e8b\u5b9e\uff1b\u9700\u8981\u56de\u5230\u539f\u59cb PDF \u9875\u9762\u4eba\u5de5\u590d\u6838\u3002\n\n'
        + '\n'.join(affected)
    )



CITATION_PAGE_MARKER_PATTERN = re.compile(
    r'[\(\uff08]\s*p{1,2}\.?\s*(\d+)(?:\s*[-\u2013\u2014]\s*(\d+))?\s*[\)\uff09]|\u7b2c\s*(\d+)\s*\u9875',
    re.IGNORECASE,
)
CITATION_NUMBER_PATTERN = re.compile(r'\[(\d+)\]')
REFERENCES_SECTION_PATTERN = re.compile(r'#{1,6}\s*(references|\u53c2\u8003\u6587\u732e)', re.IGNORECASE)


def max_known_pdf_pages(key_files: List[Dict[str, Any]]) -> int:
    max_pages = 0
    for file_info in _dedupe_pdf_sources(key_files):
        if not isinstance(file_info, dict):
            continue
        quality, metadata = _source_quality_and_metadata(file_info)
        status = _parser_status(file_info, metadata)
        page_count = status.get('page_count')
        if isinstance(page_count, int):
            max_pages = max(max_pages, page_count)
    return max_pages


def build_long_document_page_requirement(key_files: List[Dict[str, Any]]) -> str:
    '''P2-6: return a Writer prompt requirement for page-level citations on long PDFs.

    Only triggers when a source's parser reports at least
    ``LONG_DOCUMENT_PAGE_THRESHOLD`` pages; otherwise short papers keep the
    existing permissive page-marker guidance.
    '''
    max_pages = max_known_pdf_pages(key_files)
    if max_pages < LONG_DOCUMENT_PAGE_THRESHOLD:
        return ''
    return (
        '\nLONG-DOCUMENT PAGE CITATIONS: this PDF is %d pages, so section-level claims '
        'must include explicit page markers such as [1] (p. 23). Use only page numbers '
        'that appear in the extracted text ([page=N] markers or page headers); never '
        'invent a page number. If the extracted text does not expose reliable page '
        'boundaries, explicitly say which pages could not be pinned down.' % max_pages
    )


def verify_writer_citations(answer: str, key_files: List[Dict[str, Any]]) -> Dict[str, Any]:
    '''Deterministically verify inline citations and page markers in an answer.

    Returns a machine-readable verdict plus human-readable issues for:
    out-of-range citation numbers, page markers beyond the parsed page count,
    citations without a References section, and answers with no citations.
    '''
    text = str(answer or '')
    citation_numbers = sorted({int(number) for number in CITATION_NUMBER_PATTERN.findall(text)})
    page_numbers = []
    for match in CITATION_PAGE_MARKER_PATTERN.finditer(text):
        start = match.group(1) or match.group(3)
        if start:
            page_numbers.append(int(start))
        end = match.group(2)
        if end:
            page_numbers.append(int(end))

    sources = _dedupe_pdf_sources(key_files)
    source_count = len(sources)
    issues: List[str] = []
    for number in citation_numbers:
        if number < 1 or number > source_count:
            issues.append(
                '\u5f15\u7528\u7f16\u53f7 [%d] \u8d85\u51fa\u53ef\u7528\u6765\u6e90\u6570\u91cf (1..%d)' % (number, source_count)
            )

    max_known_pages = max_known_pdf_pages(key_files)
    for page_number in page_numbers:
        if max_known_pages and page_number > max_known_pages:
            issues.append(
                '\u9875\u7801 (p. %d) \u8d85\u51fa\u5df2\u89e3\u6790 PDF \u7684\u6700\u5927\u9875\u6570 %d' % (page_number, max_known_pages)
            )

    if citation_numbers and not REFERENCES_SECTION_PATTERN.search(text):
        issues.append('\u6b63\u6587\u5305\u542b [n] \u5f15\u7528\uff0c\u4f46\u7f3a\u5c11 References / \u53c2\u8003\u6587\u732e \u5c0f\u8282')
    if not citation_numbers:
        issues.append('\u6b63\u6587\u6ca1\u6709\u4efb\u4f55 [n] \u5f15\u7528\uff0c\u65e0\u6cd5\u6838\u9a8c\u8bc1\u636e\u6765\u6e90')

    page_marker_notes: List[str] = []
    if max_known_pages >= LONG_DOCUMENT_PAGE_THRESHOLD and not page_numbers:
        page_marker_notes.append(
            '\u6587\u6863\u5171 %d \u9875\u4f46\u6b63\u6587\u6ca1\u6709\u9875\u7801\u6807\u8bb0\uff0c'
            '\u5f15\u7528\u7c92\u5ea6\u4e0d\u8db3\uff0c\u5efa\u8bae\u6838\u5bf9\u540e\u518d\u8865\u5145\u9875\u7801\u3002' % max_known_pages
        )
    return {
        'status': 'verified' if not issues else 'unverified',
        'citation_count': len(citation_numbers),
        'citation_numbers': citation_numbers,
        'page_markers': page_numbers,
        'source_count': source_count,
        'max_known_pages': max_known_pages,
        'issues': issues,
        'page_marker_notes': page_marker_notes,
    }


def build_citation_check_report(citation_check: Dict[str, Any]) -> str:
    '''Build a deterministic user-visible citation-check section.

    With issues, list them; without issues, emit a one-line confirmation so the
    user can see that the deterministic check actually ran (P2-7).
    '''
    if not citation_check:
        return ''
    issues = citation_check.get('issues') or []
    if issues:
        lines = ['- %s' % issue for issue in issues]
        body = (
            '## \u5f15\u7528\u6838\u9a8c\n\n'
            '\u4ee5\u4e0b\u5f15\u7528/\u9875\u7801\u95ee\u9898\u7531\u786e\u5b9a\u6027\u68c0\u67e5\u53d1\u73b0\uff0c\u8bf7\u6838\u5bf9\u540e\u518d\u91c7\u4fe1\uff1a\n\n'
            + '\n'.join(lines)
        )
    else:
        body = (
            '## \u5f15\u7528\u6838\u9a8c\n\n'
            '\u5f15\u7528\u5df2\u901a\u8fc7\u786e\u5b9a\u6027\u6838\u9a8c\uff1a'
            '\u5f15\u7528\u7f16\u53f7 %d \u4e2a\uff0c\u9875\u7801\u6807\u8bb0 %d \u4e2a\uff0c'
            '\u53ef\u7528\u6765\u6e90 %d \u4e2a\uff0c\u672a\u53d1\u73b0\u8d85\u8303\u56f4\u95ee\u9898\u3002'
            % (len(citation_check.get('citation_numbers') or []),
               len(citation_check.get('page_markers') or []),
               citation_check.get('source_count', 0))
        )
    notes = citation_check.get('page_marker_notes') or []
    if notes:
        body += '\n\n' + '\n'.join('\u63d0\u793a\uff1a%s' % note for note in notes)
    return body


def normalize_reference_heading(answer: str) -> str:
    '''P2-5: canonicalize the reference-section heading for downstream parsers.'''
    if not answer:
        return answer or ''
    return re.sub(r'(?m)^##\s*\u53c2\u8003\u6587\u732e\s*$', '## References', str(answer))


_CN_DIGITS = {
    '\u4e00': 1, '\u4e8c': 2, '\u4e09': 3, '\u56db': 4, '\u4e94': 5,
    '\u516d': 6, '\u4e03': 7, '\u516b': 8, '\u4e5d': 9,
}


def _chinese_numeral_to_int(token: str) -> int | None:
    '''Convert a Chinese section numeral (\u4e00..\u4e5d\u5341\u4e5d) to an int, or None.'''
    if not token:
        return None
    if '\u5341' not in token:
        return _CN_DIGITS.get(token)
    head, _, tail = token.partition('\u5341')
    tens = _CN_DIGITS.get(head, 1) if head else 1
    ones = _CN_DIGITS.get(tail, 0) if tail else 0
    return tens * 10 + ones


_CN_SECTION_PATTERN = re.compile(
    r'^([\u4e00\u4e8c\u4e09\u56db\u4e94\u516d\u4e03\u516b\u4e5d\u5341]+)'
    r'([\u3001\uff0e.\uff1a:]\s*|\s+)(.*)$'
)
_AR_SECTION_PATTERN = re.compile(r'^(\d+(?:\.\d+)*)([\u3001\uff0e\uff1a:]\s*)(.*)$')


def normalize_section_numbering(answer: str) -> str:
    '''P2-8: canonicalize numbered section headings to Arabic dot notation.

    ``## \u4e00\u3001\u6838\u5fc3\u65b9\u6cd5`` becomes ``## 1. \u6838\u5fc3\u65b9\u6cd5`` and ``### 2.4\u3001\u5b9e\u9a8c``
    becomes ``### 2.4 \u5b9e\u9a8c``. Unnumbered headings such as \u6458\u8981 / References /
    parser report blocks are left untouched.
    '''
    if not answer:
        return answer or ''
    text = str(answer)
    trailing_newlines = len(text) - len(text.rstrip('\n'))
    lines = []
    for line in text.splitlines():
        heading = re.match(r'^(#{1,6}\s+)(.*)$', line)
        if not heading:
            lines.append(line)
            continue
        hashes, text = heading.group(1), heading.group(2)
        cn = _CN_SECTION_PATTERN.match(text)
        if cn:
            number = _chinese_numeral_to_int(cn.group(1))
            if number is not None:
                rest = cn.group(3)
                lines.append('%s%d.%s' % (hashes, number, (' ' + rest if rest else '')))
                continue
        ar = _AR_SECTION_PATTERN.match(text)
        if ar:
            number, rest = ar.group(1), ar.group(3)
            separator = '. ' if '.' not in number else ' '
            lines.append('%s%s%s%s' % (hashes, number, separator, rest))
            continue
        lines.append(line)
    return '\n'.join(lines) + ('\n' * trailing_newlines)

NUMERIC_CLAIM_TOKEN_PATTERN = re.compile(r'\b\d[\d,\.]*(?:[%％]|[MBKmbkGg])?\b')
NUMERIC_YEAR_PATTERN = re.compile(r'^(?:19|20)\d{2}$')
NUMERIC_THOUSANDS_PATTERN = re.compile(r'^\d{1,3}(?:,\d{3})+$')


def _parser_fact_tokens(file_info: Dict[str, Any]) -> set:
    """Collect parser-provided numeric facts so they are never flagged as claims."""
    tokens = set()
    quality, metadata = _source_quality_and_metadata(file_info)
    confidence = quality.get('overall_confidence')
    if confidence is not None:
        tokens.add(str(confidence).replace('.', ''))
    status = _parser_status(file_info, metadata)
    for key in ('page_count', 'text_page_count', 'empty_page_count', 'content_length'):
        value = status.get(key)
        if value is not None:
            tokens.add(str(value))
    parser_status = metadata.get('parser_status') or {}
    for key in ('page_count', 'text_page_count', 'empty_page_count', 'content_length'):
        value = parser_status.get(key)
        if value is not None:
            tokens.add(str(value))
    structured = _structured_evidence(file_info)
    for table in (structured.get('tables') or []):
        if not isinstance(table, dict):
            continue
        row_count = table.get('row_count')
        if isinstance(row_count, int):
            tokens.add(str(row_count))
        for page in (table.get('pages') or []):
            if isinstance(page, int):
                tokens.add(str(page))
    for formula in (structured.get('formulas') or []):
        if isinstance(formula, dict) and isinstance(formula.get('page'), int):
            tokens.add(str(formula.get('page')))
    return tokens


def _extracted_text_sources(key_files: List[Dict[str, Any]]) -> List[str]:
    """Return on-disk parser extraction texts referenced by the sources."""
    texts = []
    for file_info in key_files or []:
        if not isinstance(file_info, dict):
            continue
        text_path = file_info.get('text_path')
        if not text_path:
            pdf_path = file_info.get('pdf_path')
            if pdf_path:
                candidate = Path(str(pdf_path)).with_suffix('.txt')
                if candidate.exists():
                    text_path = str(candidate)
        if not text_path:
            continue
        path = Path(text_path)
        if not path.exists():
            continue
        try:
            texts.append(path.read_text(encoding='utf-8', errors='replace'))
        except Exception:
            continue
    return texts


def _structured_table_texts(key_files: List[Dict[str, Any]]) -> List[str]:
    """Return merged cell rows from structurally reconstructed tables.

    Values that survive reconstruction but are not in the on-disk page previews
    are still legitimate parser output, so numeric verification treats them
    as a second authoritative corpus.
    """
    texts = []
    for file_info in key_files or []:
        if not isinstance(file_info, dict):
            continue
        structured = _structured_evidence(file_info)
        for table in structured.get('tables') or []:
            if not isinstance(table, dict):
                continue
            merged = table.get('merged_text') or table.get('merged_preview') or ''
            if merged:
                texts.append(str(merged))
    return texts


def verify_answer_numeric_claims(answer: str, key_files: List[Dict[str, Any]], *,
                                extracted_texts: List[str] | None = None) -> Dict[str, Any]:
    """Deterministically flag precise numeric tokens not found in extracted text.

    Parser-provided facts (confidence, page counts, content length), years,
    markdown section numbers and ordinary short numbers are excluded. A missing
    token only means it cannot be verified from the extraction; it may be a unit
    conversion, paraphrase, parser omission, or model prior knowledge.
    """
    text = str(answer or '')
    texts = extracted_texts if extracted_texts is not None else _extracted_text_sources(key_files)
    if not texts:
        return {'status': 'not_checked', 'checked_tokens': 0, 'unverified_tokens': []}
    compact_texts = [re.sub(r'\s+', '', item) for item in texts]
    compact_structured_texts = [re.sub(r'\s+', '', item) for item in _structured_table_texts(key_files)]
    fact_tokens = set()
    for file_info in (key_files or []):
        if isinstance(file_info, dict):
            fact_tokens |= _parser_fact_tokens(file_info)

    unverified = []
    seen = set()
    for match in NUMERIC_CLAIM_TOKEN_PATTERN.finditer(text):
        raw = match.group(0)
        token = raw.replace(',', '').strip()
        digits = re.sub(r'[%％MBKmbkGg]$', '', token).rstrip('.')
        if not token or token in seen:
            continue
        seen.add(token)
        if len(digits) < 3 and not re.search(r'[%％MBKmbk]$', token):
            continue
        if NUMERIC_YEAR_PATTERN.match(digits) or digits == '0':
            continue
        if re.match(r'^\d{4}\.\d{4,5}$', token.rstrip('.')):
            continue  # arXiv identifiers (also inside file paths like 2103.14030.pdf) are metadata
        if re.match(r'^10\.\d{4,9}$', token.rstrip('.')):
            continue  # DOI prefixes like 10.48550 are metadata identifiers, not claims
        if ',' in raw:
            if not NUMERIC_THOUSANDS_PATTERN.match(raw):
                continue  # list/tuple fragments such as {2,2,18,2}
            parts = [part for part in raw.split(',') if part]
            if len(parts) >= 2 and all(
                any(re.search(re.escape(part), compact) for compact in compact_texts + compact_structured_texts)
                for part in parts
            ):
                continue  # e.g. channel dims (96,192,384,768): every component verified separately
        if digits.replace('.', '') in fact_tokens:
            continue
        context = text[max(0, match.start() - 30):match.end() + 30].replace('\n', ' ')
        line_start = text.rfind('\n', 0, match.start()) + 1
        line_end = text.find('\n', match.end())
        if line_end == -1:
            line_end = len(text)
        line_text = text[line_start:line_end]
        if re.match(r'^\s*#{1,6}\s', line_text):
            continue  # section numbers inside markdown headings like "### 2.4 训练设置"
        if re.search(r'[\\/]', line_text) and re.search(r'(?i)\.(?:pdf|txt|json)\b|workspaces[\\/]', line_text):
            continue  # numeric fragments inside file paths/workspace IDs are metadata, not claims
        if any(re.search(re.escape(digits), compact) for compact in compact_texts + compact_structured_texts):
            continue
        unverified.append({'token': token, 'context': context[:90]})
        if len(unverified) >= 15:
            break

    return {
        'status': 'unverified' if unverified else 'verified',
        'checked_tokens': len(seen),
        'unverified_tokens': unverified,
    }


def build_numeric_unverified_notice(check: Dict[str, Any]) -> str:
    """Deterministic user-visible notice listing answer numbers missing from the extraction."""
    tokens = (check or {}).get('unverified_tokens') or []
    if not tokens:
        return ''
    lines = ['- %s（上下文：%s）' % (item.get('token'), (item.get('context') or '').strip()) for item in tokens]
    return (
        '## 数值复核提示（未在解析文本中找到）\n\n'
        '以下数值未能在 PDF 提取文本中直接复核，可能为解析缺失、单位换算或模型转述；'
        '在正式引用或复现前，请对照原 PDF 版面逐格核验，不要直接采信：\n\n'
        + '\n'.join(lines)
    )
