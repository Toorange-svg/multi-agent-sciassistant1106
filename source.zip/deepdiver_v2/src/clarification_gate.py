"""Generic clarification gate for ambiguous research requests."""

from __future__ import annotations

import json
import os
import re
from typing import Any, Dict, Optional

import requests

from .query_router import is_explicit_paper_request
from .model_key_pool import post_model_request


def _u(*codepoints: int) -> str:
    return "".join(chr(codepoint) for codepoint in codepoints)


_BROAD_MARKERS = (
    _u(0x53d1, 0x5c55, 0x65b9, 0x5411),  # development directions
    _u(0x6700, 0x65b0, 0x52a8, 0x5411),  # latest trends
    _u(0x53d1, 0x5c55, 0x8d8b, 0x52bf),  # development trends
    _u(0x73b0, 0x72b6),                  # current state
    _u(0x8d8b, 0x52bf),                  # trends
    "latest trends", "recent directions", "state of the art", "future directions",
)
_SCOPE_MARKERS = (
    _u(0x6bd4, 0x8f83), _u(0x8bc4, 0x6d4b), _u(0x67b6, 0x6784),
    _u(0x5e94, 0x7528), _u(0x5b9e, 0x9a8c), _u(0x65b9, 0x6cd5),
    "compare", "benchmark", "architecture", "application", "implementation",
)


def _is_multimodal_query(query: str) -> bool:
    lowered = str(query or "").lower()
    return any(marker in lowered for marker in (
        "multimodal", "multi-modal", "mllm", "vision-language", "vision language",
        _u(0x591a, 0x6a21, 0x6001), _u(0x89c6, 0x89c9, 0x8bed, 0x8a00),
        _u(0x591a, 0x6a21, 0x6001, 0x5927, 0x6a21, 0x578b),
    ))


def build_clarification_request(query: str) -> Optional[Dict[str, Any]]:
    """Return a small choice set only when ambiguity changes research scope."""
    text = str(query or "").strip()
    lowered = text.lower()
    if not text or is_explicit_paper_request(text):
        return None
    if not any(marker in lowered for marker in _BROAD_MARKERS):
        return None
    if any(marker in lowered for marker in _SCOPE_MARKERS):
        return None
    if any(marker in lowered for marker in (_u(0x7efc, 0x5408), _u(0x5168, 0x9762), "comprehensive", "all directions")):
        return None

    if _is_multimodal_query(text):
        options = [
            {"id": "architecture", "label": _u(0x6a21, 0x578b, 0x67b6, 0x6784, 0x4e0e, 0x8bad, 0x7ec3, 0x65b9, 0x6cd5)},
            {"id": "vision_language", "label": _u(0x89c6, 0x89c9, 0x8bed, 0x8a00, 0x7406, 0x89e3, 0x4e0e, 0x5bf9, 0x9f50)},
            {"id": "generation", "label": _u(0x56fe, 0x50cf, 0x3001, 0x97f3, 0x9891, 0x548c, 0x89c6, 0x9891, 0x751f, 0x6210)},
            {"id": "agents", "label": _u(0x591a, 0x6a21, 0x6001, 0x667a, 0x80fd, 0x4f53, 0x4e0e, 0x5de5, 0x5177, 0x8c03, 0x7528)},
            {"id": "comprehensive", "label": _u(0x7efc, 0x5408, 0x4ee5, 0x4e0a, 0x6240, 0x6709, 0x65b9, 0x5411)},
            {"id": "custom", "label": _u(0x81ea, 0x5b9a, 0x4e49, 0x7814, 0x7a76, 0x8303, 0x56f4)},
        ]
    else:
        options = [
            {"id": "methods", "label": _u(0x6838, 0x5fc3, 0x65b9, 0x6cd5, 0x4e0e, 0x6a21, 0x578b, 0x67b6, 0x6784)},
            {"id": "applications", "label": _u(0x5e94, 0x7528, 0x573a, 0x666f, 0x4e0e, 0x6848, 0x4f8b)},
            {"id": "evaluation", "label": _u(0x8bc4, 0x6d4b, 0x6307, 0x6807, 0x4e0e, 0x5b9e, 0x9a8c, 0x7ed3, 0x679c)},
            {"id": "engineering", "label": _u(0x5de5, 0x7a0b, 0x5b9e, 0x73b0, 0x4e0e, 0x90e8, 0x7f72)},
            {"id": "comprehensive", "label": _u(0x7efc, 0x5408, 0x4ee5, 0x4e0a, 0x6240, 0x6709, 0x65b9, 0x5411)},
            {"id": "custom", "label": _u(0x81ea, 0x5b9a, 0x4e49, 0x7814, 0x7a76, 0x8303, 0x56f4)},
        ]
    return {
        "question": _u(0x8bf7, 0x9009, 0x62e9, 0x5e0c, 0x671b, 0x91cd, 0x70b9, 0x68c0, 0x7d22, 0x7684, 0x7814, 0x7a76, 0x8303, 0x56f4, 0xff1a),
        "options": options,
        "original_query": text,
    }


def apply_clarification_choice(query: str, choice_id: str, custom_scope: str = "") -> str:
    """Attach a selected scope to the query without replacing the user text."""
    choice = str(choice_id or "").strip().lower()
    labels = {
        "architecture": "model architecture and training methods",
        "vision_language": "vision-language understanding and alignment",
        "generation": "image, audio, and video generation",
        "agents": "multimodal agents and tool use",
        "methods": "core methods and model architecture",
        "applications": "applications and case studies",
        "evaluation": "benchmarks, metrics, and experimental results",
        "engineering": "engineering implementation and deployment",
        "comprehensive": "all major directions",
    }
    scope = custom_scope.strip() or labels.get(choice)
    if not scope:
        return str(query or "")
    return f"{str(query).strip()}\n[Research scope selected: {scope}]"


def _topic_label(query: str) -> str:
    """Extract a compact topic label without requiring a language-specific tokenizer."""
    text = str(query or "").strip()
    english_terms = re.findall(r"[A-Za-z][A-Za-z0-9_-]*", text)
    if english_terms:
        return " ".join(dict.fromkeys(english_terms[:5]))
    for marker in _BROAD_MARKERS:
        text = text.replace(marker, " ")
    text = re.sub(r"[？?！!。；;，,、：:]", " ", text)
    text = " ".join(text.split()).strip()
    return text[:28] or "当前研究主题"


def _contextual_fallback_request(query: str, diagnostics: Dict[str, Any]) -> Dict[str, Any]:
    topic = _topic_label(query)
    question = _u(0x8bf7, 0x9009, 0x62e9, 0x5e0c, 0x671b, 0x91cd, 0x70b9, 0x68c0, 0x7d22, 0x7684, 0x7814, 0x7a76, 0x8303, 0x56f4, 0xff1a)
    methods = _u(0x6838, 0x5fc3, 0x65b9, 0x6cd5, 0x4e0e, 0x6a21, 0x578b, 0x67b6, 0x6784)
    applications = _u(0x5e94, 0x7528, 0x573a, 0x666f, 0x4e0e, 0x6848, 0x4f8b)
    evaluation = _u(0x8bc4, 0x6d4b, 0x6307, 0x6807, 0x4e0e, 0x5b9e, 0x9a8c, 0x8bc1, 0x636e)
    engineering = _u(0x5de5, 0x7a0b, 0x5b9e, 0x73b0, 0x4e0e, 0x90e8, 0x7f72)
    options = [
        {"id": "methods", "label": f"{topic}：{methods}", "scope": f"{topic} core methods and architecture"},
        {"id": "applications", "label": f"{topic}：{applications}", "scope": f"{topic} applications and use cases"},
        {"id": "evaluation", "label": f"{topic}：{evaluation}", "scope": f"{topic} benchmarks and experimental evidence"},
        {"id": "engineering", "label": f"{topic}：{engineering}", "scope": f"{topic} implementation and deployment"},
        {"id": "custom", "label": "自定义研究范围", "scope": ""},
    ]
    return {
        "question": f"{question}{topic}",
        "options": options,
        "original_query": str(query or ""),
        "generation_source": "contextual_fallback",
        "search_diagnostics": diagnostics,
    }


def build_dynamic_clarification_request(
    query: str,
    diagnostics: Optional[Dict[str, Any]] = None,
    config: Any = None,
) -> Optional[Dict[str, Any]]:
    """Generate topic-specific clarification options after a search gap.

    The deterministic gate decides whether clarification is relevant. This
    function asks the configured model to name the actual competing scopes
    using the user's wording and the observed search gap. A deterministic
    fallback remains available when the model endpoint is unavailable.
    """
    base = build_clarification_request(query)
    if not base:
        return None
    diagnostics = diagnostics if isinstance(diagnostics, dict) else {}
    model_config = config.get_custom_llm_config() if config else {}
    model_url = os.getenv("MODEL_REQUEST_URL") or model_config.get("url", "")
    model_token = os.getenv("MODEL_REQUEST_TOKEN") or model_config.get("token", "")
    if not model_url:
        return _contextual_fallback_request(query, diagnostics)

    headers = {"Content-Type": "application/json"}
    if model_token:
        headers["Authorization"] = f"Bearer {model_token}"
        headers["csb-token"] = model_token
    prompt = (
        "You are a clarification planner for a scientific literature assistant. "
        "The first search has already run but did not provide enough evidence. "
        "Generate one user-facing clarification question and 3 to 5 mutually distinct options. "
        "Options must be specific to the user's topic, not a generic fixed template. "
        "Return JSON only: {question: string, options: [{id: string, label: string, scope: string}]}. "
        "Do not answer the research question and do not invent paper facts.\n"
        f"User query: {query}\n"
        f"Search diagnostics: {json.dumps(diagnostics, ensure_ascii=False)[:6000]}"
    )
    try:
        response = post_model_request(
            model_url,
            headers=headers,
            json={
                "model": getattr(config, "model_name", model_config.get("model", "")),
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.1,
                "max_tokens": 700,
            },
            timeout=min(int(model_config.get("timeout", 60) or 60), 8),
        )
        response.raise_for_status()
        data = response.json()
        if isinstance(data, str):
            data = json.loads(data)
        content = ""
        if isinstance(data, dict):
            choices = data.get("choices") or []
            if choices and isinstance(choices[0], dict):
                message = choices[0].get("message") or {}
                content = str(message.get("content") or "").strip()
        content = re.sub(r"^```(?:json)?\s*|\s*```$", "", content, flags=re.IGNORECASE).strip()
        parsed = json.loads(content)
        if not isinstance(parsed, dict) or not isinstance(parsed.get("options"), list):
            raise ValueError("clarification response has no options list")
        options = []
        for index, option in enumerate(parsed["options"][:5], 1):
            if not isinstance(option, dict):
                continue
            label = str(option.get("label") or "").strip()
            scope = str(option.get("scope") or label).strip()
            if not label or not scope:
                continue
            option_id = re.sub(r"[^a-z0-9_-]+", "_", str(option.get("id") or f"scope_{index}").lower()).strip("_")
            options.append({"id": option_id or f"scope_{index}", "label": label, "scope": scope})
        if not options:
            raise ValueError("clarification response returned no usable options")
        options.append({"id": "custom", "label": "自定义研究范围", "scope": ""})
        return {
            "question": str(parsed.get("question") or base["question"]).strip(),
            "options": options,
            "original_query": str(query or ""),
            "generation_source": "model",
            "search_diagnostics": diagnostics,
        }
    except Exception:
        return _contextual_fallback_request(query, diagnostics)
