"""Small, bounded parser for the arXiv Atom API response.

The product only needs a narrow subset of Atom.  Keeping that parsing in the
standard library removes the legacy third-party parser chain and avoids
executing a source-distribution build during cloud image creation.
"""

import re
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone


ATOM_NAMESPACE = "http://www.w3.org/2005/Atom"
ARXIV_NAMESPACE = "http://arxiv.org/schemas/atom"
DEFAULT_MAX_ATOM_BYTES = 2 * 1024 * 1024
DEFAULT_MAX_ENTRIES = 200
ATOM_READ_CHUNK_BYTES = 64 * 1024
MAX_TITLE_CHARS = 1024
MAX_SUMMARY_CHARS = 32 * 1024
MAX_AUTHORS = 64
MAX_AUTHOR_NAME_CHARS = 256
MAX_CATEGORIES = 64
MAX_CATEGORY_CHARS = 64
MAX_DOI_CHARS = 1024
_ARXIV_IDENTIFIER_RE = re.compile(
    r"^(?:(?:\d{4}\.\d{4,5})|(?:[a-z][a-z-]*(?:\.[A-Za-z-]+)?/\d{7}))(?:v\d+)?$"
)


class ArxivAtomError(ValueError):
    """Stable, non-reflective parse failure safe for diagnostics."""


def read_bounded_arxiv_response(response, *, max_bytes=DEFAULT_MAX_ATOM_BYTES):
    """Read a streamed HTTP response without buffering more than ``max_bytes``."""
    headers = getattr(response, "headers", {}) or {}
    try:
        declared_length = int(headers.get("Content-Length", "0"))
    except (TypeError, ValueError):
        declared_length = 0
    if declared_length > max_bytes:
        raise ArxivAtomError("atom_document_too_large")
    iterator = getattr(response, "iter_content", None)
    if not callable(iterator):
        raw = getattr(response, "content", b"")
        if not isinstance(raw, (bytes, bytearray, memoryview)):
            raise ArxivAtomError("invalid_atom_type")
        if len(raw) > max_bytes:
            raise ArxivAtomError("atom_document_too_large")
        return bytes(raw)
    chunks = []
    size = 0
    for chunk in iterator(chunk_size=ATOM_READ_CHUNK_BYTES):
        if not chunk:
            continue
        size += len(chunk)
        if size > max_bytes:
            raise ArxivAtomError("atom_document_too_large")
        chunks.append(bytes(chunk))
    return b"".join(chunks)


def _local_name(tag):
    return str(tag).rsplit("}", 1)[-1]


def _text(parent, name, namespace=ATOM_NAMESPACE, max_chars=None):
    node = parent.find(f"{{{namespace}}}{name}")
    if node is None:
        return ""
    value = re.sub(r"\s+", " ", "".join(node.itertext())).strip()
    return value[:max_chars] if max_chars is not None else value


def canonical_arxiv_identifier(value):
    """Return a safe arXiv identifier, or an empty string for untrusted input."""
    candidate = str(value or "").strip().rstrip("/").rsplit("/", 1)[-1]
    return candidate if _ARXIV_IDENTIFIER_RE.fullmatch(candidate) else ""


def _timestamp(value):
    value = str(value or "").strip()
    try:
        parsed = datetime.fromisoformat(value.removesuffix("Z") + "+00:00" if value.endswith("Z") else value)
    except ValueError:
        return ""
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    if parsed > datetime.now(timezone.utc) + timedelta(days=1):
        return ""
    return value


def parse_arxiv_atom(content, *, max_bytes=DEFAULT_MAX_ATOM_BYTES,
                     max_entries=DEFAULT_MAX_ENTRIES):
    """Return normalized entry dictionaries from a bounded arXiv Atom feed."""
    if isinstance(content, str):
        raw = content.encode("utf-8")
    elif isinstance(content, (bytes, bytearray, memoryview)):
        raw = bytes(content)
    else:
        raise ArxivAtomError("invalid_atom_type")
    if not raw:
        raise ArxivAtomError("empty_atom_document")
    if len(raw) > max_bytes:
        raise ArxivAtomError("atom_document_too_large")
    upper = raw.upper()
    if b"<!DOCTYPE" in upper or b"<!ENTITY" in upper:
        raise ArxivAtomError("unsafe_atom_declaration")
    try:
        root = ET.fromstring(raw)
    except (ET.ParseError, ValueError) as error:
        raise ArxivAtomError("invalid_atom_xml") from error
    if _local_name(root.tag) != "feed":
        raise ArxivAtomError("invalid_atom_root")

    entry_nodes = [child for child in root if _local_name(child.tag) == "entry"]
    if len(entry_nodes) > max_entries:
        raise ArxivAtomError("too_many_atom_entries")
    entries = []
    seen_paper_ids = set()
    for entry in entry_nodes:
        identifier = _text(entry, "id")
        paper_id = canonical_arxiv_identifier(identifier)
        if not paper_id or paper_id in seen_paper_ids:
            continue
        seen_paper_ids.add(paper_id)
        landing_url = f"https://arxiv.org/abs/{paper_id}"
        pdf_url = f"https://arxiv.org/pdf/{paper_id}"
        entries.append({
            "id": landing_url,
            "paper_id": paper_id,
            "title": _text(entry, "title", max_chars=MAX_TITLE_CHARS),
            "summary": _text(entry, "summary", max_chars=MAX_SUMMARY_CHARS),
            "published": _timestamp(_text(entry, "published", max_chars=64)),
            "updated": _timestamp(_text(entry, "updated", max_chars=64)),
            "authors": [
                name for name in (
                    _text(author, "name", max_chars=MAX_AUTHOR_NAME_CHARS)
                    for author in entry.findall(f"{{{ATOM_NAMESPACE}}}author")[:MAX_AUTHORS]
                ) if name
            ],
            "links": [
                {"href": landing_url, "type": "text/html", "rel": "", "title": ""},
                {"href": pdf_url, "type": "application/pdf", "rel": "", "title": "pdf"},
            ],
            "categories": [
                str(category.attrib.get("term") or "").strip()[:MAX_CATEGORY_CHARS]
                for category in entry.findall(f"{{{ATOM_NAMESPACE}}}category")[:MAX_CATEGORIES]
                if str(category.attrib.get("term") or "").strip()
            ],
            "doi": _text(entry, "doi", ARXIV_NAMESPACE, MAX_DOI_CHARS),
        })
    return entries
