"""Public literature source adapters with per-source throttling and caching.

This module deliberately contains no answer-model or web-server code. It can be
used by the web workflow and by the standalone source validation CLI.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sqlite3
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List
from urllib.parse import quote_plus

from .arxiv_atom import ArxivAtomError, parse_arxiv_atom, read_bounded_arxiv_response

# Prefer IPv4: some networks have broken IPv6 routes (e.g. zenodo.org returns
# AAAA records that never answer), which caused 10s timeouts on every request.
# Force getaddrinfo to return IPv4 first so requests falls through to IPv4
# immediately instead of hanging on a dead v6 route.
import socket as _socket
_orig_getaddrinfo = _socket.getaddrinfo
def _ipv4_first_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    results = _orig_getaddrinfo(host, port, family, type, proto, flags)
    ipv4 = [r for r in results if r[0] == _socket.AF_INET]
    ipv6 = [r for r in results if r[0] == _socket.AF_INET6]
    return ipv4 + ipv6
_socket.getaddrinfo = _ipv4_first_getaddrinfo

import requests
from .arxiv_query import validate_arxiv_query, repair_arxiv_query

ROOT = Path(__file__).resolve().parents[2]
# Dedicated CLI acceptance can isolate cooldown/cache without touching a live
# server's source state. Existing deployments keep the original shared paths.
STATE_DB = Path(os.getenv("SCIASSISTANT_LITERATURE_STATE_PATH", str(ROOT / "logs" / "literature_source_state.sqlite3")))
CACHE_DIR = Path(os.getenv("SCIASSISTANT_LITERATURE_CACHE_DIR", str(ROOT / "logs" / "literature_source_cache")))
SOURCE_INTERVALS = {
    "arxiv": float(os.getenv("ARXIV_MIN_REQUEST_INTERVAL", "3")),
    "zenodo": float(os.getenv("ZENODO_MIN_REQUEST_INTERVAL", "1")),
    "techrxiv": float(os.getenv("TECHRXIV_MIN_REQUEST_INTERVAL", "3")),
    "hal": float(os.getenv("HAL_MIN_REQUEST_INTERVAL", "1")),
}
SOURCE_ORDER = ("arxiv", "zenodo", "techrxiv", "hal")

# Sources parked out of rotation by configuration, independent of the runtime
# disable / half-open state in the state database. TechRxiv's public search has
# sat behind a persistent WAF (HTTP 403/406) for an extended period and never
# contributed a paper, so its half-open probes only burned latency. This is a
# deliberate, reversible operator switch, not a topic-specific rule: set
# LITERATURE_DISABLED_SOURCES="" to restore every source, or a comma separated
# list to park others. A statically parked source never touches the network and
# is reported as one honest skipped/disabled event per round.
STATIC_DISABLED_SOURCES = tuple(
    name.strip().lower()
    for name in os.getenv("LITERATURE_DISABLED_SOURCES", "techrxiv").split(",")
    if name.strip()
)


def static_disabled_reason(source: str) -> str:
    """Return a non-empty note when ``source`` is parked by configuration."""
    if str(source).strip().lower() in STATIC_DISABLED_SOURCES:
        return (
            f"{source} is statically disabled in this deployment "
            "(LITERATURE_DISABLED_SOURCES); it is not queried. "
            "Set LITERATURE_DISABLED_SOURCES='' and restart to re-enable it."
        )
    return ""
MAX_RESULTS_PER_QUERY = max(1, min(int(os.getenv("LITERATURE_MAX_RESULTS_PER_QUERY", "30")), 100))
USER_AGENT = os.getenv("LITERATURE_USER_AGENT", "SciAssistant-literature-gateway/1.0")
MAX_PDF_BYTES = int(os.getenv("LITERATURE_MAX_PDF_BYTES", str(80 * 1024 * 1024)))

# Canonical per-source outcome. ``ok`` is the only status a caller may treat as
# "usable results"; every other value states why a source produced nothing, so
# a report can tell "no relevant paper" apart from "the source was unusable".
SOURCE_STATUSES = (
    "ok",                  # the source answered and returned records
    "rate_limited",        # HTTP 429 / Retry-After
    "source_unreachable",  # transport failure, timeout after retry, 5xx
    "access_blocked",      # 401/403/406/451: WAF, geo or auth refusal
    "disabled",            # taken out of rotation after repeated blocks
    "parse_error",         # the response arrived but could not be interpreted
    "deadline_skipped",    # caller budget cannot safely wait/retry
)

# Query-side outcome. Deliberately outside the source states above: the source
# is healthy but our own query was rejected, so re-sending it is pointless.
QUERY_STATUS_INVALID = "invalid_query"

# Requests per source are bounded so one slow platform cannot hold up a whole
# retrieval round. Retry policy is shared by all adapters below.
HTTP_TIMEOUT_SECONDS = float(os.getenv("LITERATURE_HTTP_TIMEOUT", "10"))
# Two retries means at most three attempts.  The default is deliberately
# shared by every adapter so a slow or rate-limited source cannot silently
# receive a different retry budget from the others.
HTTP_RETRY_COUNT = max(0, min(int(os.getenv("LITERATURE_HTTP_RETRIES", "2")), 3))
RETRY_BACKOFF_SECONDS = tuple(
    float(value) for value in os.getenv("LITERATURE_RETRY_BACKOFF", "5,10,20").split(",")
    if str(value).strip()
)

# Consecutive access blocks before a source is taken out of rotation, and the
# reason recorded with it. The counter resets on any successful response, so a
# source that recovers is not disabled by old failures.
ACCESS_BLOCK_THRESHOLD = int(os.getenv("LITERATURE_ACCESS_BLOCK_THRESHOLD", "3"))

# Half-open recovery for a disabled source. After the cooldown elapses, the
# round's real query is allowed through as the probe: a parseable response
# (even zero records) restores the source fully, a refused probe doubles the
# cooldown up to one day. This turns "disabled until an operator intervenes"
# into "one cheap attempt per cooldown window", without dedicated probe
# requests. The state lives in the source_state database, not in memory: each
# web task runs in its own process, so an in-memory flag would not exist.
HALF_OPEN_COOLDOWN_SECONDS = float(os.getenv("LITERATURE_HALF_OPEN_COOLDOWN", "900"))
HALF_OPEN_COOLDOWN_CAP = 86400.0
# Short window that stops sibling worker processes from sending a second
# probe for the same recovered slot; cleared when the outcome is recorded and
# self-expiring if a process dies mid-probe.
HALF_OPEN_PROBE_CLAIM_SECONDS = 120.0


def _utc_now_iso() -> str:
    """Current UTC time as ISO 8601 with a trailing Z (e.g. 2026-09-17T20:15:00Z)."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


class SourceParseError(ValueError):
    """The source answered, but its payload could not be interpreted.

    Distinct from a transport or access failure: the network and the endpoint
    both worked, so this is reported as ``parse_error`` rather than being
    folded into ``source_unreachable`` where it would hide a schema change.
    """


class SourceDeadlineExceeded(TimeoutError):
    """The caller budget cannot safely wait for a source slot or retry."""


def _ensure_state_schema(connection: sqlite3.Connection) -> None:
    """Create the source state table and add any columns a later version needs.

    Existing state databases predate the disable columns, so they are migrated
    in place rather than dropped: the throttle timestamps in them are still
    meaningful.
    """
    connection.execute(
        "CREATE TABLE IF NOT EXISTS source_state ("
        "source TEXT PRIMARY KEY, next_at REAL NOT NULL DEFAULT 0, "
        "cooldown_until REAL NOT NULL DEFAULT 0, failures INTEGER NOT NULL DEFAULT 0, "
        "consecutive_blocked INTEGER NOT NULL DEFAULT 0, disabled INTEGER NOT NULL DEFAULT 0, "
        "disabled_reason TEXT NOT NULL DEFAULT '', disabled_at TEXT NOT NULL DEFAULT '', "
        "half_open_failures INTEGER NOT NULL DEFAULT 0, "
        "probe_claim_until REAL NOT NULL DEFAULT 0)"
    )
    existing = {row[1] for row in connection.execute("PRAGMA table_info(source_state)")}
    for column, declaration in (
        ("consecutive_blocked", "INTEGER NOT NULL DEFAULT 0"),
        ("disabled", "INTEGER NOT NULL DEFAULT 0"),
        ("disabled_reason", "TEXT NOT NULL DEFAULT ''"),
        # ISO 8601 UTC. Stored as text so a report can show when a source left
        # rotation without needing the state database to be read by hand.
        ("disabled_at", "TEXT NOT NULL DEFAULT ''"),
        ("half_open_failures", "INTEGER NOT NULL DEFAULT 0"),
        ("probe_claim_until", "REAL NOT NULL DEFAULT 0"),
    ):
        if column not in existing:
            connection.execute(f"ALTER TABLE source_state ADD COLUMN {column} {declaration}")
    connection.commit()


def _state_connection() -> sqlite3.Connection:
    """Open the shared source-state database outside a request slot."""
    STATE_DB.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(str(STATE_DB), timeout=30)
    connection.execute("PRAGMA busy_timeout=30000")
    _ensure_state_schema(connection)
    connection.execute("INSERT OR IGNORE INTO source_state(source) VALUES (?)", ("__init__",))
    connection.execute("DELETE FROM source_state WHERE source='__init__'")
    connection.commit()
    return connection


def disabled_reason(source: str) -> str:
    """Return why a source is out of rotation, or an empty string if it is not."""
    connection = _state_connection()
    try:
        row = connection.execute(
            "SELECT disabled, disabled_reason FROM source_state WHERE source=?", (source,)
        ).fetchone()
    finally:
        connection.close()
    if row and int(row[0] or 0):
        return str(row[1] or "disabled")
    return ""


def disabled_at(source: str) -> str:
    """Return the ISO 8601 UTC time a source left rotation, or an empty string."""
    connection = _state_connection()
    try:
        row = connection.execute(
            "SELECT disabled, disabled_at FROM source_state WHERE source=?", (source,)
        ).fetchone()
    finally:
        connection.close()
    if row and int(row[0] or 0):
        return str(row[1] or "")
    return ""


def disable_source(source: str, reason: str) -> None:
    """Take a source out of rotation until it is manually re-enabled."""
    connection = _state_connection()
    try:
        connection.execute(
            "UPDATE source_state SET disabled=1, disabled_reason=?, disabled_at=? WHERE source=?",
            (str(reason or "disabled"), _utc_now_iso(), source),
        )
        connection.commit()
    finally:
        connection.close()


def enable_source(source: str) -> None:
    """Manually return a disabled source to rotation and clear its counters."""
    connection = _state_connection()
    try:
        connection.execute(
            "UPDATE source_state SET disabled=0, disabled_reason='', disabled_at='', "
            "consecutive_blocked=0, cooldown_until=0, half_open_failures=0, probe_claim_until=0 "
            "WHERE source=?",
            (source,),
        )
        connection.commit()
    finally:
        connection.close()


def _half_open_remaining_seconds(source: str, now: float | None = None) -> float:
    """Seconds until the disabled source's next half-open probe slot."""
    connection = _state_connection()
    try:
        row = connection.execute(
            "SELECT cooldown_until FROM source_state WHERE source=?", (source,)
        ).fetchone()
    finally:
        connection.close()
    now = time.time() if now is None else now
    if not row:
        return 0.0
    return max(0.0, float(row[0] or 0) - now)


def _claim_half_open_probe(source: str, now: float | None = None) -> bool:
    """Atomically reserve this process as the half-open prober.

    Returns False while the cooldown is still running or another worker holds
    the probe claim. The claim is a short lease: it is cleared when the probe
    outcome is recorded and expires on its own if a process dies mid-probe.
    """
    now = time.time() if now is None else now
    connection = _state_connection()
    try:
        cursor = connection.execute(
            "UPDATE source_state SET probe_claim_until=? "
            "WHERE source=? AND disabled=1 AND cooldown_until<=? AND probe_claim_until<=?",
            (now + HALF_OPEN_PROBE_CLAIM_SECONDS, source, now, now),
        )
        connection.commit()
        return cursor.rowcount == 1
    finally:
        connection.close()


def _recover_source(source: str) -> None:
    """Fully restore a source after a successful half-open probe."""
    connection = _state_connection()
    try:
        connection.execute(
            "UPDATE source_state SET disabled=0, disabled_reason='', disabled_at='', "
            "consecutive_blocked=0, cooldown_until=0, half_open_failures=0, probe_claim_until=0 "
            "WHERE source=?",
            (source,),
        )
        connection.commit()
    finally:
        connection.close()


def _record_half_open_failure(source: str) -> float:
    """Record a refused half-open probe; return the next cooldown in seconds.

    Probe failures deliberately bypass ``consecutive_blocked`` — the source is
    already disabled, and the doubling backoff below is what protects it. The
    first window is the base cooldown; each further refusal doubles it, capped
    at one day.
    """
    connection = _state_connection()
    try:
        row = connection.execute(
            "SELECT half_open_failures FROM source_state WHERE source=?", (source,)
        ).fetchone()
        failures = (int(row[0] or 0) + 1) if row else 1
        delay = min(HALF_OPEN_COOLDOWN_SECONDS * (2 ** failures), HALF_OPEN_COOLDOWN_CAP)
        connection.execute(
            "UPDATE source_state SET half_open_failures=?, cooldown_until=?, probe_claim_until=0 "
            "WHERE source=?",
            (failures, time.time() + delay, source),
        )
        connection.commit()
    finally:
        connection.close()
    return delay


def disabled_source_notice(source: str) -> str:
    """Report a disabled source, its half-open plan, and the manual override.

    Recovery is automatic but patient: after the cooldown the round's real
    query acts as the probe, and every refused probe doubles the wait. This
    returns the line to put in a report so a reader can tell a cooled-down
    source from a dead one and can still restore it by hand immediately.
    """
    reason = disabled_reason(source)
    if not reason:
        return ""
    remaining = _half_open_remaining_seconds(source)
    timing = (
        f"约 {int(remaining)}s 冷却后自动以本轮真实查询半开重试（失败退避翻倍，上限 86400s）"
        if remaining > 0
        else "冷却已到，下一轮将自动以本轮真实查询半开重试"
    )
    return (
        f"{source} 已停用，本轮跳过；{timing}。原因：{reason}。"
        f"如需立即手动恢复：python -c \"from deepdiver_v2.src.literature_sources "
        f"import enable_source; enable_source('{source}')\""
    )


def source_skip_reason(source: str) -> str:
    """Return why ``search_source`` would skip this round without a network request.

    Diagnostics use this to record a rotation skip as one ``skipped`` event
    instead of a misleading ``completed``+``failed`` pair. It mirrors the two
    cooldown_skip branches of ``search_source``: a disabled source whose
    half-open cooldown has not expired, or whose recovery probe is being run
    by a parallel worker, is skipped. A disabled source whose cooldown has
    expired and whose probe slot is free returns "" because that round really
    queries the source (a half-open recovery probe).
    """
    static_reason = static_disabled_reason(source)
    if static_reason:
        return static_reason
    reason = disabled_reason(source)
    if not reason:
        return ""
    connection = _state_connection()
    try:
        row = connection.execute(
            "SELECT cooldown_until, probe_claim_until FROM source_state WHERE source=?",
            (source,),
        ).fetchone()
    finally:
        connection.close()
    now = time.time()
    cooldown_remaining = max(0.0, float(row[0] or 0) - now) if row else 0.0
    probe_claimed = bool(row and float(row[1] or 0) > now)
    if cooldown_remaining <= 0 and not probe_claimed:
        return ""
    if cooldown_remaining > 0:
        note = (f"{source} 半开冷却中，本轮跳过；"
                f"约 {int(cooldown_remaining)}s 后自动以真实查询重试")
    else:
        note = f"{source} 的半开探测正由并行任务进行，本轮跳过"
    return f"{note}。停用原因：{reason}"


def record_source_block(source: str) -> int:
    """Count a consecutive access block; disable the source at the threshold."""
    connection = _state_connection()
    try:
        connection.execute(
            "UPDATE source_state SET consecutive_blocked=consecutive_blocked+1 WHERE source=?",
            (source,),
        )
        row = connection.execute(
            "SELECT consecutive_blocked FROM source_state WHERE source=?", (source,)
        ).fetchone()
        count = int(row[0]) if row else 0
        connection.commit()
    finally:
        connection.close()
    if count >= ACCESS_BLOCK_THRESHOLD:
        disable_source(
            source,
            f"{count} consecutive access blocks (HTTP 401/403/406/451); "
            "re-enable manually with enable_source()",
        )
        # The disable reason keeps its manual-recovery hint, but recovery is
        # no longer manual-only: the half-open cooldown starts here.
        connection = _state_connection()
        try:
            connection.execute(
                "UPDATE source_state SET cooldown_until=? WHERE source=?",
                (time.time() + HALF_OPEN_COOLDOWN_SECONDS, source),
            )
            connection.commit()
        finally:
            connection.close()
    return count


def record_source_success(source: str) -> None:
    """Clear the consecutive-block counter after a usable response."""
    connection = _state_connection()
    try:
        connection.execute(
            "UPDATE source_state SET consecutive_blocked=0 WHERE source=?", (source,)
        )
        connection.commit()
    finally:
        connection.close()



def _safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", str(value or ""))[:160] or "unknown"


def _normalise_title(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(value or "").lower()).strip()


def _record(source: str, paper_id: str, title: str, *, abstract: str = "", authors=None,
            year=None, venue: str = "", doi: str = "", landing_url: str = "",
            fulltext_urls=None, access: str = "unknown", raw=None) -> Dict[str, Any]:
    urls = [str(url) for url in (fulltext_urls or []) if str(url).startswith(("http://", "https://"))]
    return {
        "paper_id": str(paper_id), "source": source, "title": str(title or ""),
        "authors": authors or [], "abstract": str(abstract or ""), "year": year,
        "venue": venue, "doi": doi, "landing_url": landing_url,
        "url": landing_url, "fulltext_urls": urls, "access": access,
        "fulltext_status": "available" if urls else "metadata_only",
        "download_status": "not_attempted", "parse_status": "not_attempted",
        "raw": raw or {},
    }


@contextmanager
def _source_slot(source: str, *, deadline_monotonic: float | None = None,
                 max_wait_seconds: float | None = None):
    """Reserve a request slot across processes for one source."""
    STATE_DB.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(str(STATE_DB), timeout=30)
    try:
        connection.execute("PRAGMA busy_timeout=30000")
        _ensure_state_schema(connection)
        connection.execute("INSERT OR IGNORE INTO source_state(source) VALUES (?)", (source,))
        connection.commit()
        while True:
            now = time.time()
            row = connection.execute("SELECT next_at, cooldown_until FROM source_state WHERE source=?", (source,)).fetchone()
            wait = max(float(row[0] or 0), float(row[1] or 0)) - now
            if wait <= 0:
                next_at = now + max(0.0, SOURCE_INTERVALS.get(source, 2.0))
                connection.execute("UPDATE source_state SET next_at=? WHERE source=?", (next_at, source))
                connection.commit()
                break
            remaining = None if deadline_monotonic is None else deadline_monotonic - time.monotonic()
            allowed_wait = wait
            if remaining is not None:
                allowed_wait = min(allowed_wait, remaining)
            if max_wait_seconds is not None:
                allowed_wait = min(allowed_wait, max(0.0, float(max_wait_seconds)))
            if allowed_wait <= 0 or allowed_wait + 0.001 < wait:
                raise SourceDeadlineExceeded("source wait exceeds caller budget")
            time.sleep(min(allowed_wait, 30.0))
        yield connection
    finally:
        connection.close()


def _retry_after_seconds(response) -> float | None:
    """Parse Retry-After as seconds or an HTTP date, without trusting bad data."""
    value = str(response.headers.get("Retry-After", "")).strip()
    if not value:
        return None
    try:
        return max(0.0, min(float(value), 900.0))
    except ValueError:
        try:
            from email.utils import parsedate_to_datetime
            when = parsedate_to_datetime(value)
            if when.tzinfo is None:
                when = when.replace(tzinfo=timezone.utc)
            return max(0.0, min(when.timestamp() - time.time(), 900.0))
        except (TypeError, ValueError, OverflowError):
            return None


def _backoff_seconds(retry_index: int, retry_after: float | None = None) -> float:
    """Return the bounded delay before retry number ``retry_index`` (1-based)."""
    if retry_after is not None:
        return max(0.0, min(float(retry_after), 900.0))
    if RETRY_BACKOFF_SECONDS:
        return max(0.0, RETRY_BACKOFF_SECONDS[min(retry_index - 1, len(RETRY_BACKOFF_SECONDS) - 1)])
    return float(5 * (2 ** max(0, retry_index - 1)))


def _request(source: str, url: str, *, params=None, timeout: float | None = None, stream: bool = False,
             deadline_monotonic: float | None = None, max_attempts: int | None = None,
             max_wait_seconds: float | None = None):
    """Perform a bounded, throttled request with shared retry semantics.

    Each attempt reserves its own per-source slot.  Retryable HTTP statuses
    (429 and 5xx) and transient transport failures use 5/10/20-second
    exponential backoff by default; a valid ``Retry-After`` always wins.
    Metadata is attached to the response for ``search_source`` diagnostics.
    """
    effective_timeout = HTTP_TIMEOUT_SECONDS if timeout is None else timeout
    attempts = 1 + max(0, HTTP_RETRY_COUNT)
    if max_attempts is not None:
        attempts = max(1, min(attempts, int(max_attempts)))
    last_error: Exception | None = None
    retry_after_seen = None
    for attempt in range(1, attempts + 1):
        try:
            remaining = None if deadline_monotonic is None else deadline_monotonic - time.monotonic()
            if remaining is not None and remaining <= 0:
                raise SourceDeadlineExceeded("source request deadline exhausted")
            attempt_timeout = effective_timeout if remaining is None else min(effective_timeout, max(0.1, remaining))
            slot = (_source_slot(source)
                    if deadline_monotonic is None and max_wait_seconds is None
                    else _source_slot(source, deadline_monotonic=deadline_monotonic,
                                      max_wait_seconds=max_wait_seconds))
            with slot as connection:
                response = requests.get(
                    url, params=params,
                    headers={"User-Agent": USER_AGENT, "Accept": "application/json, text/html, application/pdf"},
                    timeout=attempt_timeout, stream=stream,
                    allow_redirects=source != "arxiv",
                )
                if source == "arxiv" and 300 <= response.status_code < 400:
                    raise requests.HTTPError("arXiv redirect refused", response=response)
                retryable_status = response.status_code == 429 or response.status_code >= 500
                if response.status_code == 429:
                    retry_after_seen = _retry_after_seconds(response)
                    delay = _backoff_seconds(attempt, retry_after_seen)
                    connection.execute("UPDATE source_state SET cooldown_until=?, failures=failures+1 WHERE source=?", (time.time() + delay, source))
                    connection.commit()
                elif response.status_code >= 500:
                    connection.execute("UPDATE source_state SET failures=failures+1 WHERE source=?", (source,))
                    connection.commit()
                    delay = _backoff_seconds(attempt)
                else:
                    delay = 0.0
                if retryable_status and attempt < attempts:
                    # 429 is persisted in cooldown_until and the next slot
                    # waits on that shared timestamp; sleeping here too would
                    # apply Retry-After twice.  5xx has no shared cooldown.
                    if response.status_code != 429:
                        remaining = None if deadline_monotonic is None else deadline_monotonic - time.monotonic()
                        allowed = delay if remaining is None else min(delay, remaining)
                        if max_wait_seconds is not None:
                            allowed = min(allowed, max(0.0, float(max_wait_seconds)))
                        if allowed <= 0 or allowed + 0.001 < delay:
                            raise SourceDeadlineExceeded("source retry wait exceeds caller budget")
                        time.sleep(allowed)
                    continue
                try:
                    response.raise_for_status()
                except requests.HTTPError as exc:
                    exc._sci_attempts = attempt
                    exc._sci_retry_after = retry_after_seen
                    raise
                if response.status_code < 400:
                    record_source_success(source)
                response._sci_attempts = attempt
                response._sci_retry_after = retry_after_seen
                return response
        except (requests.Timeout, requests.ConnectionError) as exc:
            last_error = exc
            exc._sci_attempts = attempt
            if attempt < attempts:
                delay = _backoff_seconds(attempt)
                remaining = None if deadline_monotonic is None else deadline_monotonic - time.monotonic()
                allowed = delay if remaining is None else min(delay, remaining)
                if max_wait_seconds is not None:
                    allowed = min(allowed, max(0.0, float(max_wait_seconds)))
                if allowed <= 0 or allowed + 0.001 < delay:
                    raise SourceDeadlineExceeded("source retry wait exceeds caller budget")
                time.sleep(allowed)
                continue
            raise
    if last_error is not None:
        raise last_error
    raise requests.RequestException(f"{source} request produced no response")


def _classify_http_status(status_code: int | None) -> str:
    """Map an HTTP status onto the canonical per-source status."""
    if status_code is None:
        return "source_unreachable"
    if status_code == 429:
        return "rate_limited"
    if status_code in {401, 403, 406, 451}:
        return "access_blocked"
    if status_code >= 500:
        return "source_unreachable"
    # Any other 4xx means this endpoint refused our request shape; the exact
    # code is preserved in the report's http_status field.
    return "access_blocked"


def _plain_query_terms(query: str) -> str:
    """Reduce a query to words a free-text or field endpoint can accept.

    An arXiv expression (``(ti:"x" OR abs:"y") AND all:z``) is meaningless to
    HAL and Zenodo and invalid inside a Solr field clause. Only the quoted
    phrases and bare words survive; operators and field prefixes do not.
    """
    terms: List[str] = []
    for quoted, bare in re.findall(r'"([^"]+)"|([A-Za-z][A-Za-z0-9+.-]*)', str(query or "")):
        term = (quoted or bare).strip()
        if not term or term.lower() in {"all", "ti", "abs", "and", "or", "not", "andnot"}:
            continue
        if term.lower() not in {item.lower() for item in terms}:
            terms.append(term)
    return " ".join(terms)


def _zenodo(query: str, limit: int) -> List[Dict[str, Any]]:
    response = _request("zenodo", "https://zenodo.org/api/records", params={"q": query, "size": limit, "sort": "bestmatch"})
    try:
        hits = response.json().get("hits", {}).get("hits", [])
    except ValueError as exc:
        raise SourceParseError(f"Zenodo returned a non-JSON body: {exc}") from exc
    if not isinstance(hits, list):
        raise SourceParseError("Zenodo response has no hits list")
    output = []
    for item in hits:
        meta = item.get("metadata") or {}
        resource_type = str((meta.get("resource_type") or {}).get("type") or "").lower()
        # Zenodo indexes software, datasets and models alongside papers. Keep
        # only publication-like records for literature retrieval; the raw
        # response remains available in the validator for audit purposes.
        if resource_type not in {"publication", ""}:
            continue
        files = item.get("files") or []
        pdfs = []
        for file_info in files:
            key = str(file_info.get("key", ""))
            if not key.lower().endswith(".pdf"):
                continue
            api_url = file_info.get("links", {}).get("self")
            if api_url:
                pdfs.append(api_url)
            # The record UI file route is a useful fallback when the API
            # content gateway returns a transient 502/504.
            pdfs.append(f"https://zenodo.org/records/{item.get('id')}/files/{quote_plus(key)}?download=1")
        access = str(meta.get("access_right") or "unknown")
        if access != "open":
            pdfs = []
        output.append(_record("zenodo", item.get("id"), meta.get("title") or item.get("title"), abstract=meta.get("description", ""), authors=[x.get("name", "") for x in meta.get("creators", [])], year=str(meta.get("publication_date", ""))[:4] or None, venue=meta.get("publisher", ""), doi=item.get("doi", ""), landing_url=item.get("links", {}).get("self_html", ""), fulltext_urls=pdfs, access=access, raw=item))
    return output


class ArxivQueryError(ValueError):
    pass


def _arxiv(query: str, limit: int, *, request_options: Mapping[str, Any] | None = None) -> List[Dict[str, Any]]:
    search_query = str(query or "").strip()
    if not re.search(r"\b(?:ti|abs)\s*:", search_query, re.I):
        words = re.findall(r"[A-Za-z][A-Za-z0-9+.-]*", search_query)
        words = [w for w in words if len(w) >= 2 and w.lower() not in {"the", "and", "for", "with", "from", "this", "that", "what", "when", "where", "which", "how", "why"}]
        if words:
            search_query = " OR ".join(f'all:"{w}"' for w in words[:10])
        else:
            search_query = f'all:"{search_query.replace(chr(34), "")}"'
    valid, reason = validate_arxiv_query(search_query)
    if not valid:
        repaired = repair_arxiv_query(search_query)
        if repaired and validate_arxiv_query(repaired)[0]:
            search_query = repaired
        else:
            raise ArxivQueryError(f"invalid arXiv query ({reason})")
    response = _request("arxiv", "https://export.arxiv.org/api/query", params={"search_query": search_query, "start": 0, "max_results": limit, "sortBy": "relevance", "sortOrder": "descending"}, stream=True, **dict(request_options or {}))
    try:
        entries = parse_arxiv_atom(read_bounded_arxiv_response(response))
    except ArxivAtomError as exc:
        raise SourceParseError("arXiv returned unparseable Atom") from exc
    finally:
        close = getattr(response, "close", None)
        if callable(close):
            close()
    output = []
    for entry in entries:
        ident = entry["paper_id"]
        title = entry["title"]
        abstract = entry["summary"]
        authors = entry["authors"]
        landing = f"https://arxiv.org/abs/{ident}"
        record = _record("arxiv", ident, title, abstract=abstract, authors=authors,
                              year=entry["published"][:4] or None, doi=entry["doi"],
                              landing_url=landing,
                              fulltext_urls=[f"https://arxiv.org/pdf/{ident}.pdf"],
                              access="open", raw={})
        record.update(published_at=entry["published"], updated_at=entry["updated"])
        output.append(record)
    return output


def _hal(query: str, limit: int) -> List[Dict[str, Any]]:
    # HAL is Solr-backed, so field-scoped clauses are supported. Measured on
    # 2026-09-17 with q="world models": free text matched 12617 records, while
    # title_t+abstract_t matched 9435 and title_t alone 87. The gate only ever
    # scores a candidate's title and abstract, so restricting the search to
    # those fields aligns recall with what can actually be judged and drops
    # body-only matches that could never be accepted. An unknown field returns
    # zero hits silently rather than erroring, so the field names used here are
    # the ones actually verified against the live endpoint.
    terms = _plain_query_terms(query)
    # HAL is Solr-backed and ANDs bare terms inside a field clause by default:
    # a free-text adapter query such as "LoRA QLoRA core differences" silently
    # returns zero hits because a title rarely contains every word. Join the
    # terms with OR so recall reaches the same papers a free-text endpoint
    # would; the relevance gate and score threshold filter the noise.
    if terms:
        clause = " OR ".join(str(terms).split())
        scoped = f"title_t:({clause}) OR abstract_t:({clause})"
    else:
        scoped = str(query or "")
    params = {"q": scoped, "wt": "json", "rows": limit, "fl": "docid,title_s,abstract_s,authFullName_s,producedDateY_i,doiId_s,uri_s,docType_s,fileMain_s"}
    response = _request("hal", "https://api.archives-ouvertes.fr/search/", params=params)
    try:
        docs = response.json().get("response", {}).get("docs", [])
    except ValueError as exc:
        raise SourceParseError(f"HAL returned a non-JSON body: {exc}") from exc
    if not isinstance(docs, list):
        raise SourceParseError("HAL response has no docs list")
    output = []
    for item in docs:
        title = (item.get("title_s") or [""])[0] if isinstance(item.get("title_s"), list) else item.get("title_s", "")
        abstract = " ".join(item.get("abstract_s") or [])
        authors = item.get("authFullName_s") or []
        pdf = item.get("fileMain_s") or ""
        output.append(_record("hal", item.get("docid"), title, abstract=abstract, authors=authors, year=item.get("producedDateY_i"), doi=(item.get("doiId_s") or [""])[0] if isinstance(item.get("doiId_s"), list) else item.get("doiId_s", ""), landing_url=item.get("uri_s", ""), fulltext_urls=[pdf] if pdf.startswith("http") else [], access="open" if pdf else "unknown", raw=item))
    return output


def _techrxiv(query: str, limit: int) -> List[Dict[str, Any]]:
    """Use the public TechRxiv search page; no login or protected endpoint."""
    # The bare host is intermittently unroutable from VPN/proxy networks,
    # while the canonical www host reaches TechRxiv's Cloudflare edge. Try
    # the canonical host first and expose access blocks distinctly.
    response = None
    errors = []
    for url in ("https://www.techrxiv.org/search", "https://techrxiv.org/search"):
        try:
            response = _request("techrxiv", url, params={"q": _plain_query_terms(query) or query})
            break
        except requests.HTTPError as exc:
            status = exc.response.status_code if exc.response is not None else None
            if status in {401, 403, 406, 451, 429}:
                # A WAF refusal is a property of the source, not of this query.
                # Let it propagate: ``search_source`` classifies it, keeps the
                # HTTP code in the report, and counts the consecutive block.
                # Retrying the alternate host would only add a timeout.
                raise
            errors.append(str(exc))
        except requests.RequestException as exc:
            errors.append(str(exc))
    if response is None:
        raise requests.RequestException("; ".join(errors) or "TechRxiv endpoints unavailable")
    html = response.text
    output = []
    for match in re.finditer(r'href=["\']([^"\']*(?:article|paper)[^"\']*)["\'][^>]*>(.*?)</a>', html, re.I | re.S):
        href, title = match.groups()
        title = re.sub(r"<[^>]+>", " ", title)
        title = re.sub(r"\s+", " ", title).strip()
        if not title:
            continue
        if href.startswith("/"):
            href = "https://techrxiv.org" + href
        output.append(_record("techrxiv", href.rsplit("/", 1)[-1], title, landing_url=href, raw={"html_match": True}))
        if len(output) >= limit:
            break
    return output


def search_source(source: str, query: str, limit: int = MAX_RESULTS_PER_QUERY, *,
                  request_deadline_monotonic: float | None = None,
                  request_max_attempts: int | None = None,
                  request_max_wait_seconds: float | None = None) -> Dict[str, Any]:
    """Query one source, always returning a canonical status and timings.

    Never raises: one unusable source must not stop the other sources, so every
    failure is reported as a status on the result instead.
    """
    started = time.monotonic()
    limit = max(1, min(int(limit or MAX_RESULTS_PER_QUERY), MAX_RESULTS_PER_QUERY))
    retry_count = 0
    # Whether ``retry_count`` is a measured value. Transport failures bubble out
    # of _request without their attempt count, so those reports carry the
    # configured retry budget as a lower bound instead of a measurement.
    retry_count_is_exact = True

    def report(status: str, **extra) -> Dict[str, Any]:
        payload = {
            "source": source,
            "status": status,
            "elapsed_ms": round((time.monotonic() - started) * 1000),
            "retry_count": retry_count,
            "retry_count_is_exact": retry_count_is_exact,
            "error": None,
            "disabled_reason": None,
            "disabled_at": None,
            "papers": [],
            "max_results": limit,
            "sort_by": "relevance",
            "dedupe_by": "arxiv_id" if source == "arxiv" else "doi_or_title",
        }
        payload.update(extra)
        return payload

    # A source taken out of rotation is skipped without any network request —
    # unless its half-open cooldown has expired, in which case this round's
    # real query doubles as the recovery probe. The result then says which of
    # the three outcomes happened: cooldown_skip, probe_failed, recovered.
    static_reason = static_disabled_reason(source)
    if static_reason:
        # Configuration-parked source: never touch the network and never run a
        # half-open probe; report a stable disabled outcome.
        return report("disabled", http_status=None, error=static_reason,
                      disabled_reason=static_reason, half_open="static_disabled")
    reason = disabled_reason(source)
    half_open_probe = False
    if reason:
        now = time.time()
        if not _claim_half_open_probe(source, now):
            remaining = _half_open_remaining_seconds(source, now)
            if remaining > 0:
                skip_note = (f"{source} 半开冷却中，本轮跳过；"
                             f"约 {int(remaining)}s 后自动以真实查询重试")
            else:
                skip_note = f"{source} 的半开探测正由并行任务进行，本轮跳过"
            failure_status = "access_blocked" if "access block" in reason.lower() or "http 403" in reason.lower() else None
            return report("disabled", http_status=None,
                          error=f"{skip_note}。停用原因：{reason}",
                          disabled_reason=reason, disabled_at=disabled_at(source) or None,
                          failure_status=failure_status,
                          half_open="cooldown_skip",
                          half_open_retry_in_seconds=int(remaining))
        half_open_probe = True

    try:
        if source == "arxiv":
            request_options = {
                "deadline_monotonic": request_deadline_monotonic,
                "max_attempts": request_max_attempts,
                "max_wait_seconds": request_max_wait_seconds,
            }
            request_options = {key: value for key, value in request_options.items() if value is not None}
            papers = _arxiv(query, limit, request_options=request_options) if request_options else _arxiv(query, limit)
        elif source == "zenodo": papers = _zenodo(query, limit)
        elif source == "hal": papers = _hal(query, limit)
        elif source == "techrxiv": papers = _techrxiv(query, limit)
        else: return report("access_blocked", error=f"unknown source {source!r}")
        result = report("ok", http_status=200, papers=papers)
    except SourceDeadlineExceeded:
        result = report("deadline_skipped", http_status=None, error="source request skipped by workflow deadline")
    except requests.HTTPError as exc:
        status_code = exc.response.status_code if exc.response is not None else None
        status = _classify_http_status(status_code)
        retry_count = max(0, int(getattr(exc, "_sci_attempts", 1)) - 1)
        retry_after = getattr(exc, "_sci_retry_after", None)
        # A refused probe must not feed the consecutive-block counter: the
        # source is already disabled and the half-open backoff protects it.
        if status == "access_blocked" and not half_open_probe:
            record_source_block(source)
            if source == "techrxiv" and status_code in {403, 406}:
                # TechRxiv's public search is currently behind a persistent
                # WAF in many VPN paths. Remove it immediately so one 403
                # cannot delay otherwise healthy sources; half-open recovery
                # will retry the real query after the normal cooldown.
                disable_source(source, f"TechRxiv HTTP {status_code}")
                connection = _state_connection()
                try:
                    connection.execute(
                        "UPDATE source_state SET cooldown_until=? WHERE source=?",
                        (time.time() + HALF_OPEN_COOLDOWN_SECONDS, source),
                    )
                    connection.commit()
                finally:
                    connection.close()
        result = report(status, http_status=status_code, error=str(exc),
                        retry_after=retry_after)
    except requests.RequestException as exc:
        retry_count = max(0, int(getattr(exc, "_sci_attempts", HTTP_RETRY_COUNT + 1)) - 1)
        result = report("source_unreachable", http_status=None, error=str(exc))
    except ArxivQueryError as exc:
        result = report(QUERY_STATUS_INVALID, http_status=None, error=str(exc))
    except SourceParseError as exc:
        # The endpoint answered but the payload did not match its documented
        # shape. Reported separately from ``source_unreachable`` so a schema
        # change is visible instead of looking like a network problem.
        result = report("parse_error", http_status=None, error=str(exc))
    except RuntimeError as exc:
        # Raised by the TechRxiv adapter, which records its own block count.
        result = report("access_blocked", http_status=None, error=str(exc),
                        disabled_reason=disabled_reason(source))
    except Exception as exc:  # noqa: BLE001 - one source must not stop the rest
        retry_count = HTTP_RETRY_COUNT
        retry_count_is_exact = False
        result = report("source_unreachable", http_status=None,
                        error=f"{type(exc).__name__}: {exc}")

    if not half_open_probe:
        return result
    if result["status"] == "ok":
        # A parseable response — including zero records — proves the source
        # answers again; restore it fully for later rounds.
        _recover_source(source)
        result["half_open"] = "recovered"
        return result
    delay = _record_half_open_failure(source)
    result["half_open"] = "probe_failed"
    result["half_open_retry_in_seconds"] = int(delay)
    result["error"] = (f"半开探测仍被拒（{result['status']}），"
                       f"{int(delay)}s 后自动重试：{result['error']}")
    result["disabled_reason"] = disabled_reason(source)
    return result


def download_pdf(paper: Dict[str, Any], output_dir: Path, timeout: float = 45.0) -> Dict[str, Any]:
    urls = paper.get("fulltext_urls") or []
    result = dict(paper)
    if not urls:
        result["download_status"] = "not_available"
        result["fulltext_status"] = "metadata_only"
        return result
    target_dir = output_dir / f"{_safe_name(paper.get('source'))}_{_safe_name(paper.get('paper_id'))}"
    target_dir.mkdir(parents=True, exist_ok=True)
    target = target_dir / "paper.pdf"
    last_error = None
    for url in urls:
        for attempt in range(1, 3):
            try:
                response = _request(paper["source"], url, timeout=timeout, stream=True)
                content = response.content
                if len(content) > MAX_PDF_BYTES or not content.startswith(b"%PDF-"):
                    raise ValueError("response is not a public PDF or exceeds size limit")
                target.write_bytes(content)
                result.update({"download_status": "downloaded", "fulltext_status": "available", "pdf_path": str(target), "pdf_bytes": len(content), "sha256": hashlib.sha256(content).hexdigest()})
                return result
            except requests.HTTPError as exc:
                last_error = str(exc)
                status = exc.response.status_code if exc.response is not None else 0
                if status not in {502, 503, 504} or attempt == 2:
                    break
                time.sleep(float(attempt))
            except (requests.Timeout, requests.ConnectionError) as exc:
                last_error = str(exc)
                if attempt < 2:
                    time.sleep(float(attempt) * 2)
                    continue
                break
            except Exception as exc:
                last_error = str(exc)
                break
    result.update({"download_status": "failed", "fulltext_status": "failed", "download_error": last_error})
    return result


# Source preference when several records describe the same work. Lower wins,
# so an arXiv copy replaces a HAL or Zenodo copy of the same paper.
SOURCE_PRIORITY = {"arxiv": 0, "hal": 1, "zenodo": 2, "techrxiv": 3, "pubmed": 4}

# Readable prefixes for source attribution in an answer.
SOURCE_LABELS = {
    "arxiv": "arXiv", "hal": "HAL", "zenodo": "Zenodo",
    "techrxiv": "TechRxiv", "pubmed": "PubMed",
}


def citation_label(paper: Dict[str, Any]) -> str:
    """Build a ``[Source:id]`` attribution marker for one record."""
    source = str(paper.get("source") or "").strip().lower()
    paper_id = str(paper.get("paper_id") or "").strip()
    if not paper_id:
        return ""
    return f"[{SOURCE_LABELS.get(source, source or 'source')}:{paper_id}]"


def _arxiv_base_id(paper: Dict[str, Any]) -> str:
    """Return a bare arXiv identifier, or an empty string.

    A numeric ``paper_id`` counts as an arXiv id only when the record comes from
    arXiv or the id has the arXiv shape; otherwise HAL's and Zenodo's local
    numeric ids would collapse unrelated records into one.
    """
    paper_id = str(paper.get("paper_id") or "").strip().lower()
    if not paper_id:
        return ""
    base = re.split(r"v\d+$", paper_id)[0]
    if str(paper.get("source") or "").lower() == "arxiv" or re.fullmatch(r"\d{4}\.\d{4,5}", base):
        return base
    return ""


def _first_author_key(paper: Dict[str, Any]) -> str:
    authors = paper.get("authors") or []
    if isinstance(authors, str):
        authors = [authors]
    for author in authors:
        name = re.sub(r"[^a-z0-9]+", " ", str(author or "").lower()).strip()
        if name:
            return name
    return ""


def _canonical_url(paper: Dict[str, Any]) -> str:
    url = str(paper.get("landing_url") or paper.get("url") or "").strip().lower()
    if not url:
        return ""
    return re.sub(r"^https?://", "", url).rstrip("/")


def _identity_keys(paper: Dict[str, Any]) -> List[str]:
    """Identity keys in the required priority order: DOI, arXiv id, title+author, URL.

    Two records are the same work if they share *any* key, so an arXiv record
    and a HAL copy that only agree on the title still collapse into one entry.
    """
    keys: List[str] = []
    doi = str(paper.get("doi") or "").strip().lower()
    if doi:
        keys.append(f"doi:{doi}")
    arxiv_id = _arxiv_base_id(paper)
    if arxiv_id:
        keys.append(f"arxiv:{arxiv_id}")
    title = _normalise_title(paper.get("title", ""))
    if title:
        keys.append(f"title:{title}|{_first_author_key(paper)}")
    url = _canonical_url(paper)
    if url:
        keys.append(f"url:{url}")
    return keys


def _record_rank(paper: Dict[str, Any]) -> tuple:
    """Rank records inside one identity group; the lowest value is kept."""
    source = str(paper.get("source") or "").lower()
    version_match = re.search(r"v(\d+)$", str(paper.get("paper_id") or "").strip().lower())
    version = int(version_match.group(1)) if version_match else 0
    try:
        year = int(str(paper.get("year") or "")[:4] or 0)
    except ValueError:
        year = 0
    return (
        SOURCE_PRIORITY.get(source, 99),
        -version,
        -year,
        0 if paper.get("fulltext_urls") else 1,
    )


def deduplicate(papers: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Collapse records describing the same work, keeping the best copy.

    Grouping uses DOI, then arXiv id, then normalised title plus first author,
    then URL; records are linked when they share any of these. Within a group
    the preferred source wins (arXiv > HAL > Zenodo), then the newest version
    and year. Complementary fields that only a discarded copy carries, such as
    a DOI or a full-text link, are merged into the survivor so merging never
    loses usable metadata.
    """
    records = [paper for paper in papers if isinstance(paper, dict)]
    parent = list(range(len(records)))

    def find(index: int) -> int:
        while parent[index] != index:
            parent[index] = parent[parent[index]]
            index = parent[index]
        return index

    def union(left: int, right: int) -> None:
        root_left, root_right = find(left), find(right)
        if root_left != root_right:
            parent[max(root_left, root_right)] = min(root_left, root_right)

    key_owner: Dict[str, int] = {}
    for index, paper in enumerate(records):
        for key in _identity_keys(paper):
            if key in key_owner:
                union(index, key_owner[key])
            else:
                key_owner[key] = index

    groups: Dict[int, List[int]] = {}
    for index in range(len(records)):
        groups.setdefault(find(index), []).append(index)

    output: List[Dict[str, Any]] = []
    for members in groups.values():
        candidates = [records[index] for index in members]
        winner = min(candidates, key=_record_rank)
        merged = dict(winner)
        for other in candidates:
            if other is winner:
                continue
            for field in ("doi", "abstract", "venue", "landing_url", "url"):
                if not merged.get(field) and other.get(field):
                    merged[field] = other[field]
            if not merged.get("authors") and other.get("authors"):
                merged["authors"] = other["authors"]
            if not merged.get("fulltext_urls") and other.get("fulltext_urls"):
                merged["fulltext_urls"] = other["fulltext_urls"]
                merged["fulltext_status"] = other.get(
                    "fulltext_status", merged.get("fulltext_status")
                )
        merged["duplicate_sources"] = sorted({
            str(other.get("source") or "")
            for other in candidates
            if other is not winner and other.get("source")
        })
        output.append(merged)
    return output


# Terms that mark a record as usable evidence rather than a passing mention.
RERANK_EVIDENCE_TERMS = (
    "limitation", "drawback", "shortcoming", "weakness", "survey", "analysis",
)
RERANK_EVIDENCE_BONUS = float(os.getenv("LITERATURE_RERANK_EVIDENCE_BONUS", "0.10"))
RERANK_WEAK_MATCH_PENALTY = float(os.getenv("LITERATURE_RERANK_WEAK_MATCH_PENALTY", "0.08"))
RERANK_CATEGORY_PENALTY = float(os.getenv("LITERATURE_RERANK_CATEGORY_PENALTY", "0.12"))

# Words that signal a question asks about a relationship, not merely a name.
_RERANK_RELATION_TERMS = (
    "vs", "versus", "differ", "difference", "compare", "comparison", "limitation",
    "advantage", "disadvantage", "mechanism", "how", "why", "区别", "差异", "对比", "比较",
)

# Category tokens the user wrote themselves (``cs.CL``, ``quant-ph``). Only
# explicit mentions are honoured: mapping a research field onto a category
# taxonomy would be a topic mapping, which the retrieval rules forbid.
_CATEGORY_TOKEN = re.compile(
    r"\b(?:cs|math|stat|eess|econ|q-fin|q-bio|physics|astro-ph|cond-mat|nlin|quant-ph)"
    r"(?:\.[A-Za-z-]+)?\b",
    re.I,
)


def _question_category_tokens(query: str) -> List[str]:
    return list(dict.fromkeys(
        match.lower() for match in _CATEGORY_TOKEN.findall(str(query or ""))
    ))


def rerank_papers(
    query: str,
    papers: Iterable[Dict[str, Any]],
    *,
    concepts: Iterable[str] = (),
) -> tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """Reorder candidates by evidence usefulness.

    Ordering only. Every candidate keeps the gate's ``accepted`` verdict, so a
    rerank can never promote a rejected paper or demote an accepted one out of
    the result set; it only decides which accepted papers are read first.
    """
    query_lower = str(query or "").lower()
    category_tokens = _question_category_tokens(query)
    relation_present = any(term in query_lower for term in _RERANK_RELATION_TERMS)
    entity_terms = [str(item).lower() for item in (concepts or []) if str(item).strip()]

    ranked: List[Dict[str, Any]] = []
    for paper in papers:
        if not isinstance(paper, dict):
            continue
        base = float((paper.get("relevance") or {}).get("score") or 0.0)
        title = str(paper.get("title") or "").lower()
        abstract = str(paper.get("abstract") or "").lower()
        haystack = f"{title} {abstract}"
        adjustments: Dict[str, float] = {}

        evidence_hits = [term for term in RERANK_EVIDENCE_TERMS if term in haystack]
        if evidence_hits:
            adjustments["evidence_terms"] = RERANK_EVIDENCE_BONUS

        # A single incidental mention of a topic word, in a question that asks
        # about no relationship, is weak evidence.
        if entity_terms and not relation_present:
            counts = [abstract.count(term) for term in entity_terms]
            if counts and max(counts) <= 1:
                adjustments["weak_single_mention"] = -RERANK_WEAK_MATCH_PENALTY

        # Only when the user named a category themselves.
        if category_tokens:
            declared = " ".join(str(item) for item in (paper.get("categories") or [])).lower()
            if declared and not any(token in declared for token in category_tokens):
                adjustments["category_mismatch"] = -RERANK_CATEGORY_PENALTY

        entry = dict(paper)
        entry["rerank"] = {
            "gate_score": round(base, 4),
            "adjustments": adjustments,
            "rerank_score": round(max(0.0, min(1.0, base + sum(adjustments.values()))), 4),
        }
        ranked.append(entry)

    # Stable sort keeps the gate's own order for equal scores.
    ranked.sort(key=lambda item: item["rerank"]["rerank_score"], reverse=True)
    diagnostics = {
        "order": [str(item.get("paper_id") or "") for item in ranked],
        "category_tokens_from_question": category_tokens,
        "relation_word_present": relation_present,
    }
    return ranked, diagnostics


INSUFFICIENT_EVIDENCE_MIN = int(os.getenv("LITERATURE_MIN_EVIDENCE_PAPERS", "2"))
INSUFFICIENT_EVIDENCE_NOTICE = "检索到的论文不足以回答该问题。"


def assess_evidence_sufficiency(
    papers: Iterable[Dict[str, Any]],
    *,
    minimum: int | None = None,
) -> Dict[str, Any]:
    """Report whether enough accepted papers exist to answer the question."""
    required = INSUFFICIENT_EVIDENCE_MIN if minimum is None else int(minimum)
    count = len([paper for paper in papers if isinstance(paper, dict)])
    sufficient = count >= required
    return {
        "status": "sufficient" if sufficient else "insufficient_evidence",
        "paper_count": count,
        "minimum_required": required,
        "notice": "" if sufficient else INSUFFICIENT_EVIDENCE_NOTICE,
    }
