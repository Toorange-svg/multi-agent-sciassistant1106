"""Bounded arXiv PDF downloads with atomic cache publication and local file locks."""
from __future__ import annotations

import logging
import math
import os
import re
import tempfile
import time
from contextlib import contextmanager, nullcontext
from pathlib import Path
from typing import Callable

import requests


LOGGER = logging.getLogger(__name__)
PAPER_ID = re.compile(r"(?:\d{4}\.\d{4,5}|[A-Za-z][A-Za-z0-9.-]*/\d{7})(?:v[1-9]\d*)?\Z")


def is_complete_pdf(path: Path) -> bool:
    """Cheap completeness guard; full parser validation remains the parser's job."""
    try:
        with path.open("rb") as stream:
            if stream.read(5) != b"%PDF-":
                return False
            stream.seek(0, os.SEEK_END)
            size = stream.tell()
            stream.seek(max(0, size - 8192))
            return b"%%EOF" in stream.read()
    except OSError:
        return False


def _remaining(deadline: float) -> float:
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise TimeoutError("arXiv PDF download time budget exhausted")
    return remaining


def _sleep(seconds: float, deadline: float) -> None:
    time.sleep(min(max(0.0, seconds), _remaining(deadline)))
    _remaining(deadline)


def _record_cooldown(callback: Callable, *args) -> None:
    try:
        callback(*args)
    except Exception as exc:
        LOGGER.warning("arXiv cooldown update failed (%s)", type(exc).__name__)


@contextmanager
def _download_lock(output: Path, deadline: float, trace=None):
    # Keep this file after unlocking. Unlinking it could let another process
    # acquire a new inode while an existing waiter still holds the old one.
    with output.with_suffix(".pdf.download.lock").open("a+b") as stream:
        acquired = False
        try:
            with trace.phase("download_lock") if trace is not None else nullcontext():
                while not acquired:
                    _remaining(deadline)
                    try:
                        stream.seek(0)
                        if os.name == "nt":
                            import msvcrt
                            msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
                        else:
                            import fcntl
                            fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                        acquired = True
                    except OSError:
                        _sleep(0.05, deadline)
                # Windows permits locking a range beyond EOF. Initialise only
                # while holding that range: another opener may already have
                # locked byte 0 between our empty-file check and flush.
                stream.seek(0, os.SEEK_END)
                if stream.tell() == 0:
                    stream.write(b"0")
                    stream.flush()
            yield
        finally:
            if acquired:
                stream.seek(0)
                if os.name == "nt":
                    import msvcrt
                    msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def download_arxiv_pdf(
    paper_id: str,
    output_dir: Path,
    *,
    total_timeout: float = 90.0,
    reserve_request: Callable[[float], tuple[bool, float]],
    network_cooldown: Callable[[], object],
    rate_limit_cooldown: Callable[[object], object],
    request_get: Callable = requests.get,
    proxies=None,
    verify: bool = False,
    trace=None,
) -> str:
    """Share one budget across locks, pacing, retries, hosts, and streamed writes.

    Socket idle timeouts are also bounded by the remaining budget. A blocking
    socket/DNS call cannot be forcibly interrupted here; elapsed time is checked
    again before publication, and expired or incomplete downloads are discarded.
    """
    if not isinstance(paper_id, str) or not PAPER_ID.fullmatch(paper_id):
        raise ValueError("Invalid arXiv paper identifier")
    if not math.isfinite(total_timeout) or total_timeout <= 0:
        raise ValueError("PDF download time budget must be positive and finite")
    started = time.monotonic()
    deadline = started + total_timeout
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    output = output_dir / (paper_id.replace("/", "_") + ".pdf")

    phase = trace.phase if trace is not None else lambda name: nullcontext()
    with _download_lock(output, deadline, trace):
        with phase("cache_check"):
            cache_hit = is_complete_pdf(output)
        if cache_hit:
            LOGGER.info("arXiv PDF cache reused: %s", paper_id)
            return str(output)

        last_error = None
        for host in ("https://arxiv.org", "https://export.arxiv.org"):
            for attempt in range(1, 4):
                with phase("request_pacing"):
                    permitted, cooldown = reserve_request(_remaining(deadline))
                    _remaining(deadline)
                    if not permitted:
                        _sleep(max(0.05, cooldown), deadline)
                if not permitted:
                    continue
                partial = None
                try:
                    remaining = _remaining(deadline)
                    with phase("http_download"), request_get(
                        f"{host}/pdf/{paper_id}.pdf",
                        verify=verify, proxies=proxies, stream=True,
                        timeout=(min(15.0, remaining / 2), min(30.0, remaining / 2)),
                    ) as response:
                        _remaining(deadline)
                        if response.status_code == 429:
                            _record_cooldown(rate_limit_cooldown, response)
                        response.raise_for_status()
                        with tempfile.NamedTemporaryFile(
                            mode="wb", dir=output_dir, prefix=f".{output.stem}.",
                            suffix=".part", delete=False,
                        ) as stream:
                            partial = Path(stream.name)
                            for chunk in response.iter_content(chunk_size=65536):
                                _remaining(deadline)
                                if chunk:
                                    stream.write(chunk)
                            stream.flush()
                            os.fsync(stream.fileno())
                    _remaining(deadline)
                    with phase("response_validate"):
                        if not is_complete_pdf(partial):
                            raise ValueError("arXiv response is incomplete or is not a PDF")
                    _remaining(deadline)
                    with phase("cache_publish"):
                        os.replace(partial, output)
                    LOGGER.info("arXiv PDF downloaded: %s (%.2fs)", paper_id, time.monotonic() - started)
                    return str(output)
                except (requests.RequestException, TimeoutError, ValueError) as exc:
                    last_error = exc
                    if isinstance(exc, (requests.ConnectionError, requests.Timeout)):
                        _record_cooldown(network_cooldown)
                    _remaining(deadline)
                    if attempt < 3:
                        _sleep(float(attempt), deadline)
                finally:
                    if partial is not None:
                        partial.unlink(missing_ok=True)
        if last_error is not None:
            raise last_error
        raise TimeoutError("arXiv PDF download could not reserve a request within the time budget")
