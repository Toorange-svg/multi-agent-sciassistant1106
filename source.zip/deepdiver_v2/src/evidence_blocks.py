"""Question-oriented evidence blocks built from the local PDF parse result."""

from __future__ import annotations

import re


def _block_kind(block: dict) -> str:
    text = str(block.get("text") or "").strip()
    # Numbered headings are reliable; a single leading capital is not (it
    # would classify almost every English prose sentence as a heading).
    if re.match(r"^\d+(?:\.\d+)*\s+\S{2,100}$", text) and len(text) < 140:
        return "heading_candidate"
    if len(text) < 110 and not re.search(r"[.!?:;,]$", text) and sum(ch.isupper() for ch in text) >= 2:
        return "heading_candidate"
    if re.search(r"(?i)^\s*(?:table|tab\.?|表)\s*\d+", text):
        return "table_caption"
    if re.search(r"(?i)^\s*(?:fig(?:ure)?|图)\s*\d+", text):
        return "figure_caption"
    return "text_block"


def build_evidence_blocks(parsed: dict, *, max_blocks: int = 3000) -> list[dict]:
    """Normalize parser layout blocks into bounded, locatable evidence units."""
    blocks = []
    page_risks = {
        page.get("page"): list(page.get("risk_flags") or page.get("failure_modes") or [])
        for page in (parsed.get("pages") or []) if isinstance(page, dict)
    }
    current_section = None
    for index, raw in enumerate(parsed.get("layout_blocks") or []):
        if not isinstance(raw, dict):
            continue
        text = " ".join(str(raw.get("text") or "").split()).strip()
        if not text:
            continue
        kind = _block_kind(raw)
        if kind == "heading_candidate":
            current_section = text
        bbox = raw.get("bbox")
        if not isinstance(bbox, (list, tuple)) or len(bbox) != 4:
            bbox = None
        risk_flags = list(raw.get("risk_flags") or [])
        for flag in page_risks.get(raw.get("page"), []):
            if flag not in risk_flags:
                risk_flags.append(flag)
        blocks.append({
            "evidence_id": f"pdf-block-{index + 1}",
            "text": text[:6000],
            "page": raw.get("page"),
            "bbox": list(bbox) if bbox else None,
            "block_type": kind,
            "source_type": raw.get("type", "text"),
            "section": current_section,
            "citation_allowed": kind in {"text_block", "heading_candidate"} and not risk_flags,
            "risk_flags": risk_flags,
            "visual_review_required": raw.get("type") in {"table", "formula", "figure", "figure_caption"} or kind in {"table_caption", "figure_caption"} or bool(risk_flags),
        })
        if len(blocks) >= max_blocks:
            break
    return blocks


def select_evidence_blocks(blocks: list[dict], query: str, *, limit: int = 28) -> list[dict]:
    """Select relevant blocks while retaining page and bbox provenance."""
    terms = [t.lower() for t in re.findall(r"[A-Za-z][A-Za-z0-9_-]{2,}|[\u4e00-\u9fff]{2,}", str(query or ""))]
    if not terms:
        return blocks[:limit]
    scored = []
    for index, block in enumerate(blocks):
        text = str(block.get("text") or "").lower()
        score = sum(2 for term in terms if term in text)
        if block.get("section") and any(term in str(block["section"]).lower() for term in terms):
            score += 2
        scored.append((score, index))
    scored.sort(key=lambda item: (-item[0], item[1]))
    selected = [blocks[index] for score, index in scored if score > 0][:limit]
    return selected or blocks[:limit]


def format_evidence_blocks(blocks: list[dict], *, max_chars: int = 24000) -> str:
    lines = []
    for block in blocks:
        location = f"page={block.get('page')} bbox={block.get('bbox')}"
        section = f" section={block.get('section')}" if block.get("section") else ""
        lines.append(f"[{block.get('evidence_id')}; {location}; type={block.get('block_type')}{section}] {block.get('text')}")
    return "\n\n".join(lines)[:max_chars]
