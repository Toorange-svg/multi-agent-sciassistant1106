"""Task-scoped read suppression and credential-free PDF phase measurements."""
from __future__ import annotations

import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field


class ReadTrace:
    def __init__(self):
        self.events = []

    @contextmanager
    def phase(self, name):
        started = time.monotonic()
        event = {"phase": name, "status": "completed"}
        try:
            yield
        except Exception as exc:
            event.update(status="failed", error_type=type(exc).__name__)
            raise
        finally:
            event["elapsed_ms"] = round((time.monotonic() - started) * 1000)
            self.events.append(event)


@dataclass
class _Entry:
    ready: threading.Event = field(default_factory=threading.Event)
    result: object = None
    expires_at: float = 0


class ArxivReadGuard:
    """Process-local guard. Keys must include task/session/workspace scope.

    Share concurrent results; retain failures briefly, never cache successful
    document bodies after the active call finishes. Not a distributed lock.
    """
    def __init__(self, cooldown=300.0, join_timeout=5.0, capacity=256):
        self.cooldown = cooldown
        self.join_timeout = join_timeout
        self.capacity = capacity
        self._lock = threading.Lock()
        self._entries = {}

    def run(self, key, invoke):
        with self._lock:
            now = time.monotonic()
            self._entries = {k: e for k, e in self._entries.items()
                             if not e.ready.is_set() or e.expires_at > now}
            entry = self._entries.get(key)
            owner = entry is None
            if owner:
                if len(self._entries) >= self.capacity:
                    return None, "capacity"
                entry = _Entry()
                self._entries[key] = entry
            elif entry.ready.is_set():
                return entry.result, "failure_cooldown"
        if not owner:
            if not entry.ready.wait(self.join_timeout):
                return None, "inflight"
            return entry.result, "shared_result"
        try:
            result = invoke()
        except BaseException:
            with self._lock:
                self._entries.pop(key, None)
                entry.ready.set()
            raise
        with self._lock:
            entry.result = result
            if result.success:
                self._entries.pop(key, None)
            else:
                entry.expires_at = time.monotonic() + self.cooldown
            entry.ready.set()
        return result, "executed"
