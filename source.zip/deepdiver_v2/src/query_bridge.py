"""Bridge a non-English question to the gate's English concept vocabulary.

``score_literature_relevance`` is a conservative *lexical* gate: it matches the
question's own words against a candidate's title and abstract. A Chinese
question therefore has nothing to match, because ``_CONCEPT_ALIASES`` is keyed
by English terminology. In the real chain the planner model closes that gap by
generating English keywords; when it is unavailable the gate silently scores
every candidate 0.0 and rejects everything.

This module closes the gap without a model and without a topic catalog:

* Chinese text is segmented into terminology pieces (``query_terms`` already
  owns the function-word tables, so no second stopword list is introduced);
* each piece is resolved through the project's existing, documented concept
  vocabulary (``_CONCEPT_ALIASES``) and its English synonyms;
* resolved terminology becomes additional scoring text for the gate.

Nothing here maps a topic to a paper, an arXiv ID or a category. It maps
Chinese *wording* onto the English aliases the project already maintains, and
it reports ``degraded`` when it cannot resolve anything so that "no English
concept was found" is never mistaken for "no relevant paper exists".
"""
from __future__ import annotations

import re

from .query_terms import CHINESE_STOPWORDS, ENGLISH_STOPWORDS, chinese_content_pieces

# Terminology that is already English inside a Chinese question (``Transformer
# 的局限性``, ``GraphRAG 在多跳推理``). These are query-ready as written.
_ASCII_TOKEN = re.compile(r"[A-Za-z][A-Za-z0-9+./-]*")

# Characters that only ever occur in Chinese prose, used to tell a Chinese
# question from an English one.
_CJK = re.compile(r"[\u3400-\u9fff]")


def _alias_terms(alias: str) -> list[str]:
    """Split a concept alias into its individual English words.

    Aliases are short English phrases ("mixture of experts", "world model",
    "chain of thought"). The ASCII words inside them are the vocabulary the
    gate can actually match against a candidate's title and abstract.
    """
    return [token.lower() for token in _ASCII_TOKEN.findall(alias)]


def _concept_alias_terms() -> dict[str, list[str]]:
    # Imported lazily: ``query_router`` imports this module, so a module-level
    # import would be circular.
    from .query_router import _CONCEPT_ALIASES

    vocabulary: dict[str, list[str]] = {}
    for aliases in _CONCEPT_ALIASES.values():
        for alias in aliases:
            for token in _alias_terms(alias):
                if len(token) >= 2 and token not in ENGLISH_STOPWORDS:
                    vocabulary.setdefault(token, [])
    return vocabulary


def chinese_question_terms(query: str) -> list[str]:
    """Terminology pieces of a Chinese question, without function words."""
    terms: list[str] = []
    seen: set[str] = set()
    for piece in chinese_content_pieces(str(query or "")):
        if piece in CHINESE_STOPWORDS or len(piece) < 2:
            continue
        if piece.lower() in seen:
            continue
        seen.add(piece.lower())
        terms.append(piece)
    return terms


def _candidate_ascii_terms(query: str) -> list[str]:
    """English terminology already present in the question.

    Any ASCII word may be an identifier the gate should score against; this
    deliberately does not filter by a name catalog. Query scaffolding
    (function words, the literal word "model") is removed so a question about
    a *world model* does not score every paper containing "model".
    """
    generic = {"model", "models", "method", "methods", "paper", "papers",
               "survey", "review", "overview", "analysis", "architecture"}
    terms = []
    for token in _ASCII_TOKEN.findall(str(query or "")):
        lowered = token.lower()
        if lowered in ENGLISH_STOPWORDS or lowered in generic:
            continue
        if len(lowered) < 2:
            continue
        if lowered not in terms:
            terms.append(lowered)
    return terms


# P1 offline fallback vocabulary: standard English scholarly translations of
# common Chinese names for concepts the project's English vocabulary already
# covers. This is a *translation* table, not a topic-to-paper mapping: every
# entry maps Chinese wording onto terminology that already exists in
# ``_CONCEPT_ALIASES``, and none references a specific paper, arXiv ID or
# category. The planner model's translations remain the primary path; this
# table only guarantees that a fully non-English question still yields an
# English entity when the planner is unavailable, so entity-less queries are
# never sent to sources that reject them.
_CHINESE_CONCEPT_TRANSLATIONS = {
    "世界模型": "world model",
    "大语言模型": "large language model",
    "注意力": "attention",
    "多模态": "multimodal",
    "微调": "fine-tuning",
    "低秩适应": "low-rank adaptation",
    "检索增强生成": "retrieval-augmented generation",
    "强化学习": "reinforcement learning",
    "思维链": "chain of thought",
    "图神经网络": "graph neural network",
    "卷积神经网络": "convolutional neural network",
    "扩散模型": "diffusion model",
    "状态空间模型": "state space model",
    "量化": "quantization",
}


def chinese_entity_fallback_queries(query: str) -> list[str]:
    """English entity phrases for a Chinese question via the translation table.

    Used only as the last-resort plan when the planner model is unavailable and
    the deterministic plan carries no English entity. Returns each standard
    translation once, in question order.
    """
    results: list[str] = []
    seen: set[str] = set()
    for piece in chinese_content_pieces(str(query or "")):
        if piece in CHINESE_STOPWORDS or len(piece) < 2:
            continue
        translation = _CHINESE_CONCEPT_TRANSLATIONS.get(piece)
        if translation and translation.lower() not in seen:
            seen.add(translation.lower())
            results.append(translation)
    return results


def bridge_query_terms(query: str) -> dict:
    """Resolve a question into terminology the lexical gate can match.

    Returns a dict with:

    ``terms``
        English terminology to add to the scoring text.
    ``chinese_terms``
        Unresolved Chinese terminology pieces.
    ``resolved``
        True when at least one English term is available for scoring.
    ``scoring_status``
        ``ok`` when English terms were found, otherwise ``degraded``.
    ``source``
        Which rule produced the terms, for diagnostics.
    """
    text = str(query or "")
    has_cjk = bool(_CJK.search(text))
    ascii_terms = _candidate_ascii_terms(text)
    chinese_terms = chinese_question_terms(text) if has_cjk else []

    terms: list[str] = []
    for term in ascii_terms:
        if term not in terms:
            terms.append(term)

    resolved_by_concept = False
    if chinese_terms:
        vocabulary = _concept_alias_terms()
        for piece in chinese_terms:
            # A Chinese piece is "resolved" when it contains an ASCII part that
            # is itself project vocabulary. ``GraphRAG 在多跳推理`` yields
            # ``graphrag``; a purely Chinese piece such as ``世界模型`` resolves
            # through the translation table below instead.
            for token in _ASCII_TOKEN.findall(piece):
                lowered = token.lower()
                if lowered in vocabulary and lowered not in terms:
                    terms.append(lowered)
                    resolved_by_concept = True
            # P1 offline fallback: a purely Chinese piece whose standard
            # scholarly translation exists in the project's own vocabulary
            # resolves through ``_CHINESE_CONCEPT_TRANSLATIONS`` (e.g.
            # 世界模型 -> world model). This is terminology translation, never
            # a topic-to-paper mapping.
            translation = _CHINESE_CONCEPT_TRANSLATIONS.get(piece)
            if translation and translation not in terms:
                terms.append(translation)
                resolved_by_concept = True

    if terms:
        source = "ascii_in_question" if not resolved_by_concept else "concept_vocabulary"
    else:
        source = "none"
    # Report only genuinely non-English pieces as unresolved. A piece such as
    # ``Transformer 的局限性`` is reported through the ASCII terms it yielded,
    # so repeating it here would read as an unresolved Chinese term when the
    # English part was in fact resolved.
    unresolved = [
        piece for piece in chinese_terms
        if _CJK.search(piece) and not _ASCII_TOKEN.search(piece)
    ]
    return {
        "terms": terms,
        "chinese_terms": chinese_terms,
        "unresolved_chinese_terms": unresolved,
        "resolved": bool(terms),
        "scoring_status": "ok" if terms else "degraded",
        "source": source,
    }


def augment_scoring_query(query: str) -> tuple[str, dict]:
    """Return the gate's scoring text together with bridge diagnostics.

    The original question is always preserved: the bridge only *adds* English
    terminology, so behaviour for English questions is unchanged.
    """
    bridge = bridge_query_terms(query)
    parts = [str(query or "").strip()]
    parts.extend(bridge["terms"])
    scoring_query = " ".join(part for part in parts if part)
    return scoring_query, bridge
