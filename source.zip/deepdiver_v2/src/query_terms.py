"""Query-local term extraction for the ``query_local_term`` dimension.

This is the single home for the language-level stopword tables and the term
extractor behind literature query planning. The extractor turns the original
question into a term list, never a clause list:

- ``english`` terms are ASCII phrases with function words trimmed; they may
  enter arXiv queries directly.
- ``chinese`` terms are non-English content terminology; they are translation
  input for the planner model only and must never become query strings
  themselves. When the extractor returns no term at all, the caller skips the
  ``query_local_term`` dimension instead of querying prose.

All tables name grammar, not subject matter: no entry selects which research
field a question is about.
"""
from __future__ import annotations

import re


# Chinese function words. Single-character entries are used only for the
# "is this chunk exactly a function word" test; the split pattern below
# deliberately omits single characters that commonly occur inside real
# terminology (对齐, 行为, 有效, 一致, 地图, ...).
CHINESE_STOPWORDS = frozenset({
    # 疑问词 interrogatives
    "什么", "什么是", "为何", "为什么", "如何", "怎么", "怎样", "怎么样", "哪些", "哪个",
    "哪", "哪里", "是否", "能否", "能不能", "多少", "几", "何时", "谁", "干嘛",
    "有没有", "有无", "哪几", "几篇",
    # 介词 prepositions
    "在", "对", "对于", "关于", "从", "到", "向", "给", "被", "把", "由", "于", "跟",
    "同", "除", "按", "依", "根据", "通过", "为了", "至于", "针对", "作为",
    # 系动词 copulas
    "是", "为", "成为", "属于", "有", "具有", "存在", "叫做", "称为",
    # 冠词与量词 articles and measure words
    "一个", "一种", "一类", "一些", "一下", "个", "些", "之", "等", "等等", "之类",
    "一段", "一篇", "一条", "一项",
    # 连接词 connectives
    "和", "与", "及", "以及", "或", "或者", "还是", "但", "但是", "然而", "因此",
    "所以", "因为", "如果", "若", "则", "而且", "并且", "同时", "不过", "而是",
    "然后", "接着", "另外", "此外", "比如", "例如", "更有",
    # 代词 pronouns
    "我", "我们", "你", "你们", "他", "他们", "她", "她们", "它", "它们", "这",
    "这个", "这些", "那", "那个", "那些", "其", "其中", "该", "此", "本", "自己",
    "前者", "后者", "上述", "下列",
    # 语气词与助词 modal particles and auxiliaries
    "的", "了", "吗", "呢", "吧", "啊", "呀", "哦", "嗯", "着", "过", "地", "得",
    "所", "来着", "罢了", "而已", "需要", "能够", "应该", "应当", "必须",
    # 请求语、提示词成分与泛化名词 request verbs, prompt boilerplate, generic nouns
    "请", "讲解", "解释", "说明", "介绍", "分析", "讨论", "告诉", "告诉我", "谈谈",
    "论文", "文章", "文献", "研究", "问题", "子问题", "方面", "优势", "劣势",
    "优点", "缺点", "好处", "短板", "不足", "核心", "具体", "当前", "刚才", "最近",
    "最新", "相关", "内容", "信息", "情况", "部分", "条件", "格式", "描述",
    "背景", "期望", "要求", "输出", "输入", "包含", "包括", "覆盖", "列出",
    "总结", "汇总", "给出", "进行", "场景下", "情况下", "时候", "期间",
    "解决", "报告", "一份", "限定", "多个", "详细", "简短", "简要",
})

# English function words: interrogatives, prepositions, copulas, articles,
# connectives, pronouns, modals, plus French function words that previously
# leaked into queries as capitalized "entities" and generic research nouns.
ENGLISH_STOPWORDS = frozenset({
    # articles and connectives
    "a", "an", "the", "and", "or", "but", "if", "then", "than", "that", "this",
    "these", "those", "of", "to", "in", "on", "at", "by", "for", "from", "with",
    "without", "into", "over", "under", "as", "about", "after", "before", "also",
    "just", "not", "nor", "so", "such", "both", "either", "neither",
    # copulas and modals
    "is", "are", "be", "been", "being", "am", "was", "were", "do", "does", "did",
    "done", "doing", "can", "could", "should", "would", "will", "shall", "may",
    "might", "must", "have", "has", "had", "need", "needs",
    # interrogatives
    "how", "what", "which", "who", "whom", "when", "where", "why", "whether",
    # pronouns
    "it", "its", "they", "them", "their", "there", "here", "we", "you", "your",
    "our", "i", "me", "my", "mine",
    # French function words
    "quelles", "quelle", "quels", "quel", "comment", "pourquoi", "dans", "sur",
    "avec", "sans", "les", "des", "une", "un", "et", "ou", "est", "sont", "être",
    "ce", "ces", "qui", "que", "quoi", "où", "pour", "par", "comme", "plus",
    "moins", "aussi", "de", "du", "au", "aux", "en", "leur", "leurs", "notre",
    "votre",
    # generic research and discourse nouns
    "paper", "papers", "article", "articles", "study", "studies", "research",
    "question", "problem", "problems", "issue", "issues", "explain",
    "explanation", "discuss", "using", "use", "used", "following",
})

# Only multi-character stopwords participate in splitting, so a single
# character that also appears inside a real term cannot truncate it. The
# attributive particle 的 is the one deliberate exception: it never occurs
# inside a compound term, and splitting it keeps noun phrases ("大模型的幻觉")
# from passing as single terms.
_CHINESE_STOPWORD_SPLIT = re.compile(
    "|".join(
        [re.escape("的")]
        + [
            re.escape(word)
            for word in sorted(
                (word for word in CHINESE_STOPWORDS if len(word) >= 2),
                key=len,
                reverse=True,
            )
        ]
    )
)

# Grammatical single characters that may cling to the left edge (subject
# markers) or the right edge (aspect/existence markers) of a solid piece.
# Characters that can open a real term (有 in 有限上下文) are excluded from
# the left set so trimming cannot truncate terminology.
_EDGE_STRIP_LEFT = "的了是在对把给和与或跟同它这那我你们他她"
_EDGE_STRIP_RIGHT = "的了是在对有和与或跟同吗呢吧啊呀哦嗯"

# Interrogative characters: a piece containing one of these is a question
# fragment ("是哪几篇"), never research terminology.
_CHINESE_INTERROGATIVE_CHARS = re.compile(r"[哪几什么怎吗呢吧]")

# Punctuation and whitespace boundaries between candidate chunks.
_CHUNK_BOUNDARY = re.compile(r"[，,；;。！？?：:\s、（）()\[\]{}\"'“”‘’…·]+")

_CJK_CHAR = re.compile(r"[\u3400-\u9fff]")

# ASCII word token, matching the identifier style used by the query router.
_ASCII_TOKEN = r"[A-Za-z][A-Za-z0-9+./-]*"


def _contains_cjk(value: str) -> bool:
    return bool(_CJK_CHAR.search(value))


def chinese_content_pieces(phrase: str) -> list[str]:
    """Split a text chunk into its terminology pieces, without function words.

    A chunk that reduces to nothing but function words ("关于", "如果是前者",
    "是否还需要") yields no pieces: it is prose, never a research entity.
    """
    pieces = []
    for piece in _CHINESE_STOPWORD_SPLIT.split(str(phrase or "").strip()):
        # Grammatical single characters at the edges of an otherwise solid
        # piece ("它和稠密模型有") are markers, not terminology.
        piece = piece.strip().lstrip(_EDGE_STRIP_LEFT).rstrip(_EDGE_STRIP_RIGHT)
        if len(piece) < 2 or piece in CHINESE_STOPWORDS:
            continue
        if _CHINESE_INTERROGATIVE_CHARS.search(piece):
            continue
        pieces.append(piece)
    return pieces


def chinese_content_phrase(phrase: str) -> str:
    """Return the terminology part of a chunk, space-joined for display."""
    return " ".join(chinese_content_pieces(phrase))


def _english_terms(text: str) -> list[str]:
    """Extract short ASCII terminology, never natural-language fragments."""
    phrases: list[str] = []
    # If the source question is clearly French, do not pass untransformed
    # French ASCII words through this fallback. The LLM planner is responsible
    # for translating them; an acronym such as MoE remains safe to retain.
    french_markers = {"quelles", "quelle", "quels", "quel", "dans", "avec", "sans", "les", "des", "une", "un", "et", "ou", "sont", "pourquoi", "comment", "de", "du", "au", "aux", "en"}
    french_marker_count = sum(1 for word in re.findall(r"[A-Za-zÀ-ÿ]+", text.lower()) if word in french_markers)
    # Capture candidate spans, then trim grammatical words at both ends.
    # Unicode-letter guards prevent matching pieces of accented words such as
    # ``modèles`` -> ``mod`` or ``évaluer`` -> ``valuer``.
    pattern = rf"(?<![^\W\d_]){_ASCII_TOKEN}(?:\s+{_ASCII_TOKEN}){{0,8}}(?![^\W\d_])"
    for match in re.finditer(pattern, text):
        tokens = match.group(0).strip(" ,;:()[]{}?!").split()
        while tokens and tokens[0].lower() in ENGLISH_STOPWORDS:
            tokens.pop(0)
        while tokens and tokens[-1].lower() in ENGLISH_STOPWORDS:
            tokens.pop()
        # A phrase longer than 7 words is a sentence fragment, not a term.
        if not tokens or len(tokens) > 7:
            continue
        content_tokens = [token for token in tokens if token.lower() not in ENGLISH_STOPWORDS]
        if not content_tokens:
            continue
        value = " ".join(tokens)
        if len(value) < 3 or value.lower() in {item.lower() for item in phrases}:
            continue
        if french_marker_count >= 2 and not (len(tokens) == 1 and tokens[0].isupper()):
            continue
        # Avoid residual question/discourse fragments even when one content
        # word remains after trimming (e.g. "if former", "need solve").
        if len(content_tokens) == 1 and content_tokens[0].lower() in ENGLISH_STOPWORDS:
            continue
        phrases.append(value)
    return phrases[:12]


def _chinese_terms(text: str) -> list[str]:
    """Extract Chinese terminology pieces as translation input.

    These never enter a query directly: the planner model translates them
    into English scholarly terminology first. Pieces are bounded to 12
    characters because longer spans are clauses, not terms.
    """
    terms: list[str] = []
    seen = set()
    for chunk in _CHUNK_BOUNDARY.split(text):
        chunk = chunk.strip()
        if not chunk or not _contains_cjk(chunk):
            continue
        for piece in chinese_content_pieces(chunk):
            if not _contains_cjk(piece):
                continue
            if not (2 <= len(piece) <= 12) or piece in CHINESE_STOPWORDS:
                continue
            if piece.lower() in seen:
                continue
            seen.add(piece.lower())
            terms.append(piece)
    return terms[:8]


def extract_query_terms(query: str) -> dict:
    """Turn an original question into query-local terminology.

    Returns ``{"english": [...], "chinese": [...]}``. English phrases are
    query-ready; Chinese terms must be translated before query generation.
    An empty result means the ``query_local_term`` dimension must be skipped.
    """
    text = str(query or "")
    return {
        "english": _english_terms(text),
        "chinese": _chinese_terms(text),
    }
