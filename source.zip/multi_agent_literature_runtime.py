"""Safe product-facing projection for the bounded literature workflow."""

from __future__ import annotations

from typing import Any

from multi_agent_literature import LiteratureRoles, LiteratureWorkflowCoordinator
from multi_agent_workflow import WorkflowStore


def _last(artifacts: list[dict], artifact_type: str) -> dict | None:
    matching = [item["payload"] for item in artifacts if item["artifact_type"] == artifact_type]
    return matching[-1] if matching else None


def _evidence_ledger(evidence_set: dict | None) -> list[dict]:
    records = (evidence_set or {}).get("records") or []
    return [{
        "citation": f"[{index}]", "label": f"[{record['source']}:{record['paper_id']}]",
        "source": record["source"], "paper_id": record["paper_id"], "title": record["title"],
        "access": "official_pdf_fulltext" if record["fulltext_available"] else "abstract_only",
        "matched_keywords": [], "workflow_evidence_id": record["evidence_id"],
    } for index, record in enumerate(records, 1)]


def execute_multi_agent_literature(
    *, task_id: str, question: str, roles: LiteratureRoles, state_path: str | None = None,
) -> dict[str, Any]:
    """Execute one run and expose only answer/evidence-safe task fields.

    Existing web-task ownership remains outside this module. ``owner_ref`` is
    an opaque task-scoped identifier used solely to prevent accidental reuse of
    a run record by a different task.
    """
    store = WorkflowStore(state_path)
    coordinator = LiteratureWorkflowCoordinator(store, roles)
    summary = coordinator.run(
        task_id, f"task-{task_id}",
        {
            "schema_version": 1, "task_id": task_id, "question": question,
            "conversation_facts": [], "deadline_at": 0.0, "remaining_model_calls": 10,
        },
    )
    try:
        artifacts = store.list_artifacts(task_id)
    except Exception:
        artifacts = []
    review = _last(artifacts, "evidence_review")
    draft = _last(artifacts, "draft_answer")
    audit = _last(artifacts, "citation_audit")
    evidence_set = _last(artifacts, "evidence_set")
    ledger = _evidence_ledger(evidence_set)
    retrieval_summary = (evidence_set or {}).get("retrieval_summary") or []
    status = summary.get("workflow_status")
    if status in {"completed", "partial"} and draft:
        answer = str(draft.get("answer") or "").strip()
        if review and review.get("coverage_status") == "partial":
            unresolved = review.get("unsupported_questions") or draft.get("unresolved_questions") or []
            answer = (
                "## 证据覆盖不完整\n\n"
                "以下内容仅回答已有审查证据支持的部分；未解决问题不应视为已验证结论。"
                + ("\n\n未解决：\n" + "\n".join(f"- {item}" for item in unresolved) if unresolved else "")
                + "\n\n" + answer
            )
        references = "\n".join(
            f"[{index}] {item['title']} ({item['source']}:{item['paper_id']})"
            for index, item in enumerate(ledger, 1)
        )
        if references:
            answer += "\n\n## 文献来源\n" + references
        return {
            "success": True, "completion_status": status, "final_answer": answer,
            "evidence_ledger": ledger, "citation_check": audit or {"status": "unverified", "issues": []},
            "workflow_summary": summary, "evidence_review": {
                "coverage_status": (review or {}).get("coverage_status", "unknown"),
                "unsupported_questions": (review or {}).get("unsupported_questions", []),
                "coverage": (review or {}).get("coverage", []),
                "retrieval_summary": retrieval_summary,
            },
        }
    return {
        "success": False, "completion_status": "insufficient_evidence" if summary.get("failure_code") == "INSUFFICIENT_EVIDENCE" else "failed",
        "final_answer": "未获得足以支撑可靠综合结论的审查证据，因此本次不生成科研回答。",
        "evidence_ledger": ledger, "citation_check": audit or {"status": "not_applicable", "issues": []},
        "workflow_summary": summary, "evidence_review": {
            "coverage_status": (review or {}).get("coverage_status", "insufficient"),
            "unsupported_questions": (review or {}).get("unsupported_questions", []),
            "coverage": (review or {}).get("coverage", []),
            "retrieval_summary": retrieval_summary,
        },
    }
