"""Bounded source audits plus one whole-report review, never partial-JSON rescue."""
from copy import deepcopy
import hashlib
import json
import math

from multi_agent_quality import REPORT_FIELDS, check_audit, publication_rejections
from multi_agent_handoffs import audit_source_catalog, comparison_observations
from multi_agent_publication import review_request

AUDIT_BATCH_POLICY = 'bounded-source-batches-and-whole-report-review/v1'
AUDIT_BATCH_RECOVERY_POLICY = 'complete-batch-uncontested-verified-rows-only/v1'
MAX_AUDIT_CLAIMS = 12
GLOBAL_REVIEW_SCHEMA = 'sciassistant.report-global-review-input/v1'


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':')).encode('utf-8')).hexdigest()


def is_batched(draft):
    return draft.get('audit_delivery_policy') == AUDIT_BATCH_POLICY and len(draft.get('claims', [])) > MAX_AUDIT_CLAIMS


def required_audit_calls(draft):
    return math.ceil(len(draft['claims'])/MAX_AUDIT_CLAIMS)+1 if is_batched(draft) else 1


def source_batches(draft):
    batches = []
    for start in range(0, len(draft['claims']), MAX_AUDIT_CLAIMS):
        subset = deepcopy(draft)
        subset['claims'] = deepcopy(draft['claims'][start:start+MAX_AUDIT_CLAIMS])
        # Coverage and cross-batch consistency get their own whole-report call.
        subset.pop('publication_review_policy', None)
        batches.append({'batch_id': f'source-{len(batches)+1:03d}', 'draft': subset,
            'claim_ids': [c['claim_id'] for c in subset['claims']],
            'claim_contents_sha256': digest(subset['claims'])})
    return batches


def unreviewed(claim, reason):
    return {'claim_id': claim['claim_id'], 'decision': 'needs_review',
        'reason_code': 'AUDIT_BATCH_UNREVIEWED', 'detail': reason,
        'evidence_ids': deepcopy(claim.get('evidence_ids', [])),
        'field_results': {field: {'status': 'needs_review' if str(claim.get(field) or '').strip() else 'not_applicable',
            'detail': '本批未取得完整有效审计；不是科学批准。', 'absence_checks': []} for field in REPORT_FIELDS},
        'source_witnesses': [],
        'scope_checks': {field: 'needs_review' for field in ('family_scope', 'comparison_design', 'task_scope', 'metric_semantics')}}


def recover_source_rows(draft, evidence, audit):
    """Recover explicit, uncontested approvals, never interpret verdict prose.

    Requires a complete v7 row set. Only aggregate list/status contradictions
    qualify; malformed/truncated/incomplete payloads fail closed. Original row
    contents and claim dependencies are never changed. The caller still runs
    whole-draft checks, dependency isolation and the global report review.
    """
    receipt = {'schema_version': 'sciassistant.audit-batch-recovery/v1',
        'policy': AUDIT_BATCH_RECOVERY_POLICY, 'source_audit_sha256': digest(audit),
        'draft_sha256': digest(draft), 'approved_sources_sha256': digest(evidence),
        'original_contract_errors': deepcopy(audit.get('contract_errors', [])),
        'retained_claim_ids': [], 'contested_claim_ids': [], 'row_failures': [],
        'scientific_auto_approval': False}
    allowed = {'AUDIT_REJECTION_SET_INCONSISTENT', 'AUDIT_ISSUE_VERDICT_INCONSISTENT',
        'AUDIT_ISSUE_REASON_INCONSISTENT', 'AUDIT_STATUS_INCONSISTENT', 'AUDIT_ISSUES_INCOMPLETE'}
    errors = audit.get('contract_errors')
    if (draft.get('audit_batch_recovery_policy') != AUDIT_BATCH_RECOVERY_POLICY
            or audit.get('schema_version') != 'sciassistant.citation-audit/v7'
            or not isinstance(errors, list) or not errors or not set(errors).issubset(allowed)
            or not isinstance(evidence, dict) or not evidence.get('evidence')):
        return {}, receipt
    claims = {c['claim_id']: c for c in draft['claims']}
    rows, rejected, issues = (audit.get(k) for k in ('claim_results', 'rejected_claim_ids', 'issues'))
    if (not isinstance(rows, list) or not all(isinstance(r, dict) for r in rows)
            or any(not isinstance(r.get('claim_id'), str) for r in rows)
            or len(rows) != len(claims) or {r['claim_id'] for r in rows} != set(claims)
            or len({r['claim_id'] for r in rows}) != len(rows)
            or not isinstance(rejected, list) or any(not isinstance(k, str) for k in rejected)
            or len(set(rejected)) != len(rejected) or not set(rejected).issubset(claims)
            or not isinstance(issues, list) or any(not isinstance(r, dict)
                or not isinstance(r.get('claim_id'), str) or r['claim_id'] not in claims for r in issues)):
        return {}, receipt
    contested = set(rejected) | {r['claim_id'] for r in issues} | {
        r['claim_id'] for r in rows if r.get('decision') != 'approved'}
    receipt['contested_claim_ids'] = [k for k in claims if k in contested]
    if not contested:
        return {}, receipt  # Status-only ambiguity has no safely localized boundary.
    retained = {}
    for row in rows:
        key = row['claim_id']
        if key in contested:
            continue
        # Build a new single-row checking envelope, not a new verdict. Do not
        # copy stale derived errors, and do not edit the actual row/claim.
        probe = check_audit({'schema_version': audit['schema_version'], 'status': 'passed',
            'rejected_claim_ids': [], 'issues': [], 'claim_results': [deepcopy(row)]},
            {**draft, 'claims': [claims[key]]}, evidence)
        faults = list(probe.get('contract_errors', []))
        faults.extend(r.get('reason', 'AUDIT_ROW_INVALID') for name in
            ('protocol_issues', 'witness_issues', 'absence_issues') for r in probe.get(name, []))
        if faults:
            receipt['row_failures'].append({'claim_id': key, 'reason_codes': list(dict.fromkeys(faults))})
        else:
            retained[key] = deepcopy(row)
    receipt['retained_claim_ids'] = list(retained)
    receipt['isolated_claim_ids'] = [k for k in claims if k not in retained]
    return retained, receipt


def merge_source_audits(draft, evidence, records):
    """Only complete verified batch verdicts may contribute source approvals."""
    by_id = {c['claim_id']: c for c in draft['claims']}
    accepted, faults, recoveries = {}, [], []
    schemas = []
    for record in records:
        audit = record.get('audit') or {}
        expected = set(record['claim_ids'])
        if expected.issubset(by_id):
            audit = check_audit(audit, {**draft,'claims':[by_id[k] for k in by_id if k in expected]}, evidence)
        rows = audit.get('claim_results', [])
        valid = (audit.get('schema_version') in {'sciassistant.citation-audit/v7','sciassistant.citation-audit/v2'}
            and not audit.get('contract_errors') and isinstance(rows, list)
            and len(rows) == len(expected) and len({r.get('claim_id') for r in rows}) == len(rows)
            and {r.get('claim_id') for r in rows} == expected and expected.issubset(by_id)
            and not expected.intersection(accepted))
        if valid:
            accepted.update({r['claim_id']: deepcopy(r) for r in rows})
            schemas.append(audit.get('schema_version'))
        else:
            faults.append({'batch_id': record['batch_id'], 'claim_ids': record['claim_ids'],
                'reason_codes': audit.get('contract_errors') or [record.get('reason_code', 'AUDIT_BATCH_INVALID')]})
            if (expected.issubset(by_id) and not expected.intersection(accepted)
                    and len(record['claim_ids']) == len(expected)):
                kept, receipt = recover_source_rows(
                    {**draft, 'claims': [by_id[k] for k in by_id if k in expected]}, evidence, audit)
                if receipt['original_contract_errors'] and draft.get('audit_batch_recovery_policy') == AUDIT_BATCH_RECOVERY_POLICY:
                    recoveries.append({'batch_id': record['batch_id'], **receipt})
                if kept:
                    accepted.update(kept)
                    schemas.append(audit['schema_version'])
    missing = [key for key in by_id if key not in accepted]
    rows = [accepted.get(c['claim_id']) or unreviewed(c, '该审计批未完成、输出无效或预算不足；不解析截断回复猜测批准。')
        for c in draft['claims']]
    rejected = [r['claim_id'] for r in rows if r['decision'] != 'approved']
    # v2 is retained only for deterministic legacy fixtures; live model output
    # still requires v7. Never downgrade a real v7 result to avoid its checks.
    schema = 'sciassistant.citation-audit/v2' if schemas and all(s == 'sciassistant.citation-audit/v2' for s in schemas) else 'sciassistant.citation-audit/v7'
    result = check_audit({'schema_version': schema, 'status': 'needs_review' if rejected else 'passed',
        'rejected_claim_ids': rejected, 'issues': [{'claim_id': r['claim_id'], 'reason_code': r['reason_code']}
            for r in rows if r['decision'] != 'approved'], 'claim_results': rows}, draft, evidence)
    result.update(audit_delivery_policy=AUDIT_BATCH_POLICY, source_batch_faults=faults,
        source_unreviewed_claim_ids=missing, source_batch_recoveries=recoveries, scientific_auto_approval=False)
    return result


def global_review_input(ledger, draft, evidence, audit):
    request = review_request(ledger, draft)
    blocked = publication_rejections(audit,draft)
    approved_ids = {r['claim_id'] for r in audit.get('claim_results', [])
        if r['decision'] == 'approved' and r['claim_id'] not in blocked and 'draft' not in blocked}
    for row in request['requirements']:
        row['eligible_claim_ids'] = [k for k in row['eligible_claim_ids'] if k in approved_ids]
    return {'schema_version': GLOBAL_REVIEW_SCHEMA, 'policy': AUDIT_BATCH_POLICY,
        'delivery_phase': 'report_review_only', 'report_review_request': request,
        'claims': [{k: deepcopy(c[k]) for k in ('claim_id', 'text', 'scope_note', 'qualification',
            'requirement_ids', 'report_section_id', 'evidence_ids', 'assertion_mode') if k in c}
            for c in draft['claims']],
        'approved_source_catalog': audit_source_catalog(evidence),
        'comparison_observations': comparison_observations(evidence),
        'report_outline': deepcopy(draft.get('report_outline',{})),
        'source_decisions': [{'claim_id': r['claim_id'], 'decision': r['decision'], 'reason_code': r['reason_code']}
            for r in audit.get('claim_results', [])],
        'instructions': [
            'Review the WHOLE current report for requirement coverage and cross-section consistency, including every current ID. Do not return per-claim source verdicts or claim_results/rejected_claim_ids/issues fields.',
            'For each requested requirement select answering claims ONLY from its eligible_claim_ids. Do not borrow an ID from another requirement; do not silently add Writer bindings. If nothing eligible substantively answers it, return unanswered with [] and a concrete reason.',
            'The source decisions are already recorded, not permission to approve sources. Do not restore a rejected/unreviewed claim. Compare publishable candidates against actual source context; a rejected draft sentence alone must not make an independent correct candidate contradictory.',
            'Return report-review/v1 directly inside output with schema_version/requirements/consistency only. The adapter adds the empty internal source arrays, never source approval. Each requirement must occur exactly once. Explain actual conflicts with current IDs, not invented scientific facts.',
        ], 'new_source_approval_allowed': False, 'source_or_claim_truncated': False}
