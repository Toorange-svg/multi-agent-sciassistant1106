﻿# Sciassistant810
SciAssistant is a Python-based research multi-agent assistant built on top of the DeepDiver codebase.

It currently supports:

- direct research Q&A
- latest arXiv paper summaries
- a three-agent writing flow through PlannerAgent, InformationSeekerAgent, and WriterAgent
- a Flask-based web UI entry

## Research Web Quick Start (Windows)

The primary research web UI is served locally. Do not open `web/index.html` with
`file:///`; it needs the local backend API.

1. Install Python 3.10 or newer and make sure `python` or `py` is available in PowerShell.
2. Run:

```powershell
cd C:\path\to\SciAssistant
.\setup_windows.cmd
.\start_sciassistant.ps1
```

3. Open `http://127.0.0.1:5050/` and configure the answer-model endpoint, token, and model name.

For `llama_full` or `hybrid` PDF modes, also configure `LLAMA_CLOUD_API_KEY`.

Tesseract OCR is optional. Installing it adds OCR fallback for scanned PDFs and table OCR
cross-checking; ordinary text-based PDF parsing remains available without it. On Windows,
install Tesseract to its default location: `C:\Program Files\Tesseract-OCR\tesseract.exe`.

### One-click Windows setup

For a first-time Windows installation, run `installer/SciAssistantSetup.exe`. It creates a
project virtual environment, installs `deepdiver_v2/requirements.txt`, optionally installs
Tesseract through `winget`, and writes local API settings to ignored `.env` files. The form
pre-fills the current DeepSeek-compatible endpoint and `deepseek-v4-flash`; users provide
their own `MODEL_REQUEST_TOKEN` and, only for Llama modes, `LLAMA_CLOUD_API_KEY`.

The `chatAi` MySQL prototype and Docker deployment are not required for this local web UI.

## CLI Quick Start

Use the unified CLI entry:

```bat
cd /d <project-root>
run_demo.cmd
```

Useful single-query examples:

```bat
run_demo.cmd -q "Find latest arXiv papers about large language models"
run_demo.cmd -q "Explain your understanding of RAG"
run_demo.cmd -q "Write a concise research report about retrieval augmented generation, including background, key methods, and future directions."
```

## Main folders

- `deepdiver_v2/`
  Core multi-agent system, config, CLI, agents, and MCP tools.

- `chatAi/`
  Frontend HTML pages.

- `docs/`
  Team onboarding and testing documents.

- `bin/windows/`
  Windows launcher scripts.

## Read these first

1. `docs/MAIN_FILES.md`
2. `docs/QUICK_START_SETUP.md`
3. `docs/PROJECT_STRUCTURE.md`
4. `docs/TEAM_ONBOARDING.md`
5. `docs/FILE_OVERVIEW.md`

## Important entry points

- `run_demo.cmd`
  Unified CLI demo entry.

- `deepdiver_v2/cli/demo.py`
  Main CLI routing and output logic.

- `deepdiver_v2/src/agents/`
  Planner, research agents, writer, and shared runtime code.

- `deepdiver_v2/src/tools/`
  MCP tool server, client, and paper tools.

- `web_app.py`
  Primary SciAssistant research web backend. After starting the stack, open `http://127.0.0.1:5050/` rather than opening `web/index.html` as a file.

- `app.py`
  `chatAi` account/database prototype backend on port `5000`. Its
  "科研分析（单轮）" tab proxies requests to the validated `web_app.py`
  task API, while the existing Chat, Reasoner, account, session, and file
  library features remain separate.

## Account UI with validated research tasks

`start_sciassistant.ps1` now starts both web applications by default:

- `http://127.0.0.1:5050/`: the standalone validation/demo UI.
- `http://127.0.0.1:5000/`: the `chatAi` login page.
- `http://127.0.0.1:5000/chat`: the account-style chat UI.

The current `chatAi` page defaults to controlled six-role multi-agent research.
It supports public literature retrieval, private PDF analysis, explicitly
authorized supplemental searches, local/Llama/hybrid parsing, and located
claim-level citations. Registered users configure their own provider keys;
shared provider credentials are not a production fallback.

Follow-ups may supply bounded conversation context as background, never as
approved evidence. Sources and citations are reviewed again for the new answer.
Account login, session history and the research library require MySQL. Fresh
Compose volumes use `deploy/mysql-init/001_schema.sql` (empty schema, no users
or secrets); existing installations use `account_schema.py` migrations, not a
data-dump import. The old local `chatAi/chatai.sql` dump is not distributed.

See `docs/MULTI_AGENT_ANSWER_QUALITY_CLOSING_ACCEPTANCE_20261018.md` and its
successor public-audit stability guide for the current verification scope.
Local CLI results do not establish Linux/HTTPS deployment readiness.

## Service checks

Start or verify the MCP service:

```bat
start_mcp.cmd
check_status.cmd
```

Start the web stack:

```bat
powershell -ExecutionPolicy Bypass -File start_sciassistant.ps1
```

Then open `http://127.0.0.1:5050/` in a browser.

## Current focus

The current project focus is stability, code clarity, and team-friendly structure so the system can be extended toward a daily research assistant for latest arXiv papers.
