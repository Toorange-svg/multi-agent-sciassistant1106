"""Conservative page segmentation built on top of the local PDF parser.

The chunker deliberately describes geometry, not semantics: a region can be a
text flow, a full-width band, a visual object, or an unresolved area.  This
keeps the local reading order authoritative while leaving later vision review
free to decide whether a visual object is a chart, table, formula, or diagram.
"""
from __future__ import annotations

from collections import Counter, defaultdict
import re
from typing import Any, Iterable


FIGURE_PREFIXES = ("fig.", "figure ", "图")
TABLE_PREFIXES = ("table ", "表")


def _box(value: Iterable[float]) -> list[float]:
    return [round(float(item), 2) for item in value]


def _union(boxes: Iterable[Iterable[float]]) -> list[float]:
    items = [_box(box) for box in boxes]
    return [min(item[0] for item in items), min(item[1] for item in items),
            max(item[2] for item in items), max(item[3] for item in items)]


def _gap(first: Iterable[float], second: Iterable[float]) -> tuple[float, float]:
    a, b = _box(first), _box(second)
    return (max(0.0, max(a[0], b[0]) - min(a[2], b[2])),
            max(0.0, max(a[1], b[1]) - min(a[3], b[3])))


def _overlap(first: Iterable[float], second: Iterable[float]) -> float:
    a, b = _box(first), _box(second)
    return max(0.0, min(a[2], b[2]) - max(a[0], b[0]))


def _intersection_area(first: Iterable[float], second: Iterable[float]) -> float:
    a, b = _box(first), _box(second)
    return (
        max(0.0, min(a[2], b[2]) - max(a[0], b[0]))
        * max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
    )


def _close(first: Iterable[float], second: Iterable[float], distance: float = 20.0) -> bool:
    horizontal, vertical = _gap(first, second)
    # Do not bridge two nearby-but-independent objects (for example, a table in
    # the left column and a chart in the right column).  A wide page-header rule
    # or two adjacent top-row objects used to join through this condition.
    return (horizontal == 0.0 and vertical <= distance) or (vertical == 0.0 and horizontal <= 8.0)


def _caption(text: str) -> bool:
    normalized = " ".join(str(text or "").strip().lower().split())
    return normalized.startswith(FIGURE_PREFIXES)


def _table_caption(text: str) -> bool:
    normalized = " ".join(str(text or "").strip().lower().split())
    if normalized.startswith("表"):
        return True
    # ``Table 3 shows ...`` in body prose is a cross-reference, not a table
    # caption.  English captions normally separate their number from a title
    # with punctuation/parentheses, or start the title with a capital letter.
    # This remains deliberately conservative: an unrecognised caption stays
    # text flow rather than absorbing surrounding evidence as a false table.
    return bool(re.match(
        r"^(?i:table)\s+[A-Za-z0-9IVXLC]+(?:\s*[:.|-]\s*|\s*\(|\s+[A-Z]|\s*$)",
        str(text or ""),
    ))


def _subfigure_label(text: str) -> bool:
    return bool(re.match(r"^\s*\([a-z0-9]+\)\s+", str(text or ""), flags=re.IGNORECASE))


def _caption_cluster(anchor: dict[str, Any], blocks: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Keep a multi-line figure/table caption intact.

    Local extraction frequently marks only a caption's first line as a figure
    or table caption and puts its continuation back into ordinary ``text``.
    Treating that continuation as body prose clips the parent visual region
    halfway through its caption.  The continuation must share the caption's
    column and horizontal span, and must start close to the preceding line.
    """
    cluster = [anchor]
    current_bottom = _box(anchor["bbox"])[3]
    anchor_left, _, anchor_right, _ = _box(anchor["bbox"])
    anchor_width = max(1.0, anchor_right - anchor_left)
    column = anchor.get("column")
    candidates = sorted(
        (item for item in blocks if item is not anchor and item.get("column") == column),
        key=lambda item: (item["bbox"][1], item["bbox"][0]),
    )
    for item in candidates:
        left, top, right, bottom = _box(item["bbox"])
        if top < current_bottom - 1.0:
            continue
        # A real caption continuation is immediately below and has nearly the
        # same left edge and column width.  This deliberately stops before a
        # full-width body paragraph below a right-column caption: it can
        # overlap the caption horizontally while starting at a different track.
        horizontal = max(0.0, min(anchor_right, right) - max(anchor_left, left))
        left_aligned = abs(left - anchor_left) <= max(16.0, anchor_width * 0.18)
        item_width = max(1.0, right - left)
        anchor_center = (anchor_left + anchor_right) / 2.0
        item_center = (left + right) / 2.0
        # A nearby section heading can share the caption's left edge but is
        # usually much narrower.  It is not a continuation, even when the
        # vertical whitespace is small.  Keep enough tolerance for a wrapped
        # caption line while refusing narrow headings and body labels.
        same_span = (
            left_aligned
            and item_width >= anchor_width * 0.45
            and horizontal >= min(anchor_width, item_width) * 0.72
        )
        # Conference tables often print a short centred ``TABLE V`` line and
        # place the wide all-caps description directly below it.  The normal
        # left-edge rule cannot link that pair, even though their centre line
        # and vertical adjacency make the relationship unambiguous.
        centred_title_continuation = (
            anchor_width <= 90.0
            and item_width >= 150.0
            and abs(item_center - anchor_center) <= max(18.0, item_width * 0.12)
        )
        if (top - current_bottom <= 18.0 and (same_span or centred_title_continuation)
                and item.get("type") in {"text", "figure_caption", "table"}):
            cluster.append(item)
            current_bottom = max(current_bottom, bottom)
            continue
        if top > current_bottom + 18.0:
            break
    return cluster


def _native_visuals(
    pdf_path: str, page_number: int, page_width: float, page_height: float
) -> tuple[list[list[float]], list[list[float]]]:
    """Return usable vector/image rectangles without interpreting their content.

    PDFs may contain a single compound drawing with thousands of path items or
    an enormous clipping rectangle. Those records are rendering artifacts, not
    an object boundary: using them joins unrelated charts and all surrounding
    prose into one region. Keep native geometry only when its page footprint is
    plausible and it represents a reasonably local drawing.
    """
    import fitz

    document = fitz.open(pdf_path)
    try:
        page = document.load_page(page_number - 1)
        graphics: list[list[float]] = []
        for drawing in page.get_drawings():
            rect = drawing.get("rect")
            if not rect or (rect.width < 1.0 and rect.height < 1.0):
                continue
            drawing_type = str(drawing.get("type") or "")
            fill = drawing.get("fill")
            try:
                fill_opacity = float(drawing.get("fill_opacity") if drawing.get("fill_opacity") is not None else 1.0)
            except (TypeError, ValueError):
                fill_opacity = 1.0
            # A transparent or white filled rectangle is a background/clipping
            # layer, not a figure boundary. Such rectangles can span across a
            # column gutter even though visible ink exists only in one column.
            is_white_fill = isinstance(fill, (tuple, list)) and len(fill) >= 3 and min(fill[:3]) >= 0.98
            if drawing_type == "f" and (fill_opacity <= 0.01 or is_white_fill):
                continue
            item_count = len(drawing.get("items") or [])
            # Generated PDFs commonly contain giant compound clipping paths
            # (often 2,000 to 20,000 items) around a whole illustration. They
            # are not safe segmentation evidence; finer child paths remain.
            if item_count > 512:
                continue
            # Ignore paths that materially escape the physical page. A small
            # anti-aliasing overhang is normal, but a broad off-page rectangle
            # is almost always a clipping/background artifact.
            if rect.x0 < -12.0 or rect.y0 < -12.0 or rect.x1 > page_width + 12.0 or rect.y1 > page_height + 12.0:
                continue
            # Some TeX-generated bibliographies emit every hyperlink as a
            # separate, short underline path.  Joining those glyph-adjacent
            # paths creates a fake full-width "visual" over ordinary prose.
            # Keep longer table/chart rules and every non-horizontal drawing;
            # this only removes short underline fragments before components
            # have a chance to join them transitively.
            if rect.height <= 2.5 and rect.width < page_width * 0.18:
                continue
            # Running header/footer rules are page decorations, not evidence
            # connecting the independent table/chart objects below them.
            if rect.width >= page_width * 0.72 and rect.height <= 3.0:
                continue
            if rect and (rect.width >= 1.0 or rect.height >= 1.0):
                graphics.append(_box((rect.x0 - 0.75, rect.y0 - 0.75, rect.x1 + 0.75, rect.y1 + 0.75)))
        images: list[list[float]] = []
        for image in page.get_images(full=True):
            try:
                images.extend(_box((rect.x0, rect.y0, rect.x1, rect.y1)) for rect in page.get_image_rects(image[0])
                              if rect.width >= 1.0 and rect.height >= 1.0)
            except Exception:
                continue
        return graphics, images
    finally:
        document.close()


def _components(boxes: list[list[float]]) -> list[list[float]]:
    """Join nearby strokes/images into candidate visual objects.

    The threshold is intentionally small: joining normal body text across a
    column gutter is worse than reporting an unresolved visual candidate.
    """
    pending = list(boxes)
    components: list[list[float]] = []
    while pending:
        current = pending.pop(0)
        changed = True
        while changed:
            changed = False
            remaining: list[list[float]] = []
            for candidate in pending:
                if _close(current, candidate):
                    current = _union((current, candidate))
                    changed = True
                else:
                    remaining.append(candidate)
            pending = remaining
        components.append(current)
    return components


def _split_uncaptioned_repeated_image_stacks(
    components: list[list[float]], images: list[list[float]], graphics: list[list[float]],
    captions: list[dict[str, Any]], page_width: float,
) -> list[list[float]]:
    """Do not merge a vertical run of standalone photos into one diagram.

    Author-bio pages and team rosters commonly place several small headshots in
    one left-side rail.  Their gaps are comparable to a multi-panel figure, so
    a geometry-only component joiner connects the entire rail.  Without a
    Figure caption or a supporting vector drawing, that is insufficient
    evidence for one visual object.  Keep each image independently auditable.
    """
    output: list[list[float]] = []
    for component in components:
        members = [image for image in images if _covered_fraction(image, component) >= 0.98]
        has_caption = any(_near_caption(component, caption) for caption in captions)
        has_graphics = any(_intersects(component, graphic) for graphic in graphics)
        small_aligned_images = (
            len(members) >= 2
            and all(image[2] - image[0] <= page_width * 0.25 for image in members)
            and max(image[0] for image in members) - min(image[0] for image in members) <= page_width * 0.06
        )
        if small_aligned_images and not has_caption and not has_graphics:
            output.extend(members)
        else:
            output.append(component)
    return output


def _consolidate_repeated_visual_bands(components: list[list[float]], page_width: float) -> list[list[float]]:
    """Promote repeated wide visual bands to one parent candidate.

    Bar charts and heatmaps are frequently emitted as one drawing per bar or
    row.  Those marks form repeated, nearly identical horizontal bands and
    should be reviewed as one figure, not dozens of unrelated boxes.  The
    thresholds intentionally require a broad shared track and at least three
    bands, so nearby column objects and ordinary short rules stay independent.
    """
    pending = list(components)
    bands: list[tuple[list[float], list[list[float]]]] = []
    while pending:
        current = pending.pop(0)
        members = [current]
        changed = True
        while changed:
            changed = False
            remaining: list[list[float]] = []
            for candidate in pending:
                horizontal, vertical = _gap(current, candidate)
                if vertical == 0.0 and horizontal <= 12.0:
                    current = _union((current, candidate))
                    members.append(candidate)
                    changed = True
                else:
                    remaining.append(candidate)
            pending = remaining
        bands.append((current, members))

    broad = [item for item in bands if item[0][2] - item[0][0] >= page_width * 0.45]
    consumed_ids: set[int] = set()
    consolidated: list[list[float]] = []
    remaining = list(broad)
    while remaining:
        current, members = remaining.pop(0)
        cluster = list(members)
        changed = True
        while changed:
            changed = False
            kept: list[tuple[list[float], list[list[float]]]] = []
            for candidate, candidate_members in remaining:
                overlap = _overlap(current, candidate)
                narrowest = min(current[2] - current[0], candidate[2] - candidate[0])
                vertical_gap = _gap(current, candidate)[1]
                if overlap >= narrowest * 0.80 and vertical_gap <= 36.0:
                    current = _union((current, candidate))
                    cluster.extend(candidate_members)
                    changed = True
                else:
                    kept.append((candidate, candidate_members))
            remaining = kept
        if len(cluster) >= 3:
            consolidated.append(current)
            consumed_ids.update(id(item) for item in cluster)

    # Components which belong to a promoted parent must not survive as child
    # candidates; they would otherwise reintroduce the original fragmentation.
    return [item for item in components if id(item) not in consumed_ids] + consolidated


def _merge_aligned_horizontal_rules(boxes: list[list[float]]) -> list[list[float]]:
    """Merge the horizontal rules belonging to one local table or chart.

    PDF drawing APIs expose each table row rule as a separate vector path.  The
    general component joiner intentionally uses a small distance and therefore
    must not be widened just to cover a long table: doing so would join a
    left-column table to a right-column chart.  This pass is narrower.  It
    joins only thin, substantially overlapping horizontal rules with matching
    left/right edges.  A later caption or structured-text anchor decides
    whether the resulting geometry is a reliable visual region.
    """
    rules = [
        box for box in boxes
        if box[2] - box[0] >= 36.0 and box[3] - box[1] <= 4.0
    ]
    others = [box for box in boxes if box not in rules]
    pending = sorted(rules, key=lambda box: (box[0], box[2], box[1]))
    merged: list[list[float]] = []
    while pending:
        current = pending.pop(0)
        changed = True
        while changed:
            changed = False
            remaining: list[list[float]] = []
            current_width = max(1.0, current[2] - current[0])
            for candidate in pending:
                candidate_width = max(1.0, candidate[2] - candidate[0])
                overlap = _overlap(current, candidate)
                same_span = (
                    overlap >= min(current_width, candidate_width) * 0.82
                    and abs(current[0] - candidate[0]) <= 14.0
                    and abs(current[2] - candidate[2]) <= 14.0
                )
                vertical_gap = _gap(current, candidate)[1]
                if same_span and vertical_gap <= 72.0:
                    current = _union((current, candidate))
                    changed = True
                else:
                    remaining.append(candidate)
            pending = remaining
        merged.append(current)
    return others + merged


def _intersects(first: Iterable[float], second: Iterable[float]) -> bool:
    return _gap(first, second) == (0.0, 0.0)


def _near_caption(bbox: Iterable[float], caption: dict[str, Any]) -> bool:
    horizontal, vertical = _gap(bbox, caption["bbox"])
    visual_width = max(1.0, _box(bbox)[2] - _box(bbox)[0])
    caption_width = max(1.0, _box(caption["bbox"])[2] - _box(caption["bbox"])[0])
    shared_width = _overlap(bbox, caption["bbox"])
    # A caption must occupy the same horizontal track as the visual object.
    # Merely being close across the two-column gutter used to let one chart
    # claim the neighbouring chart/table caption and merge the whole page.
    same_track = shared_width >= min(visual_width, caption_width) * 0.28
    return same_track and vertical <= 78.0


def _group_structured_blocks(blocks: list[dict[str, Any]]) -> list[list[dict[str, Any]]]:
    """Group local table anchors without joining across a two-column gutter."""
    pending = sorted(blocks, key=lambda item: (item["bbox"][1], item["bbox"][0]))
    groups: list[list[dict[str, Any]]] = []
    while pending:
        group = [pending.pop(0)]
        changed = True
        while changed:
            changed = False
            remaining = []
            group_box = _union(item["bbox"] for item in group)
            for candidate in pending:
                horizontal, vertical = _gap(group_box, candidate["bbox"])
                same_band = horizontal == 0.0 and vertical <= 48.0
                if same_band:
                    group.append(candidate)
                    changed = True
                else:
                    remaining.append(candidate)
            pending = remaining
        groups.append(group)
    return groups


def _caption_anchored_text_grid(
    caption: dict[str, Any], previous_bottom: float, blocks: list[dict[str, Any]], page_width: float
) -> list[dict[str, Any]]:
    """Recover a long text-only table immediately above its printed caption.

    The local parser sometimes emits every cell of a PDF table as an ordinary
    text block.  A fixed 240pt lookback works for small tables but breaks a
    multi-page-size table into dozens of fake prose regions.  Instead, start
    at the caption and walk *upward* through an unbroken sequence of compact
    row bands.  The grid must demonstrate several horizontal cell tracks; a
    paragraph or a display equation cannot satisfy that evidence.
    """
    caption_top = _box(caption["bbox"])[1]
    candidates = [
        block for block in blocks
        if block is not caption
        and block.get("type") in {"text", "table"}
        and block["bbox"][1] >= previous_bottom - 3.0
        and block["bbox"][3] <= caption_top + 3.0
        and block["bbox"][3] - block["bbox"][1] <= 18.0
        and block["bbox"][2] - block["bbox"][0] >= 5.0
    ]
    if not candidates:
        return []

    # Rows in born-digital tables can differ by a point or two.  Group nearby
    # baselines while retaining every cell in that horizontal band.
    bands: list[list[dict[str, Any]]] = []
    for block in sorted(candidates, key=lambda item: (item["bbox"][1], item["bbox"][0])):
        if not bands or block["bbox"][1] - bands[-1][-1]["bbox"][1] > 5.0:
            bands.append([block])
        else:
            bands[-1].append(block)

    # A caption below a table needs a close last row.  Walk backwards only
    # across normal row spacing; a large blank gap is a genuine boundary that
    # stops this rule before an unrelated heading or body paragraph.
    selected: list[list[dict[str, Any]]] = []
    current_top = caption_top
    for band in reversed(bands):
        band_top = min(item["bbox"][1] for item in band)
        band_bottom = max(item["bbox"][3] for item in band)
        max_gap = 20.0 if not selected else 18.0
        if current_top - band_bottom > max_gap:
            break
        if selected:
            selected_box = _union(item["bbox"] for selected_band in selected for item in selected_band)
            band_box = _union(item["bbox"] for item in band)
            shared_track = _overlap(selected_box, band_box)
            if shared_track < min(
                selected_box[2] - selected_box[0],
                band_box[2] - band_box[0],
            ) * 0.18:
                break
        selected.append(band)
        current_top = band_top
    selected.reverse()
    if len(selected) < 4:
        return []

    grid_blocks = [item for band in selected for item in band]
    grid_box = _union(item["bbox"] for item in grid_blocks)
    # Tables provide repeated values in multiple x tracks.  Require either
    # multiple cells in two row bands, or a dense sequence of compact rows
    # spanning a material page width.  This keeps ordinary one-column prose
    # and narrow formula lists in the text flow.
    multi_cell_rows = sum(len(band) >= 3 for band in selected)
    x_tracks = {round(item["bbox"][0] / 16.0) for item in grid_blocks}
    grid_width = grid_box[2] - grid_box[0]
    dense_rows = len(selected) >= 12 and len(grid_blocks) >= len(selected) * 2
    compact_rows = sum(
        _text_length(band[0]) <= 48 and len(band) == 1 for band in selected
    ) >= max(4, int(len(selected) * 0.75))
    has_cell_tracks = len(x_tracks) >= 3 and (multi_cell_rows >= 2 or dense_rows)
    # Hyperparameter tables frequently have exactly two stable columns
    # (attribute/value).  They are still a grid when several row bands each
    # contain both cells; require more repeated rows and a material width so a
    # wrapped prose paragraph cannot take this smaller-track exception.
    two_cell_rows = sum(len(band) >= 2 for band in selected)
    has_two_track_grid = (
        len(x_tracks) >= 2
        and two_cell_rows >= 4
        and grid_width >= page_width * 0.28
    )
    # Extraction may also preserve one whole text row per table row.  Accept
    # that shape only when rows are compact and broad; ordinary prose lines
    # are long and therefore remain excluded even when their baselines align.
    has_compact_row_records = compact_rows and grid_width >= page_width * 0.45
    if grid_width < max(80.0, page_width * 0.18) or not (
        has_cell_tracks or has_two_track_grid or has_compact_row_records
    ):
        return []
    return grid_blocks


def _caption_local_structured_group(
    caption: dict[str, Any], blocks: list[dict[str, Any]], table_blocks: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """Associate one printed table title with its immediate structured cells.

    A full-width title overlaps both halves of a page.  It must never be used
    as a transitive bridge between side-by-side tables or between consecutive
    table captions.  Only accept table blocks shortly after the title which
    share its horizontal track; tables with a caption below are handled by the
    separate preceding-table path.
    """
    _, caption_top, _, caption_bottom = _box(caption["bbox"])
    group = list(_caption_cluster(caption, blocks))
    caption_box = _union(item["bbox"] for item in group)
    caption_width = max(1.0, caption_box[2] - caption_box[0])
    for block in table_blocks:
        if block is caption or _table_caption(block.get("text", "")):
            continue
        left, top, right, bottom = _box(block["bbox"])
        if top < caption_bottom - 8.0 or top - caption_bottom > 72.0:
            continue
        block_width = max(1.0, right - left)
        shared = _overlap(caption_box, block["bbox"])
        # A title usually spans at least as broadly as its grid.  The relative
        # overlap check works for both a full-width title over two panels and a
        # one-column title over one panel, while rejecting the neighbour across
        # the gutter.
        if shared >= min(caption_width, block_width) * 0.40:
            group.append(block)
    return list({id(item): item for item in group}.values())


def _limit_to_unclaimed(
    bbox: Iterable[float], body_blocks: list[dict[str, Any]], width: float, height: float, pad: float = 12.0,
) -> list[float]:
    """Add small context only through space not occupied by normal body text."""
    left, top, right, bottom = _box(bbox)
    expanded = [max(0.0, left - pad), max(0.0, top - pad), min(width, right + pad), min(height, bottom + pad)]
    for block in body_blocks:
        x0, y0, x1, y1 = _box(block["bbox"])
        expanded_box = (expanded[0], expanded[1], expanded[2], expanded[3])
        if _intersection_area(expanded_box, (x0, y0, x1, y1)) <= 0.0:
            continue
        body_area = max(1.0, (x1 - x0) * (y1 - y0))
        seed_fraction = _intersection_area((left, top, right, bottom), (x0, y0, x1, y1)) / body_area
        # Keep labels genuinely inside the component.  A prose line may touch
        # a native chart/table rule by a few pixels, however; that small
        # intersection must not prevent directional clipping of the visual
        # context box.  The old code incorrectly used horizontal overlap only,
        # which treated any same-row prose as intersecting evidence.
        if seed_fraction > 0.30:
            continue
        if y0 < top and y1 <= top + 12.0:
            expanded[1] = max(expanded[1], y1 + 3.0)
        elif y1 > bottom and y0 >= bottom - 12.0:
            expanded[3] = min(expanded[3], y0 - 3.0)
        if x0 < left and x1 <= left + 12.0:
            expanded[0] = max(expanded[0], x1 + 3.0)
        elif x1 > right and x0 >= right - 12.0:
            expanded[2] = min(expanded[2], x0 - 3.0)
    return _box(expanded)


def _is_margin_block(block: dict[str, Any], width: float, height: float) -> bool:
    """Identify page-edge vertical metadata that must not join body flow.

    ArXiv identifiers and publisher date marks are often emitted as one very
    tall, very narrow text block.  Treating them as ordinary ``full`` text
    makes their bounding box span charts and paragraphs on the page.
    """
    left, top, right, bottom = _box(block["bbox"])
    block_width = right - left
    block_height = bottom - top
    edge = left <= width * 0.08 or right >= width * 0.92
    return edge and block_width <= width * 0.12 and block_height >= height * 0.25


def _running_metadata_ids(
    pages: list[dict[str, Any]], width_by_page: dict[int, float], height_by_page: dict[int, float]
) -> set[str]:
    """Find repeated running headers/footers without treating them as prose.

    PDF text extraction commonly assigns a page header to the left column. Its
    visible line can extend into the gutter (or slightly into the right track),
    so including it in the first left-flow region produces a crop that overlaps
    the first line of the right column. Repetition across pages is stronger
    evidence than a title-like appearance alone and keeps ordinary section
    headings in the reading flow.
    """
    candidates: list[dict[str, Any]] = []
    for page in pages:
        number = int(page.get("page") or 0)
        width = width_by_page.get(number, 0.0)
        height = height_by_page.get(number, 0.0)
        if width <= 0.0 or height <= 0.0:
            continue
        for block in page.get("blocks") or []:
            if block.get("type") != "text":
                continue
            left, top, right, bottom = _box(block.get("bbox") or [])
            text = re.sub(r"\s+", " ", str(block.get("text") or "")).strip()
            if not text:
                continue
            shallow = bottom - top <= min(22.0, height * 0.045)
            at_edge = top <= height * 0.12 or bottom >= height * 0.88
            if shallow and at_edge:
                candidates.append({"block": block, "text": text.casefold()})

    counts = Counter(item["text"] for item in candidates if len(item["text"]) >= 12)
    result: set[str] = set()
    for item in candidates:
        block = item["block"]
        block_id = str(block.get("block_id") or "")
        text = item["text"]
        # Repeated titles, venue lines, and copyright notices are running
        # metadata. A lone digit at the page edge is a conventional page number.
        if counts.get(text, 0) >= 3 or re.fullmatch(r"\d{1,4}", text):
            if block_id:
                result.add(block_id)
    return result


def _text_length(block: dict[str, Any]) -> int:
    """Return the useful text length without whitespace-only PDF fragments."""
    return len(re.sub(r"\s+", "", str(block.get("text") or "")))


def _merged_vertical_coverage(blocks: list[dict[str, Any]]) -> float:
    """Measure sustained text flow without counting overlapping fragments twice."""
    intervals = sorted((_box(block["bbox"])[1], _box(block["bbox"])[3]) for block in blocks)
    if not intervals:
        return 0.0
    coverage = 0.0
    start, end = intervals[0]
    for top, bottom in intervals[1:]:
        if top <= end:
            end = max(end, bottom)
            continue
        coverage += max(0.0, end - start)
        start, end = top, bottom
    return coverage + max(0.0, end - start)


def _is_body_flow_candidate(block: dict[str, Any], width: float, height: float) -> bool:
    """Whether a block is credible evidence of a continuing prose column.

    Formula tokens, table cells, page numbers, and figure labels often appear
    in a parser's left/right tracks.  They describe local geometry, but they
    must not be allowed to prove that a page is visually two-column.
    """
    if block.get("type") != "text" or _is_margin_block(block, width, height):
        return False
    left, top, right, bottom = _box(block["bbox"])
    text_length = _text_length(block)
    # Short all-column headers can contain enough characters to meet a simple
    # length threshold, but their shallow bbox is not a prose run. Keep normal
    # paragraphs and multi-line blocks; permit a dense long line as a fallback.
    return (
        right - left >= width * 0.22
        and text_length >= 45
        and ((bottom - top) >= 12.0 or text_length >= 160)
    )


def _effective_layout(layout: str, blocks: list[dict[str, Any]], width: float, height: float) -> str:
    """Reject unsupported two-column labels using actual block geometry.

    Lists, reference pages, and table-of-contents leader lines can be split
    into left/right parser tracks even though they are one visual text column.
    A genuine two-column page needs sustained, non-overlapping evidence on
    both sides of the gutter; a handful of page-number fragments is not enough.
    """
    if layout != "two_column":
        return layout
    track_blocks = [
        block for block in blocks
        if block.get("column") in {"left", "right"}
        and not _is_margin_block(block, width, height)
    ]
    # Very small synthetic/title-only pages do not contain enough prose to
    # establish coverage. Preserve an explicit, geometrically valid two-track
    # label there rather than turning every short test page into one column.
    if len(track_blocks) <= 3:
        return layout
    candidates = [block for block in track_blocks if _is_body_flow_candidate(block, width, height)]
    midpoint = width / 2.0
    gutter = width * 0.06
    # Do not let a full-width table header, section title, or broken parser
    # track vote for a side merely because it was tagged ``right``. The blocks
    # below are both semantic prose candidates and geometrically inside their
    # declared text lanes.
    left = [
        block for block in candidates
        if block.get("column") == "left" and block["bbox"][2] <= midpoint + gutter
    ]
    right = [
        block for block in candidates
        if block.get("column") == "right" and block["bbox"][0] >= midpoint - gutter
    ]
    if not left or not right:
        return "single_column"
    left_coverage = _merged_vertical_coverage(left)
    right_coverage = _merged_vertical_coverage(right)
    def sustained(items: list[dict[str, Any]], coverage: float) -> bool:
        if len(items) >= 2:
            return True
        block = items[0]
        return _text_length(block) >= 250 and (block["bbox"][3] - block["bbox"][1]) >= height * 0.10
    # A proper pair of prose columns has both stable horizontal tracks and a
    # meaningful vertical run. A row of equations or table cells has neither.
    return (
        layout
        if min(left_coverage, right_coverage) >= height * 0.08
        and sustained(left, left_coverage)
        and sustained(right, right_coverage)
        else "single_column"
    )


def _peripheral_visual_labels(
    component: Iterable[float], blocks: list[dict[str, Any]], width: float, height: float
) -> list[dict[str, Any]]:
    """Find clustered axis/legend labels just outside a native visual object.

    A chart's rotated axis labels are commonly separate, narrow text blocks.
    They sit beyond the vector-drawing bbox, so cutting on native geometry
    alone loses the axis.  Require a cluster of four or more short, narrow
    labels on one edge: a lone equation number or nearby prose cannot satisfy
    this condition.
    """
    left, top, right, bottom = _box(component)
    component_width = right - left
    component_height = bottom - top
    if component_width < width * 0.18 and component_height < height * 0.10:
        return []
    sides: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for block in blocks:
        if block.get("type") not in {"text", "formula"} or _text_length(block) > 32:
            continue
        x0, y0, x1, y1 = _box(block["bbox"])
        block_width, block_height = x1 - x0, y1 - y0
        # Normal prose lines are broad. Axis ticks can be vertical or compact,
        # but need to be conspicuously narrower than a prose line.
        narrow = block_width <= 24.0 or (block_height <= 14.0 and block_width <= 72.0)
        if not narrow:
            continue
        horizontal_overlap = max(0.0, min(right, x1) - max(left, x0))
        vertical_overlap = max(0.0, min(bottom, y1) - max(top, y0))
        if horizontal_overlap >= min(block_width, component_width) * 0.45:
            if y0 >= bottom - 8.0 and y0 - bottom <= 108.0:
                sides["bottom"].append(block)
            elif y1 <= top + 8.0 and top - y1 <= 56.0:
                sides["top"].append(block)
        if vertical_overlap >= min(block_height, component_height) * 0.45:
            if x1 <= left + 8.0 and left - x1 <= 56.0:
                sides["left"].append(block)
            elif x0 >= right - 8.0 and x0 - right <= 56.0:
                sides["right"].append(block)
    selected: list[dict[str, Any]] = []
    for labels in sides.values():
        if len({item.get("block_id") or id(item) for item in labels}) >= 4:
            selected.extend(labels)
    return list({item.get("block_id") or id(item): item for item in selected}.values())


def _region_children(bbox: Iterable[float], blocks: list[dict[str, Any]], captions: list[dict[str, Any]]) -> list[str]:
    """Keep labels/captions inside a region, but do not absorb nearby prose."""
    children = []
    for block in blocks:
        block_box = _box(block["bbox"])
        # Running headers can overlap a chart's padded top edge. They are body
        # metadata, not a chart label, and must remain outside visual regions.
        is_wide_header = (block_box[1] <= 80.0
                          and block.get("column") == "full" and block.get("type") == "text"
                          and block_box[2] - block_box[0] >= 200.0
                          and block_box[3] <= _box(bbox)[1] + 16.0)
        intersection_width = max(0.0, min(_box(bbox)[2], block_box[2]) - max(_box(bbox)[0], block_box[0]))
        intersection_height = max(0.0, min(_box(bbox)[3], block_box[3]) - max(_box(bbox)[1], block_box[1]))
        overlap_area = intersection_width * intersection_height
        block_area = max(1.0, (block_box[2] - block_box[0]) * (block_box[3] - block_box[1]))
        # A one-pixel rule or padded visual edge can merely graze a paragraph.
        # It must not consume the paragraph from normal text flow. Captions are
        # explicitly retained even when their first line touches the boundary.
        materially_inside = overlap_area / block_area >= 0.55
        if not is_wide_header and (materially_inside or (block in captions and _near_caption(bbox, block))):
            if block.get("block_id"):
                children.append(block["block_id"])
    return children


def _iou(first: Iterable[float], second: Iterable[float]) -> float:
    a, b = _box(first), _box(second)
    intersection = max(0.0, min(a[2], b[2]) - max(a[0], b[0])) * max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
    if not intersection:
        return 0.0
    area_a = max(1.0, (a[2] - a[0]) * (a[3] - a[1]))
    area_b = max(1.0, (b[2] - b[0]) * (b[3] - b[1]))
    return intersection / (area_a + area_b - intersection)


def _covered_fraction(candidate: Iterable[float], container: Iterable[float]) -> float:
    a, b = _box(candidate), _box(container)
    intersection = max(0.0, min(a[2], b[2]) - max(a[0], b[0])) * max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
    area = max(1.0, (a[2] - a[0]) * (a[3] - a[1]))
    return intersection / area


def _component_has_image(component: Iterable[float], images: list[list[float]]) -> bool:
    """Whether a native component is backed by an embedded image rectangle."""
    return any(_intersects(component, image) or _close(component, image, 4.0) for image in images)


def _panel_neighbours(first: Iterable[float], second: Iterable[float]) -> bool:
    """Link adjacent image panels without crossing an unrelated figure track.

    A figure made from screenshots is often represented as several independent
    image XObjects.  Its panels can have normal white gutters between rows, so
    the conservative native-stroke component builder intentionally leaves them
    separate.  This relation is used only after a Figure caption has supplied
    a semantic boundary, and therefore permits a moderately larger row/column
    gap than :func:`_close`.
    """
    first_box, second_box = _box(first), _box(second)
    horizontal, vertical = _gap(first_box, second_box)
    width = min(first_box[2] - first_box[0], second_box[2] - second_box[0])
    height = min(first_box[3] - first_box[1], second_box[3] - second_box[1])
    shared_width = _overlap(first_box, second_box)
    shared_height = max(0.0, min(first_box[3], second_box[3]) - max(first_box[1], second_box[1]))
    return (
        (vertical <= 76.0 and shared_width >= max(20.0, width * 0.30))
        or (horizontal <= 28.0 and shared_height >= max(16.0, height * 0.35))
        # A panel row may intentionally start one cell later than the row
        # above it. Its nearest predecessor is then diagonal: it has a small
        # horizontal and vertical gutter but no shared projection on either
        # axis. This remains safe because callers have already required both
        # an explicit Figure caption and embedded-image evidence.
        or (horizontal <= 28.0 and vertical <= 76.0)
    )


def _captioned_image_panel_groups(
    components: list[list[float]], images: list[list[float]], caption_anchors: list[dict[str, Any]],
    blocks: list[dict[str, Any]], body_blocks: list[dict[str, Any]], width: float, height: float,
) -> list[dict[str, Any]]:
    """Recover a captioned screenshot/illustration grid as one figure region.

    A local parser may faithfully extract text *inside* a screenshot while
    PyMuPDF exposes every screenshot tile as a separate embedded image.  The
    normal visual pass treats those independent tiles as unresolved objects.
    Requiring an explicit Figure caption, at least four image-backed panels,
    a continuous row/column lattice, and a common caption track makes the
    promotion conservative.  It deliberately does not apply to vector-only
    charts or captionless images.
    """
    image_components = [component for component in components if _component_has_image(component, images)]
    if len(image_components) < 4:
        return []

    groups: list[dict[str, Any]] = []
    for caption in caption_anchors:
        caption_box = _box(caption["bbox"])
        caption_width = caption_box[2] - caption_box[0]
        # A page-wide Figure caption can own a page-wide panel grid.  A
        # column-local caption must keep every candidate on its own track so
        # two side-by-side figures remain separate.
        track_pad = min(width * 0.08, max(18.0, caption_width * 0.12))
        track = [
            max(0.0, caption_box[0] - track_pad), 0.0,
            min(width, caption_box[2] + track_pad), height,
        ]
        candidates = [
            component for component in image_components
            if _overlap(component, track) >= min(
                component[2] - component[0], track[2] - track[0]
            ) * 0.32
        ]
        # Start from the image row immediately associated with the caption,
        # then grow through demonstrated grid neighbours.  A distant image
        # elsewhere on the page cannot enter without a continuous panel path.
        selected = [component for component in candidates if _near_caption(component, caption)]
        if not selected:
            continue
        pending = [component for component in candidates if component not in selected]
        changed = True
        while changed:
            changed = False
            remaining: list[list[float]] = []
            for candidate in pending:
                if any(_panel_neighbours(candidate, member) for member in selected):
                    selected.append(candidate)
                    changed = True
                else:
                    remaining.append(candidate)
            pending = remaining
        if len(selected) < 4:
            continue
        panel_box = _union(selected)
        panel_width = panel_box[2] - panel_box[0]
        panel_height = panel_box[3] - panel_box[1]
        # A valid grid needs to meaningfully span its Figure caption and take
        # up a visible page band.  This filters repeated logos, icon rows and
        # other small decorative image groups.
        if panel_width < max(100.0, caption_width * 0.55) or panel_height < height * 0.12:
            continue
        bbox = _limit_to_unclaimed(_union([panel_box, caption_box]), body_blocks, width, height)
        groups.append({
            "kind": "visual_object",
            "bbox": bbox,
            "completeness": 0.9,
            "complete": True,
            "reason": "figure_caption_and_image_panel_grid",
            "child_block_ids": _region_children(bbox, blocks, [caption]),
        })
    return groups


def _visual_regions(pdf_path: str, page: int, blocks: list[dict[str, Any]], width: float, height: float) -> list[dict[str, Any]]:
    graphics, images = _native_visuals(pdf_path, page, width, height)
    # Parser labels alone are not enough: ordinary prose containing a figure
    # reference has occasionally been mislabelled as ``figure_caption``. An
    # explicit Figure/Fig./\u56fe prefix is the stable anchor used for geometry.
    caption_anchors = [block for block in blocks if _caption(block.get("text", ""))]
    captions = list({id(item): item for anchor in caption_anchors for item in _caption_cluster(anchor, blocks)}.values())
    components = _split_uncaptioned_repeated_image_stacks(
        _components(_merge_aligned_horizontal_rules(graphics) + images), images, graphics, caption_anchors, width,
    )
    components = _consolidate_repeated_visual_bands(components, width)
    # Formula blocks are ordinary text-flow children.  Only normal prose is a
    # blocker for visual expansion; labels inside the visual object stay usable.
    body_blocks = [block for block in blocks if block.get("type") in {"text", "formula"} and block not in captions]
    regions = _captioned_image_panel_groups(
        components, images, caption_anchors, blocks, body_blocks, width, height
    )
    for component in components:
        component_width = component[2] - component[0]
        component_height = component[3] - component[1]
        if component_width < 18.0 and component_height < 18.0:
            continue
        attached = [caption for caption in caption_anchors if _near_caption(component, caption)]
        attached = list({id(item): item for anchor in attached for item in _caption_cluster(anchor, blocks)}.values())
        # A page can contain a visual subfigure without a full Figure caption
        # on that page.  Keep its local ``(a) ...`` label only for broad visual
        # components; this avoids treating equation numbers as figure labels.
        broad_component = component_width >= width * 0.45 or component_height >= height * 0.12
        attached_labels = [
            block for block in blocks
            if broad_component and _subfigure_label(block.get("text", ""))
            and _near_caption(component, block)
        ]
        contains_image = any(_intersects(component, image) or _close(component, image, 4.0) for image in images)
        # Equation delimiters, hyperlink decorations, and vector glyph stems
        # can be tall but only a few points wide.  They are not standalone
        # visual regions.  Real tables are recovered below from their
        # structured blocks and rules, so discarding an isolated stem is safe.
        thin_stroke = min(component_width, component_height) <= 4.5 and max(component_width, component_height) <= height * 0.16
        # Uncaptioned decorative mastheads are not content regions.  A real
        # figure near a page edge retains either an image footprint or a
        # caption anchor and is therefore kept.
        header_or_footer = (
            (component[1] <= height * 0.12 and component[3] <= height * 0.18)
            or (component[1] >= height * 0.92 and component[3] >= height * 0.92)
        )
        if not attached and not contains_image and (thin_stroke or header_or_footer):
            continue
        # A short standalone horizontal rule is usually a footnote separator
        # or table rule.  It has no visual content by itself and must not make
        # an unresolved region that competes with nearby body text.
        if not attached and not contains_image and component_height <= 3.0:
            continue
        # Expand only to a demonstrated cluster of axis/legend labels. This is
        # deliberately separate from general context padding so nearby prose
        # cannot enlarge a chart simply because it is close to the drawing.
        peripheral_labels = _peripheral_visual_labels(component, blocks, width, height)
        visual_seed = _union([component] + [item["bbox"] for item in peripheral_labels])
        # The expanded label cluster can bring a distant Figure caption into
        # the normal same-track range. Re-evaluate the caption after expansion.
        if peripheral_labels:
            expanded_attached = [caption for caption in caption_anchors if _near_caption(visual_seed, caption)]
            attached = list({
                id(item): item
                for anchor in attached + expanded_attached
                for item in _caption_cluster(anchor, blocks)
            }.values())
        bbox = _union([visual_seed] + [item["bbox"] for item in attached + attached_labels])
        # Small isolated vector marks are common decorations/equation rules.
        # Keep them as unresolved candidates rather than claiming a full chart.
        area_ratio = (bbox[2] - bbox[0]) * (bbox[3] - bbox[1]) / max(1.0, width * height)
        has_caption = bool(attached)
        # ``images`` is page-scoped.  A single embedded figure must not make
        # every unrelated logo, rule, or vector glyph on that page look like a
        # substantial visual candidate.
        substantial = component_width >= width * 0.18 or component_height >= height * 0.10 or contains_image
        complete = has_caption and substantial and area_ratio < 0.78
        bbox = _limit_to_unclaimed(bbox, body_blocks, width, height)
        regions.append({
            "kind": "visual_object" if complete else "unresolved_visual",
            "bbox": _box(bbox),
            "completeness": 0.9 if complete else (0.55 if substantial else 0.3),
            "complete": complete,
            "reason": "caption_and_native_geometry" if complete else "native_geometry_without_confirmed_complete_context",
            "child_block_ids": _region_children(bbox, blocks, captions),
        })
    # A table may be pure text and rules. It is an anchor for a non-body region,
    # but formulas are intentionally absent from this path and remain in prose.
    table_caption_anchors = sorted(
        (block for block in blocks if _table_caption(block.get("text", ""))),
        key=lambda block: (block["bbox"][1], block["bbox"][0]),
    )
    table_blocks = [block for block in blocks if block.get("type") == "table"]
    for caption_index, caption in enumerate(table_caption_anchors):
        # A local parser may emit each row/cell of a large table as a separate
        # text/table block.  When a Table caption follows those rows, its
        # preceding caption creates a reliable vertical boundary: consolidate
        # every structured anchor in that interval into one parent region.
        # This is intentionally bounded by the preceding Table caption rather
        # than a page-wide distance so two separate tables cannot be joined.
        caption_width = max(1.0, caption["bbox"][2] - caption["bbox"][0])
        same_track_prior = [
            prior for prior in table_caption_anchors[:caption_index]
            if _overlap(prior["bbox"], caption["bbox"])
            >= min(caption_width, prior["bbox"][2] - prior["bbox"][0]) * 0.30
        ]
        # A left-column caption must not terminate the history for a table on
        # the right.  Use only a preceding title on the same horizontal track
        # as a local boundary for caption-below table reconstruction.
        previous_bottom = max((prior["bbox"][3] for prior in same_track_prior), default=0.0)
        preceding_tables = [
            block for block in table_blocks
            if block is not caption
            and block["bbox"][1] >= previous_bottom - 3.0
            and block["bbox"][1] <= caption["bbox"][1] + 3.0
            # A caption below a table is only evidence for cells on the same
            # horizontal track.  Adjacent tables often end at the same y
            # coordinate, so a vertical-only lookup would make both captions
            # claim both grids and emit overlapping parent regions.
            and _overlap(block["bbox"], caption["bbox"])
            >= min(
                max(1.0, block["bbox"][2] - block["bbox"][0]),
                caption_width,
            ) * 0.18
        ]
        # A parser can label most cells of a born-digital table as ordinary
        # text.  Build the caption-below grid before choosing caption
        # direction, so a tight table/caption pair is not mistaken for the
        # following table merely because that following table has explicit
        # ``table`` blocks.
        preceding_text_grid = _caption_anchored_text_grid(caption, previous_bottom, blocks, width)
        preceding_evidence = list({
            id(item): item for item in preceding_tables + preceding_text_grid
        }.values())
        preceding_tight = bool(preceding_evidence) and (
            caption["bbox"][1] - max(item["bbox"][3] for item in preceding_evidence) <= 20.0
        )
        # A caption can be printed either above or below its grid.  When there
        # are table cells immediately below it on the same track, it is an
        # above-grid caption and must not claim the preceding table merely
        # because the vertical gap is small.
        local_group = _caption_local_structured_group(caption, blocks, table_blocks)
        local_table_items = [
            item for item in local_group
            if item is not caption and item.get("type") == "table" and not _table_caption(item.get("text", ""))
        ]
        has_following_structure = bool(local_table_items)
        next_caption = table_caption_anchors[caption_index + 1] if caption_index + 1 < len(table_caption_anchors) else None
        local_belongs_to_next_caption = bool(
            next_caption and local_table_items
            and 0.0 <= next_caption["bbox"][1] - max(item["bbox"][3] for item in local_table_items) <= 28.0
            and _overlap(next_caption["bbox"], _union(item["bbox"] for item in local_table_items))
            >= min(
                next_caption["bbox"][2] - next_caption["bbox"][0],
                _union(item["bbox"] for item in local_table_items)[2] - _union(item["bbox"] for item in local_table_items)[0],
            ) * 0.30
        )
        if (
            len(preceding_evidence) >= 2
            and (preceding_tight or not has_following_structure or local_belongs_to_next_caption)
        ):
            table_top = min(block["bbox"][1] for block in preceding_evidence)
            table_bottom = max(block["bbox"][3] for block in preceding_evidence)
            table_track = _union(block["bbox"] for block in preceding_evidence)
            # Include parser text cells and local subcaptions inside the table
            # band, but not neighbouring prose outside its vertical extent.
            scoped_blocks = [
                block for block in blocks
                if block is not caption
                and block["bbox"][1] >= table_top - 8.0
                and block["bbox"][3] <= caption["bbox"][1] + 4.0
                and _overlap(block["bbox"], table_track) > 0.0
            ]
            matching = [
                component for component in components
                # A single PDF path can contain rules from several vertically
                # adjacent tables.  For a caption-below table, only accept a
                # component whose full vertical extent stays inside this
                # table's band (with a small tolerance for stroke width).
                # Otherwise a component touching the first row can pull later
                # tables into the current crop and re-add their text children.
                if component[1] >= table_top - 12.0
                and component[3] <= table_bottom + 12.0
                and (
                    _intersects(table_track, component)
                    or _close(table_track, component, 12.0)
                    or _overlap(component, table_track) >= min(
                        component[2] - component[0], table_track[2] - table_track[0]
                    ) * 0.18
                )
            ]
            seed = _union([caption["bbox"]] + [block["bbox"] for block in scoped_blocks])
            bbox = _union([seed] + matching) if matching else seed
            bbox = _limit_to_unclaimed(bbox, body_blocks, width, height, pad=4.0)
            regions.append({
                "kind": "visual_object",
                "bbox": bbox,
                "completeness": 0.92,
                "complete": True,
                "reason": (
                    "table_caption_and_text_grid"
                    if preceding_text_grid else "table_caption_and_scoped_structure"
                ),
                "child_block_ids": _region_children(bbox, blocks, captions),
            })
            continue
        # Some PDFs mark only the ``Table n`` title as a table and emit every
        # actual row as ordinary text.  The helper requires a caption-adjacent,
        # continuously spaced matrix rather than a fixed lookback distance, so
        # it can safely recover a tall table without absorbing body prose.
        text_grid_rows = preceding_text_grid
        if text_grid_rows:
            text_grid = _union(block["bbox"] for block in text_grid_rows)
            grid_width = text_grid[2] - text_grid[0]
            caption_width = caption["bbox"][2] - caption["bbox"][0]
            local_components = [
                component for component in components
                if (_intersects(text_grid, component) or _close(text_grid, component, 20.0))
            ]
            # The text grid must plausibly share the caption's horizontal
            # subject, not merely be a nearby narrow equation block.
            if grid_width >= max(80.0, caption_width * 0.55):
                seed = _union([caption["bbox"], text_grid] + local_components)
                bbox = _limit_to_unclaimed(seed, body_blocks, width, height, pad=4.0)
                regions.append({
                    "kind": "visual_object",
                    "bbox": bbox,
                    "completeness": 0.86,
                    "complete": True,
                    "reason": "table_caption_and_text_grid",
                    "child_block_ids": _region_children(bbox, blocks, captions),
                })
                continue
        # A printed table title can be above or below its grid.  Start with
        # the local parser's same-track table group, then add native rules
        # which touch that group or the title.  Do not use a page-wide distance
        # threshold: side-by-side tables are independent objects.
        group = local_group
        seed = _union(item["bbox"] for item in group)
        # A long table title may cross the gutter although the grid itself is
        # confined to one column.  Match rules to the structured grid, not to
        # the title's text extent, otherwise adjacent tables can claim each
        # other's horizontal rules.
        grid_blocks = [item for item in group if item is not caption and not _table_caption(item.get("text", ""))]
        rule_anchor = _union(item["bbox"] for item in grid_blocks) if grid_blocks else caption["bbox"]
        if grid_blocks:
            matching = [
                component for component in components
                if _intersects(rule_anchor, component) or _close(rule_anchor, component, 24.0)
            ]
        else:
            # A lone table-caption block cannot safely anchor a giant compound
            # vector path. Such paths are common in pages containing a table
            # followed by charts: accepting one because it merely touches the
            # caption merges unrelated figures into the table parent. Without
            # parser grid rows, accept only a local-size component and leave a
            # taller ambiguous object for the ordinary visual-candidate path.
            matching = [
                component for component in components
                if component[3] - component[1] <= height * 0.32
                and _near_caption(component, caption)
            ]
        if len(group) < 2 and not matching:
            continue
        bbox = _union([seed] + matching) if matching else seed
        bbox = _limit_to_unclaimed(bbox, body_blocks, width, height, pad=4.0)
        regions.append({
            "kind": "visual_object",
            "bbox": bbox,
            "completeness": 0.9 if matching else 0.72,
            "complete": bool(matching),
            "reason": "table_caption_and_same_track_structure",
            "child_block_ids": _region_children(bbox, blocks, captions),
        })
    # Remove duplicate components retained by drawing APIs that emit compound paths.
    unique: list[dict[str, Any]] = []
    for candidate in sorted(regions, key=lambda item: (not item["complete"], item["bbox"][1], item["bbox"][0])):
        candidate_children = set(candidate["child_block_ids"])
        duplicate = False
        for other in unique:
            other_children = set(other["child_block_ids"])
            explicit_tables = (
                candidate["reason"].startswith("table_caption_")
                and other["reason"].startswith("table_caption_")
            )
            # Two table titles on the same page are distinct semantic anchors.
            # Their captions can be adjacent, and their parser-cell sets may
            # share a header or a footnote.  Neither condition is evidence
            # that the tables form one crop, so never collapse explicit table
            # candidates through the generic duplicate heuristic.
            if explicit_tables:
                continue
            # An explicit caption/table-grid crop has an independent semantic
            # anchor.  Never widen it merely because an unresolved native path
            # happens to cover some of the same OCR text; that path may include
            # page rules, a neighbouring table, or a header decoration.
            if (
                candidate["reason"].startswith("table_caption_")
                or other["reason"].startswith("table_caption_")
            ):
                continue
            same_evidence = bool(candidate_children and other_children) and (
                len(candidate_children & other_children) / min(len(candidate_children), len(other_children)) >= 0.75
            )
            if same_evidence:
                # Several native vector components may claim the same parser
                # cells from different directions.  Preserve one parent and
                # widen it to the evidence union instead of showing stacked,
                # duplicate boxes in the review package.
                other["bbox"] = _union((other["bbox"], candidate["bbox"]))
                other["child_block_ids"] = sorted(other_children | candidate_children)
                duplicate = True
                break
            # A compound figure may be emitted as a large captioned chart
            # plus an overlapping uncaptioned legend/subplot component. The
            # latter can have different OCR children, so evidence-set matching
            # alone is insufficient. When most of that unresolved component is
            # already inside one captioned figure, extend the figure instead of
            # presenting two competing crops to downstream review.
            if (
                not candidate["complete"]
                and other["complete"]
                and other["reason"] == "caption_and_native_geometry"
                and _covered_fraction(candidate["bbox"], other["bbox"]) >= 0.45
            ):
                other["bbox"] = _union((other["bbox"], candidate["bbox"]))
                other["child_block_ids"] = sorted(other_children | candidate_children)
                duplicate = True
                break
            if (_iou(candidate["bbox"], other["bbox"]) >= 0.72
                    or _covered_fraction(candidate["bbox"], other["bbox"]) >= 0.85):
                duplicate = True
                break
        if duplicate:
            continue
        unique.append(candidate)
    # A duplicate merge can widen a captioned figure to include a legend or
    # subplot. Recompute children against the final bbox so small labels in
    # that newly admitted extent are not left behind as overlapping prose.
    for region in unique:
        region["child_block_ids"] = sorted(set(region["child_block_ids"]) | set(
            _region_children(region["bbox"], blocks, captions)
        ))
    explicit_tables = [
        region for region in unique if region["reason"].startswith("table_caption_")
    ]
    filtered: list[dict[str, Any]] = []
    for region in unique:
        if region["reason"] != "native_geometry_without_confirmed_complete_context":
            filtered.append(region)
            continue
        candidate_area = max(
            1.0,
            (region["bbox"][2] - region["bbox"][0]) * (region["bbox"][3] - region["bbox"][1]),
        )
        table_coverage = sum(
            _intersection_area(region["bbox"], table["bbox"])
            for table in explicit_tables
        ) / candidate_area
        # A table's vector rules may be emitted as one compound component. Once
        # caption-anchored table regions account for nearly all of that box,
        # retaining an additional unresolved visual only creates a competing
        # crop.  A distinct chart/diagram is not removed unless table regions
        # actually cover most of its physical area.
        if table_coverage >= 0.75:
            continue
        filtered.append(region)
    return filtered


def _flow_regions(
    blocks: list[dict[str, Any]], consumed: set[str], page_width: float,
    visual_bboxes: list[list[float]] | None = None,
    page_height: float | None = None,
    running_metadata: set[str] | None = None,
) -> list[dict[str, Any]]:
    running_metadata = running_metadata or set()
    remaining = [block for block in blocks if block.get("block_id") not in consumed]
    visual_bboxes = visual_bboxes or []
    page_height = float(page_height or 792.0)
    # Keep page-edge vertical metadata auditable, but outside normal reading
    # flow.  Its tall bbox must never inflate a body region through a chart.
    marginal = [
        block for block in remaining
        if _is_margin_block(block, page_width, page_height)
        or str(block.get("block_id") or "") in running_metadata
    ]
    remaining = [block for block in remaining if block not in marginal]
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for block in remaining:
        column = str(block.get("column") or "unknown")
        groups[column].append(block)
    output: list[dict[str, Any]] = []
    for block in marginal:
        output.append({
            "kind": "marginal_text",
            "bbox": _box(block["bbox"]),
            "completeness": 1.0,
            "complete": True,
            "reason": "page_edge_metadata",
            "child_block_ids": [block.get("block_id")] if block.get("block_id") else [],
        })
    for column, group in groups.items():
        ordered = sorted(group, key=lambda item: (item["bbox"][1], item["bbox"][0]))
        current: list[dict[str, Any]] = []
        for block in ordered:
            if current:
                previous = current[-1]
                vertical = max(0.0, block["bbox"][1] - previous["bbox"][3])
                compatible = _overlap(block["bbox"], previous["bbox"]) >= min(24.0, (previous["bbox"][2] - previous["bbox"][0]) * 0.2)
                previous_width = previous["bbox"][2] - previous["bbox"][0]
                block_width = block["bbox"][2] - block["bbox"][0]
                horizontal_gap, _ = _gap(previous["bbox"], block["bbox"])
                # Math-heavy PDFs often expose a line as several small text
                # blocks (operator, subscript, equation number).  They are
                # still one local reading-flow unit when they occupy the same
                # row and are physically close.  Do not require horizontal
                # overlap for those short fragments, but keep the allowance
                # narrow enough that separate columns cannot be bridged.
                short_fragment_bridge = (
                    vertical <= 20.0
                    and min(previous_width, block_width) <= 82.0
                    and horizontal_gap <= 56.0
                )
                midpoint = page_width / 2.0
                gutter = page_width * 0.06
                def geometric_track(item: dict[str, Any]) -> str:
                    x0, _, x1, _ = _box(item["bbox"])
                    width = x1 - x0
                    if width >= page_width * 0.66:
                        return "full"
                    if x1 <= midpoint + gutter:
                        return "left"
                    if x0 >= midpoint - gutter:
                        return "right"
                    return "full"
                # Track transitions in a globally full-width page are only
                # meaningful when an actual visual object occupies the other
                # part of that horizontal band.  Without this guard, a short
                # heading at the left edge of an ordinary paragraph creates a
                # false full-to-left transition and fragments a text-only page.
                visual_context = any(
                    visual[1] <= block["bbox"][3] + 36.0
                    and visual[3] >= block["bbox"][1] - 36.0
                    for visual in visual_bboxes
                )
                # A mixed-layout page may be globally labelled single-column
                # because only one text column surrounds a figure.  Preserve
                # the local transition from a header/full-width paragraph to
                # the adjacent narrow text track instead of drawing one box
                # through the figure.
                track_change = (
                    column == "full"
                    and previous.get("type") == "text" and block.get("type") == "text"
                    and visual_context
                    and min(previous_width, block_width) >= page_width * 0.20
                    and geometric_track(previous) != geometric_track(block)
                )
                # A text flow can already cover a full-width band before a
                # right-side figure leaves only a narrow left text track.  The
                # immediately preceding item may be a short section heading,
                # so compare against the accumulated flow as well.  Without
                # this break, one rectangular region spans across the figure.
                current_flow_box = _union(item["bbox"] for item in current)
                accumulated_width = current_flow_box[2] - current_flow_box[0]
                full_flow_to_narrow_track = (
                    column == "full"
                    and block.get("type") == "text"
                    and visual_context
                    and accumulated_width >= page_width * 0.66
                    and block_width >= page_width * 0.25
                    and geometric_track(block) != "full"
                )
                # A single-column proof may alternate a narrow equation line,
                # a right-aligned number, and normal prose.  They remain one
                # reading flow even without horizontal overlap.  This does not
                # apply to left/right tracks, so it cannot join two columns.
                same_full_flow = column == "full" and vertical <= 42.0
                # Keep a text-flow rectangle from spanning through a chart or
                # table that happens to sit beside it.  The words remain in
                # order, but the visual object gets a separate parent region.
                crosses_visual = any(_intersects(block["bbox"], visual) for visual in visual_bboxes)
                if (vertical > 42.0 or crosses_visual or track_change
                        or full_flow_to_narrow_track
                        or not (compatible or short_fragment_bridge or same_full_flow)):
                    output.append(_make_flow(current, column, page_width))
                    current = []
            current.append(block)
        if current:
            output.append(_make_flow(current, column, page_width))
    # PDF text extraction often exposes one physical line as a main run plus
    # detached equation numbers, superscripts, or table-cell remnants. The
    # sequential flow builder cannot always see the later wide run while it is
    # deciding what to do with the first tiny fragment. Coalesce only regions
    # from the same explicit track which overlap vertically and are line-sized;
    # never cross a detected visual parent.
    coalesced: list[dict[str, Any]] = []
    for region in output:
        merged = False
        if region["reason"] == "local_text_flow":
            for existing in reversed(coalesced):
                if existing["reason"] != "local_text_flow" or existing["kind"] != region["kind"]:
                    continue
                _, vertical_gap = _gap(existing["bbox"], region["bbox"])
                existing_height = existing["bbox"][3] - existing["bbox"][1]
                region_height = region["bbox"][3] - region["bbox"][1]
                same_row = vertical_gap == 0.0 and min(existing_height, region_height) <= 24.0
                if not same_row:
                    continue
                union = _union((existing["bbox"], region["bbox"]))
                if any(_intersects(union, visual) for visual in visual_bboxes):
                    continue
                existing["bbox"] = union
                existing["child_block_ids"] = list(dict.fromkeys(
                    existing["child_block_ids"] + region["child_block_ids"]
                ))
                merged = True
                break
        if not merged:
            coalesced.append(region)
    return coalesced


def _clip_text_flow_from_uncaptioned_small_visuals(
    blocks: list[dict[str, Any]], visuals: list[dict[str, Any]], page_width: float
) -> list[dict[str, Any]]:
    """Remove a small uncaptioned image rail from an over-wide text bbox.

    Some PDF text extractors return an author photograph plus the adjacent bio
    as one text block although the image contains no selectable text.  The
    chunker keeps the source ID and text intact, but narrows the geometry of
    that flow block so it does not overlap the independently reviewable image.
    """
    image_rails = [
        visual["bbox"] for visual in visuals
        if visual["kind"] == "unresolved_visual"
        and not visual.get("child_block_ids")
        and visual["bbox"][2] - visual["bbox"][0] <= page_width * 0.25
        and visual["bbox"][3] - visual["bbox"][1] >= 36.0
    ]
    output: list[dict[str, Any]] = []
    for block in blocks:
        if block.get("type") != "text":
            output.append(block)
            continue
        x0, y0, x1, y1 = _box(block["bbox"])
        replacement = None
        for rail in image_rails:
            overlap = _intersection_area((x0, y0, x1, y1), rail)
            rail_area = max(1.0, (rail[2] - rail[0]) * (rail[3] - rail[1]))
            if (
                overlap / rail_area >= 0.50
                and rail[0] <= x0 + (x1 - x0) * 0.25
                and x1 - rail[2] >= page_width * 0.12
            ):
                replacement = [min(x1 - 24.0, rail[2] + 4.0), y0, x1, y1]
                break
        output.append({**block, "bbox": _box(replacement)} if replacement else block)
    return output


def _make_flow(blocks: list[dict[str, Any]], column: str, page_width: float) -> dict[str, Any]:
    bbox = _union(block["bbox"] for block in blocks)
    # Preserve the parser's track assignment even when leader dots or a page
    # number make a right-column bbox physically wide.  The previous width
    # fallback relabelled such regions as full-width and broke page ordering.
    kind = "full_width" if column == "full" else f"{column}_column"
    return {"kind": kind, "bbox": bbox, "completeness": 1.0, "complete": True,
            "reason": "local_text_flow", "child_block_ids": [block.get("block_id") for block in blocks if block.get("block_id")]}


def _order_regions(regions: list[dict[str, Any]], layout: str, page_width: float) -> tuple[list[dict[str, Any]], float, str]:
    if layout != "two_column":
        return sorted(regions, key=lambda item: (item["bbox"][1], item["bbox"][0])), 0.95, "top_to_bottom"
    midpoint = page_width / 2.0
    gutter = page_width * 0.06

    def track(item: dict[str, Any]) -> str:
        left, _, right, _ = _box(item["bbox"])
        # Text flow already carries a reliable column assignment. Visual
        # regions need geometric assignment so a right-column plot does not
        # become a fake full-width interruption merely because it is not text.
        if item["kind"] == "left_column" or right <= midpoint + gutter:
            return "left"
        if item["kind"] == "right_column" or left >= midpoint - gutter:
            return "right"
        return "full"

    left = [item for item in regions if track(item) == "left"]
    right = [item for item in regions if track(item) == "right"]
    full = sorted((item for item in regions if track(item) == "full"),
                  key=lambda item: (item["bbox"][1], item["bbox"][0]))

    # A two-column page can contain several distinct vertical layout bands:
    # header, columns, a spanning figure/table, then columns again.  The old
    # implementation emitted every left region, then every right region, and
    # appended all spanning regions at the end.  Split columns at each actual
    # spanning region instead, retaining left-then-right only inside a band.
    ordered: list[dict[str, Any]] = []
    pending_left = sorted(left, key=lambda item: item["bbox"][1])
    pending_right = sorted(right, key=lambda item: item["bbox"][1])
    for boundary in full:
        boundary_top = boundary["bbox"][1]
        before_left = [item for item in pending_left if item["bbox"][1] < boundary_top - 2.0]
        before_right = [item for item in pending_right if item["bbox"][1] < boundary_top - 2.0]
        ordered.extend(before_left)
        ordered.extend(before_right)
        pending_left = [item for item in pending_left if item not in before_left]
        pending_right = [item for item in pending_right if item not in before_right]
        ordered.append(boundary)
    ordered.extend(pending_left)
    ordered.extend(pending_right)
    interleaved = bool(full and (left or right))
    return ordered, 0.72 if interleaved else 0.86, (
        "vertical_bands_left_then_right_with_spanning_regions" if interleaved
        else "left_column_then_right_column"
    )


def build_document_chunks(pdf_path: str, parsed: dict[str, Any]) -> dict[str, Any]:
    """Build a conservative, page-scoped region tree from local PDF evidence."""
    page_records = {int(item.get("page")): item for item in parsed.get("pages") or []}
    by_page: dict[int, list[dict[str, Any]]] = defaultdict(list)
    for block in parsed.get("layout_blocks") or []:
        if block.get("page"):
            by_page[int(block["page"])].append(block)
    page_widths = {
        page_number: float(record.get("width") or 612.0)
        for page_number, record in page_records.items()
    }
    page_heights = {
        page_number: float(record.get("height") or 792.0)
        for page_number, record in page_records.items()
    }
    running_metadata = _running_metadata_ids(
        [
            {"page": page_number, "blocks": blocks}
            for page_number, blocks in by_page.items()
        ],
        page_widths,
        page_heights,
    )
    pages = []
    for page_number in range(1, int(parsed.get("page_count") or 0) + 1):
        page = page_records.get(page_number, {})
        blocks = by_page.get(page_number, [])
        width, height = float(page.get("width") or 612.0), float(page.get("height") or 792.0)
        parser_layout = str(page.get("layout") or "layout_uncertain")
        effective_layout = _effective_layout(parser_layout, blocks, width, height)
        # The parser's track label is useful evidence, but it is not itself a
        # page-layout fact.  When the geometry rejects a false two-column
        # classification, feed one normalized full-width flow into every
        # downstream stage.  Leave the original parse record untouched so the
        # audit package can show both the parser label and the decision made
        # by the chunker.
        effective_blocks = (
            [
                {**block, "column": "full"}
                if block.get("column") in {"left", "right"} else block
                for block in blocks
            ]
            if parser_layout == "two_column" and effective_layout == "single_column"
            else blocks
        )
        visuals = _visual_regions(pdf_path, page_number, effective_blocks, width, height)
        consumed = {child for region in visuals for child in region["child_block_ids"]}
        flow_blocks = _clip_text_flow_from_uncaptioned_small_visuals(effective_blocks, visuals, width)
        regions = visuals + _flow_regions(
            flow_blocks, consumed, width, [region["bbox"] for region in visuals], height,
            running_metadata,
        )
        ordered, confidence, strategy = _order_regions(
            regions, effective_layout, width
        )
        region_records = []
        for index, region in enumerate(ordered, 1):
            region_records.append({"region_id": f"p{page_number}-r{index}", "page": page_number,
                                   "order": index, **region})
        pages.append({"page": page_number, "width": width, "height": height,
                      "layout": effective_layout, "parser_layout": parser_layout,
                      "regions": region_records,
                      "reading_order_confidence": round(confidence, 2), "reading_order_strategy": strategy})
    return {"format": "sciassistant_pdf_chunks/v1", "page_count": len(pages), "pages": pages,
            "regions": [region for page in pages for region in page["regions"]]}
