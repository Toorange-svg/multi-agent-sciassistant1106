@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo 仅重启本项目 5000。请先停止提交任务；共享 MCP 不会停止。
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0bin\windows\start_chat_5000.ps1" -RestartGateway
set EXIT_CODE=%ERRORLEVEL%
if not "%EXIT_CODE%"=="0" echo 安全检查拒绝或启动失败。不会自动强杀其他服务。
pause
endlocal & exit /b %EXIT_CODE%
