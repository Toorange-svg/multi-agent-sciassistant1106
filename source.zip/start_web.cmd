@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0bin\windows\start_web.ps1"
set WEB_EXIT=%ERRORLEVEL%
endlocal & exit /b %WEB_EXIT%
