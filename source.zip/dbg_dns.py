﻿import sys, os, tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest import mock
sys.path.insert(0, "deepdiver_v2"); sys.path.insert(0, ".")
from deepdiver_v2.cli import demo

DNS_ERROR = ("HTTPSConnectionPool(host='zenodo.org', port=443): Max retries exceeded with url: /api/records?q=LoRA+QLoRA&size=3 (Caused by NameResolutionError(\"HTTPSConnection(host='zenodo.org', port=443): Failed to resolve 'zenodo.org' ([Errno 11004] getaddrinfo failed)\"))")

def _cfg():
    return SimpleNamespace(get_custom_llm_config=lambda: {"url": "", "token": "", "timeout": 20}, model_name="offline-test")

zenodo_calls = []
def fake_arxiv_search(search_query, max_results=5):
    return SimpleNamespace(success=True, data={"papers": []}, error=None, metadata={"warnings": []})
def fake_search_source(source, adapter_query, limit=3):
    if source == "zenodo":
        zenodo_calls.append(adapter_query)
        return {"status": "source_unreachable", "papers": [], "error": DNS_ERROR}
    if source == "hal":
        return {"status": "ok", "papers": [], "error": None}
    return {"status": "ok", "papers": [], "error": None}
tools = SimpleNamespace(arxiv_cooldown_remaining=None, arxiv_search=fake_arxiv_search)

with tempfile.TemporaryDirectory() as tmp:
    env = {"SCIASSISTANT_DIAGNOSTICS_PATH": str(Path(tmp)/"d.jsonl"), "MODEL_REQUEST_URL": "", "MODEL_REQUEST_TOKEN": ""}
    with mock.patch.dict(demo.CONVERSATION_CONTEXT, {"status": "none"}, clear=True), \
         mock.patch.dict(os.environ, env, clear=False), \
         mock.patch.object(demo, "get_config", return_value=_cfg()), \
         mock.patch.object(demo, "search_source", side_effect=fake_search_source), \
         mock.patch.object(demo, "source_skip_reason", return_value=""), \
         mock.patch.object(demo, "put_literature_cache", return_value=None):
        _, diag, _ = demo._search_relevant_literature("LoRA 与 QLoRA 的核心差异是什么？", "arxiv", tools, config=None)

print("zenodo_calls:", zenodo_calls)
for item in diag.get("rounds") or []:
    if item["source"] == "zenodo":
        print("zenodo round:", item["round"], "| status:", item.get("source_status"), "| err:", (item.get("search_error") or "")[:80])
print("stop_reason:", diag.get("stop_reason"), "| search_failed:", diag.get("search_failed"))
