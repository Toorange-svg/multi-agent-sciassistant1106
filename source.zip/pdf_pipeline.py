"""Page-aware PDF extraction and retrieval utilities for SciAssistant."""

import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Any, Dict, List, Optional


# Disk cache for parse results. The key is the PDF's own content hash plus
# the OCR flag and a pipeline version, so a parser change or a different
# mode invalidates old entries instead of silently reusing them. Failed
# parses are never cached: a transient failure must retry on the next call.
PDF_PARSE_CACHE_VERSION = "v4-inline-fragment-order"
PDF_PARSE_CACHE_DIR = Path(os.getenv("PDF_PARSE_CACHE_DIR", str(Path(__file__).resolve().parent / "logs" / "pdf_parse_cache")))
PDF_PARSE_CACHE_MAX_BYTES = 64 * 1024 * 1024


def _bounded_env_int(name: str, default: int, maximum: int) -> int:
    """Read a positive resource limit without allowing invalid/unbounded values."""
    try:
        value = int(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        return default
    if value <= 0:
        return default
    return min(value, maximum)


PDF_PARSE_MAX_PAGES = _bounded_env_int("SCIASSISTANT_PDF_MAX_PAGES", 1000, 5000)
PDF_PARSE_MAX_TEXT_CHARS = _bounded_env_int(
    "SCIASSISTANT_PDF_MAX_TEXT_CHARS", 5_000_000, 20_000_000
)
PDF_PARSE_MAX_OCR_PAGES = _bounded_env_int("SCIASSISTANT_PDF_MAX_OCR_PAGES", 50, 200)
PDF_PARSE_MAX_TABLE_OCR_CHECKS = _bounded_env_int(
    "SCIASSISTANT_PDF_MAX_TABLE_OCR_CHECKS", 20, 100
)
PDF_PARSE_OCR_PAGE_TIMEOUT_SECONDS = _bounded_env_int(
    "SCIASSISTANT_PDF_OCR_PAGE_TIMEOUT_SECONDS", 30, 120
)
PDF_PARSE_OCR_TOTAL_TIMEOUT_SECONDS = _bounded_env_int(
    "SCIASSISTANT_PDF_OCR_TOTAL_TIMEOUT_SECONDS", 300, 900
)
PDF_PARSE_TABLE_OCR_TOTAL_TIMEOUT_SECONDS = _bounded_env_int(
    "SCIASSISTANT_PDF_TABLE_OCR_TOTAL_TIMEOUT_SECONDS", 120, 600
)
PDF_PARSE_MAX_RENDER_PIXELS = _bounded_env_int(
    "SCIASSISTANT_PDF_MAX_RENDER_PIXELS", 25_000_000, 100_000_000
)


def _clean_text(raw_text: str) -> str:
    cleaned = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', raw_text or '')
    cleaned = cleaned.replace('\r\n', '\n').replace('\r', '\n')
    return re.sub(r'\n{4,}', '\n\n\n', cleaned).strip()


_MOJIBAKE_MARKER_FRAGMENTS = (
    '\u951f\u65a4\u62f7',   # 锟斤拷 (classic UTF-8-as-GBK mojibake)
    '\u00e2\u20ac',         # â€... (UTF-8 quote/dash read as cp1252)
    '\u00c3',               # Ã... (UTF-8 Latin-1 letter read as cp1252)
    '\u00c2',               # Â (UTF-8 C2 lead read as cp1252)
    '\u92a5',               # 鈥 (UTF-8 right quote read as GBK)
    '\u953b',               # 锛 (UTF-8 full-width comma read as GBK)
    '\u951f',               # 锟 (UTF-8 FFFD/BOM read as GBK)
    '\u9538',               # 锘 (UTF-8 BOM read as GBK)
    '\u93c2',               # 鏂 (common GBK-misread fragment)
    '\u93c4',               # 鏄
    '\u6d93',               # 涓
    '\u9422',               # 鐢
    '\u94a8',               # 鐨
)
_WESTERN_MOJIBAKE_RE = re.compile(r'\u00c3|\u00c2|\u00e2\u20ac')


def _mojibake_score(text: str) -> int:
    '''Count suspicious mojibake signals: replacement chars, private-use glyphs, known fragments.'''
    if not text:
        return 0
    score = text.count('\ufffd') * 3
    score += len(re.findall(r'[\ue000-\uf8ff]', text)) * 2
    for marker in _MOJIBAKE_MARKER_FRAGMENTS:
        score += text.count(marker)
    return score


def _repair_mojibake(text: str):
    '''Best-effort lossless repair of UTF-8 decoded with the wrong encoding.

    Returns (repaired_text, encoding_pair) or (None, None). A candidate is only
    accepted when the full strict round trip is lossless and the result is
    strictly cleaner, so valid text is never rewritten by accident.
    '''
    if _mojibake_score(text) <= 0 and not any('\u4e00' <= ch <= '\u9fff' for ch in text):
        return None, None
    for wrong_enc in ('gb18030', 'gbk', 'cp1252', 'latin-1'):
        try:
            raw = text.encode(wrong_enc, errors='strict')
            restored = raw.decode('utf-8', errors='strict')
        except (UnicodeEncodeError, UnicodeDecodeError):
            continue
        if restored == text or '\ufffd' in restored or _mojibake_score(restored) > 0:
            continue
        try:
            roundtrip = restored.encode('utf-8', errors='strict').decode(wrong_enc, errors='strict')
        except (UnicodeEncodeError, UnicodeDecodeError):
            continue
        if roundtrip != text:
            continue
        has_cjk = any('\u4e00' <= ch <= '\u9fff' for ch in restored)
        if has_cjk or _WESTERN_MOJIBAKE_RE.search(text):
            return restored, '%s->utf-8' % wrong_enc
    return None, None


def _pdfminer_page_texts(path: Path) -> Dict[int, str]:
    '''Cross-engine page texts from pdfminer.six, used only as a mojibake fallback.'''
    try:
        from pdfminer.high_level import extract_pages
        from pdfminer.layout import LTTextContainer
    except Exception:
        return {}
    texts = {}
    try:
        for page_number, layout in enumerate(extract_pages(str(path)), 1):
            parts = [item.get_text() for item in layout if isinstance(item, LTTextContainer)]
            texts[page_number] = _clean_text('\n'.join(parts))
    except Exception:
        return {}
    return texts


def _apply_encoding_recovery(records: List[Dict[str, Any]], path: Path) -> None:
    '''P1: repair mojibake page text; use pdfminer.six when PyMuPDF output is not repairable.

    Mutates ``records`` in place: sets ``text_source`` to 'pymupdf',
    'encoding-repaired:<pair>', or 'pdfminer-fallback'.
    '''
    suspicious = [rec for rec in records if _mojibake_score(rec.get('text') or '') > 0]
    if not suspicious:
        return
    pdfminer_texts = _pdfminer_page_texts(path)
    for rec in records:
        text = rec.get('text') or ''
        score = _mojibake_score(text)
        if score <= 0:
            continue
        repaired, pair = _repair_mojibake(text)
        if repaired is not None:
            rec['text'] = repaired
            rec['text_source'] = 'encoding-repaired:%s' % pair
            rec['char_count'] = len(repaired)
            continue
        alt = (pdfminer_texts.get(rec.get('page')) or '').strip()
        alt_score = _mojibake_score(alt)
        if alt and alt_score < score and len(alt) >= max(20, len(text.strip()) // 2):
            rec['text'] = alt
            rec['text_source'] = 'pdfminer-fallback'
            rec['char_count'] = len(alt)


def _format_pages(pages: List[Dict[str, Any]]) -> str:
    return '\n\n'.join(
        f"[[page={page['page']}]]\n{page['text']}"
        for page in pages
        if page.get('text')
    )


def _is_table_caption_line(line: str) -> bool:
    """True for a real table caption line, not a body reference like 'Table 2.1 shows ...'."""
    match = _TABLE_CAPTION_RE.match(line or '')
    if not match:
        return False
    rest = line[match.end():].strip()
    if not rest:
        return True
    if rest[0] in ':?.?':
        return True
    if len(rest) <= 50 and rest.isupper():
        return True
    if _TABLE_REFERENCE_VERBS_RE.match(rest):
        return False
    return not re.search(r'\.\s+[A-Z]', rest)


def _table_caption_id(line: str) -> Optional[str]:
    match = _TABLE_CAPTION_RE.match(line or '')
    if not match:
        return None
    return 'table-%s' % match.group(2).lower()


def _block_caption_id(block: Dict[str, Any]) -> Optional[str]:
    for line in (block.get('text') or '').splitlines():
        caption_id = _table_caption_id(line.strip())
        if caption_id:
            return caption_id
    return None


def _is_table_caption(text: str) -> bool:
    return any(_is_table_caption_line(line.strip()) for line in (text or '').splitlines() if line.strip())


def _is_figure_caption_line(line: str) -> bool:
    return bool(re.search(r'(?i)^\s*(fig(?:ure)?\.?|\u56fe)\s*\d+', line or ''))


def _is_figure_caption(text: str) -> bool:
    return any(_is_figure_caption_line(line.strip()) for line in (text or '').splitlines() if line.strip())


def _is_body_sentence(text: str) -> bool:
    """Conservative guard rejecting prose paragraphs/lists as formula or table stacks."""
    stripped = (text or '').strip()
    if not stripped:
        return True
    if re.match(r'^\s*[\u2022\u00b7\-\*]\s', stripped):
        return True
    if re.search(r'(?i)https?://|www\.|commoncrawl|github\.com', stripped):
        return True
    compact = re.sub(r'\s+', '', stripped)
    if len(compact) > 220:
        return True
    if re.match(r'^[A-Z][a-z]+\b', stripped) and re.search(r'\.\s+[a-z]', stripped):
        return True
    if re.match(r'^[a-z]', stripped) and stripped.endswith('.') and len(stripped) > 20:
        return True
    if len(stripped) > 60 and re.search(
        r'\b(the|we|this|that|these|those|which|where|when|how|and|but|for|with|from|'
        r'results|section|figure|table|shown|shows|note|e\.g\.|i\.e\.|respectively|however|'
        r'therefore|moreover|furthermore|consequently|such as|in order to|one of|we can|we use|'
        r'we report|is done|used to|allows|require|requires|describe|describes|present|presents|'
        r'provide|provides|show|summarize|summarizes|example|examples|setting|method|methods|'
        r'model|models|task|tasks|dataset|datasets|performance|accuracy|score|scores)\b',
        stripped, re.I):
        return True
    return False


_REFERENCE_HINT_RE = re.compile(
    r'(?i)arxiv preprint|coRR, abs/|doi\s*:|https?://|'
    r'in proceedings (of|at|the) |proceedings of the (?:ieee|acm|international)|'
    r'et al\.|pages?\s+[\d\u2013\u2014\-–,]+\s*(?:,|$)|'
    r'\b(?:ieee|acm|neurips|icml|iclr|iccv|cvpr|eccv|acl|emnlp|naacl|coling|'
    r'journal|springer|wiley|elsevier|mit press)\b|'
    r'\b(?:conference|workshop|symposium|transactions?|proceedings)\b|'
    r'\b(?:19|20)\d{2}[,.)]?\s*$|'
    r'\barxiv\b|\d+\(\d+\):\s*\d+[\u2013\u2014-]\d+'
)
_AUTHOR_NAME_RE = re.compile(
    r"^[A-Z][A-Za-z.\u00c0-\u017f'\-]*(?:\s+[A-Z][A-Za-z.\u00c0-\u017f'\-]*"
    r"[\d*\u2217\u2020\u2021,]*)+"
    r"\s*[\d*\u2217\u2020\u2021\u00b9\u00b2\u00b3,]*$"
)
_AFFILIATION_KEYWORD_RE = re.compile(
    r'(?i)@|\b(?:research|university|institute|department|college|laboratory|lab|academy|'
    r'technologies?|corp\.|inc\.|google|microsoft|meta|openai|facebook|stanford|berkeley|'
    r'princeton|toronto|mit|eth|epfl|max planck|inria|caltech|tsinghua|peking|fudan|'
    r'zhejiang|nju|hku|cuhk|nus|deepmind|brain)\b'
)
_FUNDING_HINT_RE = re.compile(
    r'(?i)was supported|is supported|are supported|supported in part|under grant|grant no\.?|'
    r'foundation|funded by|acknowledg\w*|this work was|this project was'
)


def _is_reference_list(text: str) -> bool:
    '''True for bibliography/reference blocks that must not become tables.

    Handles both numbered ([1] Author, ...) and author-year (Ma, S., et al. ...)
    styles, including two-line-per-entry layouts where continuation lines do not
    start with a bracket. The 60% threshold keeps body text with a stray "et al."
    or "In Proceedings" mention from being suppressed.
    '''
    entries = [line for line in (text or '').splitlines() if line.strip()]
    if len(entries) < 2:
        return False
    ref_entries = 0
    hard_markers = 0
    for line in entries:
        if re.match(r'^\s*\[[^\]]+\]\s+[A-Z]', line):
            ref_entries += 1
            hard_markers += 1
        elif re.search(r'(?i)\barxiv\b|doi\s*:|coRR, abs/', line):
            ref_entries += 1
            hard_markers += 1
        elif re.search(r'(?i)et al\.|in proceedings|proceedings of the', line):
            ref_entries += 1
            hard_markers += 1
        elif re.search(_REFERENCE_HINT_RE, line):
            ref_entries += 1
    ratio = ref_entries / len(entries)
    if hard_markers >= 2 and ratio >= 0.4:
        return True
    return ratio >= 0.6


def _is_author_or_affiliation_block(text: str) -> bool:
    '''True for arXiv author/affiliation/email blocks that must not become tables.

    Requires most lines to be multi-word capitalized names (with optional
    affiliation markers such as superscript digits, asterisks or daggers),
    affiliation keywords or email addresses. Single-word label stacks used by
    real word-list tables (Atheism/Buddhism/...) do not match the name pattern.
    '''
    lines = [line for line in (text or '').splitlines() if line.strip()]
    if not lines:
        return False
    if len(lines) == 1:
        stripped = lines[0].strip()
        # Single-line author lists ("Ze Liu* Yutong Lin* ...") or email addresses.
        if _AUTHOR_NAME_RE.match(stripped) and re.search(r'[\d*\u2217\u2020\u2021]', stripped):
            return True
        if re.search(r'[\w.@\-{},]+@[\w.\-]+(?:\.\w+)+', stripped):
            return True
        return False
    name_like = 0
    affil_like = 0
    for line in lines:
        stripped = line.strip()
        if _AFFILIATION_KEYWORD_RE.search(stripped):
            affil_like += 1
        elif _AUTHOR_NAME_RE.match(stripped) and len(stripped.split()) <= 10:
            name_like += 1
    ratio = (name_like + affil_like) / len(lines)
    return ratio >= 0.75 and (name_like >= 2 or affil_like >= 1)


def _is_funding_acknowledgment(text: str) -> bool:
    '''True for funding/acknowledgment paragraphs that must not become tables.'''
    lines = [line for line in (text or '').splitlines() if line.strip()]
    if len(lines) < 2:
        return False
    hits = sum(1 for line in lines if _FUNDING_HINT_RE.search(line))
    return hits / len(lines) >= 0.5


def _looks_like_table_row(text: str) -> bool:
    """True for row-like blocks: column gaps, pipe separators, or numeric rows."""
    if (_is_reference_list(text) or _is_author_or_affiliation_block(text)
            or _is_funding_acknowledgment(text) or _looks_like_plot_axis_label(text)):
        return False
    # A real table caption marks the block as tabular even when surrounding words
    # would otherwise trip the prose guard (e.g. "... results").
    if not _is_table_caption(text) and _is_body_sentence(text):
        return False
    lines = [line for line in (text or '').splitlines() if line.strip()]
    if not lines:
        return False
    row_lines = 0
    for line in lines:
        if _is_table_caption_line(line) or _is_figure_caption_line(line):
            continue
        if _HEADING_WITH_SEPARATOR_RE.match(line):
            continue
        tokens = line.split()
        if len(tokens) < 2:
            continue
        has_gap = bool(re.search(r'\S\s{2,}\S', line)) or line.count('|') >= 1
        numeric = sum(1 for token in tokens if re.search(r'\d', token))
        short_tokens = sum(1 for token in tokens if len(token) <= 8)
        if has_gap and len(line) <= 400:
            row_lines += 1
        elif numeric >= 2 and len(line) <= 110 and numeric / len(tokens) >= 0.4 \
                and short_tokens / len(tokens) >= 0.7:
            row_lines += 1
    return row_lines >= 1


def _looks_like_table(text: str) -> bool:
    '''Identify table blocks: captions, column-gap rows, or dense vertical cell stacks.'''
    if _is_reference_list(text) or _looks_like_plot_axis_label(text):
        return False
    if _is_author_or_affiliation_block(text):
        return False
    if _is_funding_acknowledgment(text):
        return False
    lines = [line for line in (text or '').splitlines() if line.strip()]
    if len(lines) < 2:
        return False
    if any(_is_table_caption_line(line) for line in lines):
        return True
    # Wide numeric rows (e.g. "ViT-H/14 (JFT) 95.3 85.5 75.2 ...") are data even
    # with as few as two lines; the prose guard below would otherwise swallow
    # long numeric rows as body sentences.
    if len(lines) >= 2 and _is_numeric_dense_block(text, min_ratio=0.6):
        return True
    # Dense vertical stacks: arXiv tables frequently extract one cell per line.
    # These are checked before the prose guard because long data stacks would
    # otherwise be mistaken for paragraphs.
    if len(lines) >= 4:
        short = sum(1 for line in lines if len(line) <= 80)
        # Count only genuinely numeric lines: a short line carrying a digit, or a
        # long line dominated by digit tokens (>=3 of them, >=40% of tokens).
        # Two-column prose that merely mentions "Table 1"/"Section 3.2" or even
        # lists a few hyperparameters (1e-4, 0.95, 3842) has 1-2 digit tokens per
        # line and no longer trips this branch.
        numericish = sum(
            1 for line in lines
            if len(line) <= 80 and re.search(r'\d', line)
            and (len(line) <= 45 or _is_numeric_dense_line(line))
        )
        if short / len(lines) >= 0.9 and numericish >= max(3, len(lines) // 2):
            return True
        if len(lines) >= 5 and all(len(line) <= 32 for line in lines) and \
                sum(1 for line in lines if len(line.split()) <= 3) / len(lines) >= 0.9 and \
                not re.search(r'\.\s+[A-Z]', text):
            return True
    split_columns = sum(bool(re.search(r'\S\s{2,}\S', line) or line.count('|') >= 2) for line in lines)
    if split_columns >= 2:
        return True
    if _is_body_sentence(text):
        return False
    # Small label stacks such as "Dirty / Acc/F1/BLEU" or "Zero-Shot / One-Shot".
    if len(lines) >= 2 and all(len(line) <= 24 for line in lines) and \
            all(len(line.split()) <= 3 for line in lines) and \
            not any(re.match(r'^[\d.,%\-]+$', line) for line in lines) and \
            not re.search(r'[=+\u2212*^_<>|\u2192\u279d]', text) and \
            not re.match(r'^\s*\d+(?:\.\d+)*$', lines[0].strip()) and \
            not re.search(r'\.\s+[A-Z]', text) and \
            not _is_body_sentence(text):
        return True
    return False


def _is_tabular_row(text: str) -> bool:
    """True for table-row-like text that must not be classified as a formula."""
    return _looks_like_table_row(text)


def _looks_like_formula(text: str) -> bool:
    """Return True for blocks that are likely mathematical rather than prose."""
    if not text or re.search(r'(?i)https?://|www\.|commoncrawl|github\.com', text):
        return False
    if (_is_table_caption(text) or _is_figure_caption(text)
            or _looks_like_plot_axis_label(text)):
        return False
    if _is_tabular_row(text):
        return False
    if (_is_author_or_affiliation_block(text) or _is_reference_list(text)
            or _is_funding_acknowledgment(text)):
        return False
    if _is_body_sentence(text):
        return False
    compact = re.sub(r'\s+', '', text)
    if not compact or len(compact) > 400:
        return False
    operator_count = len(_MATH_OPERATOR_RE.findall(compact))
    symbol_count = len(_MATH_SYMBOL_CHARS_RE.findall(compact))
    density = symbol_count / max(1, len(compact))
    if operator_count >= 2:
        return True
    return symbol_count >= 3 and density >= 0.04


_PLOT_AXIS_HINT_RE = re.compile(
    r'(?i)\b(?:accuracy|acc|precision|recall|speed|inference|latency|fps|throughput|'
    r'top[- ]?1|top[- ]?5|m(?:ean)?\s*iou|iou|error|loss|epoch|time)\b'
)


def _looks_like_plot_axis_label(text: str) -> bool:
    """Identify short plot tick/axis fragments before table/formula heuristics.

    This is deliberately conservative: only short blocks with numeric ticks or
    a small set of common metric-axis words are filtered. Captioned tables and
    multi-column data rows remain eligible for normal reconstruction.
    """
    lines = [line.strip() for line in (text or '').splitlines() if line.strip()]
    if not lines or len(lines) > 4 or any(len(line) > 48 for line in lines):
        return False
    if any(_is_table_caption_line(line) or _is_figure_caption_line(line) for line in lines):
        return False
    numeric_ticks = sum(
        1 for line in lines
        if re.fullmatch(r'[\d.,%+\-–—eE ]+', line)
    )
    axis_words = sum(1 for line in lines if _PLOT_AXIS_HINT_RE.search(line))
    return numeric_ticks >= 1 and len(lines) <= 3 or (axis_words >= 1 and len(lines) <= 2 and numeric_ticks >= 0)


_MATH_OPERATOR_RE = re.compile(
    r'[=+\u2212\u00b1\u00d7\u00f7\u2264\u2265\u2248\u2260\u2211\u222b\u221a\u2208\u221e\u2192*/^_{}<>|]'
)
_MATH_SYMBOL_CHARS_RE = re.compile(
    r'[=+\-*/^_{}<>|\u2211\u220f\u222b\u221a\u2248\u2264\u2265\u2260\u00b1\u00d7\u00f7\u221e\u2208'
    r'\u2286\u2282\u222a\u2229\u2200\u2203\u2202\u2207\u2192\u21a6\u2026\u22ef\u2212]'
)
_TABLE_CAPTION_RE = re.compile(r'(?i)^\s*(table|\u8868)\s+([A-Z]\.\d+|[ivxlcdm]+|\d+(?:\.\d+)*)\b')
_TABLE_REFERENCE_VERBS_RE = re.compile(
    r'(?i)^\s*(shows|reports|presents|lists|summarizes|summarises|gives|displays|illustrates|'
    r'depicts|contains|include|includes|is|are|was|were|details|compares|provides|outlines|'
    r'tabulates|describes|we|the|this|in|from|for|of|a|an|and|see|also|below|above)\b'
)
_HEADING_WITH_SEPARATOR_RE = re.compile(r'^\s*\d+(?:\.\d+)*\s*[|\u00b7\-]\s*[A-Z]')


_MATH_SYMBOL_MAP = {
    '\u2211': r'\sum',
    '\u220f': r'\prod',
    '\u222b': r'\int',
    '\u221a': r'\sqrt',
    '\u2248': r'\approx',
    '\u2264': r'\le',
    '\u2265': r'\ge',
    '\u2260': r'\ne',
    '\u00b1': r'\pm',
    '\u00d7': r'\times',
    '\u00f7': r'\div',
    '\u221e': r'\infty',
    '\u03b1': r'\alpha',
    '\u03b2': r'\beta',
    '\u03b3': r'\gamma',
    '\u03b4': r'\delta',
    '\u03bb': r'\lambda',
    '\u03bc': r'\mu',
    '\u03c3': r'\sigma',
    '\u03b8': r'\theta',
    '\u03c0': r'\pi',
    '\u03c6': r'\phi',
    '\u03c9': r'\omega',
    '\u2208': r'\in',
    '\u2286': r'\subseteq',
    '\u2282': r'\subset',
    '\u222a': r'\cup',
    '\u2229': r'\cap',
    '\u2200': r'\forall',
    '\u2203': r'\exists',
    '\u2202': r'\partial',
    '\u2207': r'\nabla',
    '\u2192': r'\to',
    '\u21a6': r'\mapsto',
    '\u2026': r'\dots',
    '\u22ef': r'\cdots',
    '\u2212': '-',
}
_MATH_GLYPH_CHARS = set('=+-*/^_{}()[]<>|,.:;%') | set(_MATH_SYMBOL_MAP)


def _normalize_formula_text(text: str) -> str:
    '''Map common Unicode math glyphs to LaTeX names and compact whitespace.'''
    normalized = re.sub(r'\s+', ' ', text or '').strip()
    for symbol, latex in _MATH_SYMBOL_MAP.items():
        normalized = normalized.replace(symbol, latex)
    return re.sub(r'\s+', ' ', normalized).strip()


def _formula_glyph_confidence(text: str) -> float:
    '''Fraction of glyphs that are readable alphanumerics or known math symbols.'''
    compact = re.sub(r'\s+', '', text or '')
    if not compact:
        return 0.0
    readable = sum(1 for char in compact if char.isalnum() or char in _MATH_GLYPH_CHARS)
    return round(readable / len(compact), 2)


def _visual_metadata(page: Any, raw_blocks: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Describe visual content without claiming that a figure was understood."""
    try:
        image_count = len(page.get_images(full=True))
    except Exception:
        image_count = 0
    try:
        drawings = page.get_drawings()
        drawing_count = len(drawings)
    except Exception:
        drawings = []
        drawing_count = 0
    candidate_node_count = 0
    candidate_edge_line_count = 0
    candidate_arrow_count = 0
    for drawing in drawings:
        items = drawing.get('items') or [] if isinstance(drawing, dict) else []
        for item in items:
            if not item:
                continue
            kind = item[0]
            if kind == 're':
                rect = item[1] if len(item) > 1 else None
                try:
                    width = float(rect.width)
                    height = float(rect.height)
                    if 12 <= width <= 500 and 8 <= height <= 300:
                        candidate_node_count += 1
                except Exception:
                    pass
            elif kind in {'l', 'qu', 'c'}:
                candidate_edge_line_count += 1
        if isinstance(drawing, dict) and drawing.get('fill') is not None and len(items) >= 2:
            candidate_arrow_count += 1
    candidate_total = candidate_node_count + candidate_edge_line_count + candidate_arrow_count
    caption_count = sum(_is_figure_caption(block.get('text', '')) for block in raw_blocks)
    # A caption coupled with an image/vector-heavy region is evidence of a
    # figure, but not evidence that its visual topology has been recovered.
    label_like_blocks = sum(
        1 for block in raw_blocks
        if not _is_figure_caption(block.get('text', ''))
        and 2 <= len((block.get('text') or '').strip()) <= 120
    )
    has_figure = caption_count > 0 and (
        image_count > 0 or drawing_count >= 20 or drawing_count >= 3
    )
    if not has_figure:
        figure_kind = 'none'
    elif drawing_count >= 80 and image_count == 0:
        figure_kind = 'flowchart_or_architecture_candidate'
    elif image_count > 0 and drawing_count >= 20:
        figure_kind = 'composite_figure_candidate'
    else:
        figure_kind = 'image_or_plot_candidate'
    label_blocks = sum(
        1 for block in raw_blocks
        if not _is_figure_caption(block.get('text', ''))
        and 2 <= len((block.get('text') or '').strip()) <= 120
    ) if has_figure else 0
    return {
        'image_count': image_count,
        'drawing_count': drawing_count,
        'figure_caption_count': caption_count,
        'figure_structure_risk': has_figure,
        'figure_kind': figure_kind,
        'extracted_label_block_count': label_blocks,
        'candidate_node_count': candidate_node_count if has_figure else 0,
        'candidate_edge_line_count': candidate_edge_line_count if has_figure else 0,
        'candidate_arrow_count': candidate_arrow_count if has_figure else 0,
        'candidate_geometry_count': candidate_total if has_figure else 0,
        'visual_region_bbox': None,
        'topology_confidence': 0.0,
        'node_count_verified': 0,
        'edge_count_verified': 0,
        'topology_verified': False,
        'visual_confidence': 0.35 if has_figure else 1.0,
    }


def _page_quality(page: Dict[str, Any], page_blocks: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Score extraction reliability conservatively; it is not a content-quality score."""
    warnings: List[str] = []
    failure_modes: List[str] = []
    text = page.get('text') or ''
    confidence = 1.0

    if not text.strip():
        return {
            'confidence': 0.0,
            'warnings': ['No extractable text was found on this page.'],
            'failure_modes': ['empty_page'],
        }

    repaired_blocks = [b for b in page_blocks if b.get('encoding_repaired')]
    if repaired_blocks:
        pairs = sorted({str(b.get('encoding_repaired')) for b in repaired_blocks})
        warnings.append(
            'Mojibake text was heuristically repaired in %d block(s) (%s); repair is best-effort.'
            % (len(repaired_blocks), ', '.join(pairs))
        )
        confidence -= 0.05
    text_source = str(page.get('text_source') or '')
    if text_source.startswith('encoding-repaired:'):
        warnings.append('Page text was repaired from mojibake (%s).' % text_source.split(':', 1)[-1])
        confidence -= 0.05
    elif text_source == 'pdfminer-fallback':
        warnings.append('Page text was restored via pdfminer.six cross-engine fallback (PyMuPDF output was mojibake).')
        confidence -= 0.05

    if page.get('layout') == 'two_column':
        warnings.append('Two-column reading order was reconstructed from block coordinates.')
        confidence -= 0.08
        reading_confidence = float(page.get('reading_order_confidence', 0.82) or 0.82)
        if reading_confidence < 0.75:
            warnings.append('Two-column reading order has an internal full-width/interleaved block; verify paragraph order against the PDF.')
            failure_modes.append('reading_order_risk')
            confidence -= 0.10
    elif page.get('layout') == 'layout_uncertain':
        warnings.append('Page layout could not be classified reliably.')
        failure_modes.append('layout_uncertain')
        confidence -= 0.25

    formula_blocks = [block for block in page_blocks if block.get('type') == 'formula']
    if formula_blocks:
        warnings.append('Mathematical formula blocks may contain lost symbols or ordering errors.')
        failure_modes.append('formula_extraction_risk')
        confidence -= min(0.28, 0.08 * len(formula_blocks))

    table_blocks = [block for block in page_blocks if block.get('type') == 'table']
    if table_blocks:
        warnings.append('Table text was extracted, but row/column structure is not guaranteed.')
        failure_modes.append('table_structure_risk')
        confidence -= min(0.30, 0.10 * len(table_blocks))

    visuals = page.get('visuals') or {}
    if visuals.get('figure_structure_risk'):
        warnings.append(
            'Figure content classified as %s; %d label block(s) were extracted, but node/edge topology was not reconstructed.'
            % (visuals.get('figure_kind', 'figure'), visuals.get('extracted_label_block_count', 0))
        )
        failure_modes.append('figure_structure_risk')
        confidence -= 0.20

    if page.get('cross_page_table_risk'):
        warnings.append('A table may continue across this page boundary; row continuity was not reconstructed.')
        failure_modes.append('cross_page_table_risk')
        confidence -= 0.25

    replacement_chars = text.count('\ufffd')
    if replacement_chars:
        warnings.append(f'Extraction contains {replacement_chars} replacement character(s).')
        failure_modes.append('text_encoding_corruption')
        confidence -= min(0.35, 0.05 * replacement_chars)

    return {
        'confidence': round(max(0.0, min(1.0, confidence)), 2),
        'warnings': warnings,
        'failure_modes': failure_modes,
        'reading_order_confidence': round(float(page.get('reading_order_confidence', 1.0) or 1.0), 2),
    }


_SYMBOL_FONT_RE = re.compile(
    r'(?i)symbol|cmsy|msam|msbm|eufm|eusm|rsfs|lmmathsymbols|mnsymbol|txsy|pxsy|bbold|stmaryrd|msym'
)
_SYMBOL_FONT_GREEK_MAP = {
    'A': '\u0391', 'B': '\u0392', 'C': '\u03a7', 'D': '\u0394', 'E': '\u0395',
    'F': '\u03a6', 'G': '\u0393', 'H': '\u0397', 'I': '\u0399', 'J': '\u03d1',
    'K': '\u039a', 'L': '\u039b', 'M': '\u039c', 'N': '\u039d', 'O': '\u039f',
    'P': '\u03a0', 'Q': '\u0398', 'R': '\u03a1', 'S': '\u03a3', 'T': '\u03a4',
    'U': '\u03a5', 'V': '\u03c2', 'W': '\u03a9', 'X': '\u039e', 'Y': '\u03a8',
    'Z': '\u0396',
    'a': '\u03b1', 'b': '\u03b2', 'c': '\u03c7', 'd': '\u03b4', 'e': '\u03b5',
    'f': '\u03c6', 'g': '\u03b3', 'h': '\u03b7', 'i': '\u03b9', 'j': '\u03d5',
    'k': '\u03ba', 'l': '\u03bb', 'm': '\u03bc', 'n': '\u03bd', 'o': '\u03bf',
    'p': '\u03c0', 'q': '\u03b8', 'r': '\u03c1', 's': '\u03c3', 't': '\u03c4',
    'u': '\u03c5', 'v': '\u03c2', 'w': '\u03c9', 'x': '\u03be', 'y': '\u03c8',
    'z': '\u03b6',
}


def _looks_like_prose(text: str) -> bool:
    '''True when the text reads like natural-language prose rather than Symbol glyph runs.

    Prose-like spans (e.g. "Model accuracy") are left untouched even inside
    Symbol-named fonts so fonts with a proper ToUnicode mapping are never
    corrupted. Short glyph runs and operator-heavy math stay map-eligible.
    '''
    tokens = text.split()
    if len(tokens) < 2:
        return False
    if not all(tok.isalpha() for tok in tokens):
        return False
    if not all(len(tok) >= 2 for tok in tokens):
        return False
    return len(text) >= 6


def _map_symbol_font_text(text: str) -> str:
    '''Map Adobe-Symbol-style ASCII glyphs to Greek when the PDF font carries no ToUnicode.

    Conservative by design: only rewrites short glyph runs or math-like strings;
    text that reads like normal prose is returned unchanged.
    '''
    if not text or _looks_like_prose(text):
        return text or ''
    return ''.join(_SYMBOL_FONT_GREEK_MAP.get(ch, ch) for ch in text)


def _page_raw_blocks(page: Any, page_number: int) -> tuple[List[Dict[str, Any]], int]:
    '''Extract text blocks with per-span font awareness and per-block mojibake repair.'''
    raw_blocks = []
    symbol_mapped = 0
    try:
        page_dict = page.get_text('dict')
        for raw in page_dict.get('blocks', []):
            if raw.get('type') != 0:
                continue
            lines = []
            line_spans = []
            block_mapped = False
            for line in raw.get('lines', []):
                parts = []
                span_records = []
                for span in line.get('spans', []):
                    span_text = span.get('text') or ''
                    mapped = span_text
                    if _SYMBOL_FONT_RE.search(str(span.get('font') or '')):
                        mapped = _map_symbol_font_text(span_text)
                        if mapped != span_text:
                            symbol_mapped += 1
                            block_mapped = True
                    parts.append(mapped)
                    span_bbox = span.get('bbox') or [0, 0, 0, 0]
                    span_records.append({
                        'text': mapped,
                        'bbox': [round(float(span_bbox[0]), 2), round(float(span_bbox[1]), 2),
                                 round(float(span_bbox[2]), 2), round(float(span_bbox[3]), 2)],
                    })
                line_bbox = line.get('bbox') or [0, 0, 0, 0]
                line_spans.append({
                    'text': ''.join(parts),
                    'bbox': [round(float(line_bbox[0]), 2), round(float(line_bbox[1]), 2),
                             round(float(line_bbox[2]), 2), round(float(line_bbox[3]), 2)],
                    'spans': span_records,
                })
                lines.append(''.join(parts))
            text = _clean_text('\n'.join(lines))
            if not text:
                continue
            repaired, pair = _repair_mojibake(text)
            encoding_repaired = pair if repaired is not None else None
            if repaired is not None:
                text = repaired
            bbox = raw.get('bbox') or [0, 0, 0, 0]
            raw_blocks.append({
                'page': page_number,
                'bbox': [round(float(bbox[0]), 2), round(float(bbox[1]), 2), round(float(bbox[2]), 2), round(float(bbox[3]), 2)],
                'text': text,
                'block_no': raw.get('number'),
                'raw_type': 0,
                'encoding_repaired': encoding_repaired,
                'symbol_font_mapped': block_mapped,
                'line_spans': line_spans,
            })
    except Exception:
        # Robust fallback: plain blocks mode without font-level mapping.
        for raw in page.get_text('blocks'):
            x0, y0, x1, y1, raw_text, block_no, block_type = raw[:7]
            text = _clean_text(raw_text)
            repaired, pair = _repair_mojibake(text)
            encoding_repaired = pair if repaired is not None else None
            if repaired is not None:
                text = repaired
            if not text:
                continue
            raw_blocks.append({
                'page': page_number,
                'bbox': [round(float(x0), 2), round(float(y0), 2), round(float(x1), 2), round(float(y1), 2)],
                'text': text,
                'block_no': int(block_no),
                'raw_type': int(block_type),
                'encoding_repaired': encoding_repaired,
                'symbol_font_mapped': False,
                'line_spans': [],
            })
    return raw_blocks, symbol_mapped


def _line_track(bbox: List[float], midpoint: float, gutter: float) -> str:
    """Classify one extracted line without using its parent block's width."""
    if bbox[2] <= midpoint + gutter:
        return 'left'
    if bbox[0] >= midpoint - gutter:
        return 'right'
    return 'full'


def _rejoin_inline_fragments(lines: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Reunite nearby same-baseline text separated by PDF script glyphs.

    Preserve literal glyphs, not inferred LaTeX or mathematical meaning. A real
    column gutter/large gap must remain a boundary even at the same height.
    """
    result = []
    for row in _rows_from_lines(lines):
        groups = []
        for line in sorted(row, key=lambda value: value['bbox'][0]):
            if groups and line['bbox'][0] - max(v['bbox'][2] for v in groups[-1]) <= 8.0:
                groups[-1].append(line)
            else:
                groups.append([line])
        for group in groups:
            if len(group) == 1 or not any(len(str(v.get('text') or '').strip()) <= 24 for v in group):
                result.extend(group)
                continue
            result.append({'text': ' '.join(str(v.get('text') or '').strip() for v in group),
                'bbox': [min(v['bbox'][0] for v in group), min(v['bbox'][1] for v in group),
                         max(v['bbox'][2] for v in group), max(v['bbox'][3] for v in group)],
                'spans': [span for v in group for span in v.get('spans') or []]})
    return result


def _join_script_linked_blocks(blocks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Join PDF blocks only when a small script glyph links their physical line.

    A PyMuPDF block may end at c^FP32 while a new block starts with subscript 2
    and the sentence continuation. Keeping those blocks as separate columns
    loses the definition. Never join across a gutter or repair glyph semantics.
    """
    parents = list(range(len(blocks)))
    def root(i):
        while parents[i] != i:
            parents[i] = parents[parents[i]]
            i = parents[i]
        return i
    lines = [{**line, '_owner': i} for i, block in enumerate(blocks)
             for line in block.get('line_spans') or []
             if ''.join(block.get('text', '').split()) == ''.join(
                 ''.join(str(v.get('text') or '').split()) for v in block.get('line_spans') or [])]
    for row in _rows_from_lines(lines):
        for small in row:
            box = small['bbox']
            if (box[2] - box[0] > 15 or not re.fullmatch(r'[\w∂±]{1,6}', str(small.get('text') or '').strip())):
                continue
            for other in row:
                ob = other['bbox']
                gap = max(box[0], ob[0]) - min(box[2], ob[2])
                if (other['_owner'] != small['_owner'] and gap <= 6
                        and box[3] - box[1] <= (ob[3] - ob[1]) * 0.85):
                    parents[root(other['_owner'])] = root(small['_owner'])
    groups = {}
    for i, block in enumerate(blocks):
        groups.setdefault(root(i), []).append(block)
    output = []
    for members in groups.values():
        if len(members) == 1:
            output.append(members[0])
            continue
        rejoined = _rejoin_inline_fragments([line for block in members for line in block.get('line_spans') or []])
        output.append({**members[0], 'text': '\n'.join(line['text'] for line in rejoined),
            'line_spans': rejoined,
            'bbox': [min(b['bbox'][0] for b in members), min(b['bbox'][1] for b in members),
                     max(b['bbox'][2] for b in members), max(b['bbox'][3] for b in members)]})
    return output


def _split_cross_track_raw_blocks(raw_blocks: List[Dict[str, Any]], page_width: float) -> List[Dict[str, Any]]:
    """Split a PyMuPDF block when its individual lines change layout tracks.

    PyMuPDF occasionally emits one text block that starts in a column next to a
    figure and continues below that figure across the page.  Its parent bbox
    then crosses the gutter, even though no individual line does.  Treating the
    parent as full width consumes the neighbouring figure and corrupts reading
    order.  Line records retain the original coordinates, so split only such
    mixed-track blocks before layout classification.
    """
    midpoint = page_width / 2.0
    gutter = page_width * 0.06
    output: List[Dict[str, Any]] = []
    for block in raw_blocks:
        bbox = block.get('bbox') or [0, 0, 0, 0]
        spans_gutter = bbox[0] < midpoint - gutter and bbox[2] > midpoint + gutter
        lines = block.get('line_spans') or []
        # A caption and an aligned table row are not two prose columns.
        # Splitting them at the page midpoint separated dataset/metric headers
        # from the numeric row (e.g. QLoRA Table 3). Preserve source geometry;
        # this does not certify the meaning of a column or any measurement.
        aligned_rows = _rows_from_lines(lines) if lines else []
        aligned_cells = (bool(aligned_rows) and _looks_like_table(block.get('text') or '')
            and all(len(row) >= 2 for row in aligned_rows)
            and all(len(str(line.get('text') or '')) <= 100 for line in lines)
            and all(all(left['bbox'][2] <= right['bbox'][0] + 2
                for left, right in zip(sorted(row, key=lambda line: line['bbox'][0]),
                                       sorted(row, key=lambda line: line['bbox'][0])[1:]))
                for row in aligned_rows))
        if _is_table_caption(block.get('text') or '') or aligned_cells:
            output.append(block)
            continue
        rejoined = _rejoin_inline_fragments(lines) if lines else lines
        if len(rejoined) < len(lines):
            # Do not overwrite a repaired source string with unrepaired spans.
            literal = lambda text: ''.join(str(text).split())
            if literal(''.join(v.get('text') or '' for v in lines)) == literal(block.get('text') or ''):
                block = {**block, 'line_spans': rejoined, 'text': '\n'.join(v['text'] for v in rejoined)}
                lines = rejoined
        if not spans_gutter or len(lines) < 2:
            output.append(block)
            continue

        atoms = []
        for line in lines:
            line_bbox = list(line.get('bbox') or [0, 0, 0, 0])
            line_text = _clean_text(str(line.get('text') or ''))
            if line_text:
                atoms.append({'bbox': line_bbox, 'text': line_text,
                              'track': _line_track(line_bbox, midpoint, gutter),
                              'spans': line.get('spans') or []})
        # Do not replace a block unless it actually contains a track transition.
        if len({atom['track'] for atom in atoms}) < 2:
            output.append(block)
            continue

        current: List[Dict[str, Any]] = []
        current_track = ''
        previous_bottom = -float('inf')
        for atom in atoms:
            vertical_gap = atom['bbox'][1] - previous_bottom
            if current and (atom['track'] != current_track or vertical_gap > 20.0):
                replacement = dict(block)
                replacement['bbox'] = [
                    round(min(item['bbox'][0] for item in current), 2),
                    round(min(item['bbox'][1] for item in current), 2),
                    round(max(item['bbox'][2] for item in current), 2),
                    round(max(item['bbox'][3] for item in current), 2),
                ]
                replacement['text'] = '\n'.join(item['text'] for item in current)
                replacement['line_spans'] = [
                    {'text': item['text'], 'bbox': item['bbox'], 'spans': item['spans']}
                    for item in current
                ]
                output.append(replacement)
                current = []
            current.append(atom)
            current_track = atom['track']
            previous_bottom = atom['bbox'][3]
        if current:
            replacement = dict(block)
            replacement['bbox'] = [
                round(min(item['bbox'][0] for item in current), 2),
                round(min(item['bbox'][1] for item in current), 2),
                round(max(item['bbox'][2] for item in current), 2),
                round(max(item['bbox'][3] for item in current), 2),
            ]
            replacement['text'] = '\n'.join(item['text'] for item in current)
            replacement['line_spans'] = [
                {'text': item['text'], 'bbox': item['bbox'], 'spans': item['spans']}
                for item in current
            ]
            output.append(replacement)
    return output


def _layout_blocks_from_page(page: Any, page_number: int) -> tuple[List[Dict[str, Any]], str, Dict[str, Any], int]:
    """Extract blocks and reconstruct a cautious single- or two-column reading order."""
    page_width = float(page.rect.width)
    raw_blocks, symbol_mapped = _page_raw_blocks(page, page_number)
    raw_blocks = _split_cross_track_raw_blocks(_join_script_linked_blocks(raw_blocks), page_width)

    visuals = _visual_metadata(page, raw_blocks)
    # IEEE-style tables are often emitted as separate caption, header and data
    # blocks. Mark full-width blocks beneath a table caption until normal column
    # prose resumes, so dense numeric rows are not misclassified as formulae.
    for caption in [block for block in raw_blocks if _is_table_caption(block['text'])]:
        caption_y = caption['bbox'][1]
        prose_starts = [
            block['bbox'][1] for block in raw_blocks
            if block['bbox'][1] > caption_y and (block['bbox'][2] - block['bbox'][0]) < page_width * 0.70
            and _is_body_sentence(block['text']) and not _looks_like_table(block['text'])
            and not _looks_like_table_row(block['text'])
        ]
        table_end = min(prose_starts) if prose_starts else float('inf')
        for block in raw_blocks:
            block_width = block['bbox'][2] - block['bbox'][0]
            contained = (block['bbox'][0] >= caption['bbox'][0] - 12
                         and block['bbox'][2] <= caption['bbox'][2] + 12)
            if (caption_y <= block['bbox'][1] < table_end and contained
                    and block_width >= (caption['bbox'][2] - caption['bbox'][0]) * 0.5):
                if _looks_like_table(block['text']) or _looks_like_table_row(block['text']):
                    block['table_region'] = True
                    block['caption_anchor_id'] = _block_caption_id(caption)

    midpoint = page_width / 2
    gutter = page_width * 0.06
    # Assign a narrow block to one and only one track by its geometric centre.
    # The former overlapping gutter predicates put a centred equation fragment
    # in both ``left`` and ``right`` collections, which made a single-column
    # proof look like a two-column page.  True spanning blocks remain separate.
    def raw_track(block: Dict[str, Any]) -> str:
        x0, _, x1, _ = block['bbox']
        block_width = x1 - x0
        if block_width >= page_width * 0.66 or (x0 < midpoint - gutter and x1 > midpoint + gutter):
            return 'full'
        return 'left' if (x0 + x1) / 2.0 < midpoint else 'right'

    left = [block for block in raw_blocks if raw_track(block) == 'left']
    right = [block for block in raw_blocks if raw_track(block) == 'right']
    spanning = [block for block in raw_blocks if raw_track(block) == 'full']

    def column_prose_evidence(block: Dict[str, Any]) -> bool:
        """Reject formula fragments and visual labels as column-layout evidence."""
        text = block.get('text') or ''
        block_width = block['bbox'][2] - block['bbox'][0]
        alphabetic = sum(character.isalpha() for character in text)
        words = re.findall(r"[A-Za-z]{2,}", text)
        mostly_uppercase_short_line = (
            len(words) >= 2
            and len(text) <= 24
            and sum(character.isupper() for character in text) >= max(4, alphabetic * 0.65)
        )
        return (
            # Short ordinary lines (including headings and synthetic test
            # fixtures) are still valid column evidence.  What distinguishes
            # them from equation fragments is a substantial natural-language
            # character share, not an arbitrary paragraph-length cutoff.
            len(text) >= 6
            and block_width >= page_width * 0.03
            and alphabetic >= max(4, int(len(text) * 0.35))
            # Body prose normally has several lexical words.  The uppercase
            # exception preserves compact headings/test fixtures, while not
            # treating labels such as "input prompt" as a second text column.
            and (len(words) >= 4 or mostly_uppercase_short_line)
            # A line with an equality sign is normally an equation fragment
            # even when PyMuPDF has appended a few prose words after it.
            and '=' not in text
            and not _looks_like_formula(text)
            and not _is_figure_caption(text)
            and not _looks_like_table(text)
        )

    # Do not infer a two-column page from equation numbers, diagram labels, or
    # short fragments placed on both sides of a single-column proof.  Those
    # records created dozens of fake left/right chunks in math-heavy appendices.
    left_prose = [block for block in left if column_prose_evidence(block)]
    right_prose = [block for block in right if column_prose_evidence(block)]
    # A genuine two-column body has prose on both sides of at least one common
    # horizontal reading band.  This prevents equation numbers or a diagram
    # label on the right of an otherwise single-column page from inventing a
    # second column.
    paired_prose_band = any(
        abs(left_block['bbox'][1] - right_block['bbox'][1]) <= 26.0
        for left_block in left_prose
        for right_block in right_prose
    )
    has_two_columns = (
        # One prose line on each side is sufficient when each side also has a
        # second local block (a formula/table can belong to a real column).
        # Pure equation pages fail the prose test on at least one side because
        # their fragments lack a natural-language character share.
        len(left_prose) >= 1
        and len(right_prose) >= 1
        and len(left) >= 2
        and len(right) >= 2
        and paired_prose_band
    )

    if has_two_columns:
        page_height = float(page.rect.height)
        column_content = [
            block for block in left + right
            if len(block['text']) >= 20 and block['bbox'][1] >= page_height * 0.05
        ]
        first_column_y = min(
            (block['bbox'][1] for block in column_content),
            default=min(block['bbox'][1] for block in left + right),
        )
        above = sorted((block for block in spanning if block['bbox'][1] <= first_column_y), key=lambda block: (block['bbox'][1], block['bbox'][0]))
        below = sorted((block for block in spanning if block['bbox'][1] > first_column_y), key=lambda block: (block['bbox'][1], block['bbox'][0]))
        ordered = above + sorted(left, key=lambda block: block['bbox'][1]) + sorted(right, key=lambda block: block['bbox'][1]) + below
        # Coordinate ordering is reliable for ordinary prose but becomes
        # ambiguous when full-width blocks are interleaved with column text.
        internal_spanning = [block for block in spanning if block['bbox'][1] > first_column_y]
        reading_order_confidence = 0.70 if internal_spanning else 0.82
        layout = 'two_column'
        reading_order_strategy = 'full_width_then_left_column_then_right_column'
        if internal_spanning:
            reading_order_strategy = 'ambiguous_full_width_blocks_interleaved'
    else:
        ordered = sorted(raw_blocks, key=lambda block: (block['bbox'][1], block['bbox'][0]))
        layout = 'single_column' if raw_blocks else 'layout_uncertain'
        reading_order_confidence = 0.95 if raw_blocks else 0.0
        reading_order_strategy = 'top_to_bottom_left_to_right' if raw_blocks else 'unknown'

    blocks: List[Dict[str, Any]] = []
    for index, block in enumerate(ordered, 1):
        text = block['text']
        block_type = (
            'table' if block.get('table_region') or _is_table_caption(text)
                     or _looks_like_table(text) or _looks_like_table_row(text)
            else 'figure_caption' if _is_figure_caption(text)
            else 'formula' if _looks_like_formula(text)
            else 'text'
        )
        column = 'full'
        if has_two_columns:
            if block in left:
                column = 'left'
            elif block in right:
                column = 'right'
        confidence = 0.95
        if block_type == 'formula':
            confidence = 0.55
        elif block_type == 'table':
            confidence = 0.50
        block_record = {
            'page': page_number,
            'block_id': f'p{page_number}-b{index}',
            'bbox': block['bbox'],
            'column': column,
            'type': block_type,
            'text': text,
            'char_count': len(text),
            'confidence': confidence,
            'encoding_repaired': block.get('encoding_repaired'),
            'symbol_font_mapped': bool(block.get('symbol_font_mapped')),
            'page_height': round(float(page.rect.height), 2),
            'line_spans': block.get('line_spans') or [],
            'reading_order_confidence': round(reading_order_confidence, 2),
            'reading_order_index': index,
            'reading_order_strategy': reading_order_strategy,
            'spans_column_gutter': block in spanning,
            **({'table_region': True, 'caption_anchor_id': block.get('caption_anchor_id')}
               if block.get('table_region') else {}),
        }
        if block_type == 'formula':
            block_record['latex_guess'] = _normalize_formula_text(text)
            block_record['glyph_confidence'] = _formula_glyph_confidence(text)
            block_record['structure_uncertain'] = True
        blocks.append(block_record)
    return blocks, layout, visuals, symbol_mapped


def _mark_cross_page_table_risks(pages: List[Dict[str, Any]], layout_blocks: List[Dict[str, Any]]) -> None:
    """Flag likely split tables without inventing row continuity across pages."""
    blocks_by_page: Dict[int, List[Dict[str, Any]]] = {}
    for block in layout_blocks:
        blocks_by_page.setdefault(int(block.get('page', 0)), []).append(block)

    for current, following in zip(pages, pages[1:]):
        current_number = int(current.get('page', 0))
        following_number = int(following.get('page', 0))
        current_tables = [
            block for block in blocks_by_page.get(current_number, [])
            if block.get('type') == 'table'
        ]
        following_tables = [
            block for block in blocks_by_page.get(following_number, [])
            if block.get('type') == 'table'
        ]
        if not current_tables or not following_tables:
            continue

        page_height = float(current.get('height', 0) or 0)
        next_height = float(following.get('height', 0) or 0)
        last_table = max(current_tables, key=lambda block: block['bbox'][3])
        first_table = min(following_tables, key=lambda block: block['bbox'][1])
        if not page_height or not next_height:
            continue
        if last_table['bbox'][3] < page_height * 0.70 or first_table['bbox'][1] > next_height * 0.35:
            continue

        if not _is_table_continuation_evidence(last_table):
            continue
        if _is_table_caption(first_table.get('text', '')):
            continue
        if not _is_table_continuation_evidence(first_table):
            continue

        group_id = last_table.get('continuation_group_id') or (
            f'table-continuation-p{current_number}-p{following_number}'
        )
        last_table['continuation_group_id'] = group_id
        first_table['continuation_group_id'] = group_id
        for block in current_tables + following_tables:
            block['continuation_risk'] = True
        current['cross_page_table_risk'] = True
        following['cross_page_table_risk'] = True


def _nearest_table_caption_id(block: Dict[str, Any], table_blocks: List[Dict[str, Any]]) -> Optional[str]:
    '''Return the caption id of the nearest real table caption on the same page.

    GPT-3-style papers place the caption below the data, so prefer the closest
    caption below the block; fall back to the closest caption above (IEEE style).
    '''
    page = block.get('page')
    y0 = (block.get('bbox') or [0, 0])[1]
    block_bbox = block.get('bbox') or [0, 0, 0, 0]
    best_below = None
    best_below_dist = float('inf')
    best_above = None
    best_above_dist = float('inf')
    for other in table_blocks:
        if other is block or other.get('page') != page:
            continue
        # Only group blocks that share the caption's column strip; other-column
        # prose at the same height must never be pulled into a table group.
        if not _horizontal_overlap(block_bbox, other.get('bbox') or [0, 0, 0, 0]):
            continue
        caption_id = _block_caption_id(other)
        if not caption_id:
            continue
        other_y = (other.get('bbox') or [0, 0])[1]
        distance = other_y - y0
        if -620 <= distance < 0 and -distance < best_above_dist:
            best_above_dist = -distance
            best_above = caption_id
        elif 0 < distance <= 620 and distance < best_below_dist:
            best_below_dist = distance
            best_below = caption_id
    return best_below if best_below else best_above


def _is_table_data_line(line: str) -> bool:
    '''Keep row/cell lines inside a reconstructed table; drop captions and prose.'''
    if _is_table_caption_line(line) or _is_figure_caption_line(line):
        return False
    if _HEADING_WITH_SEPARATOR_RE.match(line):
        return False
    if len(line) > 80 and re.search(r'[a-z]{4,}', line) and re.search(r'\.\s+[A-Z]', line):
        return False
    return True


def _is_table_cell_line(line: str) -> bool:
    '''Strict row check for caption-bearing blocks so caption prose never leaks in.'''
    tokens = line.split()
    if len(tokens) < 2:
        return False
    if re.search(r'\S\s{2,}\S', line) or line.count('|') >= 1:
        return True
    numeric = sum(1 for token in tokens if re.search(r'\d', token))
    return numeric >= 2 and numeric / len(tokens) >= 0.4


_ANCHOR_GAP_PT = 55.0


def _horizontal_overlap(bbox_a, bbox_b) -> bool:
    '''True when two bboxes share any horizontal range (same column strip).'''
    return float(bbox_a[0]) < float(bbox_b[2]) and float(bbox_b[0]) < float(bbox_a[2])




def _is_numeric_dense_line(line: str, min_ratio: float = 0.4) -> bool:
    '''True when a line is dominated by numeric tokens (>=3 digit tokens).'''
    tokens = line.split()
    if len(tokens) < 3:
        return False
    numeric = sum(1 for token in tokens if re.search(r'\d', token))
    return numeric >= 3 and numeric / len(tokens) >= min_ratio


def _is_numeric_dense_block(text: str, min_ratio: float = 0.4) -> bool:
    '''True for wide data stacks like "ViT-H/14 (JFT) 95.3 85.5 75.2 ...".

    Used only by the caption anchor walk so long numeric rows that trip the
    body-sentence length guard can still be recovered as table rows.
    '''
    lines = [line.strip() for line in (text or '').splitlines() if line.strip()]
    if len(lines) < 2:
        return False
    dense = 0
    for line in lines:
        if _is_numeric_dense_line(line, min_ratio=min_ratio):
            dense += 1
    return dense >= 2


def _looks_like_uncaptioned_axis_labels(text: str) -> bool:
    """Reject short numeric fragments that are more likely plot tick labels.

    Uncaptioned blocks are already heuristic. Short lines without column
    spacing, pipes, or a structured assignment/configuration pattern should
    not become quoteable logical tables merely because they contain numbers.
    """
    lines = [line.strip() for line in (text or '').splitlines() if line.strip()]
    if not lines or len(lines) > 5:
        return False
    if any(('  ' in line or '|' in line or '=' in line or ':' in line) for line in lines):
        return False
    if any(len(line) > 42 for line in lines):
        return False
    numeric_counts = [sum(1 for token in line.split() if re.search(r'\d', token)) for line in lines]
    return max(numeric_counts or [0]) <= 4 and sum(numeric_counts) >= 2


_CELL_GAP_PT = 3.0
_ROW_Y_TOL_PT = 8.0
_COL_X_TOL_PT = 8.0
_CROSS_PAGE_TOP_RATIO = 0.35
_CROSS_PAGE_BOTTOM_RATIO = 0.85


def _cells_from_line(line: Dict[str, Any]) -> List[Dict[str, Any]]:
    '''Split one extracted text line into horizontal cells using span coordinates.

    Spans whose horizontal gap is at most ``_CELL_GAP_PT`` are merged into one
    cell (superscripts, kerning). When span coordinates are unavailable
    (synthetic blocks or the plain-blocks fallback) a double-space text split
    is used and ``coords`` stays False so alignment is never asserted on fake
    coordinates.
    '''
    spans = line.get('spans') or []
    if spans:
        cells: List[Dict[str, Any]] = []
        for span in sorted(spans, key=lambda s: float((s.get('bbox') or [0, 0, 0, 0])[0])):
            bbox = span.get('bbox') or [0, 0, 0, 0]
            text = span.get('text') or ''
            if not text:
                continue
            x0, x1 = float(bbox[0]), float(bbox[2])
            if cells and x0 - cells[-1]['x1'] <= _CELL_GAP_PT:
                cells[-1]['x1'] = max(cells[-1]['x1'], x1)
                cells[-1]['text'] += text
            else:
                cells.append({'x0': x0, 'x1': x1, 'text': text, 'coords': True})
        return cells
    parts = re.split(r'\s{2,}', (line.get('text') or '').strip())
    cells = []
    for part in parts:
        if part:
            cells.append({'x0': 0.0, 'x1': float(len(part)), 'text': part, 'coords': False})
    return cells


def _rows_from_lines(lines: List[Dict[str, Any]]) -> List[List[Dict[str, Any]]]:
    '''Cluster lines into table rows by vertical position (same-y cells).'''
    ordered = sorted(
        (line for line in lines if (line.get('bbox') or [0, 0, 0, 0])[1] is not None),
        key=lambda line: (float((line.get('bbox') or [0, 0, 0, 0])[1]),
                          float((line.get('bbox') or [0, 0, 0, 0])[0])),
    )
    rows: List[List[Dict[str, Any]]] = []
    current: List[Dict[str, Any]] = []
    row_y0 = None
    for line in ordered:
        y0 = float((line.get('bbox') or [0, 0, 0, 0])[1])
        if row_y0 is None or y0 - row_y0 <= _ROW_Y_TOL_PT:
            current.append(line)
            if row_y0 is None:
                row_y0 = y0
        else:
            rows.append(current)
            current = [line]
            row_y0 = y0
    if current:
        rows.append(current)
    return rows


def _table_data_lines_with_boxes(block: Dict[str, Any], block_has_caption: bool) -> List[Dict[str, Any]]:
    '''Return line records of a block that contribute rows to a logical table.'''
    lines = []
    for raw_line in block.get('line_spans') or []:
        text = (raw_line.get('text') or '').strip()
        if not text or not _is_table_data_line(text):
            continue
        if block_has_caption and not _is_table_cell_line(text):
            continue
        lines.append(raw_line)
    return lines


def _verify_cell_alignment(blocks: List[Dict[str, Any]]) -> Dict[str, Any]:
    '''Verify that a reconstructed table has consistent multi-column alignment.

    PyMuPDF often emits every table cell as its own text line, so rows are
    rebuilt by grouping lines that share a vertical band, then columns by x
    position. ``verified=True`` only when a clear modal column count exists,
    at least three multi-column rows agree, and column edges align within a
    few points. Wide single-line numeric rows (one span per row) stay
    unverified because their cell boundaries are unknown.
    '''
    rows: List[List[Dict[str, Any]]] = []
    has_coords = False
    for block in blocks:
        block_has_caption = _block_caption_id(block) is not None
        lines = _table_data_lines_with_boxes(block, block_has_caption)
        for row in _rows_from_lines(lines):
            cells: List[Dict[str, Any]] = []
            for line in row:
                for cell in _cells_from_line(line):
                    cells.append(cell)
                    if cell.get('coords'):
                        has_coords = True
            cells.sort(key=lambda cell: cell['x0'])
            rows.append(cells)
    cell_rows = [[cell['text'] for cell in row] for row in rows]
    multi = [row for row in rows if len(row) >= 2]
    flat = [row for row in rows if len(row) < 2]
    if len(multi) < 3:
        return {
            'verified': False, 'score': 0.0, 'columns': 1,
            'multi_rows': len(multi), 'flat_rows': len(flat),
            'note': 'fewer than 3 multi-column rows', 'rows': cell_rows,
        }
    counts = [len(row) for row in multi]
    modal = max(set(counts), key=counts.count)
    modal_rows = [row for row in multi if len(row) == modal]
    ratio = len(modal_rows) / len(multi)
    if modal < 2 or ratio < 0.6:
        return {
            'verified': False, 'score': round(ratio, 2), 'columns': modal,
            'multi_rows': len(multi), 'flat_rows': len(flat),
            'note': 'column count inconsistent across rows', 'rows': cell_rows,
        }
    if has_coords:
        aligned_cols = 0
        for col in range(modal):
            lefts = [row[col]['x0'] for row in modal_rows if len(row) > col]
            rights = [row[col]['x1'] for row in modal_rows if len(row) > col]
            if lefts and (max(lefts) - min(lefts) <= _COL_X_TOL_PT or max(rights) - min(rights) <= _COL_X_TOL_PT):
                aligned_cols += 1
        col_ratio = aligned_cols / modal
        if col_ratio < 0.7:
            return {
                'verified': False, 'score': round(ratio, 2), 'columns': modal,
                'multi_rows': len(multi), 'flat_rows': len(flat),
                'note': 'column edges do not align', 'rows': cell_rows,
            }
    else:
        col_ratio = 1.0
    return {
        'verified': True, 'score': round(0.6 * ratio + 0.4 * col_ratio, 2),
        'columns': modal, 'multi_rows': len(multi), 'flat_rows': len(flat),
        'note': 'aligned' if has_coords else 'consistent cell counts (coordinates unavailable)',
        'rows': cell_rows,
    }


def _is_table_continuation_evidence(block: Dict[str, Any]) -> bool:
    '''True when a block looks like genuine table data rather than prose/references.

    Gates cross-page continuation linking so reference lists and body prose
    are never merged into phantom cross-page tables.
    '''
    if block.get('caption_anchor_id') or block.get('table_region'):
        return True
    text = block.get('text') or ''
    if _is_body_sentence(text) or _is_reference_list(text):
        return False
    if _is_numeric_dense_block(text):
        return True
    for line in text.splitlines():
        line = line.strip()
        if line and _is_table_cell_line(line):
            return True
    return False


def _anchor_cross_page_continuations(layout_blocks: List[Dict[str, Any]]) -> None:
    """Anchor a longtable continuation at the top of the next page to its caption.

    LaTeX longtables place a caption on the first page and repeat the header
    at the top of the next page without a new caption. This walk only fires
    when the caption's table on the current page reaches the bottom strip and
    the candidate block at the top of the next page repeats that table's
    header (token overlap >= 60%). The header-repeat requirement keeps figure
    labels and unrelated top-of-page content from being stolen, so without a
    repeated header no cross-page anchor is created.
    """
    captions = [block for block in layout_blocks or [] if _is_table_caption(block.get('text', ''))]
    for cap in captions:
        cap_id = _block_caption_id(cap)
        page = cap.get('page')
        if not cap_id or not page:
            continue
        page_height = float(cap.get('page_height') or 0)
        if not page_height:
            continue
        anchored = [
            block for block in layout_blocks or []
            if block.get('page') == page and block.get('caption_anchor_id') == cap_id
        ]
        anchored_bottom = max(
            (float((b.get('bbox') or [0, 0, 0, 0])[3]) for b in anchored),
            default=0.0,
        )
        cap_bottom = float((cap.get('bbox') or [0, 0, 0, 0])[3])
        if max(anchored_bottom, cap_bottom) < page_height * _CROSS_PAGE_BOTTOM_RATIO:
            continue
        prev_header = []
        for block in sorted(anchored, key=lambda b: (b.get('bbox') or [0, 0, 0, 0])[1]):
            lines = [
                line.strip() for line in (block.get('text') or '').splitlines()
                if line.strip() and _is_table_data_line(line.strip())
            ]
            if lines:
                prev_header = lines[:2]
                break
        if not prev_header:
            continue
        prev_tokens = set(re.findall(r'[A-Za-z0-9]+', ' '.join(prev_header).lower()))
        if len(prev_tokens) < 3:
            continue
        next_page = int(page) + 1
        next_height = 0.0
        cap_bbox = cap.get('bbox') or [0, 0, 0, 0]
        for block in layout_blocks or []:
            if block.get('page') == next_page:
                next_height = float(block.get('page_height') or 0)
                break
        if not next_height:
            continue
        captions_next = [
            block for block in layout_blocks or []
            if block.get('page') == next_page and _is_table_caption(block.get('text', ''))
        ]
        first_caption_y = min(
            (float((c.get('bbox') or [0, 0, 0, 0])[1]) for c in captions_next),
            default=float('inf'),
        )
        for block in layout_blocks or []:
            if block.get('page') != next_page:
                continue
            if block.get('caption_anchor_id') or block.get('continuation_group_id'):
                continue
            bbox = block.get('bbox') or [0, 0, 0, 0]
            if float(bbox[1]) > next_height * _CROSS_PAGE_TOP_RATIO:
                continue
            if float(bbox[1]) >= first_caption_y:
                continue
            if not _horizontal_overlap(bbox, [float(cap_bbox[0]), 0, float(cap_bbox[2]), next_height]):
                continue
            if block.get('type') == 'figure_caption' or _is_figure_caption(block.get('text', '')):
                continue
            if _is_table_caption(block.get('text', '')):
                continue
            cand_lines = [
                line.strip() for line in (block.get('text') or '').splitlines()
                if line.strip() and _is_table_data_line(line.strip())
            ]
            if not cand_lines:
                continue
            cand_tokens = set(re.findall(r'[A-Za-z0-9]+', ' '.join(cand_lines[:2]).lower()))
            overlap = len(prev_tokens & cand_tokens) / len(prev_tokens)
            if overlap >= 0.6:
                block['caption_anchor_id'] = cap_id


def _anchor_blocks_to_table_captions(layout_blocks: List[Dict[str, Any]]) -> None:
    '''Annotate table-like text blocks adjacent to a real table caption with its caption id.

    Covers GPT-3-style late captions (caption below the data) and word-list
    tables whose lines have no column gaps or pipes. Only strict table captions
    are used (``_is_table_caption``), only blocks at least 25% of the page width
    wide are anchored (figure axis labels and single-cell fragments are skipped),
    and the walk stops at body prose, another figure/table caption or a vertical
    gap larger than ``_ANCHOR_GAP_PT``.
    '''
    captions = [block for block in layout_blocks or [] if _is_table_caption(block.get('text', ''))]
    for cap in captions:
        cap_id = _block_caption_id(cap)
        cap_bbox = cap.get('bbox') or [0, 0, 0, 0]
        cap_y0, cap_y1 = float(cap_bbox[1]), float(cap_bbox[3])
        page = cap.get('page')
        page_width = 0.0
        for block in layout_blocks or []:
            if block.get('page') != page:
                continue
            bbox = block.get('bbox') or []
            if len(bbox) >= 4:
                try:
                    page_width = max(page_width, float(bbox[2]))
                except (TypeError, ValueError):
                    continue
        if not page_width:
            page_width = float(cap_bbox[2])
        min_width = page_width * 0.25
        peers = [
            block for block in layout_blocks or []
            if block is not cap
            and block.get('page') == page
            and block.get('type') == 'text'
            and not _is_table_caption(block.get('text', ''))
            and not _is_figure_caption(block.get('text', ''))
        ]
        # Caption above data (IEEE style): walk downward in the same column.
        below = sorted(
            (block for block in peers if (block.get('bbox') or [0, 0, 0, 0])[1] >= cap_y1 - 2),
            key=lambda block: (block.get('bbox') or [0, 0, 0, 0])[1],
        )
        prev_bottom = cap_y1
        for block in below:
            bbox = block.get('bbox') or [0, 0, 0, 0]
            if float(bbox[1]) - prev_bottom > _ANCHOR_GAP_PT:
                break
            if not _horizontal_overlap(bbox, cap_bbox):
                continue
            if block.get('type') == 'figure_caption' or _is_figure_caption(block.get('text', '')):
                break
            if _is_body_sentence(block.get('text', '')) and not _is_numeric_dense_block(block.get('text', '')):
                break
            if float(bbox[2]) - float(bbox[0]) < min_width:
                prev_bottom = max(prev_bottom, float(bbox[3]))
                continue
            block['caption_anchor_id'] = cap_id
            prev_bottom = max(prev_bottom, float(bbox[3]))
        # Late caption below data (GPT-3 style): walk upward in the same column.
        above = sorted(
            (block for block in peers if (block.get('bbox') or [0, 0, 0, 0])[3] <= cap_y0 + 2),
            key=lambda block: (block.get('bbox') or [0, 0, 0, 0])[3],
            reverse=True,
        )
        prev_top = cap_y0
        for block in above:
            bbox = block.get('bbox') or [0, 0, 0, 0]
            if prev_top - float(bbox[3]) > _ANCHOR_GAP_PT:
                break
            if not _horizontal_overlap(bbox, cap_bbox):
                continue
            if block.get('type') == 'figure_caption' or _is_figure_caption(block.get('text', '')):
                break
            if _is_body_sentence(block.get('text', '')) and not _is_numeric_dense_block(block.get('text', '')):
                break
            if float(bbox[2]) - float(bbox[0]) < min_width:
                prev_top = min(prev_top, float(bbox[1]))
                continue
            block['caption_anchor_id'] = cap_id
            prev_top = min(prev_top, float(bbox[1]))


def _reconstruct_tables(layout_blocks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    '''Group caption and row-like blocks into logical tables and merge cross-page continuations.

    Non-prose text blocks in the contiguous region around a caption (including
    GPT-3-style late captions below the data) are anchored to that caption, so
    word-list tables without column gaps or pipes are recovered as rows.
    Rows are heuristic reconstructions; tables whose columns align in PDF
    coordinates get ``cell_structure_verified=True``, the rest stay
    unverified with a reason and lower confidence.
    '''
    _anchor_blocks_to_table_captions(layout_blocks)
    _anchor_cross_page_continuations(layout_blocks)
    candidates = [
        block for block in layout_blocks or []
        if block.get('type') == 'table'
        or block.get('caption_anchor_id')
        or (block.get('type') == 'text' and _looks_like_table_row(block.get('text', '')))
    ]
    groups: Dict[str, List[Dict[str, Any]]] = {}
    for block in candidates:
        group_key = _block_caption_id(block)
        if not group_key:
            group_key = block.get('caption_anchor_id')
        if not group_key:
            group_key = block.get('continuation_group_id')
        if not group_key:
            group_key = _nearest_table_caption_id(block, candidates) or (
                'page-%s-y%s' % (block.get('page'), round((block.get('bbox') or [0, 0])[1], 1))
            )
        groups.setdefault(str(group_key), []).append(block)
        # Pass the parser's page-local grouping to RAG instead of discarding
        # the association and then merging rows into unrelated body prose.
        block['table_id'] = 'table-%s' % group_key

    tables = []
    for group_key in sorted(groups):
        blocks = sorted(
            groups[group_key],
            key=lambda block: (int(block.get('page', 0) or 0), (block.get('bbox') or [0, 0])[1]),
        )
        pages = sorted({int(block.get('page', 0) or 0) for block in blocks})
        caption = ''
        for block in blocks:
            for line in (block.get('text') or '').splitlines():
                if _is_table_caption_line(line.strip()):
                    caption = line.strip()
                    break
            if caption:
                break
        merged_lines = []
        header_lines: List[str] = []
        header_repeated = False
        for index, block in enumerate(blocks):
            block_has_caption = _block_caption_id(block) is not None
            data_lines = []
            for raw_line in (block.get('text') or '').splitlines():
                line = raw_line.strip()
                if not line or not _is_table_data_line(line):
                    continue
                if block_has_caption and not _is_table_cell_line(line):
                    continue
                data_lines.append(line)
            if index == 0:
                header_lines = data_lines[:2]
            if index > 0:
                before = list(data_lines)
                while data_lines and header_lines and data_lines[0] == header_lines[0]:
                    data_lines.pop(0)
                header_repeated = header_repeated or len(data_lines) < len(before)
            merged_lines.extend(data_lines)
        merged_text = '\n'.join(merged_lines)
        verification = _verify_cell_alignment(blocks)
        continuation = len(pages) > 1
        page_span = 'p. %d' % pages[0] if len(pages) == 1 else 'p. %d-%d' % (pages[0], pages[-1])
        has_numeric_data = any(re.search(r'\d', line) for line in merged_lines)
        # A lone row fragment without any caption is not a usable logical table.
        lone_fragment = (
            len(blocks) == 1
            and len(merged_lines) <= 2
            and not blocks[0].get('table_region')
            and not _is_table_caption(blocks[0].get('text', ''))
            and not _looks_like_table(blocks[0].get('text', ''))
        )
        no_anchor_stack = not caption and len(blocks) == 1 and not has_numeric_data
        if lone_fragment or no_anchor_stack:
            continue
        verified = bool(verification.get('verified'))
        if not caption:
            # Uncaptioned groups are kept only when anchored to a real caption,
            # verified by coordinate alignment, or carrying dense numeric data.
            # This drops reference lists, author/affiliation blocks, body prose
            # and figure axis labels that slipped through block classification.
            if _is_reference_list(merged_text):
                continue
            anchored = any(block.get('caption_anchor_id') for block in blocks)
            numeric_dense = _is_numeric_dense_block(merged_text)
            if numeric_dense and _looks_like_uncaptioned_axis_labels(merged_text):
                numeric_dense = False
            if not (anchored or verified or numeric_dense):
                continue
        cell_matrix = None
        if verified:
            cell_matrix = [
                [cell[:60] for cell in row[:12]]
                for row in (verification.get('rows') or [])[:40]
            ]
        base_confidence = 0.62 if verified else 0.50
        if continuation:
            base_confidence = 0.55 if verified else 0.40
        cell_quote_allowed = bool(verified and cell_matrix and not continuation)
        cell_quote_block_reason = ''
        if continuation:
            # Page-to-page row continuity cannot be proven from local cell
            # coordinates alone. Keep the matrix as parser evidence, but do
            # not grant exact cell citation permission across page breaks.
            cell_quote_block_reason = 'cross_page_row_continuity_unverified'
        elif not verified or not cell_matrix:
            cell_quote_block_reason = 'cell_structure_not_verified'
        # For verified tables the cell matrix is the ground truth row count;
        # the merged-text line count counts one line per PDF cell and overcounts.
        effective_row_count = len(cell_matrix) if verified and cell_matrix else len(merged_lines)
        tables.append({
            'table_id': 'table-%s' % group_key,
            'pages': pages,
            'page_span': page_span,
            'continuation': continuation,
            'continuation_group_id': group_key if continuation else None,
            'header_repeated': header_repeated,
            'caption': caption,
            'row_count': effective_row_count,
            'cell_structure_verified': verified,
            'cell_verification_score': verification.get('score', 0.0),
            'cell_columns': verification.get('columns', 1),
            'cell_verification_note': verification.get('note', ''),
            'merged_text': merged_text,
            'char_count': len(merged_text),
            'confidence': round(base_confidence, 2),
            'cell_matrix': cell_matrix,
            'cell_quote_allowed': cell_quote_allowed,
            'cell_quote_block_reason': cell_quote_block_reason,
            'block_ids': [b.get('block_id') for b in blocks],
        })
    return tables


def _is_strong_formula(text: str) -> bool:
    '''A formula is strong when it carries real math operators/glyphs.'''
    compact = re.sub(r'\s+', '', text or '')
    if not compact or len(compact) > 400:
        return False
    operator_count = len(_MATH_OPERATOR_RE.findall(compact))
    symbol_count = len(_MATH_SYMBOL_CHARS_RE.findall(compact))
    density = symbol_count / max(1, len(compact))
    return operator_count >= 2 or (symbol_count >= 3 and density >= 0.04)


def _is_formula_noise(text: str) -> bool:
    """Drop table rows, body paragraphs, captions, URLs, and appendix labels."""
    if not text or re.search(r'(?i)https?://|www\.|commoncrawl|github\.com', text):
        return True
    if _is_table_caption(text) or _is_figure_caption(text):
        return True
    if _is_tabular_row(text) or _is_body_sentence(text):
        return True
    if re.search(r'(?i)coRR, abs/|arxiv preprint|^\s*\[[^\]]+\]\s+[A-Z]', text):
        return True
    if _is_reference_list(text):
        return True
    if re.search(r'(?im)^-{4,}', text):
        return True  # divider lines like "-------- Generated Poem 1 --------"
    if re.search(r'(?im)^\s*(correct answer|incorrect answer|context|target completion|title:)\s*[\u2192:\-]', text):
        return True  # appendix example templates
    return False


def _collect_formulas(layout_blocks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    '''Collect formula blocks into a structured, explicitly uncertain list.

    Strong formulas get a best-effort latex_guess; weak/noisy blocks stay in the
    list flagged low-confidence so downstream agents cannot quote them as verified.
    '''
    formulas = []
    for block in layout_blocks or []:
        if block.get('type') != 'formula':
            continue
        text = block.get('text', '')
        if _is_formula_noise(text):
            continue
        strong = _is_strong_formula(text)
        record = {
            'formula_id': block.get('block_id') or ('formula-p%s' % block.get('page')),
            'page': block.get('page'),
            'text': text,
            'glyph_confidence': block.get('glyph_confidence') or _formula_glyph_confidence(text),
            'structure_uncertain': True,
            'strong_formula': strong,
        }
        if strong:
            record['latex_guess'] = block.get('latex_guess') or _normalize_formula_text(text)
        formulas.append(record)
    return formulas


def _result(
    parser: str,
    pages: List[Dict[str, Any]],
    page_count: int,
    error: Optional[str] = None,
    layout_blocks: Optional[List[Dict[str, Any]]] = None,
    tables: Optional[List[Dict[str, Any]]] = None,
    formulas: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    text_page_count = sum(bool(page.get('text')) for page in pages)
    text = _format_pages(pages)
    layout_blocks = layout_blocks or []
    quality_by_page: Dict[str, Dict[str, Any]] = {}
    all_warnings: List[str] = []
    all_failure_modes: List[str] = []
    for page in pages:
        page_number = str(page['page'])
        page_blocks = [block for block in layout_blocks if block.get('page') == page['page']]
        quality = _page_quality(page, page_blocks)
        quality_by_page[page_number] = quality
        all_warnings.extend(f"p. {page_number}: {warning}" for warning in quality['warnings'])
        all_failure_modes.extend(quality['failure_modes'])
    confidences = [quality['confidence'] for quality in quality_by_page.values()]
    return {
        'success': bool(text),
        'parser': parser,
        'pages': pages,
        'text': text,
        'page_count': page_count,
        'text_page_count': text_page_count,
        'empty_page_count': max(0, page_count - text_page_count),
        'content_length': len(text),
        'extraction_status': 'parsed' if text else 'needs_ocr',
        'error': None if text else (error or 'No extractable text was found. This PDF may be scanned or image-only and requires OCR.'),
        'layout_blocks': layout_blocks,
        'tables': tables or [],
        'formulas': formulas or [],
        'parse_quality': {
            'overall_confidence': round(sum(confidences) / len(confidences), 2) if confidences else 0.0,
            'page_confidence': {page: quality['confidence'] for page, quality in quality_by_page.items()},
            'warnings': all_warnings,
            'failure_modes': sorted(set(all_failure_modes)),
        },
    }


def _resource_limit_result(
    error_code: str,
    message: str,
    limit_name: str,
    limit_value: int,
    observed_value: int,
    *,
    page_count: int = 0,
    parser: Optional[str] = None,
) -> Dict[str, Any]:
    """Return a stable fail-closed result without partial evidence text."""
    return {
        'success': False,
        'parser': parser,
        'pages': [],
        'text': '',
        'page_count': max(0, int(page_count or 0)),
        'text_page_count': 0,
        'empty_page_count': max(0, int(page_count or 0)),
        'content_length': 0,
        'extraction_status': 'resource_limited',
        'error': message,
        'error_code': error_code,
        'resource_limit': {
            'name': limit_name,
            'limit': int(limit_value),
            'observed': int(observed_value),
        },
        'layout_blocks': [],
        'tables': [],
        'formulas': [],
        'parse_quality': {
            'overall_confidence': 0.0,
            'page_confidence': {},
            'warnings': [message],
            'failure_modes': ['resource_limited'],
        },
    }


def _page_limit_result(page_count: int, parser: Optional[str] = None) -> Dict[str, Any]:
    return _resource_limit_result(
        'PDF_PAGE_LIMIT_EXCEEDED',
        'PDF exceeds the configured page limit.',
        'max_pages',
        PDF_PARSE_MAX_PAGES,
        page_count,
        page_count=page_count,
        parser=parser,
    )


def _text_limit_result(observed: int, page_count: int, parser: Optional[str] = None) -> Dict[str, Any]:
    return _resource_limit_result(
        'PDF_TEXT_LIMIT_EXCEEDED',
        'PDF extracted text exceeds the configured character limit.',
        'max_text_chars',
        PDF_PARSE_MAX_TEXT_CHARS,
        observed,
        page_count=page_count,
        parser=parser,
    )



def build_parse_metadata(parsed: Dict[str, Any], preview_chars: int = 300) -> Dict[str, Any]:
    """Return the stable, JSON-safe PDF metadata schema used by every entrypoint.

    The text itself stays in the caller's response.  This metadata exposes the
    parser's structural limits (layout, tables, formulas, figures, OCR and
    page-level confidence) without duplicating the potentially large page text.
    """
    try:
        preview_chars = max(0, int(preview_chars))
    except (TypeError, ValueError):
        preview_chars = 300

    page_summaries = []
    for page in parsed.get('pages') or []:
        page_summaries.append({
            'page': page.get('page'),
            'char_count': page.get('char_count', len(page.get('text') or '')),
            'ocr': bool(page.get('ocr')),
            'layout': page.get('layout'),
            'reading_order_confidence': page.get('reading_order_confidence'),
            'visuals': page.get('visuals') or {},
            'cross_page_table_risk': bool(page.get('cross_page_table_risk')),
            'text_source': page.get('text_source'),
            'symbol_font_mapped_blocks': page.get('symbol_font_mapped_blocks', 0),
            'preview': (page.get('text') or '')[:preview_chars],
        })

    block_summaries = []
    for block in parsed.get('layout_blocks') or []:
        block_summaries.append({
            'page': block.get('page'),
            'block_id': block.get('block_id'),
            'bbox': block.get('bbox'),
            'column': block.get('column'),
            'type': block.get('type'),
            'confidence': block.get('confidence'),
            'continuation_group_id': block.get('continuation_group_id'),
            'encoding_repaired': block.get('encoding_repaired'),
            'symbol_font_mapped': bool(block.get('symbol_font_mapped')),
        })

    table_summaries = []
    for table in parsed.get('tables') or []:
        table_summaries.append({
            'table_id': table.get('table_id'),
            'page_span': table.get('page_span'),
            'pages': table.get('pages'),
            'continuation': bool(table.get('continuation')),
            'continuation_group_id': table.get('continuation_group_id'),
            'header_repeated': bool(table.get('header_repeated')),
            'caption': table.get('caption'),
            'row_count': table.get('row_count'),
            'cell_structure_verified': bool(table.get('cell_structure_verified')),
            'cell_verification_score': table.get('cell_verification_score'),
            'cell_columns': table.get('cell_columns'),
            'ocr_cross_checked': bool(table.get('ocr_cross_checked')),
            'ocr_match_ratio': table.get('ocr_match_ratio'),
            'ocr_discrepancy': bool(table.get('ocr_discrepancy')),
            'confidence': table.get('confidence'),
            'cell_matrix': table.get('cell_matrix'),
            'merged_preview': (table.get('merged_text') or '')[:preview_chars],
            # Full digest of reconstructed cell rows so downstream numeric verification can
            # match table values even when they are absent from the compact page previews.
            'merged_text': (table.get('merged_text') or '')[:6000],
        })

    formula_summaries = []
    for formula in parsed.get('formulas') or []:
        formula_summaries.append({
            'formula_id': formula.get('formula_id'),
            'page': formula.get('page'),
            'glyph_confidence': formula.get('glyph_confidence'),
            'latex_guess': (formula.get('latex_guess') or '')[:preview_chars],
            'structure_uncertain': bool(formula.get('structure_uncertain')),
            'strong_formula': bool(formula.get('strong_formula')),
        })

    return {
        'parser': parsed.get('parser'),
        'page_count': parsed.get('page_count', 0),
        'text_page_count': parsed.get('text_page_count', 0),
        'empty_page_count': parsed.get('empty_page_count', 0),
        'content_length': parsed.get('content_length', len(parsed.get('text') or '')),
        'extraction_status': parsed.get('extraction_status'),
        'error_code': parsed.get('error_code'),
        'resource_limit': parsed.get('resource_limit') or {},
        'parser_failures': parsed.get('parser_failures') or [],
        # Keep parser-level facts separate from any later Agent/context window
        # truncation. Writers must never recompute these from a shortened file.
        'parser_status': {
            'page_count': parsed.get('page_count', 0),
            'text_page_count': parsed.get('text_page_count', 0),
            'empty_page_count': parsed.get('empty_page_count', 0),
            'content_length': parsed.get('content_length', len(parsed.get('text') or '')),
            'extraction_status': parsed.get('extraction_status'),
            'parser': parsed.get('parser'),
            'error_code': parsed.get('error_code'),
            'resource_limit': parsed.get('resource_limit') or {},
        },
        'ocr_engine': parsed.get('ocr_engine'),
        'ocr_language': parsed.get('ocr_language'),
        'ocr_cross_check': parsed.get('ocr_cross_check') or {},
        'parse_quality': parsed.get('parse_quality') or {},
        'risk_summary': build_risk_summary(parsed),
        'layout_blocks': block_summaries,
        'tables': table_summaries,
        'formulas': formula_summaries,
        'pages': page_summaries,
        'recovery': {
            'encoding_repaired_blocks': sum(1 for b in parsed.get('layout_blocks') or [] if b.get('encoding_repaired')),
            'symbol_font_mapped_blocks': sum(1 for b in parsed.get('layout_blocks') or [] if b.get('symbol_font_mapped')),
            'encoding_repaired_pages': [pg.get('page') for pg in parsed.get('pages') or [] if str(pg.get('text_source') or '').startswith('encoding-repaired')],
            'pdfminer_fallback_pages': [pg.get('page') for pg in parsed.get('pages') or [] if pg.get('text_source') == 'pdfminer-fallback'],
        },
        'parse_error': parsed.get('error'),
    }

def _normalize_ocr_tokens(text: str) -> set:
    return set(re.findall(r'[A-Za-z0-9]+', (text or '').lower()))


def _ocr_language(engine: str) -> str:
    """Choose configured OCR languages that are actually installed."""
    requested = os.getenv('SCIASSISTANT_OCR_LANG', 'eng+chi_sim')
    tessdata = Path(engine).parent / 'tessdata'
    available = {path.stem for path in tessdata.glob('*.traineddata')}
    languages = [item for item in requested.split('+') if item in available]
    if not languages and 'eng' in available:
        languages = ['eng']
    return '+'.join(languages) or requested


def _ocr_cross_check_tables(document: Any, tables: List[Dict[str, Any]],
                            layout_blocks: List[Dict[str, Any]], dpi: int = 180) -> Dict[str, Any]:
    """Cross-check reconstructed table text against OCR of its rendered regions.

    Each table's page regions are rendered with PyMuPDF and read back with
    Tesseract when an engine is installed. A low token-overlap ratio flags
    ``ocr_discrepancy`` so downstream writers never treat the text layer as
    fully reliable for that table. Without Tesseract the result is
    ``unavailable`` and parsing continues unchanged.
    """
    engine = _find_tesseract()
    if not engine:
        return {
            'status': 'unavailable', 'engine': None, 'tables_checked': 0,
            'tables_with_discrepancy': 0, 'mean_match_ratio': 0.0,
            'note': 'Tesseract OCR not installed; table text relies on the PDF text layer only.',
            'table_limit': PDF_PARSE_MAX_TABLE_OCR_CHECKS,
            'limit_reached': False,
        }
    lang = _ocr_language(engine)
    blocks_by_id = {b.get('block_id'): b for b in layout_blocks or []}
    checked = 0
    discrepant = 0
    ratios: List[float] = []
    table_candidates = list(tables or [])
    limit_reached = False
    ocr_attempts = 0
    deadline = time.monotonic() + PDF_PARSE_TABLE_OCR_TOTAL_TIMEOUT_SECONDS
    try:
        import fitz
        from PIL import Image
        matrix = fitz.Matrix(dpi / 72, dpi / 72)
        with tempfile.TemporaryDirectory() as tmpdir:
            for table in table_candidates:
                if ocr_attempts >= PDF_PARSE_MAX_TABLE_OCR_CHECKS or time.monotonic() >= deadline:
                    limit_reached = True
                    break
                page_blocks: Dict[int, List[Dict[str, Any]]] = {}
                for block_id in table.get('block_ids') or []:
                    block = blocks_by_id.get(block_id)
                    if not block or not block.get('bbox'):
                        continue
                    page_blocks.setdefault(int(block.get('page', 0)), []).append(block)
                if not page_blocks:
                    continue
                extracted = set()
                for blocks in page_blocks.values():
                    for block in blocks:
                        extracted |= _normalize_ocr_tokens(block.get('text') or '')
                if not extracted:
                    continue
                ocr_tokens: set = set()
                for page_number, blocks in sorted(page_blocks.items()):
                    remaining = deadline - time.monotonic()
                    if ocr_attempts >= PDF_PARSE_MAX_TABLE_OCR_CHECKS or remaining <= 0:
                        limit_reached = True
                        break
                    if page_number < 1 or page_number > document.page_count:
                        continue
                    x0 = min(float((b.get('bbox') or [0, 0, 0, 0])[0]) for b in blocks)
                    y0 = min(float((b.get('bbox') or [0, 0, 0, 0])[1]) for b in blocks)
                    x1 = max(float((b.get('bbox') or [0, 0, 0, 0])[2]) for b in blocks)
                    y1 = max(float((b.get('bbox') or [0, 0, 0, 0])[3]) for b in blocks)
                    clip = fitz.Rect(x0 - 2, y0 - 2, x1 + 2, y1 + 2)
                    estimated_pixels = int(
                        max(0.0, clip.width) * (dpi / 72)
                        * max(0.0, clip.height) * (dpi / 72)
                    )
                    if estimated_pixels > PDF_PARSE_MAX_RENDER_PIXELS:
                        limit_reached = True
                        continue
                    pixmap = document[page_number - 1].get_pixmap(matrix=matrix, clip=clip, alpha=False)
                    image_path = Path(tmpdir) / f'table_{page_number}.png'
                    image = Image.frombytes('RGB', [pixmap.width, pixmap.height], pixmap.samples)
                    image.save(image_path)
                    command = [engine, str(image_path), 'stdout', '-l', lang, '--psm', '6']
                    ocr_attempts += 1
                    try:
                        completed = subprocess.run(
                            command, capture_output=True, text=True, encoding='utf-8',
                            errors='replace', timeout=max(1, min(
                                PDF_PARSE_OCR_PAGE_TIMEOUT_SECONDS, int(remaining)
                            )),
                        )
                    except subprocess.TimeoutExpired:
                        limit_reached = True
                        break
                    if completed.returncode != 0 and lang != 'eng':
                        remaining = deadline - time.monotonic()
                        if remaining <= 0 or ocr_attempts >= PDF_PARSE_MAX_TABLE_OCR_CHECKS:
                            limit_reached = True
                            break
                        command = [engine, str(image_path), 'stdout', '-l', 'eng', '--psm', '6']
                        ocr_attempts += 1
                        try:
                            completed = subprocess.run(
                                command, capture_output=True, text=True, encoding='utf-8',
                                errors='replace', timeout=max(1, min(
                                    PDF_PARSE_OCR_PAGE_TIMEOUT_SECONDS, int(remaining)
                                )),
                            )
                        except subprocess.TimeoutExpired:
                            limit_reached = True
                            break
                    if completed.returncode != 0:
                        continue
                    ocr_tokens |= _normalize_ocr_tokens(completed.stdout)
                if not ocr_tokens:
                    continue
                matched = len(extracted & ocr_tokens)
                ratio = matched / len(extracted)
                ratios.append(ratio)
                checked += 1
                table['ocr_cross_checked'] = True
                table['ocr_match_ratio'] = round(ratio, 2)
                table['ocr_discrepancy'] = ratio < 0.5
                if table['ocr_discrepancy']:
                    discrepant += 1
                    table['confidence'] = round(min(table.get('confidence', 0.5), 0.42), 2)
                elif ratio >= 0.7 and table.get('cell_structure_verified'):
                    table['confidence'] = round(max(table.get('confidence', 0.5), 0.65 if not table.get('continuation') else 0.58), 2)
        return {
            'status': 'enabled', 'engine': Path(engine).name, 'tables_checked': checked,
            'tables_with_discrepancy': discrepant,
            'mean_match_ratio': round(sum(ratios) / len(ratios), 2) if ratios else 0.0,
            'lang': lang,
            'table_limit': PDF_PARSE_MAX_TABLE_OCR_CHECKS,
            'limit_reached': limit_reached,
            'ocr_attempts': ocr_attempts,
            'time_budget_seconds': PDF_PARSE_TABLE_OCR_TOTAL_TIMEOUT_SECONDS,
            'render_pixel_limit': PDF_PARSE_MAX_RENDER_PIXELS,
        }
    except Exception:
        return {
            'status': 'failed', 'engine': Path(engine).name, 'tables_checked': checked,
            'tables_with_discrepancy': discrepant,
            'mean_match_ratio': round(sum(ratios) / len(ratios), 2) if ratios else 0.0,
            'note': 'OCR cross-check failed.',
            'error_code': 'OCR_CROSS_CHECK_FAILED',
            'table_limit': PDF_PARSE_MAX_TABLE_OCR_CHECKS,
            'limit_reached': limit_reached,
            'ocr_attempts': ocr_attempts,
            'time_budget_seconds': PDF_PARSE_TABLE_OCR_TOTAL_TIMEOUT_SECONDS,
            'render_pixel_limit': PDF_PARSE_MAX_RENDER_PIXELS,
        }


def _find_tesseract() -> Optional[str]:
    configured = os.getenv('TESSERACT_CMD') or os.getenv('TESSERACT_PATH')
    candidates = [
        configured,
        shutil.which('tesseract'),
        r'C:\Program Files\Tesseract-OCR\tesseract.exe',
        r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe',
    ]
    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return str(candidate)
    return None


def _ocr_pdf(path: Path, page_count_hint: int = 0, dpi: int = 200) -> Dict[str, Any]:
    tesseract = _find_tesseract()
    if not tesseract:
        return {
            'success': False,
            'parser': 'ocr',
            'pages': [],
            'text': '',
            'page_count': page_count_hint,
            'text_page_count': 0,
            'empty_page_count': page_count_hint,
            'content_length': 0,
            'extraction_status': 'ocr_unavailable',
            'error': 'OCR engine not found. Install Tesseract OCR and ensure tesseract.exe is on PATH or set TESSERACT_CMD.',
            'error_code': 'OCR_UNAVAILABLE',
        }

    lang = _ocr_language(tesseract)
    try:
        import fitz
        from PIL import Image

        pages = []
        with fitz.open(path) as document, tempfile.TemporaryDirectory() as tmpdir:
            page_count = len(document)
            if page_count > PDF_PARSE_MAX_OCR_PAGES:
                return _resource_limit_result(
                    'PDF_OCR_PAGE_LIMIT_EXCEEDED',
                    'PDF exceeds the configured OCR page limit.',
                    'max_ocr_pages',
                    PDF_PARSE_MAX_OCR_PAGES,
                    page_count,
                    page_count=page_count,
                    parser='tesseract-ocr',
                )
            matrix = fitz.Matrix(dpi / 72, dpi / 72)
            total_chars = 0
            started = time.monotonic()
            deadline = started + PDF_PARSE_OCR_TOTAL_TIMEOUT_SECONDS
            for page_number, page in enumerate(document, 1):
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return _resource_limit_result(
                        'PDF_OCR_TIME_LIMIT_EXCEEDED',
                        'PDF OCR exceeded the configured time budget.',
                        'max_ocr_seconds',
                        PDF_PARSE_OCR_TOTAL_TIMEOUT_SECONDS,
                        max(PDF_PARSE_OCR_TOTAL_TIMEOUT_SECONDS, int(time.monotonic() - started)),
                        page_count=page_count,
                        parser='tesseract-ocr',
                    )
                estimated_pixels = int(
                    max(0.0, float(page.rect.width)) * (dpi / 72)
                    * max(0.0, float(page.rect.height)) * (dpi / 72)
                )
                if estimated_pixels > PDF_PARSE_MAX_RENDER_PIXELS:
                    return _resource_limit_result(
                        'PDF_OCR_RENDER_LIMIT_EXCEEDED',
                        'A PDF page exceeds the configured OCR render pixel limit.',
                        'max_render_pixels',
                        PDF_PARSE_MAX_RENDER_PIXELS,
                        estimated_pixels,
                        page_count=page_count,
                        parser='tesseract-ocr',
                    )
                pixmap = page.get_pixmap(matrix=matrix, alpha=False)
                image_path = Path(tmpdir) / f'page_{page_number}.png'
                image = Image.frombytes('RGB', [pixmap.width, pixmap.height], pixmap.samples)
                image.save(image_path)

                command = [tesseract, str(image_path), 'stdout', '-l', lang, '--psm', '6']
                try:
                    completed = subprocess.run(
                        command, capture_output=True, text=True, encoding='utf-8',
                        errors='replace', timeout=max(1, min(
                            PDF_PARSE_OCR_PAGE_TIMEOUT_SECONDS, int(remaining)
                        )),
                    )
                except subprocess.TimeoutExpired:
                    return _resource_limit_result(
                        'PDF_OCR_PAGE_TIMEOUT',
                        'A PDF OCR page exceeded the configured time limit.',
                        'ocr_page_timeout_seconds',
                        PDF_PARSE_OCR_PAGE_TIMEOUT_SECONDS,
                        PDF_PARSE_OCR_PAGE_TIMEOUT_SECONDS,
                        page_count=page_count,
                        parser='tesseract-ocr',
                    )
                if completed.returncode != 0 and lang != 'eng':
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        return _resource_limit_result(
                            'PDF_OCR_TIME_LIMIT_EXCEEDED',
                            'PDF OCR exceeded the configured time budget.',
                            'max_ocr_seconds',
                            PDF_PARSE_OCR_TOTAL_TIMEOUT_SECONDS,
                            max(PDF_PARSE_OCR_TOTAL_TIMEOUT_SECONDS, int(time.monotonic() - started)),
                            page_count=page_count,
                            parser='tesseract-ocr',
                        )
                    command = [tesseract, str(image_path), 'stdout', '-l', 'eng', '--psm', '6']
                    try:
                        completed = subprocess.run(
                            command, capture_output=True, text=True, encoding='utf-8',
                            errors='replace', timeout=max(1, min(
                                PDF_PARSE_OCR_PAGE_TIMEOUT_SECONDS, int(remaining)
                            )),
                        )
                    except subprocess.TimeoutExpired:
                        return _resource_limit_result(
                            'PDF_OCR_PAGE_TIMEOUT',
                            'A PDF OCR page exceeded the configured time limit.',
                            'ocr_page_timeout_seconds',
                            PDF_PARSE_OCR_PAGE_TIMEOUT_SECONDS,
                            PDF_PARSE_OCR_PAGE_TIMEOUT_SECONDS,
                            page_count=page_count,
                            parser='tesseract-ocr',
                        )
                if completed.returncode != 0:
                    raise RuntimeError((completed.stderr or completed.stdout or 'unknown OCR error').strip())

                page_text = _clean_text(completed.stdout)
                total_chars += len(page_text)
                if total_chars > PDF_PARSE_MAX_TEXT_CHARS:
                    return _text_limit_result(total_chars, page_count, 'tesseract-ocr')
                pages.append({'page': page_number, 'text': page_text, 'char_count': len(page_text), 'ocr': True})

        parsed = _result('tesseract-ocr', pages, len(pages), 'OCR completed but no text was recognized.')
        parsed['ocr_engine'] = Path(tesseract).name
        parsed['ocr_language'] = lang
        return parsed
    except Exception:
        return {
            'success': False,
            'parser': 'tesseract-ocr',
            'pages': [],
            'text': '',
            'page_count': page_count_hint,
            'text_page_count': 0,
            'empty_page_count': page_count_hint,
            'content_length': 0,
            'extraction_status': 'ocr_failed',
            'error': 'OCR processing failed.',
            'error_code': 'OCR_PROCESSING_FAILED',
            'ocr_engine': Path(tesseract).name,
            'ocr_language': lang,
        }


def parse_pdf(path: Path, enable_ocr: bool = True) -> Dict[str, Any]:
    """Parse a PDF, reusing a content-addressed disk cache across runs.

    The Web task model pays one full parse per uploaded paper per process;
    this cache turns every later run over the same file into a load. Only
    successful parses are cached, and each cached record carries
    ``cache_hit`` so a report can show whether this parse was freshly
    paid for or reused.
    """
    cache_path = _pdf_parse_cache_path(path, enable_ocr)
    if cache_path is not None and cache_path.exists():
        try:
            if cache_path.stat().st_size > PDF_PARSE_CACHE_MAX_BYTES:
                cached = None
            else:
                cached = json.loads(cache_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            cached = None
        if isinstance(cached, dict) and cached.get("success"):
            cached_page_count = int(cached.get("page_count") or 0)
            cached_content_length = int(cached.get("content_length") or len(cached.get("text") or ""))
            if cached_page_count > PDF_PARSE_MAX_PAGES:
                return _page_limit_result(cached_page_count, cached.get("parser"))
            if cached_content_length > PDF_PARSE_MAX_TEXT_CHARS:
                return _text_limit_result(
                    cached_content_length, cached_page_count, cached.get("parser")
                )
            cached["cache_hit"] = True
            return cached
    result = _parse_pdf_uncached(path, enable_ocr)
    if result.get("success"):
        result["cache_hit"] = False
        _write_pdf_parse_cache(cache_path, result)
    return result


def _pdf_parse_cache_path(path: Path, enable_ocr: bool):
    """Content-addressed cache file for one PDF, or None if unhashable."""
    try:
        digest_builder = hashlib.sha256()
        with Path(path).open("rb") as source:
            while True:
                chunk = source.read(1024 * 1024)
                if not chunk:
                    break
                digest_builder.update(chunk)
        digest = digest_builder.hexdigest()[:32]
    except OSError:
        return None
    name = f"{digest}-ocr{int(bool(enable_ocr))}.json"
    from user_credentials import scoped_storage
    return scoped_storage(PDF_PARSE_CACHE_DIR) / PDF_PARSE_CACHE_VERSION / name


def _write_pdf_parse_cache(cache_path, result: Dict[str, Any]) -> None:
    try:
        payload = json.dumps(result, ensure_ascii=False, default=str)
        if len(payload.encode("utf-8")) > PDF_PARSE_CACHE_MAX_BYTES:
            return
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = cache_path.with_suffix(".tmp")
        tmp.write_text(payload, encoding="utf-8")
        tmp.replace(cache_path)
    except (OSError, TypeError, ValueError):
        pass


def _parse_pdf_uncached(path: Path, enable_ocr: bool = True) -> Dict[str, Any]:
    """Extract a PDF with a stable record for every physical page."""
    path = Path(path)
    failed = {
        'success': False,
        'parser': None,
        'pages': [],
        'text': '',
        'page_count': 0,
        'text_page_count': 0,
        'empty_page_count': 0,
        'content_length': 0,
        'extraction_status': 'failed',
        'error': None,
        'error_code': 'PDF_PARSE_FAILED',
        'parser_failures': [],
    }
    try:
        if not path.exists():
            failed['error'] = 'PDF file does not exist'
            failed['error_code'] = 'PDF_NOT_FOUND'
            return failed
        if path.stat().st_size == 0:
            failed['error'] = 'PDF file is empty'
            failed['error_code'] = 'PDF_EMPTY'
            return failed
        with path.open('rb') as source:
            header = source.read(5)
        if header != b'%PDF-':
            failed['error'] = 'File header is not PDF'
            failed['error_code'] = 'PDF_INVALID_HEADER'
            return failed
    except OSError:
        failed['error'] = 'PDF file could not be read.'
        failed['error_code'] = 'PDF_READ_FAILED'
        return failed

    try:
        import fitz
        with fitz.open(path) as document:
            page_count = len(document)
            if page_count > PDF_PARSE_MAX_PAGES:
                return _page_limit_result(page_count, 'pymupdf')
            page_records = []
            layout_blocks = []
            total_chars = 0
            for page_number, page in enumerate(document, 1):
                page_blocks, layout, visuals, symbol_mapped = _layout_blocks_from_page(page, page_number)
                page_text = '\n\n'.join(block['text'] for block in page_blocks)
                total_chars += len(page_text)
                if total_chars > PDF_PARSE_MAX_TEXT_CHARS:
                    return _text_limit_result(total_chars, page_count, 'pymupdf')
                page_records.append({
                    'page': page_number,
                    'text': page_text,
                    'char_count': len(page_text),
                    'layout': layout,
                    'visuals': visuals,
                    'text_source': 'pymupdf',
                    'symbol_font_mapped_blocks': symbol_mapped,
                    'height': round(float(page.rect.height), 2),
                    'reading_order_confidence': min(
                        (float(block.get('reading_order_confidence', 1.0)) for block in page_blocks),
                        default=(0.0 if layout == 'layout_uncertain' else 1.0),
                    ),
                    'reading_order_strategy': (
                        page_blocks[0].get('reading_order_strategy')
                        if page_blocks else ('unknown' if layout == 'layout_uncertain' else 'top_to_bottom_left_to_right')
                    ),
                    'column_sequence': [
                        block.get('column') for block in page_blocks
                        if block.get('column') in {'left', 'right', 'full'}
                    ],
                })
                layout_blocks.extend(page_blocks)
            _apply_encoding_recovery(page_records, path)
            pages = page_records
            _mark_cross_page_table_risks(pages, layout_blocks)
            tables = _reconstruct_tables(layout_blocks)
            formulas = _collect_formulas(layout_blocks)
            if enable_ocr:
                ocr_cross_check = _ocr_cross_check_tables(document, tables, layout_blocks)
            else:
                ocr_cross_check = {
                    'status': 'disabled', 'engine': None, 'tables_checked': 0,
                    'tables_with_discrepancy': 0, 'mean_match_ratio': 0.0,
                }
            parsed = _result(
                'pymupdf', pages, len(document),
                layout_blocks=layout_blocks, tables=tables, formulas=formulas,
            )
            parsed['ocr_cross_check'] = ocr_cross_check
        if parsed['success']:
            return parsed
        failed.update(parsed)
    except Exception:
        failed['parser_failures'].append({'parser': 'pymupdf', 'error_code': 'PARSER_FAILED'})
        failed['error'] = 'PDF parsing failed with PyMuPDF.'

    try:
        from pdfminer.high_level import extract_text
        raw_text = extract_text(str(path), maxpages=PDF_PARSE_MAX_PAGES + 1) or ''
        if len(raw_text) > PDF_PARSE_MAX_TEXT_CHARS:
            return _text_limit_result(len(raw_text), 0, 'pdfminer.six')
        raw_pages = raw_text.split('\f')
        if raw_pages and not raw_pages[-1].strip():
            raw_pages.pop()
        if len(raw_pages) > PDF_PARSE_MAX_PAGES:
            return _page_limit_result(len(raw_pages), 'pdfminer.six')
        pages = []
        for page_number, raw_text in enumerate(raw_pages, 1):
            page_text = _clean_text(raw_text)
            pages.append({'page': page_number, 'text': page_text, 'char_count': len(page_text)})
        parsed = _result('pdfminer.six', pages, len(pages))
        if parsed['success']:
            return parsed
        failed.update(parsed)
    except Exception:
        failed['parser_failures'].append({'parser': 'pdfminer.six', 'error_code': 'PARSER_FAILED'})
        failed['error'] = 'PDF parsing failed with available text parsers.'

    try:
        from pypdf import PdfReader
        with path.open('rb') as source:
            reader = PdfReader(source)
            page_count = len(reader.pages)
            if page_count > PDF_PARSE_MAX_PAGES:
                return _page_limit_result(page_count, 'pypdf')
            pages = []
            total_chars = 0
            for page_number, page in enumerate(reader.pages, 1):
                page_text = _clean_text(page.extract_text() or '')
                total_chars += len(page_text)
                if total_chars > PDF_PARSE_MAX_TEXT_CHARS:
                    return _text_limit_result(total_chars, page_count, 'pypdf')
                pages.append({'page': page_number, 'text': page_text, 'char_count': len(page_text)})
            parsed = _result('pypdf', pages, page_count)
        if parsed['success']:
            return parsed
        failed.update(parsed)
    except Exception:
        failed['parser_failures'].append({'parser': 'pypdf', 'error_code': 'PARSER_FAILED'})
        failed['error'] = 'PDF parsing failed with all available text parsers.'
    if enable_ocr:
        ocr_result = _ocr_pdf(path, failed.get('page_count', 0))
        if ocr_result['success']:
            return ocr_result
        failed.update(ocr_result)
    return failed


def _split_text(text: str, max_chars: int, overlap: int) -> List[str]:
    max_chars = max(200, max_chars)
    overlap = max(0, min(overlap, max_chars - 1))
    chunks = []
    start = 0
    while start < len(text):
        end = min(start + max_chars, len(text))
        chunks.append(text[start:end])
        if end == len(text):
            break
        start = end - overlap
    return chunks


def _score(query: str, text: str) -> float:
    query_words = set(re.findall(r'[\u4e00-\u9fff]+|\w+', query.lower()))
    text_words = set(re.findall(r'[\u4e00-\u9fff]+|\w+', text.lower()))
    common = len(query_words & text_words)
    if not common or not text_words:
        return 0.0
    return min(common / ((len(text_words) ** 0.5) + 1) * (1 + common / len(query_words) * 0.5), 1.0)



RISK_MODE_DETAILS: Dict[str, Dict[str, str]] = {
    'empty_page': {'severity': 'critical', 'label': 'empty page'},
    'ocr_unavailable': {'severity': 'critical', 'label': 'OCR unavailable'},
    'ocr_failed': {'severity': 'critical', 'label': 'OCR failed'},
    'resource_limited': {'severity': 'critical', 'label': 'resource limit exceeded'},
    'text_encoding_corruption': {'severity': 'critical', 'label': 'text encoding corruption'},
    'layout_uncertain': {'severity': 'warning', 'label': 'uncertain layout'},
    'formula_extraction_risk': {'severity': 'warning', 'label': 'formula extraction risk'},
    'table_structure_risk': {'severity': 'warning', 'label': 'table structure risk'},
    'figure_structure_risk': {'severity': 'warning', 'label': 'figure structure risk'},
    'cross_page_table_risk': {'severity': 'warning', 'label': 'cross-page table risk'},
}


def _coerce_confidence(value: Any, default: float = 1.0) -> float:
    try:
        confidence = float(value)
    except (TypeError, ValueError):
        return default
    return max(0.0, min(1.0, confidence))


def page_confidence(parse_quality: Dict[str, Any], page: Any) -> float:
    """Return the parser confidence for a physical page with robust key handling."""
    quality = parse_quality or {}
    page_map = quality.get('page_confidence') or {}
    if page is not None:
        for key in (page, str(page)):
            if key in page_map:
                return _coerce_confidence(page_map.get(key), _coerce_confidence(quality.get('overall_confidence'), 1.0))
    return _coerce_confidence(quality.get('overall_confidence'), 1.0)


def confidence_adjusted_score(score: float, confidence: Any) -> float:
    """Down-weight retrieval hits from pages with unreliable PDF extraction."""
    base = _coerce_confidence(confidence, 1.0)
    try:
        raw_score = float(score)
    except (TypeError, ValueError):
        raw_score = 0.0
    # Keep weak but relevant hits discoverable while still preferring reliable pages.
    return round(max(0.0, raw_score) * (0.35 + 0.65 * base), 4)


def build_risk_summary(parsed_or_metadata: Dict[str, Any]) -> Dict[str, Any]:
    """Build a compact risk summary suitable for UI badges and agent prompts."""
    source = parsed_or_metadata or {}
    quality = source.get('parse_quality') or {}
    modes = [str(mode) for mode in (quality.get('failure_modes') or [])]
    overall = _coerce_confidence(quality.get('overall_confidence'), 1.0 if not modes else 0.0)
    severities = [RISK_MODE_DETAILS.get(mode, {}).get('severity', 'warning') for mode in modes]
    extraction_status = source.get('extraction_status')
    if extraction_status in {'ocr_unavailable', 'ocr_failed', 'resource_limited'} and extraction_status not in modes:
        modes.append(str(extraction_status))
        severities.append('critical')
    if not source.get('success', True) and not modes:
        severities.append('critical')

    if 'critical' in severities or overall < 0.5:
        level = 'critical'
    elif modes or overall < 0.85:
        level = 'warning'
    else:
        level = 'ok'

    affected_pages = []
    page_map = quality.get('page_confidence') or {}
    for page, confidence in page_map.items():
        confidence_value = _coerce_confidence(confidence, 1.0)
        if confidence_value < 0.85:
            affected_pages.append({'page': int(page) if str(page).isdigit() else page, 'confidence': confidence_value})

    labels = [RISK_MODE_DETAILS.get(mode, {}).get('label', mode) for mode in modes]
    return {
        'level': level,
        'overall_confidence': overall,
        'failure_modes': sorted(set(modes)),
        'risk_labels': labels,
        'affected_pages': affected_pages,
        'requires_manual_review': level in {'warning', 'critical'},
        'message': (
            'PDF parsing failed or is too unreliable; verify against the original PDF.'
            if level == 'critical' else
            'PDF contains layout/formula/table/figure extraction risks; verify sensitive claims against the original page.'
            if level == 'warning' else
            'PDF text extraction looks reliable.'
        ),
    }


def search_pdf(path: Path, query: str, top_k: int = 5, chunk_size: int = 1500, overlap: int = 200) -> Dict[str, Any]:
    """Search page-contained chunks and return a citable location for each hit."""
    parsed = parse_pdf(path)
    if not parsed['success']:
        return {'success': False, 'snippets': [], 'parse': parsed}

    candidates = []
    quality = parsed.get('parse_quality') or {}
    risk_summary = build_risk_summary(parsed)
    for page in parsed['pages']:
        confidence = page_confidence(quality, page.get('page'))
        page_modes = []
        if page.get('layout') == 'layout_uncertain':
            page_modes.append('layout_uncertain')
        if page.get('cross_page_table_risk'):
            page_modes.append('cross_page_table_risk')
        if (page.get('visuals') or {}).get('figure_structure_risk'):
            page_modes.append('figure_structure_risk')
        page_blocks = [block for block in parsed.get('layout_blocks', []) if block.get('page') == page.get('page')]
        if any(block.get('type') == 'formula' for block in page_blocks):
            page_modes.append('formula_extraction_risk')
        if any(block.get('type') == 'table' for block in page_blocks):
            page_modes.append('table_structure_risk')
        for chunk_index, chunk in enumerate(_split_text(page['text'], chunk_size, overlap), 1):
            raw_score = round(_score(query, chunk), 4)
            candidates.append({
                'chunk': chunk,
                'page': page['page'],
                'chunk_index': chunk_index,
                'raw_score': raw_score,
                'score': confidence_adjusted_score(raw_score, confidence),
                'source_confidence': confidence,
                'parse_risk_level': risk_summary['level'],
                'page_failure_modes': sorted(set(page_modes)),
            })
    candidates.sort(key=lambda item: item['score'], reverse=True)
    filename = Path(path).name
    for candidate in candidates[:max(1, top_k)]:
        candidate['citation'] = f"{filename}, p. {candidate['page']}"
    return {'success': True, 'snippets': candidates[:max(1, top_k)], 'parse': parsed}
