# 部署交接：先从这里开始

这是2026-10-24新源码候选，不会覆盖旧部署包，不含密钥、用户数据、PDF、数据库、Windows venv或Embedding模型。解包后先核`RELEASE_MANIFEST.json`及包SHA。包内包含全部最新科研代码及醒目的模型402提示，但**不等于生产已验收**。

## 已知目标环境与阻塞

此前提供的服务器是Ubuntu 22.04/x86_64，账号srp没有sudo，系统Python3.10。当前依赖锁和普通用户启动器要求CPython3.11；先由部署方提供3.11及venv，不能直接拿3.10或复制Windows venv安装。当前尚未连接或更改该服务器。

请准备以下项目，不要在聊天或Git中发送真实值：

- CPython3.11 + venv/ensurepip，独立可写应用目录、持久空间和进程托管方式。
- MySQL8专用应用用户、已由授权迁移账户初始化的库，按现工具使用默认TCP3306。
- 单独托管且受保护的MCP、Qdrant服务及认证；不把内部服务直接暴露公网。
- multilingual-e5-small CPU模型（384维）的独立导出和文件哈希。小源码包不带模型/运行依赖；安装需网络或另备匹配锁SHA的wheel。
- 私有签名密钥与独立、稳定的凭据加密主密钥；数据库密码、内部服务Key仅保存在源码目录之外的0600配置。新用户在“我的API Keys”填写自己的模型/解析Key，全局共享模型Key保持空。
- 域名、HTTPS反代和有权限维护它的负责人；无sudo时由管理员处理，不自行更改系统防火墙。SSH隧道只能算私有预览。
- 对应实际版本的公开源码材料及下载地址；源码页配置需与运行指纹及实际材料SHA绑定。不要把尚未落实的AGPL确认项直接设为true。

## 安装与预检

详见`docs/USER_SERVER_DEPLOYMENT_20261023.md`，下面在新解包的source目录执行：

```bash
python3.11 -m venv .venv
.venv/bin/python -m pip install --require-hashes --no-deps -r deepdiver_v2/requirements.cloud.hashes.txt
.venv/bin/python -m pip install --require-hashes --no-deps --extra-index-url https://download.pytorch.org/whl/cpu -r deepdiver_v2/requirements.rag.cloud.hashes.txt
.venv/bin/python -m pip check
.venv/bin/python tools/rag_cloud.py verify-installed
# 先复制deploy/user-server.env.example到源码目录之外的私有server.env并配置/设权限0600。
.venv/bin/python tools/user_server.py check --env-file /absolute/private/server.env
.venv/bin/python tools/user_server.py serve --env-file /absolute/private/server.env
```

模板保留占位值，不能原样启动。check不会安装解释器、建库、迁移或替你生成许可确认。serve只在预检全部通过后前台启动单worker，不杀占用端口进程；后台托管和退出SSH后的持续运行需部署方安排。未安装Docker不影响选择上述普通用户路径，但不能省略MySQL/MCP/Qdrant。

## 上线前必须在目标环境验收

1. health/readyz/science.readyz正常且`code_on_disk_matches_startup=true`；公开HTTPS与反代长请求/轮询正常。
2. 新用户注册→填个人Key→本地PDF与公开问题各跑一次；原文引用/下载/追问/刷新恢复可用；不同用户A/B/匿名资源隔离正确。
3. 模拟模型HTTP402时在正文上方显示大号红色余额提示，设置按钮只打开本人Key窗口；401/429/网络故障不误报余额。模拟不收费，不要为测试故意反复提交欠费Key。
4. 排队、并发、真实取消、服务优雅重启后历史任务/owner/PDF/调用账本一致，不自动重跑收费任务。
5. 新目录新数据库恢复演练、Qdrant独立快照、旧版本回滚；不要覆盖生产库。私有加密主密钥必须可恢复。
6. 实际对应源码地址可从网站访问、下载包与运行版本/SHA匹配；本项目source.zip不自动包含AGPL依赖对应源码。

科研质量仍有未过项：最终Prompt v107的付费复测在首调用收到MODEL_HTTP_402，尚未验证最终提示词实效；中间版仍有读表占位、损失翻译与实验规则漏项。不能以门禁绿或打包成功宣称科研质量与生产上线全部通过。

不要将原开发目录、.env、账户Key库、聊天数据或私人PDF发给公开源码下载端。若迁移已有账户，走停写备份/独立恢复方案，不混进源码ZIP。
