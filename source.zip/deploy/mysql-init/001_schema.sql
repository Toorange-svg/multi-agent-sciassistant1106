-- Initial schema for a new Compose-managed SciAssistant MySQL volume.
-- This file deliberately uses IF NOT EXISTS and contains no test users or
-- passwords. It is run by the official MySQL image only when its data volume
-- is empty; never mount it onto an existing production database as migration.
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `auth_version` int unsigned NOT NULL DEFAULT 0,
  `avatar` varchar(255) NULL DEFAULT NULL,
  `createtime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `chat_list` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `session_id` varchar(50) NOT NULL,
  `title` varchar(100) NOT NULL,
  `create_time` datetime NULL DEFAULT NULL,
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_chat_list_user_id` (`user_id`),
  KEY `idx_chat_list_session_id` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `conversation_detail` (
  `id` int NOT NULL AUTO_INCREMENT,
  `session_id` varchar(50) NOT NULL,
  `from_who` varchar(4) NOT NULL,
  `round` int NULL DEFAULT 1,
  `timestamp` datetime NOT NULL,
  `uuid` varchar(100) NULL DEFAULT NULL,
  `content` mediumtext NOT NULL,
  `think_msg` mediumtext NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `has_report` tinyint(1) NULL DEFAULT NULL,
  `report_title` varchar(255) NULL DEFAULT '研究报告',
  PRIMARY KEY (`id`),
  KEY `idx_conversation_session_id` (`session_id`),
  KEY `idx_conversation_uuid` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `user_files` (
  `id` int NOT NULL AUTO_INCREMENT,
  `file_id` varchar(64) NOT NULL,
  `user_id` int NOT NULL,
  `original_filename` varchar(255) NOT NULL,
  `stored_filename` varchar(255) NOT NULL,
  `file_path` varchar(512) NOT NULL,
  `file_size` bigint NOT NULL,
  `file_type` varchar(10) NOT NULL,
  `status` enum('processing','processed','failed') NULL DEFAULT 'processing',
  `upload_time` datetime NOT NULL,
  `process_time` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `file_id` (`file_id`),
  KEY `idx_user_files_user_id` (`user_id`),
  KEY `idx_user_files_upload_time` (`upload_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `token_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime NULL DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token_hash` (`token_hash`),
  KEY `idx_password_reset_user_id` (`user_id`),
  KEY `idx_password_reset_expires_at` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
