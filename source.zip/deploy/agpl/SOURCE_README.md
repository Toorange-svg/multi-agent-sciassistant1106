# SciAssistant a3ce456 对应源码交付材料

适用部署：a3ce4561a3a6f053bbd9057083a7e4b66d6d31c7，Prompt v107。
运行指纹：229806223f8c3afec8b055f56c295b53ba780d22c0e33e2c4977b5eea997ad00。
不是当前开发HEAD，不含Git历史、私人.env、用户PDF、聊天数据库、API Key或模型权重。

## 包含内容

- sciassistant-a3ce456-source.zip：经清理的556项目源码文件；LICENSE/NOTICE、
  前端源码与构建材料、Dockerfiles、依赖版本/hash锁、数据库初始化结构和运行工具均在内。
- pymupdf-1.28.2.tar.gz：官方PyPI原始源码分发包，SHA由PyPI元数据复核。
- mupdf-1.28.2-source.tar.gz：与PyMuPDF setup.py及实际镜像运行报告一致的MuPDF原始源码包，
  SHA与Artifex官方GitHub release asset digest一致；包含thirdparty来源和原许可，不是只有wheel。
- PyMuPDF-COPYING、MuPDF-COPYING：上游原始许可全文。
- source-materials.json：版本、来源哈希、文件大小与逐文件SHA清单。
- OFFLINE_DEPLOYMENT.md：与本次实际离线镜像配套的构建后运行说明；无运行密码。

没有修改上述上游源码。PyMuPDF wheel使用上游构建，其完整构建环境/字节级复现未由本材料重新验证。
项目原Apache-2.0 LICENSE/NOTICE应保留，不是用Apache覆盖AGPL依赖或组合的许可义务。
部署者已选择AGPL路径；发布组合时还须按实际权利范围落实适用许可、源代码提供及声明，
本自动归档不构成法律合规结论，也不替部署者作确认。

## 阅读与构建

先解压项目source.zip；项目依赖安装/Docker构建参见包内Dockerfile.account.cloud、
Dockerfile.account.rag、两个account Compose及requirements.*.hashes.txt。
这是Python3.11/Linux amd64部署。重建项目先构建base-rag，再构建rag-release，
使用原a3ce456 revision和PYMUPDF_LICENSE_MODE=agpl，不从其他开发目录混入文件。

若需要从源码构建PyMuPDF，先在独立构建环境安装编译工具和上游pyproject.toml所列构建依赖，
解压两个原始源码包，按其README/setup.py说明使用本地MuPDF目录：

```bash
cd pymupdf-1.28.2
PYMUPDF_SETUP_MUPDF_BUILD=../mupdf-1.28.2-source python -m pip wheel .
```

此命令来自上游公开构建方式，不代表本轮已完成源码编译或字节级复现；
上游源码自带的thirdparty依赖、构建开关和许可不得擅自删除。
官方说明：https://pymupdf.readthedocs.io/en/latest/installation.html 。

本材料不声称包含整个Docker/MySQL/Qdrant/Python/所有wheel的对应源码全集，
公开分发这些镜像前须另核各自分发义务；不得把本包当成所有第三方组件合规证明。

## 发布要求

当前归档仅在本地，未发布，不能先填写AGPL交付确认true。
使用新的干净公开仓库Release或可由实际用户下载的HTTPS文件位置；
不要把旧Toorange-svg/sci1.0私密仓库直接公开，旧Git历史和操作脚本可能包含凭据。
只发布这份经核验材料包，不上传整个开发目录、镜像运行卷或私有备份。
发布后实际匿名下载文件并比对最终ZIP SHA，将真实URL、SHA与运行指纹绑定到网站源码页。
private仓库链接、登录错误页或上游首页不能冒充此版本源码下载。
