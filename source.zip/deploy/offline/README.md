# a3ce456 离线 Docker 启动补充包

放置在服务器同一新目录下：镜像 tar、SciAssistant_deploy_20261017/、本 offline/ 目录。
不要复制 backup 目录、开发仓库、已有私人配置。不是现有数据迁移，不运行 down -v。
Ubuntu 22.04 已有 Docker/Compose/sudo，不必额外安装宿主 Python3.11/MySQL/Qdrant。
工具自身仅用系统 Python3.10 标准库；应用在镜像内使用3.11。

## SSH 服务器步骤（在三个交付物同级目录）

```bash
python3 offline/server.py verify
sudo python3 offline/server.py load
python3 offline/server.py init --env-file "$HOME/.config/sciassistant/a3ce456.env"
```

init随机生成独立数据库密码、JWT、凭据主密钥、MCP/Qdrant认证，不输出秘密；已有文件拒绝覆盖。
妥善备份服务器此文件，丢失主密钥不能解密用户保存的Key。不要粘贴到聊天/截图/Git。

用编辑器在服务器打开私人env，填写实际MODEL_REQUEST_URL/MODEL_NAME（不是API Key）。
用户DeepSeek/Llama Key仍由本人注册后填写，全局模型/云解析Key保持空。
AGPL对应版本材料和公开HTTPS下载地址/SHA需核查后填写许可确认；默认false。
源码入口已实现，但本套件不伪造材料、不代填true，未完成许可仍被check/start拒绝。
Llama功能开关保留原默认关闭，本包不把未验云链路宣称可用。

```bash
sudo python3 offline/server.py check --env-file "$HOME/.config/sciassistant/a3ce456.env"
# check全部通过，并确认5000空闲/不影响其他人后才执行：
sudo python3 offline/server.py start --env-file "$HOME/.config/sciassistant/a3ce456.env"
sudo python3 offline/server.py status --env-file "$HOME/.config/sciassistant/a3ce456.env"
```

无需执行sudo docker compose build；配置无build、pull_policy=never，启动额外--no-build/--pull never。
仅127.0.0.1:5000发布，MySQL/MCP/Qdrant不对宿主或公网开口。命名卷新项目前缀隔离；
start会建新库/账户/卷并启停该项目容器，不修改其他项目。已有同名前缀环境不得当成新安装重跑。
不要执行完整compose config并外发，展开结果有密码。仅config --quiet用于校验。

本地Windows另外打开PowerShell（先连校园VPN）：
`ssh -N -L 127.0.0.1:15000:127.0.0.1:5000 srp@172.30.175.208`
浏览器访问 http://127.0.0.1:15000/login.html 。保持隧道窗口开启，不开放服务器防火墙。

以上启动步骤尚需服务器实测；镜像构建/本地向量编码不代表Linux网站闭环已通过。
后续验健康/指纹、注册个人Key、本地与公开任务、引用/账户隔离、取消/重启/恢复。
公网/HTTPS另行申请配置；当前是私有试运行。最终科研质量、云解析与AGPL材料交付仍待验。
