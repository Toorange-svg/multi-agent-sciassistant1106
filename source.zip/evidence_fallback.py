"""Stable, explicit fallback rules for evidence-poor research tasks."""

GENERAL_FALLBACK_FAILURE_CODES = frozenset({
    "INSUFFICIENT_EVIDENCE",
    "NO_AUDITED_CLAIMS",
    "MODEL_SCHEMA_REJECTED",
    "MODEL_JSON_INVALID",
    "RETRIEVAL_SOURCE_UNREACHABLE",
    "RETRIEVAL_SOURCE_RATE_LIMITED",
    "RETRIEVAL_SOURCE_DEADLINE",
    "LOCAL_PDF_PARSE_FAILED",
    "LOCAL_PDF_TEXT_EMPTY",
    "LOCAL_PDF_READ_FAILED",
})


def should_use_general_fallback(status, failure_code, published_claim_count, reference_count):
    """Return whether a failed/empty evidence path may use general knowledge."""
    if str(failure_code or "") in GENERAL_FALLBACK_FAILURE_CODES:
        return True
    if str(status or "") == "failed" and int(published_claim_count or 0) == 0 and int(reference_count or 0) == 0:
        return str(failure_code or "") not in {
            "MODEL_HTTP_401", "MODEL_HTTP_402", "MODEL_HTTP_403", "MODEL_HTTP_429",
            "USER_CANCELLED", "WEB_RAG_TIMEOUT", "TASK_CANCELLED",
        }
    return str(status or "") in {"partial", "needs_review"} and int(published_claim_count or 0) == 0


def wrap_general_fallback(answer, *, reason="证据不足"):
    """Clearly separate a general explanation from a source-backed conclusion."""
    body = str(answer or "").strip() or "当前无法生成通用解释，请稍后重试。"
    return (
        "## 降级回答：当前没有足够的可核验文献证据\n\n"
        f"本轮{reason}，下面内容基于模型通用知识生成，不代表上传 PDF、检索结果或已批准引用中的结论。"
        "如果需要论文级结论，请补充资料、缩小问题范围或稍后重新检索。\n\n"
        "### 通用解释\n\n" + body
    )
