"""Agent-independent document, evidence and hybrid retrieval services.

Agents only receive the returned ``EvidencePacket`` dictionaries.  They never
receive a database handle, Qdrant client, embedding model or filesystem path.
The optional vector dependencies are imported lazily so lexical retrieval
remains testable, while live vector mode fails explicitly when unavailable.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
import shutil
import sqlite3
import time
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Iterator, Mapping, Protocol, Sequence


CHUNK_SCHEMA = "sciassistant.evidence-chunk/v1"
PACKET_SCHEMA = "sciassistant.evidence-packet/v1"
DEFAULT_EMBEDDING_MODEL = "intfloat/multilingual-e5-small"
INDEX_EMBEDDING_BATCH_SIZE = 8
TABLE_CONTEXT_POLICY = "page-local-table-rows-no-inferred-column-semantics/v1"
_SAFE_ID = re.compile(r"[A-Za-z0-9_.-]{1,160}\Z")


class RagError(ValueError):
    """Stable RAG input or storage error."""


class RagDependencyError(RuntimeError):
    """An explicitly requested vector capability is not installed."""


class EmbeddingProvider(Protocol):
    model_name: str
    dimension: int

    def embed(self, texts: Sequence[str]) -> list[list[float]]: ...


class VectorStore(Protocol):
    def upsert(self, chunks: Sequence[Mapping[str, Any]], vectors: Sequence[Sequence[float]]) -> None: ...

    def search(self, vector: Sequence[float], *, limit: int) -> list[tuple[str, float]]: ...

    def delete_document(self, document_id: str) -> None: ...


class Reranker(Protocol):
    def rerank(self, query: str, chunks: Sequence[Mapping[str, Any]]) -> list[str]: ...


def _identifier(value: Any, label: str) -> str:
    text = str(value or "")
    if not _SAFE_ID.fullmatch(text):
        raise RagError(f"invalid {label}")
    return text


def _clean_text(value: Any, limit: int = 20_000) -> str:
    text = " ".join(str(value or "").split()).strip()
    return text[:limit]


def _content_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _token_estimate(text: str) -> int:
    latin_words = sum(max(1, math.ceil(len(word) / 6)) for word in re.findall(r"[A-Za-z0-9_]+", text))
    cjk = len(re.findall(r"[\u4e00-\u9fff]", text))
    punctuation = len(re.findall(r"[^\w\s]", text, flags=re.UNICODE))
    return max(1, latin_words + math.ceil(cjk / 1.5) + math.ceil(punctuation / 4))


def _split_text(text: str, target: int, overlap: int) -> list[str]:
    if _token_estimate(text) <= target:
        return [text]
    pieces = []
    start = 0
    while start < len(text):
        low, high = start + 1, len(text)
        while low < high:
            middle = (low + high + 1) // 2
            if _token_estimate(text[start:middle]) <= target:
                low = middle
            else:
                high = middle - 1
        end = low
        boundary = text.rfind(" ", start, end)
        if boundary > start + (end - start) * 0.7:
            end = boundary
        pieces.append(text[start:end].strip())
        if end >= len(text):
            break
        overlap_start = end
        while overlap_start > start and _token_estimate(text[overlap_start - 1:end]) <= overlap:
            overlap_start -= 1
        start = max(start + 1, overlap_start)
    return [piece for piece in pieces if piece]


def build_chunks(
    document_id: str,
    paper_id: str,
    title: str,
    blocks: Sequence[Mapping[str, Any]],
    *,
    target_tokens: int = 1_000,
    overlap_tokens: int = 150,
) -> list[dict[str, Any]]:
    """Merge page-aware parser blocks into locatable, bounded chunks."""
    document_id = _identifier(document_id, "document id")
    paper_id = _identifier(paper_id, "paper id")
    if not 20 <= int(target_tokens) <= 2_000 or not 0 <= int(overlap_tokens) < int(target_tokens):
        raise RagError("invalid chunk budget")
    normalized: list[dict[str, Any]] = []
    for raw in blocks:
        if not isinstance(raw, Mapping):
            continue
        text = " ".join(str(raw.get("text") or "").split()).strip()
        if not text:
            continue
        bbox = raw.get("bbox")
        if not isinstance(bbox, (list, tuple)) or len(bbox) != 4:
            bbox = None
        item = {
            "page": int(raw.get("page") or 0) or None,
            "section": _clean_text(raw.get("section"), 500) or None,
            "paragraph": _clean_text(raw.get("paragraph"), 160) or None,
            "table_id": _clean_text(raw.get("table_id"), 128) or None,
            "figure_id": _clean_text(raw.get("figure_id"), 128) or None,
            "bbox": [round(float(item), 2) for item in bbox] if bbox else None,
            "block_type": _clean_text(raw.get("block_type") or raw.get("type") or raw.get("source_type"), 64) or "text",
            "source_parser": "llamaparse" if raw.get("source_parser") == "llamaparse" else "local",
        }
        lines = raw.get('line_spans')
        usable_lines = (isinstance(lines, list) and bool(lines) and all(isinstance(line, Mapping)
            and isinstance(line.get('bbox'), (list, tuple)) and len(line['bbox']) == 4
            and all(isinstance(v, (int, float)) and math.isfinite(v) for v in line['bbox']) for line in lines))
        # Incomplete/unrepaired geometry must not replace complete parser text.
        # Fall back to that text rather than dropping cells or raising a crash.
        if (item['table_id'] and usable_lines
                and ' '.join(' '.join(str(line.get('text') or '').split()) for line in lines) == text):
            # Same-baseline PDF lines are kept left-to-right as one row. Pipes
            # delimit observed cells, not inferred multi-level header mappings.
            from pdf_pipeline import _rows_from_lines
            rows = _rows_from_lines(lines)
            text = '\n'.join(' | '.join(str(line.get('text') or '').strip()
                for line in sorted(row, key=lambda line: line['bbox'][0])) for row in rows).strip()
            item['row_layout_preserved'] = True
        table_match = re.match(r"(?i)^table\s+(\d+)", text)
        figure_match = re.match(r"(?i)^(?:figure|fig\.)\s*(\d+)", text)
        if table_match and not item["table_id"]:
            item["table_id"] = "Table-" + table_match.group(1)
        if figure_match and not item["figure_id"]:
            item["figure_id"] = "Figure-" + figure_match.group(1)
        for part in _split_text(text, target_tokens, overlap_tokens):
            normalized.append({**item, "text": part})
    chunks: list[dict[str, Any]] = []
    cursor = 0
    while cursor < len(normalized):
        selected: list[dict[str, Any]] = []
        tokens = 0
        index = cursor
        first_section = normalized[cursor].get("section")
        hard_boundary = False
        while index < len(normalized):
            candidate = normalized[index]
            candidate_tokens = _token_estimate(candidate["text"])
            section_changed = bool(selected and first_section and candidate.get("section") not in {None, first_section})
            page_changed = bool(selected and candidate.get("page") != selected[-1].get("page"))
            special = lambda block: (block.get("table_id"), block.get("figure_id"), "formula" in block.get("block_type", ""))
            boundary_changed = bool(selected and (special(candidate) != special(selected[-1])
                or candidate["source_parser"] != selected[-1]["source_parser"]))
            if selected and (tokens + candidate_tokens > target_tokens or section_changed or page_changed or boundary_changed):
                hard_boundary = section_changed or page_changed or boundary_changed
                break
            selected.append(candidate)
            tokens += candidate_tokens
            index += 1
        if not selected:
            selected = [normalized[cursor]]
            index = cursor + 1
        text = "\n\n".join(item["text"] for item in selected)
        pages = [item["page"] for item in selected if item["page"]]
        bboxes = [item["bbox"] for item in selected if item["bbox"]]
        ordinal = len(chunks) + 1
        chunk_id = f"{document_id}-c{ordinal:05d}"
        chunk_bbox = None
        if bboxes and len(set(pages)) <= 1:
            chunk_bbox = [
                min(box[0] for box in bboxes), min(box[1] for box in bboxes),
                max(box[2] for box in bboxes), max(box[3] for box in bboxes),
            ]
        chunks.append({
            "schema_version": CHUNK_SCHEMA,
            "document_id": document_id,
            "paper_id": paper_id,
            "chunk_id": chunk_id,
            "title": _clean_text(title, 1_000),
            "text": text,
            "page": pages[0] if pages else None,
            "page_end": pages[-1] if pages else None,
            "section": selected[0].get("section"),
            "paragraph": selected[0].get("paragraph"),
            "table_id": next((item["table_id"] for item in selected if item["table_id"]), None),
            "figure_id": next((item["figure_id"] for item in selected if item["figure_id"]), None),
            "bbox": chunk_bbox,
            "anchor_text": text[:240],
            "content_hash": _content_hash(text),
            "parent_chunk_id": None,
            "previous_chunk_id": f"{document_id}-c{ordinal - 1:05d}" if ordinal > 1 else None,
            "next_chunk_id": None,
            "token_estimate": _token_estimate(text),
            "block_types": list(dict.fromkeys(item["block_type"] for item in selected))[:8],
            **({"parser_provenance": {"parser": "llamaparse", "locator": "page_only",
                 "original_review_required": True}} if selected[0]["source_parser"] == "llamaparse" else {}),
            **({"table_context": {"policy": TABLE_CONTEXT_POLICY, "column_semantics_verified": False,
                 "row_layout_preserved": all(item.get('row_layout_preserved', False) for item in selected),
                 "coverage_scope": "selected_page_region"}}
               if any(item.get('table_id') for item in selected) else {}),
        })
        if chunks[:-1]:
            chunks[-2]["next_chunk_id"] = chunk_id
        if index >= len(normalized):
            break
        # Never drag the trailing blocks across a page/section/table boundary.
        # Doing so repeatedly emitted progressively shorter tails of the same
        # page (447 chunks for the 16-page vLLM paper), wasting CPU and recall.
        if hard_boundary:
            cursor = index
            continue
        # Reuse only complete trailing blocks and always advance at least one.
        overlap = 0
        next_cursor = index
        for previous in reversed(selected):
            estimate = _token_estimate(previous["text"])
            if overlap + estimate > overlap_tokens:
                break
            overlap += estimate
            next_cursor -= 1
        cursor = next_cursor if next_cursor > cursor else index
    return chunks


class DocumentStore:
    """Filesystem document boundary; only sanitized identifiers become paths."""

    def __init__(self, root: str | Path):
        self.root = Path(root)

    def put(self, document_id: str, metadata: Mapping[str, Any], *, pdf_bytes: bytes | None = None) -> Path:
        document_id = _identifier(document_id, "document id")
        folder = self.root / document_id
        if folder.is_symlink() or folder.resolve().parent != self.root.resolve():
            raise RagError("unsafe document target")
        if pdf_bytes is not None and (not pdf_bytes.startswith(b"%PDF-") or len(pdf_bytes) > 30 * 1024 * 1024):
            raise RagError("document is not a PDF or exceeds size limit")
        if (folder / "metadata.json").is_symlink() or (folder / "source.pdf").is_symlink():
            raise RagError("unsafe document file")
        folder.mkdir(parents=True, exist_ok=True)
        safe_metadata = {
            "schema_version": "sciassistant.document/v1",
            "document_id": document_id,
            "paper_id": _identifier(metadata.get("paper_id"), "paper id"),
            "title": _clean_text(metadata.get("title"), 1_000),
            "official_url": _clean_text(metadata.get("official_url"), 2_000),
            "content_hash": _clean_text(metadata.get("content_hash"), 128),
        }
        from multi_agent_evidence import source_identity_record
        identity = source_identity_record(metadata)
        safe_metadata.update(authors=identity['authors'], author_metadata_source=identity['author_metadata_source'])
        (folder / "metadata.json").write_text(
            json.dumps(safe_metadata, ensure_ascii=False, indent=2), encoding="utf-8",
        )
        if pdf_bytes is not None:
            (folder / "source.pdf").write_bytes(pdf_bytes)
        return folder

    def pdf_path(self, document_id: str) -> Path | None:
        path = self.root / _identifier(document_id, "document id") / "source.pdf"
        return path if path.is_file() else None

    def delete_document(self, document_id: str) -> None:
        document_id = _identifier(document_id, "document id")
        folder = self.root / document_id
        if folder.is_symlink() or folder.resolve().parent != self.root.resolve():
            raise RagError("unsafe document deletion target")
        if folder.is_dir():
            shutil.rmtree(folder)


class EvidenceStore:
    """SQLite metadata/FTS store independent from workflow and Agent state."""

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connection() as connection:
            connection.executescript("""
                CREATE TABLE IF NOT EXISTS evidence_document (
                    document_id TEXT PRIMARY KEY, paper_id TEXT NOT NULL, title TEXT NOT NULL,
                    official_url TEXT NOT NULL, content_hash TEXT NOT NULL, indexed_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS evidence_chunk (
                    chunk_id TEXT PRIMARY KEY, document_id TEXT NOT NULL, paper_id TEXT NOT NULL,
                    title TEXT NOT NULL, text TEXT NOT NULL, page INTEGER, page_end INTEGER,
                    section TEXT, paragraph TEXT, table_id TEXT, figure_id TEXT, bbox_json TEXT,
                    anchor_text TEXT NOT NULL, content_hash TEXT NOT NULL, parent_chunk_id TEXT,
                    previous_chunk_id TEXT, next_chunk_id TEXT, token_estimate INTEGER NOT NULL,
                    payload_json TEXT NOT NULL,
                    FOREIGN KEY(document_id) REFERENCES evidence_document(document_id) ON DELETE CASCADE
                );
                CREATE VIRTUAL TABLE IF NOT EXISTS evidence_chunk_fts USING fts5(
                    chunk_id UNINDEXED, title, section, text, tokenize='unicode61'
                );
            """)

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.path)
        try:
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA foreign_keys=ON")
            connection.execute("PRAGMA journal_mode=WAL")
            with connection:
                yield connection
        finally:
            connection.close()

    def index_document(self, metadata: Mapping[str, Any], chunks: Sequence[Mapping[str, Any]]) -> bool:
        document_id = _identifier(metadata.get("document_id"), "document id")
        content_hash = _clean_text(metadata.get("content_hash"), 128)
        with self._connection() as connection:
            existing = connection.execute(
                "SELECT content_hash FROM evidence_document WHERE document_id=?", (document_id,),
            ).fetchone()
            if existing and existing["content_hash"] == content_hash:
                return False
            old_ids = [row[0] for row in connection.execute(
                "SELECT chunk_id FROM evidence_chunk WHERE document_id=?", (document_id,),
            )]
            for chunk_id in old_ids:
                connection.execute("DELETE FROM evidence_chunk_fts WHERE chunk_id=?", (chunk_id,))
            connection.execute("DELETE FROM evidence_chunk WHERE document_id=?", (document_id,))
            connection.execute("DELETE FROM evidence_document WHERE document_id=?", (document_id,))
            connection.execute(
                "INSERT INTO evidence_document VALUES (?, ?, ?, ?, ?, datetime('now'))",
                (document_id, _identifier(metadata.get("paper_id"), "paper id"),
                 _clean_text(metadata.get("title"), 1_000), _clean_text(metadata.get("official_url"), 2_000),
                 content_hash),
            )
            for raw in chunks:
                chunk = dict(raw)
                if chunk.get("schema_version") != CHUNK_SCHEMA or chunk.get("document_id") != document_id:
                    raise RagError("invalid evidence chunk")
                payload = json.dumps(chunk, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
                connection.execute(
                    "INSERT INTO evidence_chunk VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (chunk["chunk_id"], document_id, chunk["paper_id"], chunk["title"], chunk["text"],
                     chunk["page"], chunk["page_end"], chunk["section"], chunk["paragraph"], chunk["table_id"],
                     chunk["figure_id"], json.dumps(chunk["bbox"]), chunk["anchor_text"], chunk["content_hash"],
                     chunk["parent_chunk_id"], chunk["previous_chunk_id"], chunk["next_chunk_id"],
                     chunk["token_estimate"], payload),
                )
                connection.execute(
                    "INSERT INTO evidence_chunk_fts(chunk_id, title, section, text) VALUES (?, ?, ?, ?)",
                    (chunk["chunk_id"], chunk["title"], chunk["section"] or "", chunk["text"]),
                )
            connection.commit()
        return True

    def get_chunks(self, chunk_ids: Iterable[str]) -> list[dict[str, Any]]:
        ids = [_identifier(value, "chunk id") for value in chunk_ids]
        if not ids:
            return []
        placeholders = ",".join("?" for _ in ids)
        with self._connection() as connection:
            rows = connection.execute(
                f"SELECT chunk_id, payload_json FROM evidence_chunk WHERE chunk_id IN ({placeholders})", ids,
            ).fetchall()
        values = {row["chunk_id"]: json.loads(row["payload_json"]) for row in rows}
        return [values[chunk_id] for chunk_id in ids if chunk_id in values]

    def lexical_search(self, query: str, *, limit: int = 40, document_ids: set[str] | None = None) -> list[tuple[str, float]]:
        terms = re.findall(r"[A-Za-z0-9_]{2,}|[\u4e00-\u9fff]{2,}", str(query or ""))[:20]
        if not terms:
            return []
        expression = " OR ".join('"' + term.replace('"', '') + '"' for term in terms)
        scope_sql = ""
        parameters: list[Any] = [expression]
        if document_ids is not None:
            if not document_ids:
                return []
            scoped = sorted(_identifier(item, "document id") for item in document_ids)
            scope_sql = " AND chunk_id IN (SELECT chunk_id FROM evidence_chunk WHERE document_id IN (" + ",".join("?" for _ in scoped) + "))"
            parameters.extend(scoped)
        parameters.append(max(1, min(int(limit), 100)))
        with self._connection() as connection:
            rows = connection.execute(
                "SELECT chunk_id, bm25(evidence_chunk_fts) AS score FROM evidence_chunk_fts "
                "WHERE evidence_chunk_fts MATCH ?" + scope_sql + " ORDER BY score LIMIT ?", parameters,
            ).fetchall()
        # FTS5 bm25 is lower-is-better. Convert to a positive monotonic score.
        return [(row["chunk_id"], -float(row["score"])) for row in rows]

    def delete_document(self, document_id: str) -> list[str]:
        document_id = _identifier(document_id, "document id")
        with self._connection() as connection:
            ids = [row[0] for row in connection.execute(
                "SELECT chunk_id FROM evidence_chunk WHERE document_id=?", (document_id,),
            )]
            for chunk_id in ids:
                connection.execute("DELETE FROM evidence_chunk_fts WHERE chunk_id=?", (chunk_id,))
            connection.execute("DELETE FROM evidence_document WHERE document_id=?", (document_id,))
            connection.commit()
        return ids

    def document_hash(self, document_id: str) -> str | None:
        with self._connection() as connection:
            row = connection.execute("SELECT content_hash FROM evidence_document WHERE document_id=?",
                                     (_identifier(document_id, "document id"),)).fetchone()
        return str(row[0]) if row else None


class LocalSentenceTransformerEmbedding:
    """CPU-oriented local embedding provider loaded only when vector mode is used."""

    def __init__(self, model_name: str = DEFAULT_EMBEDDING_MODEL):
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as exc:
            raise RagDependencyError("sentence-transformers is required for local vector retrieval") from exc
        self.model_name = str(model_name)
        self.revision = str(os.getenv("SCIASSISTANT_EMBEDDING_REVISION") or "")
        self._model = SentenceTransformer(self.model_name, device="cpu",
                                          revision=self.revision or None,
                                          local_files_only=os.getenv("SCIASSISTANT_EMBEDDING_ALLOW_DOWNLOAD") != "1")
        dimension = self._model.get_sentence_embedding_dimension()
        self.dimension = int(dimension or 0)
        if self.dimension <= 0:
            raise RagDependencyError("embedding model did not expose a valid dimension")

    def embed(self, texts: Sequence[str]) -> list[list[float]]:
        # e5-small accepts fewer tokens than a 1000-token evidence chunk. Encode
        # bounded subwindows and pool them, so the tail is not silently ignored.
        windows, groups = [], []
        window_size = max(32, int(self._model.max_seq_length) - 16)
        for text in texts:
            ids = self._model.tokenizer.encode(text, add_special_tokens=False)
            indices = []
            for start in range(0, max(1, len(ids)), max(1, window_size - 64)):
                part = self._model.tokenizer.decode(ids[start:start + window_size])
                indices.append(len(windows))
                windows.append(("passage: " + part) if "e5" in self.model_name.lower() else part)
                if start + window_size >= len(ids):
                    break
            groups.append(indices)
        if not windows:
            return []
        vectors = self._model.encode(windows, normalize_embeddings=True, show_progress_bar=False, batch_size=16)
        result = []
        for indices in groups:
            mean = [sum(float(vectors[i][j]) for i in indices) / len(indices) for j in range(self.dimension)]
            norm = math.sqrt(sum(value * value for value in mean)) or 1.0
            result.append([value / norm for value in mean])
        return result

    def embed_query(self, query: str) -> list[float]:
        prefixed = "query: " + query if "e5" in self.model_name.lower() else query
        return [float(value) for value in self._model.encode([prefixed], normalize_embeddings=True, show_progress_bar=False)[0]]


class QdrantVectorStore:
    """Qdrant local-path or server adapter with one stable application API."""

    def __init__(self, *, dimension: int, path: str | Path | None = None, url: str | None = None,
                 collection: str = "sciassistant_evidence", api_key: str | None = None):
        try:
            from qdrant_client import QdrantClient
            from qdrant_client.http import models
        except ImportError as exc:
            raise RagDependencyError("qdrant-client is required for vector retrieval") from exc
        if bool(path) == bool(url):
            raise RagError("configure exactly one Qdrant path or URL")
        self._models = models
        self.collection = _identifier(collection, "Qdrant collection")
        self._client = QdrantClient(url=url, api_key=api_key, timeout=5) if url else QdrantClient(path=str(path))
        try:
            if not self._client.collection_exists(self.collection):
                try:
                    self._client.create_collection(
                        collection_name=self.collection,
                        vectors_config=models.VectorParams(size=int(dimension), distance=models.Distance.COSINE),
                    )
                except Exception:
                    # Another server client may have created it between checks.
                    # Only accept the race when the actual collection validates.
                    if not self._client.collection_exists(self.collection):
                        raise
            info = self._client.get_collection(self.collection)
            vectors = info.config.params.vectors
            if getattr(vectors, "size", None) != int(dimension):
                raise RagError("Qdrant collection embedding dimension mismatch")
        except BaseException:
            try:
                self._client.close()
            except Exception:
                pass
            raise

    def document_chunk_count(self, document_id: str) -> int:
        document_id = _identifier(document_id, "document id")
        query_filter = self._models.Filter(must=[self._models.FieldCondition(
            key="document_id", match=self._models.MatchValue(value=document_id))])
        return int(self._client.count(collection_name=self.collection, count_filter=query_filter, exact=True).count)

    def upsert(self, chunks: Sequence[Mapping[str, Any]], vectors: Sequence[Sequence[float]]) -> None:
        if len(chunks) != len(vectors):
            raise RagError("chunk/vector count mismatch")
        points = []
        for chunk, vector in zip(chunks, vectors):
            point_id = hashlib.sha256(str(chunk["chunk_id"]).encode("utf-8")).hexdigest()[:32]
            points.append(self._models.PointStruct(
                id=point_id, vector=list(vector),
                payload={"chunk_id": chunk["chunk_id"], "document_id": chunk["document_id"],
                         "content_hash": chunk["content_hash"]},
            ))
        if points:
            self._client.upsert(collection_name=self.collection, points=points, wait=True)

    def search(self, vector: Sequence[float], *, limit: int, document_ids: set[str] | None = None) -> list[tuple[str, float]]:
        query_filter = None
        if document_ids is not None:
            if not document_ids:
                return []
            query_filter = self._models.Filter(must=[self._models.FieldCondition(
                key="document_id", match=self._models.MatchAny(any=sorted(document_ids)))])
        if hasattr(self._client, "query_points"):
            response = self._client.query_points(
                collection_name=self.collection, query=list(vector), limit=int(limit), with_payload=True, query_filter=query_filter,
            )
            points = response.points
        else:
            points = self._client.search(
                collection_name=self.collection, query_vector=list(vector), limit=int(limit), with_payload=True, query_filter=query_filter,
            )
        return [(str(point.payload.get("chunk_id")), float(point.score)) for point in points if point.payload]

    def delete_document(self, document_id: str) -> None:
        self._client.delete(
            collection_name=self.collection,
            points_selector=self._models.FilterSelector(filter=self._models.Filter(must=[
                self._models.FieldCondition(
                    key="document_id", match=self._models.MatchValue(value=_identifier(document_id, "document id")),
                ),
            ])), wait=True,
        )

    def close(self):
        self._client.close()


@dataclass
class LexicalReranker:
    """Small CPU reranker; RRF still supplies semantic recall and tie order."""

    def rerank(self, query: str, chunks: Sequence[Mapping[str, Any]]) -> list[str]:
        terms = set(re.findall(r"[A-Za-z0-9_]{2,}|[\u4e00-\u9fff]{2,}", query.lower()))
        order = {chunk["chunk_id"]: index for index, chunk in enumerate(chunks)}
        def score(chunk):
            words = set(re.findall(r"[A-Za-z0-9_]{2,}|[\u4e00-\u9fff]{2,}", str(chunk["text"]).lower()))
            return len(terms & words) / max(1, len(terms))
        return [chunk["chunk_id"] for chunk in sorted(chunks, key=lambda chunk: (-score(chunk), order[chunk["chunk_id"]]))]


@dataclass
class HybridRetriever:
    evidence_store: EvidenceStore
    embedding: EmbeddingProvider | None = None
    vector_store: VectorStore | None = None
    vector_required: bool = False
    reranker: Reranker | None = None

    @staticmethod
    def _rrf(rankings: Sequence[Sequence[tuple[str, float]]], constant: int = 60) -> dict[str, float]:
        combined: dict[str, float] = {}
        for ranking in rankings:
            for rank, (chunk_id, _score) in enumerate(ranking, 1):
                combined[chunk_id] = combined.get(chunk_id, 0.0) + 1.0 / (constant + rank)
        return combined

    def search(self, query: str, *, limit: int = 12, per_document: int = 5,
               document_ids: set[str] | None = None, context_budget: int = 12_000,
               representative_document_ids: Sequence[str] = (),
               passage_queries: Sequence[str] = (),
               priority_passage_queries: Sequence[str] = (),
               mechanism_passage_queries: Sequence[str] = (),
               result_passage_queries: Sequence[str] = (),
               evidence_needs: Sequence[Mapping] = (),
               deadline_monotonic: float | None = None) -> list[dict[str, Any]]:
        # Local planned facets recover objective/mechanism passages drowned out
        # by a broad architecture query. They never create public tool actions.
        if isinstance(passage_queries, (str, bytes)) or not isinstance(passage_queries, (list, tuple)):
            raise RagError("invalid passage queries")
        if len(passage_queries) > 3 or any(not isinstance(value, str) or not value.strip()
                or len(value) > 500 or re.search(r'[\x00-\x1f\x7f]', value) for value in passage_queries):
            raise RagError("invalid passage queries")
        facets = list(dict.fromkeys(value.strip() for value in passage_queries if value.strip() != query.strip()))
        if (not isinstance(priority_passage_queries, (list, tuple)) or len(priority_passage_queries) > 1
                or any(not isinstance(value, str) or value not in passage_queries for value in priority_passage_queries)):
            raise RagError("invalid priority passage query")
        if (not isinstance(mechanism_passage_queries, (list, tuple)) or len(mechanism_passage_queries) > 3
                or any(not isinstance(value, str) or value not in passage_queries for value in mechanism_passage_queries)):
            raise RagError("invalid mechanism passage query")
        if (not isinstance(result_passage_queries, (list, tuple)) or len(result_passage_queries) > 3
                or any(not isinstance(value, str) or value not in passage_queries for value in result_passage_queries)):
            raise RagError("invalid result passage query")
        if (not isinstance(evidence_needs, (list, tuple)) or len(evidence_needs) > 4
                or any(not isinstance(n, Mapping) or set(n) != {
                    'need_id', 'entity', 'aspect', 'query', 'document_ids', 'source_binding'}
                    or not isinstance(n['need_id'], str) or not re.fullmatch(r'[A-Za-z0-9_.:-]{1,100}', n['need_id'])
                    or not isinstance(n['entity'], str) or not 1 <= len(n['entity']) <= 100
                    or not isinstance(n['aspect'], str) or n['aspect'] not in {'definition', 'mechanism', 'result', 'protocol'}
                    or not isinstance(n['query'], str) or not 1 <= len(n['query']) <= 500
                    or re.search(r'[\x00-\x1f\x7f]', n['query'])
                    or not isinstance(n['source_binding'], str) or n['source_binding'] not in {'exact_title', 'uploaded_scope', 'current_scope'}
                    or not isinstance(n['document_ids'], list) or not 1 <= len(n['document_ids']) <= 100
                    or any(not isinstance(key, str) or document_ids is None or key not in document_ids
                           for key in n['document_ids']) for n in evidence_needs)
                or len({n['need_id'] for n in evidence_needs}) != len(evidence_needs)):
            raise RagError('invalid scoped evidence needs')
        lexical = self.evidence_store.lexical_search(query, limit=40, document_ids=document_ids)
        # Keep two high core/support-ranked documents visible to the Reviewer.
        # A globally crowded chunk ranking must not silently erase their matches.
        # This is bounded lexical recall, not automatic evidence approval.
        representatives = list(dict.fromkeys(representative_document_ids))[:2]
        representatives = [key for key in representatives if document_ids is not None and key in document_ids]
        recalled = {key for key, _ in lexical}
        for document_id in representatives:
            for key, score in self.evidence_store.lexical_search(query, limit=4, document_ids={document_id}):
                if key not in recalled:
                    lexical.append((key, score))
                    recalled.add(key)
        vector: list[tuple[str, float]] = []
        if self.embedding is not None and self.vector_store is not None:
            query_vector = self.embedding.embed_query(query) if hasattr(self.embedding, "embed_query") else self.embedding.embed([query])[0]
            if document_ids is None:
                vector = self.vector_store.search(query_vector, limit=40)
            else:
                vector = self.vector_store.search(query_vector, limit=40, document_ids=document_ids)
        elif self.vector_required:
            raise RagDependencyError("vector retrieval was required but is not configured")
        rankings = [lexical, vector] if vector else [lexical]
        facet_rankings = []
        planned_facets = list(facets)
        for facet in facets:
            if deadline_monotonic is not None and time.monotonic() >= deadline_monotonic:
                break
            facet_lexical = self.evidence_store.lexical_search(facet, limit=20, document_ids=document_ids)
            recalled_ids = {key for key, _ in facet_lexical}
            for document_id in representatives:
                for key, score in self.evidence_store.lexical_search(facet, limit=4, document_ids={document_id}):
                    if key not in recalled_ids:
                        facet_lexical.append((key, score))
                        recalled_ids.add(key)
            facet_vector = []
            if self.embedding is not None and self.vector_store is not None:
                encoded = self.embedding.embed_query(facet) if hasattr(self.embedding, "embed_query") else self.embedding.embed([facet])[0]
                facet_vector = self.vector_store.search(encoded, limit=20, document_ids=document_ids) if document_ids is not None else self.vector_store.search(encoded, limit=20)
            facet_scores = self._rrf([facet_lexical, facet_vector] if facet_vector else [facet_lexical])
            facet_rankings.append(facet_scores)
            rankings.extend([facet_lexical, facet_vector] if facet_vector else [facet_lexical])
        facets = facets[:len(facet_rankings)]
        need_rankings = {}
        encoded_needs = {}
        for need in evidence_needs:
            if deadline_monotonic is not None and time.monotonic() >= deadline_monotonic:
                break
            scope = set(need['document_ids'])
            recall_limit = 40 if need['source_binding'] == 'exact_title' else 12
            local = self.evidence_store.lexical_search(need['query'], limit=recall_limit, document_ids=scope)
            semantic = []
            if self.embedding is not None and self.vector_store is not None:
                if need['query'] not in encoded_needs:
                    encoded_needs[need['query']] = (self.embedding.embed_query(need['query'])
                        if hasattr(self.embedding, 'embed_query') else self.embedding.embed([need['query']])[0])
                semantic = self.vector_store.search(encoded_needs[need['query']], limit=12, document_ids=scope)
            # A backend's result must still be checked against the allowed scope
            # after get_chunks. A vector hit never establishes semantic support.
            need_rankings[need['need_id']] = self._rrf([local, semantic] if semantic else [local])
            rankings.extend([local, semantic] if semantic else [local])
        scores = self._rrf(rankings)
        ordered_ids = [item[0] for item in sorted(scores.items(), key=lambda item: (-item[1], item[0]))]
        chunks = self.evidence_store.get_chunks(ordered_ids)
        if document_ids is not None:
            chunks = [chunk for chunk in chunks if chunk["document_id"] in document_ids]
        # A prose block ending 'yields:' is NOT the following equation. Recall
        # the adjacent equation as its own source, never silently splice text
        # under another ID/page/bbox. Selection below treats the pair atomically
        # within ALL existing quotas; neither fragment becomes approved here.
        continuation_policy = "adjacent-introducer-formula-separate-evidence-within-quota/v1"
        def introduces_formula(chunk):
            return (not any(chunk.get(key) for key in ("table_id", "figure_id"))
                    and "formula" not in chunk.get("block_types", [])
                    and bool(re.search(r"(?:\byields?|\bgives?|\bas follows|\bgiven by|\bexpressed as|\bdefined as|如下|写为|表示为|得到)\s*[:：]\s*$", chunk["text"], re.I)))
        neighbor_ids = list(dict.fromkeys(key for chunk in chunks for key in (
            [chunk.get("next_chunk_id")] if introduces_formula(chunk) else
            [chunk.get("previous_chunk_id")] if "formula" in chunk.get("block_types", []) else []) if key))
        by_chunk = {chunk["chunk_id"]: chunk for chunk in chunks}
        neighbors = {chunk["chunk_id"]: chunk for chunk in self.evidence_store.get_chunks(neighbor_ids)} if neighbor_ids else {}
        continuation_pairs = {}
        for chunk in list(chunks):
            before, after = ((chunk, neighbors.get(chunk.get("next_chunk_id"))) if introduces_formula(chunk)
                             else (neighbors.get(chunk.get("previous_chunk_id")), chunk))
            if not before or not after or not introduces_formula(before) or "formula" not in after.get("block_types", []):
                continue
            if (before["document_id"] != after["document_id"] or before["paper_id"] != after["paper_id"]
                    or document_ids is not None and after["document_id"] not in document_ids
                    or before.get("next_chunk_id") != after["chunk_id"]
                    or after.get("previous_chunk_id") != before["chunk_id"]
                    or not isinstance(before.get("page_end"), int) or not isinstance(after.get("page"), int)
                    or after["page"] - before["page_end"] not in (0, 1)
                    or before.get("section") and after.get("section") and before["section"] != after["section"]
                    or after.get("token_estimate", 0) > 600):
                continue
            pair = [before["chunk_id"], after["chunk_id"]]
            for member in (before, after):
                continuation_pairs[member["chunk_id"]] = pair
                if member["chunk_id"] not in by_chunk:
                    chunks.append(member)
                    by_chunk[member["chunk_id"]] = member
        if self.reranker is not None:
            try:
                reranked_ids = self.reranker.rerank(query, chunks)
                by_id = {chunk["chunk_id"]: chunk for chunk in chunks}
                chunks = [by_id[chunk_id] for chunk_id in reranked_ids if chunk_id in by_id]
            except Exception:
                # RRF order is a complete, deterministic fallback. A local
                # reranker outage must not make the evidence index unusable.
                pass
        # A top-k reranker may omit a required neighbour. Restore only the
        # already verified same-document pair, not arbitrary dropped sources.
        reranked = {chunk["chunk_id"] for chunk in chunks}
        for key, chunk in by_chunk.items():
            if key not in reranked and any(key in ranking for ranking in need_rankings.values()):
                chunks.append(chunk)
                reranked.add(key)
        for chunk in list(chunks):
            for key in continuation_pairs.get(chunk["chunk_id"], []):
                if key not in reranked:
                    chunks.append(by_chunk[key])
                    reranked.add(key)
        selected: list[dict[str, Any]] = []
        document_counts: dict[str, int] = {}
        seen_hashes: set[str] = set()
        selected_terms: list[set[str]] = []
        used_context = 0
        ranked_order = {chunk["chunk_id"]: i for i, chunk in enumerate(chunks)}
        candidate_terms = {chunk["chunk_id"]: set(re.findall(r"[A-Za-z0-9_]{3,}|[\u4e00-\u9fff]{2,}", chunk["text"].lower())) for chunk in chunks}
        remaining_chunks = list(chunks)
        pending_representatives = list(representatives)
        def passage_terms(value):
            # Common PDF spelling variation, not synonym or scientific inference.
            value = re.sub(r"\b(pre|fine)[- ]training\b", r"\1training", value.lower())
            value = re.sub(r"\bauto[- ]regressive\b", "autoregressive", value)
            value = re.sub(r"\bmask(?:ed|ing|s)?\b", "mask", value)
            return set(re.findall(r"[A-Za-z0-9_]{2,}|[\u4e00-\u9fff]{2,}", value))
        facet_terms = [passage_terms(value) for value in facets]
        body_terms = {chunk["chunk_id"]: passage_terms(chunk["text"]) for chunk in chunks}
        # Require the least-common actually present term, not just generic
        # 'image/text' overlap that falsely marks an objective as covered.
        anchors = []
        for expected in facet_terms:
            frequencies = {term: sum(term in terms for terms in body_terms.values()) for term in expected}
            present = [term for term in sorted(expected) if frequencies[term]]
            anchors.append(min(present, key=lambda term: frequencies[term]) if present else None)
        reference_ids = set()
        if (facets or evidence_needs) and not any(re.search(r"\breferences?\b|bibliograph|参考文献", value, re.I)
                for value in [*facets, query]):
            from pdf_pipeline import _is_reference_list
            def reference_passage(text):
                if _is_reference_list(text):
                    return True
                # Chunk normalization collapses PDF line breaks. Recover only
                # numbered-entry boundaries in a block that starts as a list;
                # inline citations in normal prose must not become bibliography.
                if not re.match(r"^\s*\[\d+\]\s+[A-Z]", text):
                    return False
                entries = re.split(r"\s+(?=\[\d+\]\s+[A-Z])", text)
                return len(entries) >= 2 and _is_reference_list("\n".join(entries))
            reference_ids = {chunk["chunk_id"] for chunk in chunks if reference_passage(chunk["text"])}
        covered_facets = {key: set() for key in representatives}
        # Facet overlap is a retrieval hint, not semantic evidence approval.
        # Matching only a document title must not create a complementary passage.
        def matching_facets(chunk):
            if chunk["chunk_id"] in reference_ids:
                return set()
            terms = body_terms[chunk["chunk_id"]]
            return {i for i, expected in enumerate(facet_terms)
                    if anchors[i] in terms and len(terms & expected) >= min(2, len(expected))}
        secondary_representatives = list(representatives) if facets else []
        priority_indices = {i for i, value in enumerate(facets) if value in priority_passage_queries}
        mechanism_indices = {i for i, value in enumerate(facets) if value in mechanism_passage_queries}
        result_indices = {i for i, value in enumerate(facets) if value in result_passage_queries}
        def result_candidate(chunk):
            # Lexical retrieval preference only: results may be negative and
            # these cues do not establish original attribution or scientific support.
            text = chunk['text']
            return bool(matching_facets(chunk) & result_indices and re.search(
                r'\b(?:find|found|observe|observed|achieve|achieves|achieved|outperform|outperforms|degrades?|decreases?|increases?)\b', text, re.I)
                and re.search(r'\d+(?:\.\d+)?\s*%|\b(?:accuracy|f1|latency|cost|performance)\b', text, re.I))
        priority_pending = bool(priority_indices)
        # One opportunity for each distinct entity before repeated aspects of
        # that entity. All opportunities consume the SAME packet/context quota.
        pending_needs, deferred_needs, entity_order = [], [], set()
        for need in evidence_needs:
            if need['need_id'] not in need_rankings:
                continue
            (deferred_needs if need['entity'].casefold() in entity_order else pending_needs).append(need)
            entity_order.add(need['entity'].casefold())
        pending_needs.extend(deferred_needs)
        need_cues = {
            'definition': (r'\b(?:input|inputs|given|prompt|prompts)\b',
                r'\b(?:output|outputs|predict\w*|produce\w*|return\w*)\b',
                r'\b(?:task|model|propose\w*|present|framework)\b'),
            'mechanism': (r'\b(?:training|loss|objective)\b',
                r'\b(?:architecture|algorithm|attention|encoder|decoder)\b', r'\b(?:our|method|propose\w*)\b'),
            'result': (r'\b(?:results?|evaluation|benchmark)\b',
                r'\b(?:accuracy|performance|latency|throughput)\b', r'\d+(?:\.\d+)?\s*%'),
            'protocol': (r'\b(?:dataset|training|test|split)\b',
                r'\b(?:protocol|setup|evaluation)\b', r'\b(?:samples|examples|images|batch)\b'),
        }
        while remaining_chunks:
            def mmr(chunk):
                terms = candidate_terms[chunk["chunk_id"]]
                redundancy = max((len(terms & prior) / max(1, len(terms | prior)) for prior in selected_terms), default=0.0)
                relevance = 1.0 - ranked_order[chunk["chunk_id"]] / max(1, len(chunks))
                return 0.75 * relevance - 0.25 * redundancy
            # One relevant recalled fragment per representative, then normal MMR.
            preferred = []
            priority_selected = False
            mechanism_preferred = False
            result_preferred = False
            need_selected = None
            while pending_needs and not preferred:
                need = pending_needs.pop(0)
                preferred = [c for c in remaining_chunks if c['document_id'] in need['document_ids']
                    and c['chunk_id'] in need_rankings[need['need_id']] and c['chunk_id'] not in reference_ids
                    and document_counts.get(c['document_id'], 0) < per_document
                    and used_context + c['token_estimate'] <= context_budget]
                if preferred:
                    need_selected = need
            if priority_pending and not preferred:
                preferred = [c for c in remaining_chunks
                    if matching_facets(c) & priority_indices and re.search(r"\d+(?:\.\d+)?\s*[%％]|\d+(?:[,\s]\d{3})*\s+samples?\b", c["text"], re.I)
                    and document_counts.get(c["document_id"], 0) < per_document
                    and used_context + c["token_estimate"] <= context_budget]
                priority_selected = bool(preferred)
                priority_pending = False
            while pending_representatives and not preferred:
                document_id = pending_representatives.pop(0)
                body = [c for c in remaining_chunks if c["document_id"] == document_id]
                mechanism_body = [c for c in body if matching_facets(c) & mechanism_indices]
                result_body = [c for c in body if result_candidate(c)]
                preferred = mechanism_body or result_body or body
                mechanism_preferred = bool(mechanism_body)
                result_preferred = bool(result_body) and not mechanism_preferred
            complementary = False
            if not preferred:
                while secondary_representatives and not preferred:
                    document_id = secondary_representatives.pop(0)
                    preferred = [c for c in remaining_chunks if c["document_id"] == document_id
                                 and matching_facets(c) - covered_facets[document_id]]
                    complementary = bool(preferred)
            def facet_relevance(chunk):
                missing = matching_facets(chunk) - covered_facets.get(chunk["document_id"], set())
                return (sum(facet_rankings[i].get(chunk["chunk_id"], 0.0) for i in missing), mmr(chunk))
            def priority_relevance(chunk):
                return (bool(chunk.get("figure_id") or chunk.get("table_id")),
                        sum(facet_rankings[i].get(chunk["chunk_id"], 0.0) for i in priority_indices), mmr(chunk))
            def mechanism_relevance(chunk):
                # Preserve the plan's requested facet order. Otherwise an intro
                # matching generic encoder/decoder terms beats a recalled mask
                # mechanism merely because the global reranker ranked it first.
                matched = matching_facets(chunk)
                if complementary:
                    matched -= covered_facets.get(chunk["document_id"], set())
                return (tuple(i in matched for i in sorted(mechanism_indices)), facet_relevance(chunk))
            def need_relevance(chunk):
                # Explainability cues are ordering hints, not truth/coverage
                # labels. No method-name-specific exceptions or auto-approval.
                native_definition = need_selected['aspect'] == 'definition' and need_selected['source_binding'] == 'exact_title'
                return (sum(bool(re.search(cue, chunk['text'], re.I)) for cue in need_cues[need_selected['aspect']]),
                    -chunk['page'] if native_definition and isinstance(chunk.get('page'), int) else 0,
                    need_rankings[need_selected['need_id']].get(chunk['chunk_id'], 0.0), mmr(chunk))
            chunk = max(preferred or remaining_chunks, key=need_relevance if need_selected else priority_relevance if priority_selected
                        else mechanism_relevance if mechanism_preferred or complementary and mechanism_indices
                        else facet_relevance if complementary else mmr)
            remaining_chunks.remove(chunk)
            document_id = chunk["document_id"]
            members = [by_chunk[key] for key in continuation_pairs.get(chunk["chunk_id"], [chunk["chunk_id"]])
                       if by_chunk[key]["content_hash"] not in seen_hashes]
            if (not members or document_counts.get(document_id, 0) + len(members) > per_document
                    or len(selected) + len(members) > max(1, min(int(limit), 40))):
                continue
            if used_context + sum(member["token_estimate"] for member in members) > context_budget:
                continue
            terms = candidate_terms[chunk["chunk_id"]]
            if any(len(terms & prior) / max(1, len(terms | prior)) >= 0.85 for prior in selected_terms):
                continue
            for member in members:
                chunk = member
                if chunk in remaining_chunks:
                    remaining_chunks.remove(chunk)
                seen_hashes.add(chunk["content_hash"])
                selected_terms.append(candidate_terms[chunk["chunk_id"]])
                if document_id in covered_facets:
                    covered_facets[document_id].update(matching_facets(chunk))
                document_counts[document_id] = document_counts.get(document_id, 0) + 1
                used_context += chunk["token_estimate"]
                selected.append({
                "schema_version": PACKET_SCHEMA,
                "evidence_id": chunk["chunk_id"],
                "document_id": document_id,
                "paper_id": chunk["paper_id"],
                "title": chunk["title"],
                "text": chunk["text"],
                "context_before": "",
                "context_after": "",
                **({"parser_provenance": chunk["parser_provenance"]} if chunk.get("parser_provenance") else {}),
                "locator": {
                    "page": chunk["page"], "page_end": chunk["page_end"], "section": chunk["section"],
                    "paragraph": chunk["paragraph"], "table_id": chunk["table_id"],
                    "figure_id": chunk["figure_id"], "bbox": chunk["bbox"],
                    "anchor_text": chunk["anchor_text"],
                },
                "retrieval": {"rrf_score": scores.get(chunk["chunk_id"], 0.0),
                              **({'evidence_need_selection': {
                                  'policy': 'entity-aspect-scoped-recall-within-existing-context/v1',
                                  'selected_for_need_id': need_selected['need_id'] if need_selected else None,
                                  'planned': [dict(n) for n in evidence_needs],
                                  'executed_need_ids': list(need_rankings),
                                  'candidate_need_ids': [n['need_id'] for n in evidence_needs
                                      if chunk['document_id'] in n['document_ids']
                                      and chunk['chunk_id'] in need_rankings.get(n['need_id'], {})],
                                  'semantic_support_verified': False}}
                                 if evidence_needs else {}),
                              "lexical_used": bool(lexical), "vector_used": bool(vector),
                              "planned_passage_queries": planned_facets,
                              "executed_passage_queries": facets,
                              "passage_deadline_skipped": len(facets) != len(planned_facets),
                              "matched_passage_facets": [facets[i] for i in sorted(matching_facets(chunk))],
                              "complementary_representative": complementary,
                              "mechanism_passage_selected": bool(matching_facets(chunk) & mechanism_indices),
                              "mechanism_priority_applied": mechanism_preferred or bool(complementary and mechanism_indices),
                              "result_priority_applied": result_preferred,
                              "result_candidate_hint": result_candidate(chunk),
                              **({"continuation": {"policy": continuation_policy,
                                  "evidence_ids": continuation_pairs[chunk["chunk_id"]],
                                  "role": "introducer" if introduces_formula(chunk) else "formula",
                                  "requires_independent_review": True}}
                                 if chunk["chunk_id"] in continuation_pairs else {}),
                              "priority_passage_selected": priority_selected},
                **({"table_context": chunk["table_context"]} if chunk.get("table_context") else {}),
            })
            if len(selected) >= max(1, min(int(limit), 40)):
                break
        return selected


@dataclass
class RagIndexer:
    """Deterministic ingest boundary shared by CLI and future Web workers."""

    evidence_store: EvidenceStore
    embedding: EmbeddingProvider | None = None
    vector_store: VectorStore | None = None
    vector_required: bool = False

    def delete_document(self, document_id: str, *, documents: DocumentStore | None = None) -> list[str]:
        document_id = _identifier(document_id, "document id")
        if self.vector_required and self.vector_store is None:
            raise RagDependencyError("vector deletion was required but is not configured")
        if self.vector_store is not None:
            self.vector_store.delete_document(document_id)
        if hasattr(self.embedding, 'clear'):
            self.embedding.clear()
        removed = self.evidence_store.delete_document(document_id)
        if documents is not None:
            documents.delete_document(document_id)
        return removed

    def index(self, metadata: Mapping[str, Any], blocks: Sequence[Mapping[str, Any]], *,
              deadline_monotonic: float | None = None) -> dict[str, Any]:
        started = time.perf_counter()
        phase_ms = {'chunk_ms': 0, 'embedding_ms': 0, 'vector_write_ms': 0, 'evidence_write_ms': 0}
        cache_before = (getattr(self.embedding, 'hits', 0), getattr(self.embedding, 'misses', 0))
        requests_before = getattr(getattr(self.embedding, 'provider', None), 'request_count', 0)
        def checkpoint():
            if deadline_monotonic is not None and time.monotonic() >= deadline_monotonic:
                raise TimeoutError("PDF_INDEX_DEADLINE")

        checkpoint()
        chunks = build_chunks(
            str(metadata.get("document_id") or ""), str(metadata.get("paper_id") or ""),
            str(metadata.get("title") or ""), blocks,
        )
        phase_ms['chunk_ms'] = round((time.perf_counter() - started) * 1000, 3)
        checkpoint()
        # Index identity includes the embedding configuration, not only PDF bytes.
        config = {"source": metadata.get("content_hash"), "model": getattr(self.embedding, "model_name", None),
                  "dimension": getattr(self.embedding, "dimension", None), "revision": getattr(self.embedding, "revision", None),
                  "chunks": [chunk["content_hash"] for chunk in chunks], "pipeline": "rag-v6-inline-paragraph-and-table-context"}
        index_metadata = {**metadata, "content_hash": _content_hash(json.dumps(config, sort_keys=True))}
        changed = self.evidence_store.document_hash(str(metadata["document_id"])) != index_metadata["content_hash"]
        repair_reason = None
        if (not changed and self.vector_required and self.vector_store is not None
                and hasattr(self.vector_store, "document_chunk_count")
                and self.vector_store.document_chunk_count(str(metadata["document_id"])) != len(chunks)):
            # Restoring logs/FTS without the vector volume must not create a
            # false cache hit. Rebuild only this document, without redownloading it.
            changed = True
            repair_reason = "VECTOR_INDEX_MISSING_OR_INCOMPLETE"
        vector_indexed = False
        if changed and self.vector_required and (self.embedding is None or self.vector_store is None):
            raise RagDependencyError("vector indexing was required but is not configured")
        if changed and self.embedding is not None and self.vector_store is not None:
            publication_started = False
            try:
                vectors = []
                # Native CPU inference is cooperative: one small batch may finish
                # after the deadline, but never start the rest of a long paper.
                for offset in range(0, len(chunks), INDEX_EMBEDDING_BATCH_SIZE):
                    checkpoint()
                    batch = chunks[offset:offset + INDEX_EMBEDDING_BATCH_SIZE]
                    phase_started = time.perf_counter()
                    encoded = self.embedding.embed([chunk["text"] for chunk in batch])
                    phase_ms['embedding_ms'] += round((time.perf_counter() - phase_started) * 1000, 3)
                    checkpoint()
                    if len(encoded) != len(batch):
                        raise RagError("EMBEDDING_BATCH_COUNT_INVALID")
                    vectors.extend(encoded)
                checkpoint()
                publication_started = True
                phase_started = time.perf_counter()
                self.vector_store.delete_document(str(metadata["document_id"]))
                self.vector_store.upsert(chunks, vectors)
                phase_ms['vector_write_ms'] = round((time.perf_counter() - phase_started) * 1000, 3)
                checkpoint()
            except BaseException:
                # No ready hash or partial vectors on failed publication. An
                # earlier complete index survives an embedding-only failure.
                if publication_started:
                    self.evidence_store.delete_document(str(metadata["document_id"]))
                    self.vector_store.delete_document(str(metadata["document_id"]))
                raise
            vector_indexed = True
        if changed:
            # Publish the ready hash only after embedding/upsert completed. A
            # forcibly killed worker cannot leave a falsely reusable index.
            try:
                checkpoint()
                phase_started = time.perf_counter()
                self.evidence_store.index_document(index_metadata, chunks)
                phase_ms['evidence_write_ms'] = round((time.perf_counter() - phase_started) * 1000, 3)
            except BaseException:
                if vector_indexed:
                    self.evidence_store.delete_document(str(metadata["document_id"]))
                    self.vector_store.delete_document(str(metadata["document_id"]))
                raise
        return {
            "schema_version": "sciassistant.rag-index-result/v1",
            "document_id": str(metadata["document_id"]),
            "changed": changed,
            "chunk_count": len(chunks),
            "vector_indexed": vector_indexed,
            "repair_reason": repair_reason,
            "phase_timings_ms": phase_ms,
            "embedding_cache": {'hits': getattr(self.embedding, 'hits', 0) - cache_before[0],
                                'misses': getattr(self.embedding, 'misses', 0) - cache_before[1]},
            "embedding_api_requests": getattr(getattr(self.embedding, 'provider', None), 'request_count', 0) - requests_before,
        }


def configured_embedding(evidence_store: EvidenceStore, *, private_document=False, cloud_consent=False):
    """Private documents never inherit public embedding configuration as consent."""
    from external_embedding import ExternalEmbedding, CachedEmbedding
    provider = os.getenv('SCIASSISTANT_EMBEDDING_PROVIDER', 'local')
    if provider not in {'local', 'external'}:
        raise RagError('EMBEDDING_PROVIDER_INVALID')
    if type(cloud_consent) is not bool:
        raise RagError('EMBEDDING_CONSENT_INVALID')
    external = provider == 'external' and (not private_document or cloud_consent)
    embedding = ExternalEmbedding() if external else LocalSentenceTransformerEmbedding(
        os.getenv('SCIASSISTANT_EMBEDDING_MODEL', DEFAULT_EMBEDDING_MODEL))
    return CachedEmbedding(embedding, evidence_store.path.with_name('embedding_cache.sqlite3'))


def configured_vector_services(evidence_store: EvidenceStore, *, private_document=False, cloud_consent=False) -> HybridRetriever:
    """Build live local/server vector services from environment configuration."""
    embedding = configured_embedding(evidence_store, private_document=private_document, cloud_consent=cloud_consent)
    qdrant_url = str(os.getenv("SCIASSISTANT_QDRANT_URL") or "").strip() or None
    qdrant_path = None if qdrant_url else Path(
        os.getenv("SCIASSISTANT_QDRANT_PATH", "logs/qdrant_evidence"),
    )
    collection = os.getenv("SCIASSISTANT_QDRANT_COLLECTION", "sciassistant_evidence")
    if embedding.external:
        collection = collection[:90] + '_ext_' + embedding.identity[:24]
    vector_store = QdrantVectorStore(
        dimension=embedding.dimension, path=qdrant_path, url=qdrant_url,
        collection=collection,
        api_key=os.getenv("SCIASSISTANT_QDRANT_API_KEY") or None,
    )
    return HybridRetriever(evidence_store, embedding, vector_store, vector_required=True, reranker=LexicalReranker())
