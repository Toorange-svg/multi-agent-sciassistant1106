"""Public license/source information. Never serves operator-selected local files.

Publication is explicit operator configuration, bound to the running source
fingerprint. A valid URL/attestation is not proof of source completeness.
"""
from __future__ import annotations

import ipaddress
import re
from urllib.parse import urlsplit

from flask import Blueprint, make_response, render_template_string, send_from_directory

HEX = re.compile(r"[0-9a-f]{64}")
TRUTH = {"true", "1", "yes"}


def source_status(values, fingerprint):
    url = str(values.get("PYMUPDF_SOURCE_URL", "")).strip()
    valid_url = False
    try:
        parsed = urlsplit(url)
        host = (parsed.hostname or "").lower()
        valid_url = (parsed.scheme == "https" and bool(host) and "." in host
                     and not parsed.username and not parsed.password and not parsed.query
                     and not parsed.fragment and parsed.port in {None, 443}
                     and not any(ord(c) < 33 or c in '<>"\\' for c in url)
                     and not host.endswith((".invalid", ".localhost", ".local", ".example"))
                     and host not in {"example.com", "example.org", "example.net"})
        try:
            valid_url = valid_url and ipaddress.ip_address(host).is_global
        except ValueError:
            pass  # DNS resolution/download is intentionally not done per request.
    except (ValueError, TypeError):
        pass
    sha = str(values.get("SCIASSISTANT_SOURCE_ARCHIVE_SHA256", ""))
    bound = str(values.get("SCIASSISTANT_SOURCE_FINGERPRINT", ""))
    checks = {
        "agpl_mode": values.get("PYMUPDF_LICENSE_MODE") == "agpl",
        "operator_review_confirmed": all(str(values.get(k, "")).lower() in TRUTH for k in (
            "PYMUPDF_AGPL_OBLIGATIONS_CONFIRMED", "PYMUPDF_CORRESPONDING_SOURCE_CONFIRMED")),
        "public_https_url": bool(valid_url),
        "archive_sha256": bool(HEX.fullmatch(sha)),
        "running_source_bound": bool(HEX.fullmatch(bound)) and bound == fingerprint,
    }
    ready = all(checks.values())
    return {"ready": ready, "checks": checks, "url": url if ready else None,
            "archive_sha256": sha if ready else None, "source_fingerprint": fingerprint}


PAGE = """<!doctype html><html lang="zh-CN"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>开源许可与对应源码 · SciAssistant</title>
<style>body{font:16px/1.7 system-ui,sans-serif;max-width:850px;margin:40px auto;padding:0 20px;color:#24324a}
code{overflow-wrap:anywhere}a{color:#235bcc}.notice{padding:18px;border:1px solid #c9d4e5;border-radius:10px;background:#f5f8ff}</style>
<h1>开源许可与对应源码</h1>
<p>本服务使用 PyMuPDF/MuPDF 的 AGPL 开源许可路径。项目原有版权声明及第三方许可均予保留。
私人 PDF、账户、API Key、数据库和聊天记录不属于公开下载内容。</p>
{% if status.ready %}<section class="notice"><h2>本部署版本的源码材料</h2>
<p><a id="corresponding-source-link" href="{{ status.url }}" rel="noopener noreferrer">获取对应源码与构建材料</a></p>
<p>下载包 SHA-256：<code>{{ status.archive_sha256 }}</code></p>
<p>材料由部署负责人发布并确认对应范围；本站展示版本绑定及校验值，不以配置检查代替完整性核查。</p></section>
{% else %}<section class="notice" role="status"><h2>源码交付尚未配置完成</h2>
<p>当前版本仅用于开发/验收，尚不能据此开放正式网站。部署方需发布与本版本相符的源码和必要依赖源码，
完成核查后配置下载地址、校验值及版本绑定。页面不会以旧版本地址或占位链接冒充已交付。</p></section>{% endif %}
<p>正在运行的源码指纹：<code>{{ status.source_fingerprint }}</code></p>
<h2>许可与归属</h2><ul><li><a href="/open-source/notices/LICENSE">项目原始 LICENSE</a></li>
<li><a href="/open-source/notices/NOTICE">项目 NOTICE 与第三方声明</a></li>
<li><a href="https://www.gnu.org/licenses/agpl-3.0.html" rel="noopener noreferrer">GNU AGPL-3.0 许可全文</a></li></ul>
<p><a href="/login.html">返回登录</a> · <a href="/ai_chat.html">返回科研助手</a></p></html>"""


def install(app, identity, root):
    import os
    routes = Blueprint("source_delivery", __name__)

    @routes.get("/open-source")
    def information():
        status = source_status(os.environ, identity.fingerprint)
        response = make_response(render_template_string(PAGE, status=status), 200 if status["ready"] else 503)
        response.headers["Cache-Control"] = "no-store"
        return response

    @routes.get("/open-source/notices/<name>")
    def notices(name):
        from flask import abort
        if name not in {"LICENSE", "NOTICE"}:
            abort(404)
        return send_from_directory(root, name, mimetype="text/plain")

    app.register_blueprint(routes)
