@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
set "PROJECT_DIR=%~dp0"
set "PYTHON_EXE=%PROJECT_DIR%venv\Scripts\python.exe"
set "CHECK_SCRIPT=%PROJECT_DIR%tools\check_arxiv_api.py"

if not exist "%PYTHON_EXE%" goto :missing_python
if not exist "%CHECK_SCRIPT%" goto :missing_script

echo Running standalone arXiv API check. Web and MCP services are not started.
"%PYTHON_EXE%" "%CHECK_SCRIPT%" %*
set "EXIT_CODE=%ERRORLEVEL%"
echo.
if "%EXIT_CODE%"=="0" goto :passed
echo Check did not pass. See endpoint statuses and the JSON report above.
goto :end

:missing_python
echo Project virtual environment not found: venv\Scripts\python.exe
set "EXIT_CODE=1"
goto :end

:missing_script
echo Check script not found: tools\check_arxiv_api.py
set "EXIT_CODE=1"
goto :end

:passed
echo Check passed.

:end
pause
endlocal & exit /b %EXIT_CODE%
