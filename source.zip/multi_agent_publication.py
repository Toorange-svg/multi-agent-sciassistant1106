"""Final requirement review and bounded recovery; bindings are not answers."""
from copy import deepcopy
import json
import re

from multi_agent_report_contracts import GLOBAL_GUIDANCE_KINDS
from multi_agent_sections import BODY_DELIVERY_POLICY

PUBLICATION_POLICY = 'auditor-requirement-review-after-publication-and-bounded-recovery/v1'
AUDIT_MATERIAL_POLICY = 'single-current-claim-view-no-global-duplicate/v1'


def body_delivery_findings(draft, *, excluded_claim_ids=()):
    """Locate an empty table lead-in, not unsupported science or missing rows.

    Only fresh versioned outlines opt in. Details cannot resolve a body pointer;
    a later visible table/list bound to the same ask and section can. No text,
    citation, approval, requirement binding or historical artifact is changed.
    """
    if draft.get('report_outline', {}).get('body_delivery_policy') != BODY_DELIVERY_POLICY:
        return []
    rows = [c for c in draft.get('claims', []) if c['claim_id'] not in excluded_claim_ids]
    table_kinds = {r['requirement_id'] for r in draft['report_outline'].get('requirements', [])
                   if r.get('answer_kind') == 'table_reading'}
    pointer = re.compile(r'(?:如下(?:表|所示)?|见下表|下表(?:所示)?|as follows|(?:shown|listed) below)'
        r'\s*(?:[（(](?:第?\s*\d+\s*页|p(?:age)?\.?\s*\d+)[)）])?\s*[:：]\s*$', re.I)

    def has_rows(text):
        lines = text.splitlines()
        return (sum(line.count('|') >= 2 for line in lines) >= 2
                or sum(bool(re.match(r'\s*(?:[-*]|\d+[.)、]|r\s*=\s*\d+\s*[:：])\s*\S', line, re.I))
                       for line in lines) >= 2)

    findings = []
    for i, claim in enumerate(rows):
        requirements = table_kinds.intersection(claim.get('requirement_ids', []))
        text = claim.get('text', '')
        match = pointer.search(text) if requirements and isinstance(text, str) else None
        if not match:
            continue
        unresolved = [rid for rid in sorted(requirements) if not any(
            other.get('report_section_id') == claim.get('report_section_id')
            and rid in other.get('requirement_ids', []) and has_rows(other.get('text', ''))
            for other in rows[i+1:])]
        if unresolved:
            findings.append({'claim_id': claim['claim_id'], 'field': 'text',
                'reason': 'BODY_TABLE_POINTER_UNRESOLVED', 'policy': BODY_DELIVERY_POLICY,
                'requirement_ids': unresolved, 'assertion': text[match.start():match.end()],
                'start': match.start(), 'end': match.end(),
                'detail': '正文承诺“如下/下表”，但后续同节、同需求的获准正文没有可见表或列表；详情不是正文交付。请用批准证据实写所要求的内容，或删除空占位并具体说明未完成项。',
                'scientific_rejection': False, 'automatic_rewrite': False})
    return findings


def audit_material(full):
    """Remove ONLY duplicate views already present in the claim-scoped jobs.

    Keep the original claim/job/source contents and exact source-choice handles.
    No excerpts, claims, requirement rows or report sections are shortened.
    """
    result = deepcopy(full)
    if not isinstance(result.get('audit_jobs'), list):
        return result
    removed = []
    for name in ('claims', 'source_witness_options', 'absence_assertion_options', 'source_copy_brief'):
        if name in result:
            removed.append(name)
            result.pop(name)
    result['audit_material'] = {'policy': AUDIT_MATERIAL_POLICY,
        'removed_duplicate_views': removed, 'authoritative_view': 'audit_jobs',
        'source_or_claim_truncated': False}
    return result


def review_request(ledger, draft):
    requirements = [deepcopy(r) for r in ledger.get('requirements', []) if r['answer_kind'] not in GLOBAL_GUIDANCE_KINDS]
    for row in requirements:
        row['eligible_claim_ids'] = [c['claim_id'] for c in draft.get('claims', [])
            if row['requirement_id'] in c.get('requirement_ids', [])]
        row['completion_checks'] = {
            'table_reading': ['Check the requested columns and actual requested values/rows in main text, not only rank names or a best-value summary. Do not demand rows the user did not request.'],
            'conclusion_summary': ['Both supported conclusions AND non-conclusions must survive publication; a heading or only one half is limited, not answered.'],
            'evaluation_protocol': ['Include the unexecuted factor contrast, reference/control, repeat protocol and a logically valid decision rule; proposing repeats alone is limited.'],
        }.get(row['answer_kind'], [])
    return {'schema_version': 'sciassistant.report-review-request/v1', 'policy': PUBLICATION_POLICY,
        'requirements': requirements,
        'body_delivery_findings': body_delivery_findings(draft),
        'claim_ids': [c['claim_id'] for c in draft.get('claims', [])],
        'instructions': [
            'Assess the actual answer to EACH original ask, not keyword overlap or correct requirement IDs. Use answered/limited/unanswered and actual answering claim IDs; a mere no-evidence disclaimer is not a substantive answer to a mechanism/design request.',
            'Return report_review {schema_version:sciassistant.report-review/v1, requirements:[{requirement_id,status,claim_ids,reason}], consistency:{reviewed_claim_ids,conflicts:[{claim_ids,detail}]}}. Every content requirement needs exactly one row. Global guidance is not a separate scientific answer.',
            'Compare main answer, analyses and conclusion against the actual sources: ties vs unique winner, metrics, dataset/task scope and proposal vs measured result. Different settings can explain a distinction, not a contradiction. Report only actual conflicts, identify all involved claim IDs.',
            'This review cannot approve source citations, restore rejected claims, create facts or extend tools. Existing citation field verdicts remain mandatory. All IDs refer to CURRENT claims only.',
            'For a requirement, claim_ids must be selected ONLY from its eligible_claim_ids; a related claim bound to a different requirement is not a valid binding. Do not add bindings yourself. Use unanswered with [] if no eligible claim actually answers it.',
            'Apply each requirement completion_checks to actual text; these are review prompts, not automatic completion or scientific approval. A verified excerpt can answer more than one assigned requirement regardless of which section displays it.',
        ], 'semantic_auto_approval': False}


def check_review(value, ledger, draft):
    """Administrative validity, not semantic truth. Bad metadata cannot veto text."""
    request = review_request(ledger, draft)
    wanted = {r['requirement_id'] for r in request['requirements']}
    by_id = {c['claim_id']: c for c in draft.get('claims', [])}
    errors, valid, diagnostics = [], {}, []
    if not isinstance(value, dict) or value.get('schema_version') != 'sciassistant.report-review/v1':
        return {'errors': ['REPORT_REVIEW_MISSING_OR_SCHEMA'], 'rows': {}, 'conflicts': [], 'consistency_verified': False,
            'diagnostics': [{'path':'report_review', 'reason':'REPORT_REVIEW_MISSING_OR_SCHEMA',
                'missing_requirement_ids':sorted(wanted)}], 'semantic_auto_approval':False}
    rows = value.get('requirements')
    if not isinstance(rows, list) or len(rows) > 200:
        rows = []
        errors.append('REPORT_REVIEW_ROWS_INVALID')
    seen = set()
    for index, row in enumerate(rows):
        if not isinstance(row, dict) or set(row) != {'requirement_id','status','claim_ids','reason'}:
            errors.append('REPORT_REVIEW_ROW_INVALID'); continue
        key, refs = row['requirement_id'], row['claim_ids']
        if not isinstance(key, str) or key not in wanted or key in seen:
            if isinstance(key, str): valid.pop(key, None)
            errors.append('REPORT_REVIEW_ID_INVALID'); continue
        seen.add(key)
        if (not isinstance(row['status'], str) or row['status'] not in {'answered','limited','unanswered'}
                or not isinstance(row['reason'], str) or not 1 <= len(row['reason'].strip()) <= 800
                or not isinstance(refs, list) or any(not isinstance(k,str) for k in refs)
                or len(refs) != len(set(refs))
                or any(k not in by_id or key not in by_id[k].get('requirement_ids', []) for k in refs)
                or (row['status']=='unanswered') != (not refs)):
            eligible = [c['claim_id'] for c in draft.get('claims', []) if key in c.get('requirement_ids', [])]
            diagnostics.append({'path':f'report_review.requirements[{index}]', 'requirement_id':key,
                'reason':'REPORT_REVIEW_BINDING_INVALID', 'eligible_claim_ids':eligible,
                'invalid_claim_ids':[k for k in refs if isinstance(k,str) and k not in eligible] if isinstance(refs,list) else [],
                'rule':'answered/limited requires nonempty unique eligible IDs; unanswered requires []; reason must be 1..800 characters.'})
            errors.append('REPORT_REVIEW_BINDING_INVALID'); continue
        valid[key] = deepcopy(row)
    if set(valid) != wanted:
        errors.append('REPORT_REVIEW_INCOMPLETE')
        diagnostics.append({'path':'report_review.requirements','reason':'REPORT_REVIEW_INCOMPLETE',
            'missing_requirement_ids':sorted(wanted-set(valid))})
    consistency = value.get('consistency')
    conflicts, verified = [], True
    if not isinstance(consistency,dict) or set(consistency) != {'reviewed_claim_ids','conflicts'}:
        verified = False
    else:
        ids = consistency['reviewed_claim_ids']
        if (not isinstance(ids,list) or any(not isinstance(k,str) for k in ids)
                or len(ids) != len(set(ids)) or set(ids) != set(by_id)):
            verified = False
        items = consistency['conflicts']
        if not isinstance(items,list) or len(items)>80:
            verified = False
        else:
            for row in items:
                if (not isinstance(row,dict) or set(row) != {'claim_ids','detail'}
                        or not isinstance(row['claim_ids'],list) or len(row['claim_ids'])<2
                        or any(not isinstance(k,str) for k in row['claim_ids'])
                        or len(row['claim_ids']) != len(set(row['claim_ids']))
                        or not set(row['claim_ids']).issubset(by_id)
                        or not isinstance(row['detail'],str) or not 1 <= len(row['detail'].strip())<=800):
                    verified=False
                else: conflicts.append(deepcopy(row))
    if not verified:
        errors.append('REPORT_CONSISTENCY_INVALID')
        conflicts=[]  # Malformed IDs never create automatic scientific rejections.
    return {'errors':list(dict.fromkeys(errors)), 'rows':valid, 'conflicts':conflicts,
        'consistency_verified':verified, 'semantic_auto_approval':False, 'diagnostics':diagnostics}


def conflict_issues(checked):
    return [{'claim_id':key, 'reason':'CROSS_SECTION_CONFLICT', 'policy':PUBLICATION_POLICY,
        'detail':row['detail'], 'related_claim_ids':row['claim_ids']}
        for row in checked['conflicts'] for key in row['claim_ids']]


def coverage(ledger, draft, audit, rejected):
    checked = check_review(audit.get('report_review'),ledger,draft)
    body_findings = body_delivery_findings(draft, excluded_claim_ids=rejected)
    rows = []
    for req in ledger.get('requirements', []):
        key = req['requirement_id']
        bound = [c['claim_id'] for c in draft.get('claims', []) if key in c.get('requirement_ids', [])]
        published = [k for k in bound if k not in rejected and 'draft' not in rejected]
        reported = checked['rows'].get(key)
        if req['answer_kind'] in GLOBAL_GUIDANCE_KINDS:
            status, reason = 'guidance', '全篇约束/组织要求保留；不计为独立科研问题已回答。'
        elif not published:
            status = 'unanswered'
            reason = '对应声明未通过审查或依赖被隔离。' if bound else '最终获准稿没有对应内容；规划安排不算已回答。'
        elif not reported:
            status, reason = 'needs_review', '有获准内容，但需求级审查缺失或无效，不能按绑定认定已经回答。'
        elif set(reported['claim_ids']) - set(published):
            status, reason = 'needs_review', '需求审查依赖的部分声明已被隔离，剩余内容的覆盖须重新核对。'
        else:
            status, reason = reported['status'], reported['reason']
        local_findings = [f for f in body_findings if key in f['requirement_ids']]
        if local_findings and status == 'answered':
            status, reason = 'limited', reason + ' 正文仍有未兑现的表格占位，不能把此项记为完整交付。'
        rows.append({'requirement_id':key, 'question_quote':req['question_quote'], 'answer_kind':req['answer_kind'],
            'status':status, 'reason':reason, 'published_claim_ids':published,
            'reviewed_claim_ids':reported['claim_ids'] if reported else [],
            'isolated_claim_ids':[k for k in bound if k not in published],
            **({'body_delivery_findings':local_findings} if local_findings else {})})
    content = [r for r in rows if r['status'] != 'guidance']
    return {'schema_version':'sciassistant.publication-coverage/v1','policy':PUBLICATION_POLICY,
        'requirements':rows, 'review_errors':checked['errors'], 'consistency_verified':checked['consistency_verified'],
        'all_content_answered':bool(content) and all(r['status']=='answered' for r in content),
        'unresolved_requirement_ids':[r['requirement_id'] for r in content if r['status']!='answered'],
        'basis':'independent_auditor_report_review_intersected_with_final_publication',
        'model_verdict_is_not_independent_human_validation':True,'semantic_auto_approval':False}


def recovery_brief(delivery, approved):
    targets=[deepcopy(r) for r in delivery['requirements'] if r['status'] in {'unanswered','needs_review','limited'}]
    return {'schema_version':'sciassistant.publication-recovery/v1','policy':PUBLICATION_POLICY,
        'requirements':targets, 'allowed_evidence_ids':[e['evidence_id'] for e in approved.get('evidence',[]) if e.get('review_status')=='approved'],
        'instructions':'Only repair these actual user asks using current approved sources. Preserve independently correct sections. '
            'Do not restore isolated facts without real correction and a fresh full audit. No new research/tool request, no invented numbers. '
            'If evidence cannot answer an ask, leave an explicit specific incomplete reason rather than a generic paragraph.',
        'uses_existing_writer_revision_round':True,'full_reaudit_required':True}


def retain_untargeted_claims(previous, revised, eligible_ids, affected_requirements):
    """Restore omitted independent content BEFORE full re-audit, never publish it.

    Only prior source-approved and requirement-reviewed claims may be retained;
    any claim involving a repair target is excluded. Existing new text is not
    overwritten. Dependency eligibility is required transitively.
    """
    result=deepcopy(revised)
    current={c['claim_id'] for c in result.get('claims',[])}
    candidates={c['claim_id']:c for c in previous.get('claims',[]) if c['claim_id'] in eligible_ids
        and not set(c.get('requirement_ids',[])) & set(affected_requirements)}
    while True:
        invalid={k for k,c in candidates.items() if not set(c.get('depends_on_claim_ids',[])).issubset(current|set(candidates))}
        if not invalid:break
        for k in invalid:candidates.pop(k)
    retained=[deepcopy(c) for k,c in candidates.items() if k not in current]
    result['claims'].extend(retained)
    return result, {'schema_version':'sciassistant.pre-reaudit-retention/v1','policy':PUBLICATION_POLICY,
        'retained_claim_ids':[c['claim_id'] for c in retained], 'automatic_publication':False,
        'full_reaudit_required':True}


def delivery_markdown(delivery):
    labels={'answered':'已回答','limited':'有限回答','unanswered':'未完成','needs_review':'覆盖待复核'}
    lines=['## 用户要求交付清单', '', '以下按最终获准内容核算，不以规划或草稿自报代替回答。', '']
    for i,row in enumerate((r for r in delivery['requirements'] if r['status']!='guidance'),1):
        quote=' '.join(row['question_quote'].split())
        lines += [f"{i}. {quote} — {labels[row['status']]}", '', '   '+row['reason'].replace('\n',' '), '']
    return '\n'.join(lines)
