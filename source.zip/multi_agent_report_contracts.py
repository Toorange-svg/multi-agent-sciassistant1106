"""Workflow-owned report budgets and literal requirements, never semantic approval."""
from copy import deepcopy
import hashlib
import re

PROFILE_POLICY = 'explicit-report-budget/v1'
REPORT_PLAN_SCHEMA = 'sciassistant.research-plan/v7'
LEGACY_REPORT_PLAN_SCHEMA = 'sciassistant.research-plan/v5'
REQUIREMENT_PLAN_SCHEMAS = {REPORT_PLAN_SCHEMA, LEGACY_REPORT_PLAN_SCHEMA, 'sciassistant.research-plan/v6'}
GLOBAL_GUIDANCE_KINDS = frozenset({'constraint', 'report_structure'})
INVENTORY_SCHEMA = 'sciassistant.question-inventory/v1'
REQUIREMENTS_SCHEMA = 'sciassistant.user-requirements/v1'
REQUIREMENTS_POLICY = 'literal-user-order-with-code-owned-segment-links/v2'
PROFILE_SOFT_POLICY = 'profile-research-start-complete-inflight/v2'
LEGACY_SOFT_POLICY = 'research-start-300-complete-inflight/v1'
# Anti-abuse envelope, not a target report length or claim/section count.
MAX_REQUIREMENTS = 200
ANSWER_KINDS = frozenset({'definition', 'mechanism', 'comparison', 'quantitative', 'inference',
    'proposal', 'conditional_recommendation', 'report_structure', 'premise_check', 'constraint',
    'table_reading', 'evidence_synthesis', 'scope_check', 'evaluation_protocol',
    'falsifiable_decision', 'report_consistency', 'relation', 'conflict_resolution', 'conclusion_summary'})


def report_budget(profile='standard', *, time_budget=None, model_calls=None):
    if not isinstance(profile, str) or profile not in {'standard', 'enhanced'}:
        raise ValueError('REPORT_PROFILE_INVALID')
    calls, cutoff, target, reserve = (10, 300, 360, 2) if profile == 'standard' else (20, 600, 720, 7)
    if time_budget is not None and (type(time_budget) is not int or not 1 <= time_budget <= target):
        raise ValueError('REPORT_TIME_BUDGET_INVALID')
    if model_calls is not None and (type(model_calls) is not int or not 1 <= model_calls <= calls):
        raise ValueError('REPORT_CALL_BUDGET_INVALID')
    return {'schema_version': 'sciassistant.report-budget/v1', 'policy': PROFILE_POLICY,
        'report_profile': profile, 'model_call_limit': calls if model_calls is None else model_calls,
        'research_start_cutoff_seconds': cutoff,
        'time_budget_seconds': target if time_budget is None else time_budget,
        'duration_target_seconds': target, 'reserved_delivery_calls': reserve,
        'maximum_initial_writer_batches': 1 if profile == 'standard' else 4,
        'automatic_profile_escalation': False}


def is_soft_time_policy(policy):
    return policy in {LEGACY_SOFT_POLICY, PROFILE_SOFT_POLICY}


def default_time_policy(profile):
    report_budget(profile)
    return LEGACY_SOFT_POLICY if profile == 'standard' else PROFILE_SOFT_POLICY


def plan_term_limit(schema, field):
    # Hint proposals are not executable requests. Old schemas keep exact caps.
    return 8 if field == 'metrics' or schema == REPORT_PLAN_SCHEMA else 4


def question_inventory(question):
    if not isinstance(question, str) or not 1 <= len(question.strip()) <= 20_000:
        raise ValueError('QUESTION_INVENTORY_INPUT_INVALID')
    segments = []
    # Exact offsets; no summarization, keyphrase filtering, or last-N truncation.
    for match in re.finditer(r'[^。！？!?；;\r\n]+[。！？!?；;]*|[。！？!?；;]+', question):
        text = match.group()
        leading, trailing = len(text) - len(text.lstrip()), len(text.rstrip())
        if leading == trailing:
            continue
        start, end = match.start() + leading, match.start() + trailing
        segments.append({'segment_id': f's{len(segments)+1}', 'start': start, 'end': end,
            'text': question[start:end]})
    if not 1 <= len(segments) <= 1000:
        raise ValueError('QUESTION_INVENTORY_SEGMENT_LIMIT')
    return {'schema_version': INVENTORY_SCHEMA, 'policy': REQUIREMENTS_POLICY,
        'question_sha256': hashlib.sha256(question.encode('utf8')).hexdigest(),
        'question_characters': len(question), 'segments': segments,
        'instructions': 'Copy exact question quotes into user_requirements. Workflow derives segment links from their literal offsets. '
            'You may identify background using segment_dispositions; omitted or mislinked context stays unclassified. Background is not evidence. '
            'Include all explicit questions, report deliverables, decisions, negative constraints and tail requests. '
            'Do not merge distinct asks merely to fit research groups. Semantic correctness is not guaranteed by this inventory.',
        'semantic_auto_approval': False}


def _quote_span(question, quote, occurrence=None):
    matches = list(re.finditer(re.escape(quote), question))
    if occurrence is None and len(matches) != 1:
        return None
    index = 1 if occurrence is None else occurrence
    if type(index) is not int or not 1 <= index <= len(matches):
        return None
    match = matches[index-1]
    return match.start(), match.end()


def align_requirement_segments(plan, question):
    """Repair linkage metadata, never facts, proposed requests or quote text.

    Current schema only. Old plans and decisions are read without reinterpretation.
    Exact quotes determine links. Unlinked input is never silently backgrounded.
    """
    result=deepcopy(plan)
    if result.get('schema_version') != REPORT_PLAN_SCHEMA:
        return result
    inventory=question_inventory(question)
    proposed=result.get('segment_dispositions')
    proposed=proposed if isinstance(proposed, dict) else {}
    spans={}
    for row in result.get('user_requirements',[]) if isinstance(result.get('user_requirements'),list) else []:
        if (isinstance(row,dict) and isinstance(row.get('id'),str)
                and isinstance(row.get('question_quote'),str) and row['question_quote']):
            span=_quote_span(question,row['question_quote'],row.get('occurrence'))
            if span:
                spans[row['id']]=span
    aligned,changes={},[]
    for segment in inventory['segments']:
        key=segment['segment_id']
        links=[rid for rid,span in spans.items() if span[0]<segment['end'] and span[1]>segment['start']]
        value=links or ('background' if proposed.get(key)=='background' else 'unclassified')
        aligned[key]=value
        if proposed.get(key)!=value:
            changes.append({'segment_id':key,'action':'bind_literal_quote' if links else 'retain_unclassified',
                'requirement_ids':links})
    result['segment_dispositions']=aligned
    result['segment_mapping']={'schema_version':'sciassistant.requirement-segment-mapping/v2',
        'policy':REQUIREMENTS_POLICY,'changes':changes,
        'unknown_proposed_segment_ids':sorted(set(proposed)-set(aligned)),
        'unclassified_segment_ids':[key for key,value in aligned.items() if value=='unclassified'],
        'requirement_content_changed':False,'semantic_auto_approval':False}
    return result


def requirement_plan_issues(plan, question=None, inventory=None):
    if plan.get('schema_version') not in REQUIREMENT_PLAN_SCHEMAS:
        return []
    issues, ids, quotes = [], set(), set()
    rows = plan.get('user_requirements')
    if not isinstance(rows, list) or not 1 <= len(rows) <= MAX_REQUIREMENTS:
        return [{'path': 'user_requirements', 'reason': 'USER_REQUIREMENTS_REQUIRED'}]
    groups = {g['id'] for g in plan.get('groups', []) if isinstance(g, dict) and isinstance(g.get('id'), str)}
    reports = {r['id'] for r in plan.get('report_obligations', []) if isinstance(r, dict) and isinstance(r.get('id'), str)}
    spans = {}
    for i, row in enumerate(rows):
        path = f'user_requirements[{i}]'
        expected = {'id', 'question_quote', 'answer_kind', 'research_group_ids', 'report_obligation_ids'}
        if not isinstance(row, dict) or not expected <= set(row) or set(row)-expected-{'occurrence'}:
            issues.append({'path': path, 'reason': 'USER_REQUIREMENT_FIELDS_INVALID'})
            continue
        key, quote, kind = row['id'], row['question_quote'], row['answer_kind']
        if not isinstance(key, str) or not re.fullmatch(r'u[1-9][0-9]*', key) or key in ids:
            issues.append({'path': path+'.id', 'reason': 'USER_REQUIREMENT_ID_INVALID'})
            continue
        ids.add(key)
        occurrence = row.get('occurrence')
        if (not isinstance(quote, str) or not 1 <= len(quote.strip()) <= 1200
                or occurrence is not None and (type(occurrence) is not int or occurrence < 1)
                or question is not None and isinstance(quote, str) and not _quote_span(question, quote, occurrence)):
            issues.append({'path': path+'.question_quote', 'reason': 'UNIQUE_CURRENT_QUESTION_QUOTE_REQUIRED'})
        elif question is not None:
            spans[key] = _quote_span(question, quote, occurrence)
        if not isinstance(kind, str) or kind not in ANSWER_KINDS:
            issues.append({'path': path+'.answer_kind', 'reason': 'USER_REQUIREMENT_KIND_INVALID'})
        elif isinstance(quote, str) and (occurrence is None or type(occurrence) is int):
            identity = (quote, kind, row.get('occurrence', 1))
            if identity in quotes:
                issues.append({'path': path, 'reason': 'DUPLICATE_USER_REQUIREMENT'})
            quotes.add(identity)
        for field, allowed in [('research_group_ids', groups), ('report_obligation_ids', reports)]:
            values = row[field]
            if (not isinstance(values, list) or len(values) > MAX_REQUIREMENTS
                    or any(not isinstance(v, str) for v in values)
                    or len(set(v for v in values if isinstance(v, str))) != len(values)
                    or any(v not in allowed for v in values if isinstance(v, str))):
                issues.append({'path': path+'.'+field, 'reason': 'REQUIREMENT_BINDING_INVALID'})
        if (row['research_group_ids'] == [] and row['report_obligation_ids'] == []
                and not (plan.get('schema_version') == REPORT_PLAN_SCHEMA and isinstance(kind, str) and kind in GLOBAL_GUIDANCE_KINDS)):
            issues.append({'path': path, 'reason': 'REQUIREMENT_HAS_NO_PLANNED_DELIVERY'})
    decisions = plan.get('segment_dispositions')
    if not isinstance(decisions, dict):
        return issues + [{'path': 'segment_dispositions', 'reason': 'SEGMENT_DISPOSITIONS_REQUIRED'}]
    for key, value in decisions.items():
        if (not isinstance(key, str) or not re.fullmatch(r's[1-9][0-9]*', key)
                or value != 'background' and not (value=='unclassified' and plan.get('schema_version') in {REPORT_PLAN_SCHEMA,'sciassistant.research-plan/v6'})
                    and (not isinstance(value, list) or not value
                    or any(not isinstance(v, str) or v not in ids for v in value))):
            issues.append({'path': 'segment_dispositions.'+str(key), 'reason': 'SEGMENT_DISPOSITION_INVALID'})
    if question is not None:
        inventory = inventory or question_inventory(question)
        expected = {s['segment_id']: s for s in inventory['segments']}
        if set(decisions) != set(expected):
            issues.append({'path': 'segment_dispositions', 'reason': 'ALL_INPUT_SEGMENTS_MUST_BE_CLASSIFIED',
                'missing_segment_ids': sorted(set(expected)-set(decisions)),
                'unknown_segment_ids': sorted(set(decisions)-set(expected))})
        referenced = set()
        for key, segment in expected.items():
            for rid in decisions.get(key, []) if isinstance(decisions.get(key), list) else []:
                if rid in spans and spans[rid][0] < segment['end'] and spans[rid][1] > segment['start']:
                    referenced.add(rid)
                else:
                    issues.append({'path': 'segment_dispositions.'+key, 'reason': 'REQUIREMENT_QUOTE_DOES_NOT_OVERLAP_SEGMENT'})
        if set(spans)-referenced:
            issues.append({'path': 'segment_dispositions', 'reason': 'REQUIREMENT_WITHOUT_INPUT_SEGMENT',
                'requirement_ids': sorted(set(spans)-referenced)})
    return issues


def compile_user_requirements(question, plan, inventory=None):
    inventory = inventory or question_inventory(question)
    plan = deepcopy(plan)
    # scope_plan_to_question may move a report-only group without changing its
    # ID. Preserve the request; rebind the delivery type, never create a search.
    report_ids = {r['id'] for r in plan.get('report_obligations', [])}
    research_ids = {g['id'] for g in plan.get('groups', [])}
    for row in plan.get('user_requirements', []):
        moved = [key for key in row['research_group_ids'] if key in report_ids and key not in research_ids]
        row['research_group_ids'] = [key for key in row['research_group_ids'] if key not in moved]
        row['report_obligation_ids'] = list(dict.fromkeys([*row['report_obligation_ids'], *moved]))
    issues = requirement_plan_issues(plan, question, inventory)
    if issues:
        raise ValueError('USER_REQUIREMENTS_CONTRACT_REJECTED')
    rows, id_map = [], {}
    for item in plan.get('user_requirements', []):
        quote = item['question_quote']
        start, end = _quote_span(question, quote, item.get('occurrence'))
        # Stable within this exact question/version, independent of model row order.
        digest = hashlib.sha256((inventory['question_sha256']+f':{start}:{len(quote)}:'+item['answer_kind']).encode()).hexdigest()[:16]
        rid = 'req-'+digest
        id_map[item['id']] = rid
        rows.append({'requirement_id': rid, 'planner_requirement_id': item['id'],
            'question_quote': quote, 'start': start, 'end': end, 'answer_kind': item['answer_kind'],
            'research_group_ids': list(item['research_group_ids']),
            'report_obligation_ids': list(item['report_obligation_ids']),
            'status': 'planned', 'answer_semantics_verified': False})
    rows.sort(key=lambda r: (r['start'], r['end'], r['answer_kind']))
    for order, row in enumerate(rows, 1):
        row['user_order'] = order
    return {'schema_version': REQUIREMENTS_SCHEMA, 'policy': REQUIREMENTS_POLICY,
        'question_sha256': inventory['question_sha256'], 'question_characters': len(question),
        'planner_schema': plan.get('schema_version'),
        'classification_status': ('explicit_partial' if 'unclassified' in plan.get('segment_dispositions',{}).values() else 'explicit')
            if plan.get('schema_version') in REQUIREMENT_PLAN_SCHEMAS else 'legacy_unclassified',
        'segment_mapping': deepcopy(plan.get('segment_mapping')),
        'requirements': rows, 'segments': [{**s, 'disposition': deepcopy(plan.get('segment_dispositions', {}).get(s['segment_id'], 'unclassified')),
            'requirement_ids': [id_map[k] for k in plan.get('segment_dispositions', {}).get(s['segment_id'], [])]
                if isinstance(plan.get('segment_dispositions', {}).get(s['segment_id']), list) else []}
            for s in inventory['segments']],
        'semantic_auto_approval': False, 'publication_coverage_verified': False}
