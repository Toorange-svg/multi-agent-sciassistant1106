@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
if "%~1"=="" (
  echo 用法：check_literature_sources.cmd "查询词" [来源]
  echo 示例：check_literature_sources.cmd "transformer limitations" all
  pause
  exit /b 2
)
set SOURCE=%~2
if "%SOURCE%"=="" set SOURCE=all
"%~dp0venv\Scripts\python.exe" "%~dp0tools\check_literature_sources.py" --query "%~1" --source "%SOURCE%" --download --parse
set EXIT_CODE=%ERRORLEVEL%
echo.
echo 报告保存在 logs\literature_source_checks\ 下。
pause
exit /b %EXIT_CODE%
