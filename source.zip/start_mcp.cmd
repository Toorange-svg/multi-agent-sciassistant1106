@echo off
setlocal
call "%~dp0bin\windows\start_mcp.cmd" %*
exit /b %errorlevel%
