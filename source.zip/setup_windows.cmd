@echo off
setlocal
chcp 65001 >nul
set PYTHONIOENCODING=utf-8
set PYTHONUTF8=1

cd /d "%~dp0"

echo ==========================================
echo SciAssistant Windows Setup
echo ==========================================
echo.

set SETUP_LOG=%CD%\setup_error.log
if exist "%SETUP_LOG%" del "%SETUP_LOG%" >nul 2>nul

set PYTHON_CMD=
where python >nul 2>nul
if not errorlevel 1 (
  set PYTHON_CMD=python
) else (
  where py >nul 2>nul
  if not errorlevel 1 (
    set PYTHON_CMD=py -3
  )
)

if "%PYTHON_CMD%"=="" (
  echo [ERROR] Python was not found.
  echo Please install Python 3.10+ first, and make sure "Add python.exe to PATH" is enabled.
  echo Download: https://www.python.org/downloads/windows/
  pause
  exit /b 1
)

echo Using Python command: %PYTHON_CMD%
%PYTHON_CMD% --version
if errorlevel 1 (
  echo [ERROR] Python command exists but cannot run.
  pause
  exit /b 1
)

if not exist "venv\Scripts\python.exe" (
  echo [1/4] Creating virtual environment...
  %PYTHON_CMD% -m venv venv 1>>"%SETUP_LOG%" 2>>&1
  if errorlevel 1 (
    echo [ERROR] Failed to create virtual environment.
    echo See details in: %SETUP_LOG%
    echo.
    type "%SETUP_LOG%"
    echo.
    echo Common fixes:
    echo   1. Reinstall Python from python.org and check "Add python.exe to PATH".
    echo   2. Make sure Python version is 3.10 or newer.
    echo   3. If using Microsoft Store Python, install the official python.org version instead.
    pause
    exit /b 1
  )
) else (
  echo [1/4] Virtual environment already exists.
)

echo [2/4] Activating virtual environment...
call "venv\Scripts\activate.bat"
if errorlevel 1 (
  echo [ERROR] Failed to activate virtual environment.
  pause
  exit /b 1
)

echo [3/4] Installing Python dependencies...
python -m pip install --upgrade pip
pip install -r "deepdiver_v2\requirements.txt" 1>>"%SETUP_LOG%" 2>>&1
if errorlevel 1 (
  echo [WARN] Default pip install failed. Retrying with Tsinghua mirror...
  pip install -r "deepdiver_v2\requirements.txt" -i https://pypi.tuna.tsinghua.edu.cn/simple 1>>"%SETUP_LOG%" 2>>&1
  if errorlevel 1 (
    echo [ERROR] Dependency installation failed.
    echo See details in: %SETUP_LOG%
    echo.
    type "%SETUP_LOG%"
    pause
    exit /b 1
  )
)

echo [4/4] Checking local configuration files...
if not exist ".env" (
  if exist ".env.example" (
    copy ".env.example" ".env" >nul
    echo Created .env from .env.example. Please fill API keys before running.
  ) else (
    echo [WARN] .env is missing and .env.example was not found.
  )
) else (
  echo Found .env.
)

if not exist "deepdiver_v2\config\.env" (
  if exist "deepdiver_v2\env.template" (
    copy "deepdiver_v2\env.template" "deepdiver_v2\config\.env" >nul
    echo Created deepdiver_v2\config\.env from env.template. Please fill API keys before running.
  ) else (
    echo [WARN] deepdiver_v2\config\.env is missing and env.template was not found.
  )
) else (
  echo Found deepdiver_v2\config\.env.
)

where tesseract >nul 2>nul
if not errorlevel 1 (
  echo Found Tesseract OCR on PATH.
) else if exist "C:\Program Files\Tesseract-OCR\tesseract.exe" (
  echo Found Tesseract OCR in the default install directory.
) else (
  echo [OPTIONAL] Tesseract OCR was not found.
  echo            Install it for scanned-PDF OCR fallback and table OCR cross-checking.
)

echo.
echo ==========================================
echo Setup completed.
echo Start the research web UI with:
echo   powershell -ExecutionPolicy Bypass -File start_sciassistant.ps1
echo Then open:
echo   http://127.0.0.1:5050/
echo.
echo Optional system dependency: install Tesseract OCR for scanned-PDF OCR
echo fallback and table OCR cross-checking. The web UI still works without it.
echo ==========================================
echo.
pause
endlocal
