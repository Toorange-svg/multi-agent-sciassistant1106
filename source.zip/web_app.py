"""Basic single-user web UI for SciAssistant PDF analysis."""

from __future__ import annotations

import io
import ipaddress
import os
import re
import json
import sys
import subprocess
import threading
import time
import uuid
import requests
from collections import deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from flask import Flask, g, jsonify, request, send_file, send_from_directory
from werkzeug.utils import secure_filename
from process_cleanup import terminate_process_tree
from runtime_identity import RuntimeIdentity
from request_observability import install_request_observability
from storage_guard import configured_min_free_bytes, has_minimum_free_space
from multi_agent_workflow import WorkflowStore
import multi_agent_web as rag_web

_RESEARCH_RUNTIME = RuntimeIdentity("research_web")
from research_runtime import (
    ResearchDependencyError, MCP_UNAVAILABLE_MESSAGE, research_command,
    research_environment, requires_shared_mcp, check_shared_mcp,
)

PROJECT_ROOT = Path(__file__).resolve().parent
DEEPDIVER_ROOT = PROJECT_ROOT / "deepdiver_v2"
if str(DEEPDIVER_ROOT) not in sys.path:
    sys.path.insert(0, str(DEEPDIVER_ROOT))

from pdf_pipeline import build_parse_metadata, build_risk_summary, parse_pdf
from deepdiver_v2.config.config import get_config, temporary_pdf_parse_mode
from deepdiver_v2.src.tools.mcp_tools import (
    run_llama_full_pdf_enhancement,
    run_llama_vision_enhancement,
)
from deepdiver_v2.src.tools.llama_evidence_fusion import build_hybrid_evidence_ledger
from deepdiver_v2.src.clarification_gate import (
    apply_clarification_choice,
    build_clarification_request,
    build_dynamic_clarification_request,
)
from deepdiver_v2.src.query_router import route_query
from deepdiver_v2.src.query_intent import analyze_query_intent, intent_instruction, request_route
from deepdiver_v2.src.evidence_blocks import (
    build_evidence_blocks,
    select_evidence_blocks,
    format_evidence_blocks,
)
from deepdiver_v2.src.answer_contract import (
    build_answer_contract,
    answer_contract_instruction,
    validate_answer_structure,
)
from deepdiver_v2.src.model_key_pool import configured_model_tokens, post_model_request
from user_credentials import ProviderCapability, provider_scope, provider_value, current_capability, child_environment, scoped_storage
from deepdiver_v2.src.report_export import export_report_files
from evidence_fallback import should_use_general_fallback, wrap_general_fallback

ROOT = PROJECT_ROOT
WEB_DIR = ROOT / "web"
UPLOAD_DIR = ROOT / "web_uploads"
LOG_DIR = ROOT / "logs"
ARXIV_DIR = ROOT / "arxiv"
CONFIG_ENV_PATH = DEEPDIVER_ROOT / "config" / ".env"
UPLOAD_DIR.mkdir(exist_ok=True)
LOG_DIR.mkdir(exist_ok=True)
ARXIV_DIR.mkdir(exist_ok=True)
# The child CLI inherits this absolute path.  Do not rely on its working
# directory when the gateway and research process exchange workflow progress.
os.environ.setdefault("SCIASSISTANT_MULTI_AGENT_STATE_PATH", str(LOG_DIR / "multi_agent_workflow.sqlite3"))

app = Flask(__name__, static_folder=str(WEB_DIR), static_url_path="/static")
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024
install_request_observability(app, app.logger, "research_web")


@app.after_request
def _research_browser_security_headers(response):
    """Apply safe baseline headers to direct 5050 and in-process responses."""
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "no-referrer")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    response.headers.setdefault("Cross-Origin-Opener-Policy", "same-origin")
    response.headers.setdefault("Cross-Origin-Resource-Policy", "same-origin")
    if request.path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store"
    return response

TASKS: dict[str, dict] = {}
TASK_LOCK = threading.Lock()
TASK_STATE_DIR = Path(os.getenv("SCIASSISTANT_TASK_STATE_DIR", str(LOG_DIR / "task_state")))
TASK_STATE_DIR.mkdir(parents=True, exist_ok=True)
RUNTIME_STORAGE_MIN_FREE_BYTES = configured_min_free_bytes()


def _positive_int_env(name: str, default: int) -> int:
    try:
        return max(1, int(os.getenv(name, str(default))))
    except (TypeError, ValueError):
        return default


def _configured_task_worker_count() -> int:
    """Reject worker settings that would split the in-process task queue."""
    source = "SCIASSISTANT_TASK_WORKERS"
    raw_value = os.getenv(source)
    if raw_value is None:
        source = "WEB_CONCURRENCY"
        raw_value = os.getenv(source, "1")
    try:
        worker_count = int(str(raw_value).strip())
    except (TypeError, ValueError) as exc:
        raise RuntimeError(f"{source} 必须是正整数") from exc
    if worker_count != 1:
        raise RuntimeError(
            f"{source}={worker_count} 不受支持：科研任务队列目前只能由一个进程执行。"
            "请设为 1，或先迁移到外部队列/数据库后再启用多 worker。"
        )
    return worker_count


TASK_EXECUTION_WORKER_COUNT = _configured_task_worker_count()
RETRIEVAL_MAX_CONCURRENT = _positive_int_env("WEB_RETRIEVAL_MAX_CONCURRENT", 8)
MAX_QUERY_LENGTH = _positive_int_env("WEB_MAX_QUERY_LENGTH", 20_000)
_RETRIEVAL_QUEUE: deque[dict] = deque()
_RETRIEVAL_ACTIVE: set[str] = set()
_RETRIEVAL_PROCESSES: dict[str, object] = {}
_TASK_CREDENTIALS: dict[str, ProviderCapability] = {}  # private, never TASKS/snapshots/artifacts
# RAG storage is namespaced per account by ``child_environment``. Keep a
# bounded semaphore per account so up to three jobs from one account can use
# task-specific index namespaces concurrently while the global queue still
# limits total pressure.
# The legacy single lock name remains as an unused compatibility symbol for
# older diagnostics; new workers use ``_rag_lock_for_task`` below.
_MULTI_AGENT_RAG_LOCK = threading.Lock()
RAG_PER_ACCOUNT_CONCURRENCY = 3
_MULTI_AGENT_RAG_LOCKS: dict[str, threading.BoundedSemaphore] = {}
_MULTI_AGENT_RAG_LOCKS_GUARD = threading.Lock()
ARXIV_RE = re.compile(r"(?:arxiv:|arxiv\.org/(?:abs|pdf)/)([0-9]{4}\.[0-9]{4,5}(?:v\d+)?)", re.I)


def _build_followup_context(parent_task_id: str, conversation_id: str) -> dict:
    """Build bounded context while keeping old evidence subject to re-checking."""
    if not parent_task_id:
        return {"status": "none", "reason": "no_parent_task"}
    with TASK_LOCK:
        parent = dict(TASKS.get(parent_task_id) or {})
    if not parent:
        snapshot_path = LOG_DIR / f"web_task_{parent_task_id}.followup.json"
        try:
            if snapshot_path.is_file():
                parent = json.loads(snapshot_path.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError):
            parent = {}
    if not parent:
        return {"status": "rejected", "reason": "parent_task_not_found", "parent_task_id": parent_task_id}
    if conversation_id and parent.get("conversation_id") and parent.get("conversation_id") != conversation_id:
        return {"status": "rejected", "reason": "conversation_mismatch", "parent_task_id": parent_task_id}
    answer = str(parent.get("answer") or "").strip()
    if not answer:
        answer = str((parent.get("sections") or {}).get("report") or "").strip()
    stored_ids = parent.get("paper_ids")
    ids = [str(item).strip() for item in stored_ids or [] if str(item).strip()]
    if not ids:
        ids = sorted(set(re.findall(r"\b\d{4}\.\d{4,5}(?:v\d+)?\b", answer)))
    return {
        "status": "ready",
        "parent_task_id": parent_task_id,
        "conversation_id": conversation_id or parent.get("conversation_id"),
        "previous_query": str(parent.get("query") or "")[:1200],
        "previous_intent": parent.get("query_intent") or {},
        "previous_answer": answer[:12000],
        "paper_ids": ids[:30],
        "evidence_policy": "旧回答仅作上下文；本轮必须重新确认论文和证据",
    }

API_KEY_FIELDS = {
    "MODEL_REQUEST_URL": {
        "label": "回答模型接口地址", "secret": False, "required": True,
        "description": "OpenAI 兼容的 chat/completions 地址；用于生成所有分析报告。",
    },
    "MODEL_REQUEST_TOKEN": {
        "label": "回答模型 API Key", "secret": True, "required": True,
        "description": "用于生成报告和回答；未配置时无法完成最终回答。",
    },
    "MODEL_REQUEST_TOKENS": {
        "label": "回答模型备用 API Keys", "secret": True, "required": False,
        "description": "可选的多个备用 Key，用英文逗号、分号或换行分隔；遇到认证、额度或限流时自动轮换。",
    },
    "MODEL_NAME": {
        "label": "回答模型名称", "secret": False, "required": True,
        "description": "例如服务商提供的模型 ID。",
    },
    "LLAMA_CLOUD_API_KEY": {
        "label": "LlamaCloud / LlamaParse API Key", "secret": True, "required": False,
        "description": "仅“整篇 Llama”和“混合增强”PDF 模式需要。",
    },
    "MCP_AUTH_TOKEN": {
        "label": "MCP 服务访问令牌", "secret": True, "required": False,
        "description": "仅当本机 MCP 服务配置了鉴权时需要。",
    },
    "SEARCH_ENGINE_API_KEYS": {
        "label": "搜索服务 API Key", "secret": True, "required": False,
        "description": "仅当配置了第三方搜索服务时需要；多个 Key 用英文逗号分隔。",
    },
    "URL_CRAWLER_API_KEYS": {
        "label": "网页抓取服务 API Key", "secret": True, "required": False,
        "description": "仅当配置了第三方网页抓取服务时需要；多个 Key 用英文逗号分隔。",
    },
}
WEB_API_KEY_FIELDS = ("MODEL_REQUEST_TOKEN", "MODEL_REQUEST_TOKENS", "LLAMA_CLOUD_API_KEY")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _task_state_path(task_id: str) -> Path:
    """Return the per-task restart snapshot path after rejecting unsafe IDs."""
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", str(task_id or "")):
        raise ValueError("invalid task id")
    return TASK_STATE_DIR / f"{task_id}.json"


def _safe_task_snapshot(task: dict) -> dict:
    """Serialize a bounded task snapshot without retaining credential-shaped text."""
    normalized = json.loads(json.dumps(task, ensure_ascii=False, default=str))

    def redact(value, key: str = ""):
        if re.search(r"(?i)(authorization|api[_ -]?key|token|secret|password)", key):
            return "[REDACTED]"
        if isinstance(value, dict):
            return {str(name): redact(item, str(name)) for name, item in value.items()}
        if isinstance(value, list):
            return [redact(item) for item in value]
        if isinstance(value, str):
            return _redact_technical_log(value, 180_000)
        return value

    return redact(normalized)


def _persist_task_locked(task: dict) -> None:
    """Atomically persist one task while the caller holds ``TASK_LOCK``."""
    task_id = str(task.get("id") or "")
    try:
        path = _task_state_path(task_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(".tmp")
        temporary.write_text(
            json.dumps(_safe_task_snapshot(task), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        os.replace(temporary, path)
    except (OSError, TypeError, ValueError):
        # A persistence failure must not take down an active research worker.
        return


def _restore_persisted_tasks() -> int:
    """Reload task snapshots; mark work interrupted by a prior restart failed."""
    restored = 0
    try:
        snapshots = list(TASK_STATE_DIR.glob("*.json"))
    except OSError:
        return restored
    with TASK_LOCK:
        for path in snapshots:
            try:
                task = json.loads(path.read_text(encoding="utf-8"))
                task_id = str(task.get("id") or "")
                if path != _task_state_path(task_id):
                    continue
            except (OSError, TypeError, ValueError, json.JSONDecodeError):
                continue
            if task.get("status") in {"queued", "running", "searching"}:
                if task.get("processing_mode") == rag_web.MODE:
                    try:
                        rag_web.sync_terminal(task_id, "failed", "SERVICE_RESTARTED")
                    except Exception:
                        pass
                previous_status = task.get("status")
                timestamp = _now()
                task.update({
                    "status": "failed",
                    "message": "服务重启导致任务中断，请重新提交",
                    "interrupted_by_restart": True,
                    "updated_at": timestamp,
                })
                task.setdefault("state_timeline", []).append({
                    "timestamp": timestamp,
                    "from": previous_status,
                    "to": "failed",
                    "message": "服务重启导致任务中断，请重新提交",
                })
            TASKS[task_id] = task
            _persist_task_locked(task)
            restored += 1
    return restored


def _api_key_settings() -> list[dict]:
    """Return field metadata without ever exposing credential values."""
    result = []
    for name in WEB_API_KEY_FIELDS:
        definition = API_KEY_FIELDS[name]
        value = provider_value(name)
        result.append({"name": name, **definition, "configured": bool(str(value).strip())})
    return result


def _persist_api_key_settings(values: dict) -> None:
    """Persist supported settings to the project config file and current process."""
    if not isinstance(values, dict):
        raise ValueError("配置内容必须是对象")
    normalized = {}
    for name in API_KEY_FIELDS:
        if name not in values:
            continue
        value = values[name]
        if not isinstance(value, str):
            raise ValueError(f"{name} 必须是文本")
        if len(value) > 8192 or "\n" in value or "\r" in value:
            raise ValueError(f"{name} 格式无效")
        normalized[name] = value.strip()
    url = normalized.get("MODEL_REQUEST_URL")
    if url and not re.match(r"^https?://", url, re.I):
        raise ValueError("回答模型接口地址必须以 http:// 或 https:// 开头")

    existing = CONFIG_ENV_PATH.read_text(encoding="utf-8", errors="replace") if CONFIG_ENV_PATH.is_file() else ""
    lines = existing.splitlines()
    found = set()
    for index, line in enumerate(lines):
        match = re.match(r"^(\s*)([A-Z][A-Z0-9_]*)(\s*=).*$", line)
        if match and match.group(2) in normalized:
            name = match.group(2)
            lines[index] = f"{match.group(1)}{name}{match.group(3)}{json.dumps(normalized[name], ensure_ascii=False)}"
            found.add(name)
    for name, value in normalized.items():
        if name not in found:
            lines.append(f"{name}={json.dumps(value, ensure_ascii=False)}")
        os.environ[name] = value
    CONFIG_ENV_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_ENV_PATH.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")
    try:
        os.chmod(CONFIG_ENV_PATH, 0o600)
    except OSError:
        pass


def _missing_task_configuration(pdf_parse_mode: str) -> list[str]:
    missing = [name for name in ("MODEL_REQUEST_URL", "MODEL_NAME") if not os.getenv(name, "").strip()]
    if not configured_model_tokens():
        missing.append("MODEL_REQUEST_TOKEN")
    if pdf_parse_mode in {"llama_full", "hybrid"} and not provider_value("LLAMA_CLOUD_API_KEY").strip():
        missing.append("LLAMA_CLOUD_API_KEY")
    return missing


def _describe_task_mode(
    query: str,
    has_upload: bool,
    pdf_parse_mode: str,
    requested_mode: str | None = None,
) -> dict:
    """Provide stable user-facing task names, honoring an explicit Web choice."""
    if has_upload:
        if requested_mode == rag_web.MODE:
            return {"id": "multi_agent_pdf", "label": "多智能体 PDF 分析", "report_title": "多智能体 PDF 科研报告"}
        if pdf_parse_mode == "local":
            return {"id": "pdf_local", "label": "本地 PDF 解析", "report_title": "本地 PDF 解析报告"}
        return {"id": "pdf_cloud", "label": "云端增强 PDF 解析", "report_title": "增强 PDF 解析报告"}
    explicit_modes = {
        "arxiv_paper": {"id": "arxiv_paper", "label": "arXiv 论文检索与解析", "report_title": "arXiv 论文解析报告"},
        "literature_answer": {"id": "literature_answer", "label": "文献依据科研问答", "report_title": "文献依据回答"},
        "multi_agent_literature": {"id": "multi_agent_literature", "label": "多 Agent 文献协作问答", "report_title": "多 Agent 文献协作回答"},
        "multi_agent_rag": {"id": "multi_agent_rag", "label": "多智能体科研 RAG", "report_title": "多智能体科研 RAG 报告"},
        "general_answer": {"id": "general_answer", "label": "通用科研问答", "report_title": "科研问答"},
    }
    if requested_mode in explicit_modes:
        return explicit_modes[requested_mode]
    route = route_query(query).get("route", "direct_llm")
    if route == "paper_evidence":
        return {"id": "arxiv_paper", "label": "arXiv 论文检索与解析", "report_title": "arXiv 论文解析报告"}
    if route == "science_literature":
        return {"id": "literature_answer", "label": "文献依据科研问答", "report_title": "文献依据回答"}
    if route == "blocked":
        return {"id": "blocked", "label": "不支持的请求", "report_title": "处理说明"}
    return {"id": "general_answer", "label": "通用科研问答", "report_title": "科研问答"}


# Source-level retrieval refusals. literature_sources.py reports a blocked
# source with this exact vocabulary (its own wording, not a provider's), and
# the transcript carries it in per-round diagnostics. A blocked literature
# source says nothing about the answer model's credentials, so these lines
# must never enter the credential scan.
_SOURCE_ERROR_LINE_MARKERS = (
    '"search_error"',
    "consecutive access blocks",
    "access_blocked",
    "http 401/403/406/451",
)
_SOURCE_ERROR_LINE_MARKERS_LOWER = tuple(marker.lower() for marker in _SOURCE_ERROR_LINE_MARKERS)


def _strip_source_error_lines(text: str) -> str:
    """Drop per-source retrieval diagnostic lines from a transcript.

    Matching is case-insensitive: the same wording also appears in the
    report's own 检索来源说明 note, which is a transparent disclosure of a
    blocked source, equally silent about the answer model's credentials.
    """
    return "\n".join(
        line for line in str(text or "").splitlines()
        if not any(marker in line.lower() for marker in _SOURCE_ERROR_LINE_MARKERS_LOWER)
    )


def _credential_error_hint(text: str, default_key: str = "MODEL_REQUEST_TOKEN") -> str | None:
    """Turn provider auth errors into a precise, non-secret configuration hint.

    The scan covers the whole run_demo transcript, so source-level refusals
    (a techrxiv 403, an arXiv throttle) must be excluded first: they used to
    make every task containing one blocked source fail with a fake
    "认证失败" hint even when the answer model worked perfectly.
    """
    normalized = _strip_source_error_lines(text).lower()
    if not normalized:
        return None
    if "llama_cloud_api_key" in normalized or "llamaparse" in normalized or "llama cloud" in normalized:
        key = "LLAMA_CLOUD_API_KEY"
    elif "search_engine_api_keys" in normalized or "search api key" in normalized:
        key = "SEARCH_ENGINE_API_KEYS"
    elif "url_crawler_api_keys" in normalized or "crawler api key" in normalized:
        key = "URL_CRAWLER_API_KEYS"
    elif ("http 401" in normalized or "http 403" in normalized or "unauthorized" in normalized
          or "forbidden" in normalized or "invalid api key" in normalized or "authentication" in normalized):
        key = default_key
    elif "not configured" in normalized and default_key.lower() in normalized:
        key = default_key
    else:
        return None
    label = API_KEY_FIELDS.get(key, {}).get("label", key)
    return f"认证失败：请检查“{label}”（{key}）是否填写正确、未过期且有可用额度。"


# Text the demo prints as the final answer when the answer model itself is
# unavailable after retries. Such a fallback sentence is not an analysis.
_FALLBACK_ANSWER_MARKERS = (
    "回答模型暂时不可用",
)


def _has_usable_answer(answer: str) -> bool:
    """Report whether the transcript yielded a real analysis, not a fallback."""
    value = str(answer or "").strip()
    if not value:
        return False
    return not any(marker in value for marker in _FALLBACK_ANSWER_MARKERS)


def _task_failed_verdict(returncode: int, output: str, answer: str, credential_hint: str | None) -> bool:
    """Decide a web task's failure from its transcript artifacts alone.

    A model-credential hint fails the task only when no trustworthy answer was
    produced: run_demo may keep a zero exit code after rendering an internal
    AgentResponse failure, but a hint next to a real, complete answer means
    the answer model demonstrably worked — the hint then describes some other
    layer (typically a blocked literature source) and must not turn a finished
    analysis into a failed one.
    """
    failed_in_demo = bool(re.search(r"Final Status:\s*(?:❌\s*)?Failed", str(output or ""), re.IGNORECASE))
    credential_failure = (
        bool(credential_hint) and "MODEL_REQUEST_TOKEN" in credential_hint
        and not _has_usable_answer(answer)
    )
    return returncode != 0 or failed_in_demo or credential_failure


_MULTI_AGENT_STAGE_MESSAGES = {
    "created": "多 Agent 协作：正在准备任务",
    "planned": "多 Agent 协作：已完成问题规划，正在分组检索",
    "retrieving": "多 Agent 协作：正在分组检索文献",
    "reviewing": "多 Agent 协作：正在审查证据覆盖范围",
    "writing": "多 Agent 协作：正在依据已审查证据写作",
    "auditing": "多 Agent 协作：正在核验引用映射",
    "completed": "多 Agent 协作：引用核验完成",
    "partial": "多 Agent 协作：已生成带证据边界的有限回答",
    "needs_review": "多 Agent 协作：结果需要人工复核",
    "failed": "多 Agent 协作：未获得足够可审查证据",
    "timed_out": "多 Agent 协作：已在时间预算边界停止",
    "cancelled": "多 Agent 协作：任务已取消",
}


def _multi_agent_workflow_summary(task_id: str) -> dict | None:
    """Read only the browser-safe workflow projection from the independent store."""
    try:
        store = WorkflowStore(os.environ.get("SCIASSISTANT_MULTI_AGENT_STATE_PATH"))
        run = store.get_run(task_id)
        stages = store.list_stages(task_id)
    except Exception:
        return None
    summary = {
        "workflow_status": str(run.get("status") or "unknown"),
        "failure_code": str(run.get("failure_code") or ""),
        "model_calls": int(run.get("model_calls_used") or 0),
        "model_call_limit": int(run.get("max_model_calls") or 10),
        "stages": [str(stage.get("stage") or "") for stage in stages if stage.get("stage") != "model_call"][-8:],
    }
    # Artifacts remain in the independent workflow store.  Project only the
    # small, user-safe coverage result needed by the status API/evidence pack;
    # never expose prompts, provider responses, excerpts, or hidden reasoning.
    try:
        reviews = [item.get("payload") or {} for item in store.list_artifacts(task_id)
                   if item.get("artifact_type") == "evidence_review"]
        review = reviews[-1] if reviews else {}
        if isinstance(review, dict):
            summary["evidence_review"] = {
                "coverage_status": str(review.get("coverage_status") or "unknown"),
                "unsupported_questions": [str(item)[:1000] for item in review.get("unsupported_questions", [])
                                          if isinstance(item, str)][:10],
            }
    except Exception:
        pass
    return summary


def _sync_multi_agent_terminal(task_id: str, status: str, failure_code: str) -> None:
    """Keep the independent workflow state aligned with an outer task stop."""
    try:
        WorkflowStore(os.environ.get("SCIASSISTANT_MULTI_AGENT_STATE_PATH")).force_terminal(
            task_id, status, failure_code=failure_code, details={"source": "web_task_boundary"},
        )
    except Exception:
        pass


def _update(task_id: str, **values) -> None:
    with TASK_LOCK:
        if task_id in TASKS:
            # Cancellation is a user-visible terminal decision.  A worker can
            # fail while its network call or subprocess is unwinding after the
            # cancel endpoint has already won the race; do not let that late
            # exception relabel the task as failed or completed.
            if (TASKS[task_id].get("status") == "cancelled"
                    and values.get("status") != "cancelled"):
                return
            previous_status = TASKS[task_id].get("status")
            next_status = values.get("status")
            if next_status and next_status != previous_status:
                TASKS[task_id].setdefault("state_timeline", []).append({
                    "timestamp": _now(),
                    "from": previous_status,
                    "to": next_status,
                    "message": _redact_technical_log(str(values.get("message") or ""), 500),
                })
                app.logger.info(
                    "task_transition task_id=%s from_status=%s to_status=%s failure_stage=%s",
                    task_id,
                    previous_status,
                    next_status,
                    str(values.get("failure_stage") or "none"),
                )
            TASKS[task_id].update(values, updated_at=_now())
            if TASKS[task_id].get('status') in rag_web.TERMINAL_STATUSES:
                _TASK_CREDENTIALS.pop(task_id, None)
            started = TASKS[task_id].get("started_at") or TASKS[task_id].get("created_at")
            if started:
                try:
                    started_dt = datetime.fromisoformat(started.replace("Z", "+00:00"))
                    TASKS[task_id]["elapsed_seconds"] = round((datetime.now(timezone.utc) - started_dt).total_seconds(), 1)
                except (TypeError, ValueError):
                    pass
            _persist_task_locked(TASKS[task_id])


def _user_facing_model_error(exc: Exception) -> str:
    """Map provider/network failures to stable messages without leaking URLs or credentials."""
    if isinstance(exc, requests.Timeout):
        return "回应失败：模型服务请求超时，请稍后重试"
    if isinstance(exc, requests.ConnectionError):
        return "回应失败：网络连接异常，暂时无法访问模型服务，请稍后重试"
    if isinstance(exc, requests.HTTPError):
        status = exc.response.status_code if exc.response is not None else None
        if status in {401, 403}:
            return "回应失败：模型服务认证失败，请检查 API Key 配置"
        if status == 402:
            return "回应失败：模型服务额度不足，请检查账户余额"
        if status == 429:
            return "回应失败：模型服务请求过于频繁，请稍后重试"
        if status and status >= 500:
            return "回应失败：模型服务暂时不可用，请稍后重试"
        if status:
            return f"回应失败：模型服务返回 HTTP {status}"
    return "回应失败：模型服务发生未知错误，请稍后重试"


def _safe_api_failure(operation: str, exc: Exception, *, status: int = 500, code: str = "INTERNAL_ERROR"):
    """Return a stable API error without exposing exception or path text."""
    app.logger.error(
        "Research API operation failed: operation=%s error_type=%s",
        operation,
        type(exc).__name__,
    )
    message = "请求配置无效，请检查后重试。" if status == 400 else "服务暂时无法完成请求，请稍后重试。"
    return jsonify({"error": code, "message": message}), status


def _is_task_cancel_requested(task_id: str) -> bool:
    with TASK_LOCK:
        task = TASKS.get(task_id) or {}
        return bool(task.get("cancel_requested")) or task.get("status") == "cancelled"


def _cancel_task(task_id: str) -> tuple[dict | None, str | None]:
    """Mark a task cancelled and remove it from the not-yet-started queue."""
    process_to_stop = None
    with TASK_LOCK:
        task = TASKS.get(task_id)
        if not task:
            return None, "任务不存在"
        if task.get("status") in rag_web.TERMINAL_STATUSES:
            return dict(task), None
        cancelled_at = _now()
        previous_status = task.get("status")
        cancellation = {
            "requested_at": cancelled_at,
            "process_registered_at_request": bool(_RETRIEVAL_PROCESSES.get(task_id)),
            "termination_requested": bool(_RETRIEVAL_PROCESSES.get(task_id)),
        }
        task.update(
            status="cancelled",
            cancel_requested=True,
            message="已取消任务",
            cancelled_at=cancelled_at,
            cancellation=cancellation,
            updated_at=cancelled_at,
        )
        _TASK_CREDENTIALS.pop(task_id, None)
        if previous_status != "cancelled":
            task.setdefault("state_timeline", []).append({
                "timestamp": cancelled_at,
                "from": previous_status,
                "to": "cancelled",
                "message": "已取消任务",
            })
        _RETRIEVAL_QUEUE_copy = [job for job in _RETRIEVAL_QUEUE if job["task_id"] != task_id]
        _RETRIEVAL_QUEUE.clear()
        _RETRIEVAL_QUEUE.extend(_RETRIEVAL_QUEUE_copy)
        _refresh_retrieval_queue_locked()
        process_to_stop = _RETRIEVAL_PROCESSES.get(task_id)
        _persist_task_locked(task)
        snapshot = dict(task)
    if process_to_stop is not None:
        _stop_task_process(task_id, process_to_stop, "cancel_requested")
        with TASK_LOCK:
            current = TASKS.get(task_id)
            if current and current.get("status") == "cancelled":
                current.setdefault("cancellation", {})["termination_requested_at"] = _now()
                _persist_task_locked(current)
                snapshot = dict(current)
    if snapshot.get("processing_mode") == rag_web.MODE:
        try:
            rag_web.sync_terminal(task_id, "cancelled", "USER_CANCELLED")
        except Exception:
            pass
    return snapshot, None


def _terminate_subprocess_tree(process) -> dict:
    return terminate_process_tree(process)


def _spawn_research_process(command: list, stream):
    environment = child_environment(research_environment())
    if requires_shared_mcp(command[3:]):
        check_shared_mcp(environment)
    spawn_options = {"start_new_session": True} if os.name != "nt" else {}
    process = subprocess.Popen(command, cwd=ROOT, env=environment,
                               stdout=stream, stderr=subprocess.STDOUT, **spawn_options)
    if os.name != "nt":
        process._sciassistant_process_group = process.pid
    return process


def _stop_task_process(task_id: str, process, reason: str) -> dict:
    requested_at = _now()
    result = _terminate_subprocess_tree(process)
    with TASK_LOCK:
        task = TASKS.get(task_id)
        if task:
            task.setdefault("execution", {}).update({
                "process_termination_requested": True,
                "process_cleanup": {**result, "reason": reason,
                                    "requested_at": requested_at, "finished_at": _now()},
            })
            _persist_task_locked(task)
    return result


def _refresh_retrieval_queue_locked() -> None:
    """Refresh user-facing queue positions while TASK_LOCK is held."""
    active_count = len(_RETRIEVAL_ACTIVE)
    for index, job in enumerate(_RETRIEVAL_QUEUE):
        task = TASKS.get(job["task_id"])
        if not task:
            continue
        ahead = active_count + index
        task.update(
            status="queued",
            queue_ahead=ahead,
            queue_position=ahead + 1,
            queue_limit=RETRIEVAL_MAX_CONCURRENT,
            message=f"检索任务已排队，前面还有 {ahead} 个任务（并发上限 {RETRIEVAL_MAX_CONCURRENT}）",
            updated_at=_now(),
        )
        _persist_task_locked(task)


def _worker_provider_capability(task_id: str):
    # Cancellation may release the captured keys before a queued thread starts.
    # Losing an account capability must never turn that worker into admin mode.
    with TASK_LOCK:
        task = TASKS.get(task_id) or {}
        cap = _TASK_CREDENTIALS.get(task_id)
        if task.get('user_id') and (cap is None or cap.owner != str(task['user_id'])):
            raise ValueError('TASK_PROVIDER_SCOPE_UNAVAILABLE')
        return cap


def _execute_retrieval_job(task_id: str, worker: Callable, args: tuple, kwargs: dict) -> None:
    try:
        with provider_scope(_worker_provider_capability(task_id)):
            worker(*args, **kwargs)
    except Exception as exc:  # noqa: BLE001 - keep a failed worker from leaking a queue slot
        _fail_task_safely(task_id, "retrieval_worker", "检索任务未能启动，请稍后重试")
    finally:
        with TASK_LOCK:
            _RETRIEVAL_ACTIVE.discard(task_id)
            if (TASKS.get(task_id) or {}).get('status') in rag_web.TERMINAL_STATUSES:
                _TASK_CREDENTIALS.pop(task_id, None)
        _drain_retrieval_queue()


def _drain_retrieval_queue() -> None:
    """Start queued retrieval jobs in FIFO order up to the configured limit."""
    launches: list[tuple[str, threading.Thread]] = []
    with TASK_LOCK:
        while _RETRIEVAL_QUEUE and len(_RETRIEVAL_ACTIVE) < RETRIEVAL_MAX_CONCURRENT:
            job = _RETRIEVAL_QUEUE.popleft()
            task_id = job["task_id"]
            task = TASKS.get(task_id)
            if not task or task.get("status") in rag_web.TERMINAL_STATUSES:
                _TASK_CREDENTIALS.pop(task_id, None)
                continue
            _RETRIEVAL_ACTIVE.add(task_id)
            task.update(
                queue_ahead=None,
                queue_position=None,
                queue_limit=RETRIEVAL_MAX_CONCURRENT,
                message="已获得检索处理名额，正在启动",
                updated_at=_now(),
            )
            _persist_task_locked(task)
            launches.append((task_id, threading.Thread(
                target=_execute_retrieval_job,
                args=(task_id, job["worker"], job["args"], job["kwargs"]),
                daemon=True,
            )))
        _refresh_retrieval_queue_locked()
    launch_failed = False
    for task_id, thread in launches:
        try:
            thread.start()
        except Exception:  # noqa: BLE001 - a failed Thread.start must not strand a queued task
            launch_failed = True
            with TASK_LOCK:
                _RETRIEVAL_ACTIVE.discard(task_id)
            _fail_task_safely(task_id, "retrieval_thread", "检索任务未能启动，请稍后重试")
    # A failed thread must immediately release its slot so the following FIFO
    # job is not left queued behind work that can never begin.
    if launch_failed:
        _drain_retrieval_queue()


def _enqueue_retrieval_task(task_id: str, worker: Callable, *args, **kwargs) -> None:
    """Queue one arXiv/research job without exceeding the global safe concurrency."""
    with TASK_LOCK:
        if task_id in _RETRIEVAL_ACTIVE or any(job["task_id"] == task_id for job in _RETRIEVAL_QUEUE):
            return
        _RETRIEVAL_QUEUE.append({
            "task_id": task_id,
            "worker": worker,
            "args": args,
            "kwargs": kwargs,
        })
        task = TASKS.get(task_id)
        if task:
            task.update(status="queued", queued_at=_now(), updated_at=_now())
            _persist_task_locked(task)
        _refresh_retrieval_queue_locked()
    _drain_retrieval_queue()


def _fail_task_safely(task_id: str, stage: str, message: str, *, returncode: int = -1) -> None:
    """Publish a terminal, non-secret failure instead of leaving a ghost task.

    Startup exceptions can contain absolute paths, provider URLs or credentials.
    The user-facing task and downloadable evidence keep only a stable stage
    label and safe message; detailed diagnostics remain server-side.
    """
    with TASK_LOCK:
        execution = dict((TASKS.get(task_id) or {}).get("execution") or {})
    execution.update(failure_stage=stage, failure_recorded_at=_now())
    _update(
        task_id,
        status="failed",
        message=message,
        answer=f"## 任务未能完成\n\n{message}",
        sections={"report": f"## 任务未能完成\n\n{message}"},
        execution=execution,
        returncode=returncode,
    )


def _execute_background_task(task_id: str, worker: Callable, args: tuple, stage: str) -> None:
    """Give non-retrieval workers the same terminal-failure guarantee."""
    try:
        with provider_scope(_worker_provider_capability(task_id)):
            worker(*args)
    except Exception:  # noqa: BLE001 - background exceptions must be observable
        _fail_task_safely(task_id, stage, "任务执行异常，请稍后重试")
    finally:
        with TASK_LOCK:
            if (TASKS.get(task_id) or {}).get('status') in rag_web.TERMINAL_STATUSES:
                _TASK_CREDENTIALS.pop(task_id, None)


def _start_background_task(task_id: str, worker: Callable, *args, stage: str) -> bool:
    """Start one background worker or synchronously publish a failed task."""
    try:
        thread = threading.Thread(
            target=_execute_background_task,
            args=(task_id, worker, args, stage),
            daemon=True,
        )
        thread.start()
        return True
    except Exception:  # noqa: BLE001 - Thread.start can fail under resource pressure
        _fail_task_safely(task_id, f"{stage}_thread", "任务未能启动，请稍后重试")
        return False


_LOG_SECRET_PATTERNS = (
    # JSON/object-style credentials: keep the key and JSON delimiters so the
    # exported diagnostic artifact remains structurally readable.
    (re.compile(
        r"(?i)((?:\"|')?(?:authorization|api[_ -]?key|token|secret|password)(?:\"|')?\s*:\s*(?:\"|'))"
        r"(?:bearer\s+)?[^\"']*(\"|')"
    ), lambda match: f"{match.group(1)}[REDACTED]{match.group(2)}"),
    # Header and key=value-style credentials. Consume the complete bearer
    # token instead of stopping after the word ``Bearer``.
    (re.compile(
        r"(?i)(authorization|api[_ -]?key|token|secret|password)\s*[:=]\s*"
        r"(?:[\"']\s*)?(?:bearer\s+)?[^\s,;\"'}]+"
    ), lambda match: f"{match.group(1)}: [REDACTED]"),
    (re.compile(r"(?i)bearer\s+[a-z0-9._-]+"), lambda match: "Bearer [REDACTED]"),
)


def _redact_technical_log(value: str, limit: int = 180_000) -> str:
    """Return a bounded transcript suitable for an advanced diagnostics panel."""
    text = str(value or "")[:limit]
    for pattern, replacement in _LOG_SECRET_PATTERNS:
        text = pattern.sub(replacement, text)
    # Raw base64 page images and embedded payloads are neither useful nor safe
    # in a browser-side log panel.
    text = re.sub(r"data:image/[^\s'\"]+", "data:image/[REDACTED]", text, flags=re.I)
    return text


# Restore only after the redactor exists: snapshots may contain diagnostic
# text and are rewritten through the same redaction boundary on startup.
_restore_persisted_tasks()


def _read_diagnostic_events(path: Path) -> list[dict]:
    events: list[dict] = []
    try:
        for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
            item = json.loads(raw)
            if not isinstance(item, dict):
                continue
            event = {
                "timestamp": str(item.get("timestamp") or ""),
                "stage": str(item.get("stage") or "unknown"),
                "status": str(item.get("status") or "unknown"),
                "elapsed_ms": (item.get("details") or {}).get("elapsed_ms"),
                "source": str(item.get("source") or "")[:240],
                "reason": _redact_technical_log(str(item.get("reason") or ""), 500),
            }
            details = item.get("details") or {}
            if isinstance(details, dict):
                call_id = details.get("call_id")
                if isinstance(call_id, str) and re.fullmatch(r"[0-9a-f]{32}", call_id):
                    event["call_id"] = call_id
                if type(details.get("business_success")) is bool:
                    event["business_success"] = details["business_success"]
                if type(details.get("context_truncated")) is bool:
                    event["context_truncated"] = details["context_truncated"]
                if details.get("report_status") in ("completed", "partial", "failed"):
                    event["report_status"] = details["report_status"]
                for field in ("paper_read_count", "model_call_count", "time_budget_seconds",
                              "source_chars", "selected_chars", "chunk_count"):
                    value = details.get(field)
                    if type(value) is int and 0 <= value <= 100000000:
                        event[field] = value
                if isinstance(details.get("read_guard"), str) and details["read_guard"] in {"executed", "failure_cooldown", "shared_result", "inflight", "capacity"}:
                    event["read_guard"] = details["read_guard"]
            events.append(event)
    except (OSError, ValueError, TypeError):
        return events
    return events[-100:]


def _merge_diagnostic_events(existing: list, path: Path) -> list[dict]:
    """Polling already copied diagnostics into timeline; do not append twice."""
    merged = []
    seen = set()
    for event in existing + _read_diagnostic_events(path):
        key = json.dumps(event, sort_keys=True, ensure_ascii=True)
        if key not in seen:
            seen.add(key)
            merged.append(event)
    return merged


def _as_number(value, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _format_upload_source_evidence(source_text: str, metadata: dict) -> str:
    """Return a small, readable audit summary instead of a raw PDF dump."""
    source_text = str(source_text or "")
    mode = str(metadata.get("pdf_parse_mode") or "local")
    mode_label = {"local": "本地解析", "llama_full": "整篇 LlamaParse", "hybrid": "混合增强"}.get(mode, mode)
    pages = metadata.get("pages") or []
    lines = [
        "本页不展示整篇原始转写，避免把数万字解析文本误当成分析结论。",
        "",
        f"- 解析来源：{mode_label}",
        f"- 原始转写长度：{len(source_text):,} 字符",
        f"- 已解析页面：{metadata.get('text_page_count', 0)} / {metadata.get('page_count', 0)} 页",
        "- 可引用边界：正文结论应回查原 PDF 页码；公式、表格、图表与流程图仍需以原页为准。",
    ]
    samples = []
    for page in pages:
        preview = re.sub(r"\s+", " ", str(page.get("preview") or "")).strip()
        if preview:
            samples.append(f"- 第 {page.get('page', '?')} 页抽样：{preview[:260]}{'...' if len(preview) > 260 else ''}")
        if len(samples) == 3:
            break
    if samples:
        lines.extend(["", "### 页级抽样（仅用于定位原文）", *samples])
    return "\n".join(lines)


def _format_upload_parse_status(metadata: dict) -> str:
    """Expose parser state as a concise user-facing report, never raw metadata."""
    mode = str(metadata.get("pdf_parse_mode") or "local")
    mode_label = {"local": "本地解析", "llama_full": "整篇 LlamaParse", "hybrid": "混合增强"}.get(mode, mode)
    quality = metadata.get("parse_quality") or {}
    ocr = metadata.get("ocr_cross_check") or {}
    llama_full = metadata.get("llama_full_pdf") or {}
    llama_vision = metadata.get("llama_vision") or {}
    hybrid = metadata.get("hybrid_evidence_summary") or {}
    confidence = _as_number(quality.get("overall_confidence"), 0.0)
    lines = [
        f"- 解析链路：{mode_label}",
        f"- 本地解析器：{metadata.get('parser') or '未报告'}",
        f"- 页面：{metadata.get('text_page_count', 0)} / {metadata.get('page_count', 0)} 页获得文本；空白页 {metadata.get('empty_page_count', 0)} 页",
        f"- 提取文本：{metadata.get('content_length', 0):,} 字符；状态：{metadata.get('extraction_status') or '未报告'}",
        f"- 本地候选：版面块 {len(metadata.get('layout_blocks') or [])} 个，表格 {len(metadata.get('tables') or [])} 个，公式 {len(metadata.get('formulas') or [])} 个",
        f"- 本地解析置信度：{confidence:.0%}（仅作风险提示，不作为内容正确性的证明）",
    ]
    if ocr:
        lines.append(f"- OCR 交叉核验：{ocr.get('status', '未启用')}；已检查表格 {ocr.get('tables_checked', 0)} 个")
    if mode != "local":
        full_status = llama_full.get("status", "unknown")
        lines.append(f"- 整篇 LlamaParse：{full_status}" + (f"（{llama_full.get('reason')}）" if llama_full.get("reason") else ""))
        llama_hint = _credential_error_hint(
            f"{llama_full.get('reason', '')} {llama_full.get('error', '')}", "LLAMA_CLOUD_API_KEY"
        )
        if llama_hint:
            lines.append(f"- 配置提示：{llama_hint}")
        if mode == "hybrid":
            lines.append(f"- 区域增强：{llama_vision.get('status', 'unknown')}；证据条目 {hybrid.get('entries', 0)} 个")
        if mode == "llama_full":
            lines.append("- 验收状态：实验性模式，尚未纳入本轮可靠性质量验收。")
        lines.append("- 隐私说明：云端模式会将 PDF 或裁剪区域发送至 LlamaParse；本地模式不会。")
    else:
        lines.append("- 云端调用：未调用 LlamaParse。")
    return "\n".join(lines)


def _format_upload_risk_report(risk_summary: dict, metadata: dict) -> str:
    """Translate parser warnings into actionable limitations for a researcher."""
    risk_summary = risk_summary or {}
    level = str(risk_summary.get("level") or "warning")
    labels = [str(item) for item in (risk_summary.get("risk_labels") or []) if item]
    affected = risk_summary.get("affected_pages") or []
    page_numbers = [str(item.get("page")) for item in affected if isinstance(item, dict) and item.get("page") is not None]
    confidence = _as_number(risk_summary.get("overall_confidence"), 0.0)
    level_label = {"ok": "低风险", "warning": "需要核验", "critical": "高风险"}.get(level, level)
    lines = [f"- 风险等级：{level_label}（本地风险分数 {confidence:.0%}，不等于内容正确率）"]
    if labels:
        lines.append("- 已识别风险：" + "、".join(labels[:8]))
    else:
        lines.append("- 未发现结构性高风险；这不代表公式、图表或扫描页已经人工验证。")
    if page_numbers:
        visible = "、".join(page_numbers[:12])
        suffix = f" 等共 {len(page_numbers)} 页" if len(page_numbers) > 12 else ""
        lines.append(f"- 优先回查页面：第 {visible} 页{suffix}")
    if risk_summary.get("requires_manual_review"):
        lines.extend([
            "",
            "### 对分析结论的影响",
            "- 不应仅凭解析结果精确引用公式符号、表格数值、图中数据点、流程图连线或跨栏相邻关系。",
            "- 论文分析报告会把这些内容作为待核验信息；需要精确结论时请回查原 PDF 页面。",
        ])
    else:
        lines.append("- 常规正文可用于概览；重要数字和图表结论仍建议回查原 PDF。")
    return "\n".join(lines)


def _is_specific_upload_question(question: str) -> bool:
    """Identify questions about a named PDF section rather than the whole paper."""
    value = str(question or "").strip().lower()
    markers = (
        "主要讲", "讲了什么", "这一节", "这节", "这部分", "本节", "该节", "该部分",
        "第", "section", "chapter", "what does", "what is covered", "explain the section",
    )
    return bool(value) and any(marker in value for marker in markers)


def _looks_like_unfocused_upload_answer(text: str) -> bool:
    """Detect a whole-paper template returned for a section-specific question."""
    value = str(text or "")
    broad_sections = ("论文概览", "核心方法", "主要结果与证据")
    return sum(marker in value for marker in broad_sections) >= 2


def _select_upload_evidence(source_text: str, question: str, limit: int = 52000) -> str:
    """Return question-centred PDF context while retaining a bounded prompt."""
    source = str(source_text or "").strip()
    if len(source) <= limit:
        return source
    query = str(question or "").strip()
    terms = []
    for token in re.findall(r"[A-Za-z][A-Za-z0-9_-]{2,}|[\u4e00-\u9fff]{2,}", query.lower()):
        if token not in terms:
            terms.append(token)
    # A literal multi-word section heading is much more reliable than its
    # individual tokens. Keep a broad window after it so the model receives
    # the complete local argument instead of only a heading or abstract.
    normalized_source = source.lower()
    english_phrases = re.findall(r"[A-Za-z][A-Za-z0-9 ,:'()_-]{8,}", query)
    positions = [normalized_source.find(phrase.strip().lower()) for phrase in english_phrases]
    positions = [position for position in positions if position >= 0]
    if positions:
        start = max(0, positions[0] - 1800)
        end = min(len(source), start + limit)
        return source[start:end]

    lines = source.splitlines()
    scored = []
    for index, line in enumerate(lines):
        lowered = line.lower()
        score = sum(1 for term in terms if term in lowered)
        if score:
            scored.append((score, index))
    if not scored:
        return source[:limit]
    scored.sort(key=lambda item: (-item[0], item[1]))
    selected = set()
    for _, index in scored[:10]:
        selected.update(range(max(0, index - 8), min(len(lines), index + 18)))
    excerpt = "\n".join(line for index, line in enumerate(lines) if index in selected)
    return excerpt[:limit] if excerpt.strip() else source[:limit]


def _upload_analysis_report(
    *, title: str, source_text: str, metadata: dict, question: str, pdf_parse_mode: str,
    query_intent: dict | None = None, evidence_blocks: list[dict] | None = None,
) -> str:
    """Turn an uploaded PDF extraction into a bounded, evidence-aware report."""
    config = get_config()
    model_config = config.get_custom_llm_config()
    model_url = os.getenv("MODEL_REQUEST_URL") or model_config.get("url", "")
    token = provider_value("MODEL_REQUEST_TOKEN", model_config.get("token", ""))
    source_text = str(source_text or "").strip()
    if not model_url:
        return (
            "## 论文分析暂不可用\n\n"
            "已完成 PDF 识别，但回答模型未配置，因此无法将识别结果整理为论文分析。"
        )
    if not source_text:
        return "## 论文分析暂不可用\n\n未取得可供分析的 PDF 转写文本。"

    focused_question = _is_specific_upload_question(question)
    query_intent = query_intent or analyze_query_intent(question, has_upload=True)
    contract = build_answer_contract(query_intent)
    all_evidence = evidence_blocks or []
    selected_evidence = select_evidence_blocks(all_evidence, question)
    metadata["evidence_block_summary"] = {
        "total": len(all_evidence),
        "selected": len(selected_evidence),
        "selected_ids": [item.get("evidence_id") for item in selected_evidence],
        "selected_pages": sorted({item.get("page") for item in selected_evidence if item.get("page") is not None}),
        "manual_review_required": any(item.get("risk_flags") or not item.get("citation_allowed") for item in selected_evidence),
    }
    response_instruction = (
        "用户问的是论文中的特定章节或部分。先用 1 至 3 段直接回答这个问题，再用‘依据与细节’说明该段的"
        "动机、做法、关键证据和作者结论。不要写整篇论文概览、不要介绍与该问题无关的模型架构或实验。"
        "只有当解析风险会直接影响该问题时，最后用一两句话说明边界。"
        if focused_question else
        "用户要求整体分析或研究笔记。这不是论文内容复述，而是有分析、有判断的研究笔记。必须使用以下小节："
        "## 核心贡献（2-3 段，用自己的话总结论文解决了什么问题、核心思路是什么、为什么重要）；"
        "## 方法亮点（分点说明方法的关键设计、与已有工作的差异、技术直觉，不要罗列公式细节）；"
        "## 实验结论（总结主要实验发现、关键数据趋势、消融实验说明了什么，不要逐行抄表格）；"
        "## 研究价值与可借鉴思路（分析这个方法能用到什么场景、有什么启发、与其他领域的联系）；"
        "## 局限与未来工作（论文自述的局限 + 你基于证据的判断）。"
        "解析风险说明放在最后，不要穿插在正文中。公式只在解释方法思路必要时简要提及，不要完整罗列。"
    )
    evidence_text = _select_upload_evidence(source_text, question)
    prompt = (
        "请用中文回答用户关于上传 PDF 的问题。只能依据下方的 PDF 转写和解析状态，"
        "不得补造实验数字、公式、图表内容或论文结论。"
        + response_instruction +
        "若原始转写没有可靠信息，直接说明无法可靠判断。"
        "不要复述整篇原文，不要输出调用日志，也不要把 PDF 解析状态 JSON 当作正文。"
        f"\n论文文件：{title}\n用户关注点：{question or '请对论文进行整体分析'}"
        f"\n解析模式：{pdf_parse_mode}"
        f"{intent_instruction(query_intent or analyze_query_intent(question, has_upload=True))}"
        f"{answer_contract_instruction(contract)}"
        f"\n解析风险摘要：{json.dumps(metadata.get('risk_summary') or {}, ensure_ascii=False)[:4000]}"
        f"\n\n结构化 PDF 证据块（每块保留页码和 bbox）：\n{format_evidence_blocks(selected_evidence)}"
        f"\n\nPDF 转写证据（按问题选择，可能被截断）：\n{evidence_text}"
    )
    headers = {"Content-Type": "application/json"}
    if token:
        headers.update({"Authorization": f"Bearer {token}", "csb-token": token})
    payload = {
        "model": config.model_name,
        "messages": [
            {"role": "system", "content": "你是严谨的 PDF 研究笔记助手。必须服从用户问题范围；不得用整篇论文报告替代章节问答。整体分析时要有分析有判断，不要只是复述论文内容。"},
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.1,
        "max_tokens": min(int(model_config.get("max_tokens", 8192) or 8192), 5000),
        "thinking": {"type": "disabled"},
        "enable_thinking": False,
        "reasoning_effort": "none",
    }
    try:
        response = post_model_request(
            model_url, headers=headers, json=payload,
            timeout=min(int(model_config.get("timeout", 60) or 60), 90),
        )
        response.raise_for_status()
        data = response.json()
        choices = data.get("choices") if isinstance(data, dict) else []
        message = (choices or [{}])[0].get("message") or {}
        content = str(message.get("content") or "").strip()
        if focused_question and _looks_like_unfocused_upload_answer(content):
            retry_payload = dict(payload)
            retry_payload["temperature"] = 0.0
            retry_payload["max_tokens"] = min(int(payload["max_tokens"]), 3200)
            retry_payload["messages"] = [
                {"role": "system", "content": "只回答用户指定的 PDF 章节。禁止输出‘论文概览’、‘核心方法’或整篇论文分析。"},
                {"role": "user", "content": (
                    f"问题：{question}\n{intent_instruction(query_intent or {})}\n{answer_contract_instruction(contract)}\n\n"
                    "请先用‘## 直接回答’准确回答，再用‘## 依据与细节’展开该节。"
                    "只讨论这个章节；解析风险仅在直接影响该问题时用一句话放在最后。\n\n"
                    f"章节相关 PDF 转写：\n{evidence_text}"
                )},
            ]
            retry_response = post_model_request(
                model_url, headers=headers, json=retry_payload,
                timeout=min(int(model_config.get("timeout", 60) or 60), 90),
            )
            retry_response.raise_for_status()
            retry_data = retry_response.json()
            retry_choices = retry_data.get("choices") if isinstance(retry_data, dict) else []
            retry_message = (retry_choices or [{}])[0].get("message") or {}
            retry_content = str(retry_message.get("content") or "").strip()
            if retry_content:
                content = retry_content
        if content:
            metadata["answer_structure_check"] = validate_answer_structure(content, contract)
            return content
        raise ValueError("回答模型返回空正文")
    except Exception as exc:  # noqa: BLE001
        credential_hint = _credential_error_hint(str(exc))
        return (
            "## 论文分析暂未生成\n\n"
            f"已取得 {pdf_parse_mode} 解析结果，但回答模型未能生成分析。"
            + (f"\n\n{credential_hint}" if credential_hint else f"\n\n原因：{exc}")
            + "\n\n解析证据摘要与解析状态仍可在下方展开查看。"
        )


_BOX_CHARS = set("─━┄┅┈┉┊┋│┃┌┐└┘├┤┬┴┼╭╮╰╯═║╔╗╚╝╠╣╦╩╬")


_REPORT_HEADINGS = (
    "PDF 解析状态报告", "部分解析失败说明", "证据可用性", "引用核验",
    "参考文献", "文献来源", "PDF EVIDENCE LEDGER (deterministic permissions)",
    "PDF EVIDENCE LEDGER", "References", "回答完整性说明",
)


def _expand_embedded_headings(line: str) -> list[str]:
    """Split Rich-collapsed headings while retaining text after a heading."""
    pieces = re.split(r"(?=##\s*)", line)
    result: list[str] = []
    for piece in pieces:
        piece = _strip_terminal_frame(piece)
        if not piece:
            continue
        match = re.match(r"^##\s*(.+?)\s*$", piece)
        if not match:
            result.append(piece)
            continue
        body = match.group(1)
        title = next((item for item in _REPORT_HEADINGS if body.startswith(item)), None)
        if not title:
            # Keep ordinary Markdown headings on their own line as well. This
            # prevents literal ``##`` markers from leaking into the Web UI.
            result.append(f"## {body}")
            continue
        result.append(f"## {title}")
        remainder = _strip_terminal_frame(body[len(title):]).lstrip(" ：:|-鈹│")
        if remainder:
            result.append(remainder)
    return result


def _strip_terminal_frame(line: str) -> str:
    """Remove Rich/box-drawing decoration without touching report content."""
    value = line.strip()
    box_chars = _BOX_CHARS | set("┌┐└┘├┤┬┴┼─━│┃╭╮╰╯╱╲")
    while value and value[0] in box_chars:
        value = value[1:].lstrip()
    while value and value[-1] in box_chars:
        value = value[:-1].rstrip()
    return value


def _extract_answer(log_text: str) -> str:
    """Extract only the final report from a verbose Rich terminal transcript."""
    # The last marker belongs to the completed answer, while earlier markers
    # can occur in intermediate agent traces or prompts.
    marker = "Final Answer:"
    # Prefer the structured final_answer field when direct routes do not emit
    # the human-facing Final Answer marker.
    structured_start = log_text.rfind("final_answer:")
    marker_start = log_text.rfind(marker)
    if structured_start > marker_start:
        marker = "final_answer:"
    start = log_text.rfind(marker)
    if start >= 0:
        candidate = log_text[start + len(marker):]
    else:
        start = log_text.find("## PDF 解析状态报告")
        if start < 0:
            return ""
        candidate = log_text[start:]
    end = candidate.find("Detailed Execution Trace")
    for metadata_marker in ("\nroute:", "\nevidence_mode:", "\ncache_hit:", "\nresponse_style:"):
        metadata_index = candidate.find(metadata_marker)
        if metadata_index >= 0 and (end < 0 or metadata_index < end):
            end = metadata_index
    if end >= 0:
        candidate = candidate[:end]
    cleaned = []
    for raw_line in candidate.splitlines():
        # Rich panels may place several Markdown headings on one visual line.
        # Split at headings before removing terminal decoration so the web UI
        # can render stable sections instead of exposing box characters.
        expanded = re.sub(r"(?<!^)##\s+", "\n## ", raw_line)
        # The answer model sometimes emits bold section labels rather than
        # Markdown headings. Normalize only our known report labels so prose
        # containing bold text is left untouched.
        for title in (
            "部分解析失败说明", "证据可用性", "引用核验", "文献来源", "参考文献",
            "回答完整性说明", "检索诊断", "PDF 解析状态报告",
        ):
            expanded = re.sub(
                rf"\*\*{re.escape(title)}\*\*\s*[:：]?",
                f"\n## {title}\n",
                expanded,
            )
        # Preserve blank lines: "".splitlines() returns [], so an empty
        # expanded line would otherwise be silently dropped and paragraph
        # breaks (\n\n) would collapse into single newlines.
        if not expanded:
            cleaned.append("")
            continue
        for expanded_line in expanded.splitlines():
            for split_line in _expand_embedded_headings(expanded_line):
                line = _strip_terminal_frame(split_line)
                if not line:
                    cleaned.append("")
                    continue
                # A standalone hash is a Rich/Markdown frame artifact, not a
                # meaningful heading.
                if re.fullmatch(r"#+", line):
                    continue
                if re.match(r"^(?:route|evidence_mode|cache_hit|response_style|task_name|completion_status):", line):
                    continue
                # Rich panel/table separators should never become report paragraphs.
                if len(line) > 8 and set(line) <= _BOX_CHARS:
                    continue
                cleaned.append(line)
    while cleaned and not cleaned[0]:
        cleaned.pop(0)
    while cleaned and not cleaned[-1]:
        cleaned.pop()
    # Rich wraps long values to the panel width. Rejoin continuation lines,
    # including wrapped bullets/headings, while preserving blank lines.
    normalized_lines = []
    for line in cleaned:
        structural = (line.startswith("#") or line.startswith(("- ", "* ", "+ ", "> ", "|"))
                      or re.match(r"^(?:\d+[.)]\s|\[\d+\])", line))
        if (line and normalized_lines and normalized_lines[-1]
                and not structural and not normalized_lines[-1].startswith("#")):
            previous = normalized_lines[-1]
            normalized_lines[-1] = previous + line
            continue
        normalized_lines.append(line)
    return "\n".join(normalized_lines).strip()


def _split_answer_sections(answer: str) -> dict[str, str]:
    """Split the final Markdown report into stable UI sections."""
    canonical_headings = {
        "\u7ed3\u8bba": "report",
        "\u4f9d\u636e": "report",
        "\u901a\u4fd7\u6d41\u7a0b\u793a\u4f8b": "report",
        "\u5de5\u7a0b\u5b9e\u73b0\u4e2d\u7684\u5e38\u89c1\u6b65\u9aa4": "report",
        "\u4e3b\u8981\u4f18\u52bf\u4e0e\u5c40\u9650": "report",
        "\u8bba\u6587\u4f9d\u636e\u8fb9\u754c": "report",
        "结论": "report",
        "依据": "report",
        "通俗流程示例": "report",
        "工程实现中的常见步骤": "report",
        "主要优势与局限": "report",
        "论文依据边界": "report",
        "\u90e8\u5206\u89e3\u6790\u5931\u8d25\u8bf4\u660e": "partial_failure",
        "\u8bc1\u636e\u53ef\u7528\u6027": "evidence_ledger",
        "\u5f15\u7528\u6838\u9a8c": "citation_check",
        "\u53c2\u8003\u6587\u732e": "references",
        "\u6587\u732e\u6765\u6e90": "references",
        "\u56de\u7b54\u5b8c\u6574\u6027\u8bf4\u660e": "answer_completeness",
        "\u68c0\u7d22\u8bca\u65ad": "search_diagnostics",
        "PDF \u89e3\u6790\u72b6\u6001\u62a5\u544a": "parse_status",
        "partial parsing failure": "partial_failure",
        "evidence availability": "evidence_ledger",
        "citation verification": "citation_check",
        "references": "references",
        "answer completeness": "answer_completeness",
        "search diagnostics": "search_diagnostics",
        "pdf parse status report": "parse_status",
    }
    headings = {
        "\u7ed3\u8bba": "report",
        "\u4f9d\u636e": "report",
        "\u901a\u4fd7\u6d41\u7a0b\u793a\u4f8b": "report",
        "\u5de5\u7a0b\u5b9e\u73b0\u4e2d\u7684\u5e38\u89c1\u6b65\u9aa4": "report",
        "\u4e3b\u8981\u4f18\u52bf\u4e0e\u5c40\u9650": "report",
        "\u8bba\u6587\u4f9d\u636e\u8fb9\u754c": "report",
        "结论": "report",
        "依据": "report",
        "通俗流程示例": "report",
        "工程实现中的常见步骤": "report",
        "主要优势与局限": "report",
        "论文依据边界": "report",
        "PDF 解析状态报告": "parse_status",
        "部分解析失败说明": "partial_failure",
        "证据可用性": "evidence_ledger",
        "引用核验": "citation_check",
        "参考文献": "references",
        "文献来源": "references",
        "检索诊断": "search_diagnostics",
        "回答完整性说明": "answer_completeness",
        "PDF 解析状态报告": "parse_status",
        "部分解析失败说明": "partial_failure",
        "PDF EVIDENCE LEDGER (deterministic permissions)": "evidence_ledger",
        "PDF EVIDENCE LEDGER": "evidence_ledger",
        "引用核验": "citation_check",
        "References": "references",
        "PDF 解析状态报告": "parse_status",
        "部分解析失败说明": "partial_failure",
        "证据可用性": "evidence_ledger",
        "引用核验": "citation_check",
        "参考文献": "references",
        "文献来源": "references",
        "参考文献": "references",
    }
    sections: dict[str, list[str]] = {"report": []}
    current = "report"
    for line in answer.splitlines():
        if line.strip() == "---":
            continue
        if line.rstrip().endswith("---"):
            line = line.rstrip()[:-3].rstrip()
            if not line:
                continue
        normalized = line.lstrip("#").strip().rstrip("：:")
        if re.match(r"^#{1,6}\s+", line.strip()):
            heading_text = re.sub(r"^#{1,6}\s+", "", line.strip()).strip()
            heading_key = heading_text.rstrip("：:").strip().lower()
            known_auxiliary = any(
                heading_key.startswith(str(title).rstrip("：:").lower())
                for title in (*headings.keys(), *canonical_headings.keys())
            )
            if not known_auxiliary:
                current = "report"
                sections.setdefault(current, [])
        matched = next((key for title, key in headings.items() if normalized.startswith(title)), None)
        if not matched:
            lower = normalized.lower()
            matched = next((key for title, key in canonical_headings.items()
                            if lower.startswith(title.lower())), None)
        # Some old Windows logs contain box characters around headings. A
        # keyword fallback keeps canonical sections recoverable after frame
        # stripping or partial encoding damage.
        if not matched:
            if "部分解析失败说明" in normalized:
                matched = "partial_failure"
            elif "PDF 解析状态报告" in normalized:
                matched = "parse_status"
            elif "证据可用性" in normalized:
                matched = "evidence_ledger"
            elif "引用核验" in normalized:
                matched = "citation_check"
            elif "参考文献" in normalized or "文献来源" in normalized:
                matched = "references"
            elif "检索诊断" in normalized:
                matched = "search_diagnostics"
        if matched:
            current = matched
            sections.setdefault(current, [])
            continue
        sections.setdefault(current, []).append(line)
    result = {key: "\n".join(value).strip() for key, value in sections.items() if "\n".join(value).strip()}
    if answer.strip() and not result.get("report"):
        result["report"] = answer.strip()
    return result


def _run_general_chat_task(task_id: str, query: str, *, fallback: bool = False,
                           fallback_reason: str = "证据不足") -> None:
    """Answer a non-academic request directly with the base model.

    No literature retrieval, no PDF work. The model responds naturally and may
    gently point the user back to research questions, but never fakes a search
    or fabricates citations.
    """
    log_path = LOG_DIR / f"web_task_{task_id}.txt"
    try:
        if _is_task_cancel_requested(task_id):
            return
        _update(task_id, status="running", started_at=_now(),
                message=("证据不足，正在生成降级通用回答" if fallback else "正在直接回应"), log=str(log_path))
        config = get_config()
        model_config = config.get_custom_llm_config()
        model_url = os.getenv("MODEL_REQUEST_URL") or model_config.get("url", "")
        token = provider_value("MODEL_REQUEST_TOKEN", model_config.get("token", ""))
        if not model_url:
            _update(task_id, status="failed",
                    message="回答模型未配置", answer="## 暂不可用\n\n回答模型尚未配置。")
            return
        context_packet = (TASKS.get(task_id) or {}).get("conversation_context") or {}
        fallback_system = (
            "你是 SciAssistant 的通用 AI 降级回答助手。科研检索或原文审查链路本轮没有形成可发布证据，"
            "但仍请像普通通用 AI 一样尽可能回答用户问题。可以使用通用知识解释概念、关系、常见方法、"
            "优缺点和适用条件；回答要先给直接结论，再给通俗解释、边界和不确定性。不要声称看过本轮 PDF、"
            "检索结果或论文原文，不要编造引用、数字、最新新闻、实时天气或实验结果。若问题依赖实时信息，"
            "明确说明当前无法核实；若问题存在多种解释，先采用最合理解释并说明假设。"
            if fallback else
            "你是 SciAssistant，一个科研文献助手。对于日常问候、闲聊或创作请求（如写诗、讲故事、讲笑话），"
            "请自然、简洁、友好地直接回应。可以在合适的时候用一句话提示：你最擅长的是基于 arXiv 等学术文献"
            "回答科研问题，欢迎提出学术问题。不要假装进行了文献检索，不要编造论文引用或编号。"
            "当前链路没有实时联网或天气工具；被问到实时天气、新闻等时，不要编造实时结果，请明确说明无法核实。"
        )
        messages = [{
            "role": "system",
            "content": fallback_system,
        }]
        # Include the immediately previous exchange for conversational continuity.
        if context_packet.get("status") == "ready":
            pq = str(context_packet.get("previous_query") or "").strip()
            pa = str(context_packet.get("previous_answer") or "").strip()
            if pq:
                messages.append({"role": "user", "content": pq[:2000]})
            if pa:
                messages.append({"role": "assistant", "content": pa[:3000]})
        messages.append({"role": "user", "content": query})
        headers = {"Content-Type": "application/json"}
        if token:
            headers.update({"Authorization": f"Bearer {token}", "csb-token": token})
        payload = {
            "model": config.model_name,
            "messages": messages,
            "temperature": 0.7,
            "max_tokens": 2000,
            "thinking": {"type": "disabled"},
            "enable_thinking": False,
            "reasoning_effort": "none",
        }
        response = post_model_request(
            model_url, headers=headers, json=payload,
            timeout=min(int(model_config.get("timeout", 60) or 60), 90),
        )
        response.raise_for_status()
        data = response.json()
        choices = data.get("choices") if isinstance(data, dict) else []
        message = (choices or [{}])[0].get("message") or {}
        answer = str(message.get("content") or "").strip()
        if not answer:
            answer = "（暂时无法生成回应，请稍后再试。）"
        if _is_task_cancel_requested(task_id):
            return
        log_path.write_text(answer, encoding="utf-8")
        if fallback:
            _update(task_id, status="needs_review", message="已生成降级通用回答：未形成可核验文献结论",
                    answer=wrap_general_fallback(answer, reason=fallback_reason),
                    report_available=True, fallback_mode="general_answer",
                    fallback_reason=fallback_reason, evidence_backed=False)
        else:
            _update(task_id, status="completed", message="已回应", answer=answer)
    except Exception as exc:  # noqa: BLE001 - surface a clear failure
        user_message = _user_facing_model_error(exc)
        failure_code = "MODEL_HTTP_402" if isinstance(exc, requests.HTTPError) and exc.response is not None and exc.response.status_code == 402 else None
        _update(task_id, status="failed", message=user_message, failure_code=failure_code,
                answer=f"## 回应失败\n\n{user_message}")


def _run_query_task(
    task_id: str,
    query: str,
    pdf_parse_mode: str = "local",
    query_mode: str | None = None,
    relax_gate: bool = False,
) -> None:
    log_path = LOG_DIR / f"web_task_{task_id}.txt"
    query_path = LOG_DIR / f"web_query_{task_id}.txt"
    diagnostics_path = LOG_DIR / f"web_task_{task_id}.diagnostics.jsonl"
    prefetch_path = LOG_DIR / f"web_task_{task_id}.prefetch.json"
    context_path = LOG_DIR / f"web_task_{task_id}.context.json"
    followup_path = LOG_DIR / f"web_task_{task_id}.followup.json"
    is_multi_agent_literature = query_mode == "multi_agent_literature"
    try:
        if _is_task_cancel_requested(task_id):
            return
        _update(task_id, status="running", started_at=_now(), queue_ahead=None, queue_position=None,
                message=("多 Agent 协作：正在规划、检索并审查文献证据" if is_multi_agent_literature
                         else "正在处理问题并检索可用科学证据"),
                log=str(log_path), diagnostics_path=str(diagnostics_path))
        # The CLI keeps its Rich format for interactive users. The Web worker
        # uses quiet mode so answer extraction receives unwrapped plain text.
        # Keep the UTF-8 query file contract, but launch this interpreter
        # directly on every OS; never bootstrap shared MCP inside a task.
        query_path.write_text(query, encoding="utf-8")
        task_snapshot = TASKS.get(task_id, {})
        context_packet = task_snapshot.get("conversation_context") or {"status": "none"}
        if context_packet.get("status") == "ready":
            context_path.write_text(json.dumps(context_packet, ensure_ascii=False), encoding="utf-8")
        command = research_command([
            "--query-file", str(query_path), "--quiet",
            "--clarification", "never",
            "--pdf-parse-mode", pdf_parse_mode,
            "--query-mode", query_mode or "auto",
            "--diagnostics-file", str(diagnostics_path),
        ])
        if is_multi_agent_literature:
            command.extend(["--workflow-run-id", task_id])
        if context_path.is_file():
            command.extend(["--conversation-context-file", str(context_path)])
        if prefetch_path.is_file():
            command.extend(["--prefetch-file", str(prefetch_path)])
        if relax_gate:
            # User-requested lower-standard third pass. Keep these in sync with
            # RELAXED_RELEVANCE_THRESHOLD in deepdiver_v2/cli/demo.py.
            command.extend(["--relevance-threshold", "0.22", "--minimum-evidence", "1"])
        timeout_seconds = int(os.getenv("WEB_TASK_TIMEOUT", "900"))
        from deepdiver_v2.src.bounded_paper import uses_bounded_paper, paper_time_budget
        bounded_paper = uses_bounded_paper(query, query_mode, pdf_parse_mode)
        if bounded_paper:
            timeout_seconds = min(timeout_seconds, paper_time_budget())
        if is_multi_agent_literature:
            timeout_seconds = min(timeout_seconds, 360)
        with log_path.open("w", encoding="utf-8", errors="replace") as stream:
            completed = _spawn_research_process(command, stream)
            with TASK_LOCK:
                task = TASKS.get(task_id) or {}
                cancelled_before_registration = (
                    bool(task.get("cancel_requested")) or task.get("status") == "cancelled"
                )
                if not cancelled_before_registration:
                    _RETRIEVAL_PROCESSES[task_id] = completed
                    task.setdefault("execution", {}).update({
                        "process_registered_at": _now(),
                        "process_termination_requested": False,
                        "launcher": "python_direct", "mcp_lifecycle": "external_shared_service",
                        "workflow": ("bounded_multi_agent_literature_v1" if is_multi_agent_literature
                                     else "bounded_paper_v1" if bounded_paper else "legacy_research"),
                        "time_budget_seconds": timeout_seconds,
                        **({"model_call_limit": 10} if is_multi_agent_literature else {}),
                        "runtime": _RESEARCH_RUNTIME.snapshot(),
                    })
                    _persist_task_locked(task)
            # A cancel request can land after Popen returns but before this
            # worker publishes its handle.  Do not wait for the next 0.5s
            # polling tick in that case: terminate the wrapper tree now.
            if cancelled_before_registration:
                _stop_task_process(task_id, completed, "cancel_before_registration")
                with TASK_LOCK:
                    task = TASKS.get(task_id)
                    if task and task.get("status") == "cancelled":
                        task.setdefault("cancellation", {}).update({
                            "late_spawn_termination_requested": True,
                            "late_spawn_termination_requested_at": _now(),
                        })
                return
            try:
                deadline = time.monotonic() + timeout_seconds
                while True:
                    try:
                        completed.wait(timeout=min(0.5, max(0.05, deadline - time.monotonic())))
                        break
                    except subprocess.TimeoutExpired:
                        if _is_task_cancel_requested(task_id):
                            _stop_task_process(task_id, completed, "cancel_requested")
                            return
                        if time.monotonic() >= deadline:
                            _stop_task_process(task_id, completed, "research_timeout")
                            raise subprocess.TimeoutExpired(command, timeout_seconds)
            except subprocess.TimeoutExpired:
                raise
            except Exception:
                _stop_task_process(task_id, completed, "worker_unwind")
                raise
            finally:
                with TASK_LOCK:
                    if _RETRIEVAL_PROCESSES.get(task_id) is completed:
                        del _RETRIEVAL_PROCESSES[task_id]
        if _is_task_cancel_requested(task_id):
            _stop_task_process(task_id, completed, "cancel_requested")
            return
        output = log_path.read_text(encoding="utf-8", errors="replace")
        answer = _extract_answer(output)
        sections = _split_answer_sections(answer)
        task_snapshot = TASKS.get(task_id, {})
        query_intent = task_snapshot.get("query_intent") or analyze_query_intent(query, has_upload=False)
        answer_contract = build_answer_contract(query_intent)
        answer_structure_check = validate_answer_structure(answer, answer_contract)
        credential_hint = _credential_error_hint(output)
        if not answer:
            error_match = re.search(r"Error:\s*(.+)", output)
            error_text = error_match.group(1).strip() if error_match else "未能从 run_demo 输出中提取最终回答。"
            sections = {"report": "分析未完成：" + error_text}
            if credential_hint:
                # Credential/configuration hints are a different problem layer
                # from parsing failures; they get their own section so the
                # 部分解析失败说明 heading never carries unrelated text.
                sections["configuration_notice"] = credential_hint
        elif credential_hint and not _has_usable_answer(answer):
            sections["configuration_notice"] = credential_hint
        # A rejected answer-model credential means no trustworthy final answer
        # was produced, even if a lower layer printed a fallback sentence.
        task_failed = _task_failed_verdict(completed.returncode, output, answer, credential_hint)
        diagnostic_events = _merge_diagnostic_events(TASKS.get(task_id, {}).get("timeline") or [], diagnostics_path)
        execution = dict((TASKS.get(task_id) or {}).get("execution") or {})
        if bounded_paper:
            for event in diagnostic_events:
                if event.get("source") != "bounded_paper" or event.get("stage") != "paper_workflow":
                    continue
                for field in ("paper_read_count", "model_call_count", "context_truncated", "report_status"):
                    if field in event:
                        execution[field] = event[field]
                if event.get("status") == "failed" and event.get("reason") in {
                    "paper_input", "paper_configuration", "paper_read", "paper_parse",
                    "paper_deadline", "paper_model", "paper_workflow",
                }:
                    execution["failure_stage"] = event["reason"]
        if is_multi_agent_literature:
            for event in diagnostic_events:
                if event.get("source") != "multi_agent_literature" or event.get("stage") != "multi_agent_workflow":
                    continue
                for field in ("model_calls", "model_call_limit", "workflow_status", "failure_code"):
                    if field in event:
                        execution[field] = event[field]
            workflow_summary = _multi_agent_workflow_summary(task_id)
            if workflow_summary:
                execution.update({
                    "workflow": "bounded_multi_agent_literature_v1",
                    "time_budget_seconds": 360,
                    "model_call_limit": workflow_summary["model_call_limit"],
                    "model_calls": workflow_summary["model_calls"],
                    "workflow_status": workflow_summary["workflow_status"],
                })
                if workflow_summary.get("failure_code"):
                    execution["failure_code"] = workflow_summary["failure_code"]
        # Persist only non-secret context needed by a later follow-up. This is
        # a runtime artifact under logs/ and is excluded from Git.
        if not task_failed:
            try:
                paper_ids = sorted(set(re.findall(r"\b\d{4}\.\d{4,5}(?:v\d+)?\b", output)))[:30]
                followup_path.write_text(json.dumps({
                    "conversation_id": (TASKS.get(task_id) or {}).get("conversation_id"),
                    "query": query,
                    "answer": answer[:12000],
                    "sections": {"report": sections.get("report", "")[:12000]},
                    "query_intent": query_intent,
                    "paper_ids": paper_ids,
                }, ensure_ascii=False), encoding="utf-8")
            except (OSError, TypeError, ValueError):
                pass
        _update(task_id, status="failed" if task_failed else "completed",
                message=((credential_hint or "分析失败，请查看结果中的错误说明") if task_failed
                         else ("多 Agent 协作结束，请核验证据覆盖和引用摘要" if is_multi_agent_literature
                               else ("限步论文分析结束，请核验报告中的证据边界" if bounded_paper else "分析完成"))),
                answer=answer,
                sections=sections,
                query_intent=query_intent,
                answer_structure_check=answer_structure_check,
                answer_quality_summary={
                    "status": answer_structure_check.get("status"),
                    "missing": answer_structure_check.get("missing", []),
                    "manual_review_required": bounded_paper or answer_structure_check.get("status") != "passed",
                },
                # Keep the complete transcript for the collapsible Web log.
                # The previous tail-only slice cut the first parser blocks in
                # the middle of a bbox record, making the log look corrupted.
                output=_redact_technical_log(output),
                timeline=diagnostic_events,
                execution=execution,
                **({"agent_workflow": workflow_summary} if is_multi_agent_literature and workflow_summary else {}),
                returncode=completed.returncode)
    except ResearchDependencyError:
        _fail_task_safely(task_id, "mcp_dependency", MCP_UNAVAILABLE_MESSAGE)
        _update(task_id, output="")
    except subprocess.TimeoutExpired:
        if is_multi_agent_literature:
            _sync_multi_agent_terminal(task_id, "timed_out", "OUTER_TASK_TIMEOUT")
        _fail_task_safely(task_id, "research_timeout", "分析超时，请稍后重试")
        _update(task_id, output="",
                timeline=_merge_diagnostic_events(TASKS.get(task_id, {}).get("timeline") or [], diagnostics_path))
    except Exception:  # noqa: BLE001 - raw process errors may contain sensitive paths or URLs
        _fail_task_safely(task_id, "research_worker", "分析未能完成，请稍后重试")
        _update(task_id, output="",
                timeline=_merge_diagnostic_events(TASKS.get(task_id, {}).get("timeline") or [], diagnostics_path))
    finally:
        try:
            query_path.unlink(missing_ok=True)
            context_path.unlink(missing_ok=True)
        except OSError:
            pass


def _prepare_query_task(
    task_id: str,
    query: str,
    pdf_parse_mode: str = "local",
    query_mode: str | None = None,
) -> None:
    """Search once before asking for scope, then hand off to the full worker."""
    started = datetime.now(timezone.utc)
    try:
        if _is_task_cancel_requested(task_id):
            return
        _update(task_id, status="searching", started_at=_now(), queue_ahead=None, queue_position=None,
                message="正在先检索候选文献，以确定需要澄清的研究范围")
        from deepdiver_v2.cli.demo import _search_relevant_literature
        from deepdiver_v2.config.config import get_config
        from deepdiver_v2.src.query_router import preferred_literature_source
        from deepdiver_v2.src.tools.mcp_tools import MCPTools

        config = get_config()
        source = preferred_literature_source(query)
        tools = MCPTools()
        # The in-process pre-search shares this long-lived web process's LLM
        # client. A stale keep-alive connection can hang the call indefinitely
        # and leave the task spinning forever. Bound it; on timeout hand off to
        # the full worker, which spawns a fresh subprocess (and a fresh client)
        # and searches again. shutdown(wait=False) is required: a context-managed
        # executor blocks on exit waiting for the hung worker thread. The leaked
        # worker is a daemon thread and is cleaned up on process exit.
        import concurrent.futures
        executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
        future = executor.submit(_search_relevant_literature, query, source, tools, config)
        try:
            papers, diagnostics, _ = future.result(
                timeout=int(os.getenv("WEB_PRESEARCH_TIMEOUT", "180"))
            )
        except concurrent.futures.TimeoutError as exc:
            executor.shutdown(wait=False)
            raise TimeoutError("in-process pre-search timed out; handing off to full worker") from exc
        executor.shutdown(wait=False)
        # The pre-search itself is an in-process library call and cannot be
        # force-killed safely.  As soon as it returns, however, avoid writing
        # more task state or launching the full CLI for a cancelled request.
        if _is_task_cancel_requested(task_id):
            return
        prefetch_path = LOG_DIR / f"web_task_{task_id}.prefetch.json"
        prefetch_path.write_text(json.dumps({
            "query": query, "source": source, "papers": papers, "diagnostics": diagnostics,
        }, ensure_ascii=False), encoding="utf-8")
        elapsed_ms = round((datetime.now(timezone.utc) - started).total_seconds() * 1000)
        preflight_event = {
            "timestamp": _now(), "stage": "literature_presearch", "status": "completed",
            "elapsed_ms": elapsed_ms, "source": source,
            "reason": f"候选 {len(papers)} 篇，后续主流程将复用此结果",
        }
        requested = set(diagnostics.get("requested_concepts") or [])
        covered = set(diagnostics.get("covered_concepts") or [])
        needs_scope = bool(
            build_clarification_request(query)
            and (not papers or (requested and not requested.issubset(covered)))
        )
        if needs_scope:
            clarification = build_dynamic_clarification_request(query, diagnostics, config)
            _update(
                task_id,
                status="needs_clarification",
                message="初步检索已完成，请选择更准确的研究范围",
                clarification=clarification,
                search_diagnostics=diagnostics,
                timeline=[preflight_event],
            )
            return
        _update(task_id, status="queued", message="初步检索已有足够范围，正在启动完整分析",
                search_diagnostics=diagnostics, timeline=[preflight_event])
        _run_query_task(task_id, query, pdf_parse_mode, query_mode)
    except Exception:  # noqa: BLE001 - keep preflight diagnostics off the user-facing task
        if _is_task_cancel_requested(task_id):
            return
        # A preflight failure must not prevent the original research request
        # from running; the full worker will expose its own evidence/failure.
        _update(task_id, status="queued", message="初步检索暂不可用，继续完整分析", timeline=[{
            "timestamp": _now(), "stage": "literature_presearch", "status": "failed",
            "elapsed_ms": round((datetime.now(timezone.utc) - started).total_seconds() * 1000),
            "source": "", "reason": "初步检索异常，已转入完整分析",
        }])
        _run_query_task(task_id, query, pdf_parse_mode, query_mode)


def _parse_upload_task(task_id: str, path: Path, pdf_parse_mode: str) -> None:
    try:
        mode_label = {"local": "本地", "llama_full": "整篇 Llama", "hybrid": "混合增强"}[pdf_parse_mode]
        _update(task_id, status="running", started_at=_now(), message=f"正在执行{mode_label} PDF 解析")
        parsed = parse_pdf(path, enable_ocr=True)
        pages = parsed.get("pages") or []
        llama_full = {"enabled": False, "status": "disabled", "reason": "PDF_PARSE_MODE=local"}
        llama_vision = {"enabled": False, "status": "disabled", "reason": "PDF_PARSE_MODE=local", "regions": []}
        hybrid_evidence = {}
        source_content = parsed.get("text") or ""

        if parsed.get("success") and pdf_parse_mode != "local":
            output_dir = scoped_storage(UPLOAD_DIR / "processed")
            output_dir.mkdir(parents=True, exist_ok=True)
            with temporary_pdf_parse_mode(pdf_parse_mode):
                runtime_config = get_config()
                llama_full = run_llama_full_pdf_enhancement(
                    path, runtime_config, output_dir / f"{task_id}.llamaparse.md",
                )
                if pdf_parse_mode == "hybrid":
                    llama_vision = run_llama_vision_enhancement(
                        path, parsed, runtime_config, output_dir / "vision_cache", visual_only=True,
                    )
                    hybrid_evidence = build_hybrid_evidence_ledger(
                        str(path), llama_vision, runtime_config.llama_vision_min_confidence,
                    )
            llama_text_path = Path(str(llama_full.get("text_path") or ""))
            if llama_full.get("status") == "completed" and llama_text_path.is_file():
                source_content = llama_text_path.read_text(encoding="utf-8", errors="replace")
            else:
                # Keep a usable local result, but make the cloud degradation
                # explicit rather than presenting it as an enhanced parse.
                source_content = (
                    "## 增强解析未完成\n\n"
                    f"所选模式：{mode_label}。LlamaParse 状态：{llama_full.get('status', 'unknown')}。\n\n"
                    f"原因：{llama_full.get('reason') or llama_full.get('error') or '未返回可用转写'}。\n\n"
                    "以下为本地解析回退结果：\n\n" + source_content
                )

        # A parser may attach a library-specific error that contains a local
        # path or malformed source fragment.  Treat an unsuccessful parse as
        # a terminal task failure before assembling any browser-visible result.
        if not parsed.get("success"):
            _fail_task_safely(task_id, "pdf_parse_result", "PDF 解析未能完成，请检查文件后重试")
            return

        parsed["pdf_parse_mode"] = pdf_parse_mode
        parsed["llama_full_pdf"] = llama_full
        parsed["llama_vision"] = llama_vision
        parsed["hybrid_evidence"] = hybrid_evidence
        metadata = build_parse_metadata(parsed)
        metadata.update({
            "pdf_parse_mode": pdf_parse_mode,
            "llama_full_pdf": llama_full,
            "llama_vision": {
                key: value for key, value in llama_vision.items() if key != "regions"
            },
            "hybrid_evidence_summary": {
                "entries": len(hybrid_evidence.get("entries", [])) if isinstance(hybrid_evidence, dict) else 0,
                "status": llama_vision.get("status"),
            },
        })
        analysis_report = _upload_analysis_report(
            title=path.name,
            source_text=source_content,
            metadata=metadata,
            question=(TASKS.get(task_id) or {}).get("query", ""),
            pdf_parse_mode=pdf_parse_mode,
            query_intent=(TASKS.get(task_id) or {}).get("query_intent"),
            evidence_blocks=build_evidence_blocks(parsed),
        ) if parsed.get("success") else ""
        _update(task_id, status="completed",
                message=f"{mode_label} PDF 解析完成",
                answer=analysis_report,
                sections={"report": analysis_report},
                result={
                    "title": path.name,
                    "report_title": (TASKS.get(task_id) or {}).get("task_mode", {}).get("report_title", "PDF 解析报告"),
                    "content": analysis_report,
                    "source_evidence_report": _format_upload_source_evidence(source_content, metadata),
                    "parse_status_report": _format_upload_parse_status(metadata),
                    "page_count": parsed.get("page_count", len(pages)),
                    "parse_quality": parsed.get("parse_quality") or {},
                    "risk_summary": build_risk_summary(parsed),
                    "risk_report": _format_upload_risk_report(build_risk_summary(parsed), metadata),
                    "metadata": metadata,
                    "query_intent": (TASKS.get(task_id) or {}).get("query_intent"),
                    "evidence_block_summary": metadata.get("evidence_block_summary", {}),
                    "answer_structure_check": metadata.get("answer_structure_check", {"status": "not_run"}),
                    "citation_check": {"status": "not_applicable", "issues": ["本地上传 PDF 未经过 WriterAgent 引用生成"]},
                })
    except Exception:  # noqa: BLE001 - parser errors can disclose local paths or service details
        _fail_task_safely(task_id, "pdf_parse", "PDF 解析未能完成，请稍后重试")


@app.get("/")
def index():
    return send_from_directory(WEB_DIR, "index.html")


@app.get("/api/settings/api-keys")
def api_key_settings():
    return jsonify({
        "fields": _api_key_settings(),
        "core_ready": not _missing_task_configuration("local"),
    })


@app.post("/api/settings/api-keys")
def save_api_key_settings():
    try:
        peer = ipaddress.ip_address(str(request.remote_addr or ""))
    except ValueError:
        peer = None
    if peer is None or not peer.is_loopback:
        return jsonify({
            "error": "LOCAL_ACCESS_REQUIRED",
            "message": "API Key 配置只能从运行服务的本机修改。",
        }), 403
    body = request.get_json(silent=True) or {}
    try:
        _persist_api_key_settings(body.get("values") or {})
    except ValueError as exc:
        return _safe_api_failure("save_api_key_settings", exc, status=400, code="INVALID_SETTINGS")
    return jsonify({
        "message": "配置已保存到本机。密钥不会显示在网页或运行日志中。",
        "fields": _api_key_settings(),
        "core_ready": not _missing_task_configuration("local"),
    })


@app.get("/api/health")
def health():
    return jsonify({
        "status": "healthy",
        "service": "SciAssistant basic web",
        "runtime": _RESEARCH_RUNTIME.snapshot(),
        "task_execution": {
            "worker_count": TASK_EXECUTION_WORKER_COUNT,
            "queue_scope": "single_process",
            "multi_worker_safe": False,
        },
    })


@app.get("/api/readyz")
def readiness():
    """Report whether durable task storage and the shared MCP dependency are usable."""
    task_state_ready = TASK_STATE_DIR.is_dir() and os.access(TASK_STATE_DIR, os.W_OK)
    storage_ready = has_minimum_free_space(
        (LOG_DIR, UPLOAD_DIR, ARXIV_DIR, TASK_STATE_DIR), RUNTIME_STORAGE_MIN_FREE_BYTES
    )
    mcp_ready = True
    try:
        check_shared_mcp(research_environment())
    except ResearchDependencyError:
        mcp_ready = False
    components = {
        "task_state": "ready" if task_state_ready else "unavailable",
        "runtime_storage": "ready" if storage_ready else "unavailable",
        "shared_mcp": "ready" if mcp_ready else "unavailable",
    }
    if not all((task_state_ready, storage_ready, mcp_ready)):
        return jsonify({"status": "not_ready", "components": components}), 503
    return jsonify({"status": "ready", "components": components})


@app.errorhandler(413)
def request_too_large(_error):
    return jsonify({"error": "请求内容超过 50 MB 限制，请缩小文件或问题后重试"}), 413


def _rag_progress(task_id: str) -> None:
    try:
        summary = rag_web.progress(task_id)
    except Exception:
        return
    if summary:
        with TASK_LOCK:
            task = TASKS.get(task_id) or {}
            execution = dict(task.get("execution") or {})
        execution.update({key: value for key, value in summary.items() if key != "stages"})
        _update(task_id, execution=execution, agent_workflow=summary,
                message=rag_web.STAGES.get(summary["workflow_status"], "正在完成报告与原文定位"))


def _rag_lock_for_task(task_id: str) -> tuple[str, threading.BoundedSemaphore]:
    """Return the bounded RAG slot pool for the task's account namespace."""
    capability = current_capability()
    owner = capability.owner if capability is not None else ""
    if not owner:
        with TASK_LOCK:
            owner = str((TASKS.get(task_id) or {}).get("user_id") or "anonymous")
    with _MULTI_AGENT_RAG_LOCKS_GUARD:
        lock = _MULTI_AGENT_RAG_LOCKS.setdefault(owner, threading.BoundedSemaphore(RAG_PER_ACCOUNT_CONCURRENCY))
    return owner, lock


def _run_multi_agent_rag_task(task_id: str, query: str, *, mode: str = "live", budget: int | None = None, pdf: Path | None = None,
                              time_policy: str | None = None) -> None:
    """Supervise the unchanged CLI core, with a separate index and bounded process tree."""
    _owner_namespace, rag_lock = _rag_lock_for_task(task_id)
    while not rag_lock.acquire(timeout=0.25):
        if _is_task_cancel_requested(task_id):
            return
        _update(task_id, status="queued", message="当前账号已有科研任务运行，正在等待本账号处理名额")
    process = None
    query_file = LOG_DIR / f"multi_agent_question_{task_id}.txt"
    context_file = LOG_DIR / f"multi_agent_context_{task_id}.json"
    try:
        if _is_task_cancel_requested(task_id):
            return
        query_file.write_text(query, encoding="utf-8")
        with TASK_LOCK:
            source_task = TASKS.get(task_id) or {}
            from multi_agent_report_contracts import report_budget, default_time_policy, is_soft_time_policy
            profile = source_task.get('report_profile', 'standard')
            report_config = report_budget(profile, time_budget=budget)
            budget = report_config['time_budget_seconds']
            time_policy = time_policy or default_time_policy(profile)
            context = source_task.get("conversation_context") or {}
            source_policy = source_task.get("source_policy")
            allow_public_search = source_task.get("public_search_allowed", False)
            pdf_parse_mode = source_task.get("pdf_parse_mode", "local")
            llama_cloud_consent = source_task.get("llama_cloud_consent", False)
        from multi_agent_sources import source_options
        sources = source_options(has_pdf=bool(pdf), policy=source_policy, allow_public=allow_public_search)
        followup = None
        if context.get("status") == "ready":
            context_file.write_text(json.dumps({"schema_version": "sciassistant.followup-context/v1",
                "previous_question": _redact_technical_log(str(context.get("previous_query") or ""), 1200),
                "previous_answer": _redact_technical_log(str(context.get("previous_answer") or ""), 6000),
                "paper_ids": list(context.get("paper_ids") or [])[:10],
                "evidence_policy": "context_only_retrieve_again"}, ensure_ascii=False), encoding="utf-8")
            followup = context_file
        _update(task_id, status="running", started_at=_now(), message="正在启动六角色 RAG 协作",
                execution={"workflow": rag_web.WORKFLOW, "launcher": "multi_agent_cli",
                           "mcp_lifecycle": "not_required", "model_call_limit": report_config['model_call_limit'], "model_calls": 0,
                           'report_profile': profile, 'report_budget_policy': report_config['policy'],
                           "time_budget_seconds": budget, "retrieval_mode": "hybrid",
                           "time_policy": time_policy, "time_budget_is_estimate": is_soft_time_policy(time_policy),
                           "research_start_cutoff_seconds": report_config['research_start_cutoff_seconds'],
                           "pdf_parse_mode": pdf_parse_mode, "llama_cloud_consent": llama_cloud_consent,
                           **sources,
                           "remote_requests_cancelled": False})
        deadline = time.monotonic() + budget
        options = {"start_new_session": True} if os.name != "nt" else {"creationflags": subprocess.CREATE_NO_WINDOW}
        source_kwargs = {"source_policy": "auto", "allow_public_search": True} if sources["source_policy"] == "auto" else {}
        if profile != 'standard':
            source_kwargs['report_profile'] = profile
        if pdf_parse_mode != "local":
            source_kwargs.update(pdf_parse_mode=pdf_parse_mode, llama_cloud_consent=llama_cloud_consent)
        worker_command = rag_web.command(task_id, query_file, mode=mode, budget=budget, context_file=followup, pdf=pdf,
                                         task_namespace=task_id, **source_kwargs)
        worker_command.extend(["--time-policy", time_policy])
        child_env = child_environment(rag_web.environment(task_namespace=task_id))
        # The task namespace isolates same-account storage and vector writes;
        # provider credentials remain account-scoped and are still shared only
        # through the encrypted capability captured for this task.
        base_collection = child_env.get("SCIASSISTANT_QDRANT_COLLECTION", "sciassistant_evidence")
        child_env["SCIASSISTANT_QDRANT_COLLECTION"] = f"{base_collection}_task_{task_id}"
        child_env["SCIASSISTANT_WORKSPACE"] = str(Path(child_env.get("SCIASSISTANT_WORKSPACE", ROOT / "workspace")) / "tasks" / task_id)
        child_env["PDF_PARSE_CACHE_DIR"] = str(Path(child_env.get("PDF_PARSE_CACHE_DIR", ROOT / "logs/pdf_cache")) / "tasks" / task_id)
        process = subprocess.Popen(worker_command,
                                   cwd=ROOT, env=child_env, stdout=subprocess.DEVNULL,
                                   stderr=subprocess.DEVNULL, **options)
        if os.name != "nt":
            process._sciassistant_process_group = process.pid
        with TASK_LOCK:
            _RETRIEVAL_PROCESSES[task_id] = process
        while process.poll() is None:
            if _is_task_cancel_requested(task_id):
                _stop_task_process(task_id, process, "cancel_requested")
                rag_web.sync_terminal(task_id, "cancelled", "USER_CANCELLED")
                return
            if time_policy == "hard-deadline/v1" and time.monotonic() >= deadline:
                _stop_task_process(task_id, process, "research_timeout")
                rag_web.sync_terminal(task_id, "timed_out", "WEB_RAG_TIMEOUT")
                _update(task_id, status="timed_out", failure_stage="research_timeout",
                        message="达到 360 秒研究预算；已停止本地任务，已完成的工件保留。",
                        answer="研究超过时间预算，未生成可核验的最终结论。请缩小问题范围后重试。")
                return
            _rag_progress(task_id)
            time.sleep(0.25)
        if _is_task_cancel_requested(task_id):
            rag_web.sync_terminal(task_id, "cancelled", "USER_CANCELLED")
            return
        data = rag_web.report(task_id)
        _rag_progress(task_id)
        # Reading/rendering the final report is part of the budget too. A CLI
        # can exit just before the deadline while Web publication crosses it.
        if time_policy == "hard-deadline/v1" and time.monotonic() >= deadline:
            rag_web.sync_terminal(task_id, "timed_out", "WEB_RAG_TIMEOUT")
            _update(task_id, status="timed_out", failure_stage="research_timeout", report_available=False,
                    message="达到 360 秒预算，报告未在时限内发布。",
                    answer="研究已超过时间预算，保留内部工件供检查，但未发布最终结论。")
            return
        status = data["status"]
        if data.get("pdf_parser_result"):
            _update(task_id, pdf_parser_result=data["pdf_parser_result"])
        published_claim_count = len(data.get("claims") or [])
        reference_count = len(data.get("references") or [])
        failure_code = str(data.get("failure_code") or "")
        if should_use_general_fallback(status, failure_code, published_claim_count, reference_count):
            reason = {
                "INSUFFICIENT_EVIDENCE": "证据覆盖不足",
                "NO_AUDITED_CLAIMS": "没有声明通过引用审查",
                "RETRIEVAL_SOURCE_UNREACHABLE": "文献来源不可达",
                "RETRIEVAL_SOURCE_RATE_LIMITED": "文献来源受到限流",
                "RETRIEVAL_SOURCE_DEADLINE": "文献检索未在等待预算内完成",
                "LOCAL_PDF_PARSE_FAILED": "PDF 未能完成解析",
                "LOCAL_PDF_TEXT_EMPTY": "PDF 没有可检索文本",
                "LOCAL_PDF_READ_FAILED": "PDF 原文读取失败",
                "MODEL_SCHEMA_REJECTED": "科研协作输出格式未完成",
                "MODEL_JSON_INVALID": "科研协作输出格式无效",
            }.get(failure_code, "当前没有可发布的证据声明")
            _update(task_id, status="needs_review", message=f"{reason}，正在切换通用回答",
                    failure_stage="evidence_fallback", fallback_reason=reason,
                    evidence_backed=False, report_available=False)
            _run_general_chat_task(task_id, query, fallback=True, fallback_reason=reason)
            return
        if process.returncode != 0 and status in rag_web.SUCCESS:
            raise ValueError("report publication failed")
        message = {"completed": "多智能体科研分析完成", "partial": "已生成有限回答：请核对证据边界",
                   "needs_review": "已生成待复核回答：存在证据或引用限制"}.get(status, "研究未完成，请查看证据包说明")
        _update(task_id, status=status, answer=data["direct_answer"], sections={"report": data["direct_answer"]},
                evidence_review={"coverage": data["coverage"], "coverage_status": status},
                paper_ids=sorted({row["paper_id"] for row in data["references"] if row.get("source") != "uploaded_pdf"}), message=message,
                report_available=True, failure_stage=None if status in rag_web.SUCCESS else "multi_agent_rag")
    except Exception as exc:
        app.logger.warning("RAG worker failed task_id=%s error_type=%s", task_id, type(exc).__name__)
        try:
            rag_web.sync_terminal(task_id, "failed", "WEB_RAG_EXECUTION_FAILED")
        except Exception:
            pass
        if not _is_task_cancel_requested(task_id):
            _update(task_id, status="needs_review", failure_stage="evidence_fallback",
                    message="科研检索链路异常，正在切换通用回答", fallback_reason="科研流水线未能完成",
                    evidence_backed=False, report_available=False)
            _run_general_chat_task(task_id, query, fallback=True, fallback_reason="科研流水线未能完成")
        else:
            _fail_task_safely(task_id, "multi_agent_rag", "新版 RAG 未能完成，请检查运行依赖或查看安全证据包。")
    finally:
        try:
            if process is not None and process.poll() is None:
                _stop_task_process(task_id, process, "worker_unwind")
        finally:
            with TASK_LOCK:
                _RETRIEVAL_PROCESSES.pop(task_id, None)
            for temporary in (query_file, context_file):
                try:
                    temporary.unlink(missing_ok=True)
                except OSError as exc:
                    app.logger.warning("RAG temporary cleanup failed task_id=%s error_type=%s", task_id, type(exc).__name__)
            rag_lock.release()


@app.get("/api/multi-agent/readyz")
def multi_agent_readiness():
    data = rag_web.readiness()
    return jsonify(data), 200 if data["ready"] else 503


def _rag_report_task(task_id: str):
    with TASK_LOCK:
        task = dict(TASKS.get(task_id) or {})
    if not task or task.get("processing_mode") != rag_web.MODE:
        return None, (jsonify({"error": "REPORT_NOT_FOUND"}), 404)
    if task.get("status") not in rag_web.TERMINAL_STATUSES:
        return None, (jsonify({"error": "REPORT_NOT_READY"}), 409)
    try:
        data = rag_web.report(task_id)
        # Cancellation/restart decisions must not revive a stale successful report.
        if data["status"] != task["status"]:
            return None, (jsonify({"error": "REPORT_NOT_AVAILABLE"}), 409)
        return data, None
    except FileNotFoundError:
        return None, (jsonify({"error": "REPORT_NOT_AVAILABLE"}), 404)
    except Exception as exc:
        return None, _safe_api_failure("rag_report", exc, status=409, code="REPORT_INTEGRITY_REJECTED")


@app.get("/api/tasks/<task_id>/report")
def multi_agent_report(task_id: str):
    data, error = _rag_report_task(task_id)
    return error if error else jsonify(data)


@app.get("/api/tasks/<task_id>/report/export")
def multi_agent_report_export(task_id: str):
    format_name = str(request.args.get("format", "html")).lower()
    if format_name not in {"md", "json", "html"}:
        return jsonify({"error": "INVALID_REPORT_FORMAT"}), 400
    data, error = _rag_report_task(task_id)
    if error:
        return error
    content, mimetype = rag_web.exported_report(data, format_name)
    return send_file(io.BytesIO(content), mimetype=mimetype, as_attachment=True,
                     download_name=f"sciassistant_rag_{task_id}.{format_name}")


@app.get("/api/tasks/<task_id>/report/assets/<path:name>")
def multi_agent_report_asset(task_id: str, name: str):
    _, error = _rag_report_task(task_id)
    if error:
        return error
    try:
        path = rag_web.asset(task_id, name)
        response = send_file(path, mimetype="application/pdf" if path.suffix == ".pdf" else "image/png")
        response.headers["Cache-Control"] = "no-store"
        return response
    except (OSError, ValueError):
        return jsonify({"error": "ASSET_NOT_FOUND"}), 404


def _provider_request_scope(func):
    from functools import wraps
    @wraps(func)
    def wrapper(*args, **kwargs):
        cap = request.environ.get('sciassistant.provider_credentials')
        if cap is not None and not isinstance(cap, ProviderCapability):
            return jsonify(error='INVALID_PROVIDER_CAPABILITY'), 403
        with provider_scope(cap):
            return func(*args, **kwargs)
    return wrapper


@app.post("/api/tasks")
@_provider_request_scope
def create_task():
    parsed_body = request.get_json(silent=True)
    body = parsed_body if isinstance(parsed_body, dict) else {}
    form_query = request.form.get("query")
    raw_query = form_query if form_query is not None else body.get("query", "")
    if raw_query is None:
        raw_query = ""
    if not isinstance(raw_query, str):
        return jsonify({"error": "问题必须是文本字符串"}), 400
    query = raw_query.strip()
    if len(query) > MAX_QUERY_LENGTH:
        return jsonify({
            "error": f"问题过长，最多允许 {MAX_QUERY_LENGTH} 个字符",
            "max_query_length": MAX_QUERY_LENGTH,
        }), 413
    # Reserved metadata for the upcoming multi-turn workflow. These fields
    # are intentionally inert for now, so existing requests remain single-turn.
    conversation_id = str(request.form.get("conversation_id") or body.get("conversation_id") or "").strip()
    parent_task_id = str(request.form.get("parent_task_id") or body.get("parent_task_id") or "").strip()
    context_policy = str(request.form.get("context_policy") or body.get("context_policy") or "single_turn").strip()
    pdf_parse_mode = str(
        request.form.get("pdf_parse_mode") or body.get("pdf_parse_mode") or "local"
    ).strip().lower()
    processing_mode = str(
        request.form.get("processing_mode") or body.get("processing_mode") or ""
    ).strip().lower()
    if current_capability() and processing_mode in {'literature_answer', 'multi_agent_literature', 'arxiv_paper'}:
        return jsonify(error='LEGACY_MODE_NOT_USER_ISOLATED', message='请选择已隔离的新版科研模式。'), 410
    # A user-requested lower-standard re-search of the SAME question (the
    # "降低标准继续检索文献" button on a degraded/insufficient answer).
    relax_gate = bool(request.form.get("relax_gate") or body.get("relax_gate"))
    upload = request.files.get("pdf")
    source_id = str(request.form.get("pdf_source_task_id") or body.get("pdf_source_task_id") or "").strip()
    pdf_source = request.environ.get("sciassistant.pdf_source")
    library_id = request.form.get("library_file_id") if request.form else body.get("library_file_id")
    library_source = request.environ.get("sciassistant.library_source")
    if library_id is not None:
        if (upload or source_id or processing_mode not in {rag_web.MODE, rag_web.PDF_MODE}
                or not isinstance(library_source, dict) or library_source.get("file_id") != library_id):
            return jsonify(error="LIBRARY_SOURCE_NOT_FOUND", message="资料不存在或无权选用。"), 404
    reused_pdf = None
    if source_id:
        # A body/header cannot grant this capability; it is supplied only by
        # the owner/conversation-checked in-process account gateway.
        if (upload or processing_mode not in {"pdf_local", rag_web.MODE, rag_web.PDF_MODE} or not isinstance(pdf_source, dict)
                or pdf_source.get("source_task_id") != source_id):
            return jsonify(error="PDF_SOURCE_NOT_FOUND", message="该会话的 PDF 不可用，请重新上传。"), 404
        try:
            from science_pdf_sessions import pdf_path
            reused_pdf = pdf_path(UPLOAD_DIR, source_id, pdf_source.get("filename"))
        except (OSError, ValueError):
            return jsonify(error="PDF_SOURCE_NOT_FOUND", message="该会话的 PDF 不可用，请重新上传。"), 404
    has_pdf = bool(upload or reused_pdf or library_source)
    if processing_mode == rag_web.PDF_MODE:
        if not has_pdf:
            return jsonify(error="LOCAL_PDF_REQUIRED", message="请上传 PDF，或选择本会话已保存的 PDF。"), 400
        processing_mode = rag_web.MODE
    source_policy = request.form.get("source_policy") if request.form else body.get("source_policy")
    allow_public = request.form.get("allow_public_search", "false") if request.form else body.get("allow_public_search", False)
    if request.form and allow_public in {"true", "1", "false", "0"}:
        allow_public = allow_public in {"true", "1"}
    sources = None
    selected_report_profile = request.form.get('report_profile', 'standard') if request.form else body.get('report_profile', 'standard')
    from multi_agent_report_contracts import report_budget
    try:
        report_budget(selected_report_profile)
    except ValueError:
        return jsonify(error='REPORT_PROFILE_INVALID', message='报告档位无效，请选择standard或enhanced。'), 400
    if selected_report_profile != 'standard' and processing_mode != rag_web.MODE:
        return jsonify(error='REPORT_PROFILE_REQUIRES_MULTI_AGENT', message='增强报告仅用于多智能体科研任务。'), 400
    if processing_mode == rag_web.MODE:
        from multi_agent_sources import source_options
        # A new multi-agent conversation without an uploaded PDF is a public
        # literature question.  Public search is therefore the default for
        # this route; the explicit consent checkbox is only required for the
        # PDF+public hybrid route.  General chat is converted to its direct
        # route immediately below and does not retain this permission.
        if not has_pdf and source_policy is None and allow_public is False:
            allow_public = True
        try:
            sources = source_options(has_pdf=has_pdf, policy=source_policy, allow_public=allow_public, question=query)
        except ValueError as error:
            return jsonify(error=str(error), message="资料来源设置无效。PDF 自动检索需要明确允许外部查询；仅本文模式不会联网。"), 400
    elif source_policy is not None or allow_public is not False:
        return jsonify(error="SOURCE_POLICY_REQUIRES_MULTI_AGENT", message="来源策略仅用于多智能体科研任务。"), 400
    if has_pdf and processing_mode == rag_web.MODE and not query:
        query = "请基于这份 PDF，概括研究问题、方法、主要结果与局限。"
    if not query and not has_pdf:
        return jsonify({"error": "请输入 arXiv 分析请求或上传 PDF"}), 400
    if upload and (not upload.filename or not upload.filename.lower().endswith(".pdf")):
        return jsonify({"error": "目前只支持 PDF 文件"}), 400
    if upload and (len(upload.filename) > 255 or "/" in upload.filename or "\\" in upload.filename
                   or any(ord(c) < 32 for c in upload.filename)):
        return jsonify(error="INVALID_PDF_FILENAME", message="PDF 文件名无效，请重命名后上传。"), 400
    if pdf_parse_mode not in {"local", "llama_full", "hybrid"}:
        return jsonify({"error": "不支持的 PDF 解析链路"}), 400
    query_mode_by_processing = {
        "arxiv_paper": "paper_evidence",
        "literature_answer": "science_literature",
        "multi_agent_literature": "multi_agent_literature",
        "multi_agent_rag": "multi_agent_rag",
        "general_answer": "direct_llm",
    }
    # Validate the original source/parser permissions before selecting a fast
    # path. A greeting cannot bypass invalid consent or an owned PDF check.
    conversation_context = _build_followup_context(parent_task_id, conversation_id)
    if conversation_context.get("status") == "rejected":
        return jsonify({"error": "无法继承上一轮上下文：" + str(conversation_context.get("reason"))}), 409
    route = request_route(query, has_upload=has_pdf)
    if processing_mode == rag_web.MODE:
        consent = request.form.get("llama_cloud_consent", "false") if request.form else body.get("llama_cloud_consent", False)
        if request.form and consent in {"true", "false"}:
            consent = consent == "true"
        from multi_agent_local_pdf import pdf_parser_options
        try:
            pdf_parser_options(has_pdf, pdf_parse_mode, consent)
        except ValueError as error:
            return jsonify(error=str(error), message="Llama 解析需有 PDF，并单独确认本轮将 PDF 发送至 LlamaCloud；补查公开文献许可不能代替此确认。"), 400
        if route['route'] == 'direct_answer':
            # The selector configures research only. A greeting still uses the
            # normal fast route rather than failing because enhanced was chosen.
            selected_report_profile = 'standard'
            processing_mode = 'general_answer'
            sources = None
            pdf_parse_mode = 'local'
    if processing_mode == rag_web.MODE:
        if not rag_web.readiness()["ready"]:
            return jsonify({"error": "MULTI_AGENT_RAG_NOT_READY", "message": "请先安装 RAG 依赖并完成本地模型自检。"}), 503
    if has_pdf and processing_mode != rag_web.MODE:
        # An upload is a PDF-analysis task, while its parse mode remains the
        # user's explicit local/Llama/hybrid choice.
        processing_mode = "pdf_local"
        query_mode = None
    else:
        if processing_mode not in query_mode_by_processing:
            return jsonify({"error": "未上传 PDF 时请选择有效的处理方式"}), 400
        query_mode = query_mode_by_processing[processing_mode]
    missing_settings = _missing_task_configuration(pdf_parse_mode)
    if missing_settings:
        labels = [API_KEY_FIELDS[name]["label"] for name in missing_settings]
        return jsonify({
            "error": "请先在页面顶部完成 API 配置：" + "、".join(labels),
            "error_code": "USER_PROVIDER_KEY_REQUIRED" if current_capability() else "MODEL_CONFIGURATION_REQUIRED",
            "message": "请在“我的 API Keys”填写当前账号自己的密钥；不会使用其他账号的密钥。",
            "missing_settings": missing_settings,
        }), 400
    task_id = uuid.uuid4().hex[:12]
    now = _now()
    query_intent = route['query_intent']
    # A relaxed-gate re-search goes straight through without the scope
    # clarification step; it is a re-run of the question already asked.
    clarification = build_clarification_request(query) if (processing_mode == "literature_answer" and not relax_gate and not query_intent.get("is_general_chat")) else None
    task_mode = _describe_task_mode(query, has_pdf, pdf_parse_mode, processing_mode)
    task = {
        "id": task_id,
        "query": query,
        "status": "searching" if clarification else "queued",
        "message": "正在先检索候选文献" if clarification else "任务已排队",
        "created_at": now,
        "updated_at": now,
        "elapsed_seconds": 0.0,
        "pdf_parse_mode": pdf_parse_mode,
        "llama_cloud_consent": consent if processing_mode == rag_web.MODE else False,
        "processing_mode": processing_mode,
        'report_profile': selected_report_profile,
        "query_mode": query_mode,
        "source_scope": sources["source_scope"] if sources else None,
        "source_policy": sources["source_policy"] if sources else None,
        "public_search_allowed": sources["public_search_allowed"] if sources else False,
        "source_policy_reason": sources.get("source_policy_reason") if sources else None,
        "task_mode": task_mode,
        "report_title": task_mode["report_title"],
        "query_intent": query_intent,
        "request_route": {key: value for key, value in route.items() if key != 'query_intent'},
        "conversation_id": conversation_id or None,
        "parent_task_id": parent_task_id or None,
        "context_policy": context_policy or "single_turn",
        "conversation_context": conversation_context,
        "relax_gate": relax_gate,
        "state_timeline": [{
            "timestamp": now,
            "from": None,
            "to": "searching" if clarification else "queued",
            "message": "正在先检索候选文献" if clarification else "任务已排队",
        }],
    }
    with TASK_LOCK:
        if current_capability():
            _TASK_CREDENTIALS[task_id] = current_capability()
            task['user_id'] = current_capability().owner
        TASKS[task_id] = task
        _persist_task_locked(task)
    app.logger.info(
        "task_created task_id=%s request_id=%s initial_status=%s processing_mode=%s",
        task_id,
        str(getattr(g, "request_id", "") or "none"),
        task["status"],
        processing_mode,
    )
    if clarification:
        _enqueue_retrieval_task(task_id, _prepare_query_task, task_id, query, pdf_parse_mode, query_mode)
        with TASK_LOCK:
            task = dict(TASKS.get(task_id) or task)
        return jsonify({"task": task}), 202
    if has_pdf:
        destination = reused_pdf
        attachment = dict(pdf_source) if reused_pdf else {
            "source_task_id": task_id, "filename": library_source["filename"] if library_source else upload.filename,
        }
        if library_source:
            destination = UPLOAD_DIR / f"{task_id}_{secure_filename(library_source['filename'])}"
            try:
                from research_library import copy_pdf
                digest = copy_pdf(library_source["path"], destination)
                _update(task_id, library_file_id=library_id, library_file_sha256=digest)
            except (OSError, ValueError):
                _fail_task_safely(task_id, "library_copy", "资料 PDF 保存失败，请重新选用文件。")
                destination = None
        if reused_pdf:
            # Inherit only a trusted server capability, not a client file ID.
            source_file = pdf_source.get("library_file_id")
            if source_file:
                _update(task_id, library_file_id=source_file)
        if upload:
            destination = UPLOAD_DIR / f"{task_id}_{secure_filename(upload.filename)}"
            try:
                upload.save(destination)
            except Exception:  # noqa: BLE001 - no durable binding for a failed save
                _fail_task_safely(task_id, "upload_save", "PDF 保存失败，请检查文件后重试")
                destination = None
        if destination is not None:
            if processing_mode == rag_web.MODE:
                from multi_agent_local_pdf import validate_pdf_input
                try:
                    validate_pdf_input(destination)
                except (OSError, ValueError):
                    _fail_task_safely(task_id, "pdf_input", "PDF 无效或超过 30MiB，本轮未调用智能体。")
                    destination = None
        if destination is not None:
            _update(task_id, pdf_attachment=attachment)
            if processing_mode == rag_web.MODE:
                _enqueue_retrieval_task(task_id, _run_multi_agent_rag_task, task_id, query, pdf=destination)
            else:
                _start_background_task(
                    task_id, _parse_upload_task, task_id, destination, pdf_parse_mode, stage="pdf_parse",
                )
    elif processing_mode == rag_web.MODE:
        _enqueue_retrieval_task(task_id, _run_multi_agent_rag_task, task_id, query)
    elif processing_mode == "general_answer" or query_intent.get("is_general_chat"):
        # Non-academic request: answer directly, skip retrieval entirely.
        _start_background_task(task_id, _run_general_chat_task, task_id, query, stage="general_chat")
    else:
        _enqueue_retrieval_task(
            task_id, _run_query_task, task_id, query, pdf_parse_mode, query_mode, relax_gate,
        )
    with TASK_LOCK:
        task = dict(TASKS.get(task_id) or task)
    return jsonify({"task": task}), 202


@app.post("/api/tasks/<task_id>/clarify")
@_provider_request_scope
def clarify_task(task_id: str):
    """Accept a Web clarification choice with this account's current capability."""
    if current_capability():
        return jsonify(error='LEGACY_MODE_NOT_USER_ISOLATED', message='旧共享任务不再恢复执行。'), 410
    body = request.get_json(silent=True) or {}
    choice = str(body.get("choice") or "").strip()
    custom_scope = str(body.get("custom_scope") or "").strip()
    with TASK_LOCK:
        task = TASKS.get(task_id)
    if not task:
        return jsonify({"error": "任务不存在"}), 404
    if task.get("status") != "needs_clarification":
        return jsonify({"error": "任务不在等待澄清状态"}), 409
    if choice == "custom" and not custom_scope:
        return jsonify({"error": "自定义研究范围不能为空"}), 400

    if choice != "custom" and not custom_scope:
        for option in (task.get("clarification") or {}).get("options", []):
            if isinstance(option, dict) and option.get("id") == choice:
                custom_scope = str(option.get("scope") or option.get("label") or "").strip()
                break
    resolved_query = apply_clarification_choice(task.get("query", ""), choice, custom_scope)
    _update(task_id, status="queued", query=resolved_query, message="任务已排队，正在启动检索")
    _enqueue_retrieval_task(
        task_id,
        _run_query_task,
        task_id,
        resolved_query,
        task.get("pdf_parse_mode", "local"),
        task.get("query_mode"),
    )
    with TASK_LOCK:
        updated = dict(TASKS.get(task_id, {}))
    return jsonify({"task": updated}), 202


@app.post("/api/tasks/<task_id>/cancel")
def cancel_task(task_id: str):
    task, error = _cancel_task(task_id)
    if error:
        return jsonify({"error": error}), 404
    return jsonify({"task": task, "message": "任务已取消"}), 200


@app.get("/api/tasks/<task_id>")
def task_status(task_id: str):
    with TASK_LOCK:
        task = TASKS.get(task_id)
    if not task:
        return jsonify({"error": "任务不存在"}), 404
    if task.get("status") in {"queued", "running", "searching"}:
        _update(task_id)
        with TASK_LOCK:
            task = TASKS.get(task_id)
        diagnostics_path = task.get("diagnostics_path") if task else None
        if diagnostics_path:
            existing = (task.get("timeline") or [])[:1]
            _update(task_id, timeline=existing + _read_diagnostic_events(Path(diagnostics_path)))
            with TASK_LOCK:
                task = TASKS.get(task_id)
        if task and task.get("processing_mode") == "multi_agent_literature":
            summary = _multi_agent_workflow_summary(task_id)
            if summary:
                stage = str(summary.get("workflow_status") or "")
                execution = dict(task.get("execution") or {})
                execution.update({
                    "workflow": "bounded_multi_agent_literature_v1",
                    "time_budget_seconds": 360,
                    "model_call_limit": summary["model_call_limit"],
                    "model_calls": summary["model_calls"],
                    "workflow_status": stage,
                })
                if summary.get("failure_code"):
                    execution["failure_code"] = summary["failure_code"]
                _update(
                    task_id,
                    execution=execution,
                    agent_workflow=summary,
                    message=_MULTI_AGENT_STAGE_MESSAGES.get(stage, "多 Agent 协作：正在执行受限工作流"),
                )
                with TASK_LOCK:
                    task = TASKS.get(task_id)
        if task and task.get("processing_mode") == rag_web.MODE:
            _rag_progress(task_id)
            with TASK_LOCK:
                task = TASKS.get(task_id)
    return jsonify(task)


_EVIDENCE_SECRET_KEY_RE = re.compile(r"(?i)(authorization|api[_ -]?key|token|secret|password)")


def _evidence_build_revision() -> str:
    """Return a traceable build revision without making Git a runtime requirement."""
    configured = str(os.getenv("SCIASSISTANT_BUILD_REVISION") or "").strip()
    if configured:
        return configured[:128]
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True,
            text=True, check=False, timeout=1,
        )
        revision = result.stdout.strip()
        if re.fullmatch(r"[0-9a-f]{40}", revision):
            return revision
    except (OSError, subprocess.SubprocessError):
        pass
    return "unavailable"


def _sanitize_evidence_value(value, *, key: str = ""):
    """Recursively redact bounded, user-downloadable acceptance evidence."""
    if _EVIDENCE_SECRET_KEY_RE.search(key):
        return "[REDACTED]"
    if isinstance(value, dict):
        return {str(item_key): _sanitize_evidence_value(item_value, key=str(item_key))
                for item_key, item_value in value.items()}
    if isinstance(value, (list, tuple)):
        return [_sanitize_evidence_value(item) for item in value[:200]]
    if isinstance(value, str):
        return _redact_technical_log(value, 4_000)
    if isinstance(value, (int, float, bool)) or value is None:
        return value
    return _redact_technical_log(str(value), 4_000)


def _task_evidence_payload(task: dict) -> dict:
    """Build a compact, portable proof bundle for any task lifecycle state."""
    task_id = str(task.get("id") or task.get("task_id") or "unknown")
    metadata_keys = (
        "status", "message", "created_at", "queued_at", "started_at", "cancelled_at",
        "updated_at", "elapsed_seconds", "returncode", "cancel_requested", "processing_mode", "pdf_parse_mode",
        "llama_cloud_consent", "pdf_parser_result",
        "query_mode", "relax_gate", "task_mode", "source_scope", "source_policy", "public_search_allowed", "report_profile",
    )
    metadata = {key: task.get(key) for key in metadata_keys if key in task}
    payload = {
        "schema": "sciassistant.acceptance-evidence/v1",
        "generated_at": _now(),
        "build": {"revision": _evidence_build_revision(),
                  "revision_semantics": "export_time_checkout_or_configured_revision",
                  "exporter_runtime": _RESEARCH_RUNTIME.snapshot()},
        "task": {
            "id": task_id,
            "report_title": task.get("report_title") or "科研任务",
            "query": task.get("query") or "",
            **metadata,
        },
        "lifecycle": {
            "state_timeline": task.get("state_timeline") or [],
            "cancellation": task.get("cancellation") or {},
            "execution": task.get("execution") or {},
        },
        "diagnostic_summary": {
            "timeline": task.get("timeline") or [],
            "answer_quality_summary": task.get("answer_quality_summary"),
            "parse_status": (task.get("sections") or {}).get("parse_status"),
        },
        "limitations": [
            "证据包记录任务状态和本地进程清理结果；partial/failed 不能当作进程树已停止，也不能替代浏览器截图/录屏。",
            "本地 CLI 清理不取消共享 MCP 服务或供应商已接受的在途调用；remote_mcp_cancelled=false，不保证费用即时停止。",
            "队列和活动子进程仍为单进程；终态任务可由快照恢复，重启中断活动任务且不自动重跑。",
        ],
    }
    return _sanitize_evidence_value(payload)


def _task_evidence_markdown(payload: dict) -> str:
    """Render the same evidence payload for non-technical acceptance review."""
    task = payload.get("task") or {}
    lifecycle = payload.get("lifecycle") or {}
    lines = [
        f"# SciAssistant 验收证据包：{task.get('report_title') or '科研任务'}",
        "",
        "> 此文件是任务生命周期的后端证据。所有凭证、Authorization、Token、密码和绝对运行路径均已脱敏或排除。",
        "",
        "## 核验摘要",
        "",
        f"- 任务 ID：`{task.get('id') or 'unknown'}`",
        f"- 最终/当前状态：`{task.get('status') or 'unknown'}`",
        f"- 取消已请求：`{bool((lifecycle.get('cancellation') or {}).get('requested_at'))}`",
        f"- 导出时间：`{payload.get('generated_at') or ''}`",
        "",
        "## 完整证据 JSON",
        "",
        "```json",
        json.dumps(payload, ensure_ascii=False, indent=2),
        "```",
        "",
        "## 如何配合浏览器验收",
        "",
        "1. 在停止前后各截一张图，证明“停止”按钮/加载占位及 Toast 的变化。",
        "2. 下载本证据包，核对 `task.status`、`lifecycle.state_timeline` 与 `lifecycle.cancellation`。",
        "3. 若需自动分析，可下载同一地址的 `format=json` 版本。",
    ]
    return "\n".join(lines)


@app.get("/api/tasks/<task_id>/evidence")
def export_task_evidence(task_id: str):
    """Download secret-redacted acceptance evidence for active or finished tasks."""
    export_format = str(request.args.get("format") or "md").lower()
    if export_format not in {"md", "json"}:
        return jsonify({"error": "format must be md or json"}), 400
    with TASK_LOCK:
        task = dict(TASKS.get(task_id) or {})
    if not task:
        return jsonify({"error": "任务不存在或服务已重启，无法导出证据包"}), 404
    task.setdefault("task_id", task_id)
    payload = _task_evidence_payload(task)
    if export_format == "json":
        content = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
        mime_type = "application/json"
    else:
        content = _task_evidence_markdown(payload).encode("utf-8")
        mime_type = "text/markdown; charset=utf-8"
    return send_file(
        io.BytesIO(content),
        mimetype=mime_type,
        as_attachment=True,
        download_name=f"sciassistant_evidence_{task_id}.{export_format}",
    )


def _task_export_markdown(task: dict) -> str:
    """Build a user-facing report without exposing raw retrieval diagnostics."""
    labels = {
        "report": "科研分析报告",
        "source_extract": "解析证据摘要",
        "answer_completeness": "回答完整性说明",
        "citation_check": "引用核验",
        "evidence_ledger": "证据账本",
        "configuration_notice": "配置与凭证提示",
        "partial_failure": "部分解析失败说明",
        "parse_status": "PDF 解析状态报告",
        "references": "参考文献",
    }
    sections = task.get("sections") or {}
    ordered_keys = [
        "report", "source_extract", "answer_completeness", "citation_check",
        "evidence_ledger", "configuration_notice", "partial_failure",
        "parse_status", "references",
    ]
    parts = [f"# {task.get('report_title') or 'SciAssistant 科研报告'}"]
    for key in ordered_keys:
        value = str(sections.get(key) or "").strip()
        if value:
            parts.append(f"## {labels[key]}\n\n{value}")
    if len(parts) == 1:
        answer = str(task.get("answer") or "").strip()
        if answer:
            parts.append("## 科研分析报告\n\n" + answer)
    return "\n\n".join(parts).strip()


def _debug_artifact_text(path_value: str | Path | None, *, limit: int = 600_000) -> tuple[str, str]:
    """Read a task artifact for the debug export without exposing secrets."""
    if not path_value:
        return "", "未记录路径"
    path = Path(path_value)
    try:
        if not path.is_file():
            return "", "文件不存在"
        raw = path.read_text(encoding="utf-8", errors="replace")
        return _redact_technical_log(raw, limit), f"已读取调试文件，字符数：{len(raw)}"
    except OSError as exc:
        app.logger.error("读取任务调试文件失败: %s", type(exc).__name__)
        return "", f"读取失败：{type(exc).__name__}"


def _debug_json_block(value: object, *, limit: int = 600_000) -> str:
    """Serialize structured task data in a bounded, Markdown-safe form."""
    try:
        text = json.dumps(value, ensure_ascii=False, indent=2, default=str)
    except (TypeError, ValueError) as exc:
        app.logger.error("序列化任务调试数据失败: %s", type(exc).__name__)
        text = json.dumps({"serialization_error": type(exc).__name__}, ensure_ascii=False, indent=2)
    return _redact_technical_log(text, limit)


def _task_debug_markdown(task: dict) -> str:
    """Export all useful, secret-redacted task execution evidence as Markdown."""
    task_id = str(task.get("id") or task.get("task_id") or "unknown")
    lines = [
        f"# SciAssistant 完整调试导出：{task.get('report_title') or '科研任务'}",
        "",
        "> 该文件用于排查检索、规划、回答和任务状态问题。内容包含运行过程信息；凭证、Authorization、Token、密码和图片数据已脱敏。",
        "",
        "## 任务元数据",
        "",
        "```json",
        _debug_json_block({key: value for key, value in task.items()
                           if key not in {"output", "sections", "timeline"}}),
        "```",
        "",
        "## 用户问题",
        "",
        str(task.get("query") or "（未记录）"),
        "",
        "## 最终回答",
        "",
        str(task.get("answer") or "（未提取到最终回答）"),
        "",
        "## 原始任务输出（脱敏）",
        "",
        "```text",
        _redact_technical_log(str(task.get("output") or "（未记录原始任务输出）")),
        "```",
        "",
        "## 报告分段",
        "",
        "```json",
        _debug_json_block(task.get("sections") or {}),
        "```",
        "",
        "## 任务时间线",
        "",
        "```json",
        _debug_json_block(task.get("timeline") or []),
        "```",
        "",
        "## 查询与证据诊断",
        "",
        "```json",
        _debug_json_block({
            "query_intent": task.get("query_intent"),
            "answer_structure_check": task.get("answer_structure_check"),
            "answer_quality_summary": task.get("answer_quality_summary"),
            "search_diagnostics": task.get("search_diagnostics"),
            "conversation_context": task.get("conversation_context"),
        }),
        "```",
    ]

    artifacts = [
        ("完整运行日志（脱敏）", task.get("log")),
        ("诊断事件 JSONL（脱敏）", task.get("diagnostics_path")),
        ("预检索结果", LOG_DIR / f"web_task_{task_id}.prefetch.json"),
        ("追问上下文快照", LOG_DIR / f"web_task_{task_id}.followup.json"),
    ]
    for title, path in artifacts:
        content, note = _debug_artifact_text(path)
        lines.extend(["", f"## {title}", "", f"<!-- {note} -->"])
        if content:
            fence = "json" if str(path).lower().endswith((".json", ".jsonl")) else "text"
            lines.extend([f"```{fence}", content, "```"])
        else:
            lines.append(f"（{note}）")

    lines.extend([
        "",
        "## 调试导出说明",
        "",
        "- `状态`、`returncode`、耗时和时间线用于判断任务是否完整结束。",
        "- 规划、查询、来源状态、候选论文和语义判定优先查看诊断 JSONL 与预检索结果。",
        "- 运行日志保留命令输出和异常上下文，但已移除凭证、Authorization、Token、密码及图片载荷。",
    ])
    return "\n".join(lines).strip()


@app.get("/api/tasks/<task_id>/export")
def export_task_report(task_id: str):
    """Download a completed task as Markdown or a rendered PDF."""
    export_format = str(request.args.get("format") or "pdf").lower()
    export_detail = str(request.args.get("detail") or "summary").lower()
    if export_format not in {"md", "pdf"}:
        return jsonify({"error": "format must be md or pdf"}), 400
    if export_detail not in {"summary", "debug"}:
        return jsonify({"error": "detail must be summary or debug"}), 400
    if export_detail == "debug" and export_format != "md":
        return jsonify({"error": "debug detail is only available for Markdown"}), 400
    with TASK_LOCK:
        task = dict(TASKS.get(task_id) or {})
    if not task:
        return jsonify({"error": "任务不存在或服务已重启，无法导出"}), 404
    if task.get("status") not in rag_web.SUCCESS:
        return jsonify({"error": "任务尚未完成，暂不能导出"}), 409
    task.setdefault("task_id", task_id)
    markdown = _task_debug_markdown(task) if export_detail == "debug" else _task_export_markdown(task)
    if not markdown:
        return jsonify({"error": "任务没有可导出的报告内容"}), 409
    export_dir = LOG_DIR / "exports" / task_id
    try:
        exported = export_report_files(markdown, export_dir, basename="sciassistant_report", formats=export_format)
        file_path = Path(exported["markdown" if export_format == "md" else "pdf"])
    except Exception as exc:
        return _safe_api_failure("export_task_report", exc)
    suffix = "_debug" if export_detail == "debug" else ""
    return send_file(file_path, as_attachment=True, download_name=f"sciassistant_{task_id}{suffix}.{export_format}")


if __name__ == "__main__":
    app.run(host=os.getenv("WEB_HOST", "127.0.0.1"), port=int(os.getenv("WEB_PORT", "5050")), debug=False)
