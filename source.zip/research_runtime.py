"""Shell-free research launch contract. Shared MCP is never a task child."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

import requests

ROOT = Path(__file__).resolve().parent
MCP_UNAVAILABLE_MESSAGE = "科研工具服务暂时不可用，请联系管理员启动独立 MCP 服务后重试"


class ResearchDependencyError(RuntimeError):
    """Public-safe dependency failure, without private URLs or exceptions."""


def research_command(arguments: list[str]) -> list[str]:
    return [sys.executable, "-u", str(ROOT / "deepdiver_v2" / "cli" / "demo.py"), *arguments]


def research_environment() -> dict[str, str]:
    environment = os.environ.copy()
    environment.update({"PYTHONIOENCODING": "utf-8", "PYTHONUTF8": "1",
                        "PYTHONUNBUFFERED": "1", "MCP_USE_STDIO": "false"})
    environment["MCP_SERVER_URL"] = environment.get("MCP_SERVER_URL") or "http://127.0.0.1:6274/mcp"
    return environment


def requires_shared_mcp(arguments: list[str]) -> bool:
    # These deterministic CLI routes use local tools/direct model requests.
    # Unknown/automatic routes may construct MCP-backed agents.
    if any(flag in arguments for flag in ("--help", "-h", "--config-only", "-c", "--create-env", "-e")):
        return False
    mode = "auto"
    for index, argument in enumerate(arguments):
        if argument == "--query-mode" and index + 1 < len(arguments):
            mode = arguments[index + 1]
        elif argument.startswith("--query-mode="):
            mode = argument.partition("=")[2]
    return mode not in {"direct_llm", "science_literature"}


def check_shared_mcp(environment: dict[str, str]) -> None:
    """Probe only health; no auth forwarding, redirects, auto-start, or tools."""
    try:
        endpoint = urlsplit(environment["MCP_SERVER_URL"])
        if endpoint.scheme not in {"http", "https"} or not endpoint.hostname or endpoint.username or endpoint.password:
            raise ValueError("Invalid service endpoint")
        health_url = urlunsplit((endpoint.scheme, endpoint.netloc,
                               endpoint.path.rstrip("/").rsplit("/", 1)[0] + "/health", "", ""))
        with requests.Session() as session:
            # No netrc credentials or ambient HTTP proxies for private health.
            session.trust_env = False
            with session.get(health_url, timeout=(1, 2), allow_redirects=False, stream=True) as response:
                if response.status_code != 200:
                    raise ValueError("Unhealthy dependency")
                payload = response.raw.read(65537)
                if len(payload) > 65536:
                    raise ValueError("Oversized health response")
                if json.loads(payload).get("status") != "healthy":
                    raise ValueError("Unhealthy dependency")
    except Exception:
        raise ResearchDependencyError(MCP_UNAVAILABLE_MESSAGE) from None
