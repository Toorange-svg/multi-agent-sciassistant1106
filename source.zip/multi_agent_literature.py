"""Workflow-first orchestration for the future multi-agent literature mode.

Role adapters are deliberately plain callables.  They receive only validated,
structured snapshots and return a structured result; they never receive the
workflow store, provider credentials, a prompt transcript, or another role.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Mapping, Protocol

from multi_agent_workflow import WorkflowBudgetExceeded, WorkflowError, WorkflowStore, validate_artifact


class PlannerRole(Protocol):
    def __call__(self, question: Mapping[str, Any]) -> Mapping[str, Any]: ...


class RetrievalRole(Protocol):
    def __call__(self, group: Mapping[str, Any]) -> Mapping[str, Any]: ...


class ReviewerRole(Protocol):
    def __call__(self, plan: Mapping[str, Any], evidence_set: Mapping[str, Any]) -> Mapping[str, Any]: ...


class GapAnalysisRole(Protocol):
    def __call__(self, plan: Mapping[str, Any], review: Mapping[str, Any], evidence_set: Mapping[str, Any],
                 round_number: int) -> Mapping[str, Any]: ...


class WriterRole(Protocol):
    def __call__(self, question: Mapping[str, Any], review: Mapping[str, Any], evidence_set: Mapping[str, Any],
                 prior_audit: Mapping[str, Any] | None = None) -> Mapping[str, Any]: ...


class AuditorRole(Protocol):
    def __call__(self, draft: Mapping[str, Any], review: Mapping[str, Any]) -> Mapping[str, Any]: ...


@dataclass(frozen=True)
class LiteratureRoles:
    planner: PlannerRole
    retriever: RetrievalRole
    reviewer: ReviewerRole
    writer: WriterRole
    auditor: AuditorRole
    gap_analyst: GapAnalysisRole | None = None


def _safe_failure_code(exc: Exception) -> str:
    if isinstance(exc, WorkflowBudgetExceeded):
        return "WORKFLOW_BUDGET_EXCEEDED"
    if isinstance(exc, WorkflowError):
        return "WORKFLOW_CONTRACT_REJECTED"
    return "WORKFLOW_ROLE_FAILED"


class LiteratureWorkflowCoordinator:
    """Fixed order coordinator with bounded evidence recovery and one writer revision."""

    MAX_EVIDENCE_RECOVERY_ROUNDS = 1
    MAX_INITIAL_QUERIES_PER_GROUP = 2
    MAX_RECOVERY_QUERIES = 2
    FINALIZATION_RESERVE_SECONDS = 90

    def __init__(self, store: WorkflowStore, roles: LiteratureRoles):
        self._store = store
        self._roles = roles

    def _model_role(self, run_id: str, role_name: str, callback: Callable[..., Mapping[str, Any]], *args) -> Mapping[str, Any]:
        self._store.reserve_model_call(run_id, role_name)
        return callback(*args)

    @staticmethod
    def _ensure_draft_is_within_review(draft: Mapping[str, Any], review: Mapping[str, Any]) -> None:
        permitted = set(review["allowed_evidence_ids"])
        for claim in draft["claim_evidence_map"]:
            if not set(claim["evidence_ids"]).issubset(permitted):
                raise WorkflowError("draft cites evidence not approved by reviewer")
        if review["coverage_status"] == "partial" and draft["coverage_status"] != "partial":
            raise WorkflowError("partial evidence review requires partial answer")

    @staticmethod
    def _ensure_audit_matches_draft(audit: Mapping[str, Any], draft: Mapping[str, Any], review: Mapping[str, Any]) -> None:
        draft_claims = {entry["claim_id"] for entry in draft["claim_evidence_map"]}
        audited_claims = {entry["claim_id"] for entry in audit["claim_results"]}
        if not audited_claims.issubset(draft_claims):
            raise WorkflowError("audit references an unknown claim")
        approved = set(review["allowed_evidence_ids"])
        for result in audit["claim_results"]:
            if not set(result["evidence_ids"]).issubset(approved):
                raise WorkflowError("audit references unapproved evidence")

    @staticmethod
    def _merge_evidence(existing: list[dict], additional: list[dict]) -> list[dict]:
        """Deduplicate recovery results deterministically under the 60-record contract."""
        merged: list[dict] = []
        seen: set[tuple[str, str]] = set()
        for record in [*existing, *additional]:
            key = (str(record.get("source") or "").lower(), str(record.get("paper_id") or "").lower())
            if not key[0] or not key[1] or key in seen:
                continue
            seen.add(key)
            merged.append(record)
            if len(merged) >= 60:
                break
        return merged

    @staticmethod
    def _merge_retrieval_summaries(existing: list[dict], additional: list[dict]) -> list[dict]:
        """Keep bounded, aggregate retrieval observations across recovery rounds."""
        return [*existing, *additional][:96]

    @staticmethod
    def _validate_review_evidence(review: Mapping[str, Any], evidence_set: Mapping[str, Any]) -> dict:
        """Reject references to unseen evidence and normalize semantic partial coverage.

        ``not_reported`` and ``not_comparable`` are evidence-backed research
        findings.  If a reviewer returns either with a known evidence id, the
        workflow must produce a qualified answer instead of a blank failure.
        """
        available = {record["evidence_id"] for record in evidence_set["records"]}
        approved = set(review["allowed_evidence_ids"])
        covered = {evidence_id for item in review["coverage"] for evidence_id in item["evidence_ids"]}
        if not approved.issubset(available) or not covered.issubset(available):
            raise WorkflowError("review approves unknown evidence")
        if covered and review["coverage_status"] == "insufficient":
            return {
                **review,
                "coverage_status": "partial",
                "allowed_evidence_ids": list(dict.fromkeys([*review["allowed_evidence_ids"], *covered])),
            }
        return dict(review)

    @staticmethod
    def _validate_gap_targets(gap: Mapping[str, Any], plan: Mapping[str, Any]) -> None:
        plan_group_ids = {group["id"] for group in plan["groups"]}
        if any(group["group_id"] not in plan_group_ids for group in gap["groups"]):
            raise WorkflowError("research gap targets an unknown group")

    def _retrieve_group_queries(self, run_id: str, group: Mapping[str, Any], *, query_limit: int) -> dict:
        """Execute and persist one query at a time under the shared deadline."""
        records: list[dict] = []
        summaries: list[dict] = []
        for query_index, query in enumerate(list(group["queries"])[:max(0, query_limit)], 1):
            self._store.assert_active(run_id)
            if self._store.remaining_seconds(run_id) <= self.FINALIZATION_RESERVE_SECONDS:
                self._store.record_event(run_id, "retrieval_query", "skipped", {
                    "group_id": group["id"], "query_index": query_index,
                    "reason": "finalization_reserve",
                })
                break
            query_group = {**group, "queries": [query]}
            retrieved = validate_artifact("evidence_set", self._roles.retriever(query_group))
            if any(record["group_id"] != group["id"] for record in retrieved["records"]):
                raise WorkflowError("retrieval returned evidence for the wrong group")
            records = self._merge_evidence(records, retrieved["records"])
            summaries = self._merge_retrieval_summaries(summaries, retrieved["retrieval_summary"])
            incremental = validate_artifact("evidence_set", {
                "schema_version": 1, "records": records, "retrieval_summary": summaries,
            })
            self._store.add_artifact(run_id, "evidence_set", incremental)
            status = summaries[-1]["source_status"] if summaries else "unknown"
            self._store.record_event(run_id, "retrieval_query", "completed", {
                "group_id": group["id"], "query_index": query_index,
                "source_status": status, "evidence_count": len(records),
            })
        return {"schema_version": 1, "records": records, "retrieval_summary": summaries}

    def run(self, run_id: str, owner_ref: str, question: Mapping[str, Any]) -> dict:
        """Run roles in a fixed sequence and return a safe orchestration summary.

        A caller may pass an already-created run only when it has exactly the
        same owner reference; normal product integration will create it at task
        creation.  No exception body is persisted or returned.
        """
        try:
            try:
                run = self._store.create_run(run_id, owner_ref)
            except WorkflowError as exc:
                if str(exc) != "workflow run already exists":
                    raise
                run = self._store.get_run(run_id)
                if run["owner_ref"] != owner_ref:
                    raise WorkflowError("workflow run owner mismatch")

            # The coordinator, rather than a caller/Agent, is authoritative
            # for the deadline and remaining-call allowance carried by roles.
            envelope_input = dict(question)
            envelope_input["deadline_at"] = run["deadline_at"]
            envelope_input["remaining_model_calls"] = run["max_model_calls"] - run["model_calls_used"]
            envelope = validate_artifact("question_envelope", envelope_input)
            if envelope["task_id"] != run_id:
                raise WorkflowError("question task id mismatch")
            self._store.add_artifact(run_id, "question_envelope", envelope)

            plan = validate_artifact("research_plan", self._model_role(run_id, "planner", self._roles.planner, envelope))
            self._store.add_artifact(run_id, "research_plan", plan)
            self._store.transition(run_id, "planned", details={"group_count": len(plan["groups"])})
            self._store.transition(run_id, "retrieving", details={"group_count": len(plan["groups"])})

            records: list[dict] = []
            retrieval_summary: list[dict] = []
            for group in plan["groups"]:
                retrieved = self._retrieve_group_queries(
                    run_id, group, query_limit=self.MAX_INITIAL_QUERIES_PER_GROUP,
                )
                records.extend(retrieved["records"])
                retrieval_summary = self._merge_retrieval_summaries(retrieval_summary, retrieved["retrieval_summary"])
            evidence_set = validate_artifact("evidence_set", {
                "schema_version": 1, "records": records, "retrieval_summary": retrieval_summary,
            })
            self._store.add_artifact(run_id, "evidence_set", evidence_set)
            self._store.transition(run_id, "reviewing", details={"evidence_count": len(records)})

            review = validate_artifact(
                "evidence_review", self._model_role(run_id, "reviewer", self._roles.reviewer, plan, evidence_set)
            )
            review = self._validate_review_evidence(review, evidence_set)
            self._store.add_artifact(run_id, "evidence_review", review)
            # Insufficient coverage is a research finding, not an immediate
            # infrastructure failure.  The coordinator allows at most two
            # deterministic recovery rounds: gap analysis -> targeted search
            # -> review.  This consumes at most four additional model calls.
            for round_number in range(1, self.MAX_EVIDENCE_RECOVERY_ROUNDS + 1):
                if review["coverage_status"] != "insufficient" or self._roles.gap_analyst is None:
                    break
                gap = validate_artifact(
                    "research_gap",
                    self._model_role(run_id, "gap_analysis", self._roles.gap_analyst,
                                     plan, review, evidence_set, round_number),
                )
                self._validate_gap_targets(gap, plan)
                self._store.add_artifact(run_id, "research_gap", gap)
                if not gap["groups"]:
                    break
                self._store.transition(run_id, "retrieving", details={"recovery_round": round_number,
                                                                          "gap_group_count": len(gap["groups"])})
                by_group = {group["id"]: group for group in plan["groups"]}
                recovered_records: list[dict] = []
                recovered_summaries: list[dict] = []
                recovery_queries_remaining = self.MAX_RECOVERY_QUERIES
                for gap_group in gap["groups"]:
                    if recovery_queries_remaining <= 0:
                        break
                    base_group = by_group[gap_group["group_id"]]
                    recovery_group = {**base_group, "queries": gap_group["queries"], "recovery_round": round_number}
                    query_count = min(recovery_queries_remaining, len(recovery_group["queries"]))
                    retrieved = self._retrieve_group_queries(run_id, recovery_group, query_limit=query_count)
                    recovery_queries_remaining -= query_count
                    recovered_records.extend(retrieved["records"])
                    recovered_summaries = self._merge_retrieval_summaries(recovered_summaries, retrieved["retrieval_summary"])
                merged_records = self._merge_evidence(records, recovered_records)
                records = merged_records
                retrieval_summary = self._merge_retrieval_summaries(retrieval_summary, recovered_summaries)
                evidence_set = validate_artifact("evidence_set", {
                    "schema_version": 1, "records": records, "retrieval_summary": retrieval_summary,
                })
                self._store.add_artifact(run_id, "evidence_set", evidence_set)
                self._store.transition(run_id, "reviewing", details={"recovery_round": round_number,
                                                                         "evidence_count": len(records)})
                review = validate_artifact(
                    "evidence_review", self._model_role(run_id, "reviewer", self._roles.reviewer, plan, evidence_set)
                )
                review = self._validate_review_evidence(review, evidence_set)
                self._store.add_artifact(run_id, "evidence_review", review)

            # A reviewer may still label the overall question insufficient
            # while approving a narrow, reliable subset.  That subset merits a
            # qualified answer, never a blank failure page.
            if review["coverage_status"] == "insufficient":
                if review["allowed_evidence_ids"]:
                    review = {**review, "coverage_status": "partial"}
                    self._store.add_artifact(run_id, "evidence_review", review)
                else:
                    self._store.transition(run_id, "failed", details={"coverage_status": "insufficient",
                                                                          "recovery_rounds": self.MAX_EVIDENCE_RECOVERY_ROUNDS},
                                           failure_code="INSUFFICIENT_EVIDENCE")
                    return self.summary(run_id)

            self._store.transition(run_id, "writing", details={"coverage_status": review["coverage_status"]})
            draft = validate_artifact(
                "draft_answer", self._model_role(run_id, "writer", self._roles.writer, envelope, review, evidence_set)
            )
            self._ensure_draft_is_within_review(draft, review)
            self._store.add_artifact(run_id, "draft_answer", draft)
            self._store.transition(run_id, "auditing", details={"draft_claim_count": len(draft["claim_evidence_map"])})

            audit = validate_artifact(
                "citation_audit", self._model_role(run_id, "auditor", self._roles.auditor, draft, review)
            )
            self._ensure_audit_matches_draft(audit, draft, review)
            self._store.add_artifact(run_id, "citation_audit", audit)
            if audit["status"] == "needs_revision":
                self._store.transition(run_id, "writing", details={"revision": 1})
                draft = validate_artifact(
                    "draft_answer", self._model_role(run_id, "writer_revision", self._roles.writer,
                                                       envelope, review, evidence_set, audit)
                )
                self._ensure_draft_is_within_review(draft, review)
                self._store.add_artifact(run_id, "draft_answer", draft)
                self._store.transition(run_id, "auditing", details={"revision": 1})
                audit = validate_artifact(
                    "citation_audit", self._model_role(run_id, "auditor_revision", self._roles.auditor, draft, review)
                )
                self._ensure_audit_matches_draft(audit, draft, review)
                self._store.add_artifact(run_id, "citation_audit", audit)

            final_status = "completed" if audit["status"] == "passed" and review["coverage_status"] == "sufficient" else "partial"
            self._store.transition(run_id, final_status, details={"coverage_status": review["coverage_status"], "audit_status": audit["status"]})
            return self.summary(run_id)
        except Exception as exc:
            failure_code = _safe_failure_code(exc)
            try:
                run = self._store.get_run(run_id)
                if run["status"] not in {"completed", "partial", "needs_review", "failed", "timed_out", "cancelled"}:
                    self._store.transition(run_id, "failed", details={"reason": failure_code}, failure_code=failure_code)
            except Exception:
                pass
            return self.summary(run_id, fallback_failure_code=failure_code)

    def summary(self, run_id: str, *, fallback_failure_code: str | None = None) -> dict:
        """Return the browser-safe workflow projection, never raw artifacts."""
        try:
            run = self._store.get_run(run_id)
            stages = self._store.list_stages(run_id)
        except Exception:
            return {"workflow_status": "failed", "failure_code": fallback_failure_code or "WORKFLOW_STORAGE_UNAVAILABLE"}
        return {
            "workflow_status": run["status"],
            "failure_code": run["failure_code"],
            "model_calls_used": run["model_calls_used"],
            "model_call_limit": run["max_model_calls"],
            "deadline_at": run["deadline_at"],
            "stages": [{"stage": stage["stage"], "status": stage["status"]} for stage in stages],
        }
