"""Fail-closed account database schema check and narrow idempotent migration.

This command intentionally supports only the password-column widening required
by salted scrypt hashes. It never creates users, reads password values, or
prints connection settings and exception text.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
import os
import re
import time
from typing import Callable, Sequence

import pymysql
from dotenv import load_dotenv


REPORT_SCHEMA = "sciassistant.account-schema/v1"
PASSWORD_COLUMN_MIN_LENGTH = 255
AUTH_VERSION_COLUMN_SQL = (
    "ALTER TABLE `users` ADD COLUMN `auth_version` INT UNSIGNED NOT NULL DEFAULT 0"
)
MIGRATION_LOCK_NAME = "sciassistant_account_schema_v1"
PROVISION_LOCK_NAME = "sciassistant_account_privileges_v1"
_SAFE_DATABASE_RE = re.compile(r"^[A-Za-z0-9_]{1,64}$")
_SAFE_USER_RE = re.compile(r"^[A-Za-z0-9_]{1,32}$")
APP_PRIVILEGES = frozenset({"SELECT", "INSERT", "UPDATE", "DELETE"})
MIGRATION_PRIVILEGES = frozenset({"SELECT", "ALTER", "CREATE"})
DATABASE_OPERATION_ATTEMPTS = 6
DATABASE_OPERATION_RETRY_DELAY_SECONDS = 5
# Retry only transport failures that can occur while MySQL replaces its
# temporary initialization server with the final TCP server. Authentication,
# privilege and schema failures must remain fail-fast.
TRANSIENT_MYSQL_ERROR_CODES = frozenset({2002, 2003, 2006, 2013})
PASSWORD_RESET_TABLE_SQL = """CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `token_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime NULL DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `token_hash` (`token_hash`),
  KEY `idx_password_reset_user_id` (`user_id`),
  KEY `idx_password_reset_expires_at` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci"""


class SchemaFailure(RuntimeError):
    """A safe, externally reportable schema failure."""

    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


@dataclass(frozen=True)
class PasswordColumn:
    data_type: str
    maximum_length: int
    nullable: bool

    @property
    def ready(self) -> bool:
        return (
            self.data_type == "varchar"
            and not self.nullable
            and self.maximum_length >= PASSWORD_COLUMN_MIN_LENGTH
        )


@dataclass(frozen=True)
class AuthVersionColumn:
    data_type: str
    column_type: str
    nullable: bool
    default: object

    @property
    def ready(self) -> bool:
        try:
            default = int(self.default)
        except (TypeError, ValueError):
            return False
        return (
            self.data_type == "int"
            and "unsigned" in self.column_type
            and not self.nullable
            and default == 0
        )


def _value(row: object, key: str, index: int):
    if isinstance(row, dict):
        return row.get(key)
    if isinstance(row, (tuple, list)) and len(row) > index:
        return row[index]
    return None


def inspect_password_column(connection, database: str) -> PasswordColumn:
    """Read metadata only; never inspect password values."""
    with connection.cursor() as cursor:
        cursor.execute(
            "SELECT DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, IS_NULLABLE "
            "FROM information_schema.COLUMNS "
            "WHERE TABLE_SCHEMA = %s AND TABLE_NAME = 'users' "
            "AND COLUMN_NAME = 'password'",
            (database,),
        )
        row = cursor.fetchone()
    if not row:
        raise SchemaFailure("PASSWORD_COLUMN_MISSING")
    data_type = str(_value(row, "DATA_TYPE", 0) or "").lower()
    maximum_length = _value(row, "CHARACTER_MAXIMUM_LENGTH", 1)
    nullable = str(_value(row, "IS_NULLABLE", 2) or "").upper()
    if data_type != "varchar" or nullable != "NO":
        raise SchemaFailure("PASSWORD_COLUMN_UNSUPPORTED")
    try:
        maximum_length = int(maximum_length)
    except (TypeError, ValueError) as exc:
        raise SchemaFailure("PASSWORD_COLUMN_UNSUPPORTED") from exc
    if maximum_length <= 0:
        raise SchemaFailure("PASSWORD_COLUMN_UNSUPPORTED")
    return PasswordColumn(data_type, maximum_length, False)


def inspect_auth_version_column(connection, database: str) -> AuthVersionColumn | None:
    """Inspect the revocation generation without reading account data."""
    with connection.cursor() as cursor:
        cursor.execute(
            "SELECT DATA_TYPE, COLUMN_TYPE, IS_NULLABLE, COLUMN_DEFAULT "
            "FROM information_schema.COLUMNS "
            "WHERE TABLE_SCHEMA = %s AND TABLE_NAME = 'users' "
            "AND COLUMN_NAME = 'auth_version'",
            (database,),
        )
        row = cursor.fetchone()
    if not row:
        return None
    column = AuthVersionColumn(
        str(_value(row, "DATA_TYPE", 0) or "").lower(),
        str(_value(row, "COLUMN_TYPE", 1) or "").lower(),
        str(_value(row, "IS_NULLABLE", 2) or "").upper() == "YES",
        _value(row, "COLUMN_DEFAULT", 3),
    )
    if not column.ready:
        raise SchemaFailure("AUTH_VERSION_COLUMN_UNSUPPORTED")
    return column


def _password_reset_table_ready(connection, database: str) -> bool:
    with connection.cursor() as cursor:
        cursor.execute(
            "SELECT 1 AS present FROM information_schema.TABLES "
            "WHERE TABLE_SCHEMA = %s AND TABLE_NAME = 'password_reset_tokens'",
            (database,),
        )
        return cursor.fetchone() is not None


def check_schema(connection, database: str) -> dict:
    column = inspect_password_column(connection, database)
    auth_version_column = inspect_auth_version_column(connection, database)
    reset_table_ready = _password_reset_table_ready(connection, database)
    return {
        "schema": REPORT_SCHEMA,
        "status": "ready" if column.ready and auth_version_column and reset_table_ready else "migration_required",
        "password_column": {
            "type": column.data_type,
            "minimum_length": PASSWORD_COLUMN_MIN_LENGTH,
            "actual_length": column.maximum_length,
            "nullable": column.nullable,
        },
        "password_reset_table_ready": reset_table_ready,
        "auth_version_column_ready": auth_version_column is not None,
        "changed": False,
    }


def _lock_result(row: object, key: str) -> int:
    value = _value(row, key, 0)
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def _validated_identity(database: str, app_user: str, migration_user: str) -> None:
    if not _SAFE_DATABASE_RE.fullmatch(database):
        raise SchemaFailure("DATABASE_NAME_UNSUPPORTED")
    if not _SAFE_USER_RE.fullmatch(app_user) or not _SAFE_USER_RE.fullmatch(migration_user):
        raise SchemaFailure("DATABASE_USER_UNSUPPORTED")
    if app_user.lower() == "root" or migration_user.lower() == "root" or app_user == migration_user:
        raise SchemaFailure("DATABASE_IDENTITIES_NOT_SEPARATE")


def _grantee(user: str) -> str:
    return f"'{user}'@'%'"


def _schema_privileges(connection, database: str, user: str) -> set[str]:
    with connection.cursor() as cursor:
        cursor.execute(
            "SELECT PRIVILEGE_TYPE FROM information_schema.SCHEMA_PRIVILEGES "
            "WHERE TABLE_SCHEMA = %s AND GRANTEE = %s",
            (database, _grantee(user)),
        )
        rows = cursor.fetchall() or ()
    return {str(_value(row, "PRIVILEGE_TYPE", 0) or "").upper() for row in rows}


def _global_privileges(connection, user: str) -> set[str]:
    with connection.cursor() as cursor:
        cursor.execute(
            "SELECT PRIVILEGE_TYPE FROM information_schema.USER_PRIVILEGES WHERE GRANTEE = %s",
            (_grantee(user),),
        )
        rows = cursor.fetchall() or ()
    return {
        str(_value(row, "PRIVILEGE_TYPE", 0) or "").upper()
        for row in rows
        if str(_value(row, "PRIVILEGE_TYPE", 0) or "").upper() != "USAGE"
    }


def provision_runtime_identities(
    connection,
    database: str,
    app_user: str,
    app_password: str,
    migration_user: str,
    migration_password: str,
    lock_timeout: int = 30,
) -> dict:
    """Reconcile two dedicated MySQL identities to exact least privileges."""
    _validated_identity(database, app_user, migration_user)
    if not app_password or not migration_password or app_password == migration_password:
        raise SchemaFailure("DATABASE_PASSWORDS_NOT_SEPARATE")
    acquired = False
    try:
        with connection.cursor() as cursor:
            cursor.execute(
                "SELECT GET_LOCK(%s, %s) AS acquired",
                (PROVISION_LOCK_NAME, lock_timeout),
            )
            acquired = _lock_result(cursor.fetchone(), "acquired") == 1
        if not acquired:
            raise SchemaFailure("PROVISION_LOCK_UNAVAILABLE")

        database_identifier = f"`{database}`"
        identities = (
            (app_user, app_password, "SELECT, INSERT, UPDATE, DELETE"),
            (migration_user, migration_password, "SELECT, ALTER, CREATE"),
        )
        with connection.cursor() as cursor:
            for user, password, grants in identities:
                cursor.execute("CREATE USER IF NOT EXISTS %s@'%%' IDENTIFIED BY %s", (user, password))
                cursor.execute("ALTER USER %s@'%%' IDENTIFIED BY %s", (user, password))
                cursor.execute("REVOKE ALL PRIVILEGES, GRANT OPTION FROM %s@'%%'", (user,))
                cursor.execute(f"GRANT {grants} ON {database_identifier}.* TO %s@'%%'", (user,))

        app_schema = _schema_privileges(connection, database, app_user)
        migration_schema = _schema_privileges(connection, database, migration_user)
        app_global = _global_privileges(connection, app_user)
        migration_global = _global_privileges(connection, migration_user)
        verified = (
            app_schema == APP_PRIVILEGES
            and migration_schema == MIGRATION_PRIVILEGES
            and not app_global
            and not migration_global
        )
        if not verified:
            raise SchemaFailure("PRIVILEGE_VERIFICATION_FAILED")
        return {
            "schema": REPORT_SCHEMA,
            "status": "provisioned",
            "identities_separate": True,
            "application_privileges_exact": True,
            "migration_privileges_exact": True,
            "global_privileges_absent": True,
        }
    finally:
        if acquired:
            try:
                with connection.cursor() as cursor:
                    cursor.execute(
                        "SELECT RELEASE_LOCK(%s) AS released",
                        (PROVISION_LOCK_NAME,),
                    )
            except Exception:
                pass


def migrate_schema(connection, database: str, lock_timeout: int = 30) -> dict:
    """Widen the one supported column under a connection-scoped MySQL lock."""
    acquired = False
    try:
        with connection.cursor() as cursor:
            cursor.execute(
                "SELECT GET_LOCK(%s, %s) AS acquired",
                (MIGRATION_LOCK_NAME, lock_timeout),
            )
            acquired = _lock_result(cursor.fetchone(), "acquired") == 1
        if not acquired:
            raise SchemaFailure("MIGRATION_LOCK_UNAVAILABLE")

        before = inspect_password_column(connection, database)
        auth_version_before = inspect_auth_version_column(connection, database)
        reset_table_existed = _password_reset_table_ready(connection, database)
        changed = False
        if not before.ready:
            with connection.cursor() as cursor:
                cursor.execute(
                    "ALTER TABLE `users` MODIFY COLUMN `password` VARCHAR(255) NOT NULL"
                )
            connection.commit()
            changed = True

        if auth_version_before is None:
            with connection.cursor() as cursor:
                cursor.execute(AUTH_VERSION_COLUMN_SQL)
            connection.commit()
            changed = True

        if not reset_table_existed:
            with connection.cursor() as cursor:
                cursor.execute(PASSWORD_RESET_TABLE_SQL)
            connection.commit()
            changed = True

        after_report = check_schema(connection, database)
        if after_report["status"] != "ready":
            raise SchemaFailure("MIGRATION_VERIFICATION_FAILED")
        return {
            "schema": REPORT_SCHEMA,
            "status": "migrated" if changed else "ready",
            "password_column": after_report["password_column"],
            "password_reset_table_ready": True,
            "auth_version_column_ready": True,
            "changed": changed,
        }
    finally:
        if acquired:
            try:
                with connection.cursor() as cursor:
                    cursor.execute(
                        "SELECT RELEASE_LOCK(%s) AS released",
                        (MIGRATION_LOCK_NAME,),
                    )
            except Exception:
                # The lock is connection-scoped and is also released when the
                # connection closes. Never mask the migration result here.
                pass


def _connection_settings() -> tuple[dict, str]:
    load_dotenv()
    database = os.getenv("MYSQL_DATABASE", "chatai").strip()
    if not database:
        raise SchemaFailure("DATABASE_NAME_MISSING")
    return ({
        "host": os.getenv("MYSQL_HOST", "localhost"),
        "user": os.getenv("MYSQL_USER", "root"),
        "password": os.getenv("MYSQL_PASSWORD", ""),
        "database": database,
        "charset": "utf8mb4",
        "cursorclass": pymysql.cursors.DictCursor,
        "connect_timeout": 10,
        "read_timeout": 15,
        "write_timeout": 30,
    }, database)


def _is_transient_mysql_error(error: pymysql.MySQLError) -> bool:
    """Classify retryable transport failures without inspecting error text."""
    if not isinstance(error, pymysql.OperationalError) or not error.args:
        return False
    try:
        return int(error.args[0]) in TRANSIENT_MYSQL_ERROR_CODES
    except (TypeError, ValueError):
        return False


def _run_connected_action(action: str, connection, database: str) -> tuple[dict, int]:
    if action == "check":
        report = check_schema(connection, database)
        return report, 0 if report["status"] == "ready" else 2
    if action == "provision":
        return provision_runtime_identities(
            connection,
            database,
            os.getenv("MYSQL_APP_USER", "").strip(),
            os.getenv("MYSQL_APP_PASSWORD", ""),
            os.getenv("MYSQL_MIGRATION_USER", "").strip(),
            os.getenv("MYSQL_MIGRATION_PASSWORD", ""),
        ), 0
    return migrate_schema(connection, database), 0


def run(
    action: str,
    connector: Callable = pymysql.connect,
    sleeper: Callable[[float], None] = time.sleep,
) -> tuple[dict, int]:
    settings, database = _connection_settings()
    for attempt in range(1, DATABASE_OPERATION_ATTEMPTS + 1):
        connection = None
        retry = False
        try:
            connection = connector(**settings)
            return _run_connected_action(action, connection, database)
        except SchemaFailure as exc:
            return {"schema": REPORT_SCHEMA, "status": "error", "error": exc.code}, 1
        except pymysql.MySQLError as exc:
            retry = (
                attempt < DATABASE_OPERATION_ATTEMPTS
                and _is_transient_mysql_error(exc)
            )
            if not retry:
                return {
                    "schema": REPORT_SCHEMA,
                    "status": "error",
                    "error": "DATABASE_OPERATION_FAILED",
                }, 1
        finally:
            if connection is not None:
                try:
                    connection.close()
                except Exception:
                    pass
        if retry:
            sleeper(DATABASE_OPERATION_RETRY_DELAY_SECONDS)

    # The loop always returns on success or final failure. Keep a fixed safe
    # fallback so static analysis and future refactors remain fail closed.
    return {"schema": REPORT_SCHEMA, "status": "error", "error": "DATABASE_OPERATION_FAILED"}, 1


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Check or migrate the account database schema.")
    parser.add_argument("action", choices=("check", "migrate", "provision"))
    args = parser.parse_args(argv)
    report, exit_code = run(args.action)
    print(json.dumps(report, ensure_ascii=False, sort_keys=True))
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
