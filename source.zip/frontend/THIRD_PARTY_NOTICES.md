# Browser assets (self-hosted)

The versions below reproduce the existing UI dependencies; this change is not a dependency major-version migration or a claim that all dependency vulnerabilities have been audited.

| Component | Pinned version | License | Local attribution |
| --- | --- | --- | --- |
| Tailwind CSS | 3.4.17 | MIT | chatAi/vendor/tailwindcss/LICENSE |
| PrismJS | 1.29.0 | MIT | chatAi/vendor/prism/LICENSE |
| KaTeX (including fonts) | 0.16.9 | MIT | chatAi/vendor/katex/LICENSE |
| Font Awesome CSS | 4.7.0 | MIT | chatAi/vendor/font-awesome/LICENSE-CSS |
| Font Awesome fonts | 4.7.0 | SIL OFL 1.1 | chatAi/vendor/font-awesome/LICENSE-FONT |
| Font Awesome upstream README | 4.7.0 | CC BY 3.0 | Upstream README, Dave Gandy attribution and original links preserved |

Packages are downloaded by npm using the committed package-lock integrity entries, with lifecycle scripts disabled. Runtime assets and their SHA256 digests are recorded in chatAi/assets/manifest.json. No npm, Node, registry access or browser compiler is needed to serve these files.

Prism's local bundle concatenates the upstream minified core and the existing language modules in dependency order, preserving source headers and the MIT license. Font and CSS files remain unmodified. These notices do not replace the separate existing Python/PyMuPDF disclosures and deployment license gates.
