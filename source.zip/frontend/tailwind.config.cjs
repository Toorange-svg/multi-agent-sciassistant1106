const path = require('node:path');
const root = path.resolve(__dirname, '..');
module.exports = {
    darkMode: ['selector', '[data-chat-theme="dark"]'],
    content: [path.join(root, 'chatAi/*.{html,js}'), path.join(root, 'web/*.html'),
        ...['app.py', 'web_app.py', 'multi_agent_presentation.py'].map(name => path.join(root, name))],
    // All runtime choices must be complete literal strings, never bg-${value}.
    safelist: ['hidden', 'block', 'flex', 'inline-flex', 'grid', 'text-red-600', 'text-green-700',
        'ring-2', 'ring-indigo-500', 'border-red-500', 'bg-green-600', 'justify-start', 'justify-end'],
    theme: {extend: {
        colors: {primary:'#3B82F6', secondary:'#10B981', dark:'#1E293B', light:'#F8FAFC',
            'chat-bg':'#F1F5F9', 'user-message':'#3B82F6', 'ai-message':'#F1F5F9'},
        fontFamily: {sans:['Inter','system-ui','sans-serif']}
    }},
    plugins: []
};
