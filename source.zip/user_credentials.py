"""Account-owned encrypted provider settings and explicit worker capabilities.

No request writes process-wide environment variables. Secrets never belong to
task snapshots, prompts, URLs or logs; only an authenticated gateway makes a cap.
"""
from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
import base64
import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import sqlite3
from types import MappingProxyType

from cryptography.fernet import Fernet, InvalidToken

FIELDS = ('MODEL_REQUEST_TOKEN', 'MODEL_REQUEST_TOKENS', 'LLAMA_CLOUD_API_KEY', 'EMBEDDING_API_KEY')
_scope = ContextVar('account_provider_credentials', default=None)
ROOT = Path(__file__).resolve().parent


def owner_id(value):
    text = str(value)
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,128}', text):
        raise ValueError('INVALID_CREDENTIAL_OWNER')
    return text


def token(value):
    if not isinstance(value, str) or not 8 <= len(value.strip()) <= 512:
        raise ValueError('INVALID_PROVIDER_KEY')
    value = value.strip()
    if any(ord(c) < 33 or ord(c) > 126 for c in value) or value in {'[REDACTED]', '********'}:
        raise ValueError('INVALID_PROVIDER_KEY')
    return value


def split_keys(value):
    if not isinstance(value, str):
        raise ValueError('INVALID_PROVIDER_KEY')
    return list(dict.fromkeys(token(v) for v in re.split(r'[,;\r\n]+', value) if v.strip()))


@dataclass(frozen=True)
class ProviderCapability:
    owner: str
    values: dict = field(repr=False)

    def __post_init__(self):
        object.__setattr__(self, 'owner', owner_id(self.owner))
        object.__setattr__(self, 'values', MappingProxyType({n: str(self.values.get(n) or '') for n in FIELDS}))


@contextmanager
def provider_scope(capability):
    if capability is not None and not isinstance(capability, ProviderCapability):
        raise ValueError('INVALID_PROVIDER_CAPABILITY')
    marker = _scope.set(capability)
    try:
        yield
    finally:
        _scope.reset(marker)


def current_capability():
    cap = _scope.get()
    if cap is not None:
        return cap
    # Only an owned worker is launched with this environment by the gateway.
    owner = os.getenv('SCIASSISTANT_PROVIDER_OWNER')
    return ProviderCapability(owner, {n: os.getenv(n, '') for n in FIELDS}) if owner else None


def provider_value(name, fallback=''):
    cap = current_capability()
    return cap.values.get(name, '') if cap else (os.getenv(name) or fallback or '')


def scoped_storage(base):
    cap = current_capability()
    base = Path(base).resolve()
    if not cap:
        return base
    target = base / 'users' / cap.owner
    if target.parent.is_symlink() or target.is_symlink() or not target.resolve().is_relative_to(base):
        raise ValueError('UNSAFE_USER_STORAGE')
    return target


def child_environment(base):
    result = dict(base)
    cap = current_capability()
    if not cap:
        return result  # explicitly local/admin CLI remains compatible
    result.update(cap.values)
    result['SCIASSISTANT_PROVIDER_OWNER'] = cap.owner
    # No alternative legacy credential is allowed to rescue an empty user key.
    for name in ('OPENROUTER_API_KEY', 'OPENAI_API_KEY', 'DEEPSEEK_API_KEY'):
        result[name] = ''  # dotenv must not repopulate an unset legacy alias
    private = scoped_storage(result.get('SCIASSISTANT_USER_RUNTIME_ROOT', ROOT / 'logs/user_runtime'))
    result['MODEL_KEY_POOL_STATE_PATH'] = str(private / 'keys.sqlite3')
    result['PDF_PARSE_CACHE_DIR'] = str(private / 'pdf_cache')
    workspace = Path(result.get('SCIASSISTANT_WORKSPACE', ROOT / 'workspace')).resolve()
    result['SCIASSISTANT_WORKSPACE'] = str(workspace / 'users' / cap.owner)
    result['SCIASSISTANT_QDRANT_COLLECTION'] = 'sciassistant_user_' + hashlib.sha256(cap.owner.encode()).hexdigest()[:24]
    return result


class CredentialStore:
    def __init__(self, path, secret):
        self.path = Path(path)
        secret = secret.strip() if isinstance(secret, str) else secret
        if not isinstance(secret, str) or len(secret) < 16:
            raise ValueError('CREDENTIAL_ENCRYPTION_UNAVAILABLE')
        key = hmac.new(secret.encode(), b'sciassistant/account-provider-v1', hashlib.sha256).digest()
        self.cipher = Fernet(base64.urlsafe_b64encode(key))

    def _connect(self):
        if self.path.is_symlink():
            raise ValueError('CREDENTIAL_STORAGE_UNAVAILABLE')
        self.path.parent.mkdir(parents=True, exist_ok=True)
        con = sqlite3.connect(self.path, timeout=5)
        con.execute('CREATE TABLE IF NOT EXISTS provider_keys (owner TEXT PRIMARY KEY, ciphertext BLOB NOT NULL)')
        try:
            os.chmod(self.path, 0o600)
        except OSError:
            pass
        return con

    def _decode(self, owner, blob):
        try:
            value = json.loads(self.cipher.decrypt(blob))
            if value.get('owner') != owner or value.get('version') != 1 or not isinstance(value.get('values'), dict):
                raise ValueError
            return {n: value['values'].get(n, '') for n in FIELDS}
        except (ValueError, TypeError, InvalidToken):
            raise ValueError('CREDENTIAL_STORAGE_UNAVAILABLE') from None

    def capability(self, owner):
        owner = owner_id(owner)
        if not self.path.exists():
            return ProviderCapability(owner, {})
        con = self._connect()
        try:
            row = con.execute('SELECT ciphertext FROM provider_keys WHERE owner=?', (owner,)).fetchone()
            return ProviderCapability(owner, self._decode(owner, row[0]) if row else {})
        finally:
            con.close()

    @staticmethod
    def status(cap):
        keys = split_keys(cap.values['MODEL_REQUEST_TOKENS']) + split_keys(cap.values['MODEL_REQUEST_TOKEN'])
        return {'schema_version': 'sciassistant.account-provider-status/v1',
                'deepseek': {'configured': bool(keys), 'key_count': len(set(keys))},
                'llama': {'configured': bool(cap.values['LLAMA_CLOUD_API_KEY'])},
                'embedding': {'configured': bool(cap.values['EMBEDDING_API_KEY'])},
                'shared_fallback': False}

    def update(self, owner, body, *, only_if_empty=False):
        owner = owner_id(owner)
        if not isinstance(body, dict) or set(body) - {'deepseek_keys', 'llama_key', 'embedding_key', 'clear'}:
            raise ValueError('INVALID_PROVIDER_SETTINGS')
        clear = body.get('clear', [])
        if not isinstance(clear, list) or any(v not in {'deepseek', 'llama', 'embedding'} for v in clear):
            raise ValueError('INVALID_PROVIDER_SETTINGS')
        changes = {}
        if 'deepseek_keys' in body:
            raw = body['deepseek_keys']
            if not isinstance(raw, list) or not 1 <= len(raw) <= 10 or 'deepseek' in clear:
                raise ValueError('INVALID_PROVIDER_SETTINGS')
            keys = list(dict.fromkeys(token(v) for v in raw))
            changes.update(MODEL_REQUEST_TOKEN=keys[0], MODEL_REQUEST_TOKENS=','.join(keys[1:]))
        if 'llama_key' in body:
            if 'llama' in clear:
                raise ValueError('INVALID_PROVIDER_SETTINGS')
            changes['LLAMA_CLOUD_API_KEY'] = token(body['llama_key'])
        if 'embedding_key' in body:
            if 'embedding' in clear:
                raise ValueError('INVALID_PROVIDER_SETTINGS')
            changes['EMBEDDING_API_KEY'] = token(body['embedding_key'])
        if 'deepseek' in clear:
            changes.update(MODEL_REQUEST_TOKEN='', MODEL_REQUEST_TOKENS='')
        if 'llama' in clear:
            changes['LLAMA_CLOUD_API_KEY'] = ''
        if 'embedding' in clear:
            changes['EMBEDDING_API_KEY'] = ''
        con = self._connect()
        try:
            con.execute('BEGIN IMMEDIATE')
            row = con.execute('SELECT ciphertext FROM provider_keys WHERE owner=?', (owner,)).fetchone()
            values = self._decode(owner, row[0]) if row else {n: '' for n in FIELDS}
            if only_if_empty and any(values.values()) and any(values.get(n, '') != v for n, v in changes.items()):
                raise ValueError('CREDENTIAL_MIGRATION_CONFLICT')
            values.update(changes)
            blob = self.cipher.encrypt(json.dumps({'version': 1, 'owner': owner, 'values': values}).encode())
            con.execute('INSERT INTO provider_keys VALUES(?,?) ON CONFLICT(owner) DO UPDATE SET ciphertext=excluded.ciphertext', (owner, blob))
            con.commit()
            return self.status(ProviderCapability(owner, values))
        finally:
            con.close()
